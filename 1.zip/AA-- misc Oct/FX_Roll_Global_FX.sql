SELECT 
   OPENPOSITIONS.FUND
                ,OPENPOSITIONS.STRATEGY
                ,OPENPOSITIONS.FOLIO_ID
                ,OPENPOSITIONS.FOLIO_PATH
                ,OPENPOSITIONS.SICOVAM
                ,OPENPOSITIONS.REFERENCE
                ,OPENPOSITIONS.NAME
                --,OPENPOSITIONS.DATEVAL
                ,CASE 
                                WHEN (OPENPOSITIONS.QUANTITY < 0 AND FXROLLS.QUANTITE < 0) THEN OPENPOSITIONS.QUANTITY 
                                WHEN (OPENPOSITIONS.QUANTITY < 0 AND FXROLLS.QUANTITE > 0) THEN OPENPOSITIONS.QUANTITY * - 1
                                WHEN (OPENPOSITIONS.QUANTITY > 0 AND FXROLLS.QUANTITE > 0) THEN OPENPOSITIONS.QUANTITY 
                                WHEN (OPENPOSITIONS.QUANTITY > 0 AND FXROLLS.QUANTITE < 0) THEN OPENPOSITIONS.QUANTITY * - 1                                
                                ELSE OPENPOSITIONS.QUANTITY
                                END QUANTITY
                ,OPENPOSITIONS.CCY
                --,FXROLLS.REFCON AS FXROLL_TRADE_ID
                --,FXROLLS.QUANTITE AS FXROLL_QUANTITY
                ,FXROLLS.COURS AS FXROLL_PRICE
                ,FXROLLS.DATEVAL AS FXROLL_DATEVAL
FROM (
                SELECT T3.NAME AS FUND
                                ,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY
                                ,P.OPCVM AS FOLIO_ID
                                ,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
                                ,T.SICOVAM AS SICOVAM
                                ,T.REFERENCE AS REFERENCE
                                ,T.LIBELLE AS NAME
                                ,H.DATEVAL
                                ,SUM(H.QUANTITE) AS QUANTITY
                                ,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY
                FROM POSITION P
                INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
                INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
                INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
                INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
                INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
                INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
                INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
                LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
                WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
                                AND P.OPCVM NOT IN (138237) -- Exclude Global FX>FX Rolls
                                AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
                                AND BE.COMPTA = 1 -- Select only Business Events that affect position  
                                AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE,+1)) 
                                AND H.DATENEG < TRUNC(SYSDATE) 
                                AND H.DEPOSITAIRE IN (10027731,10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
                GROUP BY T3.NAME, P.OPCVM, T.SICOVAM, T.REFERENCE, H.DATEVAL, T.LIBELLE, T.DEVISECTT, T.DEVISEAC, T.NOMINAL        
                ) OPENPOSITIONS

LEFT JOIN HISTOMVTS FXROLLS 
  ON FXROLLS.DATENEG = TRUNC(SYSDATE) 
  AND FXROLLS.DEPOSITAIRE IN (10027731,10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM
  AND FXROLLS.INFOS NOT LIKE 'FX Rolls'
  AND FXROLLS.OPCVM IN (138237,138264) --Global FX>FX Rolls
  
  UNION ALL
  
SELECT 
   OPENPOSITIONS.FUND
                ,OPENPOSITIONS.STRATEGY
                ,FXROLLS.OPCVM
                ,SUBSTR(BTG_FOLIONAMEPATH(FXROLLS.OPCVM), INSTR(BTG_FOLIONAMEPATH(FXROLLS.OPCVM), '/',1,7)+1) AS FOLIO_PATH
                ,OPENPOSITIONS.SICOVAM
                ,OPENPOSITIONS.REFERENCE
                ,OPENPOSITIONS.NAME
                --,OPENPOSITIONS.DATEVAL
                ,CASE 
                                WHEN (OPENPOSITIONS.QUANTITY < 0 AND FXROLLS.QUANTITE < 0) THEN OPENPOSITIONS.QUANTITY 
                                WHEN (OPENPOSITIONS.QUANTITY < 0 AND FXROLLS.QUANTITE > 0) THEN OPENPOSITIONS.QUANTITY * - 1
                                WHEN (OPENPOSITIONS.QUANTITY > 0 AND FXROLLS.QUANTITE > 0) THEN OPENPOSITIONS.QUANTITY 
                                WHEN (OPENPOSITIONS.QUANTITY > 0 AND FXROLLS.QUANTITE < 0) THEN OPENPOSITIONS.QUANTITY * - 1                                
                                ELSE OPENPOSITIONS.QUANTITY
                                END QUANTITY
                ,OPENPOSITIONS.CCY
                --,FXROLLS.REFCON AS FXROLL_TRADE_ID
                --,FXROLLS.QUANTITE AS FXROLL_QUANTITY
                ,FXROLLS.COURS AS FXROLL_PRICE
                ,FXROLLS.DATEVAL AS FXROLL_DATEVAL
FROM (
                SELECT T3.NAME AS FUND
                                ,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY
                                ,P.OPCVM AS FOLIO_ID
                                ,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
                                ,T.SICOVAM AS SICOVAM
                                ,T.REFERENCE AS REFERENCE
                                ,T.LIBELLE AS NAME
                                ,H.DATEVAL
                                ,SUM(H.QUANTITE) AS QUANTITY
                                ,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY
                FROM POSITION P
                INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
                INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
                INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
                INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
                INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
                INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
                INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
                LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
                WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
                                AND P.OPCVM NOT IN (138237,138264) -- Exclude Global FX>FX Rolls
                                AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
                                AND BE.COMPTA = 1 -- Select only Business Events that affect position  
                                AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE,+1)) 
                                AND H.DATENEG < TRUNC(SYSDATE) 
                                AND H.DEPOSITAIRE IN (10027731,10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM       
                GROUP BY T3.NAME, P.OPCVM, T.SICOVAM, T.REFERENCE, H.DATEVAL, T.LIBELLE, T.DEVISECTT, T.DEVISEAC, T.NOMINAL        
                ) OPENPOSITIONS

INNER JOIN HISTOMVTS FXROLLS 
  ON FXROLLS.DATENEG = TRUNC(SYSDATE) 
  AND FXROLLS.DEPOSITAIRE IN (10027731,10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM
  AND FXROLLS.INFOS NOT LIKE 'FX Rolls'
  AND FXROLLS.OPCVM IN (138237,138264) --Global FX>FX Rolls