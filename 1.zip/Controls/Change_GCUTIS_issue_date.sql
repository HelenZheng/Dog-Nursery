update TITRES set EMISSION='10-Jan-18' where SICOVAM=70733378;
commit;