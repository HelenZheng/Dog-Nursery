select 

 DEVISE_TO_STR(T.DEVISECTT) CCY
, A.LIBELLE ALLOTMENT
, T.SICOVAM
, T.REFERENCE 
, T.LIBELLE NAME
, T.FINPER MATURITY
, CASE 
  WHEN T.FINPER < SYSDATE THEN 'Y'
  ELSE 'N'
  END IS_MATURED  
, T.MARCHE MARKET_ID
, M.LIBELLE MARKET_NAME



  
from TITRES T 
inner join AFFECTATION A on A.IDENT = T.AFFECTATION
left join MARCHE M on M.CODEDEVISE = T.DEVISECTT AND M.MNEMOMARCHE = T.MARCHE

where T.TYPE = 'O'
order by 1,2,4
;

------------------------------------------------- LIST ALL INSTRUMENTS BY MARKET ****WILL TAKE TIME TO PROCESS ** tab: Data_for_List_Instrument

select 

TITRES.marche ||  DEVISE_TO_STR(TITRES.devisectt) KEY
, TITRES.marche MARKET_ID
, TITRES.type INST_TYPE
, AFFECTATION.libelle INST_ALLOTMENT
, TITRES.sicovam INST_SICOVAM
, TITRES.reference INST_REFERENCE
, TITRES.libelle INST_NAME
, DEVISE_TO_STR(TITRES.devisectt) INST_CCY

 from TITRES
 
 ------ALLOTMENT
LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation 
------

where 
 (TITRES.type in ('A','O') and AFFECTATION.libelle not in (
 'Bank Loan','Bond - Dummy','Cash Loan', 'External funds','External fund series', 'Internal Funds','Share - Dummy','Shares - Delisted','Shares - Unlisted') 
 or 
 TITRES.type in ('D') and AFFECTATION.libelle in ('Convertibles')
)
and TITRES.marche is not null --only Instruments with market assigned to it
and (TO_CHAR(TITRES.FINPER, 'DD-MON-YYYY') > sysdate or TITRES.FINPER is null)
--and TITRES.marche =0
--and TITRES.marche = 327685
--and TITRES.sicovam = 6760294

 group by 
 TITRES.marche
, TITRES.type
, AFFECTATION.libelle 
, TITRES.sicovam
, TITRES.reference 
, TITRES.libelle 
, TITRES.devisectt

order by MARKET_ID, INST_TYPE, INST_ALLOTMENT,INST_REFERENCE

 ;


---------------------------------------------------------------------------------

-----------------------------------------------LIST ALL MARKETS AND THEIR PSET BIC *** tab Market_in_Currencis_to_REMAIN
select 
MARCHE.mnemomarche || DEVISE_TO_STR(MARCHE.codedevise) KEY 
, MARCHE.mnemomarche MARKET_ID
, num_to_str(MARCHE.mnemomarche) MARKET_CODE
, MARCHE.codedevise MARKET_CCY_CODE
, DEVISE_TO_STR(MARCHE.codedevise) MARKET_CCY
, MARCHE.libelle MARKET_NAME
, EXTRNL_REF_MARKET_VALUE.value MARKET_PSET_BIC

from MARCHE

left join EXTRNL_REF_MARKET_VALUE
on  EXTRNL_REF_MARKET_VALUE.currency = MARCHE.codedevise
and EXTRNL_REF_MARKET_VALUE.market = MARCHE.mnemomarche 
and EXTRNL_REF_MARKET_VALUE.ref_ident=3 --3	JPM PSET BIC

order by MARKET_CCY
;

---------------------------------------------------------------------------------
--- COUNT ALL INSTRUMENTS AND GROUP BY MARKET

select 
TITRES.marche ||  DEVISE_TO_STR(TITRES.devisectt) KEY
, TITRES.marche MARKET_ID
, MARCHE.libelle MARKET_NAME
, MARCHEORGANISE.nom LISTED_MARKET_NAME
, DEVISE_TO_STR(TITRES.devisectt) INST_CCY
, count(*) NUMBER_OF_INSTRUMENTS

from TITRES

------MARKET (CURRENCIES>PLACES)
left join MARCHE 
	ON MARCHE.codedevise = TITRES.devisectt
		AND MARCHE.mnemomarche = TITRES.marche

------MARKET (MARKET>LISTED MARKETS)
LEFT JOIN MARCHEORGANISE
	ON MARCHEORGANISE.ident = TITRES.marche		

where TITRES.type not in ('E','K','X') -- Exclude FX intruments

group by 
  TITRES.marche
, TITRES.devisectt
, MARCHE.libelle
, MARCHEORGANISE.nom 

order by MARKET_NAME, LISTED_MARKET_NAME

;



---------------------------------------------------------------------------------



select 
 TITRES.type
, AFFECTATION.libelle ALLOTMENT
, TITRES.sicovam
, TITRES.reference
, TITRES.libelle name
, SECTOR_INSTRUMENT_ASSOCIATION.sector INST_BBG_COUNTRY_CODE 
, SECTORS.name INST_BBG_COUNTRY_NAME
, DEVISE_TO_STR(MARCHE.codedevise) MARKET_CCY
, TITRES.marche MARKET_ID
, num_to_str(MARCHE.mnemomarche) MARKET_CODE
, MARCHE.libelle MARKET_NAME
, EXTRNL_REF_MARKET_VALUE.value MARKET_PSET_BIC
, MARCHEORGANISE.nom LISTED_MARKET_NAME


from TITRES 

------ALLOTMENT
LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation 
------

------SECTOR_INSTRUMENT_ASSOCIATION 
left join SECTOR_INSTRUMENT_ASSOCIATION 
on SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam 
--and SECTOR_INSTRUMENT_ASSOCIATION.type=1364 --1364 BBG Country Code
------

------SECTOR
left join SECTORS
on SECTORS.id = SECTOR_INSTRUMENT_ASSOCIATION.sector
------

------MARKET (CURRENCIES>PLACES)
LEFT JOIN MARCHE
	ON MARCHE.codedevise = TITRES.devisectt
		AND MARCHE.mnemomarche = TITRES.marche
------

------MARKET (MARKET>LISTED MARKETS)
LEFT JOIN MARCHEORGANISE
	ON MARCHEORGANISE.ident = TITRES.marche		
------

------PSET BIC
left join EXTRNL_REF_MARKET_VALUE
on  EXTRNL_REF_MARKET_VALUE.currency = MARCHE.codedevise
and EXTRNL_REF_MARKET_VALUE.market = MARCHE.mnemomarche 
and EXTRNL_REF_MARKET_VALUE.ref_ident=3 --3	PSET BIC


where TITRES.type = 'I' -- O Bonds, A Shares
--where TITRES.type not in ('F','O','A','H') -- O Bonds, A Shares, H Issuers

--and MARCHE.mnemomarche is not null


AND AFFECTATION.libelle NOT IN (
    'External fund series'
    ,'External funds'
    ,'Indexes'
    ,'Internal Funds'
    ,'Share - Dummy'
    ,'Shares - Delisted'
    ,'Shares - Suspended'
    ,'Shares - Ticker Change'
    ,'Shares - Unlisted'
    )

order by TYPE, ALLOTMENT, REFERENCE

;


-------------------------------------------------------

SELECT DISTINCT

HISTOMVTS.SICOVAM SICOVAM
,TITRES.reference REFERENCE
,TITRES.libelle NAME
--,TO_CHAR(HISTOMVTS.dateneg, 'YYYY-MM-DD') TRADE_DATE
, SECTOR_INSTRUMENT_ASSOCIATION.sector INST_BBG_COUNTRY_CODE
, SECTORS.name INST_COUNTRY_NAME
, AFFECTATION.libelle ALLOTMENT
, DEVISE_TO_STR(MARCHE.codedevise) MARKET_CCY
, MARCHE.mnemomarche MARKET_ID
, num_to_str(MARCHE.mnemomarche) MARKET_CODE
--, MARCHE.codedevise CCY_CODE

, MARCHE.libelle MARKET_NAME
, EXTRNL_REF_MARKET_VALUE.value MARKET_PSET_BIC


------Select all trades in the database + Backups
FROM (
	SELECT *
	FROM HISTOMVTS
	
	UNION ALL
	
	SELECT *
	FROM btg_histomvts_backup2017 b2017
WHERE NOT EXISTS (
		SELECT 1
		FROM histomvts h
		WHERE h.refcon = b2017.refcon
		)

UNION ALL

SELECT *
FROM btg_histomvts_backup2015 b2015
WHERE NOT EXISTS (
		SELECT 1
		FROM btg_histomvts_backup2017 b
		WHERE b.refcon = b2015.refcon
		)

UNION ALL

SELECT *
FROM btg_histomvts_backup2014 b2014
WHERE NOT EXISTS (
		SELECT 1
		FROM btg_histomvts_backup2015 b
		WHERE b.refcon = b2014.refcon
		) ) HISTOMVTS
    

    
------INSTRUMENT
LEFT JOIN TITRES 
	ON TITRES.sicovam = HISTOMVTS.sicovam   
------

------ALLOTMENT
LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation 
------

------BUSINESS_EVENTS
INNER JOIN BUSINESS_EVENTS
	ON BUSINESS_EVENTS.id = HISTOMVTS.type
		AND BUSINESS_EVENTS.compta = 1 -- Select trades with BUSINESS EVENT affecting position only
------

------SECTOR_INSTRUMENT_ASSOCIATION 
left join SECTOR_INSTRUMENT_ASSOCIATION 
on SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam 
and SECTOR_INSTRUMENT_ASSOCIATION.type=1364 --1364 BBG Country Code
------

------SECTOR
left join SECTORS
on SECTORS.id = SECTOR_INSTRUMENT_ASSOCIATION.sector
------

------MARKET
LEFT JOIN MARCHE
	ON MARCHE.codedevise = TITRES.devisectt
		AND MARCHE.mnemomarche = TITRES.marche
------

------JPM PSET BIC
left join EXTRNL_REF_MARKET_VALUE
on  EXTRNL_REF_MARKET_VALUE.currency = MARCHE.codedevise
and EXTRNL_REF_MARKET_VALUE.market = MARCHE.mnemomarche 
and EXTRNL_REF_MARKET_VALUE.ref_ident=3 --3	JPM PSET BIC
------

WHERE  HISTOMVTS.backoffice NOT IN (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) -- Exclude cancelled trades    
AND TITRES.type in ('A')  --INST_TYPE A = Shares O = Bonds
AND TRUNC(HISTOMVTS.DATENEG) >= '01-MAR-2016' -- START_DATE
--AND TRUNC(HISTOMVTS.DATENEG) <= '01-MAR-2016' -- START_DATE
AND TRUNC(HISTOMVTS.DATENEG) <= '08-MAY-2017' -- END_DATE
AND AFFECTATION.libelle NOT IN (
    'External fund series'
    ,'External funds'
    ,'Indexes'
    ,'Internal Funds'
    ,'Share - Dummy'
    ,'Shares - Delisted'
    ,'Shares - Suspended'
    ,'Shares - Ticker Change'
    ,'Shares - Unlisted'
    )
;

-- COUNT ALL INSTRUMENTS IN SOPHIS 
select count(*) from TITRES where TITRES.type not in ('E','K','X'); -- Exclude FX intruments

-- COUNT ALL INSTRUMENTS IN SOPHIS 
select 

TYPE 
, DECODE(type
        ,'A', 'Share'
        ,'B', 'Cap and Floor'
        ,'C', 'Commission'
        ,'D', 'Derivative'
        ,'E', 'Exchange'
        ,'F', 'Future'
        ,'G', 'Contracts for difference'
        ,'H', 'Issuer'
        ,'I', 'Index'
        ,'K', 'Non Delivarable Forward Forex'
        ,'L', 'Repo'
        ,'M', 'Option on listed market'
        ,'N', 'Package'
        ,'O', 'Bond'
        ,'P', 'Loan'
        ,'Q', 'Commodities'
        ,'R', 'Rate'
        ,'S', 'Swap'
        ,'T', 'NCD'
        ,'W', 'Option swap'
        ,'X', 'Forex'
) TYPE_DEFINITION
, count(*) NUMBER_OF_INSTRUMENTS
from TITRES 
group by type
order by type
;
