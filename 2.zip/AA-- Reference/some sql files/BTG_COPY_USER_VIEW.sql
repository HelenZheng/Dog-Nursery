create or replace PROCEDURE BTG_COPY_USER_VIEW (PViewName USERPREFSLR.NAME%TYPE, PFromUserName RISKUSERS.NAME%TYPE, PToUserName RISKUSERS.NAME%TYPE)
IS
  
  l_FromUserId  RISKUSERS.ident%TYPE;
  l_ToUserId    RISKUSERS.ident%TYPE;
  
BEGIN
    
    SELECT RISKUSERS.ident
    INTO l_FromUserId
    FROM RISKUSERS
    WHERE RISKUSERS.name = PFromUserName;
    
    SELECT RISKUSERS.ident
    INTO l_ToUserId
    FROM RISKUSERS
    WHERE RISKUSERS.name = PToUserName;
        
    SAVEPOINT trans;
    
    BEGIN
      
      DELETE FROM USERPREFSLR
      WHERE USERPREFSLR.userid = l_ToUserId
      AND USERPREFSLR.name = PViewName;
      
      INSERT INTO USERPREFSLR
      SELECT l_ToUserId AS USERID, 
      USERPREFSLR.type, 
      USERPREFSLR.ident,
      USERPREFSLR.name, 
      USERPREFSLR.value
      FROM USERPREFSLR
      WHERE USERPREFSLR.userid = l_FromUserId
      AND USERPREFSLR.name = PViewName;
    
    EXCEPTION

      WHEN OTHERS THEN
        ROLLBACK TO trans;
        RAISE;
        
    END;
    
END BTG_COPY_USER_VIEW;