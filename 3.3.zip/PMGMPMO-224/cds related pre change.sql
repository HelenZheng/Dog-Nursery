--index


SELECT DISTINCT cds.reference CDS_REFERENCE
	,cds.libelle CDS_Name
	,decode(cdsunderlying.type, 'H', 'Issuer', 'I', 'Index', cdsunderlying.type) Index_TYPE -- For Index CDS the undelrying must be an Index
  ,extrnl_references_instruments.VALUE Generic_Ticker
   ,red.VALUE RED_ID_ON_INDEX
	,cdsunderlying.modele Index_Model
	,decode(cdsunderlying.credit_method, 1, 'Components', 2, 'Index', 3, 'Index + Components', 4, 'Components + Index', 5, 'Components Spread', 6, 'Very Synthetic') Index_Credit_Risk_Method
	,devise_to_str(cdsunderlying.devisectt) Index_Currency
	,devise_to_str(volatilityref.devisectt) Index_CDS_Volatility_Currency -- The Currency in the CDS Volatilit MUST be same as the currency of the Index
	,volatilityref.reference Index_CDS_Volatility -- The name of the CDS Volatility must be the right one for the corresponding CCY of the Index. E,g if the Index has ccy EUR then the CDS Volatilit must be INDEX CDS VOL EUR
	,composition.reference Index_Composition -- The composition of the Indec MUSTN'T be blank and should always choose the DUMMY ISSUER FOR ITRAXX
	,BTG_FN_AUDIT_INST_USER(cds.sicovam) Instr_last_amended_by
FROM titres cds
INNER JOIN titres cdsunderlying
	ON cdsunderlying.sicovam = cds.j1refcon2
LEFT JOIN ISSUER_VOLATILITY_REF
	ON ISSUER_VOLATILITY_REF.sico = cdsunderlying.sicovam
LEFT JOIN titres volatilityref
	ON volatilityref.sicovam = ISSUER_VOLATILITY_REF.issuer
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (14414,90565) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	WHERE cds.affectation = 22
		AND upper(cds.reference) LIKE '%INDEX%'
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN panier
	ON panier.sicovam = cdsunderlying.sicovam
LEFT JOIN titres composition
	ON composition.sicovam = panier.sicopanier
  
LEFT JOIN extrnl_references_instruments
ON extrnl_references_instruments.SOPHIS_IDENT=cds.SICOVAM
AND extrnl_references_instruments.ref_ident=688 -- Generic ticker

LEFT JOIN extrnl_references_instruments red
ON red.SOPHIS_IDENT=cdsunderlying.SICOVAM
AND red.ref_ident=16 -- RED ID

WHERE (
		cdsunderlying.type != 'I'
		OR ISSUER_VOLATILITY_REF.currency != cdsunderlying.devisectt
		OR ISSUER_VOLATILITY_REF.sico IS NULL
		OR cdsunderlying.modele != 'Credit Risk'
		OR cdsunderlying.credit_method != 2
		OR composition.reference IS NULL
    OR extrnl_references_instruments.VALUE is null
    OR red.VALUE is null
		);
		
		
        
        
        
        --single
        
         SELECT DISTINCT cds.sicovam
	,undelrying.reference Underlyiner_Reference
	,decode(undelrying.type, 'H', 'Issuer', 'O', 'Bond', 'D', 'Convertible Bond', undelrying.type) Undelrying_Type
	,cds.reference cds_ref
	,cds.libelle cds_name
	,cds.emission cds_start_date
	,defaultevent.NAME CDS_Restructuring_Type
  ,cds.modele CDS_Model
  ,seniority.name CDS_Seniority
	,cds.recoveryjambe1 CDS_Recovery_Rate
	,CREDITRISK_RECORATE.rate * 100 Issuer_Recovery_Rate
  ,bondissuer.reference Bond_Issuer_ref
	,issuer.reference CDS_issuer_ref
	,issuer.libelle CDS_issuer_name
  ,CREDITRISK_credit_model.model_name Issuer_CDS_Interpolation_Model
  ,decode(CREDITRISK_credit_model.def_maturity_model, 0, 'XXX', 1, 'IMM', 2, 'Series',3, 'Sovereign', 4, 'Series+1Q',CREDITRISK_credit_model.def_maturity_model) Issuer_CDS_Maturity_Model
  ,CREDITRISK_credit_model.def_maturity_model_serie Issuer_Series_No
	,extrnl_references_instruments.value Issuer_REDID
	,BloombergName.NAME Issuer_Sector_Bloomberg
	,cntry_of_issue_code.code Issuer_Sector_CNTRY_OF_ISSUE

FROM titres cds
INNER JOIN titres undelrying
ON undelrying.sicovam = cds.j1refcon2
  
left JOIN titres bondissuer
ON bondissuer.sicovam = undelrying.code_emet
  
INNER JOIN titres issuer
	ON issuer.sicovam = cds.coupon1
LEFT JOIN extrnl_references_instruments
	ON extrnl_references_instruments.sophis_ident = issuer.sicovam
		AND extrnl_references_instruments.ref_ident = 16
LEFT JOIN extrnl_references_instruments cdsisin
	ON cdsisin.sophis_ident = cds.sicovam
		AND cdsisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments issuerisin
	ON issuerisin.sophis_ident = issuer.sicovam
		AND issuerisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments cdsref
	ON cdsref.sophis_ident = cds.sicovam
		AND cdsref.ref_ident = 16
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
WITH FOLIO.ident IN (14414,90565) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.j1refcon2
	WHERE cds.affectation = 22
		AND undelrying.type != 'I'
		AND upper(cds.reference) NOT LIKE '%ABX%'
		AND upper(cds.reference) NOT LIKE '%CMBX%'
		AND upper(cds.reference) NOT LIKE '%IOS%'
		AND upper(cds.reference) NOT LIKE '%MBX%'
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN btg_mapping_code
	ON btg_mapping_code.input_code = cds.sicovam
		AND btg_mapping_code.source_id = 3
		AND btg_mapping_code.type_id = 69
		AND output_code = 'Y'
    
LEFT JOIN CREDITRISK_RECORATE
	ON CREDITRISK_RECORATE.code = issuer.sicovam
		AND CREDITRISK_RECORATE.default_event = cds.default_event_leg1
		AND CREDITRISK_RECORATE.seniority = cds.senjambe1
LEFT JOIN sector_instrument_association bloomberg
	ON bloomberg.sicovam = issuer.sicovam
		AND bloomberg.type = 1363
LEFT JOIN sectors BloombergName
	ON BloombergName.id = bloomberg.sector
LEFT JOIN sector_instrument_association cntry_of_issue
	ON cntry_of_issue.sicovam = issuer.sicovam
		AND cntry_of_issue.type = 5349
LEFT JOIN sectors cntry_of_issue_code
	ON cntry_of_issue_code.id = cntry_of_issue.sector
LEFT JOIN defaultevent
	ON defaultevent.id = cds.default_event_leg1
  
LEFT JOIN seniority
on seniority.id=cds.senjambe1

LEFT JOIN CREDITRISK_credit_model
ON CREDITRISK_credit_model.code = issuer.sicovam

WHERE cds.affectation = 22


	
	AND (
    (cds.recoveryjambe1 != CREDITRISK_RECORATE.rate * 100 AND cds.fixedrecoveryrate1 = 1)-- flag if recovery rate on CDS is different from the one specified on issuer
		OR CREDITRISK_RECORATE.rate IS NULL -- flag if there is no recovery rate set up on the issuer
		OR extrnl_references_instruments.value IS NULL --flag if the 6 digits red is not set up on the issuer
		OR length(extrnl_references_instruments.value) !=6 --flag if the 6 digits red is not set up on the issuer as 6 digits
		OR BloombergName.NAME IS NULL --flag if the Bloomberg sector is not set up on the issuer
		OR cntry_of_issue_code.code IS NULL -- flag if the CNTRY_OF_ISSUE sector is not set up on the issuer
		OR (
			cds.emission >= to_date('20-sep-2014', 'dd-mon-yyyy')
			AND defaultevent.NAME NOT LIKE '%14%'
			) -- flag if the start date is after 2014 but the restructuring is not using the 2014 ISDA
    OR cds.modele !='Standard' -- flag if the model is not statndard
    OR cds.senjambe1 =0 -- flag if the seniority is not set
    OR cds.default_event_leg1 =0-- flag if the default event is not set
    OR CREDITRISK_credit_model.def_maturity_model_serie !=100 -- pick up issuer if CDS maturity model is not set to Series 100
    OR CREDITRISK_credit_model.model_name !='BootStrap' -- pick up issuer if the interpolation modle is not set to BootStrap
		);
        
        
        
        
        
        --edm
        
        
	
	SELECT DISTINCT undelrying.sicovam Bond_sicovam
	,undelrying.reference Bond_Reference
	,decode(undelrying.fixedspread, 1, 'CDS Fixed', 2, 'CDS Spread', 3, 'YTM Fixed', 4, 'YTM Spread', 5, 'Zero Coupon Spread', 6, 'Forward Spread', 7, 'Static Spread', 8, 'ASW Spread', 9, 'CDI + Spread', 10, 'CDI % SPread', 'Not Set') Bond_Spread_Type
	,bondspread_default_event.NAME BondSpread_Default_Event
	,defaultevent.NAME Issuer_Default_Event
	,issuer.sicovam Issuer_Sicovam
	,issuer.reference Issuer_ref
	,extrnl_references_instruments.value Issuer_REDID
FROM titres undelrying
INNER JOIN titres cds
	ON undelrying.sicovam = cds.j1refcon2
INNER JOIN titres issuer
	ON issuer.sicovam = undelrying.code_emet
LEFT JOIN extrnl_references_instruments
	ON extrnl_references_instruments.sophis_ident = issuer.sicovam
		AND extrnl_references_instruments.ref_ident = 16
LEFT JOIN extrnl_references_instruments cdsisin
	ON cdsisin.sophis_ident = cds.sicovam
		AND cdsisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments issuerisin
	ON issuerisin.sophis_ident = issuer.sicovam
		AND issuerisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments cdsref
	ON cdsref.sophis_ident = cds.sicovam
		AND cdsref.ref_ident = 16
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (14414,90565) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.coupon1
	INNER JOIN credit_model
		ON credit_model.code = undelrying.sicovam
	-- and credit_model.def_cdsrate!=0
	WHERE cds.affectation = 22
		AND undelrying.type != 'I'
		AND upper(cds.reference) NOT LIKE '%ABX%'
		AND upper(cds.reference) NOT LIKE '%CMBX%'
		AND upper(cds.reference) NOT LIKE '%IOS%'
		AND upper(cds.reference) NOT LIKE '%MBX%'
		AND upper(cds.reference) NOT LIKE '%INDEX%'
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position-- Only check CDS that has open position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN CREDITRISK_RECORATE
	ON CREDITRISK_RECORATE.code = issuer.sicovam
		AND CREDITRISK_RECORATE.default_event = cds.default_event_leg1
		AND CREDITRISK_RECORATE.seniority = cds.senjambe1
LEFT JOIN defaultevent
	ON defaultevent.id = CREDITRISK_RECORATE.default_event
LEFT JOIN defaultevent bondspread_default_event
	ON bondspread_default_event.id = undelrying.default_event
LEFT JOIN seniority
	ON seniority.id = cds.senjambe1
WHERE undelrying.type IN (
		'O'
		,'D'
		) -- Only check if undelrying is the actual bond for the CDS
	AND undelrying.devisectt=cds.devisectt -- Only check if undelrying is the same ccy as the ccy of the cds
	AND (
		undelrying.fixedspread != 2 -- 2 means CDS Spread in the drop down list
		OR undelrying.default_event = 0 -- 0 means the defualt event is not set
		OR undelrying.default_event != CREDITRISK_RECORATE.default_event -- also pick up if the defualt events on the issuer is not same as the one set on the bond
		);
    