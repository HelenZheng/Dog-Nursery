SELECT        FUND_BOOK_STRATEGY.Fund_NAME                                                  Fund
            , DEP.name                                                                      Depositary
            , FUND_BOOK_STRATEGY.BOOK_NAME                                                  Strategy
            , FUND_BOOK_STRATEGY.STRATEGY_NAME                                              Folio
            , TITRES.reference                                                              Instrument_Reference
            , TITRES.sicovam                                                                Sicovam
            , AFFECTATION.libelle                                                           Allotment
            , DEVISE_TO_STR(TITRES.devisectt)                                               Instrument_CCY 
            , CASE
                    WHEN TITRES.type = 'S' THEN TRUNC(TITRES.datefinal) --IRS, OIS, Inflation Swaps, vol swap, var swap, eq swap, CDS, Correlation Swaps
                    WHEN TITRES.type IN ('B','G','O') THEN TRUNC(TITRES.finper) --Caps and Floors, CFD, Bonds
                    WHEN TITRES.affectation IN (2,10,31,1250,1301,1060,1041,23 ) THEN TRUNC(TITRES.finper) --OTC Stock Derivatives, Listed Options, Swaptions, CDS Options, Variance Options, Dividend Option, Volatility Options, FX Option
                    WHEN (TITRES.type = 'F' OR TITRES.affectation = 14) THEN TRUNC(TITRES.echeance) --Dividend Future or Package
                    WHEN TITRES.type = 'K' THEN TRUNC(HISTOMVTS.dateval) --NDF
                    WHEN TITRES.type IN ('L','N') THEN TRUNC(TITRES.dateregl) --Repo
                    ELSE null
              END                                                                           Maturity_date
            , ROUND(
                      SUM ( 
                          CASE 
                              WHEN TITRES.type IN ('F','A','G','L') THEN HISTOMVTS.QUANTITE
                              WHEN TITRES.nominal = 0 THEN HISTOMVTS.QUANTITE
                              WHEN TITRES.nominal IS NULL THEN HISTOMVTS.QUANTITE
                              ELSE HISTOMVTS.QUANTITE * TITRES.nominal
                          END                                                                            
                          )
                    ,6)                                                                       Notional
            , SUM(HISTOMVTS.quantite)                                                         Quantity

FROM HISTOMVTS

INNER JOIN ( 
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH          FOLIO.ident   IN (14414)--Primary funds
                CONNECT BY PRIOR    FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID    =   HISTOMVTS.OPCVM

INNER JOIN TITRES
ON TITRES.sicovam = HISTOMVTS.sicovam
AND TITRES.type != 'E'

INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.id = HISTOMVTS.type
AND BUSINESS_EVENTS.compta = 1

LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation

LEFT JOIN TIERS DEP
ON DEP.ident = HISTOMVTS.depositaire

WHERE   HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 

GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, DEP.name, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, TITRES.reference, TITRES.sicovam, AFFECTATION.libelle, DEVISE_TO_STR(TITRES.devisectt), CASE
                    WHEN TITRES.type = 'S' THEN TRUNC(TITRES.datefinal) --IRS, OIS, Inflation Swaps, vol swap, var swap, eq swap, CDS, Correlation Swaps
                    WHEN TITRES.type IN ('B','G','O') THEN TRUNC(TITRES.finper) --Caps and Floors, CFD, Bonds
                    WHEN TITRES.affectation IN (2,10,31,1250,1301,1060,1041,23 ) THEN TRUNC(TITRES.finper) --OTC Stock Derivatives, Listed Options, Swaptions, CDS Options, Variance Options, Dividend Option, Volatility Options, FX Option
                    WHEN (TITRES.type = 'F' OR TITRES.affectation = 14) THEN TRUNC(TITRES.echeance) --Dividend Future or Package
                    WHEN TITRES.type = 'K' THEN TRUNC(HISTOMVTS.dateval) --NDF
                    WHEN TITRES.type IN ('L','N') THEN TRUNC(TITRES.dateregl) --Repo
                    ELSE null
              END

HAVING SUM(HISTOMVTS.quantite) <> 0

ORDER BY 1,2



--70489152