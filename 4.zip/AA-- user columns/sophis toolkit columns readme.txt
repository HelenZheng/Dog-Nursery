BTG Sophis Toolkit Columns
==========================

| Date       | Version | Author    | Notes                          |
|------------|--------:|-----------|--------------------------------|
| 2016-08-01 |     1.0 | Sam Clark | Initial Release                |
| 2016-09-12 |     1.1 | Sam Clark | New Columns                    |
| 2016-12-01 |     1.2 | Sam Clark | New Columns                    |
| 2017-01-05 |     1.3 | Sam Clark | New Columns                    |
| 2017-02-14 |     2.0 | Sam Clark | New Columns + Sophis 7 Upgrade |
| 2017-04-24 |     2.1 | Sam Clark | Octopus deployment             |
| 2017-06-27 |     2.2 | Sam Clark | New Columns                    |
| 2017-09-27 |     2.3 | Sam Clark | BTG Base Date Format           |
| 2017-11-14 |     2.4 | Sam Clark | Columns dps rounding           |


#### 1.0 (2016-08-01)

Initial release containing the following columns:
- BTG Pricing Ticker


#### 1.1 (2016-09-12)

Added new columns:

- BTG Allotment
- BTG Allotment **(T)**
- BTG Allotment Code
- BTG Allotment Code **(T)**
- BTG Cheapest Bond
- BTG Cheapest Bond Code
- BTG Cheapest Bond Last Price
- BTG Cheapest Bond Reference
- BTG Depositaries
- BTG Depositary
- BTG Depositary Code
- BTG Depositary Code **(T)**
- BTG Depositary Codes
- BTG EMIR Confirm Date **(T)**
- BTG EMIR Confirm Mean **(T)**
- BTG EMIR Confirm Mean Code **(T)**
- BTG EMIR Confirm Time **(T)**
- BTG EMIR Confirm UTI **(T)**
- BTG EMIR Confirm Venue **(T)**
- BTG EMIR Confirm Venue Code **(T)**
- BTG Portfolio Code
- BTG Portfolio Code **(T)**
- BTG Portfolio Codes
- BTG Position Type Code
- BTG Position Type Name
- BTG Top Level Strategies
- BTG Top Level Strategy
- BTG Top Level Strategy **(T)**
- BTG Top Level Strategy Code
- BTG Top Level Strategy Code **(T)**
- BTG Top Level Strategy Codes


#### 1.2 (2016-12-01)

Added new columns:
- BTG Depositary **(T)**


#### 1.3 (2017-01-05)

Added new columns:
- BTG Stock Borrowing Type Code
- BTG Stock Borrowing Type
- BTG Billing Frequency Code
- BTG Billing Frequency
- BTG Billing Currency Code
- BTG Billing Currency
- BTG Funding Rate Code
- BTG Funding Rate
- BTG Funding Spread


#### 2.0 (2017-02-14)

Upgraded to work with Sophis 7.1.3 and changed assembly file name to *BTG_INT_USER_COLUMNS_ASSEMBLY.DLL* inline with the new Sophis 7.1.3 naming scheme.

Added new columns:
- BTG - CUSIP **(T)**
- BTG - ISIN **(T)**
- BTG AdjustmentCode **(T)**
- BTG Affectation
- BTG Affectation **(T)**
- BTG Affectation Code
- BTG Affectation Code **(T)**
- BTG AffectPosition **(T)**
- BTG ASCOT Asset Swap Start Date
- BTG ASCOT Asset Swap Start Date **(T)**
- BTG Base Date
- BTG Base Date **(T)**
- BTG Benchmark
- BTG Benchmark **(T)**
- BTG Benchmark ISIN
- BTG Benchmark ISIN **(T)**
- BTG Benchmark Yield
- BTG Benchmark Yield **(T)**
- BTG Bloomberg Country **(T)**
- BTG BrokerCode **(T)**
- BTG BusinessEventsCode **(T)**
- BTG CB Begin Call Clause
- BTG CB Call Price Clause
- BTG CB Call Price Clause Per or Val
- BTG CB Credit Spread
- BTG CB End Call Clause
- BTG CB Frequency
- BTG CB SoftCall Barrier
- BTG CB SoftCall Barrier Per or Val
- BTG CCY 2nd Leg
- BTG Change In Yield
- BTG Change In Yield **(T)**
- BTG Change In Yield (D-1)
- BTG Change In Yield (D-1) **(T)**
- BTG Contract Size **(T)**
- BTG CounterPartieCode **(T)**
- BTG Counterparties
- BTG Counterparty
- BTG Counterparty **(T)**
- BTG Counterparty Code
- BTG Counterparty Code **(T)**
- BTG Counterparty Codes
- BTG Day Basis Count
- BTG Day Basis Count **(T)**
- BTG Days To Settle **(T)**
- BTG DepositaryCode **(T)**
- BTG EntityCode **(T)**
- BTG EQ Underlying **(T)**
- BTG EQ Underlying Code **(T)**
- BTG EQ Underlying Global Code **(T)**
- BTG First Trade Id by Entite **(T)**
- BTG Fixing Date - NDF
- BTG Fixing Date - NDF **(T)**
- BTG FolioCode **(T)**
- BTG FundFullFolioPatch **(T)**
- BTG FundSecondLevel **(T)**
- BTG FundSecondLevelCode **(T)**
- BTG FundStrategyLevel **(T)**
- BTG FundStrategyLevelCode **(T)**
- BTG FX First Trade Folio ID
- BTG FX Second CCY Position
- BTG GlobalCode **(T)**
- BTG Instrument Type
- BTG Instrument Type **(T)**
- BTG Last Despositary
- BTG Last Despositary Code
- BTG LastUpdated **(T)**
- BTG Market Place Code **(T)**
- BTG Market Place Name **(T)**
- BTG Method Into Account **(T)**
- BTG Next Coupon Date
- BTG NickNameAtivoGlobal **(T)**
- BTG Product Family
- BTG Product Family **(T)**
- BTG Quantity
- BTG Rate Leg **(T)**
- BTG Rate Leg Code **(T)**
- BTG Rate Leg Global Code **(T)**
- BTG Rate Leg Spread **(T)**
- BTG Rate Leg Value **(T)**
- BTG Risk Instrument Type
- BTG Risk Instrument Type **(T)**
- BTG Splits Per Fund **(T)**
- BTG Spread
- BTG Spread **(T)**
- BTG Spread (D-1)
- BTG Spread (D-1) **(T)**
- BTG Sub-Strategy **(T)**
- BTG Sub-Strategy Code **(T)**
- BTG Swap Paying Day Basis Count
- BTG Swap Paying Day Basis Count **(T)**
- BTG Swap Paying Leg Type
- BTG Swap Paying Leg Type **(T)**
- BTG Swap Paying Rate
- BTG Swap Paying Rate **(T)**
- BTG Swap Receiving Day Basis Count
- BTG Swap Receiving Day Basis Count **(T)**
- BTG Swap Receiving Leg Type
- BTG Swap Receiving Leg Type **(T)**
- BTG Swap Receiving Rate
- BTG Swap Receiving Rate **(T)**
- BTG Underlying Contract Size **(T)**
- BTG Underlying Instrument Code **(T)**
- BTG Underlying Instrument Ref **(T)**
- BTG Underlying Instrument Type **(T)**
- BTG Underlying Issuer
- BTG Underlying Issuer **(T)**
- BTG Underlying Issuer Code
- BTG Underlying Issuer Code **(T)**
- BTG Upload Yield
- BTG Upload Yield **(T)**
- BTG Upload Yield (D-1)
- BTG Upload Yield (D-1) **(T)**
- BTG Vega Underlying
- BTG Vega Underlying **(T)**
- CCY 2nd Leg


#### 2.1 (2017-04-24)

First release using octopus automated release.


#### 2.2 (2017-06-27)

Added new columns:
- BTG Counterparty Depositary Code **(T)**
- BTG Counterparty Depositary Name **(T)**


#### 2.3 (2017-09-27)

BTG Base Date portfolio and transaction column date format changed to: MM/DD/YYYY


#### 2.4 (2017-11-14)

BTG Spread and BTG Spread (D-1) portfolio and transaction columns round values to the number of decimal places specified by the "NumberOfDecimalsForPrice" sophis preference.


## All Columns

| Name                                | Type          | Group         | Author               |
|-------------------------------------|---------------|---------------|----------------------|
| BTG - CUSIP                         | Transaction   | BTG Pactual   | Sam Clark            |
| BTG - ISIN                          | Transaction   | BTG Pactual   | Sam Clark            |
| BTG AdjustmentCode                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Affectation                     | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Affectation                     | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Affectation Code                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Affectation Code                | Transaction   | BTG Pactual   | Sam Clark            |
| BTG AffectPosition                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Allotment                       | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Allotment                       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Allotment Code                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Allotment Code                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG ASCOT Asset Swap Start Date     | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG ASCOT Asset Swap Start Date     | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Base Date                       | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Base Date                       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Benchmark                       | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Benchmark                       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Benchmark ISIN                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Benchmark ISIN                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Benchmark Yield                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Benchmark Yield                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Billing Currency                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Billing Currency Code           | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Billing Frequency               | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Billing Frequency Code          | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Bloomberg Country               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG BrokerCode                      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG BusinessEventsCode              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG CB Begin Call Clause            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB Call Price Clause            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB Call Price Clause Per or Val | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB Credit Spread                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB End Call Clause              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB Frequency                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB SoftCall Barrier             | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CB SoftCall Barrier Per or Val  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG CCY 2nd Leg                     | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Change In Yield                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Change In Yield                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Change In Yield (D-1)           | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Change In Yield (D-1)           | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Cheapest Bond                   | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Cheapest Bond Code              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Cheapest Bond Last Price        | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Cheapest Bond Reference         | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Contract Size                   | Transaction   | BTG Pactual   | Sam Clark            |
| BTG CounterPartieCode               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Counterparties                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Counterparty                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Counterparty                    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Counterparty Code               | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Counterparty Code               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Counterparty Codes              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Counterparty Depositary Code    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Counterparty Depositary Name    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Day Basis Count                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Day Basis Count                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Days To Settle                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Depositaries                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Depositary                      | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Depositary                      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Depositary Code                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Depositary Code                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Depositary Codes                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG DepositaryCode                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Date               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Mean               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Mean Code          | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Time               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm UTI                | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Venue              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EMIR Confirm Venue Code         | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EntityCode                      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EQ Underlying                   | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EQ Underlying Code              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG EQ Underlying Global Code       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG First Trade Id by Entite        | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Fixing Date - NDF               | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Fixing Date - NDF               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FolioCode                       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FundFullFolioPatch              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Funding Rate                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Funding Rate Code               | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Funding Spread                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG FundSecondLevel                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FundSecondLevelCode             | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FundStrategyLevel               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FundStrategyLevelCode           | Transaction   | BTG Pactual   | Sam Clark            |
| BTG FX First Trade Folio ID         | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG FX Second CCY Position          | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG GlobalCode                      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Instrument Type                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Instrument Type                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Last Despositary                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Last Despositary Code           | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG LastUpdated                     | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Market Place Code               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Market Place Name               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Method Into Account             | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Next Coupon Date                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG NickNameAtivoGlobal             | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Portfolio Code                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Portfolio Code                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Portfolio Codes                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Position Type Code              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Position Type Name              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Pricing Ticker                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Product Family                  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Product Family                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Quantity                        | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Rate Leg                        | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Rate Leg Code                   | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Rate Leg Global Code            | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Rate Leg Spread                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Rate Leg Value                  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Risk Instrument Type            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Risk Instrument Type            | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Splits Per Fund                 | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Spread                          | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Spread                          | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Spread (D-1)                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Spread (D-1)                    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Stock Borrowing Type            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Stock Borrowing Type Code       | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Sub-Strategy                    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Sub-Strategy Code               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Day Basis Count     | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Day Basis Count     | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Leg Type            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Leg Type            | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Rate                | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Paying Rate                | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Day Basis Count  | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Day Basis Count  | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Leg Type         | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Leg Type         | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Rate             | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Swap Receiving Rate             | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategies            | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategy              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategy              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategy Code         | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategy Code         | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Top Level Strategy Codes        | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Underlying Contract Size        | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Underlying Instrument Code      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Underlying Instrument Ref       | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Underlying Instrument Type      | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Underlying Issuer               | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Underlying Issuer               | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Underlying Issuer Code          | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Underlying Issuer Code          | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Upload Yield                    | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Upload Yield                    | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Upload Yield (D-1)              | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Upload Yield (D-1)              | Transaction   | BTG Pactual   | Sam Clark            |
| BTG Vega Underlying                 | Portfolio     | BTG Pactual   | Sam Clark            |
| BTG Vega Underlying                 | Transaction   | BTG Pactual   | Sam Clark            |
| CCY 2nd Leg                         | Portfolio     | BTG Pactual   | Sam Clark            |

## Configuration


#### Position Type Configuration Format

```
{
    cancelledKernelStatusGroupId: 68415,
    listType: 'Black',
    flat: ['M_pLended', 'M_pVirtualForex'],
    hierarchy: ['M_pLended', 'M_pVirtualForex'],
    underlying: ['M_pLended', 'M_pVirtualForex']
}
```


#### List Types

| Type    | Description                                             |
|---------|---------------------------------------------------------|
| 'Black' | All position types are used except the ones in the list |
| 'White' | Only position types in the list are used                |


#### Position Types

| ID | Type                          |
|----|-------------------------------|
| 0  | 'M_pStandard'                 |
| 1  | 'M_pBlocked'                  |
| 2  | 'M_pArbitrage'                |
| 3  | 'M_pLended'                   |
| 4  | 'M_pSimulation'               |
| 5  | 'M_pBasket'                   |
| 6  | 'M_pBrokerage'                |
| 7  | 'M_pVirtualForex'             |
| 8  | 'M_pSimulatedVirtualForex'    |
| 9  | 'M_pUseTheoretical'           |
| 10 | 'M_pUseLast'                  |
| 11 | 'M_pUseArbitrage'             |
| 12 | 'M_pUseTheoreticalSimulation' |
| 13 | 'M_pUseLastSimulation'        |
| 14 | 'M_pUseArbitrageSimulation'   |
| 15 | 'M_pSecurityLoan'             |
| 16 | 'M_pContractForDifference'    |
| 17 | 'M_pVirtualMarginCall'        |
| 50 | 'M_pVirtual'                  |
| 75 | 'M_pVirtualForValue'          |


### Default Configuration


##### BTG_MAPPING_SOURCE

| ID | DESCRIPTION            |
|----|------------------------|
| 15 | Sophis Toolkit Columns |


##### BTG_MAPPING_TYPE

| ID | DESCRIPTION            |
|----|------------------------|
| 76 | Position Configuration |


##### BTG_MAPPING_CODE

| SOURCE_ID | TYPE_ID | INPUT_CODE | OUTPUT_CODE |
|-----------|---------|------------|-------------|
| 15        | 76      | 'DEFAULT'  | '{ cancelledKernelStatusGroupId: 68415, listType: 'Black', flat: ['M_pLended', 'M_pVirtualForex'], hierarchy: ['M_pLended', 'M_pVirtualForex'], underlying: ['M_pLended', 'M_pVirtualForex'] }' |


### User Configuration

The default configuration can be overriden on a per user basis by adding a new entry into the BTG_MAPPING_CODE table.

SOURCE_ID and TYPE_ID should be the same as the default above.

INPUT_CODE should be the Sophis User ID (obtainable from *RISKUSERS.ident* table column).

OUTPUT_CODE should be the new overriden position type configuration encoded as a JSON string (like the default above).

| SOURCE_ID | TYPE_ID | INPUT_CODE     | OUTPUT_CODE |
|-----------|---------|----------------|-------------|
| 15        | 76      | <RISK_USER_ID> | <CONFIGURATION_JSON_VALUE> |

Example
```
INSERT INTO BTG_MAPPING_CODE (SOURCE_ID, TYPE_ID, INPUT_CODE, OUTPUT_CODE) VALUES (15, 76, '3427', '{ cancelledKernelStatusGroupId: 68415, listType: ''White'', flat : [''M_pStandard''], hierarchy : [''M_pStandard''], underlying : [''M_pStandard''] }');
```
* * *



