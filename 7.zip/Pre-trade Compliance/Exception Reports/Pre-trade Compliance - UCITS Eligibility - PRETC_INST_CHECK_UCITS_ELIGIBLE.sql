--------------------------------------------------------------------SPEC--------------------------------------------------------------------------  
-- *****************************************************************
-- Description:    PRETC_CHECK_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 04 JUN 2018     Andre Bresslau     Created (COM-319)
-- *****************************************************************  

  PROCEDURE PRETC_CHECK_UCITS_ELIGIBLE 
	(
    IN_ALLOTMENT  IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
	);

  
--------------------------------------------------------------------BODY--------------------------------------------------------------------------  

-- *****************************************************************
-- Description:    PRETC_CHECK_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 04 JUN 2018     Andre Bresslau     Created (COM-319)
-- *****************************************************************  
PROCEDURE PRETC_CHECK_UCITS_ELIGIBLE
	(
    IN_ALLOTMENT  IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PRETC_CHECK_UCITS_ELIGIBLE
  -- *****************************************************************   
          OPEN OUT_CURSOR FOR
SELECT 
   INSTRUMENTS.SICOVAM
	,INSTRUMENTS.REFERENCE
	,INSTRUMENTS.NAME
  ,INSTRUMENTS.ALLOTMENT
	,INSTRUMENTS.CCY
  ,BTG_FN_AUDIT_INST_USER(INSTRUMENTS.SICOVAM) INSTR_LAST_AMENDED_BY
	,H.REFCON LATEST_TRADE_ID
	,T3.NAME DEPOSITARY
	,R.NAME TRADER	
  ,INSTRUMENTS.UCITS_ELIGIBLE
  
FROM (
	SELECT 
     T.SICOVAM
		,T.REFERENCE
		,T.LIBELLE NAME
    ,A.LIBELLE ALLOTMENT
    ,DEVISE_TO_STR(T.DEVISECTT) CCY
    ,CASE --688649=TRUE, 689149=FALSE
    WHEN SIA.SECTOR = 688649
      THEN 'TRUE'
    WHEN SIA.SECTOR = 689149
      THEN 'FALSE'
    ELSE ''
    END UCITS_ELIGIBLE
  FROM TITRES T
	INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T.SICOVAM
		AND SIA.TYPE = 688149 --UCITS_ELIGIBLE
	WHERE 
  CASE         
	  -- Exclude expired instruments
    WHEN (A.LIBELLE IN ('Dividend Future','Futures','Volatility Futures') AND T.ECHEANCE < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'CDS' AND T.DATEFINAL < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'Gov Bonds' AND T.FINPER < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'Corp Bonds' AND T.FINPER < SYSDATE) THEN 0
    WHEN (A.LIBELLE IN ('Dividend Options','Listed Options','Volatility Options') AND T.FINPER < SYSDATE) THEN 0
    -- 
    WHEN A.LIBELLE = IN_ALLOTMENT THEN 1 	
    ELSE 0
  END = 1
  ) INSTRUMENTS      

LEFT JOIN HISTOMVTS H ON H.SICOVAM = INSTRUMENTS.SICOVAM
	AND H.REFCON IN (
		SELECT MAX(H2.REFCON)
		FROM HISTOMVTS H2
		LEFT JOIN BUSINESS_EVENTS BE ON BE.ID = H2.TYPE
			AND BE.COMPTA = 1 -- ONLY TRADES THAT AFFECT POSITION
		WHERE H2.BACKOFFICE NOT IN ( SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415 ) -- EXCLUDE CANCELLED TRADES  
			AND H2.SICOVAM = INSTRUMENTS.SICOVAM
		)
LEFT JOIN TIERS T3 ON T3.IDENT = H.DEPOSITAIRE
LEFT JOIN RISKUSERS R ON R.IDENT = H.OPERATEUR
ORDER BY ALLOTMENT, CCY, REFERENCE,INSTR_LAST_AMENDED_BY;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

-- *****************************************************************
-- END OF: PRETC_CHECK_UCITS_ELIGIBLE
-- *****************************************************************
   END PRETC_CHECK_UCITS_ELIGIBLE; 