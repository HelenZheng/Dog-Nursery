--------------------------------------------------------------------SPEC--------------------------------------------------------------------------  
-- *****************************************************************
-- Description:    PRETC_INST_MISS_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 30 MAY 2018     Andre Bresslau     Created (COM-318)
-- *****************************************************************  

  PROCEDURE PRETC_INST_MISS_UCITS_ELIGIBLE 
	(
		p_CURSOR OUT T_CURSOR
	);
  
--------------------------------------------------------------------BODY--------------------------------------------------------------------------  

-- *****************************************************************
-- Description:    PRETC_INST_MISS_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 30 MAY 2018     Andre Bresslau     Created (COM-318)
-- *****************************************************************  
PROCEDURE PRETC_INST_MISS_UCITS_ELIGIBLE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PRETC_INST_MISS_UCITS_ELIGIBLE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT 
   INSTRUMENTS.SICOVAM
	,INSTRUMENTS.REFERENCE
	,INSTRUMENTS.NAME
  ,INSTRUMENTS.ALLOTMENT
	,INSTRUMENTS.CCY
  ,BTG_FN_AUDIT_INST_USER(INSTRUMENTS.SICOVAM) INSTR_LAST_AMENDED_BY
	,H.REFCON LATEST_TRADE_ID
	,T3.NAME DEPOSITARY
	,R.NAME TRADER	

FROM (
	SELECT 
     T.SICOVAM
		,T.REFERENCE
		,T.LIBELLE NAME
    ,A.LIBELLE ALLOTMENT
    ,DEVISE_TO_STR(T.DEVISECTT) CCY
  FROM TITRES T
	INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T.SICOVAM
		AND SIA.TYPE = 688149 --UCITS_ELIGIBLE
	WHERE SIA.SECTOR IS NULL
    AND T.TYPE NOT IN ('C','E','K','X','H','R') --Exclude Commission, FX, Issuers, Repos     
    AND (     
    A.LIBELLE IN (                                                                           
                    'Indexes',
                    'Internal Funds',                    
                    'Listed Warrants',
                    'Rights Issues',
                    'Shares',
                    'Shares - ADR and GDR',
                    'Shares - ETF',
                    'Shares - Delisted',
                    'Shares - Liquidated',
                    'Shares - MLP',
                    'Shares - Preferred',
                    'Shares - REIT',
                    'Shares - Suspended',
                    'Shares - Ticker Change',
                    'Shares - Unlisted'                                           
                      )        
    -- Exclude expired instruments
    OR (A.LIBELLE IN ('Dividend Future','Futures','Volatility Futures') AND T.ECHEANCE >= SYSDATE)    
    OR (A.LIBELLE = 'CDS' AND T.DATEFINAL >= SYSDATE)
    OR (A.LIBELLE = 'Gov Bonds' AND T.FINPER >= SYSDATE)
    OR (A.LIBELLE = 'Corp Bonds' AND T.FINPER >= SYSDATE)    
    )
  
  ) INSTRUMENTS

LEFT JOIN HISTOMVTS H ON H.SICOVAM = INSTRUMENTS.SICOVAM
	AND H.REFCON IN (
		SELECT MAX(H2.REFCON)
		FROM HISTOMVTS H2
		LEFT JOIN BUSINESS_EVENTS BE ON BE.ID = H2.TYPE
			AND BE.COMPTA = 1 -- ONLY TRADES THAT AFFECT POSITION
		WHERE H2.BACKOFFICE NOT IN ( SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415 ) -- EXCLUDE CANCELLED TRADES  
			AND H2.SICOVAM = INSTRUMENTS.SICOVAM
		)
LEFT JOIN TIERS T3 ON T3.IDENT = H.DEPOSITAIRE
LEFT JOIN RISKUSERS R ON R.IDENT = H.OPERATEUR
ORDER BY ALLOTMENT, CCY, REFERENCE,INSTR_LAST_AMENDED_BY;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

-- *****************************************************************
-- END OF: PRETC_INST_MISS_UCITS_ELIGIBLE
-- *****************************************************************
   END PRETC_INST_MISS_UCITS_ELIGIBLE; 
   
   
   

