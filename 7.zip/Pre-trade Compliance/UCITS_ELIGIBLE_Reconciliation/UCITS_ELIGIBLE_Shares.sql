select * from (
select 
  A2.LIBELLE ALLOTMENT
, DEVISE_TO_STR(T2.DEVISECTT) CCY
, T2.SICOVAM
, T2.REFERENCE
, T2.LIBELLE NAME
, CASE --688649=TRUE, 689149=FALSE
    WHEN SIA.SECTOR = 688649
      THEN 'TRUE'
    WHEN SIA.SECTOR = 689149
      THEN 'FALSE'
    ELSE ''
    END UCITS_ELIGIBLE

, CASE
    WHEN T2.TYPE = 'S'  -- S = Swap
			THEN TO_CHAR(T2.DATEFINAL, 'DD-MON-YYYY')
		WHEN T2.TYPE IN ('O', 'D', 'L') -- O = Bond, D = Derivative, L = Repo
			THEN TO_CHAR(T2.FINPER, 'DD-MON-YYYY')
		WHEN T2.TYPE IN ('M', 'F', 'N') -- M = Option on listed market, F = Future, N = Package
			THEN TO_CHAR(T2.ECHEANCE, 'DD-MON-YYYY')
		--WHEN T2.TYPE = 'K' -- K = Non Delivarable Forward Forex
			--THEN TO_CHAR(H2.dateval, 'YYYY-MM-DD')
		ELSE ''
		END EXPIRE_DATE   
, INSTRUMENTS.LATEST_TRADEID 
, R.NAME TRADER
, TO_CHAR(H3.DATENEG, 'DD-MON-YYYY') TRADE_DATE 
, UND1.REFERENCE UND1_REFERENCE
, UND1.LIBELLE UND1_NAME
, UND2.REFERENCE UND2_REFERENCE
, UND2.LIBELLE UND2_NAME
, INSTRUMENTS.DEPOSITARY_LATEST_TRADE_ID


from (
select
 T.SICOVAM 
,H.REFCON LATEST_TRADEID
,TIERS.NAME DEPOSITARY_LATEST_TRADE_ID
from TITRES T

inner join AFFECTATION A on A.IDENT = T.AFFECTATION and A.LIBELLE in (--- FILTER HERE BY ALLOTMENT
'Shares',
'Shares - ADR and GDR',
'Shares - ETF',
'Shares - Delisted',
'Shares - Liquidated',
'Shares - MLP',
'Shares - Preferred',
'Shares - REIT',
'Shares - Suspended',
'Shares - Ticker Change',
'Shares - Unlisted'
)
left join HISTOMVTS H on H.SICOVAM = T.SICOVAM and H.REFCON in (
select max(H2.REFCON) from HISTOMVTS H2 
left join BUSINESS_EVENTS BE ON BE.ID = H2.TYPE AND BE.COMPTA = 1 -- Only trades that affect position
where H2.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID	FROM BO_KERNEL_STATUS_COMPONENT	WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
and H2.SICOVAM = T.SICOVAM
) 
left join TIERS on TIERS.IDENT = H.DEPOSITAIRE
--where DEVISE_TO_STR(T.DEVISECTT) in ('USD','GBP','EUR','BRL') --- FILTER HERE BY CCY

) INSTRUMENTS

left join HISTOMVTS H3 on H3.REFCON = INSTRUMENTS.LATEST_TRADEID
left join RISKUSERS R ON R.IDENT = H3.OPERATEUR
left join TITRES T2 on T2.SICOVAM = INSTRUMENTS.SICOVAM
left join AFFECTATION A2 on A2.IDENT = T2.AFFECTATION
left join SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T2.SICOVAM
	AND SIA.TYPE = 688149 --UCITS_ELIGIBLE --688649=TRUE, 689149=FALSE


------1ST UNDERLYING INSTRUMENT
LEFT JOIN TITRES UND1
	ON UND1.sicovam = CASE 
			WHEN T2.type = 'A'
				THEN T2.base1
			WHEN T2.type = 'D'
				THEN T2.codesj
			WHEN T2.type = 'B'
				THEN T2.taux_var
			WHEN T2.type = 'S'
				THEN DECODE(T2.jambe1, 1, T2.j2refcon2, DECODE(T2.j1refcon2, 0, T2.j2refcon2, T2.j1refcon2))
			ELSE DECODE(T2.code_emet, 0, DECODE(T2.codesj, 0, T2.codesj2, T2.codesj), T2.code_emet)
			END
------

------2ND UNDERLYING T2RUMENT
LEFT JOIN TITRES UND2
	ON UND2.sicovam = CASE 
			WHEN UND1.type = 'A'
				THEN UND1.base1
			WHEN UND1.type = 'D'
				THEN UND1.codesj
			WHEN UND1.type = 'B'
				THEN UND1.taux_var
			WHEN UND1.type = 'S'
				THEN DECODE(UND1.jambe1, 1, UND1.j2refcon2, DECODE(UND1.j1refcon2, 0, UND1.j2refcon2, UND1.j1refcon2))
			ELSE DECODE(UND1.code_emet, 0, DECODE(UND1.codesj, 0, UND1.codesj2, UND1.codesj), UND1.code_emet)
			END
------

order by ALLOTMENT, CCY, REFERENCE 
)

--WHERE EXPIRE_DATE > SYSDATE