
select 
  TYPE
, SICOVAM
, REFERENCE
, LIBELLE NAME 
from TITRES 
where AFFECTATION is null
and TYPE not in ('C','E','F','K','H','I','R','X','Z')
order by 1,3

;

select affectation from titres where sicovam = 70258938;