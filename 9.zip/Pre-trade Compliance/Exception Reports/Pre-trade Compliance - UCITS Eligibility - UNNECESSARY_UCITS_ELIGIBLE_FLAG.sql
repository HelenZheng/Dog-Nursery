
-----------------------------------------UNNECESSARY_UCITS_ELIGIBLE_FLAG
SELECT T.SICOVAM
	,T.REFERENCE
	,A.LIBELLE ALLOTMENT
	,BTG_FN_AUDIT_INST_USER(T.SICOVAM) INSTR_LAST_AMENDED_BY
	,'Unnecessary UCITS_ELIGIBLE flag. Please remove the value assigned into Market Data>Sectors>UCITS_ELIGIBLE' Comments
FROM TITRES T
INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T.SICOVAM
	AND SIA.TYPE = 688149 --UCITS_ELIGIBLE
WHERE A.LIBELLE NOT IN ( --If Allotment in this list it means the flag is necessary
  'ABS',
  'Agency Bond',
  'Barrier Options',
  'CDS',  
  'CMBS',
  'Corp Bonds',
  'Dividend Future',  
  'Futures',
  'Gov Bonds',
  'FRA',
  'Indexes',
  'Inflation Swaps',
  'Internal Funds',
  'Listed Warrants',
  'MBS - Agency',
  'MBS - Non Agency',
  'Rights Issues',
  'Shares',
  'Shares - ADR and GDR',
  'Shares - Delisted',
  'Shares - ETF',
  'Shares - Liquidated',
  'Shares - MLP',
  'Shares - Preferred',
  'Shares - REIT',
  'Shares - Suspended',
  'Shares - Ticker Change',
  'Shares - Unlisted',
  'Volatility Futures' 
  )
	AND SIA.SECTOR IS NOT NULL
ORDER BY ALLOTMENT
	,REFERENCE;