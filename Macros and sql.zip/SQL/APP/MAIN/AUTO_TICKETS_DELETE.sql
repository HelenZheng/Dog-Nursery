begin 
delete  from mvt_auto 
where 
((dateval is null and trunc(dateneg) < trunc(sysdate-7)) 
or (trunc(dateval) < trunc(sysdate -7))
or (sicovam in (select sicovam from titres where type = 'L') and ajustement > 0))
and (sicovam not in (select sicovam from titres where affectation in(35,38,1252,1253,1450)));
commit; 
end;
/

exit