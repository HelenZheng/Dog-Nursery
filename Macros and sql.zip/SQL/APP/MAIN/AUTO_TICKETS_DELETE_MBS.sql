begin 
delete from mvt_auto 
where 
((dateval is null and trunc(dateneg) <= trunc(sysdate)) 
or (trunc(dateval) <= trunc(sysdate)))
and (sicovam in (select sicovam from titres where affectation in(35,38,1252,1253,1450)));
commit; 
end;
/

exit