begin
/*Update swap tickets*/
UPDATE  MVT_AUTO
SET     MVT_AUTO.COURTIER = MVT_AUTO.CONTREPARTIE --sets broker and counterparty to be the same for all CDS/IRS automatic tickets
WHERE 
SICOVAM IN (   /* IRS*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =24
                UNION 
                 /* CDS*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =22
                UNION 
                /* xccy swap (no USD)*/  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =1000
               UNION 
                /* Swaps */  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =3
                UNION 
                /* Inflation Swaps */  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 50      
                UNION 
                /* FX Options */  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 23
				UNION
                /*Correlation Swaps*/
                 SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 1101
                UNION
                /*Swaptions*/
                SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 031
                UNION
                /*Variance Swaps*/
                SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 016
				UNION
				 /*Equity Swaps*/
                SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 027
				UNION
				 /*CDS Options*/
                SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION = 1250				
              )

;
COMMIT
;
/*Update NDF expiry tickets*/
UPDATE  MVT_AUTO
SET     MVT_AUTO.COURTIER = '10007902', MVT_AUTO.CONTREPARTIE = '10007902' --NDF Broker
WHERE   BTG_GET_INSTRUMENT_TYPE(sicovam) = 'Non Deliverable Forward Forex'
AND     MVT_AUTO.TYPE in (1, 9) --Closeout trades
;
COMMIT
;
/*Update ETD and FRA tickets tickets*/
UPDATE  MVT_AUTO
SET     MVT_AUTO.COURTIER =
(
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                ) 
,               MVT_AUTO.CONTREPARTIE = (
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                )
WHERE 
SICOVAM IN (   /* LISTED OPTIONS*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =10
                UNION 
                 /* FUTURES*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =5
                UNION 
                /* FRA - SWAPS AND FUTURES*/  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =33
                
              )

;
COMMIT
;

/*Update CFD tickets tickets to have CFD-COUNTERPARTY as counterparty and the value from AUTO_TKT_CP via depositary for broker*/
UPDATE MVT_AUTO
  SET MVT_AUTO.CONTREPARTIE = '10011565' --CFD-COUNTERPARTY
  ,   MVT_AUTO.COURTIER = (
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                )
  WHERE 
SICOVAM IN ( /* CFD*/ 
               SELECT T.SICOVAM FROM TITRES T
                 WHERE T.TYPE = 'G'
              )
  ;
  COMMIT
  ; 
  
/*Update cash equity tickets tickets to have the value from AUTO_TKT_CP via depositary for broker and counterparty*/
UPDATE MVT_AUTO
SET     MVT_AUTO.COURTIER =
(
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                ) 
,               MVT_AUTO.CONTREPARTIE = (
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                )
  WHERE 
SICOVAM IN ( /* Equity*/ 
               SELECT T.SICOVAM FROM TITRES T
                 WHERE T.TYPE = 'A'
              )
  ;
  COMMIT
  ;

/*Update MBS/ABS/CMBS tickets*/
UPDATE  MVT_AUTO
SET     MVT_AUTO.COURTIER =
(
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                ) 
,               MVT_AUTO.CONTREPARTIE = (
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                )
WHERE 
SICOVAM IN (   /* MBS - Agency*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =35
                UNION 
                 /* MBS - Non Agency*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =1252
                UNION 
                /* CMBS*/  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =1253
                UNION 
                /* ABS*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =38
                UNION 
                /* ABS - Student Loans*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =1450
				UNION
                /* MBS -European*/
				SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =1353
              )

;
COMMIT
; 
/*Update convertible/gov/corp bonds tickets*/
UPDATE  MVT_AUTO
SET     MVT_AUTO.COURTIER =
(
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                ) 
,               MVT_AUTO.CONTREPARTIE = (
                                                                SELECT TIERSPROPERTIES.VALUE 
                                                                FROM TIERSPROPERTIES 
                                                                WHERE TIERSPROPERTIES.CODE = MVT_AUTO.DEPOSITAIRE 
                                                                AND TIERSPROPERTIES.NAME = 'AUTO_TKT_CP'
                                                                )
WHERE 
SICOVAM IN (   /* Gov Bonds*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =25
                UNION 
                 /* Corp Bonds*/  
               SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =26
                UNION 
                /* convertibles*/  
                  SELECT T.SICOVAM FROM TITRES T
                WHERE AFFECTATION =9
              )

;
COMMIT
;   
end;
/
exit