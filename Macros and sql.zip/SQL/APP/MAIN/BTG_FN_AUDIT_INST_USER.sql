create or replace
FUNCTION "BTG_FN_AUDIT_INST_USER"(
                                   SicovamNumber NUMBER
                                )
    RETURN VARCHAR2
  IS
    v_name VARCHAR2(40);
    v_userid NUMBER;
    v_maxdate NUMBER;
    
  BEGIN
  
  v_name := '';
  v_userid := 0;
  v_maxdate := 0;
  
    SELECT  MAX(INFOS_HISTO.DATE_VALIDITE)
    INTO    v_maxdate
    FROM    INFOS_HISTO
    WHERE   INFOS_HISTO.sicovam =  SicovamNumber;
  
    SELECT  DISTINCT(INFOS_HISTO.USERIDENT)
    INTO    v_userid
    FROM    INFOS_HISTO
    WHERE   INFOS_HISTO.sicovam =  SicovamNumber
    AND     INFOS_HISTO.DATE_VALIDITE=v_maxdate;
    
    SELECT  RISKUSERS.NAME
    INTO    v_name
    FROM    RISKUSERS
    WHERE   RISKUSERS.IDENT = v_userid;
    

RETURN
    v_name;
    
END "BTG_FN_AUDIT_INST_USER";

    
