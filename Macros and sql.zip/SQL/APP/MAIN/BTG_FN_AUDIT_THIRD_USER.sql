create or replace
FUNCTION "BTG_FN_AUDIT_THIRD_USER"(
                                   TiersIdent NUMBER
                                )
    RETURN VARCHAR2
  IS
    v_name VARCHAR2(40);
    v_userid NUMBER;
    v_max NUMBER;
    
  BEGIN
  
  v_name := '';
  v_userid := 0;
  v_max := 0;
  
    SELECT  MAX(AUDIT_TIERS_COMPO.SEQUENCE)
    INTO    v_max
    FROM    AUDIT_TIERS_COMPO
    WHERE   AUDIT_TIERS_COMPO.code =  TiersIdent;
  
    SELECT  DISTINCT(AUDIT_TIERS_COMPO.ID)
    INTO    v_userid
    FROM    AUDIT_TIERS_COMPO
    WHERE   AUDIT_TIERS_COMPO.code =  TiersIdent
    AND     AUDIT_TIERS_COMPO.SEQUENCE=v_max;
    
    SELECT  RISKUSERS.NAME
    INTO    v_name
    FROM    RISKUSERS
    WHERE   RISKUSERS.IDENT = v_userid;
    

RETURN
    v_name;
    
END "BTG_FN_AUDIT_THIRD_USER";

    

