create or replace PROCEDURE BTG_RATES_PopulateFutures
AS
BEGIN


delete from BTG_RIC_RATES;

commit;

insert into btg_ric_rates select t.sicovam, 26, 'r', r.servisen,null,null,null,null,null from titres t join ric r on r.sicovam=t.sicovam where t.AFFECTATION =5 and t.libelle not like '%OIS%' and t.reference like '%Comdty%' and t.sicovam in (select sicovam from JOIN_POSITION_HISTOMVTS where opcvm in (select ident from folio start with ident in (126391) connect by mgr=prior ident)) 
and t.sicovam not in
					(70466094,70465781,70635089,70706792,70723894,70706799, 70754076,68330046,
					 68332878,68332882,68332883,68332884,68332886,68332887,69171300,69735870,70528831);

commit;

end;