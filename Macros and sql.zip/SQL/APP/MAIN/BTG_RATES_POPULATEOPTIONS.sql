create or replace PROCEDURE BTG_RATES_PopulateOptions
AS
BEGIN


delete from BTG_RIC_RATES;

commit;

insert into btg_ric_rates select t.sicovam, r.fid, 'r', r.servisen,null,null,null,null,null 
from titres t 
  join ric r 
  on r.sicovam=t.sicovam 
  where t.type in ('D') 
  and t.libelle not like '%OIS%' 
  and (UPPER(t.reference) like '%CURNCY%' 
    or UPPER(t.reference) like '%INDEX%' 
    or UPPER(t.reference) like '%COMDTY%') 
    and t.sicovam not in 
      (68981466,69907403,69907405,69911248,69911249) 
    and t.sicovam in 
      (select sicovam 
        from JOIN_POSITION_HISTOMVTS 
        where opcvm in 
          (select ident 
            from folio 
            start with ident in (126391,126134) 
            connect by mgr=prior ident)) 
    and not exists 
      (select * from btg_daily_audit_historique bdah 
      where r.sicovam = bdah.sicovam 
      and TRUNC(bdah.MODIFIED_JOUR) = TO_CHAR (SYSDATE, 'DD-MON-YY') and 
      bdah.username not in ('svc_sophis','SYSTEM'));

commit;

end;