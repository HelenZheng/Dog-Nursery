create or replace PROCEDURE BTG_RATES_PopulateSwaps
AS
BEGIN


delete from BTG_RIC_RATES;

commit;

insert into btg_ric_rates 
select t.sicovam, r.fid, 'r', r.servisen,null,null,null,null,null
from titres t INNER join 
    (
    select distinct sicovam from JOIN_POSITION_HISTOMVTS where opcvm in 
        (select ident from folio start with ident in (126391,14114,62956,129603,128644) connect by prior ident=mgr)--US Rates (ARF, GEMM, Rates) + Global Rates-Trading-John Lee (ARF, GEMM)
    minus
    select distinct sicovam from JOIN_POSITION_HISTOMVTS where opcvm in 
            (select ident from folio start with ident in (126490,126439,128663,128655,130452) connect by prior ident=mgr) -- Global Rates-Trading-John Lee-Basis (xccy) + Global Rates-Trading-John Lee-EOD - Singapore (ARF, GEMM) + USRates\SIGB ASW (GEMM)
    ) usrates 
on t.sicovam=usrates.sicovam and t.type='S' and t.libelle not like '%OIS%' 
join ric r 
on r.sicovam=t.sicovam 
where t.reference not like '%Index%' 
and (t.reference like 'SL%corp%' or t.reference like 'SL%Corp%') 
and BTG_INSTRALLOTMENT(t.sicovam) <> 'Swaptions';

commit;

end;