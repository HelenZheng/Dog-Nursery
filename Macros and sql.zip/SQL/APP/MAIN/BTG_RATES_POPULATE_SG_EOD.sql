create or replace PROCEDURE BTG_RATES_Populate_SG_EOD
AS
BEGIN

delete from BTG_RIC_RATES;

commit;

insert into btg_ric_rates 
select t.sicovam, r.fid, 'r', r.servisen,null,null,null,null,null
from titres t 
inner join (select distinct sicovam 
      from JOIN_POSITION_HISTOMVTS 
      where opcvm in (select ident from folio start with ident in (126490,126439,130452) connect by mgr=prior ident)
      ) usrates 
on t.sicovam=usrates.sicovam  
inner join ric r 
on r.sicovam=t.sicovam left outer join
(select distinct t1.sicovam from titres t1
inner join SECTOR_INSTRUMENT_ASSOCIATION
ON          SECTOR_INSTRUMENT_ASSOCIATION.sicovam     = t1.sicovam 
AND         SECTOR_INSTRUMENT_ASSOCIATION.sector      = 6290   --CNTRY_OF_DOMICILE = US
WHERE       t1.affectation                      IN ('25','1251') --Gov Bonds and Agency Bonds
AND         t1.type =  'O')ust on
ust.sicovam=t.sicovam
where ust.sicovam is null
;

commit;

end;