CREATE OR REPLACE VIEW BTG_RESTRICTED_LIST_QSF AS
SELECT * 
FROM BTG_RESTRICTED_LIST_VALUES 
WHERE LIST_ID = 0
;
/* View to show the issuers in the Queen Street Fund restricted list*/