create or replace FUNCTION BTG_GET_INSTRUMENT_TYPE
(
  p_sicovam TITRES.sicovam%TYPE
)
RETURN VARCHAR2
IS      
BEGIN

  RETURN CASE COALESCE(BTG_GET_INSTRUMENT_TYPE_CODE(p_sicovam), -2)
    WHEN -2 THEN 'Not Found'
    WHEN -1 THEN 'Unknown'
    WHEN  0 THEN 'Shares'
    WHEN  1 THEN 'Caps and Floors'
    WHEN  2 THEN 'Commissions'
    WHEN  3 THEN 'Forex'
    WHEN  4 THEN 'Contracts For Difference'
    WHEN  5 THEN 'Issuers'
    WHEN  6 THEN 'Indexes and Baskets'
    WHEN  7 THEN 'Non Deliverable Forward Forex'
    WHEN  8 THEN 'Repos'
    WHEN  9 THEN 'Listed Options'
    WHEN 10 THEN 'Packages'
    WHEN 11 THEN 'Loans on Stock'
    WHEN 12 THEN 'Commodities'
    WHEN 13 THEN 'Interest Rates'
    WHEN 14 THEN 'Debt Instruments'
    WHEN 15 THEN 'Commodity Index'
    WHEN 16 THEN 'Forward Forex'
    WHEN 17 THEN 'Not Found Fund Type'
    WHEN 18 THEN 'Internal Funds'
    WHEN 19 THEN 'External Funds' 
    WHEN 20 THEN 'Inflation Bonds'
    WHEN 21 THEN 'ABS Bond'
    WHEN 22 THEN 'Bonds'
    WHEN 23 THEN 'Index Futures'
    WHEN 24 THEN 'Exchange Rate Futures'
    WHEN 25 THEN 'Interest Rate Futures'
    WHEN 26 THEN 'Commodity Futures'
    WHEN 27 THEN 'Futures'
    WHEN 28 THEN 'Interest Rate Swaps'
    WHEN 29 THEN 'Credit Default Swaps'
    WHEN 30 THEN 'Cross Currencies Swaps'
    WHEN 31 THEN 'Single legged Swaps'
    WHEN 32 THEN 'Total Return Swaps'
    WHEN 33 THEN 'Inflation Swaps'
    WHEN 34 THEN '-1'
    WHEN 35 THEN 'Credit Derivatives'
    WHEN 36 THEN NULL
    WHEN 37 THEN 'Stock Derivatives'    
    WHEN 38 THEN 'Interest Rate Derivatives'
    WHEN 39 THEN 'Commodity Derivatives'
    WHEN 40 THEN 'Exchange Rate Options'
    WHEN 41 THEN 'Convertibles and Indexed'    
    WHEN 42 THEN 'Interest Rate Futures'
    WHEN 43 THEN 'Interest Rate Derivatives'   
    WHEN 44 THEN 'Index Futures'
    ELSE NULL
  END;
  
END;