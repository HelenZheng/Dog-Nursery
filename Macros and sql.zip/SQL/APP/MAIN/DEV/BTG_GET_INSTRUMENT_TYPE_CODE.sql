create or replace FUNCTION BTG_GET_INSTRUMENT_TYPE_CODE
(
  p_sicovam TITRES.sicovam%TYPE
)
RETURN NUMBER

  /*
  -1 : Unknown
   0 : Shares
   1 : Caps and Floors
   2 : Commissions
   3 : Forex   
   4 : Contract for Difference
   5 : Issuers
   6 : Index and Baskets
   7 : Non Deliverable Forward Forex
   8 : Repos
   9 : Listed Options
  10 : Packages 
  11 : Loans on Stock
  12 : Commodities
  13 : Interest Rates  
  14 : Debt Instruments
  15 : Commodity Index
  16 : Forward Forex  
  17 : Not Found Fund Type
  18 : Internal Fund
  19 : External Fund  
  20 : Inflation Bonds
  21 : ABS Bond
  22 : Bonds  
  23 : Index Futures
  24 : Exchange Rate Futures
  25 : Interest Rate Futures
  26 : Commodity Futures
  27 : Futures
  28 : Interest Rate Swaps
  29 : Credit Default Swaps
  30 : Cross Currencies Swaps
  31 : Single legged Swaps
  32 : Total Return Swaps
  33 : Inflation Swaps
  34 : Swaps
  35 : Credit Derivatives
  36 : Derivatives
  37 : Stock Derivatives
  38 : Interest Rate Derivatives
  39 : Commodity Derivatives
  40 : Exchange Rate Options
  41 : Convertibles and Indexed
  42 : Bond Futures
  43 : Bond Derivatives
  44 : Volatility Index Futures
  */

IS
  
  l_instrument titres%ROWTYPE;
  l_underlying titres%ROWTYPE;
    
BEGIN 

  BEGIN
    SELECT TITRES.*
    INTO l_instrument
    FROM TITRES 
    WHERE TITRES.sicovam = p_sicovam;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_instrument := NULL;
  END;
    
  IF l_instrument.TYPE IS NULL THEN
    RETURN NULL;
  ELSIF l_instrument.TYPE = 'A' THEN 
    RETURN 0;
  ELSIF l_instrument.TYPE = 'B' THEN 
    RETURN 1;  
  ELSIF l_instrument.TYPE = 'C' THEN 
    RETURN 2;  
  ELSIF l_instrument.TYPE = 'D' THEN
    
    BEGIN
      SELECT TITRES.*
      INTO l_underlying
      FROM TITRES
      WHERE TITRES.sicovam = l_instrument.CODESJ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END;
    
    IF (l_instrument.TYPESJ <> 5 AND MOD(l_instrument.TYPEPRO, 256) <= 2 AND l_underlying.TYPE = 'S' AND ((l_underlying.JAMBE1 = 1 AND l_underlying.JAMBE2 = 8) OR (l_underlying.JAMBE1 = 8 AND l_underlying.JAMBE2 = 1))) THEN
      RETURN 35;
    ELSIF (l_instrument.TYPESJ <> 5 AND (MOD(l_instrument.TYPEPRO, 256) >= 3 AND l_instrument.CODESJ2 IS NOT NULL AND l_instrument.CODESJ2 <> 0 AND (l_underlying.SICOVAM IS NULL OR NOT ((l_underlying.TYPE = 'E') OR (l_underlying.TYPE = 'F' AND l_underlying.J1REFCON1 = 4))) OR MOD(l_instrument.TYPEPRO, 256) <= 2 AND (l_instrument.CODESJ = 0 OR (l_underlying.TYPE = 'A' OR l_underlying.TYPE = 'I' OR l_underlying.TYPE = 'F' AND l_underlying.J1REFCON1 = 1))) AND (l_underlying.SICOVAM IS NULL OR NOT (l_underlying.TYPE = 'S' AND ((l_underlying.JAMBE1 = 1 AND l_underlying.JAMBE2 = 8) OR (l_underlying.JAMBE1 = 8 AND l_underlying.JAMBE2 = 1))))) THEN
      RETURN 37;
    ELSIF (l_instrument.TYPESJ <> 5 AND MOD(l_instrument.TYPEPRO, 256) <= 2 AND (l_underlying.TYPE NOT IN ('A', 'I', 'E', 'F', 'Q', 'U', 'S') OR (l_underlying.TYPE = 'F' AND l_underlying.J1REFCON1 = 3) OR (l_underlying.TYPE = 'S' AND l_underlying.TYPEDERIVE NOT IN(1,2)))) THEN
      
      IF (l_underlying.MODELE IN ('BTG Notional', 'Notionnel', 'SFE 10 Year Bond Future', 'SFE 3 Year Bond Future')) THEN
        RETURN 43;    
      ELSE 
        RETURN 38;
      END IF;     
      
    ELSIF (l_instrument.TYPESJ <> 5 AND (MOD(l_instrument.TYPEPRO, 256) <= 2 AND (l_underlying.TYPE = 'Q' OR l_underlying.TYPE = 'F' AND l_underlying.J1REFCON1 = 4 OR l_underlying.TYPE = 'U' OR l_underlying.TYPE = 'S' AND l_underlying.TYPEDERIVE IN (1, 2)) OR (mod(l_instrument.TYPEPRO, 256) = 5 AND l_underlying.TYPE = 'F' AND l_underlying.J1REFCON1 = 4))) THEN
      RETURN 39;        
    ELSIF (l_instrument.TYPESJ = 5 OR l_underlying.TYPE IN ('E', 'F')) THEN
      RETURN 40;        
    ELSIF ((MOD(l_instrument.TYPEPRO, 256) = 3 AND l_instrument.TYPEDERIVE = -1) OR (MOD(l_instrument.TYPEPRO, 256) = 11 AND l_instrument.TYPEDERIVE = 3) AND l_instrument.CODESJ2 = 0) THEN
      RETURN 41;
    ELSE        
      RETURN 36;
    END IF;

  ELSIF l_instrument.TYPE = 'E' THEN 
    RETURN 3;  
  ELSIF l_instrument.TYPE = 'F' THEN 
    
    IF l_instrument.J1REFCON1 = 1 THEN
      
      BEGIN
        SELECT TITRES.*
        INTO l_underlying
        FROM TITRES
        WHERE TITRES.sicovam = l_instrument.CODE_EMET;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          l_underlying := NULL;
      END;
      
      IF (l_underlying.MODELE IN ('Volatility Index')) THEN
        RETURN 44;
      ELSE
        RETURN 23;
      END IF;
      
    ELSIF l_instrument.J1REFCON1 = 2 THEN
      RETURN 24;
    ELSIF l_instrument.J1REFCON1 = 3 THEN
      
      IF (l_instrument.MODELE IN ('BTG Notional', 'Notionnel', 'SFE 10 Year Bond Future', 'SFE 3 Year Bond Future')) THEN
        RETURN 42;    
      ELSE 
        RETURN 25;
      END IF;
      
    ELSIF l_instrument.J1REFCON1 = 4 THEN
      RETURN 26;
    ELSE
      RETURN 27;
    END IF;
  
  ELSIF l_instrument.TYPE = 'G' THEN 
    RETURN 4;  
  ELSIF l_instrument.TYPE = 'H' THEN 
    RETURN 5;  
  ELSIF l_instrument.TYPE = 'I' THEN 
    RETURN 6;  
  ELSIF l_instrument.TYPE = 'K' THEN 
    RETURN 7;      
  ELSIF l_instrument.TYPE = 'L' THEN 
    RETURN 8;  
  ELSIF l_instrument.TYPE = 'M' THEN 
    RETURN 9;  
  ELSIF l_instrument.TYPE = 'N' THEN 
    RETURN 10;  
  ELSIF l_instrument.TYPE = 'O' THEN 

    IF (l_instrument.TYPEAMORT = 3 AND l_instrument.JAMBE1 = 14) THEN
      RETURN 20;
    ELSIF l_instrument.MODELE IN ('ABS Tranche','ABS Tranche IO') THEN
      RETURN 21;
    ELSE
      RETURN 22;
    END IF;

  ELSIF l_instrument.TYPE = 'P' THEN 
    RETURN 11;
  ELSIF l_instrument.TYPE = 'Q' THEN 
    RETURN 12;
  ELSIF l_instrument.TYPE = 'R' THEN 
    RETURN 13;
  ELSIF l_instrument.TYPE = 'S' THEN 

    IF (l_instrument.DEVISEEXER = l_instrument.DEVISEAC AND l_instrument.DEVISECTT = l_instrument.DEVISEAC AND l_instrument.jambe1 <= 2 AND l_instrument.jambe2 <= 2) THEN
      RETURN 28;    
    ELSIF ((l_instrument.JAMBE1 = 1 AND l_instrument.JAMBE2 = 8) OR (l_instrument.JAMBE1 = 8 AND l_instrument.JAMBE2 = 1)) THEN
      RETURN 29;
    ELSIF ((l_instrument.DEVISEEXER <> l_instrument.DEVISEAC OR l_instrument.DEVISECTT <> l_instrument.DEVISEAC) AND l_instrument.jambe1 <= 2 AND l_instrument.jambe2 <= 2) THEN
      RETURN 30;
    ELSIF (l_instrument.jambe1 = 13 OR l_instrument.jambe2 = 13) THEN
      RETURN 31;
    ELSIF (l_instrument.jambe1 IN (3, 5) OR l_instrument.jambe2 IN (3, 5)) THEN
      RETURN 32;
    ELSIF (l_instrument.jambe1 IN (14, 15) OR l_instrument.jambe2 in (14, 15)) THEN
      RETURN 33;
    ELSE
      RETURN 34;
    END IF;
  
  ELSIF l_instrument.TYPE = 'T' THEN 
    RETURN 14;    
  ELSIF l_instrument.TYPE = 'U' THEN 
    RETURN 15;
  ELSIF l_instrument.TYPE = 'X' THEN 
    RETURN 16;
  ELSIF l_instrument.TYPE = 'Z' THEN

    IF l_instrument.TYPEPRO = 1 THEN
      RETURN 18; 
    ELSIF l_instrument.TYPEPRO = 2 THEN
      RETURN 19; 
    ELSE 
      RETURN 17;
    END IF;

  END IF;
      
  RETURN -1;

END;