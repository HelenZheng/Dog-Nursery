create or replace 
FUNCTION "BTG_BUSINESS_DATE_HOLIDAY_2CCY" 
(
    p_date          IN DATE
  , p_offset        IN NUMBER
  , p_currency1     IN NUMBER
  , p_currency2     IN NUMBER
  , p_increment     IN NUMBER := 1
)
RETURN DATE
IS
  return_date       DATE    := p_date;
  is_holiday        NUMBER  := 0;
  offset_increment  NUMBER  := p_increment;
  
  offset            NUMBER  := p_offset;
BEGIN
  IF p_date IS NULL 
  OR p_offset IS NULL 
  OR p_currency1 IS NULL
  OR p_currency2 IS NULL THEN
    RETURN NULL;
  END IF;

  IF p_offset < 0 THEN
    offset_increment := -1;
  END IF;
  
  LOOP
    IF offset <> 0 THEN
      return_date := return_date + offset_increment;
      offset := offset - offset_increment;
    END IF;
   
    SELECT COUNT(*) INTO is_holiday
    FROM FERIES 
    WHERE CODEDEV IN (p_currency1,p_currency2)
      AND (DATEFER = return_date OR ( (to_char(return_date, 'dd-mon') != '29-feb') AND DATEFER = to_date(to_char(return_date, 'dd-mon') || '-1905') )) 
    AND ROWNUM = 1;
    
    WHILE (is_holiday > 0  
      OR to_char(return_date, 'DY') = 'SAT' 
      OR to_char(return_date, 'DY') = 'SUN')
    LOOP
      return_date := return_date + offset_increment;

      SELECT COUNT(*) INTO is_holiday
      FROM FERIES 
      WHERE CODEDEV IN (p_currency1,p_currency2)
      AND (DATEFER = return_date OR ( (to_char(return_date, 'dd-mon') != '29-feb') AND DATEFER = to_date(to_char(return_date, 'dd-mon') || '-1905') )) 
      AND ROWNUM = 1;
    END LOOP;

    IF offset = 0 THEN
      RETURN return_date;
    END IF;
  END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(return_date);
END BTG_BUSINESS_DATE_HOLIDAY_2CCY;