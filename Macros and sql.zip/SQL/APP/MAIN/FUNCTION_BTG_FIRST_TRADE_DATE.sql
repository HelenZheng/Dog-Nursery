create or replace FUNCTION "BTG_FIRST_TRADE_DATE"(
                                 P_FOLIO FOLIO.IDENT%TYPE ,
                                 P_SICOVAM  HISTOMVTS.SICOVAM%TYPE
                            )
    RETURN  VARCHAR2
  IS
   --lv_str             NUMBER(10);
   -- P_INSTRUMENT_TYPE  VARCHAR2(50);
    P_DATETRADE VARCHAR2(50);
  BEGIN
  --SELECT BTG_FIRST_TRADE_DATE(12642,69082041)  FROM DUAL 
  /*
   old code from first_trade_date column
  sqlquerystring("select min(dateneg) from histomvts where sicovam = %1 
   and opcvm in (select ident from folio connect by mgr = prior ident 
             start with ident in (28285, 13269, 13264, 13266, 28286, 26166))", 
             [Instrument code])
  */
  
  IF (P_SICOVAM IS NULL) THEN  
    RETURN '' ;
  END IF;
  IF (P_FOLIO IS NULL) THEN  
    RETURN '' ;
  END IF;
  
   SELECT TO_CHAR(MIN(DATENEG),'DD-MON-YY') INTO P_DATETRADE
--SELECT DATENEG , refcon    
   FROM  DUAL
   LEFT JOIN JOIN_POSITION_HISTOMVTS
   ON 1=1
   AND  JOIN_POSITION_HISTOMVTS.BACKOFFICE  IN         
  (
  
    SELECT  BO_KERNEL_STATUS.ID  
      FROM     
      BO_KERNEL_STATUS_GROUP 
      INNER JOIN  BO_KERNEL_BLOTTERS      
      ON BO_KERNEL_BLOTTERS.STATUS_GROUP_ID =  BO_KERNEL_STATUS_GROUP.ID     
      INNER JOIN BO_KERNEL_STATUS_COMPONENT     
      ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID  =  BO_KERNEL_BLOTTERS.STATUS_GROUP_ID     
      INNER JOIN BO_KERNEL_STATUS     
      ON BO_KERNEL_STATUS.ID  =  BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID              
      WHERE     
    -- this filter gets only the group_workflow where the user belong to
    -- each group has a pair of de 
    BO_KERNEL_STATUS_GROUP.NAME = 'Pending FM'           
    AND BO_KERNEL_BLOTTERS.ID  = 280
   ) 

   INNER JOIN BUSINESS_EVENTS   
   ON (    BUSINESS_EVENTS.ID = JOIN_POSITION_HISTOMVTS.TYPE 
      AND  BUSINESS_EVENTS.COMPTA  = 1  ) 
   
   WHERE JOIN_POSITION_HISTOMVTS.SICOVAM = p_SICOVAM -- 69082041 
   AND JOIN_POSITION_HISTOMVTS.OPCVM IN (SELECT IDENT FROM FOLIO 
                 CONNECT BY MGR = PRIOR IDENT 
                 START WITH IDENT IN (P_FOLIO)
              )  ;
              

    RETURN P_DATETRADE;

END BTG_FIRST_TRADE_DATE;
--SELECT BTG_FIRST_TRADE_DATE(12642,69082041)  FROM DUAL