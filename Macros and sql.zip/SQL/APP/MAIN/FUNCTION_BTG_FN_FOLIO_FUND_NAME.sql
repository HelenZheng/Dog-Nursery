create or replace
FUNCTION         "BTG_FN_FOLIO_FUND_NAME" 
(
  in_folio_id IN NUMBER
)
RETURN VARCHAR2
IS
  
  out_folio_name   VARCHAR2 (4000) := 'UNKNOWN';
  
BEGIN

  BEGIN
  
    SELECT      name
    INTO        out_folio_name
    FROM        folio where ident in (BTG_FN_FOLIO_FUND(in_folio_id));
                
  EXCEPTION
  
    WHEN OTHERS THEN
    
      out_folio_name := 'UNKNOWN';
      
  END;

  RETURN out_folio_name;
  
END BTG_FN_FOLIO_FUND_NAME;