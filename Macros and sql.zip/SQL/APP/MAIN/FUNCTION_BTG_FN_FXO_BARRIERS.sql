--------------------------------------------------------
--  File created - Thursday-February-21-2013   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function BTG_FN_FXO_BARRIERS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BTG_FN_FXO_BARRIERS" (
                                            SicovamNumber Number)
return varchar is
	vl01 number;
  n01 number;
  vl02 number;
  n02 number;
  
begin
    
    vl01:=null;
    vl02:=null;
    
	SELECT count(valeur) into vl01
    FROM clause
    where clause.type = 27 and
    sicovam=SicovamNumber;
    
    if(vl01=1) then
    	SELECT valeur into n01
      FROM clause
      where clause.type = 27 and
      sicovam=SicovamNumber;
    end if;
    
	SELECT count(valeur) into vl02
    FROM clause
    where clause.type = 29 and
    sicovam=SicovamNumber;
    
    if(vl02=1) then
    	SELECT valeur into n02
      FROM clause
      where clause.type = 29 and
      sicovam=SicovamNumber;
    end if;
    
    if (vl01=1) and (vl02=1)  then
          	return round(BTG_FN_FXO_STRIKE_BARRIER(SicovamNumber,n02), 4) || ' - ' || round(BTG_FN_FXO_STRIKE_BARRIER(SicovamNumber,n01), 4);
    ELSIF (vl01=1) then
          	return round(BTG_FN_FXO_STRIKE_BARRIER(SicovamNumber,n01), 4);
    ELSIF (vl02=1) then
            return round(BTG_FN_FXO_STRIKE_BARRIER(SicovamNumber,n02), 4);
    ELSE 
            return null;
    end if;

end BTG_FN_FXO_BARRIERS;

/
