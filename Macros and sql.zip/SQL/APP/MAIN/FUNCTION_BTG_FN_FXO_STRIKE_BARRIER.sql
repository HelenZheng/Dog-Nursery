--------------------------------------------------------
--  File created - Thursday-February-21-2013   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function BTG_FN_FXO_STRIKE_BARRIER
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BTG_FN_FXO_STRIKE_BARRIER" (	SicovamNumber 		Number,
						FXOValue 	Number)
return number is
	rn number;
  aux number;
begin

  aux:=0;
  rn:=0;
	SELECT instrument2.quotation_type into aux
    FROM titres instrument1
    INNER JOIN titres instrument2 ON instrument1.codesj = instrument2.sicovam
    where INSTRUMENT1.SICOVAM = SicovamNumber;
    
    if (aux=1) then
          	rn:= FXOValue;
      end if;
    if (aux=-1) then
          	rn:= 1/FXOValue;
      end if;
      return rn;
end BTG_FN_FXO_STRIKE_BARRIER;

/
