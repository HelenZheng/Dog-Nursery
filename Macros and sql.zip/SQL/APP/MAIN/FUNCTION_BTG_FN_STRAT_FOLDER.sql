create or replace
FUNCTION         "BTG_FN_STRAT_FOLDER" 
(
  in_folio_id IN NUMBER
)
RETURN NUMBER
IS
  
  out_folio_id  NUMBER := in_folio_id;
  
BEGIN

  BEGIN
  
    SELECT      parent_ident
    INTO        out_folio_id
    FROM        (
                  SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS parent_ident

  FROM FOLIO
  WHERE LEVEL >= 4
  and      FOLIO.ident  = in_folio_id
  START WITH FOLIO.ident IN (14414)--Primary funds
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                 
                ) DataSet;
                
  EXCEPTION
  
    WHEN OTHERS THEN
    
      out_folio_id := in_folio_id;
      
  END;

  RETURN out_folio_id;
  
END BTG_FN_STRAT_FOLDER;