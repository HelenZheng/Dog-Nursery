create or replace FUNCTION BTG_GET_CFI_CODE
(
  p_sicovam TITRES.sicovam%TYPE
)
RETURN VARCHAR2
IS
  
  l_instrument titres%ROWTYPE;
  l_underlying titres%ROWTYPE;
  l_underlying2 titres%ROWTYPE;
  l_clause clause%ROWTYPE;
  aux_number number;

  cficode_1 char(1);
  cficode_2 char(1);
  cficode_3 char(1);
  cficode_4 char(1);
  cficode_5 char(1);
  cficode_6 char(1);
  cficode varchar(6);

BEGIN 

  BEGIN
    SELECT TITRES.*
    INTO l_instrument
    FROM TITRES 
    WHERE TITRES.sicovam = p_sicovam;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_instrument := NULL;
  END;          


 -- for IRS and xccy swap (no USD) sections     S-R- (AHCG) -C-(CS)-C      row 41 and row  101   







IF l_instrument.AFFECTATION = 24 OR l_instrument.AFFECTATION = 1000  THEN -- IRS OR xccy swap (no USD)

    cficode_1 := 'S';
    cficode_2 := 'R';

    IF  (l_instrument.jambe1 = 1 AND l_instrument.jambe2 = 0) OR (l_instrument.jambe1 = 0 AND l_instrument.jambe2 = 1) THEN    

			IF (l_instrument.jambe1 = 0) THEN

				SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (SELECT BASE1 FROM TITRES WHERE SICOVAM = p_sicovam);

				IF( EXTRACT(year FROM l_underlying.ECHEANCE)=2083 AND (EXTRACT(DAY FROM l_underlying.ECHEANCE) - 6) = 1 ) 
THEN
				 cficode_3 := 'H';    
				ELSE
				 cficode_3 := 'C';    
				END IF;                  

			ELSIF (l_instrument.jambe2 = 0) THEN

				SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (SELECT BASE2 FROM TITRES WHERE SICOVAM = p_sicovam);

				IF( EXTRACT(year FROM l_underlying.ECHEANCE)=2083 AND (EXTRACT(DAY FROM l_underlying.ECHEANCE) - 6) = 1 ) 
THEN
				 cficode_3 := 'H';    
				ELSE
				cficode_3 := 'C';    
				END IF;

			END IF;

    ELSIF  (l_instrument.jambe1 = 0 AND l_instrument.jambe2 = 0) THEN     --Both legs are floating
			cficode_3 := 'A';    
    ELSIF  (l_instrument.jambe1 = 14 or l_instrument.jambe2 = 14) THEN     --one leg is Inflation-Linked
			cficode_3 := 'G';         
    END IF;

    cficode_4 := 'C';

    IF (l_instrument.DEVISEEXER = l_instrument.DEVISEAC AND l_instrument.DEVISECTT = l_instrument.DEVISEAC) THEN
			cficode_5 := 'S';  -- SINGLE CCY
    ELSE
			cficode_5 := 'C'; -- MULTI CCY
    END IF;

    cficode_6 := 'C';

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;



--Swaps    S-R- (AHCGSBI) - C- (CS) - C      row 60 





ELSIF l_instrument.AFFECTATION = 3 THEN-- swaps

    cficode_1 := 'S';


    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (decode(l_instrument.jambe1,1,l_instrument.j2refcon2,decode
(l_instrument.j1refcon2,0,l_instrument.j2refcon2,l_instrument.j1refcon2)));   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    IF  (l_instrument.jambe1 = 1 AND l_instrument.jambe2 = 0) OR (l_instrument.jambe1 = 0 AND l_instrument.jambe2 = 1) THEN


			IF (l_instrument.jambe1 = 0) THEN

				SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (SELECT BASE1 FROM TITRES WHERE SICOVAM = p_sicovam);

				IF( EXTRACT(year FROM l_underlying.ECHEANCE)=2083 AND (EXTRACT(DAY FROM l_underlying.ECHEANCE) - 6) = 1 ) 
THEN
				 cficode_2 := 'R';
				 cficode_3 := 'H';    
				ELSE
				 cficode_2 := 'R';
				 cficode_3 := 'C';    
				END IF;                  

			ELSIF (l_instrument.jambe2 = 0) THEN

				SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (SELECT BASE2 FROM TITRES WHERE SICOVAM = p_sicovam);

				IF( EXTRACT(year FROM l_underlying.ECHEANCE)=2083 AND (EXTRACT(DAY FROM l_underlying.ECHEANCE) - 6) = 1 ) 
THEN
				 cficode_2 := 'R';
				 cficode_3 := 'H';    
				ELSE
				cficode_2 := 'R';
				cficode_3 := 'C';    
				END IF;

			END IF;

    ELSIF  (l_instrument.jambe1 = 0 AND l_instrument.jambe2 = 0) THEN     --Both legs are floating
			cficode_2 := 'R';
			cficode_3 := 'A';    
    ELSIF  (l_instrument.jambe1 = 14 OR l_instrument.jambe2 = 14) THEN     --one leg is Inflation-Linked
			cficode_2 := 'R';
			cficode_3 := 'G';
	ELSIF  (l_instrument.jambe1 = 3 OR l_instrument.jambe1 = 4 OR l_instrument.jambe2 = 3 OR l_instrument.jambe2 = 4) THEN

	    IF (l_underlying.TYPE = 'A') THEN
    		cficode_2 := 'E';
			cficode_3 := 'S';   -- EQUITY
		ELSIF (l_underlying.TYPE = 'I') THEN
			IF (l_underlying.nbtitres = 131072) THEN
			cficode_2 := 'E';
			cficode_3 := 'B';   --BASKET
			ELSE
			cficode_2 := 'E';
			cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
    ELSE
			cficode_2 := 'E';
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

    END IF;

    cficode_4 := 'C';

    IF (l_instrument.DEVISEEXER = l_instrument.DEVISEAC AND l_instrument.DEVISECTT = l_instrument.DEVISEAC) THEN
			cficode_5 := 'S';  -- SINGLE CCY
    ELSE
			cficode_5 := 'C'; -- MULTI CCY
    END IF;

    cficode_6 := 'C';

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;	




-- inflation swap   S-R-G-C-(SC)-C    row 38

ELSIF l_instrument.AFFECTATION = 50 THEN -- Inflation Swaps

    cficode_1 := 'S';
    cficode_2 := 'R';    
    cficode_3 := 'G';   --Inflation rate index        
    cficode_4 := 'C'; --NOTIONAL CONSTANT

    IF (l_instrument.DEVISEEXER = l_instrument.DEVISEAC AND l_instrument.DEVISECTT = l_instrument.DEVISEAC) THEN
			cficode_5 := 'S';  -- SINGLE CCY
    ELSE
			cficode_5 := 'C'; -- MULTI CCY
    END IF;   

    cficode_6 := 'C';    

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  

    return cficode;	




 --  Eq Swap   S-E- (SBIM) - (PT)-X-C    row 27


ELSIF l_instrument.AFFECTATION = 27 or l_instrument.AFFECTATION = 1803 THEN -- EQUITY SWAP

    cficode_1 := 'S';
    cficode_2 := 'E';

    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (decode(l_instrument.jambe1,1,l_instrument.j2refcon2,decode
(l_instrument.j1refcon2,0,l_instrument.j2refcon2,l_instrument.j1refcon2)));   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    IF (l_underlying.TYPE = 'A') THEN
    		cficode_3 := 'S';   -- EQUITY
    ELSIF (l_underlying.TYPE = 'I') THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_3 := 'B';   --BASKET
       ELSE
       	cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

    IF  (l_instrument.jambe1 = 3 or l_instrument.jambe1 = 4) THEN

      IF l_instrument.COUPON1 = 0 THEN
        cficode_4 := 'P'; --IF DIVIDEND RATIO = 0
      ELSE
        cficode_4 := 'T';
      END IF;

    ELSIF  (l_instrument.jambe2 = 3 or l_instrument.jambe2 = 4) THEN
      IF l_instrument.COUPON2 = 0 THEN
        cficode_4 := 'P'; --IF DIVIDEND RATIO = 0
      ELSE
        cficode_4 := 'T';
      END IF;        
    END IF;

    cficode_5 := 'X'; -- NOT APPLICABLE

    cficode_6 := 'C';    

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;



-- var / vol swap         S- E-  (SBIM)-(VL) -X-C          row 78 and row 95


ELSIF l_instrument.AFFECTATION = 16 OR l_instrument.AFFECTATION = 1080 OR l_instrument.AFFECTATION = 1810 OR l_instrument.AFFECTATION = 1811 OR l_instrument.AFFECTATION = 1812 OR l_instrument.AFFECTATION = 1807 OR l_instrument.AFFECTATION = 1809 
OR l_instrument.AFFECTATION = 1852 THEN -- VARIANCE SWAP OR VOLATILITY SWAP or Variance Swap - Conditional or Volatility Swap - Conditional or Volatility Swap - Conditional Ref Index


    cficode_1 := 'S';
    cficode_2 := 'E';

    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (decode(l_instrument.jambe1,1,l_instrument.j2refcon2,decode
(l_instrument.j1refcon2,0,l_instrument.j2refcon2,l_instrument.j1refcon2)));   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    IF (l_underlying.TYPE = 'A') THEN
    		cficode_3 := 'S';   -- EQUITY
    ELSIF (l_underlying.TYPE = 'I') THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_3 := 'B';   --BASKET
       ELSE
       	cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

	IF l_instrument.AFFECTATION = 16 or l_instrument.AFFECTATION = 1810 or l_instrument.AFFECTATION = 1808 or  l_instrument.AFFECTATION = 1807 or  l_instrument.AFFECTATION = 1809 or  l_instrument.AFFECTATION = 1852 THEN
		cficode_4 := 'V'; -- Variance 
	ELSIF l_instrument.AFFECTATION = 1080 or l_instrument.AFFECTATION = 1811 or l_instrument.AFFECTATION = 1812 THEN
		cficode_4 := 'L'; -- VOLATILITY
	END IF;

    cficode_5 := 'X'; -- NOT APPLICABLE

    cficode_6 := 'C';    

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;	

ELSIF l_instrument.AFFECTATION = 1808 THEN -- Variance Swap - Conditional Outperf

	cficode_1 := 'S'; -- Swap	
    cficode_2 := 'E'; -- Equity swap
	cficode_3 := 'I'; -- Underlying assets: Index
	cficode_4 := 'V'; -- Return or payout trigger: Variance
	cficode_5 := 'X'; -- Not applicable/undefined
	cficode_6 := 'C'; -- Delivery: Cash

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;	

-- correlation swap     S-E-B-M-X-C   row 25

ELSIF l_instrument.AFFECTATION = 1101 OR l_instrument.AFFECTATION = 1802 THEN -- CORRELATION SWAP or Correlation Swap - Conditional


    cficode_1 := 'S'; --SWAP
    cficode_2 := 'E'; --      
	cficode_3 := 'B'; --BASKET
	cficode_4 := 'M'; --OTHERS
    cficode_5 := 'X'; -- NOT APPLICABLE    
    cficode_6 := 'C'; -- CASH   

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;	



-- knock in VarSwap    S-E-B-X-X-X    row 47


ELSIF l_instrument.AFFECTATION = 1120 THEN -- Knock In VarSwap

    cficode_1 := 'S'; --SWAP
    cficode_2 := 'E'; --      
	cficode_3 := 'I'; -- BASKET
	cficode_4 := 'V'; -- NOT APPLICABLE    
    cficode_5 := 'X'; -- NOT APPLICABLE    
    cficode_6 := 'C'; --  NOT APPLICABLE     

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		






-- TRS Fully Funded   S-M-X-X-X-X      row 76


ELSIF l_instrument.AFFECTATION = 1102 THEN -- TRS(Fully Funded)

    cficode_1 := 'S'; --SWAP
    cficode_2 := 'M'; --      
	cficode_3 := 'X'; -- NOT APPLICABLE    
	cficode_4 := 'X'; -- NOT APPLICABLE    
    cficode_5 := 'X'; -- NOT APPLICABLE    
    cficode_6 := 'X'; --  NOT APPLICABLE     

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		




-- CDS     S-C - (VIUM) - C- (SCX)- C     row 7

ELSIF l_instrument.AFFECTATION = 22 THEN -- CDS

    cficode_1 := 'S';
    cficode_2 := 'C';

    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = (decode(l_instrument.jambe1,1,l_instrument.j2refcon2,decode
(l_instrument.j1refcon2,0,l_instrument.j2refcon2,l_instrument.j1refcon2)));   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    IF (l_underlying.TYPE = 'I') THEN
    	IF 	l_underlying.LIBELLE LIKE '%CDX%' THEN
			cficode_3 := 'V';   -- Index tranche
		ELSE
			cficode_3 := 'I';   -- Index
		END IF;						
    ELSIF (l_underlying.AFFECTATION IN (21,25,26)) THEN
			cficode_3 := 'U';   --Corp Bonds/Gov Bonds/Issuers
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;


	cficode_4 := 'C'; --Credit default
	IF l_underlying.AFFECTATION = 25 THEN --Gov Bonds
		cficode_5 := 'S';   -- Sovereign
    ELSIF l_underlying.AFFECTATION = 26  THEN --Corp Bonds
		cficode_5 := 'C';   -- Corporate
    ELSE
    	cficode_5 := 'X';  --OTHERWISE
    END IF;

	cficode_6 := 'C'; -- Cash

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		



 -- FRA    J-R-I-X-S-(CP)   row 34   


	ELSIF l_instrument.AFFECTATION = 33 THEN -- FRA

    cficode_1 := 'J'; --
    cficode_2 := 'R'; --  RATES    
	cficode_3 := 'I'; -- NOT APPLICABLE    
	cficode_4 := 'X'; -- NOT APPLICABLE    
    cficode_5 := 'S'; -- NOT APPLICABLE    
	IF (l_instrument.TAUX_VAR = 1) THEN
      cficode_6 := 'P'; -- Physical
    ELSE
	  cficode_6 := 'C'; -- Cash
	END IF;

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		





    --CFD    S-E-(SBIM)-C-X-C    row 20


ELSIF l_instrument.AFFECTATION = 12 THEN -- CFDs

    cficode_1 := 'J';
    cficode_2 := 'E';

    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = decode(l_instrument.code_emet,0,decode
(l_instrument.codesj,0,l_instrument.codesj2,l_instrument.codesj),l_instrument.code_emet);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    IF (l_underlying.TYPE = 'A') THEN
    		cficode_3 := 'S';   -- EQUITY
    ELSIF (l_underlying.TYPE = 'I') THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_3 := 'B';   --BASKET
       ELSE
       	cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

    cficode_4 := 'X'; -- NOT APPLICABLE

    cficode_5 := 'C'; -- Contract for difference

    cficode_6 := 'C'; -- CASH

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;



    -- OTC stock deriv  /  Vol options H- E- (SBIFM)-(BEAD)-(DV)-(CP)    row 50 or row86


ELSIF l_instrument.AFFECTATION = 2 or l_instrument.AFFECTATION = 1041 OR l_instrument.AFFECTATION = 1804 OR l_instrument.AFFECTATION = 1805 OR l_instrument.AFFECTATION = 1806 THEN -- OTC Stock Derivatives or Volatility Options or Barrier Option or Return Dispersion Options or Spread Options

    cficode_1 := 'H';
	
	IF (l_instrument.TYPE = 'N' OR l_instrument.MODELE = 'Clause Builder') THEN
	
	cficode_2 := 'X';
	cficode_3 := 'X'; 
	cficode_4 := 'X';
	cficode_5 := 'X';
	cficode_6 := 'X';
	
	ELSIF (l_instrument.type = 'D' and l_instrument.TYPEDERIVE = 3) THEN

	cficode_2 := 'E';
	
	BEGIN
    SELECT      CASE WHEN U1.TYPE=U2.TYPE AND U1.TYPE = 'F' THEN 'F'
                WHEN U1.TYPE=U2.TYPE AND U1.TYPE = 'D' THEN 'O'
                WHEN U1.TYPE=U2.TYPE AND U1.TYPE = 'I' THEN 'I'
                ELSE 'M' END                   
				INTO cficode_3
				FROM TITRES 
                LEFT JOIN TITRES U1 ON TITRES.CODESJ = U1.SICOVAM
                LEFT JOIN TITRES U2 ON TITRES.CODESJ2 = U2.SICOVAM
                WHERE TITRES.SICOVAM = p_sicovam;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        cficode_3 := 'M';
    END; 

	
    IF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.PRIXEXER > 0) THEN 
		cficode_4 := 'B'; -- Exercyse Type = American and Product Type = Call	
	ELSIF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.PRIXEXER < 0) THEN 
		cficode_4 := 'E'; -- Exercyse Type = American and Product Type = Put	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.PRIXEXER > 0) THEN 		
		cficode_4 := 'A'; -- Exercyse Type = European and Product Type = Call	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.PRIXEXER < 0) THEN 		
		cficode_4 := 'D'; -- Exercyse Type = European and Product Type = Put	
	END IF;

	cficode_5 := 'V';
	cficode_6 := 'C';

	ELSE	
    cficode_2 := 'E';
    BEGIN
		SELECT TITRES.*
					INTO l_underlying
					FROM TITRES 
					WHERE TITRES.sicovam = decode(l_instrument.code_emet,0,decode
					(l_instrument.codesj,0,l_instrument.codesj2,l_instrument.codesj),l_instrument.code_emet);
		EXCEPTION
		WHEN NO_DATA_FOUND THEN
			l_underlying := NULL;
		END; 

    IF (l_underlying.TYPE = 'A') THEN
    		cficode_3 := 'S';   -- EQUITY
    ELSIF (l_underlying.TYPE = 'I') THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_3 := 'B';   --BASKET
       ELSE
       	cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
	ELSIF (l_underlying.TYPE = 'F') THEN	   
		cficode_3 := 'F';   --FUTURE
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

    IF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 
		cficode_4 := 'B'; -- Exercyse Type = American and Product Type = Call	
	ELSIF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 
		cficode_4 := 'E'; -- Exercyse Type = American and Product Type = Put	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 		
		cficode_4 := 'A'; -- Exercyse Type = European and Product Type = Call	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 		
		cficode_4 := 'D'; -- Exercyse Type = European and Product Type = Put	
	END IF;

	BEGIN
	SELECT COUNT(*) INTO aux_number
				FROM CLAUSE
				WHERE TYPE IN (20,21,35)
				AND sicovam = p_sicovam;
	EXCEPTION
      WHEN NO_DATA_FOUND THEN
        aux_number := 0;
	END;

	IF (aux_number > 1) THEN
		cficode_5 := 'D'; -- Pay Off Type = Digital
	ELSE
		cficode_5 := 'V'; -- Pay Off Type = Standard vanilla
    END IF;	

	IF (l_instrument.TYPESJ = 2) THEN
      cficode_6 := 'P'; -- Physical
    ELSE
	  cficode_6 := 'C'; -- Cash
	END IF;

	END IF;
	
    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;


 
    -- CDS Options   H-C-(VIUM)- (DS)-(PC)                  row 10
	
ELSIF l_instrument.AFFECTATION = 14 THEN -- Packages

    cficode_1 := 'H';
	cficode_2 := 'X';
	cficode_3 := 'X'; 
	cficode_4 := 'X';
	cficode_5 := 'X';
	cficode_6 := 'X';
    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;

ELSIF l_instrument.AFFECTATION = 1250 THEN -- CDS Options

    cficode_1 := 'H';
    cficode_2 := 'C';

    BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = decode(l_instrument.code_emet,0,decode
(l_instrument.codesj,0,l_instrument.codesj2,l_instrument.codesj),l_instrument.code_emet);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 

    BEGIN
    SELECT TITRES.*
				INTO l_underlying2
				FROM TITRES 
				WHERE TITRES.sicovam = (decode(l_underlying.jambe1,1,l_underlying.j2refcon2,decode
(l_underlying.j1refcon2,0,l_underlying.j2refcon2,l_underlying.j1refcon2)));   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying2 := NULL;
    END; 

    IF (l_underlying2.TYPE = 'I') THEN
    		cficode_3 := 'I';   -- Index
					
    ELSIF (l_underlying2.AFFECTATION IN (21,25,26)) THEN
			cficode_3 := 'U';   --Corp Bonds/Gov Bonds/Issuers
    ELSE
    		cficode_3 := 'M';   --OTHERWISE
    END IF;

    IF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 
		cficode_4 := 'B'; -- Exercyse Type = American and Product Type = Call	
	ELSIF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 
		cficode_4 := 'E'; -- Exercyse Type = American and Product Type = Put	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 		
		cficode_4 := 'A'; -- Exercyse Type = European and Product Type = Call	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 		
		cficode_4 := 'D'; -- Exercyse Type = European and Product Type = Put	
	END IF;

	BEGIN
	SELECT COUNT(*) INTO aux_number
				FROM CLAUSE
				WHERE TYPE IN (20,21,35)
				AND sicovam = p_sicovam;
	EXCEPTION
      WHEN NO_DATA_FOUND THEN
        aux_number := 0;
	END;

	IF (aux_number > 1) THEN
		cficode_5 := 'D'; -- Pay Off Type = Digital
	ELSE
		cficode_5 := 'V'; -- Pay Off Type = vanilla / standard
    END IF;	

	IF (l_instrument.TYPESJ = 2) THEN
      cficode_6 := 'P'; -- Physical
    ELSE
	  cficode_6 := 'C'; -- Cash
	END IF;


    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		



    --OTC Comdty Deriva  S-T-X-X-X-X    row 49



ELSIF l_instrument.AFFECTATION = 1550 THEN -- OTC Commodity Derivatives                       

    cficode_1 := 'S'; --
    cficode_2 := 'T'; --  
	cficode_3 := 'X'; -- NOT APPLICABLE    
	cficode_4 := 'X'; -- NOT APPLICABLE    
    cficode_5 := 'X'; -- NOT APPLICABLE    
	cficode_6 := 'X'; -- NOT APPLICABLE	

    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;		


     
    --Listed Options     O - (CP- (AEB) - (SIBCT)-(PCNE)- (SN)    row 108
    
ELSIF l_instrument.AFFECTATION = 10 THEN -- Listed Options

    cficode_1 := 'O';
 
 BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = decode(l_instrument.code_emet,0,decode
(l_instrument.codesj,0,l_instrument.codesj2,l_instrument.codesj),l_instrument.code_emet);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 
    
        IF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 
		cficode_2 := 'C';
        cficode_3 := 'A';-- Exercyse Type = American and Product Type = Call	
	ELSIF (l_instrument.debutper = '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 
		cficode_2 := 'P'; 
        cficode_3 := 'A';  -- Exercyse Type = American and Product Type = Put	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro IN (1,257)) THEN 		
		cficode_2 := 'C';
        cficode_3 := 'E'; -- Exercyse Type = European and Product Type = Call	
	ELSIF (l_instrument.debutper <> '01-Jan-1904' AND l_instrument.typepro NOT IN (1,257)) THEN 		
		cficode_2 := 'P'; 
        cficode_3 := 'E'; -- Exercyse Type = European and Product Type = Put	
	END IF;


    IF (l_underlying.TYPE = 'A') THEN
    		cficode_4 := 'S';   -- EQUITY
                
    ELSIF (l_underlying.TYPE = 'I') THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_4 := 'B';   --BASKET
       ELSE
       	cficode_4 := 'I';   --INDEX NOT BASKET
       END IF;
      
	ELSIF (l_underlying.TYPE = 'Q') THEN	   
		cficode_4 := 'T';   --Commodity
        
        
    ELSIF (l_underlying.TYPE = 'R') THEN	   
		cficode_4 := 'N';   --Interest Rate
        
    ELSIF (l_underlying.TYPE = 'O') THEN	   
    cficode_4 := 'D';   --Debt 
    
      ELSIF (l_underlying.TYPE = 'F') THEN	   
    cficode_4 := 'F';   --Future
    
            
    ELSIF (l_underlying.TYPE = 'E' )
   THEN	   
		cficode_4 := 'C';   --Currency
    
    
    ELSE
    		cficode_4 := 'M';   --OTHERWISE
    END IF;

	IF (l_instrument.TYPESJ = 2) THEN
      cficode_5 := 'P'; -- Physical
    ELSE
	  cficode_5 := 'C'; -- Cash
    END IF;


    cficode_6 := 'S';
    
    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;

    -- Financial Futures     -F-F-(SICNM)-(PC)- S-X     
    
    ELSIF (l_instrument.AFFECTATION = 5 or l_instrument.AFFECTATION = 28 or l_instrument.AFFECTATION = 49 or l_instrument.AFFECTATION = 1020 
or l_instrument.AFFECTATION = 1040)
 THEN -- Financial Futures

    cficode_1 := 'F';
 
 BEGIN
    SELECT TITRES.*
				INTO l_underlying
				FROM TITRES 
				WHERE TITRES.sicovam = decode(l_instrument.code_emet,0,decode
(l_instrument.codesj,0,l_instrument.codesj2,l_instrument.codesj),l_instrument.code_emet);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_underlying := NULL;
    END; 


IF (l_underlying.TYPE = 'Q') THEN
    cficode_2 := 'C';      
    cficode_3 := 'X';
    cficode_4 := 'X';
    cficode_5 := 'X';
    cficode_6 := 'X';
      cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode; 
ELSE
    cficode_2 := 'F';  
    
   IF (l_underlying.TYPE = 'A' ) THEN
    		cficode_3 := 'S';   -- EQUITY
                
   ELSIF (l_underlying.TYPE = 'I' ) THEN
       IF (l_underlying.nbtitres = 131072) THEN
       	cficode_3 := 'B';   --BASKET
       ELSE
       	cficode_3 := 'I';   --INDEX NOT BASKET
       END IF;
        
  ELSIF (l_instrument.j1refcon1=2 and (l_instrument.code_emet in 
(54609220,54742617,55593040,55656786,54741062,55069508,55201881,55789380,55859012,56246610,54807371,55788875,54739268,55923524,55001680,54875474,55594062,55267927,54613316,54678092,54742096,54745675,55072070,55133266,55135315,55135826,55137099,55400526,55400786,55466564,55855170,55857753,55463755,54612563,55592270,54871888,55918920,55725902,54675276,55790411,55987780,55727426,55532098,55593810,55331666,54805837,55137356,55269972,54940230,54742600,56253018,56115541,55787858,54742864,55003219,55461710,54678095,55726916,55264595,55920472,56115527,55269700,55925077,55002444,56249687,54742086) 
or l_instrument.devisectt in (54609220,54742617,55593040,55656786,54741062,55069508,55201881,55789380,55859012,56246610,54807371,55788875,54739268,55923524,55001680,54875474,55594062,55267927,54613316,54678092,54742096,54745675,55072070,55133266,55135315,55135826,55137099,55400526,55400786,55466564,55855170,55857753,55463755,54612563,55592270,54871888,55918920,55725902,54675276,55790411,55987780,55727426,55532098,55593810,55331666,54805837,55137356,55269972,54940230,54742600,56253018,56115541,55787858,54742864,55003219,55461710,54678095,55726916,55264595,55920472,56115527,55269700,55925077,55002444,56249687,54742086)))
    
     THEN	   
		cficode_3 := 'C';   --Currency
     
    ELSIF (l_underlying.TYPE = 'O') THEN	   
    cficode_3 := 'D';   --Debt 
    
        
    ELSIF (l_underlying.TYPE = 'S' ) THEN	   
    cficode_3 := 'W';   --Swap
    
    ELSIF (l_underlying.TYPE = 'R') THEN	   
		cficode_3 := 'N';   --Interest Rate
       
    ELSE
        cficode_3 := 'M';   --OTHERWISE
                
    END IF;

 IF (l_instrument.taux_var = 1) THEN
      cficode_4 := 'P'; -- Physical
    ELSE
	  cficode_4 := 'C'; -- Cash
	END IF;
         
       cficode_5 := 'S';
       cficode_6 := 'X';
    
    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;
        
  END IF ; 
  
  
ELSE
    cficode_1 :='X';
    cficode_2 :='X';
    cficode_3 :='X';
    cficode_4 :='X';
    cficode_5 :='X';
    cficode_6 :='X';
    cficode := cficode_1 || cficode_2 || cficode_3 || cficode_4 || cficode_5 || cficode_6;  
    return cficode;  
END IF;
  
  
END;

