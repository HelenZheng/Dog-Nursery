create or replace FUNCTION         "BTG_OTC_POST_TRADE_FLAGS" (btg_pt_indicators_value number)
return varchar2 is
    aux  number;
    aux_string char(4);
    output varchar2(100);
	begin
      aux := btg_pt_indicators_value;
      FOR Lcntr IN REVERSE 0..12
      LOOP
          IF( mod(aux,power(2,Lcntr)) < aux ) THEN
            select decode(Lcntr,0,'BENC',1,'ACTX',2,'LRGS',3,'ILQD',4,'SIZE',5,'CANC',6,'AMND',7,'SDIV',8,'RPRI',9,'DUPL',10,'TNCP',11,'TPAC',12,'XFPH') into aux_string from dual;
            output:= output || ';' || aux_string;
            aux := mod(aux,power(2,Lcntr));
          END IF;          
      END LOOP;
      RETURN substr(output,2);
	end;