create or replace 
FUNCTION            "BTG_POSITION_IOF" (
                                    sicovamNumber titres.sicovam%TYPE ,
                                    folioID histomvts.opcvm%TYPE,
                                    dateRef DATE,
                                    ENTITENUMBER NUMBER
                                 )
RETURN NUMBER
  IS
    TotalPosition   NUMBER;
    IOF             NUMBER:=0;
    FILTERINST      NUMBER;
    
    CURSOR TradesLess30Days
    IS
        SELECT * FROM JOIN_POSITION_HISTOMVTS 
        WHERE 
        SICOVAM = sicovamNumber
        AND ENTITE= ENTITENUMBER
        AND QUANTITE > 0
        AND DATENEG between (dateRef-30) AND dateRef
        AND BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)
        ORDER BY DATENEG DESC;
  
    l_trade     TradesLess30Days%ROWTYPE;
    
  BEGIN   
  
   SELECT sum(Quantite) INTO TotalPosition FROM JOIN_POSITION_HISTOMVTS
   INNER JOIN TITRES
   ON JOIN_POSITION_HISTOMVTS.SICOVAM = TITRES.SICOVAM
    WHERE
    JOIN_POSITION_HISTOMVTS.SICOVAM = sicovamNumber
    AND JOIN_POSITION_HISTOMVTS.ENTITE= ENTITENUMBER
    AND DATENEG <= dateRef
    AND JOIN_POSITION_HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)
    AND 
    ( 
    (TITRES.TYPE = 'O' AND TITRES.REFERENCE LIKE 'BR%') --BRAZILIAN BONDS
    OR
    (TITRES.TYPE = 'A' AND TITRES.AFFECTATION=45 AND TITRES.CODE_EMET=54678092 ) -- BRAZILIAN EXTERNAL FUNDS
    );
    
    -- IF POSITION=0 OR IT'S NOT A INSTRUMENT 
    IF(TotalPosition=0)
    THEN RETURN 0;
    END IF;
    
    OPEN TradesLess30Days;
    LOOP
      FETCH TradesLess30Days INTO l_trade;
      EXIT WHEN TradesLess30Days%NOTFOUND;
      IF(TotalPosition >= l_trade.Quantite)
      THEN
          TotalPosition:= TotalPosition - l_trade.Quantite;
          IF (l_trade.opcvm = folioID)
          THEN
          IOF:=IOF+BTG_CALCULATE_IOF( l_trade.refcon , dateRef );
          END IF;
      ELSE          
          IF (l_trade.opcvm = folioID)
          THEN
          IOF:=IOF + ( (TotalPosition / l_trade.Quantite) * BTG_CALCULATE_IOF( l_trade.refcon , dateRef ) );
           END IF;
          TotalPosition:= TotalPosition - l_trade.Quantite;
      END IF;      
      EXIT WHEN TotalPosition <= 0;
    END LOOP;
    CLOSE TradesLess30Days;
    Return Iof;
END;