create or replace 
FUNCTION "BTG_STUB_FIRST_RESET" 
(
    p_sicovam     NUMBER
  , p_freq        NUMBER
  , p_currency    CHAR
)
RETURN CHAR
IS 
  return_date      DATE;
  is_business_date NUMBER   :=1;
BEGIN
   --4 WEEKS
  if p_freq = 0.9 then
  SELECT (TITRES.DATEFINAL - (TRUNC( (DATEFINAL-EMISSION)/28 )* 28))
  INTO return_date
  from TITRES
  WHERE SICOVAM=p_sicovam;
  --ANY MONTHLY FREQUENCE
  else
  SELECT ADD_MONTHS(TITRES.DATEFINAL, -TRUNC(months_between(DATEFINAL,EMISSION)/p_freq)*p_freq)
  INTO return_date
  FROM  dual left join  TITRES on 1=1 
  WHERE SICOVAM =p_sicovam;
  end if;
  select BTG_BUSINESS_DATE_HOLIDAY(return_date,0,CCYSYMBOL_TO_ID(p_currency),1) into return_date from dual;
  
  
  return TO_CHAR(return_date,'mm/dd/yyyy');
 --
END BTG_STUB_FIRST_RESET;

  