CREATE OR REPLACE
FUNCTION            "BTG_STUB_FIRST_START_DATE" 
(
    p_sicovam     NUMBER
  , p_freq        CHAR
  , date_format   CHAR
)
RETURN CHAR
IS 
  return_date      DATE;
  multiplier       NUMBER   := to_number(substr(p_freq,1,length(p_freq)-1));
BEGIN
   -- WEEKS
  if substr(p_freq,-1) = 'W' then
  SELECT (TITRES.DATEFINAL - (TRUNC( (DATEFINAL-EMISSION)/ (7*multiplier) )* (7*multiplier) ))
  INTO return_date
  from TITRES
  WHERE SICOVAM=p_sicovam;
  --ANY MONTHLY FREQUENCE
  ELSIF substr(p_freq,-1) = 'M' then
  SELECT ADD_MONTHS(TITRES.DATEFINAL, -TRUNC(months_between(DATEFINAL,EMISSION)/multiplier)*multiplier)
  INTO return_date
  FROM  dual left join  TITRES on 1=1 
  WHERE SICOVAM =p_sicovam;
  --YEAR FREQUENCE
  ELSIF substr(p_freq,-1) = 'Y' then
  SELECT ADD_MONTHS(TITRES.DATEFINAL, -TRUNC(months_between(DATEFINAL,EMISSION)/(multiplier*12))*(multiplier*12))
  INTO return_date
  FROM  dual left join  TITRES on 1=1 
  WHERE SICOVAM =p_sicovam;
  end if;
  
  return TO_CHAR(return_date,date_format);
 --
END BTG_STUB_FIRST_START_DATE;