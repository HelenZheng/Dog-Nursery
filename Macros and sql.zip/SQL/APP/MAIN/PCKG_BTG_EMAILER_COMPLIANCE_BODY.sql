create or replace
PACKAGE BODY            PCKG_BTG_EMAILER_COMPLIANCE
AS



-- *****************************************************************
 -- Description:    PROCEDURE COMPL_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 20 Jun 2014     Gustavo Binnie  Created (COM-112)
 -- 31 Jul 2015		Matt Kelly		Migrated to new package PCKG_BTG_EMAILER_COMPLIANCE_REPORTS
 -- *****************************************************************  

  PROCEDURE COMPL_RESTRICTED_LIST_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: COMPL_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR


SELECT   distinct
                  RL.NAME                               Restricted_List
				, FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID in (2,3,4,5,6,7)

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: COMPL_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
	END COMPL_RESTRICTED_LIST_TRADES;


 -- *****************************************************************
 -- Description:    PROCEDURE TRADES_MISSING_ID_BB_COMPANY
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 04 Nov 2014     Gustavo Binnie  Created (COM-134)
 -- 09 Oct 2015		Matt Kelly		Updated to include "Rights Issues" 
 --									allotment (ident = 1751)
 -- *****************************************************************  

  PROCEDURE TRADES_MISSING_ID_BB_COMPANY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADES_MISSING_ID_BB_COMPANY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT		
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Sec.libelle                           Instrument_Name
					, Sec.reference                         Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
          , REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null then Sec.sicovam ELSE NULL END || ',' ||
				case when Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null then Underlying1.sicovam ELSE NULL END || ',' ||
				case when Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL then Underlying2.sicovam ELSE NULL END || ',' ||
			  case when UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL then UND_BASKET_SECURITIES.sicovam ELSE NULL END 
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
															SICOVAM_MISSING_DATA
           , REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null then Sec.REFERENCE ELSE NULL END || ',' ||
				case when Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null then Underlying1.REFERENCE ELSE NULL END || ',' ||
				case when Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL then Underlying2.REFERENCE ELSE NULL END || ',' ||
			  case when UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL then UND_BASKET_SECURITIES.REFERENCE ELSE NULL END 
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
															Inst_Reference_MISSING_DATA
				FROM histomvts Trades
				inner join titres Sec
				on Trades.sicovam = Sec.sicovam
				INNER JOIN
					(   SELECT 
						CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
						CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)  AS Fund_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)  AS BOOK_NAME ,
						FOLIO.ident                                                         AS STRATEGY_ID ,
						FOLIO.name                                                          AS STRATEGY_NAME ,
						level
						FROM FOLIO
						WHERE LEVEL                                        >= 4
						START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)-- Primary Funds, UCITS Funds
						CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
					) FUND_BOOK_STRATEGY 
				ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 
				INNER JOIN  business_events
				ON          business_events.id                            = Trades.type
				INNER JOIN  riskusers trader
				ON          trader.ident                                  = Trades.operateur
				LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
				ON			Sec.sicovam = ID_BB_COMPANY.sophis_ident
				and			ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   titres Underlying1
				ON			Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
				LEFT JOIN   extrnl_references_instruments UND1_ID_BB_COMPANY
				ON			Underlying1.sicovam = UND1_ID_BB_COMPANY.sophis_ident
				and			UND1_ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   titres Underlying2
				ON			Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
				and			Underlying1.type <> 'H'				
				LEFT JOIN   extrnl_references_instruments UND2_ID_BB_COMPANY
				ON			Underlying2.sicovam = UND2_ID_BB_COMPANY.sophis_ident
				and			UND2_ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   panier UNDERLYING_BASKET	
				ON			UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM
        LEFT JOIN   TITRES UND_BASKET_SECURITIES
				ON			UND_BASKET_SECURITIES.SICOVAM = UNDERLYING_BASKET.sicopanier
				LEFT JOIN   extrnl_references_instruments UND_BASKET_ID_BB_COMPANY
				ON			UNDERLYING_BASKET.sicopanier = UND_BASKET_ID_BB_COMPANY.sophis_ident
				and			UND_BASKET_ID_BB_COMPANY.ref_ident = 673		
				WHERE 
        
				    Trades.BACKOFFICE						          NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
				AND TRUNC(Trades.DATENEG)                         >= TRUNC(BTG_BUSINESS_DATE(sysdate,-5))  --recent trades
				AND business_events.compta                        = 1                                     --trades affecting position
        AND
        (
        (Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null)
        or
        (Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null)
        or
        (Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL)
        or
        (UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL)
        )
        ;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: TRADES_MISSING_ID_BB_COMPANY
  -- *****************************************************************   
	END TRADES_MISSING_ID_BB_COMPANY;


-- *****************************************************************
-- Description: PROCEDURE RULE_105_RESTRICTED_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_RESTRICTED_TRADES
(
	p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- ***************************************************************************
-- BEGIN OF RULE_105_RESTRICTED_TRADES 
-- ***************************************************************************	
	    OPEN p_CURSOR FOR

SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer
                , SHORT_POSITIONS.POSITION_QTY          n$Position                
FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,14414,14405,90565) -- (14414)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam
      
LEFT JOIN 
(
  SELECT Trades2.sicovam, Trades2.entite, trunc(sum(Trades2.quantite),7) POSITION_QTY
  FROM HISTOMVTS Trades2
  INNER JOIN  business_events
  ON          business_events.id                            = Trades2.type
  AND         business_events.compta                        = 1  
  WHERE       Trades2.BACKOFFICE                            NOT IN (192,11,13,17,26,27,220,248,252)
  GROUP       BY                                            Trades2.sicovam, Trades2.entite
) SHORT_POSITIONS
ON  SHORT_POSITIONS.SICOVAM = Trades.SICOVAM
AND SHORT_POSITIONS.ENTITE  = Trades.ENTITE      

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID = 15

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon   
		 AND RLA.LIST_ID  = RL.ID		         

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR 
FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN 
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate-30)  --recent trades
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
AND (
      TRADES.QUANTITE < 0 --Sell Trades
      OR
      (Sec.TYPE = 'D' AND Sec.TYPEPRO=2 AND TRADES.QUANTITE > 0) --Buy Trades on Put options
    )
;

-- ***************************************************************************
-- END OF RULE_105_RESTRICTED_TRADES 
-- ***************************************************************************	

END RULE_105_RESTRICTED_TRADES;

-- *****************************************************************
-- Description: PROCEDURE RULE_105_WATCH_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_WATCH_TRADES
(
	p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- ***************************************************************************
-- BEGIN OF RULE_105_WATCH_TRADES 
-- ***************************************************************************	
	    OPEN p_CURSOR FOR

SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer
                , SHORT_POSITIONS.POSITION_QTY          n$Position                
FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,14414,14405,90565) -- (14414)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam
      
LEFT JOIN 
(
  SELECT Trades2.sicovam, Trades2.entite, trunc(sum(Trades2.quantite),7) POSITION_QTY
  FROM HISTOMVTS Trades2
  INNER JOIN  business_events
  ON          business_events.id                            = Trades2.type
  AND         business_events.compta                        = 1  
  WHERE       Trades2.BACKOFFICE                            NOT IN (192,11,13,17,26,27,220,248,252)
  GROUP       BY                                            Trades2.sicovam, Trades2.entite
) SHORT_POSITIONS
ON  SHORT_POSITIONS.SICOVAM = Trades.SICOVAM
AND SHORT_POSITIONS.ENTITE  = Trades.ENTITE      

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID = 16

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon 
		 AND RLA.LIST_ID  = RL.ID		           

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR 
FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN 
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate-30)  --recent trades
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
AND (
      TRADES.QUANTITE < 0 --Sell Trades
      OR
      (Sec.TYPE = 'D' AND Sec.TYPEPRO=2 AND TRADES.QUANTITE > 0) --Buy Trades on Put options
    )
;

-- ***************************************************************************
-- END OF RULE_105_WATCH_TRADES 
-- ***************************************************************************	

END RULE_105_WATCH_TRADES;


-- *****************************************************************
-- Description:     PROCEDURE  GPI_WATCH_LIST
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 09 Jun 2015     Gustavo Binnie  Created.

-- *****************************************************************  

  PROCEDURE GPI_WATCH_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: GPI_WATCH_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =19

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: GPI_WATCH_LIST
-- *****************************************************************
   END GPI_WATCH_LIST;

 -- *****************************************************************
 -- Description:    PROCEDURE EQ_RESTRICTED_LISTS_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 24 Jun 2015     Gustavo Binnie  Created (COM-190)
 -- *****************************************************************  

  PROCEDURE EQ_RESTRICTED_LISTS_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EQ_RESTRICTED_LISTS_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct
                  RL.NAME                               Restricted_List
                , FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673

INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID in (39,40,41,42,43,44,45,46,59,79) 
--EQ Global Consumer Restricted List / EQ Relative Value Restricted List / EQ US Cash Restricted List / EQ Systematic Restricted List / 
--EQ Convertible Bonds Restricted List / EQ Events Restricted List / EQ Volatility Restricted List / EQ US IPO / CIO(AD) Restricted List
--Timber Trading Fund Restricted List

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: EQ_RESTRICTED_LISTS_TRADES
-- *****************************************************************
   END EQ_RESTRICTED_LISTS_TRADES;


 -- *****************************************************************
 -- Description:    PROCEDURE TRADER_MISSING_ALLOC_RULE
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 03 Sep 2015     Gustavo Binnie  Created (COM-219)
 -- *****************************************************************  

  PROCEDURE TRADER_MISSING_ALLOC_RULE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADER_MISSING_ALLOC_RULE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 		USERSMISSING.IDENT 		ID, 
			USERSMISSING.TRADER 	TRADER, 
			STRATS.STRATEGIES 		STRATEGY
FROM
		(
		SELECT  
					DISTINCT
					HISTOMVTS.OPERATEUR AS IDENT,
					RISKUSERS.NAME  AS TRADER                        
		FROM        HISTOMVTS
		INNER JOIN  RISKUSERS
		ON          RISKUSERS.IDENT = HISTOMVTS.OPERATEUR
		AND         RISKUSERS.GIDENT = 4567 --FRONT OFFICE USER GROUP
		INNER JOIN  USERINFOS
		ON          USERINFOS.IDENT = RISKUSERS.IDENT
		AND         USERINFOS.COUNTRY != 'BRAZIL' --EXCLUDE BRAZIL TRADERS SINCE THEY ARE NOT MONITORED BY GAM COMPLIANCE
		INNER JOIN  BUSINESS_EVENTS
		ON          BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
		AND         BUSINESS_EVENTS.COMPTA = 1 --POSITION AFFECTING TICKETS ONLY
		WHERE       HISTOMVTS.OPERATEUR NOT IN (
										SELECT SOPHIS_USER_ID 
										FROM BTG_ALLCTN_RL_TRDR) --SET UP IN ALLOCATION RULE MANAGER
		AND         HISTOMVTS.DATENEG > '01-JAN-2015' --TRADES FROM THIS YEAR
		) USERSMISSING
LEFT JOIN  
		(	  	
		SELECT 		TRADER AS TRADERID,
					LISTAGG(STRATEGIES, ',') within group (order by 1) AS STRATEGIES --CONCATENATION OF STRATEGIES THAT TRADER BOOK INTO
		FROM
					(
					SELECT 		DISTINCT TRADES.OPERATEUR 	 AS TRADER,
								FUND_BOOK_STRATEGY.BOOK_NAME AS STRATEGIES 
					FROM 		HISTOMVTS TRADES
					INNER JOIN  BUSINESS_EVENTS
					ON          BUSINESS_EVENTS.ID = TRADES.TYPE
					AND         BUSINESS_EVENTS.COMPTA = 1
					INNER JOIN (
								SELECT REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
								,FOLIO.IDENT AS STRATEGY_ID
								,FOLIO.NAME AS STRATEGY_NAME
								,LEVEL
								FROM FOLIO
								WHERE LEVEL >= 4 START
								WITH FOLIO.IDENT IN (14414) --PRIMARY FUNDS 
								CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
								) FUND_BOOK_STRATEGY
					ON 			FUND_BOOK_STRATEGY.STRATEGY_ID = TRADES.OPCVM
					WHERE 		TRADES.DATENEG > (SYSDATE-90) -- LAST 90 DAYS
					) 
		GROUP BY TRADER
		)STRATS
ON 		USERSMISSING.IDENT = STRATS.TRADERID
ORDER 	BY 2
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: TRADER_MISSING_ALLOC_RULE
-- *****************************************************************
   END TRADER_MISSING_ALLOC_RULE;

 -- *****************************************************************
 -- Description:    PROCEDURE REMIT_TRADING
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Nov 2015     Gustavo Binnie  Created (COM-238)
 -- *****************************************************************  

  PROCEDURE REMIT_TRADING
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REMIT_TRADING
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, SEC.libelle                    		Name
						, SEC.reference                  		Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
    FROM 		histomvts 	Trades
	INNER JOIN 	titres 		Sec
	ON 			Trades.sicovam 				= Sec.sicovam
    INNER JOIN  riskusers trader
    ON          trader.ident                = Trades.operateur
	INNER JOIN
		(   SELECT 
			CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
			CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)  AS Fund_NAME ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)  AS BOOK_NAME ,
			FOLIO.ident                                                         AS STRATEGY_ID ,
			FOLIO.name                                                          AS STRATEGY_NAME ,
			level
			FROM FOLIO
			WHERE LEVEL                                        >= 4
			START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414, 90565) 
			CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
		) FUND_BOOK_STRATEGY 
	ON          FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM 
	LEFT JOIN   titres Underlying1
    ON 			Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
	LEFT JOIN   titres Underlying2
    ON 			Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
    and 		Underlying1.type <> 'H'
	WHERE 
	(
		SEC.MODELE LIKE '%Power%' or Underlying1.modele like '%Power%' or Underlying2.modele like '%Power%' --Insrument or underlying is using a Power model
		or
		SEC.MODELE LIKE '%Gas%' or Underlying1.modele like '%Gas%' or Underlying2.modele like '%Gas%' --Insrument or underlying is using a Gas model
		or
		sec.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Insrument is using an energy unit (e.g. MMBtu, MWh)
		or
		Underlying1.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Underlying is using an energy unit (e.g. MMBtu, MWh)
		or
		Underlying2.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Second underlying is using an energy unit (e.g. MMBtu, MWh)
	)
	AND
	(
		(SEC.marche <> 961 and SEC.marche <> 1554) -- Future Market not NYMEX USD and not NYMEX CRUDE/RBOB/H-OIL/NATGAS
		OR
		Underlying1.REFERENCE <> 'NG' --Underlying is not NG (NAT GAS NYMEX)
	)
	AND    
	TRADES.BACKOFFICE  NOT IN (192,11,13,17,26,27,220,248,252)
	AND
	TRADES.DATENEG > ADD_MONTHS(SYSDATE,-1)
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: REMIT_TRADING
-- *****************************************************************
   END REMIT_TRADING;


   -- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_TRANSACTION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 22 DEC 2016     Jeff Yu    Created (COM-293)
 -- 17 JAN 2017      Jeff Yu    Modified (COM-298)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_TRANSACTION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOI_ILS_TRANSACTION
  -- *****************************************************************   
          OPEN p_CURSOR FOR


    SELECT DISTINCT
                               histomvts.SICOVAM                                                          as  Instrument_id
                              , histomvts.refcon                                                               as  Transaction_id
                              , titres.libelle                                                                       as  Instrument_name
                              , BE.name                                                                            as  Business_event
                              , affectation.libelle                                                              as  Allotment
                              , btg_get_instrument_type(histomvts.sicovam)                  as  Instrument_Type
                              , DEVISE_TO_STR(histomvts.devisepay)                             as  Payment_currency
                              , DEVISE_TO_STR(devisectt)                                               as  Quotation_currency
                              , histomvts.dateneg                                                             as  d$Trade_date
                              , histomvts.dateval                                                              as  d$Value_date
                              , histomvts.quantite                                                            as   n$Quantity
                              , histomvts.QUANTITE * NVL(TITRES.nominal,1)                as  n$Nominal
                              , histomvts.cours                                                                 as  p$8$Price
                              , histomvts.montant                                                            as  n$Net_amount
                              , histomvts.tauxchange                                                       as  Exchange_rate

    FROM  histomvts
    INNER JOIN (
            SELECT      FOLIO.ident AS STRATEGY_ID
                             ,FOLIO.NAME AS STRATEGY_NAME
                             ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 2 
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_BTG_FUND,PCKG_BTG.FOLIO_BTG_WEALTH_MANAGEMENT) --12514,86931
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
     LEFT JOIN  TITRES
     ON TITRES.SICOVAM=histomvts.SICOVAM

     LEFT JOIN  BUSINESS_EVENTS BE
     ON BE.id=histomvts.type

     LEFT JOIN  AFFECTATION
     ON  AFFECTATION.ident=titres.affectation

     LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
     ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
     AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415

    LEFT JOIN AUDIT_MVT  ---Get history trades audit information
     ON AUDIT_MVT.REFCON=histomvts.REFCON
     
     WHERE  
    (
      (titres.type in ('X','E','K') and DEVISE_TO_STR(marche)='ILS') OR
      (DEVISE_TO_STR(devisectt)='ILS' or DEVISE_TO_STR(deviseac)='ILS' or DEVISE_TO_STR(deviseexer)='ILS' or DEVISE_TO_STR(histomvts.devisepay)='ILS') 
    )
    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
    AND trunc(DATEMODIF) = TRUNC(SYSDATE-1)  --Report actions happened on previous day
    AND AUDIT_MVT.VERSION=1 ---Check New Booked trade
	;

   EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: BOI_ILS_TRANSACTION
-- *****************************************************************
   END BOI_ILS_TRANSACTION;



    -- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_MODIFICATION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 22 DEC 2016     Jeff Yu    Created (COM-293)
  -- 17 JAN 2017      Jeff Yu    Modified (COM-298)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_MODIFICATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOI_ILS_MODIFICATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR


    SELECT DISTINCT
                                histomvts.SICOVAM                                                          as  Instrument_id
                              , histomvts.refcon                                                               as  Transaction_id
                              , titres.libelle                                                                       as  Instrument_name
                              , BE.name                                                                            as  Business_event
                              , affectation.libelle                                                              as  Allotment
                              , btg_get_instrument_type(histomvts.sicovam)                 as  Instrument_Type
                              , DEVISE_TO_STR(histomvts.devisepay)                             as  Payment_currency
                              , DEVISE_TO_STR(devisectt)                                               as  Quotation_currency
                              , histomvts.dateneg                                                             as  d$Trade_date
                              , histomvts.dateval                                                              as  d$Value_date
                              , AM.Datemodify                                                                       as  d$Modification_date
                              , case when am.state = 2 then 'Modification' 
                                         when am.state = 3 then 'Cancelation' end                   as  Action_Status
                              , histomvts.quantite                                                            as   n$Quantity
                              , histomvts.QUANTITE * NVL(TITRES.nominal,1)                as  n$Nominal
                              , histomvts.cours                                                                 as  p$8$Price
                              , histomvts.montant                                                            as  n$Net_amount
                              , histomvts.tauxchange                                                       as  Exchange_rate

    FROM  histomvts
    INNER JOIN (
            SELECT      FOLIO.ident AS STRATEGY_ID
                             ,FOLIO.NAME AS STRATEGY_NAME
                             ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 2 
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_BTG_FUND,PCKG_BTG.FOLIO_BTG_WEALTH_MANAGEMENT) --12514,86931
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
     LEFT JOIN  TITRES
     ON TITRES.SICOVAM=histomvts.SICOVAM

     LEFT JOIN  BUSINESS_EVENTS BE
     ON BE.id=histomvts.type

     LEFT JOIN  AFFECTATION
     ON  AFFECTATION.ident=titres.affectation
     
      INNER JOIN      (
                        select 
                          REFCON
                        ,max(DATEMODIF)  as DATEMODIFY
                        ,max(STATE) as STATE
                        ,max(version)
                        from AUDIT_MVT 
                        where TRUNC(DATEMODIF) = TRUNC(sysdate-1) and STATE != 1
                        group by REFCON
                    ) AM
     ON AM.REFCON=histomvts.REFCON
     
     LEFT JOIN AUDIT_MVT  NB ---Get previous day new booked trade
     ON NB.REFCON=histomvts.REFCON
     and NB.version=1
     and trunc(NB.DATEMODIF) = trunc(sysdate-1)  
     
     WHERE  
    (
      (titres.type in ('X','E','K') and DEVISE_TO_STR(marche)='ILS') OR
      (DEVISE_TO_STR(devisectt)='ILS' or DEVISE_TO_STR(deviseac)='ILS' or DEVISE_TO_STR(deviseexer)='ILS' or DEVISE_TO_STR(histomvts.devisepay)='ILS') 
    )
    AND  NB.REFCON is null   ----Exclude new booked modifications
    ORDER BY histomvts.refcon
     ;

   EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: BOI_ILS_MODIFICATION
-- *****************************************************************
   END BOI_ILS_MODIFICATION;


END PCKG_BTG_EMAILER_COMPLIANCE;