create or replace
PROCEDURE         "BTG_HOUSE_KEEP" 
AS
BEGIN
  
  -- 1823 Liquidity 
  -- 1824 Level 1

  DELETE
  FROM    SECTOR_INSTRUMENT_ASSOCIATION
  WHERE   SECTOR_INSTRUMENT_ASSOCIATION.sicovam IN (
    SELECT  TITRES.sicovam 
    FROM    TITRES 
    WHERE   TITRES.type IN ('A', 'E', 'X', 'K', 'G', 'S', 'F', 'D', 'B') 
    AND NOT (TITRES.type = 'S' AND (TITRES.jambe1 IN (3, 5) OR TITRES.jambe2 IN (3, 5)))
    AND     TITRES.reference NOT IN ('573975Z CB', 'BMPS EU Equity','CFD IEH LN EQUITY UBS', 'IEH LN Equity','US02563WAA27' )
  )
  AND     SECTOR_INSTRUMENT_ASSOCIATION.type = 1823; 

  INSERT INTO SECTOR_INSTRUMENT_ASSOCIATION (
    SELECT  TITRES.sicovam 
    ,       1823
    ,       1824
    FROM    TITRES 
    WHERE   TITRES.type IN ('A', 'E', 'X', 'K', 'G', 'S', 'F', 'D', 'B') 
    AND NOT (TITRES.type = 'S' AND (TITRES.jambe1 IN (3, 5) OR TITRES.jambe2 IN (3, 5)))
    AND     TITRES.reference NOT IN ('573975Z CB', 'BMPS EU Equity','CFD IEH LN EQUITY UBS', 'IEH LN Equity','US02563WAA27' )
  );
  
  DELETE
  FROM    SECTOR_INSTRUMENT_ASSOCIATION
  WHERE   SECTOR_INSTRUMENT_ASSOCIATION.sicovam IN (
    SELECT  TITRES.sicovam 
    FROM    TITRES 
    WHERE   AFFECTATION IN (16, 1080)
  )
  AND     SECTOR_INSTRUMENT_ASSOCIATION.type = 1823; 
  
  INSERT INTO SECTOR_INSTRUMENT_ASSOCIATION (
    SELECT  TITRES.sicovam 
    ,       1823
    ,       1824
    FROM    TITRES 
    WHERE   AFFECTATION IN (16, 1080)
  );
  
  DELETE
  FROM    SECTOR_INSTRUMENT_ASSOCIATION
  WHERE   SECTOR_INSTRUMENT_ASSOCIATION.sicovam IN (
    SELECT  TITRES.sicovam 
    FROM    TITRES 
    WHERE   AFFECTATION = 1101
  )
  AND     SECTOR_INSTRUMENT_ASSOCIATION.type = 1823; 
  
  INSERT INTO SECTOR_INSTRUMENT_ASSOCIATION (
    SELECT  TITRES.sicovam 
    ,       1823
    ,       1825
    FROM    TITRES 
    WHERE   AFFECTATION = 1101
  );
    
  -- All TRS' in EM (Latam) Rates
  DELETE
  FROM SECTOR_INSTRUMENT_ASSOCIATION
  WHERE SECTOR_INSTRUMENT_ASSOCIATION.sicovam IN (
    SELECT TITRES.sicovam
    FROM TITRES 
    WHERE TITRES.sicovam IN (
      SELECT HISTOMVTS.sicovam
      FROM HISTOMVTS
      INNER JOIN (
        SELECT FOLIO.ident
        FROM FOLIO
        START WITH FOLIO.ident IN (13269, 14129, 94822)
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ) FOLIOS
      ON FOLIOS.ident = HISTOMVTS.opcvm
    )
    AND TITRES.type = 'S'
    AND (TITRES.jambe1 IN (3, 5) OR TITRES.jambe2 IN (3, 5))
  )
  AND SECTOR_INSTRUMENT_ASSOCIATION.type = 1823; 
  
  INSERT INTO SECTOR_INSTRUMENT_ASSOCIATION (
    SELECT TITRES.sicovam 
    , 1823
    , 1824
    FROM TITRES 
    WHERE TITRES.sicovam IN (
      SELECT HISTOMVTS.sicovam
      FROM HISTOMVTS
      INNER JOIN (
        SELECT FOLIO.ident
        FROM FOLIO
        START WITH FOLIO.ident IN (13269, 14129, 94822)
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ) FOLIOS
      ON FOLIOS.ident = HISTOMVTS.opcvm
    )
    AND TITRES.type = 'S'
    AND (TITRES.jambe1 IN (3, 5) OR TITRES.jambe2 IN (3, 5))
  );
  
  COMMIT;

  -- 3783 IFRS 7 Rating
  -- 3823 Level 1
  -- 3824 Level 2
  DELETE
  FROM    sector_instrument_association
  WHERE   sicovam IN (SELECT sicovam FROM titres WHERE TYPE IN ('E', 'L', 'M', 'B', 'N', 'S', 'W', 'G', 'K', 'X'))
  AND     type = 3783;

  INSERT INTO sector_instrument_association
    (SELECT sicovam, 3783, 3824 FROM titres WHERE TYPE IN ('B', 'N', 'S', 'W', 'G', 'K', 'X'));
  
  INSERT INTO sector_instrument_association
    (SELECT sicovam, 3783, 3823 FROM titres WHERE TYPE IN ('E', 'L', 'M'));
    
  COMMIT;

  -- copy over liquidity levels to IFRS 7 Rating for all bonds where IFRS 7 Rating is empty.
  INSERT INTO SECTOR_INSTRUMENT_ASSOCIATION (
    SELECT TITRES.sicovam
    , 3783 
    , CASE SECTOR_LIQUIDTY.sector WHEN 1824 THEN 3823 WHEN 1825 THEN 3824 WHEN 1843 THEN 3843 END
    FROM TITRES 
    INNER JOIN SECTOR_INSTRUMENT_ASSOCIATION SECTOR_LIQUIDTY
    ON SECTOR_LIQUIDTY.sicovam = TITRES.sicovam
    AND SECTOR_LIQUIDTY.type = 1823
    AND SECTOR_LIQUIDTY.sector IN (1824, 1825, 1843)
    WHERE TITRES.type = 'O'
    AND NOT EXISTS (SELECT * FROM SECTOR_INSTRUMENT_ASSOCIATION WHERE SECTOR_INSTRUMENT_ASSOCIATION.type = 3783 AND SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam)
  );
  
  COMMIT;  
  
  /* Remove Global from all RICs set to Closing off Duty and the instrument is in titres */
UPDATE  RIC 
SET     RIC.PREFIXE = null 
WHERE   RIC.SICOVAM IN 
        (
        SELECT 
                RIC.SICOVAM       SICOVAM
        FROM 
              RIC
        INNER JOIN TITRES
        ON    TITRES.SICOVAM=RIC.SICOVAM
        INNER JOIN FIDLIST
        ON    FIDLIST.ITEM = RIC.FID
        WHERE
              RIC.FID =0
        AND   RIC.PREFIXE = 'Global'
        );
 COMMIT;  

/* Remove Global flag from all expired instruments */
UPDATE    RIC
SET       PREFIXE = NULL
WHERE     RIC.SICOVAM IN 
          (
          SELECT      TITRES.SICOVAM
          FROM TITRES
          WHERE       (
                      (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) < trunc(sysdate)) --swaps
                      OR
                      (TITRES.type in  ('O','D') and TITRES.FINPER < trunc(sysdate)) --Bonds/Options
                      OR 
                      (TITRES.type in ('M','F') and TITRES.ECHEANCE < trunc(sysdate)) --OTC Stock derivatives
                      OR
                      (TITRES.type = 'F' and TITRES.EXSOC < trunc(sysdate) and trunc(to_date(TITRES.EXSOC,'DD-MON-YY')) != trunc(to_date('01-JAN-04','DD-MON-YY'))) --Futures
                      OR
                      (TITRES.type = 'L' and to_date(TITRES.finper,'DD-MON-YY')!=to_date('01-JAN-04','DD-MON-YY') and trunc(TITRES.FINPER) < trunc(sysdate)) --Repo
                    )
          );
  COMMIT;  
  
END;