--------------------------------------------------------
--  DDL for Sequence BTG_ALLCTN_RL_FND_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BTG_ALLCTN_RL_FND_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
/
--------------------------------------------------------
--  DDL for Sequence BTG_ALLCTN_RL_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BTG_ALLCTN_RL_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
/
--------------------------------------------------------
--  DDL for Sequence BTG_ALLCTN_RL_USR_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "BTG_ALLCTN_RL_USR_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_CHCK_HSTRY
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_CHCK_HSTRY" 
   (	"SOPHIS_TRANSACTION_ID" NUMBER, 
	"EFFECTIVE_DT" TIMESTAMP (6), 
	"ALLOCATION_RULE_ID" NUMBER, 
	"ALLOCATION_RULE_VERSION" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"ALLOCATION_RULE_ID" NUMBER(*,0), 
	"SOPHIS_FUND_ID" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND_FL
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND_FL" 
   (	"ALLOCATION_RULE_FUND_ID" NUMBER(*,0), 
	"SOPHIS_FOLIO_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND_FL_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND_FL_ID" 
   (	"ALLOCATION_RULE_FUND_ID" NUMBER(*,0), 
	"SOPHIS_FOLIO_ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND_FL_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" 
   (	"ALLOCATION_RULE_FUND_ID" NUMBER(*,0), 
	"SOPHIS_FOLIO_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"INCLUDE_EXCLUDE" CHAR(1 BYTE), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND_ID" 
   (	"ID" NUMBER(*,0), 
	"ALLOCATION_RULE_ID" NUMBER(*,0), 
	"SOPHIS_FUND_ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_FND_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_FND_VRSN" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"PERCENTAGE" NUMBER, 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_ID" 
   (	"ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/

--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_FND
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_FND" 
   (	"SOPHIS_FUND_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_FND_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_FND_ID" 
   (	"SOPHIS_FUND_ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_FND_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" 
   (	"SOPHIS_FUND_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"STARTING_SOPHIS_FOLIO_ID" NUMBER(*,0), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_USR
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_USR" 
   (	"SOPHIS_USER_ID" VARCHAR2(20 BYTE), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_USR_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_USR_ID" 
   (	"SOPHIS_USER_ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_SPHS_USR_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" 
   (	"SOPHIS_USER_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_TRDR
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_TRDR" 
   (	"ALLOCATION_RULE_ID" NUMBER(*,0), 
	"SOPHIS_USER_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_TRDR_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_TRDR_ID" 
   (	"ALLOCATION_RULE_ID" NUMBER(*,0), 
	"SOPHIS_USER_ID" NUMBER(*,0), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_TRDR_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_TRDR_VRSN" 
   (	"ALLOCATION_RULE_ID" NUMBER(*,0), 
	"SOPHIS_USER_ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_USR
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_USR" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_USR_ID
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_USR_ID" 
   (	"ID" NUMBER(*,0), 
	"NAME" VARCHAR2(50 BYTE), 
	"CREATED_BY" NUMBER(*,0), 
	"CREATED_DT" TIMESTAMP (6)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_USR_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_USR_VRSN" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"PASSWORD" VARCHAR2(20 BYTE), 
	"IS_ADMINISTRATOR" CHAR(1 BYTE), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Table BTG_ALLCTN_RL_VRSN
--------------------------------------------------------

  CREATE TABLE "BTG_ALLCTN_RL_VRSN" 
   (	"ID" NUMBER(*,0), 
	"VERSION" NUMBER(*,0), 
	"NAME" VARCHAR2(50 BYTE), 
	"ACTIVE" CHAR(1 BYTE), 
	"ACTIVE_FROM_DT" TIMESTAMP (6), 
	"ACTIVE_TO_DT" TIMESTAMP (6), 
	"UPDATED_BY" NUMBER(*,0), 
	"UPDATED_DT" TIMESTAMP (6), 
	"EFFECTIVE_FROM_DT" TIMESTAMP (6), 
	"EFFECTIVE_TO_DT" TIMESTAMP (6), 
	"DELETED" CHAR(1 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL" ("ID", "VERSION", "NAME", "ACTIVE", "ACTIVE_FROM_DT", "ACTIVE_TO_DT", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED", "MATCHED") AS 
	SELECT      BTG_ALLCTN_RL_ID.id
	,           BTG_ALLCTN_RL_VRSN.version
	,           BTG_ALLCTN_RL_VRSN.name
	,           BTG_ALLCTN_RL_VRSN.active
	,           BTG_ALLCTN_RL_VRSN.active_from_dt
	,           BTG_ALLCTN_RL_VRSN.active_to_dt
	,           BTG_ALLCTN_RL_ID.created_by
	,           BTG_ALLCTN_RL_ID.created_dt
	,           BTG_ALLCTN_RL_VRSN.updated_by
	,           BTG_ALLCTN_RL_VRSN.updated_dt
	,           BTG_ALLCTN_RL_VRSN.effective_from_dt
	,           BTG_ALLCTN_RL_VRSN.effective_to_dt
	,           BTG_ALLCTN_RL_VRSN.deleted
	,           COALESCE((SELECT 'Y' FROM DUAL WHERE EXISTS (SELECT * FROM BTG_ALLCTN_RL_CHCK_HSTRY WHERE BTG_ALLCTN_RL_CHCK_HSTRY.allocation_rule_id = BTG_ALLCTN_RL_ID.id)), 'N') AS "MATCHED"
	FROM        BTG_ALLCTN_RL
	INNER JOIN  BTG_ALLCTN_RL_ID
	ON          BTG_ALLCTN_RL_ID.id         = BTG_ALLCTN_RL.id
	INNER JOIN  BTG_ALLCTN_RL_VRSN
	ON          BTG_ALLCTN_RL_VRSN.id       = BTG_ALLCTN_RL.id
	AND         BTG_ALLCTN_RL_VRSN.version  = BTG_ALLCTN_RL.version;
	/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_FND
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_FND" ("ID", "ALLOCATION_RULE_ID", "SOPHIS_FUND_ID", "VERSION", "SOPHIS_FUND_NAME", "PERCENTAGE", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_FND_ID.id
,           BTG_ALLCTN_RL_FND_ID.allocation_rule_id
,           BTG_ALLCTN_RL_FND_ID.sophis_fund_id
,           BTG_ALLCTN_RL_FND_VRSN.version
,           TIERS.name AS sophis_fund_name
,           BTG_ALLCTN_RL_FND_VRSN.percentage
,           BTG_ALLCTN_RL_FND_ID.created_by
,           BTG_ALLCTN_RL_FND_ID.created_dt
,           BTG_ALLCTN_RL_FND_VRSN.updated_by
,           BTG_ALLCTN_RL_FND_VRSN.updated_dt
,           BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_FND_VRSN.deleted
FROM        BTG_ALLCTN_RL_FND
INNER JOIN  BTG_ALLCTN_RL_FND_ID
ON          BTG_ALLCTN_RL_FND_ID.id         = BTG_ALLCTN_RL_FND.id
INNER JOIN  BTG_ALLCTN_RL_FND_VRSN
ON          BTG_ALLCTN_RL_FND_VRSN.id       = BTG_ALLCTN_RL_FND.id
AND         BTG_ALLCTN_RL_FND_VRSN.version  = BTG_ALLCTN_RL_FND.version
INNER JOIN  TIERS
ON          TIERS.ident                     = BTG_ALLCTN_RL_FND.sophis_fund_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_FND_FL
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_FND_FL" ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID", "VERSION", "SOPHIS_FOLIO_NAME", "INCLUDE_EXCLUDE", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_FND_FL_ID.allocation_rule_fund_id
,           BTG_ALLCTN_RL_FND_FL_ID.sophis_folio_id
,           BTG_ALLCTN_RL_FND_FL_VRSN.version
,           FOLIO.name AS sophis_folio_name
,           BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude
,           BTG_ALLCTN_RL_FND_FL_ID.created_by
,           BTG_ALLCTN_RL_FND_FL_ID.created_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
,           BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.deleted
FROM        BTG_ALLCTN_RL_FND_FL
INNER JOIN  BTG_ALLCTN_RL_FND_FL_ID
ON          BTG_ALLCTN_RL_FND_FL_ID.allocation_rule_fund_id     = BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id
AND         BTG_ALLCTN_RL_FND_FL_ID.sophis_folio_id             = BTG_ALLCTN_RL_FND_FL.sophis_folio_id
INNER JOIN  BTG_ALLCTN_RL_FND_FL_VRSN
ON          BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id   = BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id
AND         BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id           = BTG_ALLCTN_RL_FND_FL.sophis_folio_id
AND         BTG_ALLCTN_RL_FND_FL_VRSN.version                   = BTG_ALLCTN_RL_FND_FL.version
INNER JOIN  FOLIO
ON          FOLIO.ident                                         = BTG_ALLCTN_RL_FND_FL.sophis_folio_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_FND_FL_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_FND_FL_VRSN" ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID", "VERSION", "SOPHIS_FOLIO_NAME", "INCLUDE_EXCLUDE", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_FND_FL_ID.allocation_rule_fund_id
,           BTG_ALLCTN_RL_FND_FL_ID.sophis_folio_id
,           BTG_ALLCTN_RL_FND_FL_VRSN.version
,           FOLIO.name AS sophis_folio_name
,           BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude
,           BTG_ALLCTN_RL_FND_FL_ID.created_by
,           BTG_ALLCTN_RL_FND_FL_ID.created_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
,           BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_FND_FL_VRSN.deleted
FROM        BTG_ALLCTN_RL_FND_FL_ID
INNER JOIN  BTG_ALLCTN_RL_FND_FL_VRSN
ON          BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id   = BTG_ALLCTN_RL_FND_FL_ID.allocation_rule_fund_id
AND         BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id           = BTG_ALLCTN_RL_FND_FL_ID.sophis_folio_id
INNER JOIN  FOLIO
ON          FOLIO.ident                                         = BTG_ALLCTN_RL_FND_FL_ID.sophis_folio_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_FND_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_FND_VRSN" ("ID", "ALLOCATION_RULE_ID", "SOPHIS_FUND_ID", "VERSION", "SOPHIS_FUND_NAME", "PERCENTAGE", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_FND_ID.id
,           BTG_ALLCTN_RL_FND_ID.allocation_rule_id
,           BTG_ALLCTN_RL_FND_ID.sophis_fund_id
,           BTG_ALLCTN_RL_FND_VRSN.version
,           TIERS.name AS sophis_fund_name
,           BTG_ALLCTN_RL_FND_VRSN.percentage
,           BTG_ALLCTN_RL_FND_ID.created_by
,           BTG_ALLCTN_RL_FND_ID.created_dt
,           BTG_ALLCTN_RL_FND_VRSN.updated_by
,           BTG_ALLCTN_RL_FND_VRSN.updated_dt
,           BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_FND_VRSN.deleted
FROM        BTG_ALLCTN_RL_FND_ID
INNER JOIN  BTG_ALLCTN_RL_FND_VRSN
ON          BTG_ALLCTN_RL_FND_VRSN.id       = BTG_ALLCTN_RL_FND_ID.id
INNER JOIN  TIERS
ON          TIERS.ident                     = BTG_ALLCTN_RL_FND_ID.sophis_fund_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_SPHS_FND
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_SPHS_FND" ("SOPHIS_FUND_ID", "VERSION", "SOPHIS_FUND_NAME", "STARTING_SOPHIS_FOLIO_ID", "STARTING_SOPHIS_FOLIO_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_SPHS_FND_ID.sophis_fund_id
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.version
,           TIERS.name as sophis_fund_name
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
,           FOLIO.name AS starting_sophis_folio_name
,           BTG_ALLCTN_RL_SPHS_FND_ID.created_by
,           BTG_ALLCTN_RL_SPHS_FND_ID.created_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
FROM        BTG_ALLCTN_RL_SPHS_FND
INNER JOIN  BTG_ALLCTN_RL_SPHS_FND_ID
ON          BTG_ALLCTN_RL_SPHS_FND_ID.sophis_fund_id    = BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id
INNER JOIN  BTG_ALLCTN_RL_SPHS_FND_VRSN
ON          BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id  = BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id
AND         BTG_ALLCTN_RL_SPHS_FND_VRSN.version         = BTG_ALLCTN_RL_SPHS_FND.version
INNER JOIN  TIERS
ON          TIERS.ident                                 = BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id
INNER JOIN  FOLIO
ON          FOLIO.ident                                 = BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_SPHS_FND_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_SPHS_FND_VRSN" ("SOPHIS_FUND_ID", "VERSION", "SOPHIS_FUND_NAME", "STARTING_SOPHIS_FOLIO_ID", "STARTING_SOPHIS_FOLIO_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_SPHS_FND_ID.sophis_fund_id
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.version
,           TIERS.name as sophis_fund_name
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
,           FOLIO.name AS starting_sophis_folio_name
,           BTG_ALLCTN_RL_SPHS_FND_ID.created_by
,           BTG_ALLCTN_RL_SPHS_FND_ID.created_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
FROM        BTG_ALLCTN_RL_SPHS_FND_ID
INNER JOIN  BTG_ALLCTN_RL_SPHS_FND_VRSN
ON          BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id  = BTG_ALLCTN_RL_SPHS_FND_ID.sophis_fund_id
INNER JOIN  TIERS
ON          TIERS.ident                                 = BTG_ALLCTN_RL_SPHS_FND_ID.sophis_fund_id
INNER JOIN  FOLIO
ON          FOLIO.ident                                 = BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_SPHS_USR
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_SPHS_USR" ("SOPHIS_USER_ID", "VERSION", "SOPHIS_USER_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_SPHS_USR_ID.sophis_user_id
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.version
,           RISKUSERS.name AS sophis_user_name
,           BTG_ALLCTN_RL_SPHS_USR_ID.created_by
,           BTG_ALLCTN_RL_SPHS_USR_ID.created_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
FROM        BTG_ALLCTN_RL_SPHS_USR
INNER JOIN  BTG_ALLCTN_RL_SPHS_USR_ID
ON          BTG_ALLCTN_RL_SPHS_USR_ID.sophis_user_id    = BTG_ALLCTN_RL_SPHS_USR.sophis_user_id
INNER JOIN  BTG_ALLCTN_RL_SPHS_USR_VRSN
ON          BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id  = BTG_ALLCTN_RL_SPHS_USR.sophis_user_id
AND         BTG_ALLCTN_RL_SPHS_USR_VRSN.version         = BTG_ALLCTN_RL_SPHS_USR.version
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident                             = BTG_ALLCTN_RL_SPHS_USR.sophis_user_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_SPHS_USR_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_SPHS_USR_VRSN" ("SOPHIS_USER_ID", "VERSION", "SOPHIS_USER_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_SPHS_USR_ID.sophis_user_id
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.version
,           RISKUSERS.name AS sophis_user_name
,           BTG_ALLCTN_RL_SPHS_USR_ID.created_by
,           BTG_ALLCTN_RL_SPHS_USR_ID.created_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
FROM        BTG_ALLCTN_RL_SPHS_USR_ID
INNER JOIN  BTG_ALLCTN_RL_SPHS_USR_VRSN
ON          BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id  = BTG_ALLCTN_RL_SPHS_USR_ID.sophis_user_id
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident                             = BTG_ALLCTN_RL_SPHS_USR_ID.sophis_user_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_TRDR
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_TRDR" ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID", "VERSION", "SOPHIS_USER_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_TRDR_ID.allocation_rule_id
,           BTG_ALLCTN_RL_TRDR_ID.sophis_user_id
,           BTG_ALLCTN_RL_TRDR_VRSN.version
,           RISKUSERS.name AS sophis_user_name
,           BTG_ALLCTN_RL_TRDR_ID.created_by
,           BTG_ALLCTN_RL_TRDR_ID.created_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.updated_by
,           BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.deleted
FROM        BTG_ALLCTN_RL_TRDR
INNER JOIN  BTG_ALLCTN_RL_TRDR_ID
ON          BTG_ALLCTN_RL_TRDR_ID.allocation_rule_id    = BTG_ALLCTN_RL_TRDR.allocation_rule_id
AND         BTG_ALLCTN_RL_TRDR_ID.sophis_user_id        = BTG_ALLCTN_RL_TRDR.sophis_user_id
INNER JOIN  BTG_ALLCTN_RL_TRDR_VRSN
ON          BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = BTG_ALLCTN_RL_TRDR.allocation_rule_id
AND         BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = BTG_ALLCTN_RL_TRDR.sophis_user_id
AND         BTG_ALLCTN_RL_TRDR_VRSN.version             = BTG_ALLCTN_RL_TRDR.version
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident                             = BTG_ALLCTN_RL_TRDR.sophis_user_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_TRDR_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_TRDR_VRSN" ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID", "VERSION", "SOPHIS_USER_NAME", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_TRDR_ID.allocation_rule_id
,           BTG_ALLCTN_RL_TRDR_ID.sophis_user_id
,           BTG_ALLCTN_RL_TRDR_VRSN.version
,           RISKUSERS.name AS sophis_user_name
,           BTG_ALLCTN_RL_TRDR_ID.created_by
,           BTG_ALLCTN_RL_TRDR_ID.created_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.updated_by
,           BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_TRDR_VRSN.deleted
FROM        BTG_ALLCTN_RL_TRDR_ID
INNER JOIN  BTG_ALLCTN_RL_TRDR_VRSN
ON          BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = BTG_ALLCTN_RL_TRDR_ID.allocation_rule_id
AND         BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = BTG_ALLCTN_RL_TRDR_ID.sophis_user_id
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident                             = BTG_ALLCTN_RL_TRDR_ID.sophis_user_id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_USR
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_USR" ("ID", "NAME", "VERSION", "PASSWORD", "IS_ADMINISTRATOR", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_USR_ID.id
,           BTG_ALLCTN_RL_USR_ID.name
,           BTG_ALLCTN_RL_USR_VRSN.version
,           BTG_ALLCTN_RL_USR_VRSN.password
,           BTG_ALLCTN_RL_USR_VRSN.is_administrator
,           BTG_ALLCTN_RL_USR_ID.created_by
,           BTG_ALLCTN_RL_USR_ID.created_dt
,           BTG_ALLCTN_RL_USR_VRSN.updated_by
,           BTG_ALLCTN_RL_USR_VRSN.updated_dt
,           BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_USR_VRSN.deleted
FROM        BTG_ALLCTN_RL_USR
INNER JOIN  BTG_ALLCTN_RL_USR_ID
ON          BTG_ALLCTN_RL_USR_ID.id         = BTG_ALLCTN_RL_USR.id
INNER JOIN  BTG_ALLCTN_RL_USR_VRSN
ON          BTG_ALLCTN_RL_USR_VRSN.id       = BTG_ALLCTN_RL_USR.id
AND         BTG_ALLCTN_RL_USR_VRSN.version  = BTG_ALLCTN_RL_USR.version;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_USR_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_USR_VRSN" ("ID", "NAME", "VERSION", "PASSWORD", "IS_ADMINISTRATOR", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_USR_ID.id
,           BTG_ALLCTN_RL_USR_ID.name
,           BTG_ALLCTN_RL_USR_VRSN.version
,           BTG_ALLCTN_RL_USR_VRSN.password
,           BTG_ALLCTN_RL_USR_VRSN.is_administrator
,           BTG_ALLCTN_RL_USR_ID.created_by
,           BTG_ALLCTN_RL_USR_ID.created_dt
,           BTG_ALLCTN_RL_USR_VRSN.updated_by
,           BTG_ALLCTN_RL_USR_VRSN.updated_dt
,           BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_USR_VRSN.deleted
FROM        BTG_ALLCTN_RL_USR_ID
INNER JOIN  BTG_ALLCTN_RL_USR_VRSN
ON          BTG_ALLCTN_RL_USR_VRSN.id       = BTG_ALLCTN_RL_USR_ID.id;
/
--------------------------------------------------------
--  DDL for View V_BTG_ALLCTN_RL_VRSN
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "V_BTG_ALLCTN_RL_VRSN" ("ID", "VERSION", "NAME", "ACTIVE", "ACTIVE_FROM_DT", "ACTIVE_TO_DT", "CREATED_BY", "CREATED_DT", "UPDATED_BY", "UPDATED_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT", "DELETED") AS 
  SELECT      BTG_ALLCTN_RL_ID.id
,           BTG_ALLCTN_RL_VRSN.version
,           BTG_ALLCTN_RL_VRSN.name
,           BTG_ALLCTN_RL_VRSN.active
,           BTG_ALLCTN_RL_VRSN.active_from_dt
,           BTG_ALLCTN_RL_VRSN.active_to_dt
,           BTG_ALLCTN_RL_ID.created_by
,           BTG_ALLCTN_RL_ID.created_dt
,           BTG_ALLCTN_RL_VRSN.updated_by
,           BTG_ALLCTN_RL_VRSN.updated_dt
,           BTG_ALLCTN_RL_VRSN.effective_from_dt
,           BTG_ALLCTN_RL_VRSN.effective_to_dt
,           BTG_ALLCTN_RL_VRSN.deleted
FROM        BTG_ALLCTN_RL_ID
INNER JOIN  BTG_ALLCTN_RL_VRSN
ON          BTG_ALLCTN_RL_VRSN.id       = BTG_ALLCTN_RL_ID.id;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_FND_FL_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_FND_FL_ID_PK" ON "BTG_ALLCTN_RL_FND_FL_ID" ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_FND_FL_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_FND_FL_PK" ON "BTG_ALLCTN_RL_FND_FL" ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_FND_FL_VRSN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_FND_FL_VRSN_PK" ON "BTG_ALLCTN_RL_FND_FL_VRSN" ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_FND_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_FND_ID_PK" ON "BTG_ALLCTN_RL_FND_ID" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_FND_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_FND_PK" ON "BTG_ALLCTN_RL_FND" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_FND_VRSN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_FND_VRSN_PK" ON "BTG_ALLCTN_RL_FND_VRSN" ("ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_PK" ON "BTG_ALLCTN_RL" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_FND_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_FND_ID_PK" ON "BTG_ALLCTN_RL_SPHS_FND_ID" ("SOPHIS_FUND_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_FND_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_FND_PK" ON "BTG_ALLCTN_RL_SPHS_FND" ("SOPHIS_FUND_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_FND_VR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_FND_VR_PK" ON "BTG_ALLCTN_RL_SPHS_FND_VRSN" ("SOPHIS_FUND_ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_USR_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_USR_ID_PK" ON "BTG_ALLCTN_RL_SPHS_USR_ID" ("SOPHIS_USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_USR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_USR_PK" ON "BTG_ALLCTN_RL_SPHS_USR" ("SOPHIS_USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_SPHS_USR_VR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_SPHS_USR_VR_PK" ON "BTG_ALLCTN_RL_SPHS_USR_VRSN" ("SOPHIS_USER_ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_TRDR_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_TRDR_ID_PK" ON "BTG_ALLCTN_RL_TRDR_ID" ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_TRDR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_TRDR_PK" ON "BTG_ALLCTN_RL_TRDR" ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_TRDR_VRSN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_TRDR_VRSN_PK" ON "BTG_ALLCTN_RL_TRDR_VRSN" ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_USR_ID_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_USR_ID_PK" ON "BTG_ALLCTN_RL_USR_ID" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_USR_ID_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_USR_ID_UK1" ON "BTG_ALLCTN_RL_USR_ID" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_USR_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_USR_PK" ON "BTG_ALLCTN_RL_USR" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_USR_VRSN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_USR_VRSN_PK" ON "BTG_ALLCTN_RL_USR_VRSN" ("ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index BTG_ALLCTN_RL_VRSN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "BTG_ALLCTN_RL_VRSN_PK" ON "BTG_ALLCTN_RL_VRSN" ("ID", "VERSION") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  DDL for Index TABLE1_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "TABLE1_PK" ON "BTG_ALLCTN_RL_ID" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS" ;
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL" ADD CONSTRAINT "BTG_ALLCTN_RL_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL" MODIFY ("ID" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_CHCK_HSTRY
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_CHCK_HSTRY" MODIFY ("SOPHIS_TRANSACTION_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_CHCK_HSTRY" MODIFY ("EFFECTIVE_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_CHCK_HSTRY" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_CHCK_HSTRY" MODIFY ("ALLOCATION_RULE_VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND" MODIFY ("SOPHIS_FUND_ID" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND_FL
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND_FL" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_FL_PK" PRIMARY KEY ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL" MODIFY ("ALLOCATION_RULE_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL" MODIFY ("SOPHIS_FOLIO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL" MODIFY ("VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND_FL_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_FL_ID_PK" PRIMARY KEY ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_ID" MODIFY ("ALLOCATION_RULE_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_ID" MODIFY ("SOPHIS_FOLIO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND_FL_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_FL_VRSN_PK" PRIMARY KEY ("ALLOCATION_RULE_FUND_ID", "SOPHIS_FOLIO_ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("ALLOCATION_RULE_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("SOPHIS_FOLIO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("INCLUDE_EXCLUDE" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_FL_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_ID_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" MODIFY ("SOPHIS_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_FND_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_FND_VRSN_PK" PRIMARY KEY ("ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("PERCENTAGE" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_FND_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_ID" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_ID" ADD CONSTRAINT "TABLE1_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_FND
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_FND_PK" PRIMARY KEY ("SOPHIS_FUND_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND" MODIFY ("SOPHIS_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND" MODIFY ("VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_FND_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_FND_ID_PK" PRIMARY KEY ("SOPHIS_FUND_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_ID" MODIFY ("SOPHIS_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_FND_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_FND_VR_PK" PRIMARY KEY ("SOPHIS_FUND_ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("SOPHIS_FUND_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("STARTING_SOPHIS_FOLIO_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_FND_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_USR
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_USR_PK" PRIMARY KEY ("SOPHIS_USER_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR" MODIFY ("VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_USR_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_USR_ID_PK" PRIMARY KEY ("SOPHIS_USER_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_ID" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_SPHS_USR_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_SPHS_USR_VR_PK" PRIMARY KEY ("SOPHIS_USER_ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_SPHS_USR_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_TRDR
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_TRDR" ADD CONSTRAINT "BTG_ALLCTN_RL_TRDR_PK" PRIMARY KEY ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR" MODIFY ("VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_TRDR_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_TRDR_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_TRDR_ID_PK" PRIMARY KEY ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_ID" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_ID" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_TRDR_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_TRDR_VRSN_PK" PRIMARY KEY ("ALLOCATION_RULE_ID", "SOPHIS_USER_ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("ALLOCATION_RULE_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("SOPHIS_USER_ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_TRDR_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_USR
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_USR" ADD CONSTRAINT "BTG_ALLCTN_RL_USR_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_USR" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR" MODIFY ("VERSION" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_USR_ID
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_USR_ID_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" ADD CONSTRAINT "BTG_ALLCTN_RL_USR_ID_UK1" UNIQUE ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" MODIFY ("NAME" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" MODIFY ("CREATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_ID" MODIFY ("CREATED_DT" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_USR_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_USR_VRSN_PK" PRIMARY KEY ("ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("PASSWORD" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("IS_ADMINISTRATOR" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("UPDATED_BY" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("UPDATED_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("EFFECTIVE_FROM_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("EFFECTIVE_TO_DT" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_USR_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/
--------------------------------------------------------
--  Constraints for Table BTG_ALLCTN_RL_VRSN
--------------------------------------------------------

  ALTER TABLE "BTG_ALLCTN_RL_VRSN" ADD CONSTRAINT "BTG_ALLCTN_RL_VRSN_PK" PRIMARY KEY ("ID", "VERSION")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT)
  TABLESPACE "USERS"  ENABLE;
 
  ALTER TABLE "BTG_ALLCTN_RL_VRSN" MODIFY ("ID" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_VRSN" MODIFY ("VERSION" NOT NULL ENABLE);
 
  ALTER TABLE "BTG_ALLCTN_RL_VRSN" MODIFY ("DELETED" NOT NULL ENABLE);
/

--------------------------------------------------------
--  DDL for Function BTG_ALLCTN_RL_FL_IN_HRRCHY
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BTG_ALLCTN_RL_FL_IN_HRRCHY" (p_starting_folio_id IN FOLIO.ident%type, p_folio_id IN FOLIO.ident%type)
RETURN NUMBER
IS
  l_exists NUMBER;
BEGIN

  SELECT      COUNT(*)
  INTO        l_exists
  FROM        FOLIO
  WHERE       FOLIO.ident   = p_folio_id          -- sophis_folio_id of a transaction
  START WITH  FOLIO.ident   = p_starting_folio_id -- sophis_folio_id of a rule
  CONNECT BY  FOLIO.mgr     = prior FOLIO.ident;

  RETURN l_exists;

END BTG_ALLCTN_RL_FL_IN_HRRCHY;

/

/
--------------------------------------------------------
--  DDL for Package PCKG_BTG_ALLOCATION
------------
--------------------------------------------

create or replace
PACKAGE PCKG_BTG_ALLOCATION
AS

  -- ***************************************************************************
	-- Constant variables
	-- ***************************************************************************
  
  RULE_IS_MATCHED   EXCEPTION;
  
  EOT                               CONSTANT TIMESTAMP    := TO_DATE( '31-Dec-9999 23:59:59', 'DD-MON-YYYY HH24:MI:SS' );
  
  -- ***************************************************************************
	-- Types
	-- ***************************************************************************
  
  TYPE T_CURSOR                     IS REF CURSOR;
   
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundsForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFoliosForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUsersForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFolios
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
  , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_FND.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
  , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFunds
  (
    p_cursor                    OUT           T_CURSOR  
  );

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundVersions
  (
    p_cursor                    OUT           T_CURSOR  
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_USR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUsers
  (
    p_cursor                    OUT           T_CURSOR  
  );

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewUser
  (
    p_id                        OUT           V_BTG_ALLCTN_RL_USR.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
  , p_created_by                IN            V_BTG_ALLCTN_RL_USR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_USR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveUser
  (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveUser
  (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUsers
  (
    p_cursor                    OUT           T_CURSOR  
  );

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_USR_VRSN.id%type
  );
    
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewAllocationRule
  (
    p_id                        OUT           V_BTG_ALLCTN_RL.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL.name%type
  , p_active                    IN            V_BTG_ALLCTN_RL.active%type
  , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
  , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
  , p_created_by                IN            V_BTG_ALLCTN_RL.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveAllocationRule
  (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL.name%type
  , p_active                    IN            V_BTG_ALLCTN_RL.active%type
  , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
  , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveAllocationRule
  (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRules
  (
    p_cursor                    OUT           T_CURSOR  
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRules
  (
    p_cursor                    OUT           T_CURSOR  
  , p_active_dt                 IN            V_BTG_ALLCTN_RL.active_from_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRuleVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_VRSN.id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_TRDR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_TRDR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraders
  (
    p_cursor                    OUT           T_CURSOR
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraders
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraderVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraderVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewFund
  (
    p_id                        OUT           V_BTG_ALLCTN_RL_FND.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_FND.sophis_fund_id%type
  , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveFund
  (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type  
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type  
  , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveFund
  (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFunds
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_FND_VRSN.id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND_FL.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolios
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolioVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id%type
  );
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolioVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude%type
  );
    
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************  
  FUNCTION CheckUserCredentials
  (
    p_name                    IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_id                      OUT           V_BTG_ALLCTN_RL_USR.id%type
  , p_is_administrator        OUT           CHAR
  )
  RETURN CHAR; -- Returns 'Y' or 'N'
    
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  FUNCTION CheckAllocationRule
  (
    p_block_refcon            IN            HISTOMVTS.refcon%TYPE
  )
  RETURN CHAR; -- Returns 'Y' or 'N'

END PCKG_BTG_ALLOCATION;

/

create or replace
PACKAGE BODY PCKG_BTG_ALLOCATION 
AS

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundsForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    CLIENTS.ident   AS ID
      ,         CLIENTS.libelle AS NAME 
      FROM      CLIENTS 
      ORDER BY  LOWER(CLIENTS.libelle);
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  FUNCTION IsRuleMatched
  (
    p_id                      IN            V_BTG_ALLCTN_RL.id%type
  )
  RETURN CHAR
  AS
  
    l_matched CHAR(1);
    
  BEGIN
      
    SELECT COALESCE((SELECT 'Y' FROM DUAL WHERE EXISTS (SELECT * FROM BTG_ALLCTN_RL_CHCK_HSTRY WHERE BTG_ALLCTN_RL_CHCK_HSTRY.allocation_rule_id = p_id)), 'N')
    INTO l_matched
    FROM DUAL;
          
    return l_matched;
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFoliosForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      FOLIO.ident AS ID
      ,           FOLIO.name
      ,           FOLIO.mgr   AS PARENT_ID
      ,           LEVEL       AS LVL
      FROM        FOLIO
      WHERE       LEVEL         > 1
      START WITH  FOLIO.ident   = 1
      CONNECT BY  FOLIO.mgr     = prior FOLIO.ident;
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUsersForSelection
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    RISKUSERS.ident AS ID
      ,         RISKUSERS.name                
      FROM      RISKUSERS
      ORDER BY  RISKUSERS.name;
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFolios
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  )
  AS
  
    l_starting_sophis_folio_id V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type;
  
  BEGIN
  
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id
    INTO        l_starting_sophis_folio_id
    FROM        V_BTG_ALLCTN_RL_SPHS_FND
    WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
    
    OPEN p_cursor FOR
      SELECT      FOLIO.ident AS ID
      ,           FOLIO.name
      ,           FOLIO.mgr   AS PARENT_ID
      ,           LEVEL       AS LVL
      FROM        FOLIO
      WHERE       LEVEL         > 1
      START WITH  FOLIO.ident   = l_starting_sophis_folio_id
      CONNECT BY  FOLIO.mgr     = prior FOLIO.ident;
      
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN
    
      raise_application_error(-20011, 'Starting Sophis Folio ID does not exist.');
      
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
  , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_FND.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;
  
  BEGIN
        
    BEGIN
    
      -- see if record already exists
    
      SELECT    V_BTG_ALLCTN_RL_SPHS_FND.*
      INTO      l_btg_allctn_rl_sphs_fnd
      FROM      V_BTG_ALLCTN_RL_SPHS_FND
      WHERE     V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
      
      p_created_by := l_btg_allctn_rl_sphs_fnd.created_by;
      p_created_dt := l_btg_allctn_rl_sphs_fnd.created_dt;
      
      SaveSophisFund
      (
        p_sophis_fund_id
      , p_version
      , p_starting_sophis_folio_id
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      );
    
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
      
        SAVEPOINT new_member;
      
        -- set versioning information
        
        p_version           := 1;    
        p_created_dt        := SYSTIMESTAMP;   
        p_updated_dt        := p_created_dt;
        p_effective_from_dt := p_created_dt;      
        p_effective_to_dt   := EOT;
        
        -- create new ID
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_FND_ID
        (
          sophis_fund_id         
        , created_by
        , created_dt
        )
        VALUES
        (
          p_sophis_fund_id    
        , p_created_by
        , p_created_dt
        );
        
        -- create new version
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
        (
          sophis_fund_id
        , version     
        , starting_sophis_folio_id
        , updated_by
        , updated_dt
        , effective_from_dt
        , effective_to_dt
        , deleted
        )
        VALUES
        (
          p_sophis_fund_id
        , p_version       
        , p_starting_sophis_folio_id
        , p_updated_by
        , p_updated_dt
        , p_effective_from_dt
        , p_effective_to_dt
        , 'N'
        );
        
        -- make new version active record
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_FND
        (
          sophis_fund_id
        , version
        )
        VALUES
        (
          p_sophis_fund_id
        , p_version
        );
        
        COMMIT;
    
    END;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
  , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND.*      
    INTO        l_btg_allctn_rl_sphs_fnd
    FROM        V_BTG_ALLCTN_RL_SPHS_FND
    WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_SPHS_FND_VRSN
    SET     BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt  = p_updated_dt
    WHERE   BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id   = p_sophis_fund_id
    AND     BTG_ALLCTN_RL_SPHS_FND_VRSN.version          = l_btg_allctn_rl_sphs_fnd.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_sphs_fnd.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
    (
      sophis_fund_id
    , version    
    , starting_sophis_folio_id
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_sophis_fund_id
    , p_version  
    , p_starting_sophis_folio_id
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_SPHS_FND
    SET     BTG_ALLCTN_RL_SPHS_FND.version        = p_version
    WHERE   BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;    
    
    COMMIT;
    
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
      
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveSophisFund
  (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
  )
  AS
  
    l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;
  
  BEGIN
    
    SAVEPOINT new_member;
    
    -- get latest version
  
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND.*      
    INTO        l_btg_allctn_rl_sphs_fnd
    FROM        V_BTG_ALLCTN_RL_SPHS_FND
    WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
    
    -- set versioning information

    l_btg_allctn_rl_sphs_fnd.updated_dt         := SYSTIMESTAMP;
    l_btg_allctn_rl_sphs_fnd.effective_from_dt  := l_btg_allctn_rl_sphs_fnd.updated_dt;      
    l_btg_allctn_rl_sphs_fnd.effective_to_dt    := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_SPHS_FND_VRSN
    SET     BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt  = l_btg_allctn_rl_sphs_fnd.updated_dt
    WHERE   BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id   = p_sophis_fund_id
    AND     BTG_ALLCTN_RL_SPHS_FND_VRSN.version          = l_btg_allctn_rl_sphs_fnd.version;
    
    -- create new version
    
    l_btg_allctn_rl_sphs_fnd.version := l_btg_allctn_rl_sphs_fnd.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
    (
      sophis_fund_id
    , version       
    , starting_sophis_folio_id
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_sophis_fund_id
    , l_btg_allctn_rl_sphs_fnd.version      
    , l_btg_allctn_rl_sphs_fnd.starting_sophis_folio_id
    , p_updated_by
    , l_btg_allctn_rl_sphs_fnd.updated_dt
    , l_btg_allctn_rl_sphs_fnd.effective_from_dt
    , l_btg_allctn_rl_sphs_fnd.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_SPHS_FND
    SET     BTG_ALLCTN_RL_SPHS_FND.version        = l_btg_allctn_rl_sphs_fnd.version
    WHERE   BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
    
    COMMIT;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFunds
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id
      ,           V_BTG_ALLCTN_RL_SPHS_FND.version      
      ,           V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id
      ,           V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_FND      
      WHERE       V_BTG_ALLCTN_RL_SPHS_FND.deleted = 'N'
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_name;
    
  END;

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id      
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version       
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_FND_VRSN      
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt; 
    
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id%type
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id      
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version       
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_name
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_FND_VRSN      
      WHERE       V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id = p_sophis_fund_id
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version; 
    
  END;  

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_USR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;
  
  BEGIN
  
    BEGIN
    
      -- see if record already exists
      
      SELECT  V_BTG_ALLCTN_RL_SPHS_USR.*      
      INTO    l_btg_allctn_rl_sphs_usr
      FROM    V_BTG_ALLCTN_RL_SPHS_USR
      WHERE   V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
      
      p_created_by := l_btg_allctn_rl_sphs_usr.created_by;
      p_created_dt := l_btg_allctn_rl_sphs_usr.created_dt;
      
      SaveSophisUser
      (
        p_sophis_user_id
      , p_version
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      );
      
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
      
        SAVEPOINT new_member;
      
        -- set versioning information
        
        p_version           := 1;    
        p_created_dt        := SYSTIMESTAMP;   
        p_updated_dt        := p_created_dt;
        p_effective_from_dt := p_created_dt;      
        p_effective_to_dt   := EOT;
        
        -- create new ID
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_USR_ID
        (
          sophis_user_id      
        , created_by
        , created_dt
        )
        VALUES
        (
          p_sophis_user_id    
        , p_created_by
        , p_created_dt
        );
        
        -- create new version
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
        (
          sophis_user_id
        , version            
        , updated_by
        , updated_dt
        , effective_from_dt
        , effective_to_dt
        , deleted
        )
        VALUES
        (
          p_sophis_user_id
        , p_version          
        , p_updated_by
        , p_updated_dt
        , p_effective_from_dt
        , p_effective_to_dt
        , 'N'
        );
        
        -- make new version active record
        
        INSERT INTO BTG_ALLCTN_RL_SPHS_USR
        (
          sophis_user_id
        , version
        )
        VALUES
        (
          p_sophis_user_id
        , p_version
        );
          
        COMMIT;
    
    END;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_SPHS_USR.*      
    INTO        l_btg_allctn_rl_sphs_usr
    FROM        V_BTG_ALLCTN_RL_SPHS_USR
    WHERE       V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_SPHS_USR_VRSN
    SET     BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt  = p_updated_dt
    WHERE   BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id   = p_sophis_user_id
    AND     BTG_ALLCTN_RL_SPHS_USR_VRSN.version          = l_btg_allctn_rl_sphs_usr.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_sphs_usr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
    (
      sophis_user_id
    , version            
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_sophis_user_id
    , p_version            
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_SPHS_USR
    SET     BTG_ALLCTN_RL_SPHS_USR.version        = p_version
    WHERE   BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;    
    
    COMMIT;
    
   EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveSophisUser
  (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
  )
  AS
  
    l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
  
    SELECT      V_BTG_ALLCTN_RL_SPHS_USR.*      
    INTO        l_btg_allctn_rl_sphs_usr
    FROM        V_BTG_ALLCTN_RL_SPHS_USR
    WHERE       V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
    
    -- set versioning information

    l_btg_allctn_rl_sphs_usr.updated_dt         := SYSTIMESTAMP;
    l_btg_allctn_rl_sphs_usr.effective_from_dt  := l_btg_allctn_rl_sphs_usr.updated_dt;      
    l_btg_allctn_rl_sphs_usr.effective_to_dt    := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_SPHS_USR_VRSN
    SET     BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt  = l_btg_allctn_rl_sphs_usr.updated_dt
    WHERE   BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id   = p_sophis_user_id
    AND     BTG_ALLCTN_RL_SPHS_USR_VRSN.version          = l_btg_allctn_rl_sphs_usr.version;
    
    -- create new version
    
    l_btg_allctn_rl_sphs_usr.version := l_btg_allctn_rl_sphs_usr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
    (
      sophis_user_id
    , version            
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_sophis_user_id
    , l_btg_allctn_rl_sphs_usr.version      
    , p_updated_by
    , l_btg_allctn_rl_sphs_usr.updated_dt
    , l_btg_allctn_rl_sphs_usr.effective_from_dt
    , l_btg_allctn_rl_sphs_usr.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_SPHS_USR
    SET     BTG_ALLCTN_RL_SPHS_USR.version        = l_btg_allctn_rl_sphs_usr.version
    WHERE   BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
    
    COMMIT;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUsers
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_SPHS_USR.version       
      ,           V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_name
      ,           V_BTG_ALLCTN_RL_SPHS_USR.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_USR      
      WHERE       V_BTG_ALLCTN_RL_SPHS_USR.deleted = 'N'
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_name;    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version       
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_name
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_USR_VRSN      
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt; 
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetSophisUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version       
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_name
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_SPHS_USR_VRSN      
      WHERE       V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id = p_sophis_user_id
      ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version; 
  
  END;

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewUser
  (
    p_id                        OUT           V_BTG_ALLCTN_RL_USR.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
  , p_created_by                IN            V_BTG_ALLCTN_RL_USR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_USR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
  )
  AS
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get new sequence number
  
    SELECT  BTG_ALLCTN_RL_USR_ID_SEQ.nextval
    INTO    p_id
    FROM    DUAL;
    
    -- set versioning information
    
    p_version           := 1;    
    p_created_dt        := SYSTIMESTAMP;   
    p_updated_dt        := p_created_dt;
    p_effective_from_dt := p_created_dt;      
    p_effective_to_dt   := EOT;
    
    -- create new ID
    
    INSERT INTO BTG_ALLCTN_RL_USR_ID
    (
      id
    , name
    , created_by
    , created_dt
    )
    VALUES
    (
      p_id
    , p_name
    , p_created_by
    , p_created_dt
    );
    
    -- create new version
    
    INSERT INTO BTG_ALLCTN_RL_USR_VRSN
    (
      id
    , version      
    , password
    , is_administrator      
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version
    , p_password
    , p_is_administrator      
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    INSERT INTO BTG_ALLCTN_RL_USR
    (
      id
    , version
    )
    VALUES
    (
      p_id
    , p_version
    );
    
    COMMIT;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveUser
  (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_usr V_BTG_ALLCTN_RL_USR%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_USR.*      
    INTO        l_btg_allctn_rl_usr
    FROM        V_BTG_ALLCTN_RL_USR
    WHERE       V_BTG_ALLCTN_RL_USR.id = p_id;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_USR_VRSN
    SET     BTG_ALLCTN_RL_USR_VRSN.effective_to_dt  = p_updated_dt
    WHERE   BTG_ALLCTN_RL_USR_VRSN.id               = p_id
    AND     BTG_ALLCTN_RL_USR_VRSN.version          = l_btg_allctn_rl_usr.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_usr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_USR_VRSN
    (
      id
    , version      
    , password
    , is_administrator      
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version      
    , p_password
    , p_is_administrator      
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_USR
    SET     BTG_ALLCTN_RL_USR.version = p_version
    WHERE   BTG_ALLCTN_RL_USR.id      = p_id;    
    
    COMMIT;
    
   EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveUser
  (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
  )
  AS
  
    l_btg_allctn_rl_usr V_BTG_ALLCTN_RL_USR%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
  
    SELECT      V_BTG_ALLCTN_RL_USR.*      
    INTO        l_btg_allctn_rl_usr
    FROM        V_BTG_ALLCTN_RL_USR
    WHERE       V_BTG_ALLCTN_RL_USR.id = p_id;
    
    -- set versioning information

    l_btg_allctn_rl_usr.updated_dt        := SYSTIMESTAMP;
    l_btg_allctn_rl_usr.effective_from_dt := l_btg_allctn_rl_usr.updated_dt;      
    l_btg_allctn_rl_usr.effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_USR_VRSN
    SET     BTG_ALLCTN_RL_USR_VRSN.effective_to_dt  = l_btg_allctn_rl_usr.updated_dt
    WHERE   BTG_ALLCTN_RL_USR_VRSN.id               = p_id
    AND     BTG_ALLCTN_RL_USR_VRSN.version          = l_btg_allctn_rl_usr.version;
    
    -- create new version
    
    l_btg_allctn_rl_usr.version := l_btg_allctn_rl_usr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_USR_VRSN
    (
      id
    , version      
    , password
    , is_administrator      
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , l_btg_allctn_rl_usr.version
    , l_btg_allctn_rl_usr.password
    , l_btg_allctn_rl_usr.is_administrator        
    , p_updated_by
    , l_btg_allctn_rl_usr.updated_dt
    , l_btg_allctn_rl_usr.effective_from_dt
    , l_btg_allctn_rl_usr.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_USR
    SET     BTG_ALLCTN_RL_USR.version = l_btg_allctn_rl_usr.version
    WHERE   BTG_ALLCTN_RL_USR.id      = p_id;
    
    COMMIT;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUsers
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_USR.id
      ,           V_BTG_ALLCTN_RL_USR.version
      ,           V_BTG_ALLCTN_RL_USR.name
      ,           V_BTG_ALLCTN_RL_USR.password
      ,           V_BTG_ALLCTN_RL_USR.is_administrator      
      ,           V_BTG_ALLCTN_RL_USR.created_by
      ,           V_BTG_ALLCTN_RL_USR.created_dt
      ,           V_BTG_ALLCTN_RL_USR.updated_by
      ,           V_BTG_ALLCTN_RL_USR.updated_dt
      ,           V_BTG_ALLCTN_RL_USR.effective_from_dt
      ,           V_BTG_ALLCTN_RL_USR.effective_to_dt
      ,           V_BTG_ALLCTN_RL_USR.deleted
      FROM        V_BTG_ALLCTN_RL_USR
      WHERE       V_BTG_ALLCTN_RL_USR.deleted  = 'N'
      ORDER BY    V_BTG_ALLCTN_RL_USR.name;      
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUserVersions
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_USR_VRSN.id
      ,           V_BTG_ALLCTN_RL_USR_VRSN.version
      ,           V_BTG_ALLCTN_RL_USR_VRSN.name
      ,           V_BTG_ALLCTN_RL_USR_VRSN.password
      ,           V_BTG_ALLCTN_RL_USR_VRSN.is_administrator      
      ,           V_BTG_ALLCTN_RL_USR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_USR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_USR_VRSN
      ORDER BY    V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt; 
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetUserVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_USR_VRSN.id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_USR_VRSN.id
      ,           V_BTG_ALLCTN_RL_USR_VRSN.version
      ,           V_BTG_ALLCTN_RL_USR_VRSN.name
      ,           V_BTG_ALLCTN_RL_USR_VRSN.password
      ,           V_BTG_ALLCTN_RL_USR_VRSN.is_administrator      
      ,           V_BTG_ALLCTN_RL_USR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_USR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_USR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_USR_VRSN
      WHERE       V_BTG_ALLCTN_RL_USR_VRSN.id   = p_id
      ORDER BY    V_BTG_ALLCTN_RL_USR_VRSN.version; 
  
  END;

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewAllocationRule
  (
    p_id                        OUT           V_BTG_ALLCTN_RL.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL.name%type
  , p_active                    IN            V_BTG_ALLCTN_RL.active%type
  , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
  , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
  , p_created_by                IN            V_BTG_ALLCTN_RL.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
  )
  AS
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get new sequence number
  
    SELECT  BTG_ALLCTN_RL_ID_SEQ.nextval
    INTO    p_id
    FROM    DUAL;
    
    -- set versioning information
    
    p_version           := 1;    
    p_created_dt        := SYSTIMESTAMP;   
    p_updated_dt        := p_created_dt;
    p_effective_from_dt := p_created_dt;      
    p_effective_to_dt   := EOT;
    
    -- create new ID
    
    INSERT INTO BTG_ALLCTN_RL_ID
    (
      id
    , created_by
    , created_dt
    )
    VALUES
    (
      p_id
    , p_created_by
    , p_created_dt
    );
    
    -- create new version
    
    INSERT INTO BTG_ALLCTN_RL_VRSN
    (
      id
    , version
    , name
    , active
    , active_from_dt
    , active_to_dt
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version
    , p_name
    , p_active
    , p_active_from_dt
    , p_active_to_dt      
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    INSERT INTO BTG_ALLCTN_RL
    (
      id
    , version
    )
    VALUES
    (
      p_id
    , p_version
    );
    
    COMMIT;
  
  EXCEPTION
  
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveAllocationRule
  (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
  , p_name                      IN            V_BTG_ALLCTN_RL.name%type
  , p_active                    IN            V_BTG_ALLCTN_RL.active%type
  , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
  , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl V_BTG_ALLCTN_RL%rowtype;
    
  BEGIN
    
    SAVEPOINT new_member;
        
    -- get latest version
      
    SELECT      V_BTG_ALLCTN_RL.*      
    INTO        l_btg_allctn_rl
    FROM        V_BTG_ALLCTN_RL
    WHERE       V_BTG_ALLCTN_RL.id = p_id;
        
    -- check if rule has been matched
    IF ((l_btg_allctn_rl.name != p_name OR l_btg_allctn_rl.active != p_active OR l_btg_allctn_rl.active_from_dt != p_active_from_dt) AND 'Y' = IsRuleMatched(p_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_VRSN
    SET     BTG_ALLCTN_RL_VRSN.effective_to_dt  = p_updated_dt
    WHERE   BTG_ALLCTN_RL_VRSN.id               = p_id
    AND     BTG_ALLCTN_RL_VRSN.version          = l_btg_allctn_rl.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_VRSN
    (
      id
    , version
    , name
    , active
    , active_from_dt
    , active_to_dt
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version
    , p_name
    , p_active
    , p_active_from_dt
    , p_active_to_dt      
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL
    SET     BTG_ALLCTN_RL.version = p_version
    WHERE   BTG_ALLCTN_RL.id      = p_id;    
    
    COMMIT;
    
   EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      ROLLBACK TO new_member;
       
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveAllocationRule
  (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
  )
  AS
  
    l_btg_allctn_rl V_BTG_ALLCTN_RL%rowtype;
  
  BEGIN
    
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(p_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
  
    SAVEPOINT new_member;
    
    -- get latest version
  
    SELECT      V_BTG_ALLCTN_RL.*      
    INTO        l_btg_allctn_rl
    FROM        V_BTG_ALLCTN_RL
    WHERE       V_BTG_ALLCTN_RL.id = p_id;
    
    -- set versioning information

    l_btg_allctn_rl.updated_dt        := SYSTIMESTAMP;
    l_btg_allctn_rl.effective_from_dt := l_btg_allctn_rl.updated_dt;      
    l_btg_allctn_rl.effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_VRSN
    SET     BTG_ALLCTN_RL_VRSN.effective_to_dt  = l_btg_allctn_rl.updated_dt
    WHERE   BTG_ALLCTN_RL_VRSN.id               = p_id
    AND     BTG_ALLCTN_RL_VRSN.version          = l_btg_allctn_rl.version;
    
    -- create new version
    
    l_btg_allctn_rl.version := l_btg_allctn_rl.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_VRSN
    (
      id
    , version
    , name
    , active
    , active_from_dt
    , active_to_dt
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , l_btg_allctn_rl.version
    , l_btg_allctn_rl.name
    , l_btg_allctn_rl.active
    , l_btg_allctn_rl.active_from_dt
    , l_btg_allctn_rl.active_to_dt      
    , p_updated_by
    , l_btg_allctn_rl.updated_dt
    , l_btg_allctn_rl.effective_from_dt
    , l_btg_allctn_rl.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL
    SET     BTG_ALLCTN_RL.version = l_btg_allctn_rl.version
    WHERE   BTG_ALLCTN_RL.id      = p_id;
    
    COMMIT;
  
  EXCEPTION
    
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRules
  (
    p_cursor                    OUT           T_CURSOR  
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL.id
      ,           V_BTG_ALLCTN_RL.version
      ,           V_BTG_ALLCTN_RL.name
      ,           V_BTG_ALLCTN_RL.active
      ,           V_BTG_ALLCTN_RL.active_from_dt
      ,           V_BTG_ALLCTN_RL.active_to_dt
      ,           V_BTG_ALLCTN_RL.created_by
      ,           V_BTG_ALLCTN_RL.created_dt
      ,           V_BTG_ALLCTN_RL.updated_by
      ,           V_BTG_ALLCTN_RL.updated_dt
      ,           V_BTG_ALLCTN_RL.effective_from_dt
      ,           V_BTG_ALLCTN_RL.effective_to_dt
      ,           V_BTG_ALLCTN_RL.deleted
      ,           V_BTG_ALLCTN_RL.matched
      FROM        V_BTG_ALLCTN_RL
      WHERE       V_BTG_ALLCTN_RL.deleted  = 'N'
      ORDER BY    V_BTG_ALLCTN_RL.name;      
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRules
  (
    p_cursor                    OUT           T_CURSOR  
  , p_active_dt                 IN            V_BTG_ALLCTN_RL.active_from_dt%type    
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL.id
      ,           V_BTG_ALLCTN_RL.version
      ,           V_BTG_ALLCTN_RL.name
      ,           V_BTG_ALLCTN_RL.active
      ,           V_BTG_ALLCTN_RL.active_from_dt
      ,           V_BTG_ALLCTN_RL.active_to_dt
      ,           V_BTG_ALLCTN_RL.created_by,           V_BTG_ALLCTN_RL.created_dt
      ,           V_BTG_ALLCTN_RL.updated_by
      ,           V_BTG_ALLCTN_RL.updated_dt
      ,           V_BTG_ALLCTN_RL.effective_from_dt
      ,           V_BTG_ALLCTN_RL.effective_to_dt
      ,           V_BTG_ALLCTN_RL.deleted
      ,           V_BTG_ALLCTN_RL.matched
      FROM        V_BTG_ALLCTN_RL
      WHERE       V_BTG_ALLCTN_RL.deleted  = 'N'
      AND         p_active_dt BETWEEN V_BTG_ALLCTN_RL.active_from_dt AND V_BTG_ALLCTN_RL.active_to_dt
      ORDER BY    V_BTG_ALLCTN_RL.name;      
  
  END;
  
  
  
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetAllocationRuleVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_VRSN.id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_VRSN.id
      ,           V_BTG_ALLCTN_RL_VRSN.version
      ,           V_BTG_ALLCTN_RL_VRSN.name
      ,           V_BTG_ALLCTN_RL_VRSN.active
      ,           V_BTG_ALLCTN_RL_VRSN.active_from_dt
      ,           V_BTG_ALLCTN_RL_VRSN.active_to_dt
      ,           V_BTG_ALLCTN_RL_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_VRSN      
      WHERE       V_BTG_ALLCTN_RL_VRSN.id = p_id
      ORDER BY    V_BTG_ALLCTN_RL_VRSN.version; 
  
  END;
  
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_TRDR.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_TRDR.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;
  
  BEGIN
    
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
  
    BEGIN
      
      -- see if record already exists
      
      SELECT  V_BTG_ALLCTN_RL_TRDR.*      
      INTO    l_btg_allctn_rl_trdr
      FROM    V_BTG_ALLCTN_RL_TRDR
      WHERE   V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
      AND     V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
      
      p_created_by := l_btg_allctn_rl_trdr.created_by;
      p_created_dt := l_btg_allctn_rl_trdr.created_dt;
      
      SaveTrader
      (
        p_allocation_rule_id
      , p_sophis_user_id
      , p_version
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      );
      
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
  
        SAVEPOINT new_member;      
        
        -- set versioning information
        
        p_version           := 1;    
        p_created_dt        := SYSTIMESTAMP;   
        p_updated_dt        := p_created_dt;
        p_effective_from_dt := p_created_dt;      
        p_effective_to_dt   := EOT;
        
        -- create new ID
        
        INSERT INTO BTG_ALLCTN_RL_TRDR_ID
        (
          allocation_rule_id
        , sophis_user_id
        , created_by
        , created_dt
        )
        VALUES
        (
          p_allocation_rule_id
        , p_sophis_user_id
        , p_created_by
        , p_created_dt
        );
        
        -- create new version
        
        INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
        (
          allocation_rule_id
        , sophis_user_id
        , version      
        , updated_by
        , updated_dt
        , effective_from_dt
        , effective_to_dt
        , deleted
        )
        VALUES
        (
          p_allocation_rule_id
        , p_sophis_user_id
        , p_version      
        , p_updated_by
        , p_updated_dt
        , p_effective_from_dt
        , p_effective_to_dt
        , 'N'
        );
        
        -- make new version active record
        
        INSERT INTO BTG_ALLCTN_RL_TRDR
        (
          allocation_rule_id
        , sophis_user_id
        , version
        )
        VALUES
        (
          p_allocation_rule_id
        , p_sophis_user_id
        , p_version
        );
      
        COMMIT;
    
    END;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
    
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;
  
  BEGIN
  
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    SAVEPOINT new_member;

    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_TRDR.*
    INTO        l_btg_allctn_rl_trdr
    FROM        V_BTG_ALLCTN_RL_TRDR
    WHERE       V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
    AND         V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_TRDR_VRSN
    SET     BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt     = p_updated_dt
    WHERE   BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
    AND     BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
    AND     BTG_ALLCTN_RL_TRDR_VRSN.version             = l_btg_allctn_rl_trdr.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_trdr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
    (
      allocation_rule_id
    , sophis_user_id
    , version      
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_allocation_rule_id
    , p_sophis_user_id
    , p_version      
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_TRDR
    SET     BTG_ALLCTN_RL_TRDR.version              = p_version
    WHERE   BTG_ALLCTN_RL_TRDR.allocation_rule_id   = p_allocation_rule_id
    AND     BTG_ALLCTN_RL_TRDR.sophis_user_id       = p_sophis_user_id;    
    
    COMMIT;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveTrader
  (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
  )
  AS
  
    l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;
  
  BEGIN
      
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_TRDR.*
    INTO        l_btg_allctn_rl_trdr
    FROM        V_BTG_ALLCTN_RL_TRDR
    WHERE       V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
    AND         V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
    
    -- set versioning information
                
    l_btg_allctn_rl_trdr.updated_dt         := SYSTIMESTAMP;
    l_btg_allctn_rl_trdr.effective_from_dt  := l_btg_allctn_rl_trdr.updated_dt;      
    l_btg_allctn_rl_trdr.effective_to_dt    := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_TRDR_VRSN
    SET     BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt     = l_btg_allctn_rl_trdr.updated_dt
    WHERE   BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
    AND     BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
    AND     BTG_ALLCTN_RL_TRDR_VRSN.version             = l_btg_allctn_rl_trdr.version;
    
    -- create new version
    
    l_btg_allctn_rl_trdr.version := l_btg_allctn_rl_trdr.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
    (
      allocation_rule_id
    , sophis_user_id
    , version      
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_allocation_rule_id
    , p_sophis_user_id
    , l_btg_allctn_rl_trdr.version      
    , p_updated_by
    , l_btg_allctn_rl_trdr.updated_dt
    , l_btg_allctn_rl_trdr.effective_from_dt
    , l_btg_allctn_rl_trdr.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_TRDR
    SET     BTG_ALLCTN_RL_TRDR.version              = l_btg_allctn_rl_trdr.version
    WHERE   BTG_ALLCTN_RL_TRDR.allocation_rule_id   = p_allocation_rule_id
    AND     BTG_ALLCTN_RL_TRDR.sophis_user_id       = p_sophis_user_id;    
    
    COMMIT;
  
  EXCEPTION

    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraders
  (
    p_cursor                    OUT           T_CURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_TRDR.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_TRDR.version     
      ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_name
      ,           V_BTG_ALLCTN_RL_TRDR.created_by
      ,           V_BTG_ALLCTN_RL_TRDR.created_dt
      ,           V_BTG_ALLCTN_RL_TRDR.updated_by
      ,           V_BTG_ALLCTN_RL_TRDR.updated_dt
      ,           V_BTG_ALLCTN_RL_TRDR.effective_from_dt
      ,           V_BTG_ALLCTN_RL_TRDR.effective_to_dt
      ,           V_BTG_ALLCTN_RL_TRDR.deleted
      FROM        V_BTG_ALLCTN_RL_TRDR
      INNER JOIN  V_BTG_ALLCTN_RL
      ON          V_BTG_ALLCTN_RL.id            = V_BTG_ALLCTN_RL_TRDR.allocation_rule_id      
      AND         V_BTG_ALLCTN_RL.deleted       = 'N'      
      WHERE       V_BTG_ALLCTN_RL_TRDR.deleted  = 'N'
      ORDER BY    V_BTG_ALLCTN_RL_TRDR.sophis_user_name;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraders
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_TRDR.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_TRDR.version     
      ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_name
      ,           V_BTG_ALLCTN_RL_TRDR.created_by
      ,           V_BTG_ALLCTN_RL_TRDR.created_dt
      ,           V_BTG_ALLCTN_RL_TRDR.updated_by
      ,           V_BTG_ALLCTN_RL_TRDR.updated_dt
      ,           V_BTG_ALLCTN_RL_TRDR.effective_from_dt
      ,           V_BTG_ALLCTN_RL_TRDR.effective_to_dt
      ,           V_BTG_ALLCTN_RL_TRDR.deleted
      FROM        V_BTG_ALLCTN_RL_TRDR
      INNER JOIN  V_BTG_ALLCTN_RL
      ON          V_BTG_ALLCTN_RL.id                      = V_BTG_ALLCTN_RL_TRDR.allocation_rule_id      
      AND         V_BTG_ALLCTN_RL.deleted                 = 'N'      
      WHERE       V_BTG_ALLCTN_RL_TRDR.deleted            = 'N'
      AND         V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
      ORDER BY    V_BTG_ALLCTN_RL_TRDR.sophis_user_name;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraderVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
  , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.version     
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_name
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_TRDR_VRSN
      WHERE       V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
      AND         V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
      ORDER BY    V_BTG_ALLCTN_RL_TRDR_VRSN.version;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetTraderVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.version     
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_name
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_TRDR_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_TRDR_VRSN      
      WHERE       V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id = p_allocation_rule_id
      ORDER BY    V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewFund
  (
    p_id                        OUT           V_BTG_ALLCTN_RL_FND.id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
  , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_FND.sophis_fund_id%type
  , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
  )
  AS
  BEGIN
  
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    SAVEPOINT new_member;    
        
    -- get new sequence number

    SELECT  BTG_ALLCTN_RL_FND_ID_SEQ.nextval
    INTO    p_id
    FROM    DUAL;
    
    -- set versioning information
    
    p_version           := 1;    
    p_created_dt        := SYSTIMESTAMP;   
    p_updated_dt        := p_created_dt;
    p_effective_from_dt := p_created_dt;      
    p_effective_to_dt   := EOT;
    
    -- create new ID
    
    INSERT INTO BTG_ALLCTN_RL_FND_ID
    (
      id    
    , allocation_rule_id
    , sophis_fund_id
    , created_by
    , created_dt
    )
    VALUES
    (
      p_id 
    , p_allocation_rule_id
    , p_sophis_fund_id
    , p_created_by
    , p_created_dt
    );
    
    -- create new version
    
    INSERT INTO BTG_ALLCTN_RL_FND_VRSN
    (
      id
    , version         
    , percentage
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version     
    , p_percentage
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    INSERT INTO BTG_ALLCTN_RL_FND
    (
      id
    , version
    , allocation_rule_id
    , sophis_fund_id
    )
    VALUES
    (
      p_id
    , p_version
    , p_allocation_rule_id
    , p_sophis_fund_id
    );
  
    COMMIT;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveFund
  (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type  
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type  
  , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
  )
  AS
  
    l_btg_allctn_rl_fnd V_BTG_ALLCTN_RL_FND%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_FND.*
    INTO        l_btg_allctn_rl_fnd
    FROM        V_BTG_ALLCTN_RL_FND    
    WHERE       V_BTG_ALLCTN_RL_FND.id = p_id;
    
    -- check if rule has been matched
    
    IF ('Y' = IsRuleMatched(l_btg_allctn_rl_fnd.ALLOCATION_RULE_ID)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_FND_VRSN
    SET     BTG_ALLCTN_RL_FND_VRSN.effective_to_dt    = p_updated_dt
    WHERE   BTG_ALLCTN_RL_FND_VRSN.id                 = p_id
    AND     BTG_ALLCTN_RL_FND_VRSN.version            = l_btg_allctn_rl_fnd.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_fnd.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_FND_VRSN
    (
      id
    , version         
    , percentage
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , p_version         
    , p_percentage
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_FND
    SET     BTG_ALLCTN_RL_FND.version = p_version
    WHERE   BTG_ALLCTN_RL_FND.id      = p_id;    
    
    COMMIT;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      ROLLBACK TO new_member;

      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);    
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveFund
  (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
  )
  AS
  
    l_btg_allctn_rl_fnd V_BTG_ALLCTN_RL_FND%rowtype;
  
  BEGIN
  
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_FND.*
    INTO        l_btg_allctn_rl_fnd
    FROM        V_BTG_ALLCTN_RL_FND
    WHERE       V_BTG_ALLCTN_RL_FND.id = p_id;
    
    IF ('Y' = IsRuleMatched(l_btg_allctn_rl_fnd.ALLOCATION_RULE_ID)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    -- set versioning information
                
    l_btg_allctn_rl_fnd.updated_dt        := SYSTIMESTAMP;
    l_btg_allctn_rl_fnd.effective_from_dt := l_btg_allctn_rl_fnd.updated_dt;      
    l_btg_allctn_rl_fnd.effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_FND_VRSN
    SET     BTG_ALLCTN_RL_FND_VRSN.effective_to_dt  = l_btg_allctn_rl_fnd.updated_dt
    WHERE   BTG_ALLCTN_RL_FND_VRSN.id               = p_id
    AND     BTG_ALLCTN_RL_FND_VRSN.version          = l_btg_allctn_rl_fnd.version;
    
    -- create new version
    
    l_btg_allctn_rl_fnd.version := l_btg_allctn_rl_fnd.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_FND_VRSN
    (
      id
    , version         
    , percentage
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_id
    , l_btg_allctn_rl_fnd.version       
    , l_btg_allctn_rl_fnd.percentage    
    , p_updated_by
    , l_btg_allctn_rl_fnd.updated_dt
    , l_btg_allctn_rl_fnd.effective_from_dt
    , l_btg_allctn_rl_fnd.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_FND
    SET     BTG_ALLCTN_RL_FND.version = l_btg_allctn_rl_fnd.version
    WHERE   BTG_ALLCTN_RL_FND.id      = p_id;        
    
    COMMIT;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      ROLLBACK TO new_member;
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFunds
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND.id
      ,           V_BTG_ALLCTN_RL_FND.version      
      ,           V_BTG_ALLCTN_RL_FND.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_FND.sophis_fund_id 
      ,           V_BTG_ALLCTN_RL_FND.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_FND.percentage
      ,           V_BTG_ALLCTN_RL_FND.created_by
      ,           V_BTG_ALLCTN_RL_FND.created_dt
      ,           V_BTG_ALLCTN_RL_FND.updated_by
      ,           V_BTG_ALLCTN_RL_FND.updated_dt
      ,           V_BTG_ALLCTN_RL_FND.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND.deleted
      FROM        V_BTG_ALLCTN_RL_FND
      INNER JOIN  V_BTG_ALLCTN_RL
      ON          V_BTG_ALLCTN_RL.id                      = V_BTG_ALLCTN_RL_FND.allocation_rule_id
      AND         V_BTG_ALLCTN_RL.deleted                 = 'N'      
      WHERE       V_BTG_ALLCTN_RL_FND.deleted             = 'N'
      AND         V_BTG_ALLCTN_RL_FND.allocation_rule_id  = p_allocation_rule_id
      ORDER BY    V_BTG_ALLCTN_RL_FND.sophis_fund_name;
  
  END;

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id%type
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND_VRSN.id
      ,           V_BTG_ALLCTN_RL_FND_VRSN.version      
      ,           V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_id      
      ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_FND_VRSN.percentage
      ,           V_BTG_ALLCTN_RL_FND_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_FND_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_FND_VRSN      
      WHERE       V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id = p_allocation_rule_id
      ORDER BY    V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_id                        IN            V_BTG_ALLCTN_RL_FND_VRSN.id%type
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND_VRSN.id
      ,           V_BTG_ALLCTN_RL_FND_VRSN.version      
      ,           V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id
      ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_id      
      ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_name
      ,           V_BTG_ALLCTN_RL_FND_VRSN.percentage
      ,           V_BTG_ALLCTN_RL_FND_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_FND_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_FND_VRSN      
      WHERE       V_BTG_ALLCTN_RL_FND_VRSN.id = p_id      
      ORDER BY    V_BTG_ALLCTN_RL_FND_VRSN.version;
  
    NULL;
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE NewFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
  , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND_FL.created_by%type
  , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.created_dt%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
  )
  AS
  
    l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
    
    l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;
  
  BEGIN
      
      SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
      INTO    l_allocation_rule_id
      FROM    V_BTG_ALLCTN_RL_FND
      WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
      
      IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
      
        RAISE RULE_IS_MATCHED;
        
      END IF;

    BEGIN

      -- see if record already exists
      
      SELECT  V_BTG_ALLCTN_RL_FND_FL.*      
      INTO    l_btg_allctn_rl_fnd_fl
      FROM    V_BTG_ALLCTN_RL_FND_FL
      WHERE   V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id      
      AND     V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
      
      p_created_by := l_btg_allctn_rl_fnd_fl.created_by;
      p_created_dt := l_btg_allctn_rl_fnd_fl.created_dt;
      
      SaveFundFolio
      (
        p_allocation_rule_fund_id      
      , p_sophis_folio_id
      , p_version
      , p_include_exclude
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      );
      
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
  
        SAVEPOINT new_member;      
        
        -- set versioning information
        
        p_version           := 1;    
        p_created_dt        := SYSTIMESTAMP;   
        p_updated_dt        := p_created_dt;
        p_effective_from_dt := p_created_dt;      
        p_effective_to_dt   := EOT;
        
        -- create new ID
        
        INSERT INTO BTG_ALLCTN_RL_FND_FL_ID
        (
          allocation_rule_fund_id        
        , sophis_folio_id
        , created_by
        , created_dt
        )
        VALUES
        (
          p_allocation_rule_fund_id        
        , p_sophis_folio_id
        , p_created_by
        , p_created_dt
        );
        
        -- create new version
        
        INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
        (
          allocation_rule_fund_id        
        , sophis_folio_id
        , version
        , include_exclude
        , updated_by
        , updated_dt
        , effective_from_dt
        , effective_to_dt
        , deleted
        )
        VALUES
        (
          p_allocation_rule_fund_id        
        , p_sophis_folio_id
        , p_version     
        , p_include_exclude
        , p_updated_by
        , p_updated_dt
        , p_effective_from_dt
        , p_effective_to_dt
        , 'N'
        );
        
        -- make new version active record
        
        INSERT INTO BTG_ALLCTN_RL_FND_FL
        (
          allocation_rule_fund_id        
        , sophis_folio_id
        , version
        )
        VALUES
        (
          p_allocation_rule_fund_id        
        , p_sophis_folio_id
        , p_version
        );
      
        COMMIT;
        
    END;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE SaveFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type  
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
  , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
  , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
  )
  AS
  
    l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
    
    l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;
  
  BEGIN
  
    SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
    INTO    l_allocation_rule_id
    FROM    V_BTG_ALLCTN_RL_FND
    WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
    
    IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
      
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_FND_FL.*
    INTO        l_btg_allctn_rl_fnd_fl
    FROM        V_BTG_ALLCTN_RL_FND_FL    
    WHERE       V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
    AND         V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
    
    -- set versioning information
                
    p_updated_dt        := SYSTIMESTAMP;
    p_effective_from_dt := p_updated_dt;      
    p_effective_to_dt   := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_FND_FL_VRSN
    SET     BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt         = p_updated_dt
    WHERE   BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id    
    AND     BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
    AND     BTG_ALLCTN_RL_FND_FL_VRSN.version                 = l_btg_allctn_rl_fnd_fl.version;
    
    -- create new version
    
    p_version := l_btg_allctn_rl_fnd_fl.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
    (
      allocation_rule_fund_id    
    , sophis_folio_id
    , version
    , include_exclude
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_allocation_rule_fund_id    
    , p_sophis_folio_id
    , p_version     
    , p_include_exclude
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    , 'N'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_FND_FL
    SET     BTG_ALLCTN_RL_FND_FL.version                  = p_version
    WHERE   BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
    AND     BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
    
    COMMIT;
  
  EXCEPTION
      
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE RemoveFundFolio
  (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
  , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
  )
  AS
  
    l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
    
    l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;
  
  BEGIN
  
    SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
    INTO    l_allocation_rule_id
    FROM    V_BTG_ALLCTN_RL_FND
    WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
    
    IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;
    
    SAVEPOINT new_member;
    
    -- get latest version
    
    SELECT      V_BTG_ALLCTN_RL_FND_FL.*
    INTO        l_btg_allctn_rl_fnd_fl
    FROM        V_BTG_ALLCTN_RL_FND_FL    
    WHERE       V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
    AND         V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
    
    -- set versioning information
                
    l_btg_allctn_rl_fnd_fl.updated_dt         := SYSTIMESTAMP;
    l_btg_allctn_rl_fnd_fl.effective_from_dt  := l_btg_allctn_rl_fnd_fl.updated_dt;      
    l_btg_allctn_rl_fnd_fl.effective_to_dt    := EOT;
    
    -- update existing version
    
    UPDATE  BTG_ALLCTN_RL_FND_FL_VRSN
    SET     BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt         = l_btg_allctn_rl_fnd_fl.updated_dt
    WHERE   BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id    
    AND     BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
    AND     BTG_ALLCTN_RL_FND_FL_VRSN.version                 = l_btg_allctn_rl_fnd_fl.version;
    
    -- create new version
    
    l_btg_allctn_rl_fnd_fl.version := l_btg_allctn_rl_fnd_fl.version + 1;
          
    INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
    (
      allocation_rule_fund_id    
    , sophis_folio_id
    , version
    , include_exclude
    , updated_by
    , updated_dt
    , effective_from_dt
    , effective_to_dt
    , deleted
    )
    VALUES
    (
      p_allocation_rule_fund_id    
    , p_sophis_folio_id
    , l_btg_allctn_rl_fnd_fl.version     
    , l_btg_allctn_rl_fnd_fl.include_exclude
    , p_updated_by
    , l_btg_allctn_rl_fnd_fl.updated_dt
    , l_btg_allctn_rl_fnd_fl.effective_from_dt
    , l_btg_allctn_rl_fnd_fl.effective_to_dt
    , 'Y'
    );
    
    -- make new version active record
    
    UPDATE  BTG_ALLCTN_RL_FND_FL
    SET     BTG_ALLCTN_RL_FND_FL.version                  = l_btg_allctn_rl_fnd_fl.version
    WHERE   BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
    AND     BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;     
    
    COMMIT;
  
  EXCEPTION
  
    WHEN RULE_IS_MATCHED THEN
    
      raise_application_error(-20111, 'Rule has been matched.');
      
    WHEN OTHERS THEN

      ROLLBACK TO new_member;

      raise_application_error(-20011, sqlerrm);
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolios
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id      
      ,           V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id      
      ,           V_BTG_ALLCTN_RL_FND_FL.version
      ,           V_BTG_ALLCTN_RL_FND_FL.sophis_folio_name
      ,           V_BTG_ALLCTN_RL_FND_FL.include_exclude      
      ,           V_BTG_ALLCTN_RL_FND_FL.created_by
      ,           V_BTG_ALLCTN_RL_FND_FL.created_dt
      ,           V_BTG_ALLCTN_RL_FND_FL.updated_by
      ,           V_BTG_ALLCTN_RL_FND_FL.updated_dt
      ,           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND_FL.deleted
      FROM        V_BTG_ALLCTN_RL_FND_FL
      INNER JOIN  V_BTG_ALLCTN_RL_FND
      ON          V_BTG_ALLCTN_RL_FND.id                          = V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id
      AND         V_BTG_ALLCTN_RL_FND.deleted                     = 'N'
      INNER JOIN  V_BTG_ALLCTN_RL
      ON          V_BTG_ALLCTN_RL.id                              = V_BTG_ALLCTN_RL_FND.allocation_rule_id
      AND         V_BTG_ALLCTN_RL.deleted                         = 'N'
      WHERE       V_BTG_ALLCTN_RL_FND_FL.deleted                  = 'N'
      AND         V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id      
      AND         V_BTG_ALLCTN_RL_FND_FL.include_exclude          = p_include_exclude
      ORDER BY    V_BTG_ALLCTN_RL_FND_FL.sophis_folio_name;
  
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolioVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
  , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.version
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_name
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_FND_FL_VRSN      
      WHERE       V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id      
      AND         V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
      ORDER BY    V_BTG_ALLCTN_RL_FND_FL_VRSN.version;
      
  END;
  
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  PROCEDURE GetFundFolioVersions
  (
    p_cursor                    OUT           T_CURSOR
  , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
  , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude%type
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT      V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.version
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_name
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude      
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_by
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
      ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.deleted
      FROM        V_BTG_ALLCTN_RL_FND_FL_VRSN          
      WHERE       V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id      
      AND         V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude         = p_include_exclude
      ORDER BY    V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt;
      
  END;

  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************  
  FUNCTION CheckUserCredentials
  (
    p_name                    IN            V_BTG_ALLCTN_RL_USR.name%type
  , p_password                IN            V_BTG_ALLCTN_RL_USR.password%type
  , p_id                      OUT           V_BTG_ALLCTN_RL_USR.id%type
  , p_is_administrator        OUT           CHAR
  )
  RETURN CHAR -- Returns 'Y' or 'N'
  AS
  BEGIN
    
    SELECT      V_BTG_ALLCTN_RL_USR.id
    ,           V_BTG_ALLCTN_RL_USR.is_administrator      
    INTO        p_id
    ,           p_is_administrator
    FROM        V_BTG_ALLCTN_RL_USR    
    WHERE       V_BTG_ALLCTN_RL_USR.deleted   = 'N'
    AND         V_BTG_ALLCTN_RL_USR.name      = p_name
    AND         V_BTG_ALLCTN_RL_USR.password  = p_password;
    
    RETURN 'Y';
    
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN
      
      RETURN 'N';   
    
  END;
    
  -- *****************************************************************
  -- Description:
	--
  -- Author:          M.Canning
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 16 AUG 2012      M.Canning     Created.
  -- *****************************************************************
  FUNCTION CheckAllocationRule
  (
    p_block_refcon  IN  HISTOMVTS.refcon%TYPE
  ) 
  RETURN CHAR -- Returns 'Y' or 'N'
  AS
  
    l_execution               HISTOMVTS%rowtype;
    l_sophis_user_exists      NUMBER;
    l_allocation_rule_id      V_BTG_ALLCTN_RL.id%type;
    l_allocation_rule_version V_BTG_ALLCTN_RL.version%type;
    
  BEGIN
    
    -- get the execution
    
    SELECT      HISTOMVTS.*
    INTO        l_execution
    FROM        HISTOMVTS
    WHERE       HISTOMVTS.refcon = p_block_refcon;
    
    -- are we interested in this operator?
    
    SELECT      COUNT(*)
    INTO        l_sophis_user_exists
    FROM        V_BTG_ALLCTN_RL_SPHS_USR
    WHERE       V_BTG_ALLCTN_RL_SPHS_USR.deleted != 'Y'
    AND         V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = l_execution.operateur;
        
    IF (l_sophis_user_exists = 1)
    THEN
    
      BEGIN
      
        SELECT      ALLOCATION_RULE.id
        ,           ALLOCATION_RULE.version
        INTO        l_allocation_rule_id
        ,           l_allocation_rule_version
        FROM        (
                      SELECT      V_BTG_ALLCTN_RL.id
                      ,           V_BTG_ALLCTN_RL.version
                      ,           COUNT(*) AS required_count_to_match_rule
                      FROM        V_BTG_ALLCTN_RL
                      INNER JOIN  V_BTG_ALLCTN_RL_FND
                      ON          V_BTG_ALLCTN_RL_FND.allocation_rule_id  = V_BTG_ALLCTN_RL.id
                      AND         V_BTG_ALLCTN_RL_FND.deleted             = 'N'
                      WHERE       V_BTG_ALLCTN_RL.deleted                 = 'N'
                      GROUP BY    V_BTG_ALLCTN_RL.id
                      ,           V_BTG_ALLCTN_RL.version
                    ) ALLOCATION_RULE
        INNER JOIN  (
                      SELECT      V_BTG_ALLCTN_RL.id                                                                                        AS allocation_rule_id
                      ,           SUM(CASE WHEN TRADE.flag IS NOT NULL AND V_BTG_ALLCTN_RL_FND_FL.include_exclude = 'I' THEN  1 ELSE 0 END)
                                  +
                                  SUM(CASE WHEN TRADE.flag IS NOT NULL AND V_BTG_ALLCTN_RL_FND_FL.include_exclude = 'E' THEN -1 ELSE 0 END) AS actual_count_matched_to_rule
                      FROM        V_BTG_ALLCTN_RL
                      INNER JOIN  V_BTG_ALLCTN_RL_TRDR
                      ON          V_BTG_ALLCTN_RL_TRDR.allocation_rule_id           = V_BTG_ALLCTN_RL.id
                      AND         V_BTG_ALLCTN_RL_TRDR.deleted                      = 'N'
                      INNER JOIN  V_BTG_ALLCTN_RL_FND
                      ON          V_BTG_ALLCTN_RL_FND.allocation_rule_id            = V_BTG_ALLCTN_RL.id
                      AND         V_BTG_ALLCTN_RL_FND.deleted                       = 'N'                            
                      INNER JOIN  V_BTG_ALLCTN_RL_FND_FL
                      ON          V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id    = V_BTG_ALLCTN_RL_FND.id
                      AND         V_BTG_ALLCTN_RL_FND_FL.deleted                    = 'N'
                      LEFT JOIN   (
                                    SELECT      1                                                             AS flag
                                    ,           ALLOCATION.entite                                             AS fund_id
                                    ,           ALLOCATION.opcvm                                              AS folio_id
                                    ,           ROUND(ABS(ALLOCATION.quantite) / ABS(EXECUTION.quantite), 4)  AS percentage             
                                    FROM        TA_BLOCK_TO_GENERATED
                                    INNER JOIN  HISTOMVTS EXECUTION
                                    ON          EXECUTION.refcon                    = TA_BLOCK_TO_GENERATED.block_id
                                    INNER JOIN  HISTOMVTS ALLOCATION
                                    ON          ALLOCATION.refcon                   = TA_BLOCK_TO_GENERATED.generated_id
                                    WHERE       TA_BLOCK_TO_GENERATED.block_id      = l_execution.refcon
                                  ) TRADE
                      ON          TRADE.fund_id                                     = V_BTG_ALLCTN_RL_FND.sophis_fund_id
                      AND         TRADE.percentage                                  = V_BTG_ALLCTN_RL_FND.percentage
                      AND         1                                                 = BTG_ALLCTN_RL_FL_IN_HRRCHY(V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id, TRADE.folio_id)
                      WHERE       V_BTG_ALLCTN_RL.deleted                           = 'N'
                      AND         V_BTG_ALLCTN_RL.active                            = 'Y'                          
                      AND         V_BTG_ALLCTN_RL.active_from_dt                   <= l_execution.dateneg
                      AND         V_BTG_ALLCTN_RL.active_to_dt                     >= l_execution.dateneg
                      AND         V_BTG_ALLCTN_RL_TRDR.sophis_user_id               = l_execution.operateur         
                      GROUP BY    V_BTG_ALLCTN_RL.id
                    ) ALLOCATION_RULES_MATCHED
        ON          ALLOCATION_RULES_MATCHED.allocation_rule_id           = ALLOCATION_RULE.id
        AND         ALLOCATION_RULES_MATCHED.actual_count_matched_to_rule = ALLOCATION_RULE.required_count_to_match_rule
        WHERE       ROWNUM                                                = 1;
        
        INSERT INTO BTG_ALLCTN_RL_CHCK_HSTRY
        (
          sophis_transaction_id
        , effective_dt
        , allocation_rule_id
        , allocation_rule_version
        )
        VALUES
        (
          l_execution.refcon
        , SYSTIMESTAMP
        , l_allocation_rule_id
        , l_allocation_rule_version
        );
        
        RETURN 'Y';
      
      EXCEPTION
      
        WHEN NO_DATA_FOUND THEN
    
          INSERT INTO BTG_ALLCTN_RL_CHCK_HSTRY
          (
            sophis_transaction_id
          , effective_dt
          , allocation_rule_id
          , allocation_rule_version
          )
          VALUES
          (
            l_execution.refcon
          , SYSTIMESTAMP
          , -1
          , -1
          );
                    
          RETURN 'N';
      
      END;
      
    ELSE
    
      RETURN 'Y';
    
    END IF;
    
  EXCEPTION
    
    WHEN OTHERS THEN
  
      raise_application_error(-20011, sqlerrm);  
  
  END;
  
END PCKG_BTG_ALLOCATION;
  
/

DECLARE 

  l_id                    V_BTG_ALLCTN_RL_USR.id%type;
  l_version               V_BTG_ALLCTN_RL_USR.version%type;
  l_created_dt            V_BTG_ALLCTN_RL_USR.created_dt%type;
  l_updated_dt            V_BTG_ALLCTN_RL_USR.updated_dt%type;
  l_effective_from_dt     V_BTG_ALLCTN_RL_USR.effective_from_dt%type;
  l_effective_to_dt       V_BTG_ALLCTN_RL_USR.effective_to_dt%type;

BEGIN

  PCKG_BTG_ALLOCATION.NewUser(l_id, l_version, 'Administrator', 'btg@123', 'Y', -42, l_created_dt, -42, l_updated_dt, l_effective_from_dt, l_effective_to_dt);

  PCKG_BTG_ALLOCATION.NewUser(l_id, l_version, 'Jun Guan', 'Jun Guan', 'Y', -42, l_created_dt, -42, l_updated_dt, l_effective_from_dt, l_effective_to_dt);
  
  PCKG_BTG_ALLOCATION.NewUser(l_id, l_version, 'Oliver South', 'Oliver South', 'Y', -42, l_created_dt, -42, l_updated_dt, l_effective_from_dt, l_effective_to_dt);
  
END;

/
/*
DECLARE

  CURSOR cur_riskusers_idents IS
    SELECT RISKUSERS.ident
    FROM RISKUSERS 
    WHERE RISKUSERS.gident IN (4572, 4567, 4562); -- 4572=BACK OFFICE. 4567=FRONT OFFICE. 4562=GLOBAL ADMINISTRATOR
    
  v_riskusers_ident cur_riskusers_idents%ROWTYPE;
    
  l_version             V_BTG_ALLCTN_RL_SPHS_USR.version%type;  
  l_created_by          V_BTG_ALLCTN_RL_SPHS_USR.created_by%type;
  l_created_dt          V_BTG_ALLCTN_RL_SPHS_USR.created_dt%type;
  l_updated_dt          V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type;
  l_effective_from_dt   V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type;
  l_effective_to_dt     V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type;
  
BEGIN

  l_created_by := -42;

  OPEN cur_riskusers_idents;  
  
  LOOP
    
    FETCH cur_riskusers_idents INTO v_riskusers_ident;    
    
    EXIT WHEN cur_riskusers_idents%NOTFOUND;
	  
	  PCKG_BTG_ALLOCATION.NewSophisUser(v_riskusers_ident.ident, l_version, l_created_by, l_created_dt, l_created_by, l_updated_dt, l_effective_from_dt, l_effective_to_dt);
  
  END LOOP;
  
  CLOSE cur_riskusers_idents;
  
END;
*/