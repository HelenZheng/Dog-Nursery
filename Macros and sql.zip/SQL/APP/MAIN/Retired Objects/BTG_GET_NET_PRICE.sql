create or replace
FUNCTION "BTG_FN_GET_NET_PRICE"(
                             Trade_Id HISTOMVTS.refcon%TYPE
                             )
    RETURN VARCHAR2
  IS
    IntrumentType   TITRES.TYPE%TYPE;
    IntrumentAllot  TITRES.affectation%TYPE;
    NetPrice        NUMBER;
  BEGIN 
   
  SELECT TITRES.type
  INTO IntrumentType
  FROM TITRES
  INNER JOIN HISTOMVTS
  ON HISTOMVTS.sicovam = TITRES.sicovam
  AND HISTOMVTS.refcon = Trade_Id;
  
  SELECT TITRES.affectation
  INTO IntrumentAllot
  FROM TITRES
  INNER JOIN HISTOMVTS
  ON HISTOMVTS.sicovam = TITRES.sicovam
  AND HISTOMVTS.refcon = Trade_Id;
  
  IF IntrumentType = 'A' THEN
            SELECT ROUND((HISTOMVTS.montant/HISTOMVTS.quantite),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice;
  END IF ; --Shares take the net amount and divide by quantity

  IF IntrumentType IN ('O', 'G', 'E', 'S') THEN
            SELECT ROUND((HISTOMVTS.cours),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice;
  END IF ; --Bonds, CFDs, FX and swaps are all traded at the net price so taking directly from the database with no calculation.
  
  IF IntrumentAllot = '9' THEN
            SELECT ROUND((HISTOMVTS.cours),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice;
  END IF ; -- Convertible Bonds traded at the net price so taking directly from the database with no calculation.
  
  IF IntrumentType = 'D' AND IntrumentAllot != '9' THEN
            SELECT ROUND((HISTOMVTS.montant/(TITRES.quotite*HISTOMVTS.quantite)),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            INNER JOIN TITRES 
            ON TITRES.sicovam = HISTOMVTS.sicovam 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice;
  END IF ; --Options are taking the contract size into account
  
  IF IntrumentType = 'F' THEN
            SELECT ROUND((((HISTOMVTS.quantite*TITRES.quotite*HISTOMVTS.cours)+HISTOMVTS.montant)/(HISTOMVTS.quantite*TITRES.quotite)),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            INNER JOIN TITRES 
            ON TITRES.sicovam = HISTOMVTS.sicovam 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice;
  END IF ; --Futures are taking the contract size into account and because net amount only consists of fees then this is added in too
  
            SELECT ROUND((HISTOMVTS.cours),4) 
            INTO NetPrice 
            FROM HISTOMVTS 
            WHERE HISTOMVTS.refcon = Trade_Id;
    RETURN NetPrice; --Catch all to send price if not falling under one of the above criteria 

  EXCEPTION
  WHEN OTHERS THEN
    IF SQL%NOTFOUND THEN
      --  RAISE_APPLICATION_ERROR( -20011, SQLERRM );
      RETURN '' ;-- SQLERRM;
    ELSE
      -- RAISE_APPLICATION_ERROR( -20011, SQLERRM );
      RETURN SQLERRM;
    END IF;
  END; 

 