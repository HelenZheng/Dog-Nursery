﻿CREATE OR REPLACE FUNCTION BTG41DEV."BTG_BUSINESS_DATE" 
(
    p_date        IN DATE
  , p_offset      IN NUMBER
)
RETURN DATE
IS
  return_date      DATE    := p_date;
  offset_increment NUMBER  := 1;

  business_days     NUMBER  := 0;
  skip_counter      NUMBER  := 0;
BEGIN
  IF p_date IS NULL 
  OR p_offset IS NULL THEN
    RETURN NULL;
  END IF;

  IF p_offset < 0 THEN
    offset_increment := -1;
  END IF;
  
  LOOP
      
    IF to_char(return_date, 'DY') = 'SAT' 
    OR to_char(return_date, 'DY') = 'SUN' THEN
      return_date := return_date + offset_increment;
      skip_counter := skip_counter + 1;
    ELSE
      IF p_offset = 0 THEN
        RETURN return_date;
      END IF;

      IF ABS(business_days) >= ABS(p_offset) THEN
        RETURN return_date;
      END IF;      

      return_date := return_date + offset_increment;
      business_days := business_days + offset_increment;

      IF skip_counter > 0 THEN
        business_days := business_days + offset_increment;
        skip_counter := 0;
      END IF;
      
    END IF;    
  END LOOP;
END BTG_BUSINESS_DATE;
/