CREATE OR REPLACE FUNCTION "BTG_BUSINESS_DATE_HOLIDAY" 
(
    p_date          IN DATE
  , p_offset        IN NUMBER
  , p_currency      IN NUMBER
  , p_increment     IN NUMBER := 1
)
RETURN DATE
IS
  return_date       DATE    := p_date;
  is_holiday        NUMBER  := 0;
  offset_increment  NUMBER  := p_increment;
  
  offset            NUMBER  := p_offset;
BEGIN
  IF p_date IS NULL 
  OR p_offset IS NULL 
  OR p_currency IS NULL THEN
    RETURN NULL;
  END IF;

  IF p_offset < 0 THEN
    offset_increment := -1;
  END IF;
  
  LOOP
    IF offset > 0 THEN
      return_date := return_date + offset_increment;
      offset := offset - 1;
    END IF;
   
    SELECT COUNT(*) INTO is_holiday
    FROM FERIES 
    WHERE CODEDEV = p_currency 
      AND (DATEFER = return_date OR ( (to_char(return_date, 'dd-mon') != '29-feb') AND DATEFER = to_date(to_char(return_date, 'dd-mon') || '-1905') )) 
    AND ROWNUM = 1;
    
    WHILE (is_holiday = 1 
      OR to_char(return_date, 'DY') = 'SAT' 
      OR to_char(return_date, 'DY') = 'SUN')
    LOOP
      return_date := return_date + offset_increment;

      SELECT COUNT(*) INTO is_holiday
      FROM FERIES 
      WHERE CODEDEV = p_currency 
      AND (DATEFER = return_date OR ( (to_char(return_date, 'dd-mon') != '29-feb') AND DATEFER = to_date(to_char(return_date, 'dd-mon') || '-1905') )) 
      AND ROWNUM = 1;
    END LOOP;

    IF offset = 0 THEN
      RETURN return_date;
    END IF;
  END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(return_date);
END BTG_BUSINESS_DATE_HOLIDAY;
/
