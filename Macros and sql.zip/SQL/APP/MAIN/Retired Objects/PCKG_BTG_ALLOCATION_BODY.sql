CREATE OR REPLACE PACKAGE BODY PCKG_BTG_ALLOCATION 
AS

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFundsForSelection
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT    CLIENTS.ident   AS ID
    ,         CLIENTS.libelle AS NAME 
    FROM      CLIENTS 
    ORDER BY  LOWER(CLIENTS.libelle);
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
FUNCTION IsRuleMatched
(
  p_id                      IN            V_BTG_ALLCTN_RL.id%type
)
RETURN CHAR
AS

  l_matched CHAR(1);
  
BEGIN
    
  SELECT COALESCE((SELECT 'Y' FROM DUAL WHERE EXISTS (SELECT * FROM BTG_ALLCTN_RL_CHCK_HSTRY WHERE BTG_ALLCTN_RL_CHCK_HSTRY.allocation_rule_id = p_id)), 'N')
  INTO l_matched
  FROM DUAL;
        
  return l_matched;
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFoliosForSelection
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      FOLIO.ident AS ID
    ,           FOLIO.name
    ,           FOLIO.mgr   AS PARENT_ID
    ,           LEVEL       AS LVL
    FROM        FOLIO
    WHERE       LEVEL         > 1
    START WITH  FOLIO.ident   = 1
    CONNECT BY  FOLIO.mgr     = prior FOLIO.ident;
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisUsersForSelection
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT    RISKUSERS.ident AS ID
    ,         RISKUSERS.name                
    FROM      RISKUSERS
    ORDER BY  RISKUSERS.name;
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFolios
(
  p_cursor                    OUT           T_CURSOR
, p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
)
AS

  l_starting_sophis_folio_id V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type;

BEGIN

  SELECT      V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id
  INTO        l_starting_sophis_folio_id
  FROM        V_BTG_ALLCTN_RL_SPHS_FND
  WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
  
  OPEN p_cursor FOR
    SELECT      FOLIO.ident AS ID
    ,           FOLIO.name
    ,           FOLIO.mgr   AS PARENT_ID
    ,           LEVEL       AS LVL
    FROM        FOLIO
    WHERE       LEVEL         > 1
    START WITH  FOLIO.ident   = l_starting_sophis_folio_id
    CONNECT BY  FOLIO.mgr     = prior FOLIO.ident;
    
EXCEPTION

  WHEN NO_DATA_FOUND THEN
  
    raise_application_error(-20011, 'Starting Sophis Folio ID does not exist.');
    
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewSophisFund
(
  p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
, p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
, p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_FND.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
)
AS

  l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;

BEGIN
      
  BEGIN
  
    -- see if record already exists
  
    SELECT    V_BTG_ALLCTN_RL_SPHS_FND.*
    INTO      l_btg_allctn_rl_sphs_fnd
    FROM      V_BTG_ALLCTN_RL_SPHS_FND
    WHERE     V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
    
    p_created_by := l_btg_allctn_rl_sphs_fnd.created_by;
    p_created_dt := l_btg_allctn_rl_sphs_fnd.created_dt;
    
    SaveSophisFund
    (
      p_sophis_fund_id
    , p_version
    , p_starting_sophis_folio_id
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    );
  
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN
    
      SAVEPOINT new_member;
    
      -- set versioning information
      
      p_version           := 1;    
      p_created_dt        := SYSTIMESTAMP;   
      p_updated_dt        := p_created_dt;
      p_effective_from_dt := p_created_dt;      
      p_effective_to_dt   := EOT;
      
      -- create new ID
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_FND_ID
      (
        sophis_fund_id         
      , created_by
      , created_dt
      )
      VALUES
      (
        p_sophis_fund_id    
      , p_created_by
      , p_created_dt
      );
      
      -- create new version
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
      (
        sophis_fund_id
      , version     
      , starting_sophis_folio_id
      , updated_by
      , updated_dt
      , effective_from_dt
      , effective_to_dt
      , deleted
      )
      VALUES
      (
        p_sophis_fund_id
      , p_version       
      , p_starting_sophis_folio_id
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      , 'N'
      );
      
      -- make new version active record
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_FND
      (
        sophis_fund_id
      , version
      )
      VALUES
      (
        p_sophis_fund_id
      , p_version
      );
      
      COMMIT;
  
  END;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveSophisFund
(
  p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
, p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
)
AS

  l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_SPHS_FND.*      
  INTO        l_btg_allctn_rl_sphs_fnd
  FROM        V_BTG_ALLCTN_RL_SPHS_FND
  WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_SPHS_FND_VRSN
  SET     BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt  = p_updated_dt
  WHERE   BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id   = p_sophis_fund_id
  AND     BTG_ALLCTN_RL_SPHS_FND_VRSN.version          = l_btg_allctn_rl_sphs_fnd.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_sphs_fnd.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
  (
    sophis_fund_id
  , version    
  , starting_sophis_folio_id
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_sophis_fund_id
  , p_version  
  , p_starting_sophis_folio_id
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_SPHS_FND
  SET     BTG_ALLCTN_RL_SPHS_FND.version        = p_version
  WHERE   BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;    
  
  COMMIT;
  
EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);
    
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveSophisFund
(
  p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
)
AS

  l_btg_allctn_rl_sphs_fnd V_BTG_ALLCTN_RL_SPHS_FND%rowtype;

BEGIN
  
  SAVEPOINT new_member;
  
  -- get latest version

  SELECT      V_BTG_ALLCTN_RL_SPHS_FND.*      
  INTO        l_btg_allctn_rl_sphs_fnd
  FROM        V_BTG_ALLCTN_RL_SPHS_FND
  WHERE       V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
  
  -- set versioning information

  l_btg_allctn_rl_sphs_fnd.updated_dt         := SYSTIMESTAMP;
  l_btg_allctn_rl_sphs_fnd.effective_from_dt  := l_btg_allctn_rl_sphs_fnd.updated_dt;      
  l_btg_allctn_rl_sphs_fnd.effective_to_dt    := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_SPHS_FND_VRSN
  SET     BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt  = l_btg_allctn_rl_sphs_fnd.updated_dt
  WHERE   BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id   = p_sophis_fund_id
  AND     BTG_ALLCTN_RL_SPHS_FND_VRSN.version          = l_btg_allctn_rl_sphs_fnd.version;
  
  -- create new version
  
  l_btg_allctn_rl_sphs_fnd.version := l_btg_allctn_rl_sphs_fnd.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_SPHS_FND_VRSN
  (
    sophis_fund_id
  , version       
  , starting_sophis_folio_id
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_sophis_fund_id
  , l_btg_allctn_rl_sphs_fnd.version      
  , l_btg_allctn_rl_sphs_fnd.starting_sophis_folio_id
  , p_updated_by
  , l_btg_allctn_rl_sphs_fnd.updated_dt
  , l_btg_allctn_rl_sphs_fnd.effective_from_dt
  , l_btg_allctn_rl_sphs_fnd.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_SPHS_FND
  SET     BTG_ALLCTN_RL_SPHS_FND.version        = l_btg_allctn_rl_sphs_fnd.version
  WHERE   BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id = p_sophis_fund_id;
  
  COMMIT;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFunds
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id
    ,           V_BTG_ALLCTN_RL_SPHS_FND.version      
    ,           V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id
    ,           V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_FND      
    WHERE       V_BTG_ALLCTN_RL_SPHS_FND.deleted = 'N'
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_name;
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFundVersions
(
  p_cursor                    OUT           T_CURSOR
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id      
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version       
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_FND_VRSN      
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt; 
  
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisFundVersions
(
  p_cursor                    OUT           T_CURSOR
, p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id%type
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id      
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version       
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_id
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.starting_sophis_folio_name
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_FND_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_FND_VRSN      
    WHERE       V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id = p_sophis_fund_id
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_FND_VRSN.version; 
  
END;  

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewSophisUser
(
  p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
, p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_USR.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
)
AS

  l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;

BEGIN

  BEGIN
  
    -- see if record already exists
    
    SELECT  V_BTG_ALLCTN_RL_SPHS_USR.*      
    INTO    l_btg_allctn_rl_sphs_usr
    FROM    V_BTG_ALLCTN_RL_SPHS_USR
    WHERE   V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
    
    p_created_by := l_btg_allctn_rl_sphs_usr.created_by;
    p_created_dt := l_btg_allctn_rl_sphs_usr.created_dt;
    
    SaveSophisUser
    (
      p_sophis_user_id
    , p_version
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    );
    
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN
    
      SAVEPOINT new_member;
    
      -- set versioning information
      
      p_version           := 1;    
      p_created_dt        := SYSTIMESTAMP;   
      p_updated_dt        := p_created_dt;
      p_effective_from_dt := p_created_dt;      
      p_effective_to_dt   := EOT;
      
      -- create new ID
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_USR_ID
      (
        sophis_user_id      
      , created_by
      , created_dt
      )
      VALUES
      (
        p_sophis_user_id    
      , p_created_by
      , p_created_dt
      );
      
      -- create new version
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
      (
        sophis_user_id
      , version            
      , updated_by
      , updated_dt
      , effective_from_dt
      , effective_to_dt
      , deleted
      )
      VALUES
      (
        p_sophis_user_id
      , p_version          
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      , 'N'
      );
      
      -- make new version active record
      
      INSERT INTO BTG_ALLCTN_RL_SPHS_USR
      (
        sophis_user_id
      , version
      )
      VALUES
      (
        p_sophis_user_id
      , p_version
      );
        
      COMMIT;
  
  END;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveSophisUser
(
  p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
)
AS

  l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_SPHS_USR.*      
  INTO        l_btg_allctn_rl_sphs_usr
  FROM        V_BTG_ALLCTN_RL_SPHS_USR
  WHERE       V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_SPHS_USR_VRSN
  SET     BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt  = p_updated_dt
  WHERE   BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id   = p_sophis_user_id
  AND     BTG_ALLCTN_RL_SPHS_USR_VRSN.version          = l_btg_allctn_rl_sphs_usr.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_sphs_usr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
  (
    sophis_user_id
  , version            
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_sophis_user_id
  , p_version            
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_SPHS_USR
  SET     BTG_ALLCTN_RL_SPHS_USR.version        = p_version
  WHERE   BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;    
  
  COMMIT;
  
 EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveSophisUser
(
  p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
)
AS

  l_btg_allctn_rl_sphs_usr V_BTG_ALLCTN_RL_SPHS_USR%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version

  SELECT      V_BTG_ALLCTN_RL_SPHS_USR.*      
  INTO        l_btg_allctn_rl_sphs_usr
  FROM        V_BTG_ALLCTN_RL_SPHS_USR
  WHERE       V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
  
  -- set versioning information

  l_btg_allctn_rl_sphs_usr.updated_dt         := SYSTIMESTAMP;
  l_btg_allctn_rl_sphs_usr.effective_from_dt  := l_btg_allctn_rl_sphs_usr.updated_dt;      
  l_btg_allctn_rl_sphs_usr.effective_to_dt    := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_SPHS_USR_VRSN
  SET     BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt  = l_btg_allctn_rl_sphs_usr.updated_dt
  WHERE   BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id   = p_sophis_user_id
  AND     BTG_ALLCTN_RL_SPHS_USR_VRSN.version          = l_btg_allctn_rl_sphs_usr.version;
  
  -- create new version
  
  l_btg_allctn_rl_sphs_usr.version := l_btg_allctn_rl_sphs_usr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_SPHS_USR_VRSN
  (
    sophis_user_id
  , version            
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_sophis_user_id
  , l_btg_allctn_rl_sphs_usr.version      
  , p_updated_by
  , l_btg_allctn_rl_sphs_usr.updated_dt
  , l_btg_allctn_rl_sphs_usr.effective_from_dt
  , l_btg_allctn_rl_sphs_usr.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_SPHS_USR
  SET     BTG_ALLCTN_RL_SPHS_USR.version        = l_btg_allctn_rl_sphs_usr.version
  WHERE   BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = p_sophis_user_id;
  
  COMMIT;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisUsers
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_SPHS_USR.version       
    ,           V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_name
    ,           V_BTG_ALLCTN_RL_SPHS_USR.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_USR      
    WHERE       V_BTG_ALLCTN_RL_SPHS_USR.deleted = 'N'
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_name;    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisUserVersions
(
  p_cursor                    OUT           T_CURSOR
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version       
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_name
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_USR_VRSN      
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt; 

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetSophisUserVersions
(
  p_cursor                    OUT           T_CURSOR
, p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version       
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_name
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_SPHS_USR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_SPHS_USR_VRSN      
    WHERE       V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id = p_sophis_user_id
    ORDER BY    V_BTG_ALLCTN_RL_SPHS_USR_VRSN.version; 

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewUser
(
  p_id                        OUT           V_BTG_ALLCTN_RL_USR.id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
, p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
, p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
, p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
, p_created_by                IN            V_BTG_ALLCTN_RL_USR.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_USR.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
)
AS
BEGIN

  SAVEPOINT new_member;
  
  -- get new sequence number

  SELECT  BTG_ALLCTN_RL_USR_ID_SEQ.nextval
  INTO    p_id
  FROM    DUAL;
  
  -- set versioning information
  
  p_version           := 1;    
  p_created_dt        := SYSTIMESTAMP;   
  p_updated_dt        := p_created_dt;
  p_effective_from_dt := p_created_dt;      
  p_effective_to_dt   := EOT;
  
  -- create new ID
  
  INSERT INTO BTG_ALLCTN_RL_USR_ID
  (
    id
  , name
  , created_by
  , created_dt
  )
  VALUES
  (
    p_id
  , p_name
  , p_created_by
  , p_created_dt
  );
  
  -- create new version
  
  INSERT INTO BTG_ALLCTN_RL_USR_VRSN
  (
    id
  , version      
  , password
  , is_administrator      
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version
  , p_password
  , p_is_administrator      
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  INSERT INTO BTG_ALLCTN_RL_USR
  (
    id
  , version
  )
  VALUES
  (
    p_id
  , p_version
  );
  
  COMMIT;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveUser
(
  p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
, p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
, p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
, p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
, p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
)
AS

  l_btg_allctn_rl_usr V_BTG_ALLCTN_RL_USR%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_USR.*      
  INTO        l_btg_allctn_rl_usr
  FROM        V_BTG_ALLCTN_RL_USR
  WHERE       V_BTG_ALLCTN_RL_USR.id = p_id;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_USR_VRSN
  SET     BTG_ALLCTN_RL_USR_VRSN.effective_to_dt  = p_updated_dt
  WHERE   BTG_ALLCTN_RL_USR_VRSN.id               = p_id
  AND     BTG_ALLCTN_RL_USR_VRSN.version          = l_btg_allctn_rl_usr.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_usr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_USR_VRSN
  (
    id
  , version      
  , password
  , is_administrator      
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version      
  , p_password
  , p_is_administrator      
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_USR
  SET     BTG_ALLCTN_RL_USR.version = p_version
  WHERE   BTG_ALLCTN_RL_USR.id      = p_id;    
  
  COMMIT;
  
 EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveUser
(
  p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
)
AS

  l_btg_allctn_rl_usr V_BTG_ALLCTN_RL_USR%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version

  SELECT      V_BTG_ALLCTN_RL_USR.*      
  INTO        l_btg_allctn_rl_usr
  FROM        V_BTG_ALLCTN_RL_USR
  WHERE       V_BTG_ALLCTN_RL_USR.id = p_id;
  
  -- set versioning information

  l_btg_allctn_rl_usr.updated_dt        := SYSTIMESTAMP;
  l_btg_allctn_rl_usr.effective_from_dt := l_btg_allctn_rl_usr.updated_dt;      
  l_btg_allctn_rl_usr.effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_USR_VRSN
  SET     BTG_ALLCTN_RL_USR_VRSN.effective_to_dt  = l_btg_allctn_rl_usr.updated_dt
  WHERE   BTG_ALLCTN_RL_USR_VRSN.id               = p_id
  AND     BTG_ALLCTN_RL_USR_VRSN.version          = l_btg_allctn_rl_usr.version;
  
  -- create new version
  
  l_btg_allctn_rl_usr.version := l_btg_allctn_rl_usr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_USR_VRSN
  (
    id
  , version      
  , password
  , is_administrator      
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , l_btg_allctn_rl_usr.version
  , l_btg_allctn_rl_usr.password
  , l_btg_allctn_rl_usr.is_administrator        
  , p_updated_by
  , l_btg_allctn_rl_usr.updated_dt
  , l_btg_allctn_rl_usr.effective_from_dt
  , l_btg_allctn_rl_usr.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_USR
  SET     BTG_ALLCTN_RL_USR.version = l_btg_allctn_rl_usr.version
  WHERE   BTG_ALLCTN_RL_USR.id      = p_id;
  
  COMMIT;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetUsers
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_USR.id
    ,           V_BTG_ALLCTN_RL_USR.version
    ,           V_BTG_ALLCTN_RL_USR.name
    ,           V_BTG_ALLCTN_RL_USR.password
    ,           V_BTG_ALLCTN_RL_USR.is_administrator      
    ,           V_BTG_ALLCTN_RL_USR.created_by
    ,           V_BTG_ALLCTN_RL_USR.created_dt
    ,           V_BTG_ALLCTN_RL_USR.updated_by
    ,           V_BTG_ALLCTN_RL_USR.updated_dt
    ,           V_BTG_ALLCTN_RL_USR.effective_from_dt
    ,           V_BTG_ALLCTN_RL_USR.effective_to_dt
    ,           V_BTG_ALLCTN_RL_USR.deleted
    FROM        V_BTG_ALLCTN_RL_USR
    WHERE       V_BTG_ALLCTN_RL_USR.deleted  = 'N'
    ORDER BY    V_BTG_ALLCTN_RL_USR.name;      

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetUserVersions
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_USR_VRSN.id
    ,           V_BTG_ALLCTN_RL_USR_VRSN.version
    ,           V_BTG_ALLCTN_RL_USR_VRSN.name
    ,           V_BTG_ALLCTN_RL_USR_VRSN.password
    ,           V_BTG_ALLCTN_RL_USR_VRSN.is_administrator      
    ,           V_BTG_ALLCTN_RL_USR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_USR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_USR_VRSN
    ORDER BY    V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt; 

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetUserVersions
(
  p_cursor                    OUT           T_CURSOR
, p_id                        IN            V_BTG_ALLCTN_RL_USR_VRSN.id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_USR_VRSN.id
    ,           V_BTG_ALLCTN_RL_USR_VRSN.version
    ,           V_BTG_ALLCTN_RL_USR_VRSN.name
    ,           V_BTG_ALLCTN_RL_USR_VRSN.password
    ,           V_BTG_ALLCTN_RL_USR_VRSN.is_administrator      
    ,           V_BTG_ALLCTN_RL_USR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_USR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_USR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_USR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_USR_VRSN
    WHERE       V_BTG_ALLCTN_RL_USR_VRSN.id   = p_id
    ORDER BY    V_BTG_ALLCTN_RL_USR_VRSN.version; 

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewAllocationRule
(
  p_id                        OUT           V_BTG_ALLCTN_RL.id%type
, p_version                   OUT           V_BTG_ALLCTN_RL.version%type
, p_name                      IN            V_BTG_ALLCTN_RL.name%type
, p_active                    IN            V_BTG_ALLCTN_RL.active%type
, p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
, p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
, p_created_by                IN            V_BTG_ALLCTN_RL.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
)
AS
BEGIN

  SAVEPOINT new_member;
  
  -- get new sequence number

  SELECT  BTG_ALLCTN_RL_ID_SEQ.nextval
  INTO    p_id
  FROM    DUAL;
  
  -- set versioning information
  
  p_version           := 1;    
  p_created_dt        := SYSTIMESTAMP;   
  p_updated_dt        := p_created_dt;
  p_effective_from_dt := p_created_dt;      
  p_effective_to_dt   := EOT;
  
  -- create new ID
  
  INSERT INTO BTG_ALLCTN_RL_ID
  (
    id
  , created_by
  , created_dt
  )
  VALUES
  (
    p_id
  , p_created_by
  , p_created_dt
  );
  
  -- create new version
  
  INSERT INTO BTG_ALLCTN_RL_VRSN
  (
    id
  , version
  , name
  , active
  , active_from_dt
  , active_to_dt
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version
  , p_name
  , p_active
  , p_active_from_dt
  , p_active_to_dt      
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  INSERT INTO BTG_ALLCTN_RL
  (
    id
  , version
  )
  VALUES
  (
    p_id
  , p_version
  );
  
  COMMIT;

EXCEPTION

  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveAllocationRule
(
  p_id                        IN            V_BTG_ALLCTN_RL.id%type
, p_version                   OUT           V_BTG_ALLCTN_RL.version%type
, p_name                      IN            V_BTG_ALLCTN_RL.name%type
, p_active                    IN            V_BTG_ALLCTN_RL.active%type
, p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
, p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
)
AS

  l_btg_allctn_rl V_BTG_ALLCTN_RL%rowtype;
  
BEGIN
  
  SAVEPOINT new_member;
      
  -- get latest version
    
  SELECT      V_BTG_ALLCTN_RL.*      
  INTO        l_btg_allctn_rl
  FROM        V_BTG_ALLCTN_RL
  WHERE       V_BTG_ALLCTN_RL.id = p_id;
      
  -- check if rule has been matched
  IF ((l_btg_allctn_rl.name != p_name OR l_btg_allctn_rl.active != p_active OR l_btg_allctn_rl.active_from_dt != p_active_from_dt) AND 'Y' = IsRuleMatched(p_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_VRSN
  SET     BTG_ALLCTN_RL_VRSN.effective_to_dt  = p_updated_dt
  WHERE   BTG_ALLCTN_RL_VRSN.id               = p_id
  AND     BTG_ALLCTN_RL_VRSN.version          = l_btg_allctn_rl.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_VRSN
  (
    id
  , version
  , name
  , active
  , active_from_dt
  , active_to_dt
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version
  , p_name
  , p_active
  , p_active_from_dt
  , p_active_to_dt      
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL
  SET     BTG_ALLCTN_RL.version = p_version
  WHERE   BTG_ALLCTN_RL.id      = p_id;    
  
  COMMIT;
  
 EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    ROLLBACK TO new_member;
     
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveAllocationRule
(
  p_id                        IN            V_BTG_ALLCTN_RL.id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
)
AS

  l_btg_allctn_rl V_BTG_ALLCTN_RL%rowtype;

BEGIN
  
  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(p_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;

  SAVEPOINT new_member;
  
  -- get latest version

  SELECT      V_BTG_ALLCTN_RL.*      
  INTO        l_btg_allctn_rl
  FROM        V_BTG_ALLCTN_RL
  WHERE       V_BTG_ALLCTN_RL.id = p_id;
  
  -- set versioning information

  l_btg_allctn_rl.updated_dt        := SYSTIMESTAMP;
  l_btg_allctn_rl.effective_from_dt := l_btg_allctn_rl.updated_dt;      
  l_btg_allctn_rl.effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_VRSN
  SET     BTG_ALLCTN_RL_VRSN.effective_to_dt  = l_btg_allctn_rl.updated_dt
  WHERE   BTG_ALLCTN_RL_VRSN.id               = p_id
  AND     BTG_ALLCTN_RL_VRSN.version          = l_btg_allctn_rl.version;
  
  -- create new version
  
  l_btg_allctn_rl.version := l_btg_allctn_rl.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_VRSN
  (
    id
  , version
  , name
  , active
  , active_from_dt
  , active_to_dt
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , l_btg_allctn_rl.version
  , l_btg_allctn_rl.name
  , l_btg_allctn_rl.active
  , l_btg_allctn_rl.active_from_dt
  , l_btg_allctn_rl.active_to_dt      
  , p_updated_by
  , l_btg_allctn_rl.updated_dt
  , l_btg_allctn_rl.effective_from_dt
  , l_btg_allctn_rl.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL
  SET     BTG_ALLCTN_RL.version = l_btg_allctn_rl.version
  WHERE   BTG_ALLCTN_RL.id      = p_id;
  
  COMMIT;

EXCEPTION
  
  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetAllocationRules
(
  p_cursor                    OUT           T_CURSOR  
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL.id
    ,           V_BTG_ALLCTN_RL.version
    ,           V_BTG_ALLCTN_RL.name
    ,           V_BTG_ALLCTN_RL.active
    ,           V_BTG_ALLCTN_RL.active_from_dt
    ,           V_BTG_ALLCTN_RL.active_to_dt
    ,           V_BTG_ALLCTN_RL.created_by
    ,           V_BTG_ALLCTN_RL.created_dt
    ,           V_BTG_ALLCTN_RL.updated_by
    ,           V_BTG_ALLCTN_RL.updated_dt
    ,           V_BTG_ALLCTN_RL.effective_from_dt
    ,           V_BTG_ALLCTN_RL.effective_to_dt
    ,           V_BTG_ALLCTN_RL.deleted
    ,           V_BTG_ALLCTN_RL.matched
    FROM        V_BTG_ALLCTN_RL
    WHERE       V_BTG_ALLCTN_RL.deleted  = 'N'
    ORDER BY    V_BTG_ALLCTN_RL.name;      

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetAllocationRules
(
  p_cursor                    OUT           T_CURSOR  
, p_active_dt                 IN            V_BTG_ALLCTN_RL.active_from_dt%type    
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL.id
    ,           V_BTG_ALLCTN_RL.version
    ,           V_BTG_ALLCTN_RL.name
    ,           V_BTG_ALLCTN_RL.active
    ,           V_BTG_ALLCTN_RL.active_from_dt
    ,           V_BTG_ALLCTN_RL.active_to_dt
    ,           V_BTG_ALLCTN_RL.created_by,           V_BTG_ALLCTN_RL.created_dt
    ,           V_BTG_ALLCTN_RL.updated_by
    ,           V_BTG_ALLCTN_RL.updated_dt
    ,           V_BTG_ALLCTN_RL.effective_from_dt
    ,           V_BTG_ALLCTN_RL.effective_to_dt
    ,           V_BTG_ALLCTN_RL.deleted
    ,           V_BTG_ALLCTN_RL.matched
    FROM        V_BTG_ALLCTN_RL
    WHERE       V_BTG_ALLCTN_RL.deleted  = 'N'
    AND         p_active_dt BETWEEN V_BTG_ALLCTN_RL.active_from_dt AND V_BTG_ALLCTN_RL.active_to_dt
    ORDER BY    V_BTG_ALLCTN_RL.name;      

END;




-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetAllocationRuleVersions
(
  p_cursor                    OUT           T_CURSOR
, p_id                        IN            V_BTG_ALLCTN_RL_VRSN.id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_VRSN.id
    ,           V_BTG_ALLCTN_RL_VRSN.version
    ,           V_BTG_ALLCTN_RL_VRSN.name
    ,           V_BTG_ALLCTN_RL_VRSN.active
    ,           V_BTG_ALLCTN_RL_VRSN.active_from_dt
    ,           V_BTG_ALLCTN_RL_VRSN.active_to_dt
    ,           V_BTG_ALLCTN_RL_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_VRSN      
    WHERE       V_BTG_ALLCTN_RL_VRSN.id = p_id
    ORDER BY    V_BTG_ALLCTN_RL_VRSN.version; 

END;


-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewTrader
(
  p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
, p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
, p_created_by                IN OUT        V_BTG_ALLCTN_RL_TRDR.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_TRDR.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
)
AS

  l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;

BEGIN
  
  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;

  BEGIN
    
    -- see if record already exists
    
    SELECT  V_BTG_ALLCTN_RL_TRDR.*      
    INTO    l_btg_allctn_rl_trdr
    FROM    V_BTG_ALLCTN_RL_TRDR
    WHERE   V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
    AND     V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
    
    p_created_by := l_btg_allctn_rl_trdr.created_by;
    p_created_dt := l_btg_allctn_rl_trdr.created_dt;
    
    SaveTrader
    (
      p_allocation_rule_id
    , p_sophis_user_id
    , p_version
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    );
    
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN

      SAVEPOINT new_member;      
      
      -- set versioning information
      
      p_version           := 1;    
      p_created_dt        := SYSTIMESTAMP;   
      p_updated_dt        := p_created_dt;
      p_effective_from_dt := p_created_dt;      
      p_effective_to_dt   := EOT;
      
      -- create new ID
      
      INSERT INTO BTG_ALLCTN_RL_TRDR_ID
      (
        allocation_rule_id
      , sophis_user_id
      , created_by
      , created_dt
      )
      VALUES
      (
        p_allocation_rule_id
      , p_sophis_user_id
      , p_created_by
      , p_created_dt
      );
      
      -- create new version
      
      INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
      (
        allocation_rule_id
      , sophis_user_id
      , version      
      , updated_by
      , updated_dt
      , effective_from_dt
      , effective_to_dt
      , deleted
      )
      VALUES
      (
        p_allocation_rule_id
      , p_sophis_user_id
      , p_version      
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      , 'N'
      );
      
      -- make new version active record
      
      INSERT INTO BTG_ALLCTN_RL_TRDR
      (
        allocation_rule_id
      , sophis_user_id
      , version
      )
      VALUES
      (
        p_allocation_rule_id
      , p_sophis_user_id
      , p_version
      );
    
      COMMIT;
  
  END;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
  
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveTrader
(
  p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
, p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
)
AS

  l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;

BEGIN

  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  SAVEPOINT new_member;

  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_TRDR.*
  INTO        l_btg_allctn_rl_trdr
  FROM        V_BTG_ALLCTN_RL_TRDR
  WHERE       V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
  AND         V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_TRDR_VRSN
  SET     BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt     = p_updated_dt
  WHERE   BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
  AND     BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
  AND     BTG_ALLCTN_RL_TRDR_VRSN.version             = l_btg_allctn_rl_trdr.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_trdr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
  (
    allocation_rule_id
  , sophis_user_id
  , version      
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_allocation_rule_id
  , p_sophis_user_id
  , p_version      
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_TRDR
  SET     BTG_ALLCTN_RL_TRDR.version              = p_version
  WHERE   BTG_ALLCTN_RL_TRDR.allocation_rule_id   = p_allocation_rule_id
  AND     BTG_ALLCTN_RL_TRDR.sophis_user_id       = p_sophis_user_id;    
  
  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveTrader
(
  p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
, p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
)
AS

  l_btg_allctn_rl_trdr V_BTG_ALLCTN_RL_TRDR%rowtype;

BEGIN
    
  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_TRDR.*
  INTO        l_btg_allctn_rl_trdr
  FROM        V_BTG_ALLCTN_RL_TRDR
  WHERE       V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
  AND         V_BTG_ALLCTN_RL_TRDR.sophis_user_id     = p_sophis_user_id;
  
  -- set versioning information
              
  l_btg_allctn_rl_trdr.updated_dt         := SYSTIMESTAMP;
  l_btg_allctn_rl_trdr.effective_from_dt  := l_btg_allctn_rl_trdr.updated_dt;      
  l_btg_allctn_rl_trdr.effective_to_dt    := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_TRDR_VRSN
  SET     BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt     = l_btg_allctn_rl_trdr.updated_dt
  WHERE   BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
  AND     BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
  AND     BTG_ALLCTN_RL_TRDR_VRSN.version             = l_btg_allctn_rl_trdr.version;
  
  -- create new version
  
  l_btg_allctn_rl_trdr.version := l_btg_allctn_rl_trdr.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_TRDR_VRSN
  (
    allocation_rule_id
  , sophis_user_id
  , version      
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_allocation_rule_id
  , p_sophis_user_id
  , l_btg_allctn_rl_trdr.version      
  , p_updated_by
  , l_btg_allctn_rl_trdr.updated_dt
  , l_btg_allctn_rl_trdr.effective_from_dt
  , l_btg_allctn_rl_trdr.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_TRDR
  SET     BTG_ALLCTN_RL_TRDR.version              = l_btg_allctn_rl_trdr.version
  WHERE   BTG_ALLCTN_RL_TRDR.allocation_rule_id   = p_allocation_rule_id
  AND     BTG_ALLCTN_RL_TRDR.sophis_user_id       = p_sophis_user_id;    
  
  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetTraders
(
  p_cursor                    OUT           T_CURSOR
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_TRDR.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_TRDR.version     
    ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_name
    ,           V_BTG_ALLCTN_RL_TRDR.created_by
    ,           V_BTG_ALLCTN_RL_TRDR.created_dt
    ,           V_BTG_ALLCTN_RL_TRDR.updated_by
    ,           V_BTG_ALLCTN_RL_TRDR.updated_dt
    ,           V_BTG_ALLCTN_RL_TRDR.effective_from_dt
    ,           V_BTG_ALLCTN_RL_TRDR.effective_to_dt
    ,           V_BTG_ALLCTN_RL_TRDR.deleted
    FROM        V_BTG_ALLCTN_RL_TRDR
    INNER JOIN  V_BTG_ALLCTN_RL
    ON          V_BTG_ALLCTN_RL.id            = V_BTG_ALLCTN_RL_TRDR.allocation_rule_id      
    AND         V_BTG_ALLCTN_RL.deleted       = 'N'      
    WHERE       V_BTG_ALLCTN_RL_TRDR.deleted  = 'N'
    ORDER BY    V_BTG_ALLCTN_RL_TRDR.sophis_user_name;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetTraders
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_TRDR.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_TRDR.version     
    ,           V_BTG_ALLCTN_RL_TRDR.sophis_user_name
    ,           V_BTG_ALLCTN_RL_TRDR.created_by
    ,           V_BTG_ALLCTN_RL_TRDR.created_dt
    ,           V_BTG_ALLCTN_RL_TRDR.updated_by
    ,           V_BTG_ALLCTN_RL_TRDR.updated_dt
    ,           V_BTG_ALLCTN_RL_TRDR.effective_from_dt
    ,           V_BTG_ALLCTN_RL_TRDR.effective_to_dt
    ,           V_BTG_ALLCTN_RL_TRDR.deleted
    FROM        V_BTG_ALLCTN_RL_TRDR
    INNER JOIN  V_BTG_ALLCTN_RL
    ON          V_BTG_ALLCTN_RL.id                      = V_BTG_ALLCTN_RL_TRDR.allocation_rule_id      
    AND         V_BTG_ALLCTN_RL.deleted                 = 'N'      
    WHERE       V_BTG_ALLCTN_RL_TRDR.deleted            = 'N'
    AND         V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = p_allocation_rule_id
    ORDER BY    V_BTG_ALLCTN_RL_TRDR.sophis_user_name;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetTraderVersions
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
, p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.version     
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_name
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_TRDR_VRSN
    WHERE       V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id  = p_allocation_rule_id
    AND         V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      = p_sophis_user_id
    ORDER BY    V_BTG_ALLCTN_RL_TRDR_VRSN.version;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetTraderVersions
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id      
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.version     
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_name
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_TRDR_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_TRDR_VRSN      
    WHERE       V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id = p_allocation_rule_id
    ORDER BY    V_BTG_ALLCTN_RL_TRDR_VRSN.effective_from_dt;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewFund
(
  p_id                        OUT           V_BTG_ALLCTN_RL_FND.id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
, p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_FND.sophis_fund_id%type
, p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type
, p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_FND.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
)
AS
BEGIN

  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(p_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  SAVEPOINT new_member;    
      
  -- get new sequence number

  SELECT  BTG_ALLCTN_RL_FND_ID_SEQ.nextval
  INTO    p_id
  FROM    DUAL;
  
  -- set versioning information
  
  p_version           := 1;    
  p_created_dt        := SYSTIMESTAMP;   
  p_updated_dt        := p_created_dt;
  p_effective_from_dt := p_created_dt;      
  p_effective_to_dt   := EOT;
  
  -- create new ID
  
  INSERT INTO BTG_ALLCTN_RL_FND_ID
  (
    id    
  , allocation_rule_id
  , sophis_fund_id
  , created_by
  , created_dt
  )
  VALUES
  (
    p_id 
  , p_allocation_rule_id
  , p_sophis_fund_id
  , p_created_by
  , p_created_dt
  );
  
  -- create new version
  
  INSERT INTO BTG_ALLCTN_RL_FND_VRSN
  (
    id
  , version         
  , percentage
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version     
  , p_percentage
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  INSERT INTO BTG_ALLCTN_RL_FND
  (
    id
  , version
  , allocation_rule_id
  , sophis_fund_id
  )
  VALUES
  (
    p_id
  , p_version
  , p_allocation_rule_id
  , p_sophis_fund_id
  );

  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveFund
(
  p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type  
, p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type  
, p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type  
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
)
AS

  l_btg_allctn_rl_fnd V_BTG_ALLCTN_RL_FND%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_FND.*
  INTO        l_btg_allctn_rl_fnd
  FROM        V_BTG_ALLCTN_RL_FND    
  WHERE       V_BTG_ALLCTN_RL_FND.id = p_id;
  
  -- check if rule has been matched
  
  IF ('Y' = IsRuleMatched(l_btg_allctn_rl_fnd.ALLOCATION_RULE_ID)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_FND_VRSN
  SET     BTG_ALLCTN_RL_FND_VRSN.effective_to_dt    = p_updated_dt
  WHERE   BTG_ALLCTN_RL_FND_VRSN.id                 = p_id
  AND     BTG_ALLCTN_RL_FND_VRSN.version            = l_btg_allctn_rl_fnd.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_fnd.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_FND_VRSN
  (
    id
  , version         
  , percentage
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , p_version         
  , p_percentage
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_FND
  SET     BTG_ALLCTN_RL_FND.version = p_version
  WHERE   BTG_ALLCTN_RL_FND.id      = p_id;    
  
  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    ROLLBACK TO new_member;

    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);    

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveFund
(
  p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
)
AS

  l_btg_allctn_rl_fnd V_BTG_ALLCTN_RL_FND%rowtype;

BEGIN

  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_FND.*
  INTO        l_btg_allctn_rl_fnd
  FROM        V_BTG_ALLCTN_RL_FND
  WHERE       V_BTG_ALLCTN_RL_FND.id = p_id;
  
  IF ('Y' = IsRuleMatched(l_btg_allctn_rl_fnd.ALLOCATION_RULE_ID)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  -- set versioning information
              
  l_btg_allctn_rl_fnd.updated_dt        := SYSTIMESTAMP;
  l_btg_allctn_rl_fnd.effective_from_dt := l_btg_allctn_rl_fnd.updated_dt;      
  l_btg_allctn_rl_fnd.effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_FND_VRSN
  SET     BTG_ALLCTN_RL_FND_VRSN.effective_to_dt  = l_btg_allctn_rl_fnd.updated_dt
  WHERE   BTG_ALLCTN_RL_FND_VRSN.id               = p_id
  AND     BTG_ALLCTN_RL_FND_VRSN.version          = l_btg_allctn_rl_fnd.version;
  
  -- create new version
  
  l_btg_allctn_rl_fnd.version := l_btg_allctn_rl_fnd.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_FND_VRSN
  (
    id
  , version         
  , percentage
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_id
  , l_btg_allctn_rl_fnd.version       
  , l_btg_allctn_rl_fnd.percentage    
  , p_updated_by
  , l_btg_allctn_rl_fnd.updated_dt
  , l_btg_allctn_rl_fnd.effective_from_dt
  , l_btg_allctn_rl_fnd.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_FND
  SET     BTG_ALLCTN_RL_FND.version = l_btg_allctn_rl_fnd.version
  WHERE   BTG_ALLCTN_RL_FND.id      = p_id;        
  
  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    ROLLBACK TO new_member;
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFunds
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND.id
    ,           V_BTG_ALLCTN_RL_FND.version      
    ,           V_BTG_ALLCTN_RL_FND.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_FND.sophis_fund_id 
    ,           V_BTG_ALLCTN_RL_FND.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_FND.percentage
    ,           V_BTG_ALLCTN_RL_FND.created_by
    ,           V_BTG_ALLCTN_RL_FND.created_dt
    ,           V_BTG_ALLCTN_RL_FND.updated_by
    ,           V_BTG_ALLCTN_RL_FND.updated_dt
    ,           V_BTG_ALLCTN_RL_FND.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND.deleted
    FROM        V_BTG_ALLCTN_RL_FND
    INNER JOIN  V_BTG_ALLCTN_RL
    ON          V_BTG_ALLCTN_RL.id                      = V_BTG_ALLCTN_RL_FND.allocation_rule_id
    AND         V_BTG_ALLCTN_RL.deleted                 = 'N'      
    WHERE       V_BTG_ALLCTN_RL_FND.deleted             = 'N'
    AND         V_BTG_ALLCTN_RL_FND.allocation_rule_id  = p_allocation_rule_id
    ORDER BY    V_BTG_ALLCTN_RL_FND.sophis_fund_name;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFundVersions
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id%type
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND_VRSN.id
    ,           V_BTG_ALLCTN_RL_FND_VRSN.version      
    ,           V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_id      
    ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_FND_VRSN.percentage
    ,           V_BTG_ALLCTN_RL_FND_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_FND_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_FND_VRSN      
    WHERE       V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id = p_allocation_rule_id
    ORDER BY    V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFundVersions
(
  p_cursor                    OUT           T_CURSOR
, p_id                        IN            V_BTG_ALLCTN_RL_FND_VRSN.id%type
)
AS
BEGIN
  
  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND_VRSN.id
    ,           V_BTG_ALLCTN_RL_FND_VRSN.version      
    ,           V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id
    ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_id      
    ,           V_BTG_ALLCTN_RL_FND_VRSN.sophis_fund_name
    ,           V_BTG_ALLCTN_RL_FND_VRSN.percentage
    ,           V_BTG_ALLCTN_RL_FND_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_FND_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_FND_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_FND_VRSN      
    WHERE       V_BTG_ALLCTN_RL_FND_VRSN.id = p_id      
    ORDER BY    V_BTG_ALLCTN_RL_FND_VRSN.version;

  NULL;
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE NewFundFolio
(
  p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
, p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
, p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
, p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND_FL.created_by%type
, p_created_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.created_dt%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
)
AS

  l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
  
  l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;

BEGIN
    
    SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
    INTO    l_allocation_rule_id
    FROM    V_BTG_ALLCTN_RL_FND
    WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
    
    IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
    
      RAISE RULE_IS_MATCHED;
      
    END IF;

  BEGIN

    -- see if record already exists
    
    SELECT  V_BTG_ALLCTN_RL_FND_FL.*      
    INTO    l_btg_allctn_rl_fnd_fl
    FROM    V_BTG_ALLCTN_RL_FND_FL
    WHERE   V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id      
    AND     V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
    
    p_created_by := l_btg_allctn_rl_fnd_fl.created_by;
    p_created_dt := l_btg_allctn_rl_fnd_fl.created_dt;
    
    SaveFundFolio
    (
      p_allocation_rule_fund_id      
    , p_sophis_folio_id
    , p_version
    , p_include_exclude
    , p_updated_by
    , p_updated_dt
    , p_effective_from_dt
    , p_effective_to_dt
    );
    
  EXCEPTION
  
    WHEN NO_DATA_FOUND THEN

      SAVEPOINT new_member;      
      
      -- set versioning information
      
      p_version           := 1;    
      p_created_dt        := SYSTIMESTAMP;   
      p_updated_dt        := p_created_dt;
      p_effective_from_dt := p_created_dt;      
      p_effective_to_dt   := EOT;
      
      -- create new ID
      
      INSERT INTO BTG_ALLCTN_RL_FND_FL_ID
      (
        allocation_rule_fund_id        
      , sophis_folio_id
      , created_by
      , created_dt
      )
      VALUES
      (
        p_allocation_rule_fund_id        
      , p_sophis_folio_id
      , p_created_by
      , p_created_dt
      );
      
      -- create new version
      
      INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
      (
        allocation_rule_fund_id        
      , sophis_folio_id
      , version
      , include_exclude
      , updated_by
      , updated_dt
      , effective_from_dt
      , effective_to_dt
      , deleted
      )
      VALUES
      (
        p_allocation_rule_fund_id        
      , p_sophis_folio_id
      , p_version     
      , p_include_exclude
      , p_updated_by
      , p_updated_dt
      , p_effective_from_dt
      , p_effective_to_dt
      , 'N'
      );
      
      -- make new version active record
      
      INSERT INTO BTG_ALLCTN_RL_FND_FL
      (
        allocation_rule_fund_id        
      , sophis_folio_id
      , version
      )
      VALUES
      (
        p_allocation_rule_fund_id        
      , p_sophis_folio_id
      , p_version
      );
    
      COMMIT;
      
  END;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE SaveFundFolio
(
  p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
, p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
, p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
, p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type  
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
, p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
, p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
, p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
)
AS

  l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
  
  l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;

BEGIN

  SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
  INTO    l_allocation_rule_id
  FROM    V_BTG_ALLCTN_RL_FND
  WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
  
  IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
    
  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_FND_FL.*
  INTO        l_btg_allctn_rl_fnd_fl
  FROM        V_BTG_ALLCTN_RL_FND_FL    
  WHERE       V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
  AND         V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
  
  -- set versioning information
              
  p_updated_dt        := SYSTIMESTAMP;
  p_effective_from_dt := p_updated_dt;      
  p_effective_to_dt   := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_FND_FL_VRSN
  SET     BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt         = p_updated_dt
  WHERE   BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id    
  AND     BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
  AND     BTG_ALLCTN_RL_FND_FL_VRSN.version                 = l_btg_allctn_rl_fnd_fl.version;
  
  -- create new version
  
  p_version := l_btg_allctn_rl_fnd_fl.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
  (
    allocation_rule_fund_id    
  , sophis_folio_id
  , version
  , include_exclude
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_allocation_rule_fund_id    
  , p_sophis_folio_id
  , p_version     
  , p_include_exclude
  , p_updated_by
  , p_updated_dt
  , p_effective_from_dt
  , p_effective_to_dt
  , 'N'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_FND_FL
  SET     BTG_ALLCTN_RL_FND_FL.version                  = p_version
  WHERE   BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
  AND     BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
  
  COMMIT;

EXCEPTION
    
  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE RemoveFundFolio
(
  p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
, p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
, p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
)
AS

  l_allocation_rule_id V_BTG_ALLCTN_RL.id%type;
  
  l_btg_allctn_rl_fnd_fl V_BTG_ALLCTN_RL_FND_FL%rowtype;

BEGIN

  SELECT  V_BTG_ALLCTN_RL_FND.allocation_rule_id
  INTO    l_allocation_rule_id
  FROM    V_BTG_ALLCTN_RL_FND
  WHERE   V_BTG_ALLCTN_RL_FND.id = p_allocation_rule_fund_id;
  
  IF ('Y' = IsRuleMatched(l_allocation_rule_id)) THEN
  
    RAISE RULE_IS_MATCHED;
    
  END IF;
  
  SAVEPOINT new_member;
  
  -- get latest version
  
  SELECT      V_BTG_ALLCTN_RL_FND_FL.*
  INTO        l_btg_allctn_rl_fnd_fl
  FROM        V_BTG_ALLCTN_RL_FND_FL    
  WHERE       V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
  AND         V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;
  
  -- set versioning information
              
  l_btg_allctn_rl_fnd_fl.updated_dt         := SYSTIMESTAMP;
  l_btg_allctn_rl_fnd_fl.effective_from_dt  := l_btg_allctn_rl_fnd_fl.updated_dt;      
  l_btg_allctn_rl_fnd_fl.effective_to_dt    := EOT;
  
  -- update existing version
  
  UPDATE  BTG_ALLCTN_RL_FND_FL_VRSN
  SET     BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt         = l_btg_allctn_rl_fnd_fl.updated_dt
  WHERE   BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id    
  AND     BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
  AND     BTG_ALLCTN_RL_FND_FL_VRSN.version                 = l_btg_allctn_rl_fnd_fl.version;
  
  -- create new version
  
  l_btg_allctn_rl_fnd_fl.version := l_btg_allctn_rl_fnd_fl.version + 1;
        
  INSERT INTO BTG_ALLCTN_RL_FND_FL_VRSN
  (
    allocation_rule_fund_id    
  , sophis_folio_id
  , version
  , include_exclude
  , updated_by
  , updated_dt
  , effective_from_dt
  , effective_to_dt
  , deleted
  )
  VALUES
  (
    p_allocation_rule_fund_id    
  , p_sophis_folio_id
  , l_btg_allctn_rl_fnd_fl.version     
  , l_btg_allctn_rl_fnd_fl.include_exclude
  , p_updated_by
  , l_btg_allctn_rl_fnd_fl.updated_dt
  , l_btg_allctn_rl_fnd_fl.effective_from_dt
  , l_btg_allctn_rl_fnd_fl.effective_to_dt
  , 'Y'
  );
  
  -- make new version active record
  
  UPDATE  BTG_ALLCTN_RL_FND_FL
  SET     BTG_ALLCTN_RL_FND_FL.version                  = l_btg_allctn_rl_fnd_fl.version
  WHERE   BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id    
  AND     BTG_ALLCTN_RL_FND_FL.sophis_folio_id          = p_sophis_folio_id;     
  
  COMMIT;

EXCEPTION

  WHEN RULE_IS_MATCHED THEN
  
    raise_application_error(-20111, 'Rule has been matched.');
    
  WHEN OTHERS THEN

    ROLLBACK TO new_member;

    raise_application_error(-20011, sqlerrm);

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFundFolios
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
, p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id      
    ,           V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id      
    ,           V_BTG_ALLCTN_RL_FND_FL.version
    ,           V_BTG_ALLCTN_RL_FND_FL.sophis_folio_name
    ,           V_BTG_ALLCTN_RL_FND_FL.include_exclude      
    ,           V_BTG_ALLCTN_RL_FND_FL.created_by
    ,           V_BTG_ALLCTN_RL_FND_FL.created_dt
    ,           V_BTG_ALLCTN_RL_FND_FL.updated_by
    ,           V_BTG_ALLCTN_RL_FND_FL.updated_dt
    ,           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND_FL.deleted
    FROM        V_BTG_ALLCTN_RL_FND_FL
    INNER JOIN  V_BTG_ALLCTN_RL_FND
    ON          V_BTG_ALLCTN_RL_FND.id                          = V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id
    AND         V_BTG_ALLCTN_RL_FND.deleted                     = 'N'
    INNER JOIN  V_BTG_ALLCTN_RL
    ON          V_BTG_ALLCTN_RL.id                              = V_BTG_ALLCTN_RL_FND.allocation_rule_id
    AND         V_BTG_ALLCTN_RL.deleted                         = 'N'
    WHERE       V_BTG_ALLCTN_RL_FND_FL.deleted                  = 'N'
    AND         V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id  = p_allocation_rule_fund_id      
    AND         V_BTG_ALLCTN_RL_FND_FL.include_exclude          = p_include_exclude
    ORDER BY    V_BTG_ALLCTN_RL_FND_FL.sophis_folio_name;

END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFundFolioVersions
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
, p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.version
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_name
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_FND_FL_VRSN      
    WHERE       V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id      
    AND         V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id         = p_sophis_folio_id
    ORDER BY    V_BTG_ALLCTN_RL_FND_FL_VRSN.version;
    
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
PROCEDURE GetFundFolioVersions
(
  p_cursor                    OUT           T_CURSOR
, p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
, p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude%type
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT      V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.version
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_name
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude      
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_by
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.created_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_by
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.updated_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_to_dt
    ,           V_BTG_ALLCTN_RL_FND_FL_VRSN.deleted
    FROM        V_BTG_ALLCTN_RL_FND_FL_VRSN          
    WHERE       V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id = p_allocation_rule_fund_id      
    AND         V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude         = p_include_exclude
    ORDER BY    V_BTG_ALLCTN_RL_FND_FL_VRSN.effective_from_dt;
    
END;

-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************  
FUNCTION CheckUserCredentials
(
  p_name                    IN            V_BTG_ALLCTN_RL_USR.name%type
, p_password                IN            V_BTG_ALLCTN_RL_USR.password%type
, p_id                      OUT           V_BTG_ALLCTN_RL_USR.id%type
, p_is_administrator        OUT           CHAR
)
RETURN CHAR -- Returns 'Y' or 'N'
AS
BEGIN
  
  SELECT      V_BTG_ALLCTN_RL_USR.id
  ,           V_BTG_ALLCTN_RL_USR.is_administrator      
  INTO        p_id
  ,           p_is_administrator
  FROM        V_BTG_ALLCTN_RL_USR    
  WHERE       V_BTG_ALLCTN_RL_USR.deleted   = 'N'
  AND         V_BTG_ALLCTN_RL_USR.name      = p_name
  AND         V_BTG_ALLCTN_RL_USR.password  = p_password;
  
  RETURN 'Y';
  
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    
    RETURN 'N';   
  
END;
  
-- *****************************************************************
-- Description:
  --
-- Author:          M.Canning
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 AUG 2012      M.Canning     Created.
-- *****************************************************************
FUNCTION CheckAllocationRule
(
  p_block_refcon          IN      HISTOMVTS.refcon%TYPE
) 
RETURN CHAR -- Returns 'Y' or 'N'
AS
  p_precision INT := 3;
 
  l_execution_exists      NUMBER;
  l_sophis_user_exists    NUMBER;
  l_match                 CHAR    := 'N';

BEGIN

  SELECT      COUNT(*)
  INTO        l_execution_exists
  FROM        HISTOMVTS
  WHERE       HISTOMVTS.refcon = p_block_refcon;

  SELECT      COUNT(*)
  INTO        l_sophis_user_exists
  FROM        HISTOMVTS
  JOIN        V_BTG_ALLCTN_RL_SPHS_USR
  ON          V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id = HISTOMVTS.operateur
  WHERE       HISTOMVTS.refcon = p_block_refcon;
  
  IF (l_execution_exists = 1 AND l_sophis_user_exists = 1)
  THEN
  BEGIN
      FOR match IN
      (
        SELECT
              RT_RESULT.*
          FROM
          (
	SELECT
			RT_MATCH.rule_id
		,	RT_MATCH.execution_id
		,	RT_MATCH.rule_version
		,	CASE WHEN (	(	RT_MATCH.instrument_type = 'O' 
								AND RT_MATCH.instrument_allotment IS NOT NULL 
								AND RT_MATCH.instrument_allotment IN (25, 26, 1353))				-- bonds (gov/corp/euro mbs)
						OR	(RT_MATCH.instrument_type = 'A')										-- shares	
						OR	(RT_MATCH.instrument_type = 'G')										-- CFDs
						OR	(RT_MATCH.instrument_type IN ('D', 'M') 
								AND RT_MATCH.instrument_allotment IS NOT NULL 
								AND RT_MATCH.instrument_allotment IN (2, 10, 1041, 1060))			-- derivatives / options (otc/listed/vol/dividend)
						OR 	(RT_MATCH.instrument_type IN ('D')
								AND RT_MATCH.instrument_allotment IS NOT NULL 
								AND RT_MATCH.instrument_allotment IN (9))							-- convertible bonds
						OR	(RT_MATCH.instrument_type IN ('F') 
								AND (	RT_MATCH.instrument_allotment IS NULL 
										OR RT_MATCH.instrument_allotment NOT IN (33)))				-- futures (not FRA)
					)
			THEN																					-- allow best-fit match
				CASE WHEN (SUM(RT_MATCH.match_perfect) = 0)
				THEN 'Y'
				ELSE 
					CASE WHEN (SUM(RT_MATCH.match_best) = 0)
					THEN 'L'
					ELSE 'N' 
					END
				END
			ELSE -- perfect matches only
				CASE WHEN (SUM(RT_MATCH.match_perfect) = 0)
				THEN 'Y'
				ELSE 'N' 
				END
			END																						AS pass
		FROM
		(	
------------------------------------------------------------------------- debugging single trade
			SELECT
				-- allocation is perfect
				CASE WHEN (		RT_COMPARE.allocation_amount = RT_COMPARE.perfect_allocation 
							-- call it a perfect match if the actual proportion matches the rule to 4dp (percentage to 2dp)
							OR	ROUND(RT_COMPARE.rule_fund_proportion, p_precision) = ROUND(RT_COMPARE.actual_proportion, p_precision)	
				)						
				THEN 0
				ELSE 1 
				END																					AS match_perfect
				-- allocation is nearest increment to best fit, or min piece
			,	CASE WHEN (	(	RT_COMPARE.allocation_amount = RT_COMPARE.best_fit
								-- roll up from previous allocations            
								OR (	RT_COMPARE.allocation_amount = (RT_COMPARE.best_fit + RT_COMPARE.best_diff)
								--AND	RT_COMPARE.max_proportion = RT_COMPARE.rule_fund_proportion	-- enforce overflow to largest proportion
								AND RT_COMPARE.all_increments_valid = 0)						
							)
							AND RT_COMPARE.actual_equal = 1
				) 
				THEN 0		
				ELSE 1
				END																					AS match_best
			,	RT_COMPARE.*	-- all columns from below
			FROM
			(
				SELECT
					-- does the allocation sum equal the execution
					CASE WHEN (COALESCE(RT_LAST.execution_amount - RT_LAST.last_actual, 0) > 0) 
					THEN 0
					ELSE 1 
					END																				AS actual_equal
				,	COALESCE(RT_LAST.execution_amount - RT_LAST.last_actual, 0)						AS actual_diff
					-- does the best-fit sum equal the execution
				,	CASE WHEN COALESCE(RT_LAST.execution_amount - RT_LAST.last_best, 0) > 0 
					THEN 0
					ELSE 1 
					END																				AS best_equal
				,	COALESCE(RT_LAST.execution_amount - RT_LAST.last_best, 0)						AS best_diff
				,	RT_LAST.*
				FROM
				(
					SELECT
						-- sum allocation values over the partition
						LAST_VALUE(RT_SUM.sum_actual)
						OVER(	PARTITION BY RT_SUM.execution_id, RT_SUM.rule_id
								ORDER BY RT_SUM.rule_id, RT_SUM.rule_fund_proportion 
								RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
						)																			AS last_actual
						-- sum best-fit values over the partition
					,	LAST_VALUE(RT_SUM.sum_best)
						OVER(	PARTITION BY RT_SUM.execution_id, RT_SUM.rule_id
								ORDER BY RT_SUM.rule_id, RT_SUM.rule_fund_proportion 
								RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
						)																			AS last_best
						-- get the largest proportion from the rule
					,	MAX(RT_SUM.rule_fund_proportion)
						OVER(	PARTITION BY RT_SUM.execution_id, RT_SUM.rule_id
								ORDER BY RT_SUM.rule_id
								RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
						)																			AS max_proportion
						-- get a flag inidicating whether all allocations are increment multiples
					,	SUM(RT_SUM.valid_increment)
						OVER(	PARTITION BY RT_SUM.execution_id, RT_SUM.rule_id
								ORDER BY RT_SUM.rule_id
								RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
						)																			AS all_increments_valid
					,	RT_SUM.*
					FROM	 
					(
						SELECT 
							RT_BEST.*
						,	SUM(RT_BEST.allocation_amount)
							OVER (	PARTITION BY RT_BEST.execution_id, RT_BEST.rule_id
									ORDER BY RT_BEST.rule_id, RT_BEST.rule_fund_proportion
							)																		AS sum_actual
						,	SUM(RT_BEST.best_fit)
							OVER (	PARTITION BY RT_BEST.execution_id, RT_BEST.rule_id
									ORDER BY RT_BEST.rule_id, RT_BEST.rule_fund_proportion
							)																		AS sum_best
						,	RT_BEST.best_fit / RT_BEST.execution_amount								AS best_proportion
						FROM	 
						(
							SELECT
								RULE_INC.*
------------------------------------------------------------------------- best-fit: where the magic happens
							,	COALESCE(
									-- min piece is not satisfied by allocation
									CASE WHEN RULE_INC.valid_min_piece = 1 
									THEN
										-- perfect allocation satisfies min piece and increment
										CASE WHEN RULE_INC.valid_perfect_min_piece = 0 AND RULE_INC.valid_perfect_increment = 0
										THEN RULE_INC.perfect_allocation
										ELSE
											-- rounding up to the min piece is close than down 
											CASE WHEN RULE_INC.piece_up_diff <= RULE_INC.piece_down_diff
											THEN RULE_INC.signed_piece
											ELSE 0
											END
										END
									ELSE
										-- allocation satisfies min piece
										-- allocation is increment multiple
										-- 		AND (the allocation is the min piece AND the piece is closer to perfect) OR the allocation is perfect 
										CASE WHEN (		RULE_INC.valid_increment = 0
														AND (	(	ABS(RULE_INC.allocation_amount) = RULE_INC.min_piece
																	AND RULE_INC.piece_up_diff <= RULE_INC.piece_down_diff) 
																OR	RULE_INC.perfect_diff = 0
														)
											)
											THEN RULE_INC.allocation_amount
											ELSE
												-- round 0.5 up 
												CASE WHEN RULE_INC.increment_down_diff < RULE_INC.increment_up_diff
												THEN RULE_INC.increment_down
												ELSE RULE_INC.increment_up 
												END
											END
									END,
								0)																	AS best_fit
-------------------------------------------------------------------------
							FROM
							(
								SELECT
									RULE_TRADE.*
								,	ABS(RULE_TRADE.allocation_amount - RULE_TRADE.perfect_allocation)
																									AS perfect_diff 
									-- if magnitude of perfect allocation is less than the min piece 			
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation >= RULE_TRADE.min_piece
									THEN null
									ELSE RULE_TRADE.signed_piece 
									END																AS piece_up
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation >= RULE_TRADE.min_piece
									THEN null
									ELSE ABS(RULE_TRADE.signed_piece - RULE_TRADE.perfect_allocation)
									END																AS piece_up_diff
									-- piece down
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation >= RULE_TRADE.min_piece
									THEN null
									--ELSE RULE_TRADE.signed_piece - RULE_TRADE.signed_increment
									ELSE 0
									END																AS piece_down
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation >= RULE_TRADE.min_piece
									THEN null
									ELSE
										ABS(RULE_TRADE.abs_perfect_allocation)
									END																AS piece_down_diff

									-- round up (diverge from zero) to the nearest integer multiple of the increment
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation <= RULE_TRADE.min_piece
									THEN null
									ELSE CEIL(RULE_TRADE.abs_perfect_allocation / RULE_TRADE.min_increment) * RULE_TRADE.signed_increment 
									END																AS increment_up
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation <= RULE_TRADE.min_piece
									THEN null
									ELSE ABS(	(CEIL(RULE_TRADE.abs_perfect_allocation / RULE_TRADE.min_increment) * RULE_TRADE.signed_increment)
											 	- RULE_TRADE.perfect_allocation)
									END																AS increment_up_diff
									-- round down (converge towards zero) to the nearest integer multiple of the incrmeent 
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation <= RULE_TRADE.min_piece
									THEN null
									ELSE FLOOR(RULE_TRADE.abs_perfect_allocation / RULE_TRADE.min_increment) * RULE_TRADE.signed_increment
									END																AS increment_down
								,	CASE WHEN RULE_TRADE.abs_perfect_allocation <= RULE_TRADE.min_piece
									THEN null
									ELSE MOD(RULE_TRADE.abs_perfect_allocation - RULE_TRADE.min_piece, RULE_TRADE.min_increment)
									END																AS increment_down_diff									
								FROM
								(
									SELECT
										RULE.rule_id
									,	RULE.rule_version
									,	TRADE.execution_id
									,	TRADE.allocation_id
									,	TRADE.instrument
									,	TRADE.instrument_allotment
									,	TRADE.instrument_type
									,	TRADE.min_piece
									,	CASE WHEN TRADE.execution_amount < 0
										THEN (-1 * TRADE.min_piece)
										ELSE TRADE.min_piece
										END															AS signed_piece
									,	TRADE.min_increment
									,	CASE WHEN TRADE.execution_amount < 0
										THEN (-1 * TRADE.min_increment)
										ELSE TRADE.min_increment
										END															AS signed_increment
									,	RULE.rule_fund_name
									,	TRADE.folio_id
									,	TRADE.execution_quantity
									,	TRADE.execution_amount
									,	COALESCE(TRADE.allocation_quantity, 0)						AS allocation_quantity
									,	COALESCE(TRADE.allocation_amount, 0)						AS allocation_amount
									,	RULE.rule_fund_proportion
									,	TRADE.percentage											AS actual_proportion
									,	CASE WHEN (ABS(TRADE.allocation_amount) >= TRADE.min_piece) 
										THEN 0 
										ELSE 1 
										END															AS valid_min_piece
									,	CASE WHEN (MOD(TRADE.allocation_amount, TRADE.min_increment) = 0)
										THEN 0
										ELSE 1
										END															AS valid_increment
									,	TRADE.execution_amount * RULE.rule_fund_proportion			AS perfect_allocation
									,	ABS(TRADE.execution_amount * RULE.rule_fund_proportion)		AS abs_perfect_allocation
									,	CASE WHEN (ABS(TRADE.execution_amount) * RULE.rule_fund_proportion >= TRADE.min_piece) 
										THEN 0 
										ELSE 1
										END															AS valid_perfect_min_piece
									,	CASE WHEN MOD(TRADE.execution_amount * RULE.rule_fund_proportion, TRADE.min_increment) = 0
										THEN 0
										ELSE 1
										END															AS valid_perfect_increment
									FROM
									(
										SELECT	 
											EXECUTION.REFCON										AS execution_id
											,	EXECUTION.quantite									AS execution_quantity
											,	CASE
													WHEN ( 	INSTRUMENT.type = 'O' 
															OR (INSTRUMENT.type = 'D' AND INSTRUMENT.affectation = 9))
													THEN EXECUTION.quantite * INSTRUMENT.nominal
													ELSE EXECUTION.quantite 
													END	 
																									AS execution_amount 
											,	ALLOCATION.entite									AS fund_id
											,	ALLOCATION.opcvm									AS folio_id
											,	ALLOCATION.REFCON									AS allocation_id
											,	ALLOCATION.quantite									AS allocation_quantity
											,	CASE
													WHEN ( 	INSTRUMENT.type = 'O' 
															OR (INSTRUMENT.type = 'D' AND INSTRUMENT.affectation = 9))
													THEN ALLOCATION.quantite * INSTRUMENT.nominal
													ELSE ALLOCATION.quantite 
													END
																									AS allocation_amount 
											,	ROUND(ABS(ALLOCATION.quantite) / ABS(EXECUTION.quantite), p_precision)
																									AS percentage			 
											,	EXECUTION.dateneg									AS trade_date
											,	EXECUTION.OPERATEUR									AS trade_user_id
											,	INSTRUMENT.reference								AS instrument
											,	INSTRUMENT.affectation								AS instrument_allotment
											,	INSTRUMENT.type										AS instrument_type
											,	COALESCE(INSTRUMENT.MINIMUMPIECE, 1)				AS min_piece
											,	COALESCE(
													NULLIF(	
														CASE 
															WHEN ( 	INSTRUMENT.type = 'O' -- bonds or convertible bonds: use min inc column
																	OR (INSTRUMENT.type = 'D' AND INSTRUMENT.affectation = 9)
															)	
															THEN COALESCE(INSTRUMENT.LOWESTINCREMENT, 0)
															ELSE 
																CASE 
																	WHEN (	INSTRUMENT.type IN ('D', 'F', 'M') -- option / futures / derivatives: use 1
																			AND (INSTRUMENT.affectation IS NULL OR INSTRUMENT.affectation NOT IN (33))
																	)
																	THEN 1
																	ELSE COALESCE(NULLIF(INSTRUMENT.quotite, 0), 1) -- default to 1
																	END
															END											
														, 0)
													, 1)											AS min_increment
										FROM HISTOMVTS EXECUTION

										INNER JOIN TA_BLOCK_TO_GENERATED
											ON TA_BLOCK_TO_GENERATED.block_id = EXECUTION.refcon

										INNER JOIN HISTOMVTS ALLOCATION
											ON ALLOCATION.refcon = TA_BLOCK_TO_GENERATED.generated_id

										INNER JOIN TITRES INSTRUMENT
											ON INSTRUMENT.SICOVAM = EXECUTION.SICOVAM

										INNER JOIN BUSINESS_EVENTS BE
											ON BE.ID = EXECUTION.TYPE
											AND	BE.COMPTA = 1

										WHERE EXECUTION.refcon = p_block_refcon	 
										AND	EXECUTION.BACKOFFICE NOT IN (192, 11, 13, 17, 26, 27, 220, 248, 252)
									) TRADE
									INNER JOIN		 
									(	
										SELECT
											V_BTG_ALLCTN_RL.id										AS rule_id
										,	V_BTG_ALLCTN_RL.NAME									AS rule_name
										,	V_BTG_ALLCTN_RL.version									AS rule_version
										,	V_BTG_ALLCTN_RL_FND.SOPHIS_FUND_ID						AS rule_fund_id
										,	V_BTG_ALLCTN_RL_FND.SOPHIS_FUND_NAME					AS rule_fund_name
										,	ROUND(V_BTG_ALLCTN_RL_FND.PERCENTAGE, p_precision)		AS rule_fund_proportion
										,	V_BTG_ALLCTN_RL_FND_FL.SOPHIS_FOLIO_ID					AS rule_folio_root
										,	V_BTG_ALLCTN_RL.active_from_dt							AS active_from_dt
										,	V_BTG_ALLCTN_RL.active_to_dt							AS active_to_dt
										,	V_BTG_ALLCTN_RL_TRDR.sophis_user_id						AS rule_user_id

										FROM V_BTG_ALLCTN_RL

										INNER JOIN V_BTG_ALLCTN_RL_TRDR
											ON V_BTG_ALLCTN_RL_TRDR.allocation_rule_id = V_BTG_ALLCTN_RL.id
											AND V_BTG_ALLCTN_RL_TRDR.deleted = 'N'

										INNER JOIN V_BTG_ALLCTN_RL_FND
											ON V_BTG_ALLCTN_RL_FND.allocation_rule_id = V_BTG_ALLCTN_RL.id
											AND V_BTG_ALLCTN_RL_FND.deleted = 'N'							

										INNER JOIN V_BTG_ALLCTN_RL_FND_FL
											ON V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id = V_BTG_ALLCTN_RL_FND.id
											AND V_BTG_ALLCTN_RL_FND_FL.deleted = 'N'		

										WHERE V_BTG_ALLCTN_RL.deleted = 'N'
											AND V_BTG_ALLCTN_RL.active	= 'Y'
										ORDER BY V_BTG_ALLCTN_RL.id, V_BTG_ALLCTN_RL_FND.PERCENTAGE ASC
									) RULE
									ON TRADE.fund_id = RULE.rule_fund_id
										AND TRADE.trade_user_id = RULE.rule_user_id
										AND BTG_ALLCTN_RL_FL_IN_HRRCHY(RULE.rule_folio_root, TRADE.folio_id) = 1
										AND RULE.active_from_dt <= TRADE.trade_date
										AND RULE.active_to_dt >= TRADE.trade_date
									ORDER BY TRADE.execution_id, TRADE.allocation_id
								) RULE_TRADE 
								WHERE RULE_TRADE.execution_id IS NOT NULL
							) RULE_INC 
						) RT_BEST
						ORDER BY RT_BEST.rule_id, RT_BEST.rule_fund_proportion
					) RT_SUM
				) RT_LAST
			) RT_COMPARE
------------------------------------------------------------------------- detail testing
		) RT_MATCH
		GROUP BY RT_MATCH.execution_id, RT_MATCH.rule_id, RT_MATCH.instrument_allotment, RT_MATCH.instrument_type, RT_MATCH.rule_version, RT_MATCH.execution_id          ) RT_RESULT

          WHERE RT_RESULT.PASS IN ('Y', 'L')
      )
      LOOP
              INSERT INTO BTG_ALLCTN_RL_CHCK_HSTRY
              (
                  sophis_transaction_id
              ,   effective_dt
              ,   allocation_rule_id
              ,   allocation_rule_version
              )
              VALUES
              (
                  p_block_refcon
              ,   SYSTIMESTAMP
              ,   match.rule_id
              ,   match.rule_version
              );

          IF match.pass = 'Y'
          THEN
              l_match := 'Y';
          ELSE 
              IF match.pass = 'L' AND l_match = 'N'
              THEN
--                        l_match := 'L';
                  l_match := 'Y';         -- return only Y/N for now
              END IF;
          END IF;
      END LOOP;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          l_match := 'N';
      END;
 
  END IF;
  
  IF l_match = 'N'
  THEN
      INSERT INTO BTG_ALLCTN_RL_CHCK_HSTRY
      (
          sophis_transaction_id
      ,   effective_dt
      ,   allocation_rule_id
      ,   allocation_rule_version
      )
      VALUES
      (
          p_block_refcon
      ,   SYSTIMESTAMP
      ,   -1
      ,   -1
      );
  END IF;
  
  RETURN l_match;    
  
EXCEPTION WHEN OTHERS THEN
  raise_application_error(-20011, sqlerrm);  
  RETURN l_match;
END;

-- *****************************************************************
-- Description: Load all allocation rules in denormalised for for 
-- specified user name
-- Author:          J.Coldridge
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 21 OCT 2013      J.Coldridge     Created.
-- *****************************************************************
PROCEDURE GetAllocationRulesForUser
(
    p_username                      IN      RISKUSERS.name%TYPE := NULL
  , p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_cursor                        OUT     SYS_REFCURSOR
)
AS
BEGIN
 OPEN p_cursor FOR
  SELECT DISTINCT
           U.ident                                        AS USER_ID          -- 0
         , U.name                                         AS USER_NAME
         , R.id                                           AS RULE_ID
         , R.name                                         AS RULE_NAME
         , R.comm                                         AS RULE_COMMENT
         , RP.folio                                       AS FOLIO_IDENT      -- 5
         , F.name                                         AS FOLIO_NAME
         ,( SELECT REVERSE(SYS_CONNECT_BY_PATH(REVERSE(FOLIO.NAME), ':')) 
            FROM FOLIO 
            WHERE CONNECT_BY_ISLEAF = 1 
            START WITH FOLIO.ident = RP.folio 
            CONNECT BY PRIOR FOLIO.MGR = FOLIO.ident
            AND FOLIO.ident != 1 )                        AS FOLIO_PATH
         , RP.prop                                        AS PROPORTION
         , TIERS.ident                                    AS FUND_ID  
         , TIERS.name                                     AS FUND_NAME        -- 10
         , FIRST_VALUE(DPS_SPECIFIC.DEPOSITARY_ID) 
              OVER (PARTITION BY RP.folio 
                    ORDER BY DPS_SPECIFIC.position)       AS DEPOSITARY_ID    
         , FIRST_VALUE(DPS_SPECIFIC.DEPOSITARY_NAME) 
              OVER (PARTITION BY RP.folio 
                    ORDER BY DPS_SPECIFIC.position)       AS DEPOSITARY_NAME
         
      FROM RISKUSERS U 
      INNER JOIN TA_RULES R 
          ON U.ident = R.user_id
      INNER JOIN TA_RULES_FP_PROP RP 
          ON R.id = RP.id
      INNER JOIN FOLIO F
          ON F.ident = RP.folio
      INNER JOIN TIERS
          ON TIERS.ident = F.entite
      JOIN TITRES FI
          ON FI.code_emet = F.entite 
      
      LEFT JOIN 
      (   SELECT 
                depositary    AS DEPOSITARY_ID
              , TIERS.NAME    AS DEPOSITARY_NAME
              , trader
              , fund
              , position
          FROM BTG_DEPOSITARY_SELECTOR DPS
          JOIN TITRES I
              ON (I.affectation = DPS.allotment OR DPS.allotment <= 0)
              AND (I.DEVISECTT = DPS.currency OR DPS.currency <= 0)
              AND I.sicovam = p_sicovam
          JOIN TIERS 
              ON TIERS.ident = DPS.DEPOSITARY
      ) DPS_SPECIFIC
      ON (DPS_SPECIFIC.fund = FI.sicovam OR DPS_SPECIFIC.fund <= 0)
          AND (DPS_SPECIFIC.trader = U.ident OR DPS_SPECIFIC.trader <= 0)
      WHERE 
          U.NAME = p_username;
END;

  PROCEDURE GetAllocationRuleReasons
  (
    p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    OPEN p_cursor FOR
        SELECT 
            ID                
          , REASON                AS DESCRIPTION
          , RFT                   AS REQUIRE_FREE_TEXT
        FROM BTG_ALLCTN_RL_PRDFND_RSN 
        WHERE STATUS = 1
        ORDER BY "ORDER";

  END GetAllocationRuleReasons;

  PROCEDURE SetAllocationRuleComment
  (
    p_refcon                        IN      HISTOMVTS.REFCON%type
  , p_userId                        IN      RISKUSERS.IDENT%type  
  , p_reasonId                      IN      BTG_ALLCTN_RL_PRDFND_RSN.ID%type
  , p_comment                       IN      BTG_ALLCTN_RL_CMMNT.COMMENT%type
  )
  AS
  BEGIN
    INSERT INTO BTG_ALLCTN_RL_CMMNT
    (
      REFCON
    , USERID
    , REASON
    , "COMMENT"
    )
    VALUES
    (
      p_refcon
    , p_userId
    , p_reasonId
    , p_comment
    );
  END SetAllocationRuleComment;

  PROCEDURE GetBreachConfiguration
  (
    p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN     
    OPEN p_cursor FOR
      SELECT 
          PREFNOM
        , PREFVALEUR 
      FROM RISKPREF 
      WHERE PREFNOM IN
      ( 'ReviewRequiredStatus'
      , 'MinWordCount'
      , 'MinWordLenght'
      , 'PostAllocationReviewRight'
      );    
  END GetBreachConfiguration;

  PROCEDURE GetAllocationRuleFolioTree
  (
    p_username                      IN      RISKUSERS.name%TYPE := NULL
  , p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
      OPEN p_cursor FOR
          SELECT
              USER_RULES.USER_ID                                                  -- 0
             ,p_username                              AS USER_NAME
             ,USER_RULES.RULE_ID
             ,USER_RULES.RULE_NAME
             ,USER_RULES.RULE_COMMENT
             ,USER_RULE_FOLIOS.FOLIO_ID                                           -- 5
             ,USER_RULE_FOLIOS.FOLIO_NAME
             ,USER_RULE_FOLIOS.FOLIO_PATH
             ,USER_RULES.ALLOCATION_PROPORTION
             ,USER_RULE_FOLIOS.FUND_ID
             ,USER_RULE_FOLIOS.FUND_NAME                                          -- 10
             ,FOLIO_DEPOSITARY.DEPOSITARY_ID
             ,FOLIO_DEPOSITARY.DEPOSITARY_NAME
             ,USER_RULE_FOLIOS.RULE_FOLIO_ID                                      
             ,INSTRUMENT_FUND_POSITION.ORIG_FACE      AS INSTRUMENT_POSITION      -- 14
          FROM
          (
              SELECT
                  RISKUSERS.ident                     AS USER_ID
                 ,TA_RULES.id                         AS RULE_ID
                 ,TA_RULES.name                       AS RULE_NAME
                 ,TA_RULES.comm                       AS RULE_COMMENT
                 ,TA_RULES_FP_PROP.prop               AS ALLOCATION_PROPORTION
                 ,TA_RULES_FP_PROP.folio              AS ALLOCATION_FOLIO_ID
              FROM TA_RULES
              INNER JOIN TA_RULES_FP_PROP  
                  ON TA_RULES_FP_PROP.ID = TA_RULES.id  
              INNER JOIN RISKUSERS
                  ON RISKUSERS.ident = TA_RULES.user_id
              WHERE riskusers.NAME = p_username
          ) USER_RULES
          -- join folio tree
          JOIN         
          (
              SELECT CONNECT_BY_ROOT(FOLIO.ident)     AS RULE_FOLIO_ID
              , FOLIO.ident                           AS FOLIO_ID
              , FOLIO.mgr                             AS FOLIO_PARENT_ID
              , FOLIO.name                            AS FOLIO_NAME
              ,( SELECT REVERSE(SYS_CONNECT_BY_PATH(REVERSE(F.NAME), '\')) 
                FROM FOLIO F
                WHERE CONNECT_BY_ISLEAF = 1 
                START WITH F.ident = FOLIO.ident 
                CONNECT BY PRIOR F.MGR = F.ident
                    AND F.MGR NOT IN (1))  AS FOLIO_PATH
              ,FOLIO_ENTITY.ident                     AS FUND_ID
              ,FOLIO_ENTITY.name                      AS FUND_NAME                              
              FROM FOLIO
              JOIN TIERS FOLIO_ENTITY
                  ON FOLIO_ENTITY.ident = FOLIO.entite            
              START WITH FOLIO.ident IN 
              (
                  SELECT TA_RULES_FP_PROP.folio 
                  FROM TA_RULES
                  INNER JOIN TA_RULES_FP_PROP  
                      ON TA_RULES_FP_PROP.id = TA_RULES.id  
                  INNER JOIN RISKUSERS
                      ON RISKUSERS.ident = TA_RULES.user_id
                  WHERE RISKUSERS.name = p_username
              )
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
          ) USER_RULE_FOLIOS
              ON USER_RULE_FOLIOS.rule_folio_id = USER_RULES.ALLOCATION_FOLIO_ID
          -- join depositary selection
          LEFT JOIN
          (
              SELECT DISTINCT
                  DPS_RULE_MATCH.folio_id
                 ,DPS_RULE_MATCH.folio_name
                 ,FIRST_VALUE(DPS_RULE_MATCH.depositary_id) 
                  OVER (
                      PARTITION BY DPS_RULE_MATCH.folio_id 
                      ORDER BY DPS_RULE_MATCH.rule_order
                  )                                           AS DEPOSITARY_ID    
                 ,FIRST_VALUE(DPS_RULE_MATCH.depositary_name) 
                  OVER (
                      PARTITION BY DPS_RULE_MATCH.folio_id
                      ORDER BY DPS_RULE_MATCH.rule_order
                  )                                           AS DEPOSITARY_NAME
                 ,DPS_RULE_MATCH.FUND_ID
                 ,DPS_RULE_MATCH.FUND_NAME
              FROM 
              (
                  SELECT 
                      FOLIO.ident                         AS FOLIO_ID
                     ,FOLIO.name                          AS FOLIO_NAME                
                         
                     ,DPS.depositary                      AS DEPOSITARY_ID
                     ,DEPOSITARY_ENTITY.name              AS DEPOSITARY_NAME
                     ,DPS.position                        AS RULE_ORDER
                     ,FUND_ENTITY.ident                   AS FUND_ID
                     ,FUND_ENTITY.name                    AS FUND_NAME
                  FROM FOLIO 
                  JOIN RISKUSERS
                      ON RISKUSERS.NAME = p_username
                  JOIN TIERS FUND_ENTITY
                      ON FUND_ENTITY.ident = FOLIO.entite
                  JOIN TITRES FUND_INSTRUMENT
                      ON FUND_INSTRUMENT.code_emet = FOLIO.entite 
                  JOIN BTG_DEPOSITARY_SELECTOR DPS
                      ON (DPS.fund = FUND_INSTRUMENT.sicovam OR DPS.fund = 0)
                      AND (DPS.trader = RISKUSERS.ident OR DPS.trader = 0)
                  JOIN TITRES I
                      ON (I.affectation = DPS.allotment OR DPS.allotment = 0)
                      AND (I.DEVISECTT = DPS.currency OR DPS.currency = 0)
                      AND I.sicovam = p_sicovam
                  JOIN TIERS DEPOSITARY_ENTITY
                      ON DEPOSITARY_ENTITY.ident = DPS.depositary
              ) DPS_RULE_MATCH
              ORDER BY FOLIO_ID DESC
          ) FOLIO_DEPOSITARY
              ON FOLIO_DEPOSITARY.FOLIO_ID = USER_RULE_FOLIOS.FOLIO_ID
          LEFT JOIN
          (
              SELECT
                  TIERS.IDENT
                 ,SUM(T.QUANTITE * I.NOMINAL) AS Orig_Face
              FROM HISTOMVTS T
              INNER JOIN TITRES I
                  ON I.SICOVAM = T.SICOVAM
              INNER JOIN BUSINESS_EVENTS BE
                  ON T.TYPE = BE.ID
              INNER JOIN TIERS 
                  ON TIERS.IDENT = T.ENTITE 
              INNER JOIN
                ( SELECT 
                      F.IDENT
                     ,F.NAME
                     ,NVL(btg_parse_string(SYS_CONNECT_BY_PATH(F.IDENT, '/'),3,4), F.IDENT) parent_ident
                  FROM FOLIO F
                  WHERE level        > 1
                  START WITH F.IDENT = 12514 -- BTG - Funds
                      CONNECT BY F.MGR = prior F.IDENT
                ) strategy
                  ON strategy.IDENT = T.OPCVM
              WHERE I.SICOVAM = p_sicovam
                  AND T.BACKOFFICE NOT IN(192,11,13,17,26,27,220,248,252)
                  AND BE.COMPTA = 1
              GROUP BY TIERS.IDENT
          ) INSTRUMENT_FUND_POSITION  
              ON INSTRUMENT_FUND_POSITION.IDENT = USER_RULE_FOLIOS.FUND_ID
          
          ORDER BY USER_RULES.RULE_ID, USER_RULE_FOLIOS.rule_folio_id, USER_RULE_FOLIOS.FOLIO_PATH;
  END GetAllocationRuleFolioTree;

END PCKG_BTG_ALLOCATION;
/
