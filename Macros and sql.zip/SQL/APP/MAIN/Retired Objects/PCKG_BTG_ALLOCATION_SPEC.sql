CREATE OR REPLACE PACKAGE PCKG_BTG_ALLOCATION
AS

    -- ***************************************************************************
    -- Constant variables
    -- ***************************************************************************
      
    RULE_IS_MATCHED   EXCEPTION;
      
    EOT                               CONSTANT TIMESTAMP    := TO_DATE( '31-Dec-9999 23:59:59', 'DD-MON-YYYY HH24:MI:SS' );
      
    -- ***************************************************************************
    -- Types
    -- ***************************************************************************
      
    TYPE T_CURSOR                     IS REF CURSOR;
       
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFundsForSelection
    (
    p_cursor                    OUT           T_CURSOR  
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFoliosForSelection
    (
    p_cursor                    OUT           T_CURSOR  
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisUsersForSelection
    (
    p_cursor                    OUT           T_CURSOR  
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFolios
    (
    p_cursor                    OUT           T_CURSOR
    , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewSophisFund
    (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
    , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
    , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_FND.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveSophisFund
    (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_FND.version%type  
    , p_starting_sophis_folio_id  IN            V_BTG_ALLCTN_RL_SPHS_FND.starting_sophis_folio_id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_FND.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_FND.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveSophisFund
    (
    p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND.sophis_fund_id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_FND.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFunds
    (
    p_cursor                    OUT           T_CURSOR  
    );

    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFundVersions
    (
    p_cursor                    OUT           T_CURSOR  
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisFundVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_SPHS_FND_VRSN.sophis_fund_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewSophisUser
    (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
    , p_created_by                IN OUT        V_BTG_ALLCTN_RL_SPHS_USR.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveSophisUser
    (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_SPHS_USR.version%type  
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_SPHS_USR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_SPHS_USR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveSophisUser
    (
    p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR.sophis_user_id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_SPHS_USR.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisUsers
    (
    p_cursor                    OUT           T_CURSOR  
    );

    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisUserVersions
    (
    p_cursor                    OUT           T_CURSOR
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetSophisUserVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_SPHS_USR_VRSN.sophis_user_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewUser
    (
    p_id                        OUT           V_BTG_ALLCTN_RL_USR.id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
    , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
    , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
    , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
    , p_created_by                IN            V_BTG_ALLCTN_RL_USR.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_USR.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveUser
    (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_USR.version%type
    , p_name                      IN            V_BTG_ALLCTN_RL_USR.name%type
    , p_password                  IN            V_BTG_ALLCTN_RL_USR.password%type
    , p_is_administrator          IN            V_BTG_ALLCTN_RL_USR.is_administrator%type  
    , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_USR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_USR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_USR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveUser
    (
    p_id                        IN            V_BTG_ALLCTN_RL_USR.id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_USR.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetUsers
    (
    p_cursor                    OUT           T_CURSOR  
    );

    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetUserVersions
    (
    p_cursor                    OUT           T_CURSOR
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetUserVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_id                        IN            V_BTG_ALLCTN_RL_USR_VRSN.id%type
    );
        
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewAllocationRule
    (
    p_id                        OUT           V_BTG_ALLCTN_RL.id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
    , p_name                      IN            V_BTG_ALLCTN_RL.name%type
    , p_active                    IN            V_BTG_ALLCTN_RL.active%type
    , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
    , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
    , p_created_by                IN            V_BTG_ALLCTN_RL.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveAllocationRule
    (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL.version%type
    , p_name                      IN            V_BTG_ALLCTN_RL.name%type
    , p_active                    IN            V_BTG_ALLCTN_RL.active%type
    , p_active_from_dt            IN            V_BTG_ALLCTN_RL.active_from_dt%type
    , p_active_to_dt              IN            V_BTG_ALLCTN_RL.active_to_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveAllocationRule
    (
    p_id                        IN            V_BTG_ALLCTN_RL.id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetAllocationRules
    (
    p_cursor                    OUT           T_CURSOR  
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetAllocationRules
    (
    p_cursor                    OUT           T_CURSOR  
    , p_active_dt                 IN            V_BTG_ALLCTN_RL.active_from_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetAllocationRuleVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_id                        IN            V_BTG_ALLCTN_RL_VRSN.id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewTrader
    (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
    , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
    , p_created_by                IN OUT        V_BTG_ALLCTN_RL_TRDR.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_TRDR.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveTrader
    (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
    , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_TRDR.version%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_TRDR.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_TRDR.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_TRDR.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveTrader
    (
    p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
    , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR.sophis_user_id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_TRDR.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetTraders
    (
    p_cursor                    OUT           T_CURSOR
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetTraders
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR.allocation_rule_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetTraderVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
    , p_sophis_user_id            IN            V_BTG_ALLCTN_RL_TRDR_VRSN.sophis_user_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetTraderVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_TRDR_VRSN.allocation_rule_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewFund
    (
    p_id                        OUT           V_BTG_ALLCTN_RL_FND.id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
    , p_sophis_fund_id            IN            V_BTG_ALLCTN_RL_FND.sophis_fund_id%type
    , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type
    , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveFund
    (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type  
    , p_version                   OUT           V_BTG_ALLCTN_RL_FND.version%type  
    , p_percentage                IN            V_BTG_ALLCTN_RL_FND.percentage%type  
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveFund
    (
    p_id                        IN            V_BTG_ALLCTN_RL_FND.id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFunds
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND.allocation_rule_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFundVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_id        IN            V_BTG_ALLCTN_RL_FND_VRSN.allocation_rule_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFundVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_id                        IN            V_BTG_ALLCTN_RL_FND_VRSN.id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE NewFundFolio
    (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
    , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
    , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
    , p_created_by                IN OUT        V_BTG_ALLCTN_RL_FND_FL.created_by%type
    , p_created_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.created_dt%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE SaveFundFolio
    (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
    , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
    , p_version                   OUT           V_BTG_ALLCTN_RL_FND_FL.version%type
    , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type  
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
    , p_updated_dt                OUT           V_BTG_ALLCTN_RL_FND_FL.updated_dt%type
    , p_effective_from_dt         OUT           V_BTG_ALLCTN_RL_FND_FL.effective_from_dt%type
    , p_effective_to_dt           OUT           V_BTG_ALLCTN_RL_FND_FL.effective_to_dt%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE RemoveFundFolio
    (
    p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
    , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL.sophis_folio_id%type
    , p_updated_by                IN            V_BTG_ALLCTN_RL_FND_FL.updated_by%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFundFolios
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL.allocation_rule_fund_id%type  
    , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL.include_exclude%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFundFolioVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
    , p_sophis_folio_id           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.sophis_folio_id%type
    );
      
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    PROCEDURE GetFundFolioVersions
    (
    p_cursor                    OUT           T_CURSOR
    , p_allocation_rule_fund_id   IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.allocation_rule_fund_id%type  
    , p_include_exclude           IN            V_BTG_ALLCTN_RL_FND_FL_VRSN.include_exclude%type
    );
        
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************  
    FUNCTION CheckUserCredentials
    (
    p_name                    IN            V_BTG_ALLCTN_RL_USR.name%type
    , p_password                IN            V_BTG_ALLCTN_RL_USR.password%type
    , p_id                      OUT           V_BTG_ALLCTN_RL_USR.id%type
    , p_is_administrator        OUT           CHAR
    )
    RETURN CHAR; -- Returns 'Y' or 'N'
   
    -- *****************************************************************
    -- Description:
    --
    -- Author:          M.Canning
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 16 AUG 2012      M.Canning     Created.
    -- *****************************************************************
    FUNCTION CheckAllocationRule
    (
    p_block_refcon            IN            HISTOMVTS.refcon%TYPE
    )
    RETURN CHAR; -- Returns 'Y' or 'N'

    -- *****************************************************************
    -- Description: Load all allocation rules in denormalised for for 
    -- specified user name
    -- Author:          J.Coldridge
    --
    -- Revision History
    -- Date             Author        Reason for Change
    -- ----------------------------------------------------------------
    -- 21 OCT 2013      J.Coldridge     Created.
    -- *****************************************************************
    PROCEDURE GetAllocationRulesForUser
    (
      p_username                      IN      RISKUSERS.name%TYPE := NULL
    , p_sicovam                       IN      TITRES.sicovam%TYPE
    , p_cursor                        OUT     SYS_REFCURSOR
    );

    PROCEDURE GetAllocationRuleReasons
    (
      p_cursor                        OUT     SYS_REFCURSOR
    );

    PROCEDURE SetAllocationRuleComment
    (
      p_refcon                        IN      HISTOMVTS.REFCON%TYPE
    , p_userId                        IN      RISKUSERS.IDENT%TYPE  
    , p_reasonId                      IN      BTG_ALLCTN_RL_PRDFND_RSN.ID%TYPE
    , p_comment                       IN      BTG_ALLCTN_RL_CMMNT.COMMENT%TYPE
    );

    PROCEDURE GetBreachConfiguration
    (
      p_cursor                        OUT     SYS_REFCURSOR
    );

    PROCEDURE GetAllocationRuleFolioTree
    (
      p_username                      IN      RISKUSERS.name%TYPE := NULL
    , p_sicovam                       IN      TITRES.sicovam%TYPE
    , p_cursor                        OUT     SYS_REFCURSOR
    );
    
END PCKG_BTG_ALLOCATION;
