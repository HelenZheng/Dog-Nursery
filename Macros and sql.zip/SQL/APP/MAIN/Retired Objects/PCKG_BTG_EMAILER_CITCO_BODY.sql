create or replace
PACKAGE BODY         "PCKG_BTG_EMAILER_CITCO" 
AS

	PROCEDURE GEMM_OTCRep
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      nvl(ROUND(Trades.QUANTITE*titres.nominal, 8),0)                		n$Quantity,
                      nvl(trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3),0) 	n$Price,
                      Trades.Montant                                		n$NetAmount,
                      Currency.libelle                              		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003512) --GEMM
      and             Trades.DATENEG                                > trunc(sysdate) - 10
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009765,10004002,10006711,10005102,10007082,10003642,10005982,10006710,10005743,10006706,10006704,10006707,10006709,10006705,10006709,10007445) --UBS FI, FX, ETD and Equity accounts + Citi FI + Santander account
      and             Trades.TYPE                                  not in (15,2)              -- Repo Re-rates
      and             Instrument.TYPE                              not in ('L','C')
      order by        6,2 asc;

/*collects all OTC trades for GEMM from the last 10 days and orders by trade date*/
  
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END GEMM_OTCRep;  

PROCEDURE DMF_Coupons
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
    select
                     Trades.sicovam				                        										Sicovam,
                     Instrument.libelle                            													Name,
                     Instrument.reference                          													Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           													Type,
                     trunc(Trades.DATENEG)                         													d$TradeDate,
                     trunc(Trades.DATEVAL)                         													d$ValueDate,
                     SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))                          					n$Quantity,
                     nvl(trunc(sum(Trades.Montant)/ SUM(decode (Instrument.type, 'A',decode(Trades.QUANTITE,Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE,Trades.QUANTITE*titres.nominal))),6),0)                              	n$Rate,
                     sum(Trades.Montant)                           													n$NetAmount,
                     Currency.libelle                              													Currency,
                     PrimeBroker.NAME                              													PrimeBroker,
                     business_events.name                          													BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             titres.sicovam = trades.sicovam
      and             Trades.entite                                 IN (10006762) --DMF
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            in (10007122,10007142,10007722) 
      and             Trades.TYPE                                  != 15              -- Repo Re-rates
      and             Trades.TYPE                                  = 2               -- Coupons are not sent in any trade file to Citco 
      and             Instrument.TYPE                              != 'L'
      and             Instrument.type                               !='S'
     group by Trades.sicovam, Instrument.libelle, Instrument.reference, case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end, trunc(Trades.DATENEG), trunc(Trades.DATEVAL), Currency.libelle, PrimeBroker.NAME, business_events.name
      order by        5,3 asc;

/* Reports all coupons and dividends posted to UBS, PBL, Citi and Santander for DMF*/
  
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END DMF_Coupons;

	PROCEDURE GEMM_OTCCOUP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      Trades.QUANTITE*titres.nominal                		n$Quantity,
                      trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3) 	n$Price,
                      Trades.Montant                                		n$NetAmount,
                      Currency.libelle                              		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003512) --GEMM
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009765,10004002,10006711,10005102,10007082,10003642,10005982,10006710,10005743,10006706,10006704,10006707,10006709,10006705) --UBS FI, FX, ETD and Equity accounts + Citi FI + Santander account
      and             Trades.TYPE                                  =2              -- Coupons
      and             Instrument.TYPE                              != 'L'
      order by        6,2 asc;

  /*collects all OTC coupons for GEMM from the last 30 days and orders by trade date*/
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END GEMM_OTCCOUP; 

  PROCEDURE ARF2_OTCCOUP
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
     select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      Trades.QUANTITE*titres.nominal                		n$Quantity,
                      trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3) 	n$Price,
                      Trades.Montant                                		n$NetAmount,
                      DECODE(Currency.libelle,'CHINA RENMINBI (YUAN)','CNY',  Currency.libelle)                            		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12,16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003503) --ARF 2
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009764,10007242,10006563,10006564,1006562,10006582,10006565,10006566,10006602,10006562,10010548) --UBS FI, FX, ETD and Equity accounts + Citi FI account
      and             Trades.TYPE                                  =2              -- Coupons
      and             Instrument.TYPE                              != 'L'
      order by        6,2 asc;
    
    
  /*collects all OTC coupons for ARF2 from the last 30 days and orders by trade date*/
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF2_OTCCOUP; 

PROCEDURE ARF_OTCCOUP
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                     case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      Trades.QUANTITE*titres.nominal                		n$Quantity,
                      trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3) 	n$Price,
                      Trades.Montant                                		n$NetAmount,
                      Currency.libelle                              		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003506) --ARF
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009763,10003642,10008342,10008242,10008262,10008642,10008362,10008302,10008322,10005742,10008282,10007443,10007444) --UBS FI, FX, ETD and Equity accounts + Citi FI + Santander account
      and             Trades.TYPE                                  =2               -- Coupons
      and             Instrument.TYPE                              != 'L'
      order by        6,2 asc;

  /*collects all OTC coupons for ARF from the last 30 days and orders by trade date*/
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF_OTCCOUP;

     PROCEDURE PROJ_SWAP_PAY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select 
    m.sicovam, 
    t.libelle name, 
    m.dateneg d$ProposedDate, 
    m.dateval d$PayDate, 
    round(m.montant,2) n$Amount,
    f.name Fund, 
    d.libelle CCY, 
    g.name 
from 
    mvt_auto m,
    titres t,
    tiers f,
    tiers g,
    devisev2 d
where t.sicovam = m.sicovam
and m.dateneg > sysdate-1
and  m.dateneg < sysdate+30
and m.entite = f.ident
and m.depositaire = g.ident
and m.devisepay = d.code
and t.type = 'S'
and f.ident in (10003503,10003506,10003512,10006762)
order by 3,1,5,8,7;

END PROJ_SWAP_PAY;

  PROCEDURE ARF2_OTCTREP
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      nvl(Trades.QUANTITE*titres.nominal,0)                		n$Quantity,
                      nvl(trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3),0) 	n$Price,
                      nvl(Trades.Montant,0)                                		n$NetAmount,
                      Currency.libelle                              		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12,16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003503) --ARF 2
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009764,10003642,10007242,10006563,10006564,1006562,10006582,10006565,10006566,10006602,10006562,10010548) --UBS FI, FX, ETD and Equity accounts + Citi FI account
      and             Trades.TYPE                                  not in (15,2)              -- Repo Re-rates
      and             Instrument.TYPE                              not in ('L','C')
      order by        6,2 asc;
  -- ***************************************************************************
  -- collects all OTC trades for ARF 2 from the last 30 days and orders by trade date
  -- ***************************************************************************
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF2_OTCTREP; 
  

  
  PROCEDURE ARF2_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select          Trades.sicovam				                        										Sicovam,
                     Instrument.libelle                            													Name,
                     Instrument.reference                          													Ticker,
                                           case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           													Type,
                     trunc(Trades.DATENEG)                         													d$TradeDate,
                     trunc(Trades.DATEVAL)                         													d$ValueDate,
                     SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))                          					n$Quantity,
                     trunc(sum(Trades.Montant)/   DECODE(SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal)),0,100000000000,SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))),6)                               	n$Rate,
                     sum(Trades.Montant)                           													n$NetAmount,
                     Currency.libelle                              													Currency,
                     PrimeBroker.NAME                              													PrimeBroker,
                     business_events.name                          													BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12,16,244)   -- checked mo
      and             titres.sicovam = trades.sicovam
      and             Trades.entite                                 IN (10003503) --,10003506,10003512,10006762)
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            in (10006563,10006564,1006562,10007242) --!= 10003642        -- Internal Trades 
      and             Trades.TYPE                                  = 2               -- Coupons are not sent in any trade file to Citco 
      and             Instrument.TYPE                              != 'L'
     group by Trades.sicovam, Instrument.libelle, Instrument.reference, case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end, trunc(Trades.DATENEG), trunc(Trades.DATEVAL), Currency.libelle, PrimeBroker.NAME, business_events.name
      order by        5,3 asc;

  -- ***************************************************************************
  -- ARF 2 Coupon and Dividend Report
  -- ***************************************************************************
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF2_COUPONS; 
  

  
  PROCEDURE ARF_OTCTREP
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select          
                     Trades.sicovam				   		Sicovam,
                     Trades.refcon				   		TradeId,
                     Instrument.libelle                            		Name,
                     Instrument.reference                          		Ticker,
                     case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           		Type,
                      trunc(Trades.DATENEG)                         		d$TradeDate,
                      trunc(Trades.DATEVAL)                         		d$ValueDate,
                      Trades.QUANTITE*titres.nominal                		n$Quantity,
                      trunc(Trades.Montant/(decode(Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE*titres.nominal)),3) 	n$Price,
                      Trades.Montant                                		n$NetAmount,
                      Currency.libelle                              		Currency,
                      PrimeBroker.NAME                              		PrimeBroker,
                      business_events.name                          		BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12,16,244)   -- checked mo
      and             trades.sicovam = titres.sicovam
      and             Trades.entite                                 IN (10003506) --ARF
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            not in (10009763,10003464,10003662,10003642,10003642,10008342,10008242,10008262,10008642,10008362,10008302,10008322,10005742,10008282,10007443,10007444) --UBS FI, FX, ETD and Equity accounts + Citi FI + Santander account
      and             Trades.TYPE                                  not in (15,2)              -- Repo Re-rates
      and             Instrument.TYPE                              not in ('L','C')
      order by        6,2 asc;
  -- ***************************************************************************
  -- collects all OTC trades for ARF from the last 30 days and orders by trade date
  -- ***************************************************************************    
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF_OTCTREP;
  

  
  PROCEDURE GEMM_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select
                     Trades.sicovam				                        										Sicovam,
                     Instrument.libelle                            													Name,
                     Instrument.reference                          													Ticker,
                     case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           													Type,
                     trunc(Trades.DATENEG)                         													d$TradeDate,
                     trunc(Trades.DATEVAL)                         													d$ValueDate,
                     SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))                          					n$Quantity,
                     trunc(sum(Trades.Montant)/   DECODE(SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal)),0,1,SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))),6)                               	n$Rate,
                     sum(Trades.Montant)                           													n$NetAmount,
                     Currency.libelle                              													Currency,
                     PrimeBroker.NAME                              													PrimeBroker,
                     business_events.name                          													BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12,16,244)   -- checked mo
      and             titres.sicovam = trades.sicovam
      and             Trades.entite                                 IN (10003512) --GEMM
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            in (10006707,10006706,10005743,100006711,10007082,10006710) 
      and             Trades.TYPE                                  = 2               -- Coupons are not sent in any trade file to Citco 
      and             Instrument.TYPE                              != 'L'
     group by Trades.sicovam, Instrument.libelle, Instrument.reference, case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end, trunc(Trades.DATENEG), trunc(Trades.DATEVAL), Currency.libelle, PrimeBroker.NAME, business_events.name
      order by        5,3 asc;

  -- ***************************************************************************
  -- Reports all coupons and dividends posted to UBS, PBL and Santander for GEMM
  -- ***************************************************************************
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END GEMM_COUPONS;
  

  
  PROCEDURE ARF_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select
                     Trades.sicovam				                        										Sicovam,
                     Instrument.libelle                            													Name,
                     Instrument.reference                          													Ticker,
                     case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           													Type,
                     trunc(Trades.DATENEG)                         													d$TradeDate,
                     trunc(Trades.DATEVAL)                         													d$ValueDate,
                     SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))                          					n$Quantity,
                     trunc(sum(Trades.Montant)/   DECODE(SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal)),0,100000000000,SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))),6)                               	n$Rate,
                     sum(Trades.Montant)                           													n$NetAmount,
                     Currency.libelle                              													Currency,
                     PrimeBroker.NAME                              													PrimeBroker,
                     business_events.name                          													BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             titres.sicovam = trades.sicovam
      and             Trades.entite                                 IN (10003506) --ARF
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            in (10008342,10008242,10008642,10008302,10005742,10008282) 
      and             Trades.TYPE                                  = 2               -- Coupons are not sent in any trade file to Citco 
      and             Instrument.TYPE                              != 'L'
      and             Instrument.type                               !='S'
     group by Trades.sicovam, Instrument.libelle, Instrument.reference, case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end, trunc(Trades.DATENEG), trunc(Trades.DATEVAL), Currency.libelle, PrimeBroker.NAME, business_events.name
      order by        5,3 asc;

  -- ***************************************************************************
  -- Reports all coupons and dividends posted to UBS, PBL, Citi and Santander for ARF
  -- ***************************************************************************
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ARF_COUPONS;

  PROCEDURE ABS_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR
      select
                     Trades.sicovam				                        										Sicovam,
                     Instrument.libelle                            													Name,
                     Instrument.reference                          													Ticker,
                     case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end                                           													Type,
                     trunc(Trades.DATENEG)                         													d$TradeDate,
                     trunc(Trades.DATEVAL)                         													d$ValueDate,
                     SUM(decode (Instrument.type, 'A',Trades.QUANTITE,Trades.QUANTITE*titres.nominal))                          					n$Quantity,
                     nvl(trunc(sum(Trades.Montant)/ SUM(decode (Instrument.type, 'A',decode(Trades.QUANTITE,Trades.QUANTITE*titres.nominal,0,1,Trades.QUANTITE,Trades.QUANTITE*titres.nominal))),6),0)                               	n$Rate,
                     sum(Trades.Montant)                           													n$NetAmount,
                     Currency.libelle                              													Currency,
                     PrimeBroker.NAME                              													PrimeBroker,
                     business_events.name                          													BusinesEvent    
      from            titres, histomvts Trades 
      
      inner join      business_events
      on              business_events.id                            = Trades.type
      
      inner join      devisev2 Currency
      on              Currency.code                                 = Trades.devisepay
      
      inner join      titres Instrument
      on              Instrument.sicovam                            = Trades.sicovam 
      
      inner join      tiers PrimeBroker     
      on              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      where           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo
      and             titres.sicovam = trades.sicovam
      and             Trades.entite                                 IN (10009482) --ARF
      and             Trades.DATENEG                                > trunc(sysdate) - 30
      and             Trades.DATENEG                                < trunc(sysdate)
      and             Trades.DEPOSITAIRE                            in (10009502,10009503) 
      and             Trades.TYPE                                  = 2               -- Coupons are not sent in any trade file to Citco 
      and             Instrument.TYPE                              != 'L'
      and             Instrument.type                               !='S'
     group by Trades.sicovam, Instrument.libelle, Instrument.reference, case
                        when Instrument.type = 'A' then 'Share'
                        when Instrument.type = 'B' then 'Cap and Floor'
                        when Instrument.type = 'C' then 'Commission'
                        when Instrument.type = 'D' then 'Derivative'
                        when Instrument.type = 'E' then 'Exchange'
                        when Instrument.type = 'F' then 'Future'
                        when Instrument.type = 'G' then 'CFD'
                        when Instrument.type = 'I' then 'Index'
                        when Instrument.type = 'K' then 'NDF'
                        when Instrument.type = 'L' then 'Repo'
                        when Instrument.type = 'M' then 'Option on listed market'
                        when Instrument.type = 'N' then 'Package'
                        when Instrument.type = 'O' then 'Bond'
                        when Instrument.type = 'P' then 'Loan'
                        when Instrument.type = 'R' then 'Rate'
                        when Instrument.type = 'S' then 'Swap'
                        when Instrument.type = 'T' then 'NCD'
                        when Instrument.type = 'W' then 'Option swap'       
                        else 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                      end, trunc(Trades.DATENEG), trunc(Trades.DATEVAL), Currency.libelle, PrimeBroker.NAME, business_events.name
      order by        5,3 asc;

  -- ***************************************************************************
  -- Reports all coupons and dividends posted PBL for Absoluto Fund
  -- ***************************************************************************
    
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END ABS_COUPONS;

END PCKG_BTG_EMAILER_CITCO;