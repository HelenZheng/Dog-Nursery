create or replace
PACKAGE BODY            "PCKG_BTG_EMAILER_EXCEPTION" 
AS



  -- *****************************************************************
  -- Description: PROCEDURE BROKER_DEALER_WRONG_BROKER
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 2013-07-19       Jun Guan      Created.  
  
  PROCEDURE BROKER_DEALER_WRONG_BROKER
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF BROKER_DEALER_WRONG_BROKER
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

      SELECT refcon Trade_ID
            ,titres.sicovam Sicovam
            ,titres.reference InstrumentReference
            ,titres.libelle InstrumentName
            ,BrokerName.NAME Broker
            ,CounterpartyName.NAME Counterparty
  
      FROM histomvts

      INNER JOIN (
                  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS FUND_ID
                        ,CONNECT_BY_ROOT(FOLIO.NAME) AS FUND_NAME
                        ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
                        ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                        ,FOLIO.ident AS STRATEGY_ID
                        ,FOLIO.NAME AS STRATEGY_NAME
                  FROM FOLIO
                  WHERE LEVEL > 2 START
                  WITH FOLIO.ident IN (89631) -- -Broker Dealer funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FUND_BOOK_STRATEGY 
      ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM

      LEFT JOIN fraistiers 
      ON fraistiers.ident = histomvts.courtier
      AND fraistiers.entity = 10018177
      AND fraistiers.options = 2

      LEFT JOIN fraistiers fraistiers2 
      ON fraistiers2.ident = histomvts.contrepartie
      AND fraistiers2.entity = 10018177
      AND fraistiers2.options = 1
  
      LEFT JOIN tiers Broker 
      ON Broker.ident = fraistiers.ident

      LEFT JOIN tiers CP 
      ON CP.ident = fraistiers2.ident

      INNER JOIN Titres 
      ON Titres.sicovam = Histomvts.sicovam

      LEFT JOIN tiers BrokerName 
      ON BrokerName.ident = Histomvts.courtier

      LEFT JOIN tiers CounterpartyName 
      ON CounterpartyName.ident = Histomvts.contrepartie

      WHERE histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
      AND (
            broker.NAME IS NULL OR CP.NAME IS NULL
          );

 
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF BROKER_DEALER_WRONG_BROKER 
  -- ***************************************************************************         
	END BROKER_DEALER_WRONG_BROKER;




-- *****************************************************************
-- Description:     PROCEDURE  EMIR_MISSING_UTI
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 feb 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE EMIR_MISSING_UTI (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EMIR_MISSING_UTI
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT DISTINCT histomvts.refcon Trade_ID
	,titres.reference instrument_reference
	,affectation.libelle allotment
	,titres.sicovam sicovam
	,fund.reference Fund
	,business_events.NAME business_event
	,histomvts.quantite quantity
	,histomvts.cours price
  ,trunc(histomvts.DATENEG)   d$Trade_Date
  ,trunc(histomvts.DATEVAL)   d$Value_Date
	,tiers.reference depositary
	,cpty.reference counterparty

FROM histomvts

INNER JOIN (
	SELECT folio.ident
		,folio.NAME
		,NVL(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'), 3, 4), ident) parent_ident
	FROM folio
	WHERE LEVEL > 2 START
	WITH ident = PCKG_BTG.FOLIO_UCITS_FUND CONNECT BY mgr = prior ident
	) strategy
ON strategy.ident = histomvts.opcvm

INNER JOIN titres fund
ON fund.code_emet = histomvts.entite

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.fund = fund.sicovam
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN business_events
ON business_events.id = histomvts.type
AND business_events.compta = 1

INNER JOIN tiers
ON tiers.ident = histomvts.depositaire

INNER JOIN tiers cpty
ON cpty.ident = histomvts.contrepartie

INNER JOIN AMRECON_EXTSYS_ACCOUNTS depo
ON depo.pb = tiers.ident
AND depo.esid = 3183
AND depo.include = 1

INNER JOIN titres
ON titres.sicovam = histomvts.sicovam

LEFT JOIN affectation
ON affectation.ident = titres.affectation

LEFT JOIN btg_emir_confirm
ON btg_emir_confirm.refcon = histomvts.refcon

WHERE TRUNC(histomvts.DATENEG) >= '12-FEB-2014'
AND histomvts.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
AND btg_emir_confirm.uti IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

EMIR_MISSING_UTI;

-- *****************************************************************
-- END OF: EMIR_MISSING_UTI
-- *****************************************************************





-- *****************************************************************
  -- Description  PROCEDURE EXECUTION_WRONG_STATUS
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE EXECUTION_WRONG_STATUS
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF EXECUTION_WRONG_STATUS 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
          SELECT              riskusers.name                    Trader
                            , bo_kernel_status.name             Status
                            , trades.refcon                     TradeID
                            , trades.sicovam  
                            , titres.libelle                     InstrumentName
                            , titres.reference                   InstrumentReference
                            , trades.dateneg                     d$TradeDate
                            , trades.dateval                     d$ValueDate
                            , trades.quantite                    Quantity
                            , trades.cours                       Price
                            , business_events.name              BusinessEvent
          FROM histomvts trades
          INNER JOIN ( 
                        SELECT 
                                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                              , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                              , FOLIO.ident                                                         AS STRATEGY_ID
                              , FOLIO.name                                                          AS STRATEGY_NAME
                              , level
                        FROM  FOLIO
                        WHERE
                            LEVEL >= 4
                            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK ) -- (14045)--execution books
                            CONNECT BY PRIOR FOLIO.ident         =   FOLIO.mgr  
                      )   FUND_BOOK_STRATEGY
          ON              FUND_BOOK_STRATEGY.STRATEGY_ID        =    Trades.OPCVM

          LEFT JOIN       riskusers
          ON              riskusers.ident                       =    trades.operateur          
          LEFT JOIN       bo_kernel_status
          ON              bo_kernel_status.id                   =    trades.backoffice          
          LEFT JOIN       titres 
          ON              titres.sicovam                        =    trades.sicovam          
          LEFT JOIN       business_events
          ON              business_events.id                    =    trades.type          
          WHERE
          trades.dateneg                                        >=    '14-Oct-2012'
          AND trades.backoffice                                 NOT IN (262,220,260);

	-- ***************************************************************************
  -- END OF EXECUTION_WRONG_STATUS 
  -- ***************************************************************************	
 END EXECUTION_WRONG_STATUS;






END PCKG_BTG_EMAILER_EXCEPTION;