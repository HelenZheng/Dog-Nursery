create or replace
PACKAGE            "PCKG_BTG_EMAILER_EXCEPTION" 
AS

	TYPE T_CURSOR IS REF CURSOR;


  -- *****************************************************************
  -- Description: PROCEDURE BROKER_DEALER_WRONG_BROKER
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 2013-07-19       Jun Guan      Created.
  -- *****************************************************************
	PROCEDURE BROKER_DEALER_WRONG_BROKER
	(
		p_CURSOR OUT T_CURSOR
	);



-- *****************************************************************
-- Description:     PROCEDURE  EMIR_MISSING_UTI
--
-- Author:          JUN GUAN
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 FEB 2014      JUN GUAN            Created.
-- ***************************************************************** 

  PROCEDURE EMIR_MISSING_UTI

	(
		p_CURSOR OUT T_CURSOR
	);


  -- *****************************************************************
  -- Description: PROCEDURE EXECUTION_WRONG_STATUS
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE EXECUTION_WRONG_STATUS
	(
		p_CURSOR OUT T_CURSOR
	);

	
	
	
END PCKG_BTG_EMAILER_EXCEPTION;