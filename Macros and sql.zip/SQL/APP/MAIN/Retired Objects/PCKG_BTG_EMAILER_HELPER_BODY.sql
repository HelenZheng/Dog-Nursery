CREATE OR REPLACE PACKAGE BODY PCKG_BTG_EMAILER_HELPER AS

   FUNCTION GetFolioTree(in_folio_ident_1 FOLIO.ident%TYPE
  , in_folio_ident_2 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_3 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_4 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_5 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_6 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_7 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_8 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_9 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_10 FOLIO.ident%TYPE DEFAULT NULL
  ) RETURN T_FOLIO_SET PIPELINED
  AS    
    l_folios T_FOLIO_SET := T_FOLIO_SET();    
    
    CURSOR c IS 
      SELECT *
      FROM FOLIO 
      START WITH FOLIO.ident IN (in_folio_ident_1, in_folio_ident_2, in_folio_ident_3, in_folio_ident_4, in_folio_ident_5, in_folio_ident_6)
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr;
      
  BEGIN
    
    FOR l_folio_row in c LOOP
    
        PIPE ROW(l_folio_row);
        
    END LOOP;    
    
  END GetFolioTree;

END PCKG_BTG_EMAILER_HELPER;
