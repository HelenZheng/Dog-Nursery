CREATE OR REPLACE PACKAGE PCKG_BTG_EMAILER_HELPER AS 

  TYPE T_FOLIO_SET IS TABLE OF FOLIO%ROWTYPE;
  
  FUNCTION GetFolioTree( in_folio_ident_1 FOLIO.ident%type
  , in_folio_ident_2 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_3 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_4 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_5 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_6 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_7 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_8 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_9 FOLIO.ident%TYPE DEFAULT NULL
  , in_folio_ident_10 FOLIO.ident%TYPE DEFAULT NULL
  ) RETURN T_FOLIO_SET PIPELINED;

END PCKG_BTG_EMAILER_HELPER;
