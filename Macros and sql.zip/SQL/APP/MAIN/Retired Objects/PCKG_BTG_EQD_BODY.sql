create or replace PACKAGE BODY            "PCKG_BTG_EQD" AS

  
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 27/10/2014
  -- Description:	Returns all restricted stocks for QSF
  -- =============================================
  PROCEDURE GET_QSF_RESTRICTED_LIST
  (
    p_cursor OUT T_CURSOR
  ) 
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT ID_BB_COMPANY, ISSUER_NAME, MODIFIED_TIMESTAMP, active_from, active_to
      from BTG_RESTRICTED_LIST_QSF
      WHERE active_from <= CURRENT_DATE
        AND active_to IS NULL OR active_to >= CURRENT_DATE;
      --SELECT LIST_ID, ID_BB_COMPANY, ISSUER_NAME, MODIFIED_TIMESTAMP
      --FROM BTG_RESTRICTED_LIST_IDS 
      --WHERE LIST_ID = 0;
      
  END GET_QSF_RESTRICTED_LIST;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns all the dividends
  -- =============================================
  PROCEDURE GET_DIVIDENDS
  (
    p_cursor OUT T_CURSOR
  ) 
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT datediv,avoir_fiscal,currency,dateexdiv,
              datepaye,exsoc,infos,reference,status,typediv,valeur
      FROM BTG_EQD_DIVIDENDS;
    
  END GET_DIVIDENDS;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns the dividends for a given instrument
  -- =============================================
  PROCEDURE GET_DIVIDENDS
  (
    p_reference   IN    BTG_EQD_DIVIDENDS.REFERENCE%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT datediv,avoir_fiscal,currency,dateexdiv,
              datepaye,exsoc,infos,reference,status,typediv,valeur
      FROM BTG_EQD_DIVIDENDS
      WHERE BTG_EQD_DIVIDENDS.reference = p_reference;
    
  END GET_DIVIDENDS;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 11/02/2013
  -- Description:	Returns the tax of an instrument
  -- =============================================
  PROCEDURE GET_TAX
  (
    p_reference   IN    TITRES.REFERENCE%TYPE
    , p_tax       OUT   tableavoirfiscal.tauxfiscalitepays%type
  )
  AS
  BEGIN
  
      SELECT tauxfiscalitepays into p_tax
      FROM TITRES inner join tableavoirfiscal on Titres.sicovam = tableavoirfiscal.codetitre
      WHERE titres.reference = p_reference;
  
  END GET_TAX;
  
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns the dividends for a given instrument
  -- =============================================
  PROCEDURE GET_ALLOCATION_RULE
  (
    p_user_name    IN    BTG_EQD_ALLOCATION_RULE.USER_NAME%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT user_id, user_name, rule_id, rule_name, folio_ident, prop
      FROM BTG_EQD_ALLOCATION_RULE
      WHERE BTG_EQD_ALLOCATION_RULE.USER_NAME = p_user_name;
    
  END GET_ALLOCATION_RULE;
  
  
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns the dividends for a given instrument
  -- =============================================
  PROCEDURE GET_CFD
  (
    p_sophis_ref  IN    BTG_EQD_CFD.UL_REFERENCE%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT *
      FROM BTG_EQD_CFD
      WHERE btg_eqd_cfd.ul_reference = p_sophis_ref;
    
  END GET_CFD;
  
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 10/09/2013
  -- Description:	Returns the sophis
  -- =============================================
  PROCEDURE GET_SOPHIS_IDENT
  (
    sophisref   IN    TITRES.REFERENCE%TYPE
    ,ident      OUT   TITRES.SICOVAM%TYPE
  )
  AS
    
  BEGIN

    SELECT sicovam
    INTO ident
    FROM TITRES
    WHERE reference = sophisref;
    
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    ident := '';
  
  END GET_SOPHIS_IDENT;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 10/09/2013
  -- Description:	Returns the fid data
  -- =============================================
  PROCEDURE GET_FID
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
    
  BEGIN

    OPEN p_cursor FOR
    SELECT sicovam, prefixe, servisen , FIDLIST.name as fid_name
    FROM FIDLIST INNER JOIN RIC ON FIDLIST.item = RIC.FID
    WHERE sicovam = ident;
  
  END GET_FID;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 10/09/2013
  -- Description:	Returns the fid data
  -- =============================================
  PROCEDURE GET_ISSUER
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
    
  BEGIN

    OPEN p_cursor FOR
    SELECT tIssuer.sicovam, tIssuer.reference, cds.rate, devise_to_str(cds.currency) as currency
    FROM TITRES t 
      INNER JOIN TITRES tIssuer on t.base1 = tissuer.sicovam
      LEFT JOIN credit_default_swap cds on cds.code = tIssuer.sicovam
    WHERE t.sicovam = ident;
  
  END GET_ISSUER;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 10/09/2013
  -- Description:	Returns the fid data
  -- =============================================
  PROCEDURE GET_ISSUER_NEW
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  )
  AS
    
  BEGIN

    OPEN p_cursor FOR
    SELECT tIssuer.sicovam, tIssuer.reference, cds.rate, devise_to_str(cds.currency) as currency
    FROM TITRES tIssuer
      LEFT JOIN credit_default_swap cds on cds.code = tIssuer.sicovam
    WHERE tIssuer.sicovam = ident;
  
  END GET_ISSUER_NEW;

    -- =============================================
  -- Author:                          Gautier Oudine
  -- Create date: 19/08/2011
  -- Modified date: 17/07/2015 (delte insert replaced by upsert
  -- Description: Insert the Ctrl J information when we create an option using the integration service
  -- =============================================
  PROCEDURE INSERT_FID_TICKER
  (
    ident         IN    RIC.SICOVAM%TYPE
    , ticker      IN    RIC.SERVISEN%TYPE
    , fid_name    IN    FIDLIST.NAME%TYPE
  )
  AS
    
    l_fid_item FIDLIST.ITEM%TYPE;
    
  BEGIN
 
    SELECT FIDLIST.item
    INTO l_fid_item
    FROM FIDLIST
    WHERE FIDLIST.name = fid_name;
    
    INSERT INTO RIC (SICOVAM,FID,PREFIXE,SERVISEN) 
      VALUES (ident,l_fid_item,'Global',ticker);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX then
        UPDATE RIC 
        SET    FID=l_fid_item,PREFIXE='Global',SERVISEN=ticker
        WHERE  SICOVAM = ident;
        
  END INSERT_FID_TICKER;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns the net position for a given portfolio
  --              fatser than GET_NET_POSITIONS as it does not include the volatility
  -- =============================================
  PROCEDURE GET_QUANT_POSITIONS
  (
    p_folio   IN    FOLIO.IDENT%TYPE
    ,p_cursor OUT   POS_CURSOR
    ,p_date   IN    DATE              DEFAULT NULL
  )
  AS
  BEGIN

  OPEN p_cursor FOR
  SELECT
    OPEN_POSITIONS.PositionId
    , OPEN_POSITIONS.FolioId
    , FOLIO.name as FolioName
    , OPEN_POSITIONS.sicovam AS Sicovam
    , TITRES.reference
    , BTG_GET_INSTRUMENT_TYPE(OPEN_POSITIONS.sicovam) AS InstrumentType
    , TITRES.libelle
    , ID_TO_CCYSYMBOL(TITRES.devisectt) AS Currency
    , OPEN_POSITIONS.quantity AS Quantity
    , ( SELECT HISTORIQUE.d 
        FROM HISTORIQUE 
        WHERE HISTORIQUE.sicovam = OPEN_POSITIONS.sicovam 
        AND HISTORIQUE.jour = (
          SELECT MAX(HISTORIQUE2.jour) 
          FROM HISTORIQUE HISTORIQUE2
          WHERE HISTORIQUE2.sicovam = OPEN_POSITIONS.sicovam
          AND HISTORIQUE2.d IS NOT NULL
        )
      ) AS LastPrice
    , ric.servisen AS RefBloomberg
    , SEDOL_REF.value as Sedol
    , ricsj.sicovam
    , ricsj.servisen as UnderlyingRef
    , SEDOL_REF_SJ.value as UnderlyingSedol
    , affectation.libelle as Allotment
  FROM (
    SELECT 
    HISTOMVTS.mvtident as PositionId
    , HISTOMVTS.sicovam
    , SUM(HISTOMVTS.quantite) AS QUANTITY
    , FOLIOS.ident AS FolioId
    FROM HISTOMVTS
    INNER JOIN (
      SELECT 
        FOLIO.ident
      FROM FOLIO
      START WITH FOLIO.ident = p_folio
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
    ) FOLIOS
    ON FOLIOS.Ident = HISTOMVTS.opcvm
    INNER JOIN BUSINESS_EVENTS
    ON BUSINESS_EVENTS.id = HISTOMVTS.type
    AND BUSINESS_EVENTS.compta = 1
    INNER JOIN TITRES
    ON TITRES.sicovam = HISTOMVTS.sicovam
    AND TITRES.type != 'L'  -- What does it mean ?
    WHERE HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)  -- What does it mean ?
    AND HISTOMVTS.dateneg <= Coalesce(p_date, SYSDATE) -- to keep for debug Coalesce(to_date(:p_date,'DD/MM/YYYY'), SYSDATE)
    GROUP BY 
      FOLIOS.Ident
      , HISTOMVTS.mvtident
      , HISTOMVTS.sicovam
    HAVING ABS(SUM(HISTOMVTS.quantite)) > 0.5
  ) OPEN_POSITIONS
  INNER JOIN TITRES
    ON TITRES.sicovam = OPEN_POSITIONS.sicovam
  INNER JOIN FOLIO
    ON FOLIO.ident = OPEN_POSITIONS.FolioId
  LEFT JOIN AFFECTATION
    ON TITRES.affectation = AFFECTATION.ident
  LEFT JOIN RIC
    ON OPEN_POSITIONS.sicovam = RIC.sicovam
  LEFT JOIN RIC ricsj
    ON ricsj.sicovam = CASE WHEN titres.type ='G' THEN titres.code_emet ELSE titres.codesj END
  LEFT JOIN (SELECT sophis_ident, value
              FROM extrnl_references_instruments extrnl_ref 
                INNER JOIN extrnl_references_definition extrnl_ref_def 
                  ON extrnl_ref.ref_ident = extrnl_ref_def.ref_ident
              WHERE ref_name='SEDOL') SEDOL_REF 
    ON SEDOL_REF.sophis_ident = TITRES.sicovam
  LEFT JOIN (SELECT sophis_ident, value
              FROM extrnl_references_instruments extrnl_ref 
                INNER JOIN extrnl_references_definition extrnl_ref_def 
                  ON extrnl_ref.ref_ident = extrnl_ref_def.ref_ident
              WHERE ref_name='SEDOL') SEDOL_REF_SJ 
    ON SEDOL_REF_SJ.sophis_ident = ricsj.sicovam
  ORDER BY
    FolioId
    , InstrumentType
    , Libelle;
      
  END GET_QUANT_POSITIONS;
      
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Returns the net position for a given portfolio
  -- =============================================
  PROCEDURE GET_NET_POSITIONS
  (
    p_folio   IN    FOLIO.IDENT%TYPE
    ,p_cursor OUT   POS_CURSOR
    ,p_date   IN    DATE              DEFAULT NULL
  )
  AS
  BEGIN

  OPEN p_cursor FOR
    SELECT
    OPEN_POSITIONS.PositionId
    , OPEN_POSITIONS.FolioId
    , OPEN_POSITIONS.FolioName as FolioName
    , OPEN_POSITIONS.sicovam AS Sicovam
    , TITRES.reference
    , BTG_GET_INSTRUMENT_TYPE(OPEN_POSITIONS.sicovam) AS InstrumentType
    , TITRES.libelle
    , ID_TO_CCYSYMBOL(TITRES.devisectt) AS Currency
    , OPEN_POSITIONS.quantity AS QUANTITY
    , ( SELECT HISTORIQUE.d 
        FROM HISTORIQUE 
        WHERE HISTORIQUE.sicovam = OPEN_POSITIONS.sicovam 
        AND HISTORIQUE.jour = (
          SELECT MAX(HISTORIQUE2.jour) 
          FROM HISTORIQUE HISTORIQUE2 
          WHERE HISTORIQUE2.sicovam = OPEN_POSITIONS.sicovam
          AND HISTORIQUE2.d IS NOT NULL
        )
      ) AS LastPrice
    , titres.quotite as ContractSize    
    , ric.servisen AS RefBloomberg
    , SEDOL_REF.sedol as Sedol
    , clause.valeur as Volatility
    , ricsj.sicovam AS UnderlyingCode
    , ricsj.servisen as UnderlyingRef
    , SEDOL_REF_SJ.value as UnderlyingSedol
    , affectation.libelle as Allotment
    FROM (
      SELECT 
        HISTOMVTS.mvtident as PositionId
        , HISTOMVTS.sicovam
        , SUM(HISTOMVTS.quantite) AS QUANTITY
        , FOLIOS.ident AS FolioId
        , Folios.name as FolioName
      FROM HISTOMVTS
      INNER JOIN (
      SELECT 
        FOLIO.ident
        , FOLIO.name
      FROM FOLIO
        START WITH FOLIO.ident = p_folio
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ) FOLIOS
      ON FOLIOS.Ident = HISTOMVTS.opcvm
      INNER JOIN BUSINESS_EVENTS
      ON BUSINESS_EVENTS.id = HISTOMVTS.type
      AND BUSINESS_EVENTS.compta = 1
      INNER JOIN TITRES
      ON TITRES.sicovam = HISTOMVTS.sicovam
      AND TITRES.type != 'L'  -- What does it mean ?
      WHERE HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)  -- What does it mean ?
      AND (p_date IS NULL OR HISTOMVTS.dateneg <= p_date) -- to keep for debug Coalesce(to_date(:p_date,'DD/MM/YYYY'), SYSDATE)
      GROUP BY 
        FOLIOS.Ident
        , FOLIOS.Name
        , HISTOMVTS.mvtident
        , HISTOMVTS.sicovam
      HAVING ABS(SUM(HISTOMVTS.quantite)) > 0.5
    ) OPEN_POSITIONS
    INNER JOIN TITRES
      ON TITRES.sicovam = OPEN_POSITIONS.sicovam
    LEFT JOIN affectation
      ON TITRES.affectation = AFFECTATION.ident
    LEFT JOIN RIC
      ON TITRES.sicovam = RIC.sicovam
    LEFT JOIN CLAUSE
      ON clause.sicovam = titres.sicovam
      AND clause.type = 25 -- how to change to the enum value Overvolatility
    LEFT JOIN RIC ricsj
      ON ricsj.sicovam = CASE WHEN titres.type ='G' THEN titres.code_emet ELSE titres.codesj END
    LEFT JOIN (SELECT sophis_ident, value as sedol
              FROM extrnl_references_instruments extrnl_ref 
                INNER JOIN extrnl_references_definition extrnl_ref_def 
                  ON extrnl_ref.ref_ident = extrnl_ref_def.ref_ident
              WHERE ref_name='SEDOL') SEDOL_REF 
      ON SEDOL_REF.sophis_ident = TITRES.sicovam
    LEFT JOIN (SELECT sophis_ident, value
              FROM extrnl_references_instruments extrnl_ref 
                INNER JOIN extrnl_references_definition extrnl_ref_def 
                  ON extrnl_ref.ref_ident = extrnl_ref_def.ref_ident
              WHERE ref_name='SEDOL') SEDOL_REF_SJ 
    ON SEDOL_REF_SJ.sophis_ident = ricsj.sicovam

    ORDER BY
      FolioId
      , InstrumentType
      , Libelle;
      
  END GET_NET_POSITIONS;


    -- =============================================
  -- Author:                          Gautier Oudine
  -- Create date: 19/08/2011
  -- Description: Returns the trrades of a given portfolio
  -- Modified: 23/07/2015 Jira: FOEAI-18
  -- =============================================
   PROCEDURE GET_TRADES
  (
    p_folio   IN    FOLIO.IDENT%TYPE 
    ,p_cursor OUT   POS_CURSOR
    ,p_from_date   IN    DATE              DEFAULT NULL
    ,p_to_date   IN    DATE              DEFAULT NULL
  )
  AS
  BEGIN
  
  OPEN p_cursor FOR
   SELECT 
    HISTOMVTS.refcon
    , HISTOMVTS.sicovam
    , TITRES.reference
    , BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam) AS InstrumentType
    , HISTOMVTS.quantite
    , HISTOMVTS.fraiscounterparty
    , HISTOMVTS.fraismarche
    , HISTOMVTS.cours
    , HISTOMVTS.montant
    , HISTOMVTS.dateneg
    , bo_kernel_status.name as Status
    , FOLIOS.ident AS FolioId
	, BUSINESS_EVENTS.name as BusinessEvent
    FROM HISTOMVTS
    INNER JOIN (
      SELECT 
        FOLIO.ident
        , FOLIO.name
      FROM FOLIO
      START WITH FOLIO.ident = p_folio
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
    ) FOLIOS
    ON FOLIOS.Ident = HISTOMVTS.opcvm
    INNER JOIN BUSINESS_EVENTS
    ON BUSINESS_EVENTS.id = HISTOMVTS.type
    AND BUSINESS_EVENTS.compta = 1
    INNER JOIN TITRES
    ON TITRES.sicovam = HISTOMVTS.sicovam
    INNER JOIN BO_KERNEL_STATUS
    ON HISTOMVTS.backoffice = BO_KERNEL_STATUS.id
    WHERE HISTOMVTS.backoffice IN (8, 12, 19, 244, 260)  -- NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) --IN (8, 19, 260)  -- Checked FM, Modified FM / Pending MO, Unallocated
    AND HISTOMVTS.dateneg >= Coalesce(p_from_date, TO_DATE('1', 'J'))
    AND HISTOMVTS.dateneg <= Coalesce(p_to_date, TO_DATE('9999', 'yyyy'))

    ORDER BY
      FolioId
      , titres.reference;

  END GET_TRADES;


  
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 02/01/2012
  -- Description:	Returns the detailed of the given portfolio + all the children
  -- =============================================
  PROCEDURE GET_FOLIO_WITH_CHILDREN
  (
    folio_ident IN Folio.ident%TYPE
    ,p_cursor   OUT T_CURSOR
  )
  AS
  BEGIN
  
      OPEN p_cursor FOR
      SELECT FOLIO.*, GET_FOLIO_FULLNAME(FOLIO.ident) AS fullname, tiers.name as fund_name
      FROM FOLIO INNER JOIN TIERS on FOLIO.ENTITE = TIERS.IDENT
      START WITH FOLIO.ident = folio_ident
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr;

  END GET_FOLIO_WITH_CHILDREN;

  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 02/01/2013
  -- Description:	Returns the full name of a portfolio
  -- =============================================
  FUNCTION GET_FOLIO_FULLNAME
  (
    folio_ident IN Folio.ident%TYPE
  )
  RETURN VARCHAR2 
  is   
    path_name  VARCHAR2(10000);
    ident_father Folio.ident%TYPE;
  BEGIN

    if  folio_ident = 1 then     
      return 'ROOT';
    end if ;
  
    select nvl(name,' '), nvl(mgr,null) into path_name, ident_father 
    from dual left join folio on 1=1 and folio.IDENT =  folio_ident;
  
    if  ident_father is null then     
      return 'Folio Not Found'; 
    end if;

    RETURN GET_FOLIO_FULLNAME(ident_father) || ':' || path_name;
  
  END; 

  -- =============================================
  -- Author:                          Gautier Oudine
  -- Create date: 27/11/2014
  -- Description: Returns the sophis fixed volatility
  -- =============================================
  PROCEDURE GET_SOPHIS_FIXED_VOLATILITY
  (
    sophisref     IN    TITRES.REFERENCE%TYPE
    ,volatility   OUT   CLAUSE.valeur%TYPE
  )
  AS
    
  BEGIN

    SELECT valeur
    INTO volatility
    FROM TITRES INNER JOIN CLAUSE ON Titres.sicovam = clause.sicovam
    WHERE reference = sophisref
	AND CLAUSE.Type = 25; -- Type Overvolatility
    
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    volatility := 0;
  
  END GET_SOPHIS_FIXED_VOLATILITY;
  
  
END PCKG_BTG_EQD;