create or replace PACKAGE            "PCKG_BTG_EQD" 
AS
  -- =============================================
  -- Author:		Gautier Oudine
  -- Create date: 19/08/2011
  -- Description:	Stored procs used by eqd business
  -- =============================================

  TYPE T_CURSOR IS REF CURSOR;
  TYPE POS_CURSOR IS REF CURSOR;

  PROCEDURE GET_QSF_RESTRICTED_LIST
  (
    p_cursor OUT T_CURSOR
  );

  PROCEDURE GET_DIVIDENDS
  (
    p_cursor OUT T_CURSOR
  );

  PROCEDURE GET_TAX
  (
    p_reference   IN    TITRES.REFERENCE%TYPE
    , p_tax       OUT   tableavoirfiscal.tauxfiscalitepays%type
  );

  PROCEDURE GET_DIVIDENDS
  (
    p_reference   IN    BTG_EQD_DIVIDENDS.REFERENCE%TYPE
    , p_cursor    OUT   T_CURSOR
  );
  
  PROCEDURE GET_ALLOCATION_RULE
  (
    p_user_name    IN    BTG_EQD_ALLOCATION_RULE.USER_NAME%TYPE
    , p_cursor    OUT   T_CURSOR
  );

  PROCEDURE GET_CFD
  (
    p_sophis_ref  IN    BTG_EQD_CFD.UL_REFERENCE%TYPE
    ,p_cursor    OUT   T_CURSOR
  );
    
  PROCEDURE GET_SOPHIS_IDENT
  (
    sophisref   IN    TITRES.REFERENCE%TYPE
    ,ident      OUT   TITRES.SICOVAM%TYPE
  );

  PROCEDURE GET_FID
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  );

  PROCEDURE GET_ISSUER
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  );

  PROCEDURE GET_ISSUER_NEW
  (
    ident         IN    RIC.SICOVAM%TYPE
    , p_cursor    OUT   T_CURSOR
  );

  PROCEDURE INSERT_FID_TICKER
  (
  -- Insert the Ctrl J information when we create an option using the integration service
    ident         IN    RIC.SICOVAM%TYPE
    , ticker      IN    RIC.SERVISEN%TYPE
    , fid_name    IN    FIDLIST.NAME%TYPE
  );
  
  PROCEDURE GET_QUANT_POSITIONS
  (
    p_folio   IN    FOLIO.IDENT%TYPE
    ,p_cursor OUT   POS_CURSOR
    ,p_date   IN    DATE              DEFAULT NULL
  );
  
  PROCEDURE GET_NET_POSITIONS
  (
    p_folio   IN    FOLIO.IDENT%TYPE
    ,p_cursor OUT POS_CURSOR
    ,p_date   IN    DATE              DEFAULT NULL
  );
  
  PROCEDURE GET_TRADES
  (
    p_folio   IN    FOLIO.IDENT%TYPE 
    ,p_cursor OUT   POS_CURSOR
     ,p_from_date   IN    DATE              DEFAULT NULL
    ,p_to_date   IN    DATE              DEFAULT NULL

  );
  
  PROCEDURE GET_FOLIO_WITH_CHILDREN
  (
    folio_ident IN Folio.ident%TYPE
    ,p_cursor   OUT T_CURSOR
  );
  
  FUNCTION GET_FOLIO_FULLNAME 
  ( 
    folio_ident IN Folio.ident%TYPE
  ) RETURN VARCHAR2;
  
  PROCEDURE GET_SOPHIS_FIXED_VOLATILITY
  (
    sophisref     IN    TITRES.REFERENCE%TYPE
    ,volatility   OUT   CLAUSE.valeur%TYPE
  );
	
  
END PCKG_BTG_EQD;