CREATE OR REPLACE PACKAGE BODY PCKG_BTG_SRVC_ACCNTNG 
AS

    PROCEDURE GetDepositary
    (
        p_id            IN      DEPOSITAIRES.ident%TYPE
       ,p_name          OUT     DEPOSITAIRES.libelle%TYPE
    ) AS
    BEGIN

    SELECT    DEPOSITAIRES.libelle
    INTO      p_name
    FROM      DEPOSITAIRES 
    WHERE     DEPOSITAIRES.ident = p_id;
        
    END GetDepositary;

    PROCEDURE GetDepositaryList
    (
        p_cursor        OUT     SYS_REFCURSOR
    ) 
    AS
    BEGIN
        
    OPEN p_cursor FOR
      SELECT    DEPOSITAIRES.ident   AS ID
      ,         DEPOSITAIRES.libelle AS NAME 
      FROM      DEPOSITAIRES 
      ORDER BY  LOWER(DEPOSITAIRES.libelle);
        
    END GetDepositaryList;

    PROCEDURE GetFolio
    (
        p_id            IN      FOLIO.ident%TYPE
       ,p_name          OUT     FOLIO.name%TYPE
       ,p_path          OUT     VARCHAR2
    ) 
    AS
    BEGIN
        
      SELECT  FOLIO.name 
      ,       SYS_CONNECT_BY_PATH(FOLIO.name, '\')
      INTO    p_name
      ,       p_path
      FROM    FOLIO
      WHERE   LEVEL > 2
      AND     FOLIO.ident = p_id
      START WITH FOLIO.ident IN (SELECT FOLIO.ident FROM FOLIO WHERE FOLIO.mgr IN (14414, 14405))
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr;
        
    END GetFolio;

    PROCEDURE GetFolioList
    (
        p_cursor        OUT     SYS_REFCURSOR
    ) 
    AS
    BEGIN

    OPEN p_cursor FOR
      SELECT  FOLIO.ident AS ID
      ,       FOLIO.name AS NAME
      ,       SYS_CONNECT_BY_PATH(FOLIO.name, '\') AS PATH
      FROM    FOLIO
      WHERE   LEVEL > 2
      START WITH FOLIO.ident IN (SELECT FOLIO.ident FROM FOLIO WHERE FOLIO.mgr IN (14414, 14405))
      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ORDER BY PATH;
                
    END GetFolioList;

    PROCEDURE GetStrategy
    (
        p_id            IN      FOLIO_STRATEGIES.code%TYPE
       ,p_name          OUT     FOLIO_STRATEGIES.name%TYPE
    ) 
    AS
    BEGIN

    SELECT    FOLIO_STRATEGIES.name
    INTO      p_name
    FROM      FOLIO_STRATEGIES 
    WHERE     FOLIO_STRATEGIES.code = p_id;
        
    END GetStrategy;

    PROCEDURE GetStrategyList
    (
        p_cursor        OUT     SYS_REFCURSOR
    ) 
    AS
    BEGIN
        OPEN p_cursor FOR
            SELECT
                FOLIO_STRATEGIES.code    AS ID
            ,   FOLIO_STRATEGIES.name    AS NAME 
            FROM FOLIO_STRATEGIES 
            ORDER BY LOWER(FOLIO_STRATEGIES.name);
    END GetStrategyList;

    PROCEDURE GetDepositaryForFolio
    (
        p_folioId       IN      TIERS.IDENT%TYPE
       ,p_sicovam       IN      TITRES.SICOVAM%TYPE
       ,p_username      IN      RISKUSERS.NAME%TYPE
        
       ,p_cursor        OUT     SYS_REFCURSOR
    )
    AS
    BEGIN
        OPEN p_cursor FOR
            SELECT DISTINCT
                FIRST_VALUE(DPS_RULE_MATCH.depositary_id) 
                OVER (
                    PARTITION BY DPS_RULE_MATCH.folio_id 
                    ORDER BY DPS_RULE_MATCH.rule_order
                )                                           AS DEPOSITARY_ID    
               ,FIRST_VALUE(DPS_RULE_MATCH.depositary_name) 
                OVER (
                    PARTITION BY DPS_RULE_MATCH.folio_id
                    ORDER BY DPS_RULE_MATCH.rule_order
                )                                           AS DEPOSITARY_NAME
                FROM 
                (
                    SELECT 
                        FOLIO.ident                         AS FOLIO_ID
                       ,FOLIO.name                          AS FOLIO_NAME                
                       ,DPS.depositary                      AS DEPOSITARY_ID
                       ,DEPOSITARY_ENTITY.name              AS DEPOSITARY_NAME
                       ,DPS.position                        AS RULE_ORDER
                    FROM BTG_DEPOSITARY_SELECTOR DPS
                    JOIN FOLIO
                        ON FOLIO.ident = p_folioId
                    JOIN TIERS FUND_ENTITY
                        ON FUND_ENTITY.ident = FOLIO.entite
                    JOIN TITRES FUND_INSTRUMENT
                        ON FUND_INSTRUMENT.code_emet = FOLIO.entite 
                    JOIN TITRES I
                        ON (I.affectation = DPS.allotment OR DPS.allotment <= 0)
                        AND (I.DEVISECTT = DPS.currency OR DPS.currency <= 0)
                        AND I.sicovam = p_sicovam
                    JOIN TIERS DEPOSITARY_ENTITY
                        ON DEPOSITARY_ENTITY.ident = DPS.depositary
                    JOIN RISKUSERS
                        ON RISKUSERS.NAME = p_username
                    WHERE (DPS.fund = FUND_INSTRUMENT.sicovam OR DPS.fund <= 0)
                        AND (DPS.trader = RISKUSERS.ident OR DPS.trader <= 0)
                ) DPS_RULE_MATCH;
    END GetDepositaryForFolio;

END PCKG_BTG_SRVC_ACCNTNG;
/
