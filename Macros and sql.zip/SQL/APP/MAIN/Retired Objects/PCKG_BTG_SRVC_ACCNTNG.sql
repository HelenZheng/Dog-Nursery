CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_ACCNTNG"
AS
    PROCEDURE GetDepositary
    (
        p_id            IN      DEPOSITAIRES.ident%TYPE
       ,p_name          OUT     DEPOSITAIRES.libelle%TYPE
    );

    PROCEDURE GetDepositaryList
    (
        p_cursor        OUT     SYS_REFCURSOR
    );

    PROCEDURE GetFolio
    (
        p_id            IN      FOLIO.ident%TYPE
       ,p_name          OUT     FOLIO.name%TYPE
       ,p_path          OUT     VARCHAR2
    );

    PROCEDURE GetFolioList
    (
        p_cursor        OUT     SYS_REFCURSOR
    );

    PROCEDURE GetStrategy
    (
        p_id            IN      FOLIO_STRATEGIES.code%TYPE
       ,p_name          OUT     FOLIO_STRATEGIES.name%TYPE
    );

    PROCEDURE GetStrategyList
    (
        p_cursor        OUT     SYS_REFCURSOR
    );

    PROCEDURE GetDepositaryForFolio
    (
        p_folioId       IN      TIERS.IDENT%TYPE
       ,p_sicovam       IN      TITRES.SICOVAM%TYPE
       ,p_username      IN      RISKUSERS.NAME%TYPE
        
       ,p_cursor        OUT     SYS_REFCURSOR
    );

END PCKG_BTG_SRVC_ACCNTNG;
/