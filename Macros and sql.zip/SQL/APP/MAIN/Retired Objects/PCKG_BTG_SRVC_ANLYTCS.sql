CREATE OR REPLACE
PACKAGE            "PCKG_BTG_SRVC_ANLYTCS" 
AS

--------------------------------------------------------------------------------

  INSTRUMENT_NOT_FOUND EXCEPTION;
  
--------------------------------------------------------------------------------

  PROCEDURE GetPrices
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetPricesForDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_date                          IN      HISTORIQUE.jour%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetPricesFromDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_from_date                     IN      HISTORIQUE.jour%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  ); 
  
--------------------------------------------------------------------------------

  PROCEDURE GetPricesInDateRange
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_from_date                     IN      HISTORIQUE.jour%TYPE
  , p_to_date                       IN      HISTORIQUE.jour%TYPE
  , p_cursor                        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (    
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_close_price                   IN      HISTORIQUE.d%TYPE  
  );
  
--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (    
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_theorectical_price            IN      HISTORIQUE.t%TYPE
  );
  
--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (    
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_close_price                   IN      HISTORIQUE.d%TYPE
  , p_theorectical_price            IN      HISTORIQUE.t%TYPE
  );
  
--------------------------------------------------------------------------------

END PCKG_BTG_SRVC_ANLYTCS;
 
CREATE OR REPLACE
PACKAGE BODY PCKG_BTG_SRVC_ANLYTCS
AS

--------------------------------------------------------------------------------

  TYPE T_SICOVAM_TAB IS TABLE OF TITRES.sicovam%TYPE;
  
--------------------------------------------------------------------------------

  PROCEDURE GetPrices
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT    HISTORIQUE.sicovam AS SICOVAM
      ,         HISTORIQUE.jour AS "DATE"
      ,         HISTORIQUE.d AS CLOSE_PRICE
      ,         HISTORIQUE.t AS THEORECTICAL_PRICE
      ,         ISINS.value AS ISIN
      ,         SEDOLS.value AS SEDOL
      ,         CUSIPS.value as CUSIP 
      FROM      HISTORIQUE
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISINS
      ON ISINS.sophis_ident = HISTORIQUE.sicovam
      AND ISINS.ref_ident = 1
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS SEDOLS
      ON SEDOLS.sophis_ident = HISTORIQUE.sicovam
      AND SEDOLS.ref_ident = 2
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CUSIPS
      ON CUSIPS.sophis_ident = HISTORIQUE.sicovam
      AND CUSIPS.ref_ident = 3
      WHERE     HISTORIQUE.sicovam IN 
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference) 
      )
      ORDER BY  HISTORIQUE.jour;
      
  END;

--------------------------------------------------------------------------------

  PROCEDURE GetPricesForDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_date                          IN      HISTORIQUE.jour%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    HISTORIQUE.sicovam AS SICOVAM
      ,         HISTORIQUE.jour AS "DATE"
      ,         HISTORIQUE.d AS CLOSE_PRICE
      ,         HISTORIQUE.t AS THEORECTICAL_PRICE
      ,         ISINS.value AS ISIN
      ,         SEDOLS.value AS SEDOL
      ,         CUSIPS.value as CUSIP  
      FROM      HISTORIQUE
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISINS
      ON ISINS.sophis_ident = HISTORIQUE.sicovam
      AND ISINS.ref_ident = 1
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS SEDOLS
      ON SEDOLS.sophis_ident = HISTORIQUE.sicovam
      AND SEDOLS.ref_ident = 2
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CUSIPS
      ON CUSIPS.sophis_ident = HISTORIQUE.sicovam
      AND CUSIPS.ref_ident = 3      
      WHERE     HISTORIQUE.sicovam IN 
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)  
      )
      AND       HISTORIQUE.jour = TRUNC(p_date) 
      ORDER BY  HISTORIQUE.jour;
    
  END;

--------------------------------------------------------------------------------

  PROCEDURE GetPricesFromDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_from_date                     IN      HISTORIQUE.jour%TYPE  
  , p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT    HISTORIQUE.sicovam AS SICOVAM
      ,         HISTORIQUE.jour AS "DATE"
      ,         HISTORIQUE.d AS CLOSE_PRICE
      ,         HISTORIQUE.t AS THEORECTICAL_PRICE
      ,         ISINS.value AS ISIN
      ,         SEDOLS.value AS SEDOL
      ,         CUSIPS.value as CUSIP 
      FROM      HISTORIQUE
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISINS
      ON ISINS.sophis_ident = HISTORIQUE.sicovam
      AND ISINS.ref_ident = 1
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS SEDOLS
      ON SEDOLS.sophis_ident = HISTORIQUE.sicovam
      AND SEDOLS.ref_ident = 2
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CUSIPS
      ON CUSIPS.sophis_ident = HISTORIQUE.sicovam
      AND CUSIPS.ref_ident = 3      
      WHERE     HISTORIQUE.sicovam IN
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)  
      )
      AND       HISTORIQUE.jour >= TRUNC(p_from_date)
      ORDER BY  HISTORIQUE.jour;
    
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE GetPricesInDateRange
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE  
  , p_from_date                     IN      HISTORIQUE.jour%TYPE
  , p_to_date                       IN      HISTORIQUE.jour%TYPE
  , p_cursor                        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    HISTORIQUE.sicovam AS SICOVAM
      ,         HISTORIQUE.jour AS "DATE"
      ,         HISTORIQUE.d AS CLOSE_PRICE
      ,         HISTORIQUE.t AS THEORECTICAL_PRICE
      ,         ISINS.value AS ISIN
      ,         SEDOLS.value AS SEDOL
      ,         CUSIPS.value as CUSIP 
      FROM      HISTORIQUE
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISINS
      ON ISINS.sophis_ident = HISTORIQUE.sicovam
      AND ISINS.ref_ident = 1
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS SEDOLS
      ON SEDOLS.sophis_ident = HISTORIQUE.sicovam
      AND SEDOLS.ref_ident = 2
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CUSIPS
      ON CUSIPS.sophis_ident = HISTORIQUE.sicovam
      AND CUSIPS.ref_ident = 3      
      WHERE     HISTORIQUE.sicovam IN
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
      )
      AND       HISTORIQUE.jour >= TRUNC(p_from_date)
      AND       HISTORIQUE.jour <= TRUNC(p_to_date)
      ORDER BY  HISTORIQUE.jour;
      
    END;
  
--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_close_price                   IN      HISTORIQUE.d%TYPE  
  )
  AS
  
    l_sicovams T_SICOVAM_TAB;
    
  BEGIN
       
    MERGE INTO HISTORIQUE
    USING (
      SELECT DISTINCT SICOVAM
      FROM 
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code as SICOVAM
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
      )
    ) SICOVAMS
    ON (HISTORIQUE.sicovam = SICOVAMS.sicovam AND HISTORIQUE.jour = TRUNC(p_date))
    WHEN MATCHED THEN UPDATE SET HISTORIQUE.d = p_close_price
    WHEN NOT MATCHED THEN INSERT (sicovam, jour, d) VALUES (SICOVAMS.sicovam, TRUNC(p_date), p_close_price);
    
    IF SQL%ROWCOUNT = 0 THEN
      RAISE INSTRUMENT_NOT_FOUND; 
    END IF;
      
  EXCEPTION
  
    WHEN INSTRUMENT_NOT_FOUND 

      THEN RAISE_APPLICATION_ERROR(-20111, 'Instrument not found.');
  
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_theorectical_price            IN      HISTORIQUE.t%TYPE
  )  
  AS
  
    l_sicovams T_SICOVAM_TAB;
    
  BEGIN
        
    MERGE INTO HISTORIQUE
    USING (
      SELECT DISTINCT SICOVAM
      FROM 
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code as SICOVAM
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
      )
    ) SICOVAMS
    ON (HISTORIQUE.sicovam = SICOVAMS.sicovam AND HISTORIQUE.jour = TRUNC(p_date))
    WHEN MATCHED THEN UPDATE SET HISTORIQUE.t = p_theorectical_price
    WHEN NOT MATCHED THEN INSERT (sicovam, jour, t) VALUES (SICOVAMS.sicovam, TRUNC(p_date), p_theorectical_price);
    
    IF SQL%ROWCOUNT = 0 THEN 
      RAISE INSTRUMENT_NOT_FOUND; 
    END IF;
        
  EXCEPTION
  
    WHEN INSTRUMENT_NOT_FOUND 

      THEN RAISE_APPLICATION_ERROR(-20111, 'Instrument not found.');
  
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE SetPriceForDate
  (
    p_sicovam                       IN      TITRES.sicovam%TYPE
  , p_reference                     IN      TITRES.reference%TYPE
  , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
  , p_user_reference                IN      RIC.servisen%TYPE
  , p_date                          IN      HISTORIQUE.jour%TYPE
  , p_close_price                   IN      HISTORIQUE.d%TYPE
  , p_theorectical_price            IN      HISTORIQUE.t%TYPE
  )
  AS
  
    l_sicovams T_SICOVAM_TAB;
    
  BEGIN
  
    MERGE INTO HISTORIQUE
    USING (
      SELECT DISTINCT SICOVAM
      FROM 
      (
        SELECT  TITRES.sicovam
        FROM    TITRES
        WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
        OR      (p_reference IS NOT NULL AND TITRES.reference = p_reference)          
        UNION          
        SELECT  TAUX.sicovam
        FROM    TAUX
        WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
        UNION
        SELECT  devisev2.code as SICOVAM
        FROM    devisev2
        WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
        UNION
        SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
        FROM    EXTRNL_REFERENCES_INSTRUMENTS
        WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_isin)
        OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_sedol)
        OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND EXTRNL_REFERENCES_INSTRUMENTS.value = p_cusip)          
        UNION          
        SELECT  RIC.sicovam          
        FROM    RIC
        WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
      )
    ) SICOVAMS
    ON (HISTORIQUE.sicovam = SICOVAMS.sicovam AND HISTORIQUE.jour = TRUNC(p_date))
    WHEN MATCHED THEN UPDATE SET HISTORIQUE.d = p_close_price, HISTORIQUE.t = p_theorectical_price
    WHEN NOT MATCHED THEN INSERT (sicovam, jour, d, t) VALUES (SICOVAMS.sicovam, TRUNC(p_date), p_close_price, p_theorectical_price);
    
    IF SQL%ROWCOUNT = 0 THEN 
      RAISE INSTRUMENT_NOT_FOUND; 
    END IF;         
                
  EXCEPTION
  
    WHEN INSTRUMENT_NOT_FOUND 

      THEN RAISE_APPLICATION_ERROR(-20111, 'Instrument not found.');
  
  END;

--------------------------------------------------------------------------------

END PCKG_BTG_SRVC_ANLYTCS;