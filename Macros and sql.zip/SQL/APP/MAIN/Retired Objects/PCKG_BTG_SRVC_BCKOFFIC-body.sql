CREATE OR REPLACE PACKAGE BODY PCKG_BTG_SRVC_BCKOFFIC
AS

PROCEDURE GetAllotments
(
  p_cursor                        OUT     SYS_REFCURSOR
                      
)
AS
BEGIN
  OPEN p_cursor FOR
    SELECT
         IDENT AS ID
        ,LIBELLE AS NAME
    FROM AFFECTATION
    ORDER BY LIBELLE;

END GetAllotments;

PROCEDURE GetBusinessEvents
(
  p_cursor                        OUT     SYS_REFCURSOR
                      
)
AS
BEGIN
  OPEN p_cursor FOR
    SELECT
         ID
        ,NAME
    FROM BUSINESS_EVENTS
    ORDER BY NAME;

END GetBusinessEvents;

END PCKG_BTG_SRVC_BCKOFFIC;
/