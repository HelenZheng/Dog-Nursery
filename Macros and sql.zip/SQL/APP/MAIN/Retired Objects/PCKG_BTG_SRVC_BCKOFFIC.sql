﻿CREATE OR REPLACE PACKAGE PCKG_BTG_SRVC_BCKOFFIC 
AS

PROCEDURE GetAllotments
(
  p_cursor                        OUT     SYS_REFCURSOR
);

PROCEDURE GetBusinessEvents
(
  p_cursor                        OUT     SYS_REFCURSOR
);

END PCKG_BTG_SRVC_BCKOFFIC;
/