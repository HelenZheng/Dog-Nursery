﻿CREATE OR REPLACE PACKAGE BODY "PCKG_BTG_SRVC_CFDS" 
AS

PROCEDURE GetFinancingTransactions
(
  p_tradeDate                    IN      DATE := SYSDATE
, p_cursor                       OUT     SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
          I.SICOVAM                                   AS INSTRUMENT_ID          -- 0
        , I.REFERENCE                                 AS INSTRUMENT_REFERENCE 
        
        , CASE WHEN 
            --UI1.type = 'I' 
            COALESCE(UI1.type, UI2.type, UI3.type) = 'I'
          THEN 
            --ERI1.value 
            COALESCE(ERI1.value, ERI2.value, ERI3.value)
          ELSE ER.value
          END                                         AS UNDERLYING_SEDOL

        , T.REFCON                                    AS TRADE_ID
        , T.DATENEG                                   AS TRADE_DATE
        , T.DATEVAL                                   AS TRADE_VALUE_DATE       -- 5
        , C.IDENT                                     AS COUNTERPARTY_ID
        , C.LIBELLE                                   AS COUNTERPARTY_NAME
        , B.IDENT                                     AS BROKER_ID
        , B.LIBELLE                                   AS BROKER_NAME
        , D.IDENT                                     AS DEPOSITARY_ID          --10
        , D.LIBELLE                                   AS DEPOSITARY_NAME
        , T.ENTITE                                    AS FUND_ID
        , E.NAME                                      AS FUND_NAME
        , T.MONTANT                                   AS TRADE_NET
        , T.COURS                                     AS TRADE_PRICE            --15
        , T.QUANTITE                                  AS TRADE_QUANTITY
        , DEVISE_TO_STR(T.DEVISEPAY)                  AS TRADE_CURRENCY
        , I.NOMINAL                                   AS INSTRUMENT_NOMINAL
        , T.TYPE                                      AS TRADE_TYPE
        , T.OPERATEUR                                 AS TRADE_TRADER_ID
        , RU.NAME                                     AS TRADE_TRADER_NAME
        , I.LIBELLE                                   AS INSTRUMENT_NAME 
        , F.IDENT                                     AS FOLIO_ID
        , F.NAME                                      AS FOLIO_NAME

        FROM TITRES I
        
        JOIN HISTOMVTS T
          ON  T.SICOVAM = I.SICOVAM

        LEFT JOIN TITRES UI1
          ON UI1.SICOVAM = I.code_emet
        LEFT JOIN TITRES UI2
          ON UI2.SICOVAM = I.codesj
        LEFT JOIN TITRES UI3
          ON UI3.SICOVAM = I.codesj2

        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ER
          ON ER.SOPHIS_IDENT = I.code_emet
          AND ER.REF_IDENT = 2 

        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ERI1
          ON ERI1.SOPHIS_IDENT = I.code_emet
          AND ERI1.REF_IDENT = 682 
        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ERI2
          ON ERI2.SOPHIS_IDENT = I.codesj
          AND ERI2.REF_IDENT = 682 
        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ERI3
          ON ERI3.SOPHIS_IDENT = I.codesj2
          AND ERI3.REF_IDENT = 682 

        JOIN BUSINESS_EVENTS BE
          ON  BE.ID = T.TYPE
        JOIN CONTREPARTIES C
          ON C.IDENT = T.CONTREPARTIE      
        JOIN DEPOSITAIRES D
          ON D.IDENT = T.DEPOSITAIRE      
        JOIN COURTIERS B
          ON B.IDENT = T.COURTIER
        JOIN TIERS E
          ON E.IDENT = T.ENTITE
          AND estclient(options) = 1
        JOIN RISKUSERS RU
          ON T.OPERATEUR = RU.IDENT
        JOIN FOLIO F
          ON T.OPCVM = F.IDENT
        
        WHERE   I.AFFECTATION = 12
          AND   T.TYPE = 143
          AND (p_tradeDate IS NOT NULL AND T.DATENEG = TRUNC(p_tradeDate));

END GetFinancingTransactions;

PROCEDURE GetFeeDetails
(
	p_positionsDate             	IN      DATE := NULL, 
	p_cursor                        OUT     SYS_REFCURSOR
)
AS 
BEGIN
	OPEN p_cursor FOR
		SELECT  FUND_BOOK_STRATEGY.Fund_NAME            Fund
			,TITRES.sicovam                             Sicovam
			,HISTOMVTS.opcvm                            Folio_ID
			,TITRES.reference                           CFD_Reference
			,DEVISE_TO_STR(TITRES.devisectt)            CFD_Currency
			,TIERS.name                                 Depositary
			,TIERS.ident                                Depositary_Code
			,SUM(HISTOMVTS.quantite)                    Quantity
			,CASE
				WHEN Underlying.TYPE = 'I' THEN EXTRNL_REFERENCES_INSTRUMENTS.value
				ELSE ULY_SEDOL.value
			END                                         Underlying_SEDOL
			,UNDERLYING.libelle                         Underlying_Name
      
		FROM HISTOMVTS
		INNER JOIN BUSINESS_EVENTS
			ON BUSINESS_EVENTS.id = HISTOMVTS.TYPE
			AND BUSINESS_EVENTS.compta = 1
		INNER JOIN TITRES --join only on CFDs
			ON TITRES.sicovam = HISTOMVTS.sicovam 
			AND TITRES.TYPE = 'G'
		INNER JOIN TITRES UNDERLYING
			ON UNDERLYING.sicovam = TITRES.code_emet
		LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ULY_ISIN
			ON ULY_ISIN.sophis_ident = UNDERLYING.sicovam
			AND ULY_ISIN.REF_IDENT = 1
		LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ULY_SEDOL
			ON ULY_SEDOL.sophis_ident = UNDERLYING.sicovam
			AND ULY_SEDOL.REF_IDENT = 2
		LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
			ON EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident = TITRES.sicovam
			AND EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 682
		INNER JOIN TIERS
			ON TIERS.ident = HISTOMVTS.depositaire
		INNER JOIN ( 
			SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                      AS TOP_FUND_ID
				, CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
				, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
				, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME
				, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
				, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME
				, FOLIO.ident                                                         AS STRATEGY_ID
				, FOLIO.name                                                          AS STRATEGY_NAME
				, LEVEL
			FROM FOLIO
			WHERE LEVEL >= 4
			START WITH FOLIO.ident IN (14414,14405)--Primary funds and Secondary Funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
		) FUND_BOOK_STRATEGY
			ON FUND_BOOK_STRATEGY.STRATEGY_ID =  HISTOMVTS.OPCVM
			WHERE HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
			AND HISTOMVTS.dateneg <= (p_positionsDate) --Negotiation date selected by user in tool (replace with sysdate-1 to test)
			GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, TITRES.sicovam, HISTOMVTS.opcvm, TITRES.reference, DEVISE_TO_STR(TITRES.devisectt), TIERS.name, TIERS.ident, EXTRNL_REFERENCES_INSTRUMENTS.value, 
			CASE
				WHEN Underlying.TYPE = 'I' THEN EXTRNL_REFERENCES_INSTRUMENTS.value
				ELSE ULY_SEDOL.value
			END, ULY_ISIN.value, UNDERLYING.libelle
				HAVING (
                    (SUM(HISTOMVTS.quantite) > 0 or SUM(HISTOMVTS.quantite) < 0)  --open positions
                    OR
                    (SUM(HISTOMVTS.quantite) = 0 and (MAX(TRUNC(HISTOMVTS.dateneg)) >= ((p_positionsDate)-38))) --position was closed less than or equal to 38 days ago (replace p_positionsDate with sysdate-1 to test)
				)
			ORDER BY 1, 6, 2;
	
END GetFeeDetails;

END PCKG_BTG_SRVC_CFDS;
/