﻿CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_CFDS" 
AS

PROCEDURE GetFinancingTransactions
(
  p_tradeDate                    IN      DATE := SYSDATE
, p_cursor                       OUT     SYS_REFCURSOR
);

PROCEDURE GetFeeDetails
(
	p_positionsDate             	IN      DATE := NULL, 
	p_cursor                        OUT     SYS_REFCURSOR
);

END PCKG_BTG_SRVC_CFDS;
