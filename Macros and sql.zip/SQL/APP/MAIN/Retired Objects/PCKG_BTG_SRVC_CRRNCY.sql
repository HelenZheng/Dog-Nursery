﻿CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_CRRNCY" 
AS

PROCEDURE GetCurrencyHolidays
(
  p_currency                      IN      VARCHAR
, p_cursor                        OUT     SYS_REFCURSOR
);

PROCEDURE GetCurrency
(
p_id                            IN      VARCHAR
, p_name                          OUT     DEVISEV2.libelle%type
);
  
PROCEDURE GetCurrencies
(
p_cursor                        OUT     SYS_REFCURSOR
);

END PCKG_BTG_SRVC_CRRNCY;
/