CREATE OR REPLACE PACKAGE BODY PCKG_BTG_SRVC_INSTRUMENTS
AS
--------------------------------------------------------------------------------
    FUNCTION TestInstrumentExists
    (
          p_sicovam                       IN      TITRES.sicovam%TYPE
        , p_reference                     IN      TITRES.reference%TYPE
        , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_user_reference                IN      RIC.servisen%TYPE
    )
    RETURN INTEGER
    IS
        r_count      INTEGER    := 0;
    BEGIN
      
        SELECT COUNT(*) INTO r_count
        FROM 
        (
          SELECT  TITRES.sicovam
          FROM    TITRES
          WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
          OR      (p_reference IS NOT NULL AND UPPER(TITRES.reference) = SUBSTR(UPPER(p_reference),0,24))          
          UNION          
          SELECT  TAUX.sicovam
          FROM    TAUX
          WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
          UNION
          SELECT  devisev2.code as SICOVAM
          FROM    devisev2
          WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
          UNION
          SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
          FROM    EXTRNL_REFERENCES_INSTRUMENTS
          WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_isin))
          OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_sedol))
          OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_cusip))          
          UNION          
          SELECT  RIC.sicovam          
          FROM    RIC
          WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
        );
       RETURN r_count;

    END TestInstrumentExists;
-----------------------------------

    FUNCTION GetSicovamForInstrument
    (
          p_sicovam                       IN      TITRES.sicovam%TYPE
        , p_reference                     IN      TITRES.reference%TYPE
        , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
        , p_user_reference                IN      RIC.servisen%TYPE
    )
    RETURN INTEGER
    IS
        r_sicovam      INTEGER    := 0;
    BEGIN
        SELECT sicovam INTO r_sicovam
        FROM 
        (
          SELECT  TITRES.sicovam                                                AS SICOVAM
          FROM    TITRES
          WHERE   (p_sicovam IS NOT NULL AND TITRES.sicovam = p_sicovam)          
          OR      (p_reference IS NOT NULL AND UPPER(TITRES.reference) = SUBSTR(UPPER(p_reference),0,24))          
              
          UNION          
          SELECT  TAUX.sicovam                                                  AS SICOVAM
          FROM    TAUX
          WHERE   (p_sicovam IS NOT NULL AND TAUX.sicovam = p_sicovam)
              
          UNION
          SELECT  devisev2.code                                                 AS SICOVAM
          FROM    devisev2
          WHERE   (p_sicovam IS NOT NULL AND devisev2.code = p_sicovam)
              
          UNION
          SELECT  EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident                    AS SICOVAM
          FROM    EXTRNL_REFERENCES_INSTRUMENTS
          WHERE   (p_isin IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 1 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_isin))
          OR      (p_sedol IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 2 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_sedol))
          OR      (p_cusip IS NOT NULL AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 3 AND UPPER(EXTRNL_REFERENCES_INSTRUMENTS.value) = UPPER(p_cusip))          
              
          UNION          
          SELECT  RIC.sicovam                                                   AS SICOVAM          
          FROM    RIC
          WHERE   (p_user_reference IS NOT NULL AND RIC.servisen = p_user_reference)
        );
        RETURN r_sicovam;
        EXCEPTION 
            WHEN NO_DATA_FOUND  THEN
                RETURN 0;
    END GetSicovamForInstrument;
-----------------------------------

    PROCEDURE GetInstrument
    (
          p_sicovam                       IN      TITRES.sicovam%TYPE
    , p_cursor                          OUT     SYS_REFCURSOR
    )
    AS
    BEGIN
        OPEN p_cursor FOR
            SELECT
                I.SICOVAM                                       AS INSTRUMENT_ID                -- 0
                , I.REFERENCE                                   AS INSTRUMENT_REFERENCE 
                , I.NOMINAL                                     AS INSTRUMENT_NOMINAL
                , I.LIBELLE                                     AS INSTRUMENT_NAME
                , I.MODELE                                      AS INSTRUMENT_MODEL
                , A.IDENT                                       AS INSTRUMENT_ALLOTMENT_ID      -- 5
                , A.LIBELLE                                     AS INSTRUMENT_ALLOTMENT_NAME
                , PCKG_BTG_SRVC_SCTRS.GetSectorStringForInstrument(I.SICOVAM) AS SECTORS
                , DEVISE_TO_STR(I.DEVISECTT)                    AS INSTRUMENT_CURRENCY
                , I.SETTLE_SHIFT                                AS INSTRUMENT_SETTLE_SHIFT
                , NULLIF(I.BASE1, 0)                            AS INSTRUMENT_INDEX_ID          -- 10
                , COALESCE(NULLIF(I.UNIT1, 0), I.BASIS_AC)      AS INSTRUMENT_BASIS_ID
                , ER1.VALUE                                     AS INSTRUMENT_ISIN
                , ER2.VALUE                                     AS INSTRUMENT_CUSIP
                , I.MINIMUMPIECE                                AS INSTRUMENT_MINIMUMPIECE
                , I.LOWESTINCREMENT                             AS INSTRUMENT_LOWESTINCREMENT   -- 15
                , INSTRUMENT_HISTORICAL.LAST_PRICE              AS INSTRUMENT_PRICE
                , I.FIRSTSETTLEMENTDATE                         AS INSTRUMENT_FIRST_SETTLEMENT
           FROM TITRES I
            JOIN AFFECTATION A
                ON I.AFFECTATION = A.IDENT
            LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ER1 
                ON ER1.SOPHIS_IDENT = I.SICOVAM
                AND ER1.ref_ident = 1
            LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ER2 
                ON ER2.SOPHIS_IDENT = I.SICOVAM
                AND ER2.ref_ident = 3
            LEFT JOIN 
            (   SELECT
                SICOVAM                                               
                ,D                                              AS LAST_PRICE
                FROM HISTORIQUE 
                WHERE SICOVAM = p_sicovam
                AND ROWNUM = 1
                ORDER BY JOUR DESC
            ) INSTRUMENT_HISTORICAL
            ON INSTRUMENT_HISTORICAL.SICOVAM = I.SICOVAM
            WHERE (p_sicovam IS NOT NULL AND p_sicovam = I.SICOVAM);
    
    END GetInstrument;
    
END PCKG_BTG_SRVC_INSTRUMENTS;
/
