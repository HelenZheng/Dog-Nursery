CREATE OR REPLACE PACKAGE PCKG_BTG_SRVC_INSTRUMENTS
AS
  
    FUNCTION TestInstrumentExists
    (
      p_sicovam                       IN      TITRES.sicovam%TYPE
    , p_reference                     IN      TITRES.reference%TYPE
    , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_user_reference                IN      RIC.servisen%TYPE
    )
    RETURN INTEGER;
    
    
    FUNCTION GetSicovamForInstrument
    (
      p_sicovam                       IN      TITRES.sicovam%TYPE
    , p_reference                     IN      TITRES.reference%TYPE
    , p_isin                          IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_sedol                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_cusip                         IN      EXTRNL_REFERENCES_INSTRUMENTS.value%TYPE
    , p_user_reference                IN      RIC.servisen%TYPE
    )
    RETURN INTEGER;

    PROCEDURE GetInstrument
    (
      p_sicovam                         IN      TITRES.sicovam%TYPE

    , p_cursor                          OUT     SYS_REFCURSOR
    );

END PCKG_BTG_SRVC_INSTRUMENTS;
/
