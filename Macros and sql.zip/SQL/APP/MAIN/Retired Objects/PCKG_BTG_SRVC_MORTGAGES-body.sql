CREATE OR REPLACE PACKAGE BODY "PCKG_BTG_SRVC_MORTGAGES" 
AS



/* TODO
  - extend both procedures to accept identifiers list rather than just 'age criteria'
  - extend get redemptions to allow fitlering to only instruments with positions in date range
*/

PROCEDURE GetMortgageRedemptions
(
  p_historicalMonths              IN      INT := 360
, p_sicovam                       IN      INT := NULL
, p_offsetDate                    IN      DATE := SYSDATE
, p_periodMultiplier              IN      INT := 1
, p_cursor                        OUT     SYS_REFCURSOR
                       
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT
      I.SICOVAM                                   AS INSTRUMENT_ID              -- 0
    , I.REFERENCE                                 AS INSTRUMENT_REFERENCE 
    , I.NOMINAL                                   AS INSTRUMENT_NOMINAL
    , NULLIF(I.BASE1, 0)                          AS INDEX_ID
    , A.DATEECH                                   AS FIXED_DATE
    , NULLIF(A.POOLFACTOR, -10000000)             AS FIXED_POOLFACTOR           -- 5
    , I.CROIDIV                                   AS FIXED_COUPON
    , NUM_TO_DATE(F.DEBUT)                        AS FLOATING_START_DATE
    , NUM_TO_DATE(F.FIN)                          AS FLOATING_END_DATE
    , NULLIF(F.POOLFACTOR, -10000000)             AS FLOATING_POOLFACTOR
    , CASE II.MODELE
      WHEN 'Inverse Floater' THEN 
        NULLIF(H.D, -10000000) * -1  
      ELSE 
        NULLIF(H.D, -10000000) END   AS FLOATING_THEORETICAL
    , COALESCE(NULLIF(F.TAUX2, -10000000), 0)     AS FLOATING_SPREAD
    , COALESCE(A.DATEECH, NUM_TO_DATE(F.FIN))     AS MATCHING_DATE
    , ROWNUM                                      AS REDEMPTION_ROWID
    , II.MODELE                                   AS INDEX_MODEL
    , BTG_BUSINESS_DATE_HOLIDAY(NUM_TO_DATE(F.DEBUT),
        COALESCE(II.NBTITRES, 0),
        I.DEVISECTT,
        -1)                                       AS FLOATING_FIXING_DATE       -- 15
    , ER.VALUE                                    AS FLOATING_INDEX_TICKER
    , I.LIBELLE                                   AS INSTRUMENT_NAME
    , A.COUPON / (I.NOMINAL / 100)                AS FIXED_COUPON_RATE


    FROM  TITRES I
    LEFT JOIN TITRES II
      ON II.SICOVAM = I.BASE1
    LEFT JOIN AMORTISSEMENT A
      ON A.SICOVAM = I.SICOVAM
      AND A.DATEECH > ADD_MONTHS(p_offsetDate, -p_historicalMonths)
      AND A.DATEECH <= ADD_MONTHS(p_offsetDate, p_periodMultiplier * FreqIdToPeriod(I.FREQ_COUPON))
    LEFT JOIN FLUXJAMBE F
      ON F.SICOVAM = I.SICOVAM
      AND NUM_TO_DATE(F.FIN) > ADD_MONTHS(p_offsetDate, -p_historicalMonths)
      AND NUM_TO_DATE(F.DEBUT) <= ADD_MONTHS(p_offsetDate, p_periodMultiplier * FreqIdToPeriod(I.DUREE1))
    LEFT JOIN HISTORIQUE H
      ON I.BASE1 = H.SICOVAM
      AND H.JOUR = BTG_BUSINESS_DATE_HOLIDAY(NUM_TO_DATE(F.DEBUT), COALESCE(II.NBTITRES, 0), I.DEVISECTT, -1)
    LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ER
        ON I.BASE1 = ER.SOPHIS_IDENT 
        AND ER.REF_IDENT = 667
    WHERE I.TYPE = 'O'
      AND I.MODELE IN ('ABS Bond', 'ABS IO')
      AND I.AFFECTATION IN (35, 38, 1252, 1253, 1450)
      AND COALESCE(A.DATEECH, NUM_TO_DATE(F.FIN)) IS NOT NULL
      AND   ((p_sicovam IS NULL 
--        AND I.SICOVAM IN ( 
--           69254652
--          ,67683090
--          ,69198346
--          ,67818143
--          ,67663579
--    )
      ) OR (p_sicovam IS NOT NULL AND I.SICOVAM = p_sicovam))
    ORDER BY 
     INSTRUMENT_ID,
     FIXED_DATE,
     FLOATING_END_DATE;

END GetMortgageRedemptions;

PROCEDURE GetMortgageTransactions
(
  p_historicalMonths              IN      INT := 360
, p_sicovam                       IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT
      I.SICOVAM                                   AS INSTRUMENT_ID          -- 0
    , I.REFERENCE                                 AS INSTRUMENT_REFERENCE 
    , T.REFCON                                    AS TRADE_ID
    , ABS(TBTG.BLOCK_ID)                          AS TRADE_EXECUTION_ID
    , T.DATENEG                                   AS TRADE_DATE
    , T.DATEVAL                                   AS TRADE_VALUE_DATE       -- 5
    , C.IDENT                                     AS COUNTERPARTY_ID
    , C.LIBELLE                                   AS COUNTERPARTY_NAME
    , T.ENTITE                                    AS FUND_ID
    , E.NAME                                      AS FUND_NAME
    , T.COUPON                                    AS TRADE_COUPON           -- 10
    , T.MONTANT                                   AS TRADE_NET
    , T.MONTANTCOURU                              AS TRADE_ACCRUED
    , T.COURS                                     AS TRADE_PRICE
    , T.QUANTITE                                  AS TRADE_QUANTITY
    , DEVISE_TO_STR(T.DEVISEPAY)                  AS TRADE_CURRENCY         -- 15
    , I.NOMINAL                                   AS INSTRUMENT_NOMINAL
    , ROWNUM                                      AS TRADE_ROWID
    , T.TYPE                                      AS TRADE_TYPE
    , I.MODELE                                    AS INSTRUMENT_MODEL
    , A.IDENT                                     AS INSTRUMENT_ALLOCATION_ID -- 20
    , A.LIBELLE                                   AS INSTRUMENT_ALLOCATION_NAME
    , T.OPERATEUR                                 AS TRADE_TRADER_ID
    , RU.NAME                                     AS TRADE_TRADER_NAME
    , I.LIBELLE                                   AS INSTRUMENT_NAME 
    , BROKER.LIBELLE                              AS TRADE_BROKER_NAME          -- 25
    FROM TITRES I
    JOIN HISTOMVTS T
      ON  T.SICOVAM = I.SICOVAM
      AND T.DATENEG > add_months(trunc(sysdate, 'mm'), -p_historicalMonths)
    JOIN BUSINESS_EVENTS BE
      ON  BE.ID = T.TYPE
      AND BE.COMPTA = 1 --this shows all business events that affects position
    LEFT JOIN TA_BLOCK_TO_GENERATED TBTG
      ON  TBTG.GENERATED_ID = T.REFCON
    JOIN CONTREPARTIES C
      ON C.IDENT = T.CONTREPARTIE      
    JOIN TIERS E
      ON E.IDENT = T.ENTITE
      AND estclient(options) = 1
    JOIN AFFECTATION A
      ON I.AFFECTATION = A.IDENT
    JOIN RISKUSERS RU
      ON T.OPERATEUR = RU.IDENT
    JOIN COURTIERS BROKER
      ON T.COURTIER = BROKER.IDENT
    WHERE I.TYPE = 'O'
      AND   I.MODELE IN ('ABS Bond', 'ABS IO')
      AND   I.AFFECTATION IN (35, 38, 1252, 1253, 1450)
      AND   T.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
      AND   ((p_sicovam IS NULL 
--        AND I.SICOVAM IN ( 
--           69254652
--          ,67683090
--          ,69198346
--          ,67818143
--          ,67663579
--    )
      ) OR (p_sicovam IS NOT NULL AND I.SICOVAM = p_sicovam))
    ORDER BY INSTRUMENT_ID;

END GetMortgageTransactions;

PROCEDURE GetMortgageTransaction
(
  p_refcon                        IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
)
AS
BEGIN

  OPEN p_cursor FOR
    SELECT
      I.SICOVAM                                   AS INSTRUMENT_ID              -- 0
    , I.REFERENCE                                 AS INSTRUMENT_REFERENCE 
    , T.REFCON                                    AS TRADE_ID
    , ABS(TBTG.BLOCK_ID)                          AS TRADE_EXECUTION_ID
    , T.DATENEG                                   AS TRADE_DATE
    , T.DATEVAL                                   AS TRADE_VALUE_DATE           -- 5
    , C.IDENT                                     AS COUNTERPARTY_ID
    , C.LIBELLE                                   AS COUNTERPARTY_NAME
    , T.ENTITE                                    AS FUND_ID
    , E.NAME                                      AS FUND_NAME
    , T.COUPON                                    AS TRADE_COUPON               -- 10
    , T.MONTANT                                   AS TRADE_NET
    , T.MONTANTCOURU                              AS TRADE_ACCRUED
    , T.COURS                                     AS TRADE_PRICE
    , T.QUANTITE                                  AS TRADE_QUANTITY
    , DEVISE_TO_STR(T.DEVISEPAY)                  AS TRADE_CURRENCY             -- 15
    , I.NOMINAL                                   AS INSTRUMENT_NOMINAL
    , ROWNUM                                      AS TRADE_ROWID
    , T.TYPE                                      AS TRADE_TYPE
    , I.MODELE                                    AS INSTRUMENT_MODEL
    , A.IDENT                                     AS INSTRUMENT_ALLOCATION_ID   -- 20
    , A.LIBELLE                                   AS INSTRUMENT_ALLOCATION_NAME
    , T.OPERATEUR                                 AS TRADE_TRADER_ID
    , RU.NAME                                     AS TRADE_TRADER_NAME
    , PCKG_BTG_SRVC_SCTRS.GetSectorStringForInstrument(I.SICOVAM)                       AS SECTORS
    , I.LIBELLE                                   AS INSTRUMENT_NAME            -- 25 
    , BROKER.LIBELLE                              AS TRADE_BROKER_NAME     
    , T.INFOS                                     AS TRADE_COMMENT         
    ,RS_MAPPING.ACCOUNT_NAME                      AS RISKSPAN_ACCOUNT
    ,CP_PROP.VALUE                                AS RISKSPAN_COUNTERPARTY
    ,DP_PROP.VALUE                                AS RISKSPAN_LOCATION          -- 30    
    , F.IDENT                                     AS TRADE_FOLIO_ID
    , F.NAME                                      AS TRADE_FOLIO_NAME
    , ( SELECT REVERSE(SYS_CONNECT_BY_PATH(REVERSE(FOLIO.NAME), '\')) 
              FROM FOLIO
              WHERE CONNECT_BY_ISLEAF = 1 
              START WITH FOLIO.ident = F.ident 
              CONNECT BY PRIOR FOLIO.MGR = FOLIO.ident
                  AND FOLIO.MGR NOT IN (1))       AS FOLIO_PATH  
    FROM TITRES I
    JOIN HISTOMVTS T
      ON  T.SICOVAM = I.SICOVAM
    JOIN BUSINESS_EVENTS BE
      ON  BE.ID = T.TYPE
    LEFT JOIN TA_BLOCK_TO_GENERATED TBTG
      ON  TBTG.GENERATED_ID = T.REFCON
    JOIN CONTREPARTIES C
      ON C.IDENT = T.CONTREPARTIE      
    JOIN TIERS E
      ON E.IDENT = T.ENTITE
      AND estclient(options) = 1
    JOIN AFFECTATION A
      ON I.AFFECTATION = A.IDENT
    JOIN RISKUSERS RU
      ON T.OPERATEUR = RU.IDENT
    JOIN COURTIERS BROKER
      ON T.COURTIER = BROKER.IDENT
    JOIN FOLIO F
      ON  F.IDENT = T.OPCVM
    LEFT JOIN (SELECT 
                TO_NUMBER(SUBSTR(FIRST_TOKEN,INSTRC(FIRST_TOKEN, '=', 1, 1) +1))    AS FUND_ID,
                TO_NUMBER(SUBSTR(SECOND_TOKEN, INSTRC(SECOND_TOKEN, '=', 1, 1) +1)) AS ALLOTMENT_ID,
                OUTPUT_CODE AS ACCOUNT_NAME
            FROM (
                SELECT 
                    SUBSTR(INPUT_CODE, 0, INSTRC(INPUT_CODE, ';', 1, 1) -1)         AS FIRST_TOKEN,
                    SUBSTR(INPUT_CODE, INSTRC(INPUT_CODE, ';', 1, 1) +1)            AS SECOND_TOKEN,
                    OUTPUT_CODE
                FROM BTG_MAPPING_CODE 
                WHERE SOURCE_ID = 8 
                    AND TYPE_ID = 38
                )
            WHERE FIRST_TOKEN IS NOT NULL
                AND SECOND_TOKEN IS NOT NULL) RS_MAPPING
        ON T.ENTITE = RS_MAPPING.FUND_ID
            AND I.AFFECTATION = RS_MAPPING.ALLOTMENT_ID
    LEFT JOIN TIERSPROPERTIES CP_PROP
        ON CP_PROP.CODE = T.CONTREPARTIE
        AND CP_PROP.NAME = 'RS_CODE'
    LEFT JOIN TIERSPROPERTIES DP_PROP
        ON DP_PROP.CODE = T.DEPOSITAIRE
        AND DP_PROP.NAME = 'RS_CODE'
                  
    WHERE (p_refcon IS NOT NULL AND T.REFCON = p_refcon);

END GetMortgageTransaction;


FUNCTION FreqIdToPeriod 
(
    p_basis       IN INT := 0
)
RETURN INT
IS
BEGIN
    CASE p_basis
        WHEN 1 THEN RETURN 1;
        WHEN 2 THEN RETURN 3;
        WHEN 3 THEN RETURN 6;
        WHEN 4 THEN RETURN 12;
        ELSE RETURN NULL;
    END CASE;
END FreqIdToPeriod;


FUNCTION GetRiskSpanAccountMapping
(
    p_allotmentId             IN  TITRES.AFFECTATION%TYPE
   ,p_fundId                  IN  HISTOMVTS.ENTITE%TYPE
)
RETURN VARCHAR2
IS
    r_mapping               BTG_MAPPING_CODE.OUTPUT_CODE%TYPE   := NULL;

BEGIN
    SELECT 
        RS_MAPPING.ACCOUNT_NAME INTO r_mapping
    FROM (
        SELECT 
            TO_NUMBER(SUBSTR(FIRST_TOKEN,INSTRC(FIRST_TOKEN, '=', 1, 1) +1))    AS FUND_ID,
            TO_NUMBER(SUBSTR(SECOND_TOKEN, INSTRC(SECOND_TOKEN, '=', 1, 1) +1)) AS ALLOTMENT_ID,
            OUTPUT_CODE AS ACCOUNT_NAME
        FROM (
            SELECT 
                SUBSTR(INPUT_CODE, 0, INSTRC(INPUT_CODE, ';', 1, 1) -1)         AS FIRST_TOKEN,
                SUBSTR(INPUT_CODE, INSTRC(INPUT_CODE, ';', 1, 1) +1)            AS SECOND_TOKEN,
                OUTPUT_CODE
            FROM BTG_MAPPING_CODE 
            WHERE SOURCE_ID = 8 
                AND TYPE_ID = 38
        )
        WHERE FIRST_TOKEN IS NOT NULL
            AND SECOND_TOKEN IS NOT NULL
     ) RS_MAPPING
     WHERE RS_MAPPING.FUND_ID = p_fundId
         AND RS_MAPPING.ALLOTMENT_ID = p_allotmentId;
     
     RETURN r_mapping;
    
END GetRiskSpanAccountMapping;


PROCEDURE GetRiskSpanCounterpartyList
(
    p_cursor        OUT     SYS_REFCURSOR
)
AS
BEGIN
    
    OPEN p_cursor FOR
        SELECT    CONTREPARTIES.ident   AS ID
        ,         CONTREPARTIES.libelle AS NAME 
        FROM      CONTREPARTIES 
        JOIN TIERSPROPERTIES CP_PROP
            ON CP_PROP.CODE = CONTREPARTIES.ident
            AND CP_PROP.NAME = 'RS_CODE'     
            AND CP_PROP.VALUE IS NOT NULL
        ORDER BY  LOWER(CONTREPARTIES.libelle);
    
END GetRiskSpanCounterpartyList;

PROCEDURE GetPosition
(
  p_sicovam                       IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT 
            SUM(T.QUANTITE * I.NOMINAL) AS Orig_Face
        FROM HISTOMVTS T
        INNER JOIN TITRES I
            ON I.SICOVAM = T.SICOVAM
        INNER JOIN BUSINESS_EVENTS BE
            ON T.TYPE = BE.ID
        INNER JOIN
          ( SELECT 
                F.IDENT
               ,F.NAME
               ,NVL(btg_parse_string(SYS_CONNECT_BY_PATH(F.IDENT, '/'),3,4), F.IDENT) parent_ident
            FROM FOLIO F
            WHERE level        > 1
            START WITH F.IDENT = 12514 -- BTG - Funds
                CONNECT BY F.MGR = prior F.IDENT
          ) strategy
            ON strategy.IDENT = T.OPCVM
        WHERE I.SICOVAM = p_sicovam
            AND T.BACKOFFICE NOT IN(192,11,13,17,26,27,220,248,252)
            AND BE.COMPTA = 1;

END GetPosition;

END PCKG_BTG_SRVC_MORTGAGES;
/