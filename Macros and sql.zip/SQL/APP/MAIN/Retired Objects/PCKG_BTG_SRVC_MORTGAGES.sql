﻿CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_MORTGAGES" 
AS

PROCEDURE GetMortgageRedemptions
(
  p_historicalMonths              IN      INT := 360
, p_sicovam                       IN      INT := NULL
, p_offsetDate                    IN      DATE := SYSDATE
, p_periodMultiplier              IN      INT := 1
, p_cursor                        OUT     SYS_REFCURSOR
);

PROCEDURE GetMortgageTransactions
(
  p_historicalMonths              IN      INT := 360
, p_sicovam                       IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
);

PROCEDURE GetMortgageTransaction
(
  p_refcon                        IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
);

FUNCTION FreqIdToPeriod 
(
    p_basis       IN INT := 0
)
RETURN INT;

FUNCTION GetRiskSpanAccountMapping
(
    p_allotmentId             IN  TITRES.AFFECTATION%TYPE
   ,p_fundId                  IN  HISTOMVTS.ENTITE%TYPE
)
RETURN VARCHAR2;

PROCEDURE GetRiskSpanCounterpartyList
(
    p_cursor        OUT     SYS_REFCURSOR
);

PROCEDURE GetPosition
(
  p_sicovam                       IN      INT := NULL
, p_cursor                        OUT     SYS_REFCURSOR
);


END PCKG_BTG_SRVC_MORTGAGES;
/