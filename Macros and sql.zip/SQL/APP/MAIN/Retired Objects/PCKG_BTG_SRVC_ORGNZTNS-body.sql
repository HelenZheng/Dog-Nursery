CREATE OR REPLACE PACKAGE BODY PCKG_BTG_SRVC_ORGNZTNS 
AS
  
--------------------------------------------------------------------------------

  PROCEDURE GetBroker
  (
    p_id            IN      COURTIERS.ident%TYPE
  , p_name          OUT     COURTIERS.libelle%TYPE
  )
  AS
  BEGIN
    
    SELECT    COURTIERS.libelle
    INTO      p_name
    FROM      COURTIERS 
    WHERE     COURTIERS.ident = p_id;
    
  END;

--------------------------------------------------------------------------------
  
  PROCEDURE GetBrokerList
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    COURTIERS.ident   AS ID
      ,         COURTIERS.libelle AS NAME 
      FROM      COURTIERS 
      ORDER BY  LOWER(COURTIERS.libelle);
    
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE GetCounterparty
  (
    p_id            IN      CONTREPARTIES.ident%TYPE
  , p_name          OUT     CONTREPARTIES.libelle%TYPE
  )
  AS
  BEGIN
    
    SELECT  CONTREPARTIES.libelle
    INTO    p_name
    FROM    CONTREPARTIES
    WHERE   CONTREPARTIES.ident = p_id;
    
  END;

--------------------------------------------------------------------------------

  PROCEDURE GetCounterpartyList
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    CONTREPARTIES.ident   AS ID
      ,         CONTREPARTIES.libelle AS NAME 
      FROM      CONTREPARTIES 
      ORDER BY  LOWER(CONTREPARTIES.libelle);
    
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE GetFund
  (
    p_id            IN      CLIENTS.ident%TYPE
  , p_name          OUT     CLIENTS.libelle%TYPE
  )
  AS
  BEGIN
    
    SELECT    CLIENTS.libelle
    INTO      p_name
    FROM      CLIENTS 
    WHERE     CLIENTS.ident = p_id;
    
  END;

--------------------------------------------------------------------------------

  PROCEDURE GetFundList
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    CLIENTS.ident   AS ID
      ,         CLIENTS.libelle AS NAME 
      FROM      CLIENTS 
      ORDER BY  LOWER(CLIENTS.libelle);
    
  END;

--------------------------------------------------------------------------------

  PROCEDURE GetIssuer
  (
    p_id            IN      TITRES.sicovam%TYPE
  , p_name          OUT     TITRES.libelle%TYPE
  )
  AS
  BEGIN
    
    SELECT    TITRES.libelle
    INTO      p_name
    FROM      TITRES
    WHERE     TITRES.type = 'H'
    AND       TITRES.sicovam = p_id;
    
  END;

--------------------------------------------------------------------------------
  
  PROCEDURE GetIssuerList
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
      SELECT    TITRES.sicovam AS ID
      ,         TITRES.libelle AS NAME
      FROM      TITRES
      WHERE     TITRES.type = 'H'
      ORDER BY  LOWER(TITRES.libelle);
    
  END;
  
--------------------------------------------------------------------------------

  PROCEDURE GetCounterpartyList2
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
    
    OPEN p_cursor FOR
        SELECT DISTINCT TIERS.ident AS ID 
        , TIERS.name AS NAME 
        FROM TIERS 
        INNER JOIN FRAISTIERS 
        ON TIERS.ident = FRAISTIERS.ident 
        WHERE FRAISTIERS.allotment IN (-1) 
        AND TIERS.name IS NOT NULL 
        AND TIERS.options = 6
        ORDER BY TIERS.name;
  END;
  
--------------------------------------------------------------------------------

END PCKG_BTG_SRVC_ORGNZTNS;
/
