CREATE OR REPLACE PACKAGE PCKG_BTG_SRVC_ORGNZTNS
AS

--------------------------------------------------------------------------------

  PROCEDURE GetBroker
  (
    p_id            IN      COURTIERS.ident%TYPE
  , p_name          OUT     COURTIERS.libelle%TYPE
  );

--------------------------------------------------------------------------------

  PROCEDURE GetBrokerList
  (
    p_cursor        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetCounterparty
  (
    p_id            IN      CONTREPARTIES.ident%TYPE
  , p_name          OUT     CONTREPARTIES.libelle%TYPE
  );
  
--------------------------------------------------------------------------------

  PROCEDURE GetCounterpartyList
  (
    p_cursor        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetFund
  (
    p_id            IN      CLIENTS.ident%TYPE
  , p_name          OUT     CLIENTS.libelle%TYPE
  );

--------------------------------------------------------------------------------

  PROCEDURE GetFundList
  (
    p_cursor        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetIssuer
  (
    p_id            IN      TITRES.sicovam%TYPE
  , p_name          OUT     TITRES.libelle%TYPE
  );

--------------------------------------------------------------------------------

  PROCEDURE GetIssuerList
  (
    p_cursor        OUT     SYS_REFCURSOR
  );

--------------------------------------------------------------------------------

  PROCEDURE GetCounterpartyList2
  (
    p_cursor        OUT     SYS_REFCURSOR
  );

END PCKG_BTG_SRVC_ORGNZTNS;
/