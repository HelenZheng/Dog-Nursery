CREATE OR REPLACE PACKAGE BODY PCKG_BTG_SRVC_PPL 
AS

--------------------------------------------------------------------------------

  PROCEDURE GetTrader
  (
    p_id            IN      RISKUSERS.ident%TYPE
  , p_name          OUT     RISKUSERS.name%TYPE
  ) 
  AS
  BEGIN
  
    SELECT RISKUSERS.name
    INTO p_name
    FROM RISKUSERS
    WHERE RISKUSERS.ident = p_id;
  
  END GetTrader;

--------------------------------------------------------------------------------

  PROCEDURE GetTraderList
  (
    p_cursor        OUT     SYS_REFCURSOR
  )
  AS
  BEGIN
  
    OPEN p_cursor FOR
      SELECT RISKUSERS.ident AS ID
      , RISKUSERS.name AS NAME
      FROM RISKUSERS
	  WHERE RISKUSERS.GIDENT  IN ( 4562,4572,4567 ) -- filter to front office users
      ORDER BY LOWER(RISKUSERS.name);
      
  END GetTraderList;

--------------------------------------------------------------------------------

PROCEDURE GetUsers
(
	p_name			IN		RISKUSERS.name%TYPE
,	p_cursor		OUT		SYS_REFCURSOR
)
AS
BEGIN
	OPEN p_cursor FOR
		SELECT
			RISKUSERS.ident		AS	id
		,	RISKUSERS.name		AS	name
		FROM RISKUSERS
		WHERE 
			(p_name IS NULL OR (p_name IS NOT NULL AND RISKUSERS.name = p_name));
			
END GetUsers;

PROCEDURE GetUserDetails
(
	p_name			IN		RISKUSERS.name%TYPE
,	p_cursor		OUT		SYS_REFCURSOR
)
AS
BEGIN
	OPEN p_cursor FOR
		SELECT
			RISKUSERS.ident		AS	id
		,	RISKUSERS.name		AS	name
		,	RISKUSERS.password	AS 	password_encrypted
		FROM RISKUSERS
		WHERE 
			(p_name IS NULL OR (p_name IS NOT NULL AND RISKUSERS.name = p_name));
END GetUserDetails;

END PCKG_BTG_SRVC_PPL;
