CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_PPL"
AS

--------------------------------------------------------------------------------

PROCEDURE GetTrader
(
	p_id            IN      RISKUSERS.ident%TYPE
,	p_name          OUT     RISKUSERS.name%TYPE
);

--------------------------------------------------------------------------------

PROCEDURE GetTraderList
(
	p_cursor        OUT     SYS_REFCURSOR
);

PROCEDURE GetUsers
(
	p_name			IN		RISKUSERS.name%TYPE
,	p_cursor		OUT		SYS_REFCURSOR
);

PROCEDURE GetUserDetails
(
	p_name			IN		RISKUSERS.name%TYPE
,	p_cursor		OUT		SYS_REFCURSOR
);
--------------------------------------------------------------------------------

END PCKG_BTG_SRVC_PPL;
