CREATE OR REPLACE PACKAGE BODY "PCKG_BTG_SRVC_REGULATION" 
AS

PROCEDURE GetTradesForUTIConf
(
    p_refcon                        IN    NUMBER            := NULL,
    p_sicovam                       IN    NUMBER            := NULL,
    p_uti                           IN    VARCHAR           := NULL,
    p_startDate                     IN    DATE              := NULL,
    p_endDate                       IN    DATE              := NULL,
    p_entity                        IN    NUMBER            := NULL,
    p_excludeExistingUti            IN    NUMBER            := 0,

    p_cursor                        OUT   SYS_REFCURSOR     
)
AS
BEGIN
    IF (p_refcon IS NOT NULL) THEN
        OPEN p_cursor FOR
            SELECT
                CM.ID                               AS CONFIRM_MEAN_ID,         --0
                CM.VALUE                            AS CONFIRM_MEAN,
                CV.ID                               AS CONFIRM_VENUE_ID,
                CV.VALUE                            AS CONFIRM_VENUE,
                EC.CONFIRM_DATE                     AS CONFIRM_DATE,
                EC.CONFIRM_TIME                     AS CONFIRM_TIME,            --5
                EC.UTI                              AS CONFIRM_UTI,
                EC.CONFIRM_FILE                     AS CONFIRM_FILE,
            
                BE.NAME                             AS KERNEL_EVENT,
                KS.NAME                             AS KERNEL_STATUS,
                E.NAME                              AS FUND,                    --10
                FUND_BOOK_STRATEGY.BOOK_NAME        AS STRATEGY,

                T.DATENEG                           AS TRADE_DATE,
                T.REFCON                            AS TRADE_ID,
                I.REFERENCE                         AS INSTRUMENT_REFERENCE,
                I.SICOVAM                           AS INSTRUMENT_ID,           --15
                COALESCE(A.LIBELLE, 'N/A')          AS INSTRUMENT_ALLOTMENT,
                T.QUANTITE*COALESCE(I.NOMINAL, 1)   AS TRADE_NOTIONAL,
                DEVISE_TO_STR(T.DEVISEPAY)          AS TRADE_CURRENCY,                       
                DE.NAME                             AS TRADE_DEPOSITARY,
                BROKER.NAME                             AS TRADE_BROKER             --20
                
            FROM HISTOMVTS T
            
            LEFT JOIN BTG_EMIR_CONFIRM EC
                ON EC.REFCON = T.REFCON
            LEFT JOIN BTG_EMIR_CONFIRM_MEAN CM
                ON CM.ID = EC.CONFIRM_MEAN
            LEFT JOIN BTG_EMIR_CONFIRM_VENUE CV
                ON CV.ID = EC.CONFIRM_VENUE
                
            INNER JOIN
                (   SELECT 
                        REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                        FOLIO.ident                 AS STRATEGY_ID,
                        level
                     FROM FOLIO
                     WHERE LEVEL >= 4
                     START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_UCITS_FUND) 
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                ) FUND_BOOK_STRATEGY 
                ON FUND_BOOK_STRATEGY.STRATEGY_ID = T.OPCVM                          
            
            JOIN BUSINESS_EVENTS BE
                ON BE.ID = T.TYPE
            JOIN BO_KERNEL_STATUS KS
                ON KS.ID = T.BACKOFFICE
            JOIN TIERS E
                ON E.IDENT = T.ENTITE
            JOIN TITRES I
                ON I.SICOVAM = T.SICOVAM
            LEFT JOIN AFFECTATION A
                ON A.IDENT = I.AFFECTATION
            LEFT JOIN TIERS DE
                ON DE.IDENT = T.DEPOSITAIRE 
            LEFT JOIN TIERS BROKER
                ON BROKER.IDENT = T.COURTIER 
            
            WHERE
                p_refcon IS NOT NULL
            AND p_refcon = T.refcon 
			
			AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BACKOFFICE EBO WHERE EBO.ID = T.BACKOFFICE)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_ALLOTMENTS EA WHERE EA.ID = I.AFFECTATION)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = BROKER.IDENT)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = T.CONTREPARTIE)
            AND DE.IDENT IN (SELECT * FROM BTG_EMIR_INCLUDE_DEPOSITORIES)
            AND (I.AFFECTATION IS NULL OR I.AFFECTATION != 20)  
            AND BE.COMPTA = 1
            ORDER BY T.REFCON DESC;
    ELSIF (p_uti IS NOT NULL) THEN
        OPEN p_cursor FOR
            SELECT
                CM.ID                               AS CONFIRM_MEAN_ID,         --0
                CM.VALUE                            AS CONFIRM_MEAN,
                CV.ID                               AS CONFIRM_VENUE_ID,
                CV.VALUE                            AS CONFIRM_VENUE,
                EC.CONFIRM_DATE                     AS CONFIRM_DATE,
                EC.CONFIRM_TIME                     AS CONFIRM_TIME,            --5
                EC.UTI                              AS CONFIRM_UTI,
                EC.CONFIRM_FILE                     AS CONFIRM_FILE,
            
                BE.NAME                             AS KERNEL_EVENT,
                KS.NAME                             AS KERNEL_STATUS,
                E.NAME                              AS FUND,                    --10
                FUND_BOOK_STRATEGY.BOOK_NAME        AS STRATEGY,
                T.DATENEG                           AS TRADE_DATE,
                T.REFCON                            AS TRADE_ID,
                I.REFERENCE                         AS INSTRUMENT_REFERENCE,
                I.SICOVAM                           AS INSTRUMENT_ID,           --15
                COALESCE(A.LIBELLE, 'N/A')          AS INSTRUMENT_ALLOTMENT,
                T.QUANTITE*COALESCE(I.NOMINAL, 1)   AS TRADE_NOTIONAL,
                DEVISE_TO_STR(T.DEVISEPAY)          AS TRADE_CURRENCY,                       
                DE.NAME                             AS TRADE_DEPOSITARY,
                BROKER.NAME                         AS TRADE_BROKER             --20
                
            FROM HISTOMVTS T
            
            LEFT JOIN BTG_EMIR_CONFIRM EC
                ON EC.REFCON = T.REFCON
            LEFT JOIN BTG_EMIR_CONFIRM_MEAN CM
                ON CM.ID = EC.CONFIRM_MEAN
            LEFT JOIN BTG_EMIR_CONFIRM_VENUE CV
                ON CV.ID = EC.CONFIRM_VENUE
                
            INNER JOIN
                (   SELECT 
                        REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                        FOLIO.ident                 AS STRATEGY_ID,
                        level
                     FROM FOLIO
                     WHERE LEVEL >= 4
                     START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_UCITS_FUND) 
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                ) FUND_BOOK_STRATEGY 
                ON FUND_BOOK_STRATEGY.STRATEGY_ID = T.OPCVM                            
            
            JOIN BUSINESS_EVENTS BE
                ON BE.ID = T.TYPE
            JOIN BO_KERNEL_STATUS KS
                ON KS.ID = T.BACKOFFICE
            JOIN TIERS E
                ON E.IDENT = T.ENTITE
            JOIN TITRES I
                ON I.SICOVAM = T.SICOVAM
            LEFT JOIN AFFECTATION A
                ON A.IDENT = I.AFFECTATION
            LEFT JOIN TIERS DE
                ON DE.IDENT = T.DEPOSITAIRE 
            LEFT JOIN TIERS BROKER
                ON BROKER.IDENT = T.COURTIER 
            
            WHERE
                p_uti IS NOT NULL
            AND EC.UTI LIKE (p_uti || '%')
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BACKOFFICE EBO WHERE EBO.ID = T.BACKOFFICE)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_ALLOTMENTS EA WHERE EA.ID = I.AFFECTATION)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = BROKER.IDENT)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = T.CONTREPARTIE)
            AND DE.IDENT IN (SELECT * FROM BTG_EMIR_INCLUDE_DEPOSITORIES)
            AND (I.AFFECTATION IS NULL OR I.AFFECTATION != 20)  
            AND BE.COMPTA = 1
            ORDER BY T.REFCON DESC; 
    ELSE
        OPEN p_cursor FOR
            SELECT
                CM.ID                               AS CONFIRM_MEAN_ID,         --0
                CM.VALUE                            AS CONFIRM_MEAN,
                CV.ID                               AS CONFIRM_VENUE_ID,
                CV.VALUE                            AS CONFIRM_VENUE,
                EC.CONFIRM_DATE                     AS CONFIRM_DATE,
                EC.CONFIRM_TIME                     AS CONFIRM_TIME,            --5
                EC.UTI                              AS CONFIRM_UTI,
                EC.CONFIRM_FILE                     AS CONFIRM_FILE,
            
                BE.NAME                             AS KERNEL_EVENT,
                KS.NAME                             AS KERNEL_STATUS,
                E.NAME                              AS FUND,                    --10
                FUND_BOOK_STRATEGY.BOOK_NAME        AS STRATEGY,

                T.DATENEG                           AS TRADE_DATE,
                T.REFCON                            AS TRADE_ID,
                I.REFERENCE                         AS INSTRUMENT_REFERENCE,
                I.SICOVAM                           AS INSTRUMENT_ID,           --15
                COALESCE(A.LIBELLE, 'N/A')          AS INSTRUMENT_ALLOTMENT,
                T.QUANTITE*COALESCE(I.NOMINAL, 1)   AS TRADE_NOTIONAL,
                DEVISE_TO_STR(T.DEVISEPAY)          AS TRADE_CURRENCY,                       
                DE.NAME                             AS TRADE_DEPOSITARY,
                BROKER.NAME                             AS TRADE_BROKER             --20
                
            FROM HISTOMVTS T
            
            LEFT JOIN BTG_EMIR_CONFIRM EC
                ON EC.REFCON = T.REFCON
            LEFT JOIN BTG_EMIR_CONFIRM_MEAN CM
                ON CM.ID = EC.CONFIRM_MEAN
            LEFT JOIN BTG_EMIR_CONFIRM_VENUE CV
                ON CV.ID = EC.CONFIRM_VENUE
                
            INNER JOIN
                (   SELECT 
                        REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                        FOLIO.ident                 AS STRATEGY_ID,
                        level
                     FROM FOLIO
                     WHERE LEVEL >= 4
                     START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_UCITS_FUND) 
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                ) FUND_BOOK_STRATEGY 
                ON FUND_BOOK_STRATEGY.STRATEGY_ID = T.OPCVM                
            
            JOIN BUSINESS_EVENTS BE
                ON BE.ID = T.TYPE
            JOIN BO_KERNEL_STATUS KS
                ON KS.ID = T.BACKOFFICE
            JOIN TIERS E
                ON E.IDENT = T.ENTITE
            JOIN TITRES I
                ON I.SICOVAM = T.SICOVAM
            LEFT JOIN AFFECTATION A
                ON A.IDENT = I.AFFECTATION
            LEFT JOIN TIERS DE
                ON DE.IDENT = T.DEPOSITAIRE 
            LEFT JOIN TIERS BROKER
                ON BROKER.IDENT = T.COURTIER 
            
            WHERE
            (
                     p_entity = T.ENTITE
                AND (p_sicovam IS NULL          OR p_sicovam = T.sicovam)
                AND (p_startDate IS NULL        OR T.DATENEG >= p_startDate)
                AND (p_endDate IS NULL          OR T.DATENEG <= p_endDate)
                AND (p_excludeExistingUti = 0   OR (p_excludeExistingUti = 1     AND EC.UTI IS NULL))
            )
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BACKOFFICE EBO WHERE EBO.ID = T.BACKOFFICE)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_ALLOTMENTS EA WHERE EA.ID = I.AFFECTATION)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = BROKER.IDENT)
            AND NOT EXISTS (SELECT * FROM BTG_EMIR_EXCLUDE_BROKERS EB WHERE EB.ID = T.CONTREPARTIE)
            AND DE.IDENT IN (SELECT * FROM BTG_EMIR_INCLUDE_DEPOSITORIES)
            AND (I.AFFECTATION IS NULL OR I.AFFECTATION != 20)  
            AND BE.COMPTA = 1
            ORDER BY T.REFCON DESC;
    END IF;    

END GetTradesForUTIConf;

PROCEDURE UpdateUTIConfirmation
(
    p_refcon                        IN      NUMBER          := NULL,
    p_confirmMean                   IN      NUMBER          := NULL,
    p_confirmVenue                  IN      NUMBER          := NULL,
    p_confirmDate                   IN      DATE            := NULL,
    p_confirmTime                   IN      DATE            := NULL,
    p_uti                           IN      VARCHAR         := NULL,
    p_filePath                      IN      VARCHAR         := NULL
)
AS
BEGIN
    MERGE INTO BTG_EMIR_CONFIRM USING DUAL ON (REFCON = p_refcon)
         WHEN NOT MATCHED THEN
            INSERT 
            (
                REFCON,
                CONFIRM_MEAN,
                CONFIRM_VENUE,
                CONFIRM_DATE,
                CONFIRM_TIME,
                UTI,
                CONFIRM_FILE
            ) 
            VALUES
            (
                p_refcon,
                p_confirmMean,
                p_confirmVenue,
                p_confirmDate,
                p_confirmTime,
                p_uti,
                p_filePath
            )
         WHEN MATCHED THEN
            UPDATE SET
                CONFIRM_MEAN    = p_confirmMean,
                CONFIRM_VENUE   = p_confirmVenue,
                CONFIRM_DATE    = p_confirmDate,
                CONFIRM_TIME    = p_confirmTime,
                UTI             = p_uti,
                CONFIRM_FILE    = p_filePath;
            
END UpdateUTIConfirmation;

PROCEDURE GetConfirmationMeans
(
    p_cursor                        OUT   SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT ID, VALUE, ISDEFAULT
        FROM BTG_EMIR_CONFIRM_MEAN
        ORDER BY ID;

END GetConfirmationMeans;

PROCEDURE GetConfirmationVenues
(
    p_cursor                        OUT   SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT ID, VALUE, ISDEFAULT
        FROM BTG_EMIR_CONFIRM_VENUE
        ORDER BY ID;

END GetConfirmationVenues;

PROCEDURE GetConfirmationEntities
(
    p_cursor                        OUT   SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT ID, VALUE, ISDEFAULT
        FROM BTG_EMIR_CONFIRM_ENTITY
        ORDER BY ID;

END GetConfirmationEntities;

PROCEDURE GetAllDistinctUti
(
    p_cursor                        OUT   SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            DISTINCT(UTI) 
        FROM BTG_EMIR_CONFIRM 
        WHERE UTI IS NOT NULL;

END GetAllDistinctUti;

FUNCTION CountSendDealBlotterInState
(
    p_refcon                        IN    NUMBER            := NULL,
    p_state                         IN    NUMBER            := 0,
    p_sent                          IN    NUMBER            := NULL
)
RETURN INT
IS
    v_count                         INT     := 0;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM AMRECON_VACATIONS 
    WHERE REFCON = p_refcon
    AND ESID = 3183
    AND GENERATION_TYPE = p_state
    AND SENT = p_sent;

    RETURN v_count;
    
END CountSendDealBlotterInState;    

PROCEDURE TestInsertSendDealBlotter
(
    p_refcon                        IN    NUMBER            := NULL
)
AS
BEGIN
    IF CountSendDealBlotterInState(p_refcon, 1, 1) > 0 
    AND CountSendDealBlotterInState(p_refcon, 2, 0) = 0 THEN
        INSERT INTO AMRECON_VACATIONS 
            (REFCON, GENERATION_TYPE, INSERTION_DATE, SENT, ESID) 
        VALUES 
            (p_refcon, 2, SYSDATE, 0, 3183);
    END IF;

END TestInsertSendDealBlotter;

PROCEDURE GetEmirConfirmation
(
    p_refcon            IN OUT      HISTOMVTS.REFCON%TYPE,
    p_meanCode          OUT         BTG_EMIR_CONFIRM_MEAN.ID%TYPE,
    p_mean              OUT         BTG_EMIR_CONFIRM_MEAN.VALUE%TYPE,
    p_venueCode         OUT         BTG_EMIR_CONFIRM_VENUE.ID%TYPE,
    p_venue             OUT         BTG_EMIR_CONFIRM_VENUE.VALUE%TYPE,
    p_date              OUT         BTG_EMIR_CONFIRM.CONFIRM_DATE%TYPE,
    p_time              OUT         BTG_EMIR_CONFIRM.CONFIRM_TIME%TYPE,
    p_uti               OUT         BTG_EMIR_CONFIRM.UTI%TYPE    
) 
AS 
BEGIN

  SELECT BTG_EMIR_CONFIRM.refcon
  , BTG_EMIR_CONFIRM.confirm_mean
  , BTG_EMIR_CONFIRM_MEAN.value
  , BTG_EMIR_CONFIRM.confirm_venue
  , BTG_EMIR_CONFIRM_VENUE.value
  , BTG_EMIR_CONFIRM.confirm_date
  , BTG_EMIR_CONFIRM.confirm_time
  , BTG_EMIR_CONFIRM.uti
  INTO p_refcon
  , p_meanCode
  , p_mean
  , p_venueCode
  , p_venue
  , p_date
  , p_time
  , p_uti
  FROM BTG_EMIR_CONFIRM
  INNER JOIN BTG_EMIR_CONFIRM_MEAN
  ON BTG_EMIR_CONFIRM_MEAN.id = BTG_EMIR_CONFIRM.confirm_mean
  INNER JOIN BTG_EMIR_CONFIRM_VENUE
  ON BTG_EMIR_CONFIRM_VENUE.id = BTG_EMIR_CONFIRM.confirm_venue
  WHERE BTG_EMIR_CONFIRM.refcon = p_refcon;

EXCEPTION

  WHEN NO_DATA_FOUND THEN BEGIN
  
    p_refcon := NULL;
    p_meanCode := NULL;
    p_mean := NULL;
    p_venueCode := NULL;
    p_venue := NULL;
    p_date := NULL;
    p_time := NULL;
    p_uti := NULL;
              
  END;
  
END;

END PCKG_BTG_SRVC_REGULATION;
/