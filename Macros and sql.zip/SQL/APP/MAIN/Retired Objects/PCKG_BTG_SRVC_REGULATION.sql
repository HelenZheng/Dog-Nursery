CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_REGULATION" 
AS

PROCEDURE GetTradesForUTIConf
(
    p_refcon                        IN    NUMBER            := NULL,
    p_sicovam                       IN    NUMBER            := NULL,
    p_uti                           IN    VARCHAR           := NULL,
    p_startDate                     IN    DATE              := NULL,
    p_endDate                       IN    DATE              := NULL,
    p_entity                        IN    NUMBER            := NULL,
    p_excludeExistingUti               IN    NUMBER            := 0,

    p_cursor                        OUT   SYS_REFCURSOR     
);


PROCEDURE UpdateUTIConfirmation
(
    p_refcon                        IN    NUMBER            := NULL,
    p_confirmMean                   IN    NUMBER            := NULL,
    p_confirmVenue                  IN    NUMBER            := NULL,
    p_confirmDate                   IN    DATE              := NULL,
    p_confirmTime                   IN    DATE              := NULL,
    p_uti                           IN    VARCHAR           := NULL,
    p_filePath                      IN    VARCHAR           := NULL
);


PROCEDURE GetConfirmationMeans
(
    p_cursor                        OUT   SYS_REFCURSOR
);

PROCEDURE GetConfirmationVenues
(
    p_cursor                        OUT   SYS_REFCURSOR
);

PROCEDURE GetConfirmationEntities
(
    p_cursor                        OUT   SYS_REFCURSOR
);


PROCEDURE GetAllDistinctUti
(
    p_cursor                        OUT   SYS_REFCURSOR
);

FUNCTION CountSendDealBlotterInState
(
    p_refcon                        IN    NUMBER            := NULL,
    p_state                         IN    NUMBER            := 0,
    p_sent                          IN    NUMBER            := NULL
)
RETURN INT;

PROCEDURE TestInsertSendDealBlotter
(
    p_refcon                        IN    NUMBER            := NULL
);

PROCEDURE GetEmirConfirmation
(
    p_refcon            IN OUT      HISTOMVTS.REFCON%TYPE,
    p_meanCode          OUT         BTG_EMIR_CONFIRM_MEAN.ID%TYPE,
    p_mean              OUT         BTG_EMIR_CONFIRM_MEAN.VALUE%TYPE,
    p_venueCode         OUT         BTG_EMIR_CONFIRM_VENUE.ID%TYPE,
    p_venue             OUT         BTG_EMIR_CONFIRM_VENUE.VALUE%TYPE,
    p_date              OUT         BTG_EMIR_CONFIRM.CONFIRM_DATE%TYPE,
    p_time              OUT         BTG_EMIR_CONFIRM.CONFIRM_TIME%TYPE,
    p_uti               OUT         BTG_EMIR_CONFIRM.UTI%TYPE    
);

END PCKG_BTG_SRVC_REGULATION;
/