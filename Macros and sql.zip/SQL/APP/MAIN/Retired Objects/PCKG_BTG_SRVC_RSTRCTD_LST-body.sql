CREATE OR REPLACE PACKAGE BODY "PCKG_BTG_SRVC_RSTRCTD_LST" 
AS

PROCEDURE GetEnabledLists
(
    p_cursor                       OUT     SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT 
            id,
            name
        FROM BTG_RESTRICTED_LIST
        WHERE enabled = 'Y'
        ORDER BY name;

END GetEnabledLists;

PROCEDURE GetListValues
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_cursor                       OUT     SYS_REFCURSOR   
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            id_bb_company
        ,   issuer_name
        FROM BTG_RESTRICTED_LIST_IDS
        WHERE list_id = p_list_id
        ORDER BY LPAD(id_bb_company, 16), issuer_name;

END GetListValues;   

FUNCTION AddListValue
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_new_id_bb_company                IN      VARCHAR     := NULL
    ,p_new_issuer_name                  IN      VARCHAR     := NULL
    ,p_audit_user                   IN  VARCHAR := NULL
)
RETURN NUMBER
IS
    insert_rowcount         NUMBER;
BEGIN
    INSERT INTO BTG_RESTRICTED_LIST_IDS 
    (
        LIST_ID, 
        ID_BB_COMPANY, 
        ISSUER_NAME, 
        MODIFIED_TIMESTAMP
    )
    VALUES 
    (
        p_list_id,
        p_new_id_bb_company,
        p_new_issuer_name,
        systimestamp
    );
        
    insert_rowcount := SQL%ROWCOUNT;

    IF (insert_rowcount > 0) THEN
        InsertAuditRecord(p_list_id, 'INSERT', p_audit_user, null, p_new_id_bb_company, null, p_new_issuer_name);
    END IF;
        
    RETURN insert_rowcount;
END AddListValue;

FUNCTION UpdateListValue
(
    p_list_id                           IN      NUMBER      := NULL
,   p_id_bb_company                     IN      VARCHAR     := NULL
,   p_new_id_bb_company                 IN      VARCHAR     := NULL
,   p_new_issuer_name                   IN      VARCHAR     := NULL
,   p_audit_user                        IN  VARCHAR := NULL

)
RETURN NUMBER
IS
    update_rowcount         NUMBER;
    old_issuer_name         VARCHAR(50);
BEGIN
    SELECT
        issuer_name INTO old_issuer_name
    FROM 
        BTG_RESTRICTED_LIST_IDS
    WHERE list_id = p_list_id
        AND id_bb_company = p_id_bb_company;

    UPDATE 
        BTG_RESTRICTED_LIST_IDS
    SET 
        id_bb_company = p_new_id_bb_company,
        issuer_name = p_new_issuer_name
    WHERE list_id = p_list_id
        AND id_bb_company = p_id_bb_company;
        
    update_rowcount := SQL%ROWCOUNT;
    
    IF (update_rowcount > 0) THEN
        InsertAuditRecord(p_list_id, 'UPDATE', p_audit_user, p_id_bb_company, p_new_id_bb_company, old_issuer_name, p_new_issuer_name);
    END IF;

    RETURN update_rowcount;
END UpdateListValue;

FUNCTION DeleteListValue
(
     p_list_id                       IN      NUMBER  := NULL
    ,p_id_bb_company                IN      VARCHAR := NULL
    ,p_audit_user                   IN      VARCHAR := NULL
    
)
RETURN NUMBER
IS
    delete_rowcount         NUMBER;
BEGIN
    DELETE FROM BTG_RESTRICTED_LIST_IDS
    WHERE list_id = p_list_id
    AND id_bb_company = p_id_bb_company;
    
    delete_rowcount := SQL%ROWCOUNT;   
    
    IF (delete_rowcount > 0) THEN
        InsertAuditRecord(p_list_id, 'DELETE', p_audit_user, p_id_bb_company, null, null, null);
    END IF;
    
    RETURN delete_rowcount;
END DeleteListValue;


PROCEDURE InsertAuditRecord
(
     p_list_id                          IN      NUMBER  := NULL
    ,p_action                           IN      VARCHAR := NULL
    ,p_audit_user                       IN      VARCHAR := NULL

    ,p_old_id_bb_company                IN      VARCHAR := NULL
    ,p_new_id_bb_company                IN      VARCHAR := NULL

    ,p_old_issuer_name                  IN      VARCHAR := NULL
    ,p_new_issuer_name                  IN      VARCHAR := NULL
)
AS
BEGIN
    INSERT INTO BTG_RESTRICTED_LIST_AUDIT
    (   AUDIT_ID,
        LIST_ID,
        ACTION,
        USERNAME,
    
        OLD_ID_BB_COMPANY,
        NEW_ID_BB_COMPANY,
    
        OLD_ISSUER_NAME,
        NEW_ISSUER_NAME,
        
        AUDIT_TIMESTAMP )
    VALUES
    (   SEQ_RESTRICTED_LIST_AUDIT.NEXTVAL,
        p_list_id,
        p_action,
        p_audit_user,
        
        p_old_id_bb_company,
        p_new_id_bb_company,
        
        p_old_issuer_name,
        p_new_issuer_name,
        
        systimestamp
    );

END InsertAuditRecord; 

END PCKG_BTG_SRVC_RSTRCTD_LST;
/