CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_RSTRCTD_LST" 
AS

PROCEDURE GetEnabledLists
(
    p_cursor                       OUT     SYS_REFCURSOR
);

PROCEDURE GetListValues
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_cursor                       OUT     SYS_REFCURSOR   
);

FUNCTION AddListValue
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_new_id_bb_company                IN      VARCHAR     := NULL
    ,p_new_issuer_name                  IN      VARCHAR     := NULL
    ,p_audit_user                   IN      VARCHAR := NULL
    
)
RETURN NUMBER;

FUNCTION UpdateListValue
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_id_bb_company                IN      VARCHAR     := NULL
    ,p_new_id_bb_company                IN      VARCHAR     := NULL
    ,p_new_issuer_name                  IN      VARCHAR     := NULL
    ,p_audit_user                   IN      VARCHAR := NULL
)
RETURN NUMBER;

FUNCTION DeleteListValue
(
    p_list_id                       IN      NUMBER          := NULL
    ,p_id_bb_company                IN      VARCHAR     := NULL
    ,p_audit_user                   IN      VARCHAR := NULL
)
RETURN NUMBER;

PROCEDURE InsertAuditRecord
(
     p_list_id                          IN      NUMBER  := NULL
    ,p_action                           IN      VARCHAR := NULL
    ,p_audit_user                       IN      VARCHAR := NULL

    ,p_old_id_bb_company                IN      VARCHAR := NULL
    ,p_new_id_bb_company                IN      VARCHAR := NULL

    ,p_old_issuer_name                  IN      VARCHAR := NULL
    ,p_new_issuer_name                  IN      VARCHAR := NULL
);

END PCKG_BTG_SRVC_RSTRCTD_LST;
/