CREATE OR REPLACE PACKAGE BODY "PCKG_BTG_SRVC_SCTRS"
AS

PROCEDURE GetSectors
(
  p_parentId                      IN      INT := 0
, p_parentName                    IN      VARCHAR
, p_cursor                        OUT     SYS_REFCURSOR
                      
)
AS
  parentId                        INT := 0;
BEGIN
  IF p_parentName IS NOT NULL THEN
    SELECT id INTO parentId
    FROM SECTORS
    WHERE name = p_parentName;
  ELSE
    parentId := p_parentId;
  END IF;
    
  OPEN p_cursor FOR
    SELECT
         S1.id
        ,S1.name
        ,S1.parent as parentId
        ,S2.name as parentName
    FROM SECTORS S1
    LEFT JOIN SECTORS S2
        ON S1.parent = S2.id
    WHERE S1.parent = parentId
    ORDER BY S1.name;

END GetSectors;

FUNCTION GetSectorStringForInstrument 
(
    p_sicovam       IN INT := 0
)
RETURN VARCHAR
IS
    sectorString VARCHAR(2048) := null;
BEGIN
    FOR INSTRUMENT_SECTORS IN (
        SELECT 
            SIA.SECTOR  AS SECTOR_ID,
            S1.NAME     AS SECTOR_NAME,
            SIA.TYPE    AS PARENT_SECTOR_ID,
            S2.NAME     AS PARENT_SECTOR_NAME
        FROM SECTOR_INSTRUMENT_ASSOCIATION SIA
            JOIN SECTORS S1
                ON SIA.SECTOR = S1.ID
            JOIN SECTORS S2
                ON SIA.TYPE = S2.ID
        WHERE SIA.SICOVAM = p_sicovam) LOOP
        sectorString := sectorString || INSTRUMENT_SECTORS.parent_sector_id || '§' || INSTRUMENT_SECTORS.parent_sector_name || '»' || INSTRUMENT_SECTORS.sector_id || '§' ||INSTRUMENT_SECTORS.sector_name || '¦';
    END LOOP;
    
    RETURN sectorString;
END GetSectorStringForInstrument;

PROCEDURE SetSectorForInstrument
(
    p_sicovam                      IN    TITRES.SICOVAM%TYPE
   ,p_sectorId                     IN    SECTORS.ID%TYPE
)
AS
BEGIN
    MERGE INTO SECTOR_INSTRUMENT_ASSOCIATION
        USING (
            SELECT S.parent
            FROM SECTORS S
            WHERE S.id = p_sectorId
        ) SECTOR
        ON (SECTOR_INSTRUMENT_ASSOCIATION.sicovam = p_sicovam 
            AND SECTOR_INSTRUMENT_ASSOCIATION.type = SECTOR.parent)
    WHEN MATCHED THEN 
        UPDATE SET SECTOR_INSTRUMENT_ASSOCIATION.sector = p_sectorId
    WHEN NOT MATCHED THEN 
        INSERT (sicovam, type, sector) 
        VALUES (p_sicovam, SECTOR.parent, p_sectorId);
END SetSectorForInstrument;

END PCKG_BTG_SRVC_SCTRS;
/