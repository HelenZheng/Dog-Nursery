﻿CREATE OR REPLACE PACKAGE "PCKG_BTG_SRVC_SCTRS" 
AS

PROCEDURE GetSectors
(
  p_parentId                      IN      INT := 0
, p_parentName                    IN      VARCHAR
, p_cursor                        OUT     SYS_REFCURSOR
);

FUNCTION GetSectorStringForInstrument
(
    p_sicovam       IN INT := 0
)
RETURN VARCHAR;


PROCEDURE SetSectorForInstrument
(
    p_sicovam                      IN    TITRES.SICOVAM%TYPE
   ,p_sectorId                     IN    SECTORS.ID%TYPE
);

END PCKG_BTG_SRVC_SCTRS;
/