CREATE OR REPLACE
PACKAGE PCKG_BTG_SRVC_TRANSACTIONS
AS

  -- ***************************************************************************
    -- Constant variables
    -- ***************************************************************************
  
  EOT                               CONSTANT TIMESTAMP    := TO_DATE( '31-Dec-9999 23:59:59', 'DD-MON-YYYY HH24:MI:SS' );
  
  -- ***************************************************************************
    -- Types
    -- ***************************************************************************
  
  TYPE T_CURSOR                     IS REF CURSOR;
  
  -- *****************************************************************
  -- Description:
    --
  -- Author:          Diogo Novaes
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 13 NOV 2012      Diogo Novaes     Created.
  -- *****************************************************************
  PROCEDURE LogRun
  (
    vMessage                        IN      VARCHAR2
  );
  
  PROCEDURE GetTradesByInstrumentId
  (
    p_instrumentId                  IN      INT
  , p_type                          IN      INT
  , p_cursor                        OUT     T_CURSOR
  );
  
  /*PROCEDURE GetABSImpactedTrades
  (
    p_instrumentId                          IN      INT
  , p_cursor                        OUT     T_CURSOR
  );*/
  
END PCKG_BTG_SRVC_TRANSACTIONS; 

CREATE OR REPLACE
PACKAGE BODY PCKG_BTG_SRVC_TRANSACTIONS 
AS
  -- *****************************************************************
  -- Description:
  --
  -- Author:          Diogo Novaes
  --
  -- Revision History
  -- Date             Author            Reason for Change
  -- ----------------------------------------------------------------
  -- 13 NOV 2012      Diogo Novaes      Created.
  -- 15 FEB 2013      Jack Coldridge    Integrate join for allocated trades
  -- *****************************************************************
  PROCEDURE LogRun
  (
    vMessage                        IN      VARCHAR2
  )
  AS
  BEGIN
    DBMS_OUTPUT.put_line( vMessage );
  EXCEPTION
    WHEN OTHERS THEN
      raise_application_error( -20011, SQLERRM );
  END;

  PROCEDURE GetTradesByInstrumentId
  (
    p_instrumentId                  IN      INT
  , p_type                          IN      INT
  , p_cursor                        OUT     T_CURSOR
  )
  AS
  BEGIN
    -- p_type = 1 for use abs impacted rules
    IF (p_type = 1) THEN
        OPEN p_cursor FOR
          SELECT    H.REFCON, ABS(TBTG.BLOCK_ID) AS PARENT_ID
          FROM      histomvts               H
          JOIN      BUSINESS_EVENTS         BE
          ON        BE.ID                   = H.Type
          AND       trim(upper(BE.name))    in ('PURCHASE/SALE', 'TRANSFER')
          JOIN      BO_KERNEL_STATUS BKS 
          ON        BKS.ID = H.BACKOFFICE
          LEFT JOIN TA_BLOCK_TO_GENERATED TBTG
          ON        TBTG.GENERATED_ID = H.REFCON
          AND       UPPER(BKS.NAME)          NOT LIKE '%CANCEL%' 
          WHERE     H.sicovam              =  p_instrumentId;
    ELSE
        OPEN p_cursor FOR
          SELECT    H.REFCON, ABS(TBTG.BLOCK_ID) AS PARENT_ID
          FROM      histomvts H
          LEFT JOIN TA_BLOCK_TO_GENERATED TBTG
          ON        TBTG.GENERATED_ID = H.REFCON
          WHERE     H.sicovam = p_instrumentId;
    END IF;
  END;   

  
END PCKG_BTG_SRVC_TRANSACTIONS;