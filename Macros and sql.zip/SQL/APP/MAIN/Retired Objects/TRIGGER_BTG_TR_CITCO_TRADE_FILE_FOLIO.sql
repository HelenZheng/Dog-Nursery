create or replace
TRIGGER "BTG41"."BTG_TR_CITCO_TRADE_FILE_FOLIO"  
AFTER UPDATE OF "OPCVM" ON "HISTOMVTS" 
FOR EACH ROW

     WHEN ( NEW.backoffice in (12,16,244) and NEW.type not in (2,15,46) and NEW.DEPOSITAIRE not in(10003642,10009763,10009764,10009765,10010706,10011816,10010525,10020016) ) 
     

begin

 if updating then
 
 DECLARE
  
	v_foundRepoNew          NUMBER := 0;
  v_foundRepoAmend        NUMBER := 0;
  v_foundRepoCancel       NUMBER := 0;
  v_foundTradeNew         NUMBER := 0;
  v_foundTradeAmend       NUMBER := 0;
  v_foundTradeCancel      NUMBER := 0;
  v_foundFXNew            NUMBER := 0;
  v_foundFXAmend          NUMBER := 0;
  v_foundFXCancel         NUMBER := 0;
  v_foundNewTradeNew      NUMBER := 0;
  v_foundNewTradeAmend    NUMBER := 0;
  v_foundNewTradeCancel   NUMBER := 0;
   

	 CURSOR check_cursorRepoNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1483) and generation_type=1 and sent=1  ; 
   --Citco Dublin FA REPO Trade (there are some new trades sent)
   
	 CURSOR check_cursorRepoAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1483) and generation_type=2 and sent in(0,4)  ; 
   --Citco Dublin FA REPO Trade (there are some amendment in the pending to be sent or error status)
   
	 CURSOR check_cursorRepoCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1483) and generation_type=3   ; 
   --Citco Dublin FA REPO Trade (there are cancellation in the amrecon_vacations)
   
	 CURSOR check_cursorFXNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1482) and generation_type=1 and sent=1  ; 
   --Citco Dublin FA FX Trade (there are some new trades sent)
   
	 CURSOR check_cursorFXAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1482) and generation_type=2 and sent in(0,4)  ; 
   --Citco Dublin FA FX Trade (there are some amendment in the pending to be sent or error status)
   
	 CURSOR check_cursorFXCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1482) and generation_type=3   ; 
   --Citco Dublin FA FX Trade (there are cancellation in the amrecon_vacations)
   
	 CURSOR check_cursorTradeNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1481) and generation_type=1 and sent=1  ; 
   --Citco Dublin FA ALL Trade (there are some new trades sent)
   
	 CURSOR check_cursorTradeAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1481) and generation_type=2 and sent in(0,4)  ; 
   --Citco Dublin FA ALL Trade (there are some amendment in the pending to be sent or error status)
   
	 CURSOR check_cursorTradeCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1481) and generation_type=3   ; 
   --Citco Dublin FA ALL Trade (there are cancellation in the amrecon_vacations)
   
   CURSOR check_cursorNewTradeNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (2631) and generation_type=1 and sent=1  ; 
   --Citco Dublin FA ALL Trade New (there are some new trades sent)
   
	 CURSOR check_cursorNewTradeAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (2631) and generation_type=2 and sent in(0,4)  ; 
   --Citco Dublin FA ALL Trade New (there are some amendment in the pending to be sent or error status)
   
	 CURSOR check_cursorNewTradeCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (2631) and generation_type=3   ; 
   --Citco Dublin FA ALL Trade New (there are cancellation in the amrecon_vacations)


   
BEGIN
	OPEN  check_cursorRepoNew;
	FETCH check_cursorRepoNew INTO v_foundRepoNew;
	CLOSE check_cursorRepoNew;
  
	OPEN  check_cursorRepoAmend;
	FETCH check_cursorRepoAmend INTO v_foundRepoAmend;
	CLOSE check_cursorRepoAmend;
  
	OPEN  check_cursorRepoCancel;
	FETCH check_cursorRepoCancel INTO v_foundRepoCancel;
	CLOSE check_cursorRepoCancel;
  
	OPEN  check_cursorFXNew;
	FETCH check_cursorFXNew INTO v_foundFXNew;
	CLOSE check_cursorFXNew;
  
	OPEN  check_cursorFXAmend;
	FETCH check_cursorFXAmend INTO v_foundFXAmend;
	CLOSE check_cursorFXAmend;
  
	OPEN  check_cursorFXCancel;
	FETCH check_cursorFXCancel INTO v_foundFXCancel;
	CLOSE check_cursorFXCancel;
  
	OPEN  check_cursorTradeNew;
	FETCH check_cursorTradeNew INTO v_foundTradeNew;
	CLOSE check_cursorTradeNew;
  
	OPEN  check_cursorTradeAmend;
	FETCH check_cursorTradeAmend INTO v_foundTradeAmend;
	CLOSE check_cursorTradeAmend;
  
	OPEN  check_cursorTradeCancel;
	FETCH check_cursorTradeCancel INTO v_foundTradeCancel;
	CLOSE check_cursorTradeCancel;
  
	OPEN  check_cursorNewTradeNew;
	FETCH check_cursorNewTradeNew INTO v_foundNewTradeNew;
	CLOSE check_cursorNewTradeNew;
  
	OPEN  check_cursorNewTradeAmend;
	FETCH check_cursorNewTradeAmend INTO v_foundNewTradeAmend;
	CLOSE check_cursorNewTradeAmend;
  
	OPEN  check_cursorNewTradeCancel;
	FETCH check_cursorNewTradeCancel INTO v_foundNewTradeCancel;
	CLOSE check_cursorNewTradeCancel;
  

	 IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundRepoNew >= 1 and v_foundRepoAmend = 0 and v_foundRepoCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1483);--insert into file Citco Dublin FA REPO Trade
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFXNew >= 1 and v_foundFXAmend = 0 and v_foundFXCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1482);--insert into file Citco Dublin FA FX Trade
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundTradeNew >= 1 and v_foundTradeAmend = 0 and v_foundTradeCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1481);--insert into file Citco Dublin FA ALL Trade
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundNewTradeNew >= 1 and v_foundNewTradeAmend = 0 and v_foundNewTradeCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,2631);--insert into file Citco Dublin FA ALL Trade New
	 END IF; 
     

   
 END;
end if;
END;