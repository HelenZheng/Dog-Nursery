create or replace
TRIGGER "BTG41"."BTG_TR_STAARS_TRADE_FILE_FOLIO" 
AFTER UPDATE OF OPCVM ON HISTOMVTS 
FOR EACH ROW

               WHEN (NEW.backoffice not in (11,13) and NEW.type not in (15,28) ) BEGIN

 if updating then
 
 DECLARE
 	v_foundGEMM               NUMBER := 0;
	v_foundARF                NUMBER := 0;
	v_foundARF2               NUMBER := 0;
  v_foundDMF                NUMBER := 0;
  v_foundABS                NUMBER := 0;
  v_foundFOCUS               NUMBER := 0;
  
  v_foundGEMMFUT            NUMBER := 0;
	v_foundARFFUT             NUMBER := 0;
	v_foundARF2FUT            NUMBER := 0;
  v_foundFOCUSFUT            NUMBER := 0;
  
  v_foundGEMMFX             NUMBER := 0;
	v_foundARFFX              NUMBER := 0;
	v_foundARF2FX             NUMBER := 0;
  v_foundFOCUSFX             NUMBER := 0;
  
	v_foundFolioARF           NUMBER := 0;
  v_foundFolioARF2          NUMBER := 0;
  v_foundFolioGEMM          NUMBER := 0;
  v_foundFolioDMF           NUMBER := 0;
  v_foundFolioABS           NUMBER := 0;
  v_foundFolioFOCUS           NUMBER := 0;
  
  v_foundFUTDepoARF         NUMBER := 0;
  v_foundFUTDepoARF2        NUMBER := 0;
  v_foundFUTDepoGEMM        NUMBER := 0;
  v_foundFUTDepoFOCUS        NUMBER := 0;
  
  v_foundFXDepoARF          NUMBER := 0;
  v_foundFXDepoARF2         NUMBER := 0;
  v_foundFXDepoGEMM         NUMBER := 0;
  v_foundFXDepoFOCUS         NUMBER := 0;
  
  v_foundGEMMNew            NUMBER := 0;
  v_foundGEMMAmend          NUMBER := 0;
  v_foundGEMMCancel         NUMBER := 0;
  v_foundARFNew             NUMBER := 0;
  v_foundARFAmend           NUMBER := 0;
  v_foundARFCancel          NUMBER := 0;
  v_foundARF2New            NUMBER := 0;
  v_foundARF2Amend          NUMBER := 0;
  v_foundARF2Cancel         NUMBER := 0;
  v_foundDMFNew             NUMBER := 0;
  v_foundDMFAmend           NUMBER := 0;
  v_foundDMFCancel          NUMBER := 0;
  v_foundABSNew             NUMBER := 0;
  v_foundABSAmend           NUMBER := 0;
  v_foundABSCancel          NUMBER := 0;
  v_foundFOCUSNew             NUMBER := 0;
  v_foundFOCUSAmend           NUMBER := 0;
  v_foundFOCUSCancel          NUMBER := 0;
  
  v_foundGEMMFUTNew         NUMBER := 0;
  v_foundGEMMFUTAmend       NUMBER := 0;
  v_foundGEMMFUTCancel      NUMBER := 0;
  v_foundARFFUTNew          NUMBER := 0;
  v_foundARFFUTAmend        NUMBER := 0;
  v_foundARFFUTCancel       NUMBER := 0;
  v_foundARF2FUTNew         NUMBER := 0;
  v_foundARF2FUTAmend       NUMBER := 0;
  v_foundARF2FUTCancel      NUMBER := 0;
  v_foundFOCUSFUTNew         NUMBER := 0;
  v_foundFOCUSFUTAmend       NUMBER := 0;
  v_foundFOCUSFUTCancel      NUMBER := 0;
  
  v_foundGEMMFXNew          NUMBER := 0;
  v_foundGEMMFXAmend        NUMBER := 0;
  v_foundGEMMFXCancel       NUMBER := 0;
  v_foundARFFXNew           NUMBER := 0;
  v_foundARFFXAmend         NUMBER := 0;
  v_foundARFFXCancel        NUMBER := 0;
  v_foundARF2FXNew          NUMBER := 0;
  v_foundARF2FXAmend        NUMBER := 0;
  v_foundARF2FXCancel       NUMBER := 0;
  v_foundFOCUSFXNew          NUMBER := 0;
  v_foundFOCUSFXAmend        NUMBER := 0;
  v_foundFOCUSFXCancel       NUMBER := 0;

 
   
   CURSOR check_cursorGEMM
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1061)  ; --GEMM STaARS file
   
	 CURSOR check_cursorARF
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1281)  ; --ARF STaARS file
   
	 CURSOR check_cursorARF2
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1282)  ; -- ARF2 STaARS file
  
   CURSOR check_cursorABS
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1321)  ; -- ABS STaARS file
   
CURSOR check_cursorFOCUS
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1582)  ; -- FOCUS STaARS file
   
   CURSOR check_cursorARF2FUT
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1363)  ; -- ARF2 FUT STaARS file
   
   CURSOR check_cursorARFFUT
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1362)  ; -- ARF FUT STaARS file
   
   CURSOR check_cursorGEMMFUT
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1361)  ; -- GEMM FUT STaARS file
   
CURSOR check_cursorFOCUSFUT
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1581)  ; -- FOCUS FUT STaARS file
   
   CURSOR check_cursorARF2FX
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1504)  ; -- ARF2 FX STaARS file
   
   CURSOR check_cursorARFFX
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1503)  ; -- ARF FX STaARS file
   
   CURSOR check_cursorGEMMFX
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1505)  ; -- GEMM FX STaARS file
   
CURSOR check_cursorFOCUSFX
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1661)  ; -- FOCUS FX STaARS file
   
   CURSOR check_cursorFolioGEMM
	 IS
	 select 1 from
						(
							select      folio.ident
							,           folio.name
							,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
							from        folio
							where       level       > 0
							start with  ident       = 12505 -- GEMM Funds
							connect by  mgr         = prior ident
						) strategy
         
						inner join  folio fund_strategy
						on          fund_strategy.ident       = strategy.parent_ident
						where  strategy.ident= :NEW."OPCVM";

	 CURSOR check_cursorFolioARF
	 IS
	 select 1 from
						(
							select      folio.ident
							,           folio.name
							,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
							from        folio
							where       level       > 0
							start with  ident       = 12506 -- ARF Funds
							connect by  mgr         = prior ident
						) strategy
         
						inner join  folio fund_strategy
						on          fund_strategy.ident       = strategy.parent_ident
						where  strategy.ident= :NEW."OPCVM";
      
      
   CURSOR check_cursorFolioARF2
   IS
   select 1 from
            (
							select      folio.ident
							,           folio.name
							,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
							from        folio
							where       level       > 0
							start with  ident       = 12642 -- ARF2 Funds
							connect by  mgr         = prior ident
						) strategy
         
						inner join  folio fund_strategy
						on          fund_strategy.ident       = strategy.parent_ident
						where  strategy.ident= :NEW."OPCVM";
            
   CURSOR check_cursorFolioABS
   IS
   select 1 from
            (
							select      folio.ident
							,           folio.name
							,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
							from        folio
							where       level       > 0
							start with  ident       = 58901 -- ABS Funds
							connect by  mgr         = prior ident
						) strategy
         
						inner join  folio fund_strategy
						on          fund_strategy.ident       = strategy.parent_ident
						where  strategy.ident= :NEW."OPCVM";
            
CURSOR check_cursorFolioFOCUS
   IS
   select 1 from
            (
							select      folio.ident
							,           folio.name
							,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
							from        folio
							where       level       > 0
							start with  ident       = 62880 -- FOCUS Funds
							connect by  mgr         = prior ident
						) strategy
         
						inner join  folio fund_strategy
						on          fund_strategy.ident       = strategy.parent_ident
						where  strategy.ident= :NEW."OPCVM";
    
    
   
   CURSOR check_cursorFUTDepoGEMM
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10009102,10006704) ; 
            
   CURSOR check_cursorFUTDepoARF2
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10006565) ; 
            
   CURSOR check_cursorFUTDepoARF
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10009042,10008322) ; 
   
CURSOR check_cursorFUTDepoFOCUS
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10010271) ; 

   CURSOR check_cursorFXDepoGEMM
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10007445,10006709) ; 
            
   CURSOR check_cursorFXDepoARF2
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10006566) ; 
            
   CURSOR check_cursorFXDepoARF
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10007444,10007443) ;  
   
CURSOR check_cursorFXDepoFOCUS
	 IS
	 select 1 from tiers 
   where  ident= :NEW."DEPOSITAIRE" and ident in (10010488) ; 
   
   
   
CURSOR check_cursorFOCUSNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1582) and generation_type=1 and sent=1  ; --FOCUS NEW file
   
CURSOR check_cursorFOCUSAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1582) and generation_type=2 and sent in(0,4)  ; --FOCUS AMEND file
   
CURSOR check_cursorFOCUSCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1582) and generation_type=3   ; --FOCUS CANCEL file
   
   
   
            
   CURSOR check_cursorGEMMNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1061) and generation_type=1 and sent=1  ; --GEMM NEW file
   
	 CURSOR check_cursorGEMMAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1061) and generation_type=2 and sent in(0,4)  ; --GEMM AMEND file
   
	 CURSOR check_cursorGEMMCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1061) and generation_type=3   ; --GEMM CANCEL file
   
   
   CURSOR check_cursorARF2New
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1282) and generation_type=1 and sent=1  ; --ARF2 NEW file
   
	 CURSOR check_cursorARF2Amend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1282) and generation_type=2 and sent in(0,4)  ; --ARF2 AMEND file
   
	 CURSOR check_cursorARF2Cancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1282) and generation_type=3   ; --ARF2 CANCEL file
   
   
   CURSOR check_cursorARFNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1281) and generation_type=1 and sent=1  ; --ARF NEW file
   
	 CURSOR check_cursorARFAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1281) and generation_type=2 and sent in(0,4)  ; --ARF AMEND file
   
	 CURSOR check_cursorARFCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1281) and generation_type=3   ; --ARF CANCEL file
   
   CURSOR check_cursorABSNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1321) and generation_type=1 and sent=1  ; --ABS NEW file
   
	 CURSOR check_cursorABSAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1321) and generation_type=2 and sent in(0,4)  ; --ABS AMEND file
   
	 CURSOR check_cursorABSCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1321) and generation_type=3   ; --ABS CANCEL file
   
   
   
   
   
CURSOR check_cursorFOCUSFUTNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1581) and generation_type=1 and sent=1  ; --FOCUS NEW FUT file
   
CURSOR check_cursorFOCUSFUTAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1581) and generation_type=2 and sent in(0,4)  ; --FOCUS AMEND FUT file
   
CURSOR check_cursorFOCUSFUTCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1581) and generation_type=3   ; --FOCUS CANCEL FUT file
   
   
   
   
   CURSOR check_cursorGEMMFUTNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1361) and generation_type=1 and sent=1  ; --GEMM NEW FUT file
   
	 CURSOR check_cursorGEMMFUTAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1361) and generation_type=2 and sent in(0,4)  ; --GEMM AMEND FUT file
   
	 CURSOR check_cursorGEMMFUTCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1361) and generation_type=3   ; --GEMM CANCEL FUT file
   
   
   CURSOR check_cursorARFFUTNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1362) and generation_type=1 and sent=1  ; --ARF NEW FUT file
   
	 CURSOR check_cursorARFFUTAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1362) and generation_type=2 and sent in(0,4)  ; --ARF AMEND FUT file
   
	 CURSOR check_cursorARFFUTCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1362) and generation_type=3   ; --ARF CANCEL FUT file
   
   
   CURSOR check_cursorARF2FUTNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1363) and generation_type=1 and sent=1  ; --ARF2 NEW FUT file
   
	 CURSOR check_cursorARF2FUTAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1363) and generation_type=2 and sent in(0,4)  ; --ARF2 AMEND FUT file
   
	 CURSOR check_cursorARF2FUTCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1363) and generation_type=3   ; --ARF2 CANCEL FUT file
   
   
CURSOR check_cursorFOCUSFXNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1661) and generation_type=1 and sent=1  ; --FOCUS NEW FX file
   
CURSOR check_cursorFOCUSFXAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1661) and generation_type=2 and sent in(0,4)  ; --FOCUS AMEND FX file
   
CURSOR check_cursorFOCUSFXCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1661) and generation_type=3   ; --FOCUS CANCEL FX file
   
   
   
   CURSOR check_cursorGEMMFXNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1505) and generation_type=1 and sent=1  ; --GEMM NEW FX file
   
	 CURSOR check_cursorGEMMFXAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1505) and generation_type=2 and sent in(0,4)  ; --GEMM AMEND FX file
   
	 CURSOR check_cursorGEMMFXCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1505) and generation_type=3   ; --GEMM CANCEL FX file
   
   
   CURSOR check_cursorARFFXNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1503) and generation_type=1 and sent=1  ; --ARF NEW FX file
   
	 CURSOR check_cursorARFFXAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1503) and generation_type=2 and sent in(0,4)  ; --ARF AMEND FX file
   
	 CURSOR check_cursorARFFXCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1503) and generation_type=3   ; --ARF CANCEL FX file
   
   
   CURSOR check_cursorARF2FXNew
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1504) and generation_type=1 and sent=1  ; --ARF2 NEW FX file
   
	 CURSOR check_cursorARF2FXAmend
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1504) and generation_type=2 and sent in(0,4)  ; --ARF2 AMEND FX file
   
	 CURSOR check_cursorARF2FXCancel
	 IS
	 SELECT 1
	 FROM amrecon_vacations 
	 WHERE refcon = :NEW."REFCON"  and esid in (1504) and generation_type=3   ; --ARF2 CANCEL FX file
   
   
   
   
  Begin
  OPEN  check_cursorGEMM;
  FETCH check_cursorGEMM INTO v_foundGEMM;
  CLOSE check_cursorGEMM;

  OPEN  check_cursorARF;
  FETCH check_cursorARF INTO v_foundARF;
  CLOSE check_cursorARF;
  
  OPEN  check_cursorARF2;
  FETCH check_cursorARF2 INTO v_foundARF2;
  CLOSE check_cursorARF2;
  
  OPEN  check_cursorABS;
  FETCH check_cursorABS INTO v_foundABS;
  CLOSE check_cursorABS;
  
OPEN  check_cursorFOCUS;
  FETCH check_cursorFOCUS INTO v_foundFOCUS;
  CLOSE check_cursorFOCUS;
  
  
  OPEN  check_cursorGEMMFUT;
  FETCH check_cursorGEMMFUT INTO v_foundGEMMFUT;
  CLOSE check_cursorGEMMFUT;

  OPEN  check_cursorARFFUT;
  FETCH check_cursorARFFUT INTO v_foundARFFUT;
  CLOSE check_cursorARFFUT;
  
  OPEN  check_cursorARF2FUT;
  FETCH check_cursorARF2FUT INTO v_foundARF2FUT;
  CLOSE check_cursorARF2FUT;
  
OPEN  check_cursorFOCUSFUT;
  FETCH check_cursorFOCUSFUT INTO v_foundFOCUSFUT;
  CLOSE check_cursorFOCUSFUT;
  
  OPEN  check_cursorGEMMFX;
  FETCH check_cursorGEMMFX INTO v_foundGEMMFX;
  CLOSE check_cursorGEMMFX;

  OPEN  check_cursorARFFX;
  FETCH check_cursorARFFX INTO v_foundARFFX;
  CLOSE check_cursorARFFX;
  
  OPEN  check_cursorARF2FX;
  FETCH check_cursorARF2FX INTO v_foundARF2FX;
  CLOSE check_cursorARF2FX;
  
OPEN  check_cursorFOCUSFX;
  FETCH check_cursorFOCUSFX INTO v_foundFOCUSFX;
  CLOSE check_cursorFOCUSFX;
  
  
  OPEN  check_cursorFolioARF2;
  FETCH check_cursorFolioARF2 INTO v_foundFolioARF2;
  CLOSE check_cursorFolioARF2;
  
  OPEN  check_cursorFolioARF;
  FETCH check_cursorFolioARF INTO v_foundFolioARF;
  CLOSE check_cursorFolioARF;
  
  OPEN  check_cursorFolioGEMM;
  FETCH check_cursorFolioGEMM INTO v_foundFolioGEMM;
  CLOSE check_cursorFolioGEMM;
  
  OPEN  check_cursorFolioABS;
  FETCH check_cursorFolioABS INTO v_foundFolioABS;
  CLOSE check_cursorFolioABS;
  
OPEN  check_cursorFolioFOCUS;
  FETCH check_cursorFolioFOCUS INTO v_foundFolioFOCUS;
  CLOSE check_cursorFolioFOCUS;
  
  
  
  OPEN  check_cursorFUTDepoARF2;
  FETCH check_cursorFUTDepoARF2 INTO v_foundFUTDepoARF2;
  CLOSE check_cursorFUTDepoARF2;
  
  OPEN  check_cursorFUTDepoARF;
  FETCH check_cursorFUTDepoARF INTO v_foundFUTDepoARF;
  CLOSE check_cursorFUTDepoARF;
  
  OPEN  check_cursorFUTDepoGEMM;
  FETCH check_cursorFUTDepoGEMM INTO v_foundFUTDepoGEMM;
  CLOSE check_cursorFUTDepoGEMM;
  
  
OPEN  check_cursorFUTDepoFOCUS;
  FETCH check_cursorFUTDepoFOCUS INTO v_foundFUTDepoFOCUS;
  CLOSE check_cursorFUTDepoFOCUS;
  
  
  OPEN  check_cursorFXDepoARF2;
  FETCH check_cursorFXDepoARF2 INTO v_foundFXDepoARF2;
  CLOSE check_cursorFXDepoARF2;
  
  OPEN  check_cursorFXDepoARF;
  FETCH check_cursorFXDepoARF INTO v_foundFXDepoARF;
  CLOSE check_cursorFXDepoARF;
  
  OPEN  check_cursorFXDepoGEMM;
  FETCH check_cursorFXDepoGEMM INTO v_foundFXDepoGEMM;
  CLOSE check_cursorFXDepoGEMM;
  
  
OPEN  check_cursorFXDepoFOCUS;
  FETCH check_cursorFXDepoFOCUS INTO v_foundFXDepoFOCUS;
  CLOSE check_cursorFXDepoFOCUS;
  
  
  
  
  
OPEN  check_cursorFOCUSNew;
	FETCH check_cursorFOCUSNew INTO v_foundFOCUSNew;
	CLOSE check_cursorFOCUSNew;
  
OPEN  check_cursorFOCUSAmend;
	FETCH check_cursorFOCUSAmend INTO v_foundFOCUSAmend;
	CLOSE check_cursorFOCUSAmend;
  
OPEN  check_cursorFOCUSCancel;
	FETCH check_cursorFOCUSCancel INTO v_foundFOCUSCancel;
	CLOSE check_cursorFOCUSCancel;
  
  
  
  
  
  
  OPEN  check_cursorGEMMNew;
	FETCH check_cursorGEMMNew INTO v_foundGEMMNew;
	CLOSE check_cursorGEMMNew;
  
	OPEN  check_cursorGEMMAmend;
	FETCH check_cursorGEMMAmend INTO v_foundGEMMAmend;
	CLOSE check_cursorGEMMAmend;
  
	OPEN  check_cursorGEMMCancel;
	FETCH check_cursorGEMMCancel INTO v_foundGEMMCancel;
	CLOSE check_cursorGEMMCancel;
  
	OPEN  check_cursorARF2New;
	FETCH check_cursorARF2New INTO v_foundARF2New;
	CLOSE check_cursorARF2New;
  
	OPEN  check_cursorARF2Amend;
	FETCH check_cursorARF2Amend INTO v_foundARF2Amend;
	CLOSE check_cursorARF2Amend;
  
	OPEN  check_cursorARF2Cancel;
	FETCH check_cursorARF2Cancel INTO v_foundARF2Cancel;
	CLOSE check_cursorARF2Cancel;
  
	OPEN  check_cursorARFNew;
	FETCH check_cursorARFNew INTO v_foundARFNew;
	CLOSE check_cursorARFNew;
  
	OPEN  check_cursorARFAmend;
	FETCH check_cursorARFAmend INTO v_foundARFAmend;
	CLOSE check_cursorARFAmend;
  
	OPEN  check_cursorARFCancel;
	FETCH check_cursorARFCancel INTO v_foundARFCancel;
	CLOSE check_cursorARFCancel;
  
  OPEN  check_cursorABSNew;
	FETCH check_cursorABSNew INTO v_foundABSNew;
	CLOSE check_cursorABSNew;
  
	OPEN  check_cursorABSAmend;
	FETCH check_cursorABSAmend INTO v_foundABSAmend;
	CLOSE check_cursorABSAmend;
  
	OPEN  check_cursorABSCancel;
	FETCH check_cursorABSCancel INTO v_foundABSCancel;
	CLOSE check_cursorABSCancel;
  
  
  
OPEN  check_cursorFOCUSFUTNew;
	FETCH check_cursorFOCUSFUTNew INTO v_foundFOCUSFUTNew;
	CLOSE check_cursorFOCUSFUTNew;
  
OPEN  check_cursorFOCUSFUTAmend;
	FETCH check_cursorFOCUSFUTAmend INTO v_foundFOCUSFUTAmend;
	CLOSE check_cursorFOCUSFUTAmend;
  
OPEN  check_cursorFOCUSFUTCancel;
	FETCH check_cursorFOCUSFUTCancel INTO v_foundFOCUSFUTCancel;
	CLOSE check_cursorFOCUSFUTCancel;
  
  
  
  OPEN  check_cursorGEMMFUTNew;
	FETCH check_cursorGEMMFUTNew INTO v_foundGEMMFUTNew;
	CLOSE check_cursorGEMMFUTNew;
  
	OPEN  check_cursorGEMMFUTAmend;
	FETCH check_cursorGEMMFUTAmend INTO v_foundGEMMFUTAmend;
	CLOSE check_cursorGEMMFUTAmend;
  
	OPEN  check_cursorGEMMFUTCancel;
	FETCH check_cursorGEMMFUTCancel INTO v_foundGEMMFUTCancel;
	CLOSE check_cursorGEMMFUTCancel;
  
  OPEN  check_cursorARFFUTNew;
	FETCH check_cursorARFFUTNew INTO v_foundARFFUTNew;
	CLOSE check_cursorARFFUTNew;
  
	OPEN  check_cursorARFFUTAmend;
	FETCH check_cursorARFFUTAmend INTO v_foundARFFUTAmend;
	CLOSE check_cursorARFFUTAmend;
  
	OPEN  check_cursorARFFUTCancel;
	FETCH check_cursorARFFUTCancel INTO v_foundARFFUTCancel;
	CLOSE check_cursorARFFUTCancel;
  
  OPEN  check_cursorARF2FUTNew;
	FETCH check_cursorARF2FUTNew INTO v_foundARF2FUTNew;
	CLOSE check_cursorARF2FUTNew;
  
	OPEN  check_cursorARF2FUTAmend;
	FETCH check_cursorARF2FUTAmend INTO v_foundARF2FUTAmend;
	CLOSE check_cursorARF2FUTAmend;
  
	OPEN  check_cursorARF2FUTCancel;
	FETCH check_cursorARF2FUTCancel INTO v_foundARF2FUTCancel;
	CLOSE check_cursorARF2FUTCancel;
  
  
  
  
OPEN  check_cursorFOCUSFXNew;
	FETCH check_cursorFOCUSFXNew INTO v_foundFOCUSFXNew;
	CLOSE check_cursorFOCUSFXNew;
  
OPEN  check_cursorFOCUSFXAmend;
	FETCH check_cursorFOCUSFXAmend INTO v_foundFOCUSFXAmend;
	CLOSE check_cursorFOCUSFXAmend;
  
OPEN  check_cursorFOCUSFXCancel;
	FETCH check_cursorFOCUSFXCancel INTO v_foundFOCUSFXCancel;
	CLOSE check_cursorFOCUSFXCancel;
  
  
  
  OPEN  check_cursorGEMMFXNew;
	FETCH check_cursorGEMMFXNew INTO v_foundGEMMFXNew;
	CLOSE check_cursorGEMMFXNew;
  
	OPEN  check_cursorGEMMFXAmend;
	FETCH check_cursorGEMMFXAmend INTO v_foundGEMMFXAmend;
	CLOSE check_cursorGEMMFXAmend;
  
	OPEN  check_cursorGEMMFXCancel;
	FETCH check_cursorGEMMFXCancel INTO v_foundGEMMFXCancel;
	CLOSE check_cursorGEMMFXCancel;
  
  OPEN  check_cursorARFFXNew;
	FETCH check_cursorARFFXNew INTO v_foundARFFXNew;
	CLOSE check_cursorARFFXNew;
  
	OPEN  check_cursorARFFXAmend;
	FETCH check_cursorARFFXAmend INTO v_foundARFFXAmend;
	CLOSE check_cursorARFFXAmend;
  
	OPEN  check_cursorARFFXCancel;
	FETCH check_cursorARFFXCancel INTO v_foundARFFXCancel;
	CLOSE check_cursorARFFXCancel;
  
  OPEN  check_cursorARF2FXNew;
	FETCH check_cursorARF2FXNew INTO v_foundARF2FXNew;
	CLOSE check_cursorARF2FXNew;
  
	OPEN  check_cursorARF2FXAmend;
	FETCH check_cursorARF2FXAmend INTO v_foundARF2FXAmend;
	CLOSE check_cursorARF2FXAmend;
  
	OPEN  check_cursorARF2FXCancel;
	FETCH check_cursorARF2FXCancel INTO v_foundARF2FXCancel;
	CLOSE check_cursorARF2FXCancel;
  


IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUSNew >= 1 AND v_foundFUTDepoFOCUS=0 AND v_foundFXDepoFOCUS=0 and v_foundFolioFOCUS = 1 and v_foundFOCUSAmend = 0 and v_foundFOCUSCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1582); --FOCUS TRADE FILE
	 END IF; 
 
IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUSFUTNew >= 1 AND v_foundFUTDepoFOCUS >=1 and v_foundFolioFOCUS = 1 and v_foundFOCUSFUTAmend = 0 and v_foundFOCUSFUTCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1581); -- FOCUS FUT FILE
	 END IF; 
   
IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUSFXNew >= 1 AND v_foundFXDepoFOCUS >=1 and v_foundFolioFOCUS = 1 and v_foundFOCUSFXAmend = 0 and v_foundFOCUSFXCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1661); --FOCUS FX TARDE FILE
	 END IF; 
   
	 IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMMNew >= 1 AND v_foundFUTDepoGEMM=0 AND v_foundFXDepoGEMM=0 and v_foundFolioGEMM = 1 and v_foundGEMMAmend = 0 and v_foundGEMMCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1061); --GEMM TRADE FILE
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMMFUTNew >= 1 AND v_foundFUTDepoGEMM >=1 and v_foundFolioGEMM = 1 and v_foundGEMMFUTAmend = 0 and v_foundGEMMFUTCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1361); -- GEMM FUT FILE
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMMFXNew >= 1 AND v_foundFXDepoGEMM >=1 and v_foundFolioGEMM = 1 and v_foundGEMMFXAmend = 0 and v_foundGEMMFXCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1505); --GEMM FX TARDE FILE
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARFNew >= 1 AND v_foundFUTDepoARF=0 AND v_foundFXDepoARF=0 and v_foundFolioARF = 1  and v_foundARFAmend = 0 and v_foundARFCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1281);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARFFUTNew >= 1 AND v_foundFUTDepoARF >=1 and v_foundFolioARF = 1 and v_foundARFFUTAmend = 0 and v_foundARFFUTCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1362);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARFFXNew >= 1 AND v_foundFXDepoARF >=1 and v_foundFolioARF = 1 and v_foundARFFXAmend = 0 and v_foundARFFXCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1503); --ARF FX TARDE FILE
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2New >= 1 AND v_foundFUTDepoARF2=0 AND v_foundFXDepoARF2=0 and v_foundFolioARF2 = 1 and v_foundARF2Amend = 0 and v_foundARF2Cancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1282);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2FUTNew >= 1 AND v_foundFUTDepoARF2 >=1 and v_foundFolioARF2 = 1 and v_foundARF2FUTAmend = 0 and v_foundARF2FUTCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1363);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2FXNew >= 1 AND v_foundFXDepoARF2 >=1 and v_foundFolioARF2 = 1 and v_foundARF2FXAmend = 0 and v_foundARF2FXCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1504);--ARF2 FX TRADE FILE
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundABSNew >= 1 and v_foundFolioABS = 1 and v_foundABSAmend = 0 and v_foundABSCancel = 0 )
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",2,sysdate,0 ,null,1321);
	 END IF; 
   
   
IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUS =0 and v_foundFolioFOCUS = 1 AND v_foundFUTDepoARF2 =0 AND v_foundFXDepoARF2 =0 and v_foundFUTDepoARF =0 and v_foundFXDepoARF =0 AND v_foundFUTDepoGEMM =0 AND v_foundFXDepoGEMM =0 AND v_foundFUTDepoFOCUS =0 AND v_foundFXDepoFOCUS =0)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1582);--focus trade file
	 END IF; 
   
IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUSFUT =0 and v_foundFolioFOCUS = 1 AND v_foundFUTDepoFOCUS >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1581);-- focus fut file
	 END IF; 
   
IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundFOCUSFX =0 and v_foundFolioFOCUS = 1 AND v_foundFXDepoFOCUS >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1661);-- focus fx tarde file
	 END IF; 
   
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMM =0 and v_foundFolioGEMM = 1 AND v_foundFUTDepoARF2 =0 AND v_foundFXDepoARF2 =0 and v_foundFUTDepoARF =0 and v_foundFXDepoARF =0 AND v_foundFUTDepoGEMM =0 AND v_foundFXDepoGEMM =0 AND v_foundFUTDepoFOCUS =0 AND v_foundFXDepoFOCUS =0)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1061);--gemm trade file
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMMFUT =0 and v_foundFolioGEMM = 1 AND v_foundFUTDepoGEMM >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1361);-- gemm fut file
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundGEMMFX =0 and v_foundFolioGEMM = 1 AND v_foundFXDepoGEMM >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1505);-- gemm fx tarde file
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF =0 and v_foundFolioARF = 1 AND v_foundFUTDepoARF2 =0 AND v_foundFXDepoARF2 =0 and v_foundFUTDepoARF =0 and v_foundFXDepoARF =0 AND v_foundFUTDepoGEMM =0 AND v_foundFXDepoGEMM =0 AND v_foundFUTDepoFOCUS =0 AND v_foundFXDepoFOCUS =0)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1281);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARFFUT =0 and v_foundFolioARF = 1 AND v_foundFUTDepoARF >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1362);
	 END IF;
   
    IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARFFX =0 and v_foundFolioARF = 1 AND v_foundFXDepoARF >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1503);
	 END IF;
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2 =0 and v_foundFolioARF2 = 1 AND v_foundFUTDepoARF2 =0 and v_foundFUTDepoARF =0 AND v_foundFUTDepoGEMM =0 AND v_foundFXDepoARF2 =0 and v_foundFXDepoARF =0 AND v_foundFXDepoGEMM =0 AND v_foundFUTDepoFOCUS =0 AND v_foundFXDepoFOCUS =0)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1282);
	 END IF; 
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2FUT =0 and v_foundFolioARF2 = 1 AND v_foundFUTDepoARF2 >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1363);
	 END IF;
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundARF2FX =0 and v_foundFolioARF2 = 1 AND v_foundFXDepoARF2 >=1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1504);
	 END IF;
   
   IF (BTG_FN_TOP_STRATEGY(:NEW."OPCVM" ) != BTG_FN_TOP_STRATEGY(:OLD."OPCVM") and v_foundABS =0 and v_foundFolioABS = 1)
	 THEN
	 INSERT INTO amrecon_vacations VALUES ( :NEW."REFCON",1,sysdate,0 ,null,1321);
	 END IF; 
  
  End;
  
 end if;
END;