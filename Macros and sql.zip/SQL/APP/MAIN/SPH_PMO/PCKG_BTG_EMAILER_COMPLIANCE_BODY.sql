create or replace PACKAGE BODY            PCKG_BTG_EMAILER_COMPLIANCE
AS



-- *****************************************************************
 -- Description:    PROCEDURE COMPL_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 20 Jun 2014     Gustavo Binnie  Created (COM-112)
 -- 31 Jul 2015		Matt Kelly		Migrated to new package PCKG_BTG_EMAILER_COMPLIANCE_REPORTS
 -- *****************************************************************  

  PROCEDURE COMPL_RESTRICTED_LIST_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: COMPL_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR


SELECT   distinct
                  RL.NAME                               Restricted_List
				, FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID in (2,3,4,5,6,7)

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: COMPL_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
	END COMPL_RESTRICTED_LIST_TRADES;


 -- *****************************************************************
 -- Description:    PROCEDURE TRADES_MISSING_ID_BB_COMPANY
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 04 Nov 2014     Gustavo Binnie  Created (COM-134)
 -- 09 Oct 2015		Matt Kelly		Updated to include "Rights Issues" 
 --									allotment (ident = 1751)
 -- *****************************************************************  

  PROCEDURE TRADES_MISSING_ID_BB_COMPANY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADES_MISSING_ID_BB_COMPANY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT		
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Sec.libelle                           Instrument_Name
					, Sec.reference                         Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
          , REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null then Sec.sicovam ELSE NULL END || ',' ||
				case when Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null then Underlying1.sicovam ELSE NULL END || ',' ||
				case when Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL then Underlying2.sicovam ELSE NULL END || ',' ||
			  case when UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL then UND_BASKET_SECURITIES.sicovam ELSE NULL END 
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
															SICOVAM_MISSING_DATA
           , REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null then Sec.REFERENCE ELSE NULL END || ',' ||
				case when Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null then Underlying1.REFERENCE ELSE NULL END || ',' ||
				case when Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL then Underlying2.REFERENCE ELSE NULL END || ',' ||
			  case when UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL then UND_BASKET_SECURITIES.REFERENCE ELSE NULL END 
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
															Inst_Reference_MISSING_DATA
				FROM histomvts Trades
				inner join titres Sec
				on Trades.sicovam = Sec.sicovam
				INNER JOIN
					(   SELECT 
						CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
						CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)  AS Fund_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)  AS BOOK_NAME ,
						FOLIO.ident                                                         AS STRATEGY_ID ,
						FOLIO.name                                                          AS STRATEGY_NAME ,
						level
						FROM FOLIO
						WHERE LEVEL                                        >= 4
						START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)-- Primary Funds, UCITS Funds
						CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
					) FUND_BOOK_STRATEGY 
				ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 
				INNER JOIN  business_events
				ON          business_events.id                            = Trades.type
				INNER JOIN  riskusers trader
				ON          trader.ident                                  = Trades.operateur
				LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
				ON			Sec.sicovam = ID_BB_COMPANY.sophis_ident
				and			ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   titres Underlying1
				ON			Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
				LEFT JOIN   extrnl_references_instruments UND1_ID_BB_COMPANY
				ON			Underlying1.sicovam = UND1_ID_BB_COMPANY.sophis_ident
				and			UND1_ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   titres Underlying2
				ON			Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
				and			Underlying1.type <> 'H'				
				LEFT JOIN   extrnl_references_instruments UND2_ID_BB_COMPANY
				ON			Underlying2.sicovam = UND2_ID_BB_COMPANY.sophis_ident
				and			UND2_ID_BB_COMPANY.ref_ident = 673
				LEFT JOIN   panier UNDERLYING_BASKET	
				ON			UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM
        LEFT JOIN   TITRES UND_BASKET_SECURITIES
				ON			UND_BASKET_SECURITIES.SICOVAM = UNDERLYING_BASKET.sicopanier
				LEFT JOIN   extrnl_references_instruments UND_BASKET_ID_BB_COMPANY
				ON			UNDERLYING_BASKET.sicopanier = UND_BASKET_ID_BB_COMPANY.sophis_ident
				and			UND_BASKET_ID_BB_COMPANY.ref_ident = 673		
				WHERE 
        
				    Trades.BACKOFFICE						          NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
				AND TRUNC(Trades.DATENEG)                         >= TRUNC(BTG_BUSINESS_DATE(sysdate,-5))  --recent trades
				AND business_events.compta                        = 1                                     --trades affecting position
        AND
        (
        (Sec.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and ID_BB_COMPANY.value is null)
        or
        (Underlying1.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) and UND1_ID_BB_COMPANY.value is null)
        or
        (Underlying2.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND2_ID_BB_COMPANY.VALUE IS NULL)
        or
        (UND_BASKET_SECURITIES.AFFECTATION IN (1751,1601,9,38,1353,4,5,18,25,26,1020,1102,1140,1180,1251,1500,1501,1502,1503,1504,1505,1506,1600,35,1252,1450) AND UND_BASKET_ID_BB_COMPANY.VALUE IS NULL)
        )
        ;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: TRADES_MISSING_ID_BB_COMPANY
  -- *****************************************************************   
	END TRADES_MISSING_ID_BB_COMPANY;


-- *****************************************************************
-- Description: PROCEDURE RULE_105_RESTRICTED_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_RESTRICTED_TRADES
(
	p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- ***************************************************************************
-- BEGIN OF RULE_105_RESTRICTED_TRADES 
-- ***************************************************************************	
	    OPEN p_CURSOR FOR

SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer
                , SHORT_POSITIONS.POSITION_QTY          n$Position                
FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,14414,14405,90565) -- (14414)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam
      
LEFT JOIN 
(
  SELECT Trades2.sicovam, Trades2.entite, trunc(sum(Trades2.quantite),7) POSITION_QTY
  FROM HISTOMVTS Trades2
  INNER JOIN  business_events
  ON          business_events.id                            = Trades2.type
  AND         business_events.compta                        = 1  
  WHERE       Trades2.BACKOFFICE                            NOT IN (192,11,13,17,26,27,220,248,252)
  GROUP       BY                                            Trades2.sicovam, Trades2.entite
) SHORT_POSITIONS
ON  SHORT_POSITIONS.SICOVAM = Trades.SICOVAM
AND SHORT_POSITIONS.ENTITE  = Trades.ENTITE      

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID = 15

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon   
		 AND RLA.LIST_ID  = RL.ID		         

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR 
FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN 
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate-30)  --recent trades
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
AND (
      TRADES.QUANTITE < 0 --Sell Trades
      OR
      (Sec.TYPE = 'D' AND Sec.TYPEPRO=2 AND TRADES.QUANTITE > 0) --Buy Trades on Put options
    )
;

-- ***************************************************************************
-- END OF RULE_105_RESTRICTED_TRADES 
-- ***************************************************************************	

END RULE_105_RESTRICTED_TRADES;

-- *****************************************************************
-- Description: PROCEDURE RULE_105_WATCH_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_WATCH_TRADES
(
	p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- ***************************************************************************
-- BEGIN OF RULE_105_WATCH_TRADES 
-- ***************************************************************************	
	    OPEN p_CURSOR FOR

SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer
                , SHORT_POSITIONS.POSITION_QTY          n$Position                
FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,14414,14405,90565) -- (14414)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam
      
LEFT JOIN 
(
  SELECT Trades2.sicovam, Trades2.entite, trunc(sum(Trades2.quantite),7) POSITION_QTY
  FROM HISTOMVTS Trades2
  INNER JOIN  business_events
  ON          business_events.id                            = Trades2.type
  AND         business_events.compta                        = 1  
  WHERE       Trades2.BACKOFFICE                            NOT IN (192,11,13,17,26,27,220,248,252)
  GROUP       BY                                            Trades2.sicovam, Trades2.entite
) SHORT_POSITIONS
ON  SHORT_POSITIONS.SICOVAM = Trades.SICOVAM
AND SHORT_POSITIONS.ENTITE  = Trades.ENTITE      

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID = 16

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon 
		 AND RLA.LIST_ID  = RL.ID		           

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR 
FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN 
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate-30)  --recent trades
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
AND (
      TRADES.QUANTITE < 0 --Sell Trades
      OR
      (Sec.TYPE = 'D' AND Sec.TYPEPRO=2 AND TRADES.QUANTITE > 0) --Buy Trades on Put options
    )
;

-- ***************************************************************************
-- END OF RULE_105_WATCH_TRADES 
-- ***************************************************************************	

END RULE_105_WATCH_TRADES;


-- *****************************************************************
-- Description:     PROCEDURE  GPI_WATCH_LIST
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 09 Jun 2015     Gustavo Binnie  Created.

-- *****************************************************************  

  PROCEDURE GPI_WATCH_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: GPI_WATCH_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =19

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: GPI_WATCH_LIST
-- *****************************************************************
   END GPI_WATCH_LIST;

 -- *****************************************************************
 -- Description:    PROCEDURE EQ_RESTRICTED_LISTS_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 24 Jun 2015     Gustavo Binnie  Created (COM-190)
 -- *****************************************************************  

  PROCEDURE EQ_RESTRICTED_LISTS_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EQ_RESTRICTED_LISTS_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct
                  RL.NAME                               Restricted_List
                , FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673

INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID in (39,40,41,42,43,44,45,46,59,79) 
--EQ Global Consumer Restricted List / EQ Relative Value Restricted List / EQ US Cash Restricted List / EQ Systematic Restricted List / 
--EQ Convertible Bonds Restricted List / EQ Events Restricted List / EQ Volatility Restricted List / EQ US IPO / CIO(AD) Restricted List
--Timber Trading Fund Restricted List

INNER JOIN BTG_RESTRICTED_LIST RL
					ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
					ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: EQ_RESTRICTED_LISTS_TRADES
-- *****************************************************************
   END EQ_RESTRICTED_LISTS_TRADES;


 -- *****************************************************************
 -- Description:    PROCEDURE TRADER_MISSING_ALLOC_RULE
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 03 Sep 2015     Gustavo Binnie  Created (COM-219)
 -- 16 AUG 2018   Jeff Yu    Modified (PMOGUCITS-60)
 -- *****************************************************************  

  PROCEDURE TRADER_MISSING_ALLOC_RULE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADER_MISSING_ALLOC_RULE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 		USERSMISSING.IDENT 		ID, 
			USERSMISSING.TRADER 	TRADER, 
			STRATS.STRATEGIES 		STRATEGY
FROM
		(
		SELECT  
					DISTINCT
					HISTOMVTS.OPERATEUR AS IDENT,
					RISKUSERS.NAME  AS TRADER                        
		FROM        HISTOMVTS
		INNER JOIN  RISKUSERS
		ON          RISKUSERS.IDENT = HISTOMVTS.OPERATEUR
		AND         RISKUSERS.GIDENT = 4567 --FRONT OFFICE USER GROUP
		INNER JOIN  USERINFOS
		ON          USERINFOS.IDENT = RISKUSERS.IDENT
		AND         USERINFOS.COUNTRY != 'BRAZIL' --EXCLUDE BRAZIL TRADERS SINCE THEY ARE NOT MONITORED BY GAM COMPLIANCE
		INNER JOIN  BUSINESS_EVENTS
		ON          BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
		AND         BUSINESS_EVENTS.COMPTA = 1 --POSITION AFFECTING TICKETS ONLY
		WHERE       HISTOMVTS.OPERATEUR NOT IN (
										SELECT SOPHIS_USER_ID 
										FROM BTG_ALLCTN_RL_TRDR) --SET UP IN ALLOCATION RULE MANAGER
		AND         HISTOMVTS.DATENEG > '01-JAN-2015' --TRADES FROM THIS YEAR
		) USERSMISSING
LEFT JOIN  
		(	  	
		SELECT 		TRADER AS TRADERID,
					LISTAGG(STRATEGIES, ',') within group (order by 1) AS STRATEGIES --CONCATENATION OF STRATEGIES THAT TRADER BOOK INTO
		FROM
					(
					SELECT 		DISTINCT TRADES.OPERATEUR 	 AS TRADER,
								FUND_BOOK_STRATEGY.BOOK_NAME AS STRATEGIES 
					FROM 		HISTOMVTS TRADES
					INNER JOIN  BUSINESS_EVENTS
					ON          BUSINESS_EVENTS.ID = TRADES.TYPE
					AND         BUSINESS_EVENTS.COMPTA = 1
					INNER JOIN (
								SELECT REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
								,FOLIO.IDENT AS STRATEGY_ID
								,FOLIO.NAME AS STRATEGY_NAME
								,LEVEL
								FROM FOLIO
								WHERE LEVEL >= 4 START
								WITH FOLIO.IDENT IN (14414,90565) --PRIMARY FUNDS AND UCITS FUND
								CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
								) FUND_BOOK_STRATEGY
					ON 			FUND_BOOK_STRATEGY.STRATEGY_ID = TRADES.OPCVM
					WHERE 		TRADES.DATENEG > (SYSDATE-90) -- LAST 90 DAYS
					) 
		GROUP BY TRADER
		)STRATS
ON 		USERSMISSING.IDENT = STRATS.TRADERID
ORDER 	BY 2
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: TRADER_MISSING_ALLOC_RULE
-- *****************************************************************
   END TRADER_MISSING_ALLOC_RULE;

 -- *****************************************************************
 -- Description:    PROCEDURE REMIT_TRADING
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Nov 2015     Gustavo Binnie  Created (COM-238)
 -- *****************************************************************  

  PROCEDURE REMIT_TRADING
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REMIT_TRADING
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, SEC.libelle                    		Name
						, SEC.reference                  		Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
    FROM 		histomvts 	Trades
	INNER JOIN 	titres 		Sec
	ON 			Trades.sicovam 				= Sec.sicovam
    INNER JOIN  riskusers trader
    ON          trader.ident                = Trades.operateur
	INNER JOIN
		(   SELECT 
			CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
			CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)  AS Fund_NAME ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID ,
			REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)  AS BOOK_NAME ,
			FOLIO.ident                                                         AS STRATEGY_ID ,
			FOLIO.name                                                          AS STRATEGY_NAME ,
			level
			FROM FOLIO
			WHERE LEVEL                                        >= 4
			START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414, 90565) 
			CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
		) FUND_BOOK_STRATEGY 
	ON          FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM 
	LEFT JOIN   titres Underlying1
    ON 			Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
	LEFT JOIN   titres Underlying2
    ON 			Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
    and 		Underlying1.type <> 'H'
	WHERE 
	(
		SEC.MODELE LIKE '%Power%' or Underlying1.modele like '%Power%' or Underlying2.modele like '%Power%' --Insrument or underlying is using a Power model
		or
		SEC.MODELE LIKE '%Gas%' or Underlying1.modele like '%Gas%' or Underlying2.modele like '%Gas%' --Insrument or underlying is using a Gas model
		or
		sec.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Insrument is using an energy unit (e.g. MMBtu, MWh)
		or
		Underlying1.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Underlying is using an energy unit (e.g. MMBtu, MWh)
		or
		Underlying2.unit in (SELECT ID FROM COMMODITY_UNIT where UNIT_TYPE = 67612715) --Second underlying is using an energy unit (e.g. MMBtu, MWh)
	)
	AND
	(
		(SEC.marche <> 961 and SEC.marche <> 1554) -- Future Market not NYMEX USD and not NYMEX CRUDE/RBOB/H-OIL/NATGAS
		OR
		Underlying1.REFERENCE <> 'NG' --Underlying is not NG (NAT GAS NYMEX)
	)
	AND    
	TRADES.BACKOFFICE  NOT IN (192,11,13,17,26,27,220,248,252)
	AND
	TRADES.DATENEG > ADD_MONTHS(SYSDATE,-1)
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: REMIT_TRADING
-- *****************************************************************
   END REMIT_TRADING;


   -- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_TRANSACTION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 22 DEC 2016     Jeff Yu    Created (COM-293)
 -- 17 JAN 2017      Jeff Yu    Modified (COM-298)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_TRANSACTION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOI_ILS_TRANSACTION
  -- *****************************************************************   
          OPEN p_CURSOR FOR


    SELECT DISTINCT
                               histomvts.SICOVAM                                                          as  Instrument_id
                              , histomvts.refcon                                                               as  Transaction_id
                              , titres.libelle                                                                       as  Instrument_name
                              , BE.name                                                                            as  Business_event
                              , affectation.libelle                                                              as  Allotment
                              , btg_get_instrument_type(histomvts.sicovam)                  as  Instrument_Type
                              , DEVISE_TO_STR(histomvts.devisepay)                             as  Payment_currency
                              , DEVISE_TO_STR(devisectt)                                               as  Quotation_currency
                              , histomvts.dateneg                                                             as  d$Trade_date
                              , histomvts.dateval                                                              as  d$Value_date
                              , histomvts.quantite                                                            as   n$Quantity
                              , histomvts.QUANTITE * NVL(TITRES.nominal,1)                as  n$Nominal
                              , histomvts.cours                                                                 as  p$8$Price
                              , histomvts.montant                                                            as  n$Net_amount
                              , histomvts.tauxchange                                                       as  Exchange_rate

    FROM  histomvts
    INNER JOIN (
            SELECT      FOLIO.ident AS STRATEGY_ID
                             ,FOLIO.NAME AS STRATEGY_NAME
                             ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 2 
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_BTG_FUND,PCKG_BTG.FOLIO_BTG_WEALTH_MANAGEMENT) --12514,86931
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
     LEFT JOIN  TITRES
     ON TITRES.SICOVAM=histomvts.SICOVAM

     LEFT JOIN  BUSINESS_EVENTS BE
     ON BE.id=histomvts.type

     LEFT JOIN  AFFECTATION
     ON  AFFECTATION.ident=titres.affectation

     LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
     ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
     AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415

    LEFT JOIN AUDIT_MVT  ---Get history trades audit information
     ON AUDIT_MVT.REFCON=histomvts.REFCON
     
     WHERE  
    (
      (titres.type in ('X','E','K') and DEVISE_TO_STR(marche)='ILS') OR
      (DEVISE_TO_STR(devisectt)='ILS' or DEVISE_TO_STR(deviseac)='ILS' or DEVISE_TO_STR(deviseexer)='ILS' or DEVISE_TO_STR(histomvts.devisepay)='ILS') 
    )
    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
    AND trunc(DATEMODIF) = TRUNC(SYSDATE-1)  --Report actions happened on previous day
    AND AUDIT_MVT.VERSION=1 ---Check New Booked trade
	;

   EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: BOI_ILS_TRANSACTION
-- *****************************************************************
   END BOI_ILS_TRANSACTION;



    -- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_MODIFICATION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 22 DEC 2016     Jeff Yu    Created (COM-293)
  -- 17 JAN 2017      Jeff Yu    Modified (COM-298)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_MODIFICATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOI_ILS_MODIFICATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR


    SELECT DISTINCT
                                histomvts.SICOVAM                                                          as  Instrument_id
                              , histomvts.refcon                                                               as  Transaction_id
                              , titres.libelle                                                                       as  Instrument_name
                              , BE.name                                                                            as  Business_event
                              , affectation.libelle                                                              as  Allotment
                              , btg_get_instrument_type(histomvts.sicovam)                 as  Instrument_Type
                              , DEVISE_TO_STR(histomvts.devisepay)                             as  Payment_currency
                              , DEVISE_TO_STR(devisectt)                                               as  Quotation_currency
                              , histomvts.dateneg                                                             as  d$Trade_date
                              , histomvts.dateval                                                              as  d$Value_date
                              , AM.Datemodify                                                                       as  d$Modification_date
                              , case when am.state = 2 then 'Modification' 
                                         when am.state = 3 then 'Cancelation' end                   as  Action_Status
                              , histomvts.quantite                                                            as   n$Quantity
                              , histomvts.QUANTITE * NVL(TITRES.nominal,1)                as  n$Nominal
                              , histomvts.cours                                                                 as  p$8$Price
                              , histomvts.montant                                                            as  n$Net_amount
                              , histomvts.tauxchange                                                       as  Exchange_rate

    FROM  histomvts
    INNER JOIN (
            SELECT      FOLIO.ident AS STRATEGY_ID
                             ,FOLIO.NAME AS STRATEGY_NAME
                             ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 2 
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_BTG_FUND,PCKG_BTG.FOLIO_BTG_WEALTH_MANAGEMENT) --12514,86931
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
     LEFT JOIN  TITRES
     ON TITRES.SICOVAM=histomvts.SICOVAM

     LEFT JOIN  BUSINESS_EVENTS BE
     ON BE.id=histomvts.type

     LEFT JOIN  AFFECTATION
     ON  AFFECTATION.ident=titres.affectation
     
      INNER JOIN      (
                        select 
                          REFCON
                        ,max(DATEMODIF)  as DATEMODIFY
                        ,max(STATE) as STATE
                        ,max(version)
                        from AUDIT_MVT 
                        where TRUNC(DATEMODIF) = TRUNC(sysdate-1) and STATE != 1
                        group by REFCON
                    ) AM
     ON AM.REFCON=histomvts.REFCON
     
     LEFT JOIN AUDIT_MVT  NB ---Get previous day new booked trade
     ON NB.REFCON=histomvts.REFCON
     and NB.version=1
     and trunc(NB.DATEMODIF) = trunc(sysdate-1)  
     
     WHERE  
    (
      (titres.type in ('X','E','K') and DEVISE_TO_STR(marche)='ILS') OR
      (DEVISE_TO_STR(devisectt)='ILS' or DEVISE_TO_STR(deviseac)='ILS' or DEVISE_TO_STR(deviseexer)='ILS' or DEVISE_TO_STR(histomvts.devisepay)='ILS') 
    )
    AND  NB.REFCON is null   ----Exclude new booked modifications
    ORDER BY histomvts.refcon
     ;

   EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

-- *****************************************************************
-- END OF: BOI_ILS_MODIFICATION
-- *****************************************************************
   END BOI_ILS_MODIFICATION;


 -- *****************************************************************
 -- Description:    MIFID2_RECON
 --                  
 --
 -- Author:         Andre Bresslau
 --
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 29 DEC 2017     Andre Bresslau    Created (COM-310)
 -- 09 JAN 2018     Andre Bresslau    Modified (COM-310)
 -- 10 JAN 2018     Andre Bresslau    Modified (COM-310)
 -- 21 MAY 2018     Luis Magalhaes    Modified (COM-317)
 -- 20 JUN 2018     Jeff Yu    Modified (PMGMRISK-228)
 -- *****************************************************************
 

PROCEDURE MIFID2_RECON
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: MIFID2_RECON
  -- *****************************************************************   
          OPEN p_CURSOR FOR

SELECT DISTINCT   
   TO_CHAR(AUDIT_MVT.datemodif,'DD-MON-YYYY') INSERTION_DATE  
  ,TO_CHAR(AUDIT_MVT.datemodif, 'HH24:MI:SS') INSERTION_TIME  
  ,TRADES.refcon TRADE_ID	
  ,CASE WHEN BLOCK_TRADE.block_id IS NULL THEN TRADES.refcon ELSE ABS(BLOCK_TRADE.block_id) END PARENT_ID
	,TRADE_STATUS.name TRADE_STATUS
	,FUND.name ENTITY
	,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(TRADES.opcvm), '[^/]+', 5, 6) AS TOP_LEVEL_STRATEGY
	,TRADER.name TRADER
	,TRADER.ident TRADER_ID
	,USER_INFO.country USER_COUNTRY	
	------BOOKING_METHOD
	,CASE WHEN TRADES.creation = 0 THEN 'Manual' WHEN TRADES.creation = 1 THEN 'Automatic' WHEN TRADES.creation = 2 THEN 'Electronic' ELSE 'Other' END BOOKING_METHOD	
	------BUSINESS_EVENT
	,BUSINESS_EVENTS.name BUSINESS_EVENT	
	------TRADE_DATE
	,TO_CHAR(TRADES.dateneg,'DD-MON-YYYY') TRADE_DATE	
	------TRADE_TIME
	,CASE WHEN TRADES.heureneg = 0 THEN '00:01:00' ELSE TO_CHAR(TRUNC(TRADES.heureneg / 3600), 'FM9900') || ':' || TO_CHAR(TRUNC(MOD(TRADES.heureneg, 3600) / 60), 'FM00') || ':' || TO_CHAR(MOD(TRADES.HEURENEG, 60), 'FM00') END TRADE_TIME	
	------Buy or Sell
	,CASE WHEN TRADES.quantite  < 0 THEN 'S' ELSE 'B' END B_S	
	------QUANTITY
	/*For Shares, Futures, Options, Warrant, CFDs, Rights >> return Quantity
Otherwise
     IF Nominal = 0 >> return Quantity
     Otherwise >> return Quantity x Nominal
*/
	,CASE WHEN INST.affectation IN (
				SELECT IDENT
				FROM AFFECTATION
				WHERE LIBELLE LIKE '%Share%' OR LIBELLE LIKE '%Future%' OR LIBELLE LIKE '%Option%' OR LIBELLE LIKE '%Warrant%' OR LIBELLE LIKE '%CFDs%' OR LIBELLE LIKE '%Rights%'
				) THEN ABS(TRADES.quantite) ELSE DECODE(INST.nominal, 0, ABS(TRADES.quantite), ABS(TRADES.quantite * INST.nominal)) END QUANTITY
		  
  ------PRICE	
  ,DECODE(MARKET.unitedecotation,2,0.01,3,0.001,1) * ROUND(TRADES.cours,8) GROSS_PRICE    
	------PRICE_CCY
	/*For CFDs, report the instrument underlying CCY*/
  ,CASE WHEN INST.type = 'G' THEN DEVISE_TO_STR(NVL(UNDERLYING1.devisectt, UNDERLYING1.deviseac)) ELSE DEVISE_TO_STR(NVL(INST.devisectt, INST.deviseac)) END PRICE_CCY
	,INST.libelle INST_NAME
	,INST.reference INST_REFERENCE
	,CASE WHEN DECODE(INST_UNIV_REF.model, 'Reference', 1, 0) = 1 AND LENGTH(INST.reference) = 12 THEN INST.reference WHEN DECODE(INST_UNIV_REF.model, 'Reference', 1, 0) = 0 AND LENGTH(ISIN.value) = 12 THEN ISIN.value WHEN DECODE(UND_UNIV_REF.model, 'Reference', 1, 0) = 1 AND LENGTH(ULTIMATE_UNDERLYING.reference) = 12 THEN ULTIMATE_UNDERLYING.reference WHEN DECODE(UND_UNIV_REF.model, 'Reference', 1, 0) = 0 AND LENGTH(UND_ISIN.value) = 12 THEN UND_ISIN.value ELSE '' END INST_ISIN
	,TRADES.sicovam SICOVAM
	,BTG_GET_INSTRUMENT_TYPE(TRADES.sicovam) INSTRUMENT_TYPE
	,ALLOTMENT.libelle ALLOTMENT
	,DEVISE_TO_STR(NVL(INST.devisectt, INST.deviseac)) INST_CCY	
	------CALL_PUT
	,CASE WHEN INST.type = 'D' AND INST.typepro = 1 THEN 'C' WHEN INST.type = 'D' AND INST.typepro = 2 THEN 'P' END CALL_PUT	
	------STRIKE
	,CASE WHEN INST.prixexer IS NOT NULL THEN TO_CHAR(ROUND(INST.prixexer, 8)) ELSE '' END STRIKE
	,CASE WHEN INST.type = 'F' AND INST.taux_var = 4 THEN 'Cash' --For futures
		WHEN INST.type = 'F' AND INST.taux_var = 1 THEN 'Physical' --For futures
		WHEN INST.type = 'D' AND INST.typesj = 0 THEN 'Physical' --For options
		WHEN INST.type = 'D' AND INST.typesj = 1 THEN 'New Share' --For options
		WHEN INST.type = 'D' AND INST.typesj = 2 THEN 'Market Delivery' --For options
		WHEN INST.type = 'D' AND INST.typesj = 3 THEN 'Cash' --For options
		WHEN INST.type = 'D' AND INST.typesj = 4 THEN 'Cash and Application' --For options
		WHEN INST.type = 'D' AND INST.typesj = 5 THEN 'Currency' --For options
		WHEN INST.type = 'D' AND INST.typesj = 6 THEN 'Future' --For options
		WHEN INST.type = 'G' AND UNDERLYING1.taux_var = 4 THEN 'Cash' --For CFD
		WHEN INST.type = 'G' AND UNDERLYING1.taux_var = 1 THEN 'Physical' --For CFD
		ELSE '' END DELIVERY_TYPE
	,CASE WHEN INST.type = 'D' AND (INST.typepro = 1 OR INST.typepro = 2) AND INST.debutper = '01-Jan-1904' THEN 'American' WHEN INST.type = 'D' AND (INST.typepro = 1 OR INST.typepro = 2) THEN 'European' ELSE '' END OPTION_STYLE	
	------MATURITY_DATE
	/*
If ISIN of the instrument is 12 characters long >> report blank      
Otherwise >> report Maturity / Exercise / Delivery date
*/
	--Maturity / Exercise / Delivery date
	,CASE WHEN DECODE(INST_UNIV_REF.model, 'Reference', 1, 0) = 1 AND LENGTH(INST.reference) = 12 THEN '' WHEN DECODE(INST_UNIV_REF.model, 'Reference', 1, 0) = 0 AND LENGTH(ISIN.value) = 12 THEN '' WHEN INST.type = 'S' -- S = Swap
			THEN TO_CHAR(INST.datefinal, 'YYYY-MM-DD') WHEN INST.type IN ('O', 'D', 'L') -- O = Bond, D = Derivative, L = Repo
			THEN TO_CHAR(INST.finper, 'YYYY-MM-DD') WHEN INST.type IN ('M', 'F', 'N') -- M = Option on listed market, F = Future, N = Package
			THEN TO_CHAR(INST.echeance, 'YYYY-MM-DD') WHEN INST.type = 'K' -- K = Non Delivarable Forward Forex
			THEN TO_CHAR(TRADES.dateval, 'YYYY-MM-DD') ELSE '' END MATURITY_DATE	
	------IS_OTC
	,CASE WHEN OTC_DERIVATIVE.output_code = 'Y' OR (OTC_DERIVATIVE.output_code = 'U' AND UPPER(DEPOSITARY.reference) LIKE '%OTC%') THEN 'Y' ELSE 'N' END IS_OTC
	,DEPOSITARY.name DEPOSITARY
	,UNDERLYING1.reference UND_INST_REFERENCE
	,CASE WHEN UNDERLYING1.type = 'H' AND INST.affectation != 1102 -- H = Issuer | INST.affectation 1102 = TRS(Fully Funded)
			THEN '' WHEN UNDERLYING1.type = 'H' AND INST.affectation = 1102 -- H = Issuer | INST.affectation 1102 = TRS(Fully Funded)
			THEN ISIN.value WHEN OTC_DERIVATIVE.output_code = 'Y' OR (OTC_DERIVATIVE.output_code = 'U' AND UPPER(DEPOSITARY.reference) LIKE '%OTC%') THEN (CASE WHEN DECODE(UND_UNIV_REF.model, 'Reference', 1, 0) = 1 AND LENGTH(ULTIMATE_UNDERLYING.reference) = 12 THEN ULTIMATE_UNDERLYING.reference WHEN DECODE(UND_UNIV_REF.model, 'Reference', 1, 0) = 0 AND LENGTH(UND_ISIN.value) = 12 THEN UND_ISIN.value WHEN DECODE(UND_UNIV_REF.model, 'Reference', 1, 0) = 0 AND (LENGTH(UND_ISIN.value) = 0 OR UND_ISIN.value IS NULL) THEN '' ELSE '' END) ELSE '' END UNDERLYING_INSTRUMENT_ISIN
	,UNDERLYING1.sicovam UND_SICOVAM	
	------COUNTERPARTY
	,CASE WHEN TRADES.type IN (
				SELECT ID
				FROM BUSINESS_EVENTS
				WHERE NAME LIKE '%Assignment%'
				) THEN CPTY2.name ELSE CPTY.name END COUNTERPARTY	
	------COUNTERPARTY_LEI
	,CASE WHEN TRADES.type IN (
				SELECT ID
				FROM BUSINESS_EVENTS
				WHERE NAME LIKE '%Assignment%'
				) THEN CPTY2.lei ELSE CASE WHEN BRKR.ident = 10012815 THEN 'INTERNAL' ELSE CPTY.lei END END COUNTERPARTY_LEI	
	------COUNTERPARTY_IDENT
	,CASE WHEN TRADES.type IN (
				SELECT ID
				FROM BUSINESS_EVENTS
				WHERE NAME LIKE '%Assignment%'
				) THEN CPTY2.ident ELSE CPTY.ident END COUNTERPARTY_IDENT	
	------BROKER
	,BRKR.name BROKER
	------BROKER_LEI
	,BRKR.lei BROKER_LEI
	------BROKER_IDENT
	,BRKR.ident BROKER_IDENT

	------BROKER_GROUP
	,BRKRGROUP.name BROKER_GROUP
	------MARKET_NAME
	,CASE WHEN INST.type = 'F' THEN LISTED_MARKET.NOM --LISTED MARKET NAME
		ELSE MARKET.libelle END MARKET_NAME	
	------MARKET_MIC_CODE
	,CASE WHEN INST.type = 'F' THEN LISTED_MARKET_MIC_CODE.output_code --LISTED MARKET NAME
		ELSE MARKET_MIC_CODE.value END MARKET_MIC_CODE	
	------MARKET_ESMA
	,NVL(MARKET_ESMA.value, MAP_ESMA.output_code) MARKET_ESMA
--For listed instruments, returns the Currency > Market > 'ESMA Regulated (Y/N)' defined only on the database, not available in Sophis
--For Futures, returns the Market > 'ESMA Regulated (Y/N)' defined only on the database, not available in Sophis
FROM histomvts TRADES
------
------BUSINESS_EVENTS
INNER JOIN BUSINESS_EVENTS ON BUSINESS_EVENTS.id = TRADES.type AND BUSINESS_EVENTS.compta = 1 -- Select trades with BUSINESS EVENT affecting position only
	------
------TRADE_STATUS
LEFT JOIN bo_kernel_status TRADE_STATUS ON TRADE_STATUS.id = TRADES.backoffice
------
------INSTRUMENT
LEFT JOIN titres INST ON INST.sicovam = TRADES.sicovam
------
------DEPOSITARY
LEFT JOIN tiers DEPOSITARY ON DEPOSITARY.ident = TRADES.depositaire
------
------FUND
LEFT JOIN tiers FUND ON FUND.ident = TRADES.entite
------
------ALLOTMENT
LEFT JOIN affectation ALLOTMENT ON ALLOTMENT.ident = INST.affectation
------
------AUDIT_MVT
LEFT JOIN AUDIT_MVT ON AUDIT_MVT.refcon = TRADES.refcon AND AUDIT_MVT.VERSION = 1
------
------1ST UNDERLYING INSTRUMENT
LEFT JOIN titres UNDERLYING1 ON UNDERLYING1.sicovam = CASE WHEN INST.type = 'A' THEN INST.base1 WHEN INST.type = 'D' THEN INST.codesj WHEN INST.type = 'B' THEN INST.taux_var WHEN INST.type = 'S' THEN DECODE(INST.jambe1, 1, INST.j2refcon2, DECODE(INST.j1refcon2, 0, INST.j2refcon2, INST.j1refcon2)) ELSE DECODE(INST.code_emet, 0, DECODE(INST.codesj, 0, INST.codesj2, INST.codesj), INST.code_emet) END
------
------2ND UNDERLYING INSTRUMENT
LEFT JOIN titres UNDERLYING2 ON UNDERLYING2.sicovam = CASE WHEN UNDERLYING1.type = 'A' THEN UNDERLYING1.base1 WHEN UNDERLYING1.type = 'D' THEN UNDERLYING1.codesj WHEN UNDERLYING1.type = 'B' THEN UNDERLYING1.taux_var WHEN UNDERLYING1.type = 'S' THEN DECODE(UNDERLYING1.jambe1, 1, UNDERLYING1.j2refcon2, DECODE(UNDERLYING1.j1refcon2, 0, UNDERLYING1.j2refcon2, UNDERLYING1.j1refcon2)) ELSE DECODE(UNDERLYING1.code_emet, 0, DECODE(UNDERLYING1.codesj, 0, UNDERLYING1.codesj2, UNDERLYING1.codesj), UNDERLYING1.code_emet) END
------
------ULTIMATE UNDERLYING
LEFT JOIN titres ULTIMATE_UNDERLYING ON ULTIMATE_UNDERLYING.sicovam = DECODE(UNDERLYING1.type, 'H', NULL, NULL, NULL, DECODE(UNDERLYING2.type, 'H', UNDERLYING1.sicovam, NULL, UNDERLYING1.sicovam, UNDERLYING2.sicovam))
------
------ULTIMATE UNDERLYING ISIN
LEFT JOIN extrnl_references_instruments UND_ISIN ON UND_ISIN.sophis_ident = ULTIMATE_UNDERLYING.sicovam AND UND_ISIN.ref_ident = 1 -- 1 = ISIN defined on EXTRNL_REFERENCES_DEFINITION
	------
------ULTIMATE UNDERLYING UNIVERSAL_REFERENCE
LEFT JOIN REFERENCES UND_UNIV_REF ON UND_UNIV_REF.allotment = ULTIMATE_UNDERLYING.affectation AND UND_UNIV_REF.reference = 'ISIN'
------
------INSTRUMENT UNIVERSAL REFERENCE  
LEFT JOIN REFERENCES INST_UNIV_REF ON INST_UNIV_REF.allotment = INST.affectation AND INST_UNIV_REF.reference = 'ISIN'
------
------MARKET
LEFT JOIN marche MARKET ON MARKET.codedevise = DECODE(INST.affectation,12,UNDERLYING1.devisectt,INST.devisectt) AND MARKET.mnemomarche = DECODE(INST.affectation,12,UNDERLYING1.marche,INST.marche)
------
------LISTED_MARKET
LEFT JOIN marcheorganise LISTED_MARKET ON LISTED_MARKET.ident = INST.marche
------
------TRADER
LEFT JOIN riskusers TRADER ON TRADER.ident = TRADES.operateur
------
------USER_INFO
INNER JOIN userinfos USER_INFO ON USER_INFO.ident = TRADES.operateur
------
------EXTERNAL REFERENCES > ISIN  
LEFT JOIN extrnl_references_instruments ISIN ON ISIN.sophis_ident = INST.sicovam AND ISIN.ref_ident = 1 -- 1 = ISIN defined on EXTRNL_REFERENCES_DEFINITION
	------
------EXTERNAL REFERENCES > INST_RED_ID  
LEFT JOIN extrnl_references_instruments INST_RED_ID ON INST_RED_ID.sophis_ident = INST.sicovam AND INST_RED_ID.ref_ident = 16 -- 16 = MarkIT RED ID defined on EXTRNL_REFERENCES_DEFINITION
	------
------EXTERNAL REFERENCES > UND_RED_ID  
LEFT JOIN extrnl_references_instruments UND_RED_ID ON UND_RED_ID.sophis_ident = INST.coupon1 AND UND_RED_ID.ref_ident = 16 -- 16 = MarkIT RED ID defined on EXTRNL_REFERENCES_DEFINITION
	------
------EXTERNAL REFERENCES > CDS_UND_ISIN  
LEFT JOIN extrnl_references_instruments CDS_UND_ISIN ON CDS_UND_ISIN.sophis_ident = INST.coupon1 AND CDS_UND_ISIN.ref_ident = 1 -- 1 = ISIN defined on EXTRNL_REFERENCES_DEFINITION
	------
------EXTERNAL REFERENCES > EXCH_PRODUCT_CODE
LEFT JOIN extrnl_references_instruments EXCH_PRODUCT_CODE ON EXCH_PRODUCT_CODE.sophis_ident = INST.sicovam AND EXCH_PRODUCT_CODE.ref_ident = 25 -- 25 = EXCH_PRODUCT_CODE defined on EXTRNL_REFERENCES_DEFINITION
	------
------EXTERNAL REFERENCES > MARKET_MIC_CODE
LEFT JOIN extrnl_ref_market_value MARKET_MIC_CODE ON MARKET_MIC_CODE.market = INST.marche -- INST.marche is related to MARCHE and MARCHEORGANISE
	AND MARKET_MIC_CODE.currency = NVL(INST.devisectt, INST.deviseac) AND MARKET_MIC_CODE.ref_ident = 7 -- 7 = MIC CODE defined on EXTRNL_REF_MARKET_DEFINITION
------BTG_MAPPING > LISTED_MARKET_MIC_CODE
LEFT JOIN btg_mapping_code LISTED_MARKET_MIC_CODE ON LISTED_MARKET_MIC_CODE.input_code = INST.marche -- INST.marche is related to MARCHE and MARCHEORGANISE
	AND LISTED_MARKET_MIC_CODE.source_id = 3 -- 3 = Generic defined on BTG_MAPPING_SOURCE
	AND LISTED_MARKET_MIC_CODE.type_id = 23 -- 23 = MIC Code defined on BTG_MAPPING_TYPE
	------
------------Relates to the Instrument
------INST_ESMA
------Instrument > External Reference > ESMA flag
LEFT JOIN extrnl_references_instruments INST_ESMA ON INST_ESMA.sophis_ident = INST.sicovam AND INST_ESMA.ref_ident = 26 -- 26 = 'ESMA Regulated (Y/N)' defined on EXTRNL_REFERENCES_DEFINITION
	------
------MARKET_ESMA
------Instrument > CCY > Market > ESMA flag (DB only)
LEFT JOIN extrnl_ref_market_value MARKET_ESMA ON MARKET_ESMA.market = INST.marche -- INST.marche is related to MARCHE and MARCHEORGANISE
	AND MARKET_ESMA.currency = INST.devisectt AND MARKET_ESMA.ref_ident = 8 -- 8 = 'ESMA Regulated (Y/N)' defined on EXTRNL_REF_MARKET_DEFINITION		
	------    
------FUT_MARKET_ESMA
LEFT JOIN BTG_mapping_code MAP_ESMA ON MAP_ESMA.input_code = INST.marche -- INST.marche is related to MARCHE and MARCHEORGANISE
	AND MAP_ESMA.source_id = 3 -- 3 = 'Generic' defined on BTG_MAPPING_SOURCE
	AND MAP_ESMA.type_id = 25 -- 25 = 'ESMA Regulated (Y/N)' defined on BTG_MAPPING_TYPE
	------------
------------Relates to the 1st Underlying Instrument
------UND_INST_EMSA
--Same logic as Column A but for the 1st Underlying of the Instrument
LEFT JOIN extrnl_references_instruments UND_ESMA ON UND_ESMA.sophis_ident = UNDERLYING1.sicovam AND UND_ESMA.ref_ident = 26
------
------UND_MARKET_ESMA
--Same logic as Column B but for the 1st Underlying of the Instrument
LEFT JOIN extrnl_ref_market_value UND_MARKET_ESMA ON UND_MARKET_ESMA.market = UNDERLYING1.marche AND UND_MARKET_ESMA.currency = UNDERLYING1.devisectt AND UND_MARKET_ESMA.ref_ident = 8 -- 8 = 'ESMA Regulated (Y/N)' defined on EXTRNL_REF_MARKET_DEFINITION		
	------
------UND_FUT_MARKET_ESMA
--Same logic as Column C but for the 1st Underlying of the Instrument
LEFT JOIN btg_mapping_code UND_MAP_ESMA ON UND_MAP_ESMA.input_code = UNDERLYING1.marche AND UND_MAP_ESMA.source_id = 3 -- 3 = 'Generic' defined on BTG_MAPPING_SOURCE
	AND UND_MAP_ESMA.type_id = 25 -- 25 = 'ESMA Regulated (Y/N)' defined on BTG_MAPPING_TYPE
	------------
------------Relates to the 2nd Underlying Instrument
------UND2_INST_EMSA
--Same logic as Column A but for the 2nd Underlying of the Instrument
LEFT JOIN extrnl_references_instruments UND2_ESMA ON UND2_ESMA.sophis_ident = UNDERLYING2.sicovam AND UND2_ESMA.ref_ident = 26
------
------UND2_MARKET_ESMA
--Same logic as Column B but for the 2nd Underlying of the Instrument
LEFT JOIN extrnl_ref_market_value UND2_MARKET_ESMA ON UND2_MARKET_ESMA.market = UNDERLYING2.marche AND UND2_MARKET_ESMA.currency = UNDERLYING2.devisectt AND UND2_MARKET_ESMA.ref_ident = 8 -- 8 = 'ESMA Regulated (Y/N)' defined on EXTRNL_REF_MARKET_DEFINITION	
	------
------UND2_FUT_MARKET_ESMA
--Same logic as Column C but for the 2nd Underlying of the Instrument
LEFT JOIN btg_mapping_code UND2_MAP_ESMA ON UND2_MAP_ESMA.input_code = UNDERLYING2.marche AND UND2_MAP_ESMA.source_id = 3 -- 3 = 'Generic' defined on BTG_MAPPING_SOURCE
	AND UND2_MAP_ESMA.type_id = 25 -- 25 = 'ESMA Regulated (Y/N)' defined on BTG_MAPPING_TYPE
	------------
------INSTRUMENT_TYPE
LEFT JOIN btg_mapping_code INSTRUMENT_TYPE_MAP ON INSTRUMENT_TYPE_MAP.input_code = DECODE(UNDERLYING1.type, 'H', INST.affectation, -- H = Issuer
		NULL, INST.affectation, DECODE(UNDERLYING2.type, 'H', UNDERLYING1.affectation, NULL, UNDERLYING1.affectation, UNDERLYING2.affectation)) AND INSTRUMENT_TYPE_MAP.source_id = 6 -- 6 = 'UnaVista' defined on BTG_MAPPING_SOURCE
	AND INSTRUMENT_TYPE_MAP.type_id = 24 -- 24 = 'Instrument Type Code' defined on BTG_MAPPING_TYPE
	------------
------DERIVATIVE_TYPE
LEFT JOIN btg_mapping_code DERIVATIVE_TYPE_MAP ON DERIVATIVE_TYPE_MAP.input_code = INST.affectation AND DERIVATIVE_TYPE_MAP.source_id = 6 -- 6 = 'UnaVista' defined on BTG_MAPPING_SOURCE
	AND DERIVATIVE_TYPE_MAP.type_id = 24 -- 24 = 'Instrument Type Code' defined on BTG_MAPPING_TYPE
------DERIVATIVE_TYPE_MAP_UNDERLYING
LEFT JOIN btg_mapping_code DERIVATIVE_TYPE_MAP_UNDERLYING ON DERIVATIVE_TYPE_MAP_UNDERLYING.input_code = ULTIMATE_UNDERLYING.affectation AND DERIVATIVE_TYPE_MAP_UNDERLYING.source_id = 6 -- 6 = 'UnaVista' defined on BTG_MAPPING_SOURCE
	AND DERIVATIVE_TYPE_MAP_UNDERLYING.type_id = 24 -- 24 = 'Instrument Type Code' defined on BTG_MAPPING_TYPE
------COUNTERPARTY IDENTIERS------
LEFT JOIN tiersgeneral CPTY2_BIC_CODE ON CPTY2_BIC_CODE.code = TRADES.contrepartie2
LEFT JOIN tiersgeneral BRKR_BIC_CODE ON BRKR_BIC_CODE.code = TRADES.courtier
LEFT JOIN tiersproperties BRKR_FRN ON BRKR_FRN.code = TRADES.courtier AND BRKR_FRN.name = 'FRN CODE'
LEFT JOIN tiersproperties CPTY2_FRN ON CPTY2_FRN.code = TRADES.contrepartie2 AND CPTY2_FRN.name = 'FRN CODE'
LEFT JOIN tiersproperties BRKR_MIFID ON BRKR_MIFID.code = TRADES.courtier AND BRKR_MIFID.name = 'MiFID (Y/N)'
LEFT JOIN tiersproperties CPTY2_MIFID ON CPTY2_MIFID.code = TRADES.contrepartie2 AND CPTY2_MIFID.name = 'MiFID (Y/N)'
LEFT JOIN tiers CPTY ON CPTY.ident = TRADES.contrepartie
LEFT JOIN tiers CPTY2 ON CPTY2.ident = TRADES.contrepartie2
LEFT JOIN tiers BRKR ON BRKR.ident = TRADES.courtier
--AND BRKR.ident = '10012815' -- 10012815 = 'INTERNAL TRANSFER (FUND)'
LEFT JOIN tiers BRKRGROUP ON BRKRGROUP.ident = BRKR.mgr
LEFT JOIN tiers CPTYGROUP ON CPTYGROUP.ident = CPTY.mgr
LEFT JOIN tiers CPTY2GROUP ON CPTY2GROUP.ident = CPTY2.mgr
------END OF COUNTERPARTY IDENTIERS------
------OTC DERIVATIVE (Y/N/U)
LEFT JOIN btg_mapping_code OTC_DERIVATIVE ON OTC_DERIVATIVE.type_id = 75 -- 75 = 'Allotment OTC Derivatives' defined on BTG_MAPPING_TYPE
	AND OTC_DERIVATIVE.source_id = 6 -- 6 = 'UnaVista' defined on BTG_MAPPING_SOURCE
	AND OTC_DERIVATIVE.input_code = INST.affectation
------
LEFT JOIN TA_BLOCK_TO_GENERATED BLOCK_TRADE ON BLOCK_TRADE.generated_id = TRADES.refcon

LEFT JOIN TITRES ccypair 
    on ccypair.sicovam = case when INST.TYPE='K' or INST.AFFECTATION = 23 then INST.CODESJ else INST.sicovam end 
   

WHERE TRADES.backoffice NOT IN (
		SELECT KERNEL_STATUS_ID
		FROM BO_KERNEL_STATUS_COMPONENT
		WHERE KERNEL_STATUS_GROUP_ID = 68415
		) -- Exclude cancelled trades
	AND TRADES.type IN (1, 4, 17, 25, 99, 140, 160, 161, 190, 221, 240, 241, 242, 243, 247, 250, 274, 280, 344, 394, 444, 794, 796, 846,1394,1444,1494) -- Select only those Business Events
	AND TRADES.entite IN (
		SELECT IDENT
		FROM TIERS
		WHERE MGR = 10003502 AND IDENT != 10004083 AND IDENT != 10012566 AND IDENT != 10003582
		) -- MGR = 10003502 Fund Level / IDENT=10004083  Execution Book / IDENT=10003582 TESTFUND
	AND UPPER(USER_INFO.country) = 'UK' -- Select only UK users
	AND TRADER.ident != 12816 --Exclude Rafael Rocha (OPS)
    -- Filter trades Inserted from T-1 20:05 until T-0 20:05    
    AND (TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') >= TO_CHAR(BTG_BUSINESS_DATE(SYSDATE,-1),'YYYYMMDD') || ' 20:05:00' AND TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') < TO_CHAR(SYSDATE,'YYYYMMDD') || ' 20:05:00')
  
	AND 
    (
        (
        INST.type NOT IN ('E', 'X', 'K', 'C', 'L') -- Exclude FX Instruments, Cash, Repos	
        )
        OR
        (
            ( 
                ( 
                INST.type IN ('X','E') and BTG_BUSINESS_DATE_HOLIDAY_2CCY(trunc(TRADES.DATENEG),2,ccypair.DEVISECTT,ccypair.MARCHE) < trunc(TRADES.DATEVAL) --FX Forward 
                ) 
                or 
                TRADES.refcon in (select refcon from FOREX_SWAP where LINKEDREFCON != 0 union select LINKEDREFCON from FOREX_SWAP where LINKEDREFCON != 0) -- FX Swaps 
                or 
                INST.type = 'K' --NDF 
              )           
          AND (ISIN.VALUE IS NULL OR LENGTH(ISIN.VALUE) <> 12) 
        )
    )
ORDER BY 
    1 ASC,
    2 ASC, 
    TRADE_DATE ASC
;

   EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
-- *****************************************************************
-- END OF: MIFID2_RECON
-- *****************************************************************
   END MIFID2_RECON; 


     

    -- *****************************************************************
 -- Description:    Short_Sale_on_KRW
 --                  
 --
 -- Author:         Helen Zheng
 --
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 09 JAN 2018     Helen Zheng    Created (COM-312)
 -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
 -- *****************************************************************
 

PROCEDURE Short_Sale_on_KRW
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: Short_Sale_on_KRW
  -- *****************************************************************   
          OPEN p_CURSOR FOR

SELECT	
  Trades.refcon                                 Trade_Id
, business_events.name                          Business_Event
, FUND_BOOK_STRATEGY.Fund_NAME                  Fund_Name
, FUND_BOOK_STRATEGY.BOOK_NAME                  Strategy_Name  
, trader.name                                   Trader
, Trades.sicovam                                Sicovam
, TO_CHAR(Trades.dateneg,'YYYY-MM-DD')          Trade_Date
, TO_CHAR(Trades.dateval,'YYYY-MM-DD')    	    Settlement_Date
, trades.cours                                  Price
, instrument.reference                          Instrument_Reference
, instrument.libelle                            Instrument_Name
, allotment.libelle                             Instrument_Allotment
, Trades.quantite                               Quantity
, Broker.name                                   Broker
, Cpty.name                                     Counterparty
,devise_to_str(Instrument.devisectt) currency
  
from histomvts trades

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = trades.type

inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (14414,90565)--Primary funds and UCITS fund
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =trades.OPCVM 

inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 

inner join tiers broker     
ON          broker.ident = trades.courtier

inner join      tiers Cpty
on              cpty.ident = trades.contrepartie

inner join      riskusers trader
on              trader.ident = trades.operateur
inner join      affectation allotment
on              instrument.affectation = allotment.ident
where business_events.name='Short sale'
and trunc(trades.dateneg) = trunc(sysdate)-1
and devise_to_str(Instrument.devisectt)='KRW'   
and Trades.backoffice not in (11,13,17,26,27,192,220,248,252)
;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

   -- *****************************************************************
-- END OF: Short_Sale_on_KRW
-- *****************************************************************
   END Short_Sale_on_KRW; 


  -- *****************************************************************
 -- Description:    INCORRECT_SHORT_SALE
 
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 29 JAN 2018     Jeff Yu    Created (PMCMIFID2-62)
 -- 10 MAY 2018    Jeff Yu    Modified (PMOG-1235)
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
 -- *****************************************************************
PROCEDURE INCORRECT_SHORT_SALE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: INCORRECT_SHORT_SALE
  -- *****************************************************************   
          OPEN p_CURSOR FOR

select  TO_CHAR(AUDIT_MVT.datemodif,'DD-MON-YYYY') INSERTION_DATE  
,TO_CHAR(AUDIT_MVT.datemodif, 'HH24:MI:SS') INSERTION_TIME  
, STRATEGY.Fund_NAME
, trades.refcon  as trade_id
, titres.sicovam
, titres.reference
, BUSINESS_EVENTS.name as business_event
, trunc(trades.dateneg)  as trade_date
, trades.quantite
, tiers.name as depositary
, RISKUSERS.name as trader
, sum(tr2.quantite) as "T-1 Sum Qty"
,'Incorrect purchase/sale business event' as flag_situation

from 
HISTOMVTS trades

inner join titres
on titres.sicovam = trades.sicovam

inner join BUSINESS_EVENTS
on BUSINESS_EVENTS.ID = trades.type

inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (14414,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=trades.OPCVM

left join tiers
on tiers.ident=trades.DEPOSITAIRE

left join RISKUSERS
on RISKUSERS.ident=trades.OPERATEUR

left join USERINFOS
on USERINFOS.ident=trades.OPERATEUR

left join HISTOMVTS tr2
on trunc(tr2.dateneg) < trunc(trades.dateneg)
and trades.sicovam = tr2.sicovam
and trades.DEPOSITAIRE = tr2.DEPOSITAIRE
and tr2.type in (select id from BUSINESS_EVENTS where COMPTA = 1)
and tr2.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)

LEFT JOIN AUDIT_MVT 
ON AUDIT_MVT.refcon = TRADES.refcon 
AND AUDIT_MVT.VERSION = 1

where trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND (titres.type='A' or titres.affectation=25)  -----Shares and Gov Bonds
AND USERINFOS.country = 'UK'  ----only report UK trades
and trades.quantite < 0 ----sell direction
and trades.type = 1  -----Purchase/Sale BE
AND (TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') >= TO_CHAR(BTG_BUSINESS_DATE(SYSDATE,-1),'YYYYMMDD') || ' 20:05:00' 
     AND TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') < TO_CHAR(SYSDATE,'YYYYMMDD') || ' 20:05:00')  -- Filter trades Inserted from T-1 20:05 until T-0 20:05    
group by TO_CHAR(AUDIT_MVT.datemodif,'DD-MON-YYYY')
,TO_CHAR(AUDIT_MVT.datemodif, 'HH24:MI:SS')
, STRATEGY.Fund_NAME
, trades.refcon
, titres.sicovam
, titres.reference
, BUSINESS_EVENTS.name
, trunc(trades.dateneg)
, trades.quantite
, tiers.name 
, RISKUSERS.name 
having sum(tr2.quantite) <= 0 -----T1 position has negetive sum Qty

UNION

select  TO_CHAR(AUDIT_MVT.datemodif,'DD-MON-YYYY') INSERTION_DATE  
,TO_CHAR(AUDIT_MVT.datemodif, 'HH24:MI:SS') INSERTION_TIME  
, STRATEGY.Fund_NAME
, trades.refcon  as trade_id
, titres.sicovam
, titres.reference
, BUSINESS_EVENTS.name as business_event
, trunc(trades.dateneg)  as trade_date
, trades.quantite
, tiers.name as depositary
, RISKUSERS.name as trader
, sum(tr2.quantite) as "T-1 Sum Qty"
,'Incorrect short/sell business event' as flag_situation

from 
HISTOMVTS trades

inner join titres
on titres.sicovam = trades.sicovam

inner join BUSINESS_EVENTS
on BUSINESS_EVENTS.ID = trades.type

inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (14414,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=trades.OPCVM

left join tiers
on tiers.ident=trades.DEPOSITAIRE

left join RISKUSERS
on RISKUSERS.ident=trades.OPERATEUR

left join USERINFOS
on USERINFOS.ident=trades.OPERATEUR

left join HISTOMVTS tr2
on trunc(tr2.dateneg) < trunc(trades.dateneg)
and trades.sicovam = tr2.sicovam
and trades.DEPOSITAIRE = tr2.DEPOSITAIRE
and tr2.type in (select id from BUSINESS_EVENTS where COMPTA = 1)
and tr2.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)

LEFT JOIN AUDIT_MVT 
ON AUDIT_MVT.refcon = TRADES.refcon 
AND AUDIT_MVT.VERSION = 1

where trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND (titres.type='A' or titres.affectation=25)  -----Shares and Gov Bonds
AND USERINFOS.country = 'UK'  ----only report UK trades
and trades.quantite < 0 ----sell direction
and trades.type in  (140,1394)  -----short/sell and Delta hedge - short sale BE
AND (TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') >= TO_CHAR(BTG_BUSINESS_DATE(SYSDATE,-1),'YYYYMMDD') || ' 20:05:00' 
      AND TO_CHAR(AUDIT_MVT.datemodif, 'YYYYMMDD HH24:MI:SS') < TO_CHAR(SYSDATE,'YYYYMMDD') || ' 20:05:00')  -- Filter trades Inserted from T-1 20:05 until T-0 20:05   

group by TO_CHAR(AUDIT_MVT.datemodif,'DD-MON-YYYY')
,TO_CHAR(AUDIT_MVT.datemodif, 'HH24:MI:SS')
, STRATEGY.Fund_NAME
, trades.refcon
, titres.sicovam
, titres.reference
, BUSINESS_EVENTS.name
, trunc(trades.dateneg)
, trades.quantite
, tiers.name 
, RISKUSERS.name 
having sum(tr2.quantite) > 0 -----T1 position has positive sum Qty
order by 1,5
;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

   -- *****************************************************************
-- END OF: INCORRECT_SHORT_SALE
-- *****************************************************************
   END INCORRECT_SHORT_SALE; 


 -- *****************************************************************
 -- Description:    FXFWD_MISS_ISIN
 
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
-- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
-- 19 JUN 2018				  PMCMIFID2-91	- Include Strategy column
-- 03 AUG 2018	   Gustavo Binnie PMOG-1253 - Include Top Level Ticket Id
 -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
 -- *****************************************************************
PROCEDURE FXFWD_MISS_ISIN
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: FXFWD_MISS_ISIN
  -- *****************************************************************   
          OPEN p_CURSOR FOR

SELECT DISTINCT 

                     ccyForward.sicovam 
                   , ccyForward.reference 
                   , ccyForward.libelle Instrument_Name
                   , NVL(BLCK.BLOCK_ID,HISTOMVTS.REFCON) Top_Level_Ticket_ID
				   , FUND_BOOK_STRATEGY.BOOK_NAME Strategy
   
        FROM histomvts 
        INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                              , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME 
                              , FOLIO.ident AS STRATEGY_ID 
                              , FOLIO.name AS STRATEGY_NAME 
                              , level 
                      FROM FOLIO 
                      WHERE LEVEL >= 2 
                      START WITH FOLIO.ident IN (14414,90565) 
  
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
                 ) FUND_BOOK_STRATEGY 
        ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.opcvm 
      INNER JOIN titres security 
        ON security.sicovam = histomvts.sicovam 
      LEFT JOIN TITRES ccypair 
        on ccypair.sicovam = case when security.TYPE='K' or security.AFFECTATION = 23 then security.CODESJ else security.sicovam end
	  LEFT JOIN TA_BLOCK_TO_GENERATED BLCK
	    ON   BLCK.GENERATED_ID = histomvts.REFCON
           
      LEFT JOIN TITRES ccyForward 
        on security.sicovam = case when security.TYPE='K' then ccyForward.sicovam else ccyForward.codesj end 
        and histomvts.dateval = case when security.TYPE='K' then histomvts.dateval else ccyForward.echeance end 
        and ccyForward.type = case when security.TYPE='K' then 'K' else 'X' end 
      LEFT JOIN RISKUSERS 
        on RISKUSERS.ident = histomvts.OPERATEUR 
      INNER JOIN USERINFOS 
        on USERINFOS.ident = histomvts.OPERATEUR 
        and USERINFOS.country = 'UK' 
         
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISIN 
      ON ISIN.REF_IDENT = 1 
      AND ISIN.SOPHIS_IDENT = ccyForward.SICOVAM 
               
      WHERE 
            histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
      AND ( 
            ( 
              security.type IN ('X','E') and BTG_BUSINESS_DATE_HOLIDAY_2CCY(trunc(histomvts.DATENEG),2,ccypair.DEVISECTT,ccypair.MARCHE) < trunc(histomvts.DATEVAL) --FX Forward 
            ) 
            or 
            histomvts.refcon in (select refcon from FOREX_SWAP where LINKEDREFCON != 0 union select LINKEDREFCON from FOREX_SWAP where LINKEDREFCON != 0) -- FX Swaps 
            or 
            security.type = 'K' --NDF 
          ) 
      AND histomvts.dateneg > (sysdate - 7) 
      AND (ISIN.VALUE IS NULL OR LENGTH(ISIN.VALUE) <> 12) 
      order by 1,4; 

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

   -- *****************************************************************
-- END OF: FXFWD_MISS_ISIN
-- *****************************************************************
   END FXFWD_MISS_ISIN; 


-- *****************************************************************
 -- Description:    FXSPOT_WITH_ISIN
 
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
-- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
 -- *****************************************************************
PROCEDURE FXSPOT_WITH_ISIN
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: FXSPOT_WITH_ISIN
  -- *****************************************************************   
          OPEN p_CURSOR FOR

SELECT DISTINCT 

                     FX_SPOT.sicovam 
                   , FX_SPOT.reference 
                   , FX_SPOT.libelle Instrument_Name 
                   , ISIN.VALUE AS ISIN 
   
        FROM TITRES FX_SPOT 
       
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISIN 
      ON ISIN.REF_IDENT = 1 
      AND ISIN.SOPHIS_IDENT = FX_SPOT.SICOVAM 
               
      WHERE 
            FX_SPOT.TYPE = 'E' 
        AND (ISIN.VALUE IS NOT NULL) 
      order by 1; 

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

   -- *****************************************************************
-- END OF: FXSPOT_WITH_ISIN
-- *****************************************************************
   END FXSPOT_WITH_ISIN; 


-- *****************************************************************
 -- Description:    FXOPTION_MISS_ISIN
 
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
-- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
-- 19 JUN 2018				  PMCMIFID2-91	- Include Strategy column
 -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
 -- *****************************************************************
PROCEDURE FXOPTION_MISS_ISIN
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: FXOPTION_MISS_ISIN
  -- *****************************************************************   
          OPEN p_CURSOR FOR

SELECT DISTINCT 

                     security.sicovam 
                   , security.reference 
                   , security.libelle Instrument_Name 
				   , FUND_BOOK_STRATEGY.BOOK_NAME Strategy
   
        FROM   histomvts 
        INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                              , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID 
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME 
                              , FOLIO.ident AS STRATEGY_ID 
                              , FOLIO.name AS STRATEGY_NAME 
                              , level 
                      FROM FOLIO 
                      WHERE LEVEL >= 2 
                      START WITH FOLIO.ident IN (14414,90565) 
  
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
                 ) FUND_BOOK_STRATEGY 
        ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.opcvm 
      INNER JOIN titres security 
        ON security.sicovam = histomvts.sicovam 
      LEFT JOIN RISKUSERS 
        on RISKUSERS.ident = histomvts.OPERATEUR 
      INNER JOIN USERINFOS 
        on USERINFOS.ident = histomvts.OPERATEUR 
        and USERINFOS.country = 'UK' 
         
      LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISIN 
      ON ISIN.REF_IDENT = 1 
      AND ISIN.SOPHIS_IDENT = security.SICOVAM 
               
      WHERE  histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
      AND security.affectation=23
      AND histomvts.dateneg > (sysdate - 7) 
      AND (ISIN.VALUE IS NULL OR LENGTH(ISIN.VALUE) <> 12) 
      order by 1; 

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

   -- *****************************************************************
-- END OF: FXOPTION_MISS_ISIN
-- *****************************************************************
   END FXOPTION_MISS_ISIN; 

-- *****************************************************************
-- Description:    PRETC_INST_MISS_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 30 MAY 2018     Andre Bresslau     Created (COM-318)
-- *****************************************************************  
PROCEDURE PRETC_INST_MISS_UCITS_ELIGIBLE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PRETC_INST_MISS_UCITS_ELIGIBLE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
	SELECT 
	INSTRUMENTS.SICOVAM
	,INSTRUMENTS.REFERENCE
	,INSTRUMENTS.NAME
	,INSTRUMENTS.ALLOTMENT
	,INSTRUMENTS.CCY
	,BTG_FN_AUDIT_INST_USER(INSTRUMENTS.SICOVAM) INSTR_LAST_AMENDED_BY
	,H.REFCON LATEST_TRADE_ID
	,T3.NAME DEPOSITARY
	,R.NAME TRADER	
	,INSTRUMENTS.INDEX_TYPE

	FROM (
	SELECT 
	 T.SICOVAM
	,T.REFERENCE
	,T.LIBELLE NAME
	,A.LIBELLE ALLOTMENT
	,DEVISE_TO_STR(T.DEVISECTT) CCY
	,CASE
		WHEN T.NBTITRES = 65536 THEN 'Composed'
		WHEN T.NBTITRES = 131072 THEN 'Basket'
		WHEN T.NBTITRES = 196608 THEN 'Capitalised'
	 END INDEX_TYPE
	FROM TITRES T
	INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T.SICOVAM
	AND SIA.TYPE = 688149 --UCITS_ELIGIBLE
	WHERE SIA.SECTOR IS NULL
	AND T.TYPE NOT IN ('C','E','K','X','H','R') --Exclude Commission, FX, Issuers, Repos     
	AND (     
	A.LIBELLE IN (                                                                           
					'Indexes',
					'Internal Funds',                    
					'Listed Warrants',
					'Rights Issues',
					'Shares',
					'Shares - ADR and GDR',
					'Shares - ETF',
					'Shares - Delisted',
					'Shares - Liquidated',
					'Shares - MLP',
					'Shares - Preferred',
					'Shares - REIT',
					'Shares - Suspended',
					'Shares - Ticker Change',
					'Shares - Unlisted'                                           
					  )        
	-- Exclude expired instruments
	OR (A.LIBELLE IN ('Dividend Future','Futures','Volatility Futures') AND T.ECHEANCE >= SYSDATE)    
	OR (A.LIBELLE = 'CDS' AND T.DATEFINAL >= SYSDATE)
	OR (A.LIBELLE = 'Gov Bonds' AND T.FINPER >= SYSDATE)
	OR (A.LIBELLE = 'Corp Bonds' AND T.FINPER >= SYSDATE)    
	)

	) INSTRUMENTS

	LEFT JOIN HISTOMVTS H ON H.SICOVAM = INSTRUMENTS.SICOVAM
	AND H.REFCON IN (
	SELECT MAX(H2.REFCON)
	FROM HISTOMVTS H2
	LEFT JOIN BUSINESS_EVENTS BE ON BE.ID = H2.TYPE
	  AND BE.COMPTA = 1 -- ONLY TRADES THAT AFFECT POSITION
	WHERE H2.BACKOFFICE NOT IN ( SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415 ) -- EXCLUDE CANCELLED TRADES  
	  AND H2.SICOVAM = INSTRUMENTS.SICOVAM
	)
	LEFT JOIN TIERS T3 ON T3.IDENT = H.DEPOSITAIRE
	LEFT JOIN RISKUSERS R ON R.IDENT = H.OPERATEUR
	ORDER BY ALLOTMENT, CCY, REFERENCE,INSTR_LAST_AMENDED_BY;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

-- *****************************************************************
-- END OF: PRETC_INST_MISS_UCITS_ELIGIBLE
-- *****************************************************************
   END PRETC_INST_MISS_UCITS_ELIGIBLE; 

-----------------------------------------------------------------------------------------------------------------------------------------------------

-- *****************************************************************
-- Description:    PRETC_CHECK_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 04 JUN 2018     Andre Bresslau     Created (COM-319)
-- *****************************************************************  
PROCEDURE PRETC_CHECK_UCITS_ELIGIBLE
	(
    IN_ALLOTMENT  IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PRETC_CHECK_UCITS_ELIGIBLE
  -- *****************************************************************   
          OPEN OUT_CURSOR FOR
SELECT 
   INSTRUMENTS.SICOVAM
	,INSTRUMENTS.REFERENCE
	,INSTRUMENTS.NAME
  ,INSTRUMENTS.ALLOTMENT
	,INSTRUMENTS.CCY
  ,BTG_FN_AUDIT_INST_USER(INSTRUMENTS.SICOVAM) INSTR_LAST_AMENDED_BY
	,H.REFCON LATEST_TRADE_ID
	,T3.NAME DEPOSITARY
	,R.NAME TRADER	
  ,INSTRUMENTS.UCITS_ELIGIBLE
  
FROM (
	SELECT 
     T.SICOVAM
		,T.REFERENCE
		,T.LIBELLE NAME
    ,A.LIBELLE ALLOTMENT
    ,DEVISE_TO_STR(T.DEVISECTT) CCY
    ,CASE --688649=TRUE, 689149=FALSE
    WHEN SIA.SECTOR = 688649
      THEN 'TRUE'
    WHEN SIA.SECTOR = 689149
      THEN 'FALSE'
    ELSE ''
    END UCITS_ELIGIBLE
  FROM TITRES T
	INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SIA ON SIA.SICOVAM = T.SICOVAM
		AND SIA.TYPE = 688149 --UCITS_ELIGIBLE
	WHERE 
  CASE         
	  -- Exclude expired instruments
    WHEN (A.LIBELLE IN ('Dividend Future','Futures','Volatility Futures') AND T.ECHEANCE < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'CDS' AND T.DATEFINAL < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'Gov Bonds' AND T.FINPER < SYSDATE) THEN 0
    WHEN (A.LIBELLE = 'Corp Bonds' AND T.FINPER < SYSDATE) THEN 0
    WHEN (A.LIBELLE IN ('Dividend Options','Listed Options','Volatility Options') AND T.FINPER < SYSDATE) THEN 0
    -- 
    WHEN A.LIBELLE = IN_ALLOTMENT THEN 1 	
    ELSE 0
  END = 1
  ) INSTRUMENTS      

LEFT JOIN HISTOMVTS H ON H.SICOVAM = INSTRUMENTS.SICOVAM
	AND H.REFCON IN (
		SELECT MAX(H2.REFCON)
		FROM HISTOMVTS H2
		LEFT JOIN BUSINESS_EVENTS BE ON BE.ID = H2.TYPE
			AND BE.COMPTA = 1 -- ONLY TRADES THAT AFFECT POSITION
		WHERE H2.BACKOFFICE NOT IN ( SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415 ) -- EXCLUDE CANCELLED TRADES  
			AND H2.SICOVAM = INSTRUMENTS.SICOVAM
		)
LEFT JOIN TIERS T3 ON T3.IDENT = H.DEPOSITAIRE
LEFT JOIN RISKUSERS R ON R.IDENT = H.OPERATEUR
ORDER BY ALLOTMENT, CCY, REFERENCE,INSTR_LAST_AMENDED_BY;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

-- *****************************************************************
-- END OF: PRETC_CHECK_UCITS_ELIGIBLE
-- *****************************************************************
   END PRETC_CHECK_UCITS_ELIGIBLE; 

END PCKG_BTG_EMAILER_COMPLIANCE;