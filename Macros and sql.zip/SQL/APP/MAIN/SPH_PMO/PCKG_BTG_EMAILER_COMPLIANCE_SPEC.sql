create or replace PACKAGE            PCKG_BTG_EMAILER_COMPLIANCE
AS

	TYPE T_CURSOR IS REF CURSOR;


 -- *****************************************************************
 -- Description:    PROCEDURE COMPL_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 20 Jun 2014     Gustavo Binnie  Created (COM-112)
 -- 31 Jul 2015		Matt Kelly		Migrated to new package PCKG_BTG_EMAILER_COMPLIANCE_REPORTS
 -- *****************************************************************  

  PROCEDURE COMPL_RESTRICTED_LIST_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:    PROCEDURE TRADES_MISSING_ID_BB_COMPANY
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 04 Nov 2014     Gustavo Binnie  Created (COM-134)
 -- *****************************************************************  

  PROCEDURE TRADES_MISSING_ID_BB_COMPANY
	(
     p_CURSOR OUT T_CURSOR
	);	

-- *****************************************************************
-- Description: PROCEDURE RULE_105_RESTRICTED_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_RESTRICTED_TRADES
(
	p_CURSOR OUT T_CURSOR
);

-- *****************************************************************
-- Description: PROCEDURE RULE_105_WATCH_TRADES
-- Author:      Gustavo Binnie
--
-- Revision History
-- Date             Author        		Reason for Change
-- 12-Dec-2014      Gustavo Binnie      Creation
-- ---------------------------------------------------------------- 
 
PROCEDURE RULE_105_WATCH_TRADES
(
	p_CURSOR OUT T_CURSOR
);


-- *****************************************************************
-- Description:     PROCEDURE  GPI_WATCH_LIST
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 09 Jun 2015     Gustavo Binnie  Created.

-- *****************************************************************  

PROCEDURE GPI_WATCH_LIST
(
	p_CURSOR OUT T_CURSOR
);

 -- *****************************************************************
 -- Description:    PROCEDURE EQ_RESTRICTED_LISTS_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 24 Jun 2015     Gustavo Binnie  Created (COM-190)
 -- *****************************************************************  

  PROCEDURE EQ_RESTRICTED_LISTS_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);

	 -- *****************************************************************
 -- Description:    PROCEDURE TRADER_MISSING_ALLOC_RULE
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 03 Sep 2015     Gustavo Binnie  Created (COM-219)
 -- *****************************************************************  

  PROCEDURE TRADER_MISSING_ALLOC_RULE
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:    PROCEDURE REMIT_TRADING
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Nov 2015     Gustavo Binnie  Created (COM-238)
 -- *****************************************************************  

  PROCEDURE REMIT_TRADING
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_TRANSACTION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 27 DEC 2016     Jeff Yu   Created (COM-293)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_TRANSACTION
	(
		p_CURSOR OUT T_CURSOR
	);



	-- *****************************************************************
 -- Description:    PROCEDURE BOI_ILS_MODIFICATION
 --                  
 --
 -- Author:         Jeff Yu
 --
 -- Revision History
 -------------------
 -- Date            Author         	Reason for Change
 -- ----------------------------------------------------------------
 -- 27 DEC 2016     Jeff Yu  Created (COM-293)
 -- *****************************************************************  

  PROCEDURE BOI_ILS_MODIFICATION
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:    MIFID2_RECON
 --                  
 --
 -- Author:         Andre Bresslau
 --
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 29 DEC 2017     Andre Bresslau    Created (COM-310)
 -- *****************************************************************  

  PROCEDURE MIFID2_RECON
	(
		p_CURSOR OUT T_CURSOR
	);

	
 -- *****************************************************************
 -- Description:    Short_Sale_on_KRW 
 --                  
 --
 -- Author:         Helen Zheng
 --
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 09 JAN 2018     Helen Zheng    Created (COM-312)
 -- *****************************************************************  

  PROCEDURE Short_Sale_on_KRW 
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:    INCORRECT_SHORT_SALE 
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 29 JAN 2018     Jeff Yu    Created (PMCMIFID2-62)
 -- *****************************************************************  

  PROCEDURE INCORRECT_SHORT_SALE 
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:    FXFWD_MISS_ISIN
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
 -- *****************************************************************  

  PROCEDURE FXFWD_MISS_ISIN
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:    FXSPOT_WITH_ISIN
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
 -- *****************************************************************  

  PROCEDURE FXSPOT_WITH_ISIN
	(
		p_CURSOR OUT T_CURSOR
	);
	
-- *****************************************************************
 -- Description:    FXOPTION_MISS_ISIN_UK
 -- Revision History
 -------------------
 -- Date            Author         	  Reason for Change
 -- ----------------------------------------------------------------
 -- 10 MAY 2018     Jeff Yu    Created (PMCMIFID2-86)
 -- *****************************************************************  

  PROCEDURE FXOPTION_MISS_ISIN 
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:    PRETC_INST_MISS_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 30 MAY 2018     Andre Bresslau     Created (COM-318)
-- *****************************************************************  

  PROCEDURE PRETC_INST_MISS_UCITS_ELIGIBLE 
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:    PRETC_CHECK_UCITS_ELIGIBLE
-- Revision History
-------------------
-- Date            Author         	  Reason for Change
-- ----------------------------------------------------------------
-- 04 JUN 2018     Andre Bresslau     Created (COM-319)
-- *****************************************************************  

  PROCEDURE PRETC_CHECK_UCITS_ELIGIBLE 
	(
    IN_ALLOTMENT  IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
	);


END PCKG_BTG_EMAILER_COMPLIANCE;