create or replace
PACKAGE BODY            "PCKG_BTG_EMAILER_CRITICAL" 
AS



  
  -- *****************************************************************
  -- Description: PROCEDURE CASH_DIR_WRONG
	--/* checks that buy trades have us paying cash and vice versa*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE CASH_DIR_WRONG
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: CASH_DIR_WRONG 
 -- *****************************************************************
     OPEN p_CURSOR FOR

     SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, Instrument.libelle                    Name
						, Instrument.reference                  Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
     FROM       histomvts Trades
     INNER JOIN ( 
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH          FOLIO.ident   IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)-- IN (14414,90565)--Primary funds
                CONNECT BY PRIOR    FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =   Trades.OPCVM
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam          = Trades.sicovam
    INNER JOIN      riskusers trader
    ON              trader.ident                = Trades.operateur
    INNER JOIN      business_events
    ON              business_events.id          = Trades.type
    AND             (
                      ( Instrument.type in ('O','A') )
                      OR 
                      ( Instrument.type = 'D'  AND instrument.affectation = 9 )
                    )
    AND            ( 
                     (Trades.quantite < 0 AND Trades.montant >0) 
                      OR 
                     (Trades.quantite > 0 AND Trades.montant <0)
                    )
   AND              business_events.compta = 1 -- position affecting results
   AND              business_events.id    NOT IN (9, 244) --Conv bond exercise and ADR conversion events can have fees
   AND              Trades.backoffice     NOT IN (192,11,13,17,26,27,220,248,252)
   ORDER BY         1,2;

/* checks that buy trades have us paying cash and vice versa*/
 -- *****************************************************************
 -- END  OF: CASH_DIR_WRONG
 -- *****************************************************************
END CASH_DIR_WRONG;

  -- *****************************************************************
  -- Description: PROCEDURE UST_ACC_CHECK
	--/* checks that UST are booked to the 7 account and that non-UST are not*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --06 Jan 2014 Oliver South	Made depositaries select from mapping table
  -- *****************************************************************
  PROCEDURE UST_ACC_CHECK
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: UST_ACC_CHECK
 -- *****************************************************************
     OPEN p_CURSOR FOR

        SELECT         
              FUND_BOOK_STRATEGY.BOOK_NAME           Fund_Strategy
						, FUND_BOOK_STRATEGY.Fund_NAME           Fund
						, histomvts.dateneg                      d$TradeDate
						, histomvts.refcon                       TradeID
						, security.reference                     Name
						, pb.name                                Depositary
						, histomvts.quantite                     n$Quantity
						, histomvts.sicovam                      Sicovam 
            , affectation.libelle                    Allotment
      FROM          histomvts
      LEFT JOIN     tiers PB
      ON            pb.ident=histomvts.depositaire
      INNER JOIN ( 
                    SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                          ,  CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                          , FOLIO.ident                                                             AS STRATEGY_ID
                          , FOLIO.name                                                              AS STRATEGY_NAME
                          , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)-- IN (14414,90565)--Primary funds
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM
      INNER JOIN  titres security
      ON          security.sicovam                            = histomvts.sicovam
      AND         security.type                               = 'O' --Bonds
      AND         security.affectation                        IN ('25','1251') --Gov Bonds and Agency Bonds
      INNER JOIN  affectation
      ON          affectation.ident = security.affectation
      INNER JOIN  business_events
      ON          business_events.id                          = histomvts.TYPE
      AND         business_events.compta                      = 1 --position affecting trades only
      INNER JOIN  sector_instrument_association
      ON          sector_instrument_association.sicovam       = security.sicovam 
      AND         sector_instrument_association.sector        = 6290   --CNTRY_OF_DOMICILE = US
      WHERE       histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Not deleted trades
      AND         histomvts.depositaire NOT IN (
                                                SELECT btg_mapping_code.input_code 
                                                FROM btg_mapping_code 
                                                WHERE btg_mapping_code.type_id =47
                                                AND btg_mapping_code.source_id = 9
                                                )
      AND         histomvts.dateneg > sysdate - 5 --Recent Trades
      AND         FUND_BOOK_STRATEGY.BOOK_NAME != 'Treasury Offshore' --treasury team book in many depositaries for collateral purposes
UNION
  SELECT         
              FUND_BOOK_STRATEGY.BOOK_NAME           Fund_Strategy
						, FUND_BOOK_STRATEGY.Fund_NAME           Fund
						, histomvts.dateneg                      d$TradeDate
						, histomvts.refcon                       TradeID
						, security.reference                     Name
						, pb.name                                Depositary
						, histomvts.quantite                     n$Quantity
						, histomvts.sicovam                      Sicovam
            , affectation.libelle                    Allotment
      FROM          histomvts
      LEFT JOIN     tiers PB
      ON            pb.ident=histomvts.depositaire
      INNER JOIN ( 
                    SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                          ,  CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                          , FOLIO.ident                                                             AS STRATEGY_ID
                          , FOLIO.name                                                              AS STRATEGY_NAME
                          , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)-- IN (14414,90565)--Primary funds
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM
      INNER JOIN  titres security
      ON          security.sicovam                            = histomvts.sicovam
      AND         security.type                               = 'O' --Bonds
      INNER JOIN  affectation
      ON          affectation.ident = security.affectation
      INNER JOIN  business_events
      ON          business_events.id                          = histomvts.TYPE
      AND         business_events.compta                      = 1 --position affecting trades only
      LEFT JOIN   sector_instrument_association
      ON          sector_instrument_association.sicovam       = security.sicovam 
      AND         sector_instrument_association.TYPE = 5347
      WHERE       histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Not deleted trades
      AND         (
                    security.affectation                        NOT IN ('25','1251') --Gov Bonds and Agency Bonds
                    OR         
                    NVL(sector_instrument_association.sector,0)   <> 6290   --CNTRY_OF_DOMICILE = US
                  )
      AND         security.affectation NOT IN (34, 35,38,1252,1253,1353,1450) -- TBA, MBS - Agency, ABS, MBS - Non Agency, CMBS and MBS - European. These are allowed in some of these accounts
      AND         histomvts.depositaire IN (
                                                SELECT btg_mapping_code.input_code 
                                                FROM btg_mapping_code 
                                                WHERE btg_mapping_code.type_id =47
                                                AND btg_mapping_code.source_id = 9
                                            )
      AND         histomvts.dateneg > sysdate - 5 --Recent Trades
      AND         FUND_BOOK_STRATEGY.BOOK_NAME != 'Treasury Offshore' --treasury team book in many depositaries for collateral purposes
ORDER BY    1,2;

 /* checks that UST are booked to the 7 account and that non-UST are not*/
 -- *****************************************************************
 -- END  OF: UST_ACC_CHECK
 -- *****************************************************************
END UST_ACC_CHECK;


  -- *****************************************************************
  -- Description: PROCEDURE TRADES_NOT_IN_STRAT
	--/* Trades booked directly in Strategy folder rather than within the relevant strategy*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADES_NOT_IN_STRAT
  (
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: TRADES_NOT_IN_STRAT
 -- ***************************************************************** 
     OPEN p_CURSOR FOR
     
      SELECT          
						  FUND_BOOK_STRATEGY.FUND_NAME        Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME    Strategy_Name
						, Trades.sicovam                      Sicovam
						, Trades.refcon                       Trade_Id
						, trader.name                         Trader
						, Instrument.libelle                  Instrument_Name
						, Instrument.reference                Instrument_Reference
						, trunc(Trades.DATENEG)               d$Trade_Date
						, trunc(Trades.DATEVAL)               d$Value_Date
						, business_events.name                Busines_Event
      FROM            histomvts                           Trades 
      INNER JOIN      business_events
      ON              business_events.id                  = Trades.type
      INNER JOIN      riskusers trader
      ON              trader.ident                        = Trades.operateur
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                  = Trades.sicovam 
      INNER JOIN ( 
                      SELECT     CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                , FOLIO.ident                                                           AS STRATEGY_ID
                                , FOLIO.name                                                            AS STRATEGY_NAME
                                , level
                      FROM FOLIO
                      WHERE LEVEL     <= 3
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- in (14414,90565)--Primary funds
                      CONNECT BY PRIOR FOLIO.ident      = FOLIO.mgr  
                    ) FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID      = Trades.OPCVM 
      WHERE 
                    FUND_BOOK_STRATEGY.STRATEGY_NAME    != 'Fees'
      AND           FUND_BOOK_STRATEGY.STRATEGY_NAME    NOT LIKE'Cash _ S/R'
      AND           Trades.backoffice                   NOT IN (192,11,13,17,26,27,220,248,252)
      ORDER BY      1,2 ASC;

/* Trades booked directly in Strategy folder rather than within the relevant strategy*/
 -- *****************************************************************
 -- END  OF: TRADES_NOT_IN_STRAT
 -- ****************************************************************
END TRADES_NOT_IN_STRAT;

  -- *****************************************************************
  -- Description: PROCEDURE TRADEFUND_NOT_FOLIOFUND
	-- Report a trade that has the entity field different to the fund folder
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADEFUND_NOT_FOLIOFUND
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- BEGIN  OF: TRADEFUND_NOT_FOLIOFUND
 -- ****************************************************************
    OPEN p_CURSOR FOR
      SELECT      
						Strategy.name                     Strategy_Name
					, StrategyFund.name                   Strategy_Fund
					, TransactionFund.name                Transaction_Fund
					, Transactions.refcon                 Transaction_ID
					, Transactions.dateneg                Trade_Date
					, security.reference                  Ticker
					, security.libelle                    Name
					, trader.name                         Trader
					, business_events.name                BusinesEvent
					, bo_kernel_status.name               Status      
      FROM        histomvts                           Transactions      
      INNER JOIN  riskusers trader
      ON          trader.ident                     = Transactions.operateur      
      INNER JOIN  business_events
      ON          business_events.id               = Transactions.type      
      INNER JOIN  bo_kernel_status
      ON          bo_kernel_status.id              = Transactions.backoffice      
      INNER JOIN  titres security
      ON          security.sicovam                 = Transactions.sicovam      
      INNER JOIN  folio Strategy
      ON          Strategy.ident                   = Transactions.opcvm
      
      INNER JOIN  tiers StrategyFund
      ON          StrategyFund.ident               = Strategy.entite
      
      INNER JOIN  tiers TransactionFund
      ON          TransactionFund.ident            = Transactions.entite
      
   INNER JOIN ( 
            SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                  , FOLIO.ident                                                            AS STRATEGY_ID
                  , FOLIO.name                                                             AS STRATEGY_NAME
                  , level
            FROM  FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)  --IN (14414,90565)--Primary funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
          ) FUND_BOOK_STRATEGY
    ON      FUND_BOOK_STRATEGY.STRATEGY_ID      =   Transactions.OPCVM
    WHERE    TransactionFund.name               != StrategyFund.name
    AND      Transactions.backoffice            NOT IN (192,11,13,17,26,27,220,248,252)
    AND      StrategyFund.ident                 NOT IN (10003582,10012566)--- ignore testfund and EQ EXECUTION BOOK
	ORDER BY 1,2 ASC
  ;

  -- ***************************************************************************
  -- Report a trade that has the entity field different to the fund folder
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
-- *****************************************************************
 -- END  OF: TRADEFUND_NOT_FOLIOFUND
 -- ****************************************************************      
END TRADEFUND_NOT_FOLIOFUND; 


  -- *****************************************************************
  -- Description: PROCEDURE FXOPTION_EXERCISE_WITH_CASH
	-- All FX options that have been expired with cash when the fx trades should have been delivered
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013	Oliver South	Formatted SQL
  -- *****************************************************************
  PROCEDURE FXOPTION_EXERCISE_WITH_CASH
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: FXOPTION_EXERCISE_WITH_CASH
 -- ****************************************************************    
    OPEN p_CURSOR FOR
    SELECT 
					   h1.refcon     		         	TradeID
					  ,h1.sicovam           	  		SICOVAM
					  ,h1.dateneg						d$TradeDate
					  ,h1.dateval						d$ValueDate
					  ,PrimeBroker.NAME  				Account
					  ,Instrument.reference  			Reference
					  ,trader.name						Trader    
    FROM 
                    histomvts         h1    
    INNER JOIN      tiers             PrimeBroker     
    ON              PrimeBroker.IDENT         = h1.DEPOSITAIRE
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam        = h1.sicovam 
    INNER JOIN      riskusers trader
    ON              trader.ident              = h1.operateur
    
    WHERE 
    h1.montant                                !=0
    AND h1.type                               IN (9,360)
    AND Instrument.type                       = 'D'
    AND Instrument.codesj                     IN (SELECT r.sicovam
                                                   FROM titres r  
                                                  WHERE r.type = 'E')
    AND Instrument.marche                     = 0
    AND h1.dateneg                            > '31-Dec-2010';

  -- ***************************************************************************
  -- All FX options that have been expired with cash when the fx trades should have been delivered
  -- ***************************************************************************
   
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
 -- *****************************************************************
 -- END  OF: FXOPTION_EXERCISE_WITH_CASH
 -- ****************************************************************    
END FXOPTION_EXERCISE_WITH_CASH;




   -- *****************************************************************
  -- Description: PROCEDURE TRADE_DEAD_CCY
	-- GET CANCELED TRADES WHERE PAYMENT CURRENCY IS IN (GERMAN MARK, ITALIAN LIRA, FRENCH FRANC)
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADE_DEAD_CCY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADE_DEAD_CCY 
  -- ***************************************************************************
    OPEN p_CURSOR FOR
    
    SELECT              
                     FUND_BOOK_STRATEGY.BOOK_NAME                   Strategy_Name 
                   , FUND_BOOK_STRATEGY.Fund_NAME                   Fund_Name
                   , Trades.sicovam                                 Sicovam
                   , Trades.refcon                                  Trade_Id
                   , trader.name                                    Trader
                   , Instrument.libelle                             Instrument_Name
                   , Instrument.reference                           Instrument_Reference
                   , trunc(Trades.DATENEG)                          d$Trade_Date
                   , trunc(Trades.DATEVAL)                          d$Value_Date
                   , devise_to_str(Trades.devisepay)                Currency
                   , business_events.name                           BusinesEvent
    FROM                            
                    histomvts                        Trades 
    INNER JOIN      business_events
    ON              business_events.id              = Trades.type
    INNER JOIN      riskusers trader
    ON              trader.ident                    = Trades.operateur
    INNER JOIN      tiers fund
    on              fund.ident                      = Trades.entite
    inner join      titres Instrument
    ON              Instrument.sicovam              = Trades.sicovam 
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
    WHERE          Trades.devisepay                   IN (54805837
                                                        , 55137356
                                                        , 54940230) --GERMAN MARK, ITALIAN LIRA, FRENCH FRANC
    AND            Trades.backoffice                  NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    ORDER BY       1,2 ASC;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF TRADE_DEAD_CCY 
  -- ***************************************************************************
END TRADE_DEAD_CCY;


-- *****************************************************************
-- Description: PROCEDURE BOND_WRONG_DEP
-- 
-- Author:          Jun Guan
--
-- Revision History
-- Date           Author			Reason for Change
----------------------------------------------------------------------------------
-- 05/06/2013		Matt Kelly		Filtered out MBS_EURO instruments, increased 
--                                scope to include primary funds and all strats.
-- 22 Jul 2014		Oliver South	Excluded CNH traded bonds
-- -------------------------------------------------------------------------------

PROCEDURE BOND_WRONG_DEP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF BOND_WRONG_DEP 
  -- ***************************************************************************
     OPEN p_CURSOR FOR

SELECT 
             FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME Fund
            , RISKUSERS.NAME Trader
            , HISTOMVTS.sicovam Sicovam
            , HISTOMVTS.refcon Trade_Id
            , TIERS.NAME Depositary
            , TITRES.libelle Instrument_name
            , TITRES.reference Instrument_reference
            , AFFECTATION.libelle Allotment
            , TRUNC(HISTOMVTS.DATENEG) d$Trade_Date
            , HISTOMVTS.QUANTITE Quantity
FROM        HISTOMVTS
INNER JOIN  RISKUSERS 
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  TIERS 
ON          HISTOMVTS.depositaire = TIERS.ident
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN  AFFECTATION
ON          TITRES.affectation = AFFECTATION.ident
INNER JOIN (
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
            FROM FOLIO
            WHERE LEVEL >= 4 START
            WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY 
ON          FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
LEFT JOIN   BTG_MAPPING_CODE 
ON          BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND         BTG_MAPPING_CODE.type_id = 40
AND         BTG_MAPPING_CODE.source_id = 9
WHERE       TITRES.type IN ('O') --bonds
AND         HISTOMVTS.devisepay != 54742600 --ignore CNH traded bonds since these don't settle in the fixed income accounts
AND         TITRES.affectation NOT IN (13,20,1102,1353,1400) --exclude Debt Instruments, Cash, TRS(Fully Funded), MBS - European and Bank Loans
AND         HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --deleted trades
AND         BTG_MAPPING_CODE.output_code IS NULL
AND         HISTOMVTS.dateneg > sysdate - 14 --recent trades
ORDER BY    1,2,3,11 ASC;

-- ***************************************************************************
-- END OF BOND_WRONG_DEP 
-- ***************************************************************************
	END BOND_WRONG_DEP; 
  

  -- *****************************************************************
  -- Description: PROCEDURE MBS_EURO_WRONG_DEP
  --
  --
  -- Revision History
  --
  -- Date           Author			Reason for Change
  ----------------------------------------------------------------------------------
  -- 05/06/2013		Matt Kelly		Created.
  --24 Jun 2013		Oliver South	Added Global Depositary
  --25 Jul 2013		Oliver South	Added to only look at trades in past 7 days PMOG-298
  -- -------------------------------------------------------------------------------
  PROCEDURE MBS_EURO_WRONG_DEP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF MBS_EURO_WRONG_DEP 
  -- ***************************************************************************
     OPEN p_CURSOR FOR

SELECT 
	 FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
	,FUND_BOOK_STRATEGY.Fund_NAME Fund
	,trader.NAME Trader
	,Trades.sicovam Sicovam
	,Trades.refcon Trade_Id
	,depositary.NAME Depositary
	,Instrument.libelle Instrument_name
	,Instrument.reference Instrument_reference
	,Allotment.libelle Allotment
	,trunc(Trades.DATENEG) d$Trade_Date
	,Trades.QUANTITE Quantity

FROM histomvts Trades

INNER JOIN riskusers trader 
ON trader.ident = Trades.operateur

INNER JOIN tiers depositary 
ON trades.depositaire = depositary.ident

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN affectation Allotment 
ON instrument.affectation = allotment.ident

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (
			PCKG_BTG.FOLIO_PRIMARY_FUNDS
			,PCKG_BTG.FOLIO_UCITS_FUND
			) -- (14414,90565)--Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.source_id = 9
AND btg_mapping_code.type_id = 41

WHERE Instrument.TYPE IN ('O') --bonds
AND Instrument.affectation = 1353 --MBS European
AND Trades.backoffice NOT IN (
		192
		,11
		,13
		,17
		,26
		,27
		,220
		,248
		,252
		) --deleted trades
AND Trades.dateneg >= trunc(sysdate) - 7 --traded in the last week
AND btg_mapping_code.output_code IS NULL
ORDER BY 1
	,2
	,3
	,11 ASC;

  -- ***************************************************************************
  -- END OF MBS_EURO_WRONG_DEP 
  -- ***************************************************************************
	END MBS_EURO_WRONG_DEP; 


 -- *****************************************************************
  -- Description: PROCEDURE EQ_1_2_STRAT_TRADE
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  --11 March 2014	Oliver South	Re-write
  -- ----------------------------------------------------------------  
  PROCEDURE EQ_1_2_STRAT_TRADE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQ_1_2_STRAT_TRADE 
  -- ***************************************************************************  
     OPEN p_CURSOR FOR

      SELECT
				FUND_BOOK_STRATEGY.BOOK_NAME              Fund_Strategy
			  , FUND_BOOK_STRATEGY.Fund_NAME              Fund
			  , HISTOMVTS.refcon                          Trade_ID
			  , FUND_BOOK_STRATEGY.STRATEGY_NAME          Folio
			  , HISTOMVTS.sicovam				          Sicovam
			  , TITRES.reference                          Instrument_Reference
			  , TRUNC(HISTOMVTS.DATENEG)                  d$Trade_Date
			  , TRUNC(HISTOMVTS.DATEVAL)                  d$Value_Date

		FROM            HISTOMVTS           
		INNER JOIN      TITRES
		ON              TITRES.sicovam = HISTOMVTS.sicovam         
		INNER JOIN (
				SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
				  ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
				  ,FOLIO.ident AS STRATEGY_ID
				  ,FOLIO.NAME AS STRATEGY_NAME
				  ,LEVEL
				FROM FOLIO
				WHERE LEVEL IN (4,5) START --Booked in top 2 strategy levels
				WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
				  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
				) FUND_BOOK_STRATEGY 
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm    
		INNER JOIN BTG_MAPPING_CODE
		ON BTG_MAPPING_CODE.INPUT_CODE = FUND_BOOK_STRATEGY.BOOK_ID
		AND BTG_MAPPING_CODE.TYPE_ID = 34 --EQ strategies
		WHERE HISTOMVTS.backoffice not in (11,13,17,26,27,192,220,248,252) --Ignore cancelled trades
		AND FUND_BOOK_STRATEGY.BOOK_NAME NOT IN ('EQ US IPO') --Exclude EQ US IPO since no complaints from Brazil teams to date for Boletas bookings
		AND FUND_BOOK_STRATEGY.STRATEGY_NAME != 'Financing' --trades in financing folio is OK
		ORDER BY 1,2,7;

  -- ***************************************************************************
  -- END OF EQ_1_2_STRAT_TRADE 
  -- ***************************************************************************  
	END EQ_1_2_STRAT_TRADE; 
  
   -- *****************************************************************
  -- Description: PROCEDURE FOCUS_ELECTRONIC_TRADES
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date                 Author             Reason for Change
  --18 Feb 2013     Oliver South		Formatting SQL
  --28 Mar 2017    Jeff Yu               PMOG-1090
  -- ----------------------------------------------------------------  
  PROCEDURE FOCUS_ELECTRONIC_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF FOCUS_ELECTRONIC_TRADES 
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

    SELECT
                          trades.refcon                    tradeID
                         ,fund.name                        Fund
                         ,fund_strategy.name               Fund_Strategy
                         ,strategy.name                    Strategy
                         ,PrimeBroker.name                 Depositary
                         ,trader.name                      Trader
                         ,Trades.sicovam				   Sicovam
                         ,Instrument.reference             REPO_Reference
                         ,trunc(Trades.DATENEG)            TradeDate
                         ,trunc(Trades.DATEVAL)            ValueDate

      FROM            histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam       
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE      
      INNER JOIN  (
                      SELECT       folio.ident
                                  ,folio.name
                                  ,nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident)    parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_FOCUS_FUND_RATE -- 62880 -- Focus
        CONNECT BY  mgr         = prior ident
      ) strategy
      ON          strategy.ident            = Trades.opcvm
      INNER JOIN      folio fund_strategy
      ON              fund_strategy.ident   = strategy.parent_ident    
      INNER JOIN      tiers fund
      ON              fund.ident            = Trades.entite
      INNER JOIN      riskusers trader
      ON              trader.ident          = Trades.operateur      
      WHERE           trades.creation       = 2
	  AND           trunc(Trades.DATENEG) >= BTG_BUSINESS_DATE(trunc(sysdate),-3)   ---Only report trades booked within past 3 business days
      AND            ( 
                          trades.contrepartie IN (10004042,10004782) 
                          OR trades.courtier  IN (10004042,10004782)
                     )    
	  AND            TRADES.backoffice not in (11,13,17,26,27,192,220,248,252) ;
	
 -- ***************************************************************************
  -- END OF FOCUS_ELECTRONIC_TRADES 
  -- ***************************************************************************   
	END FOCUS_ELECTRONIC_TRADES; 
  
  
  

  -- *****************************************************************
  -- Description: PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- ---------------------------------------------------------------- 

  PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- ***************************************************************************
  -- BEGIN OF WRONG_TRADER_UBS_ETD_9ARF2B 
  -- ***************************************************************************   
  OPEN p_CURSOR FOR

 SELECT 
	 FUND_BOOK_STRATEGY.BOOK_NAME         Strategy_Name
	,FUND_BOOK_STRATEGY.Fund_NAME         Fund_Name
	,Trades.sicovam                       Sicovam
	,Trades.refcon                        Trade_ID
	,Instrument.reference                 Ticker
	,trunc(Trades.DATENEG)                d$Trade_Date
	,trunc(Trades.DATEVAL)                d$Value_Date
	,DEVISE_TO_STR(Trades.devisepay)      Currency
	,PrimeBroker.NAME                     Prime_Broker
FROM histomvts Trades

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE

INNER JOIN (
		SELECT FOLIO.IDENT
		FROM FOLIO START WITH FOLIO.IDENT IN 
                    (
                    SELECT EQFOLIO.INPUT_CODE
                    FROM btg_mapping_code EQFOLIO
                    WHERE EQFOLIO.TYPE_ID = '34' --London EQ strategies
                    ) 
			CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
          ) strategy
ON strategy.IDENT = trades.OPCVM

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 42
AND btg_mapping_code.source_id = 9

WHERE Trades.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND (Instrument.TYPE = 'F'
		OR 
      (
      Instrument.TYPE = 'D'
      AND 
      Instrument.affectation = 10
      )
		) --futures or listed options
AND trades.dateneg >= sysdate - 5 --recent trades
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.ident NOT IN 
		(
		SELECT int_dep.input_code
    FROM btg_mapping_code int_dep
		WHERE int_dep.type_id = 35 
		)--exclude internal trades depositaries
ORDER BY 1,2 ASC;
 
  -- ***************************************************************************
  -- END OF WRONG_TRADER_UBS_ETD_9ARF2B 
  -- ***************************************************************************      
	END WRONG_TRADER_UBS_ETD_9ARF2B; 
  
  -- *****************************************************************
  -- Description: PROCEDURE EQTEAM_WRONG_UBS_ETD
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- ----------------------------------------------------------------

   PROCEDURE EQTEAM_WRONG_UBS_ETD
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQTEAM_WRONG_UBS_ETD 
  -- ***************************************************************************       
     OPEN p_CURSOR FOR
SELECT FUND_BOOK_STRATEGY.BOOK_NAME Strategy
	,FUND_BOOK_STRATEGY.Fund_NAME Fund
	,Trades.sicovam Sicovam
	,Trades.refcon Trade_ID
	,Instrument.reference Ticker
	,trunc(Trades.DATENEG) d$Trade_Date
	,trunc(Trades.DATEVAL) d$Value_Date
	,DEVISE_TO_STR(Trades.devisepay) Currency
	,PrimeBroker.NAME PrimeBroker
	
FROM histomvts Trades

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (
			PCKG_BTG.FOLIO_PRIMARY_FUNDS
			,PCKG_BTG.FOLIO_UCITS_FUND
			) --Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 43
AND btg_mapping_code.source_id = 9

WHERE Trades.BACKOFFICE NOT IN (
		11
		,13
		,17
		,26
		,27
		,192
		,220
		,248
		,252
		) --cancelled trades
AND (
		(
			Instrument.TYPE = 'F'
			AND Instrument.affectation != 33 --check all futures, but exclude FRA
			)
		OR (
			Instrument.TYPE = 'D'
			AND Instrument.affectation = 10 --checks all listed options
			)
		)
AND trades.dateneg > btg_business_date(sysdate, - 5) --recent trades
AND NVL(Instrument.marche,0) NOT IN (781) -- Exclude BMF trades (PMOG-668)
AND FUND_BOOK_STRATEGY.BOOK_NAME IN (
		'EM (EMEA) Rates'
		,'EM Credit'
		,'Europe Rates and FX'
		,'Global Credit'
		,'Systematic'
		)
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.NAME NOT LIKE '%INTERNAL%'
ORDER BY 3 ASC;
  
  -- ***************************************************************************
  -- END OF EQTEAM_WRONG_UBS_ETD 
  -- ***************************************************************************       
	END EQTEAM_WRONG_UBS_ETD; 
 
  

  
-- *****************************************************************
-- Description: PROCEDURE UST_NON_1000
--  New query on the Trade Booking Errors report that brings to our attention any US Treasury bond trades that have
--      a traded nominal less than a multiple of 1,000.
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
--18 Feb 2013 Oliver South	Changed column order PROJ-26
--03 Jul 2014 Oliver South	clean up and removed coupons PMWM-7
------------------------------------------------------------------  
  PROCEDURE UST_NON_1000
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN		
-- ***************************************************************************
-- BEGIN OF UST_NON_1000 
-- *************************************************************************** 	
		OPEN p_CURSOR FOR

      SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME                  Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME                  Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME              Strategy
						, TITRES.reference                              ISIN
						, HISTOMVTS.refcon                              n$TradeID
						, RISKUSERS.name                                Trader
						, HISTOMVTS.dateneg                             d$Trade_Date
						, HISTOMVTS.dateval                             d$Value_Date
						, HISTOMVTS.quantite*titres.nominal             n$Nominal
						, HISTOMVTS.quantite                            n$Quantity
						, HISTOMVTS.sicovam                             n$Sicovam
            , BUSINESS_EVENTS.name                          Business_Event
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
                    ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =    HISTOMVTS.OPCVM    
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position affecting trades only
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur        
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam    
INNER JOIN  SECTOR_INSTRUMENT_ASSOCIATION
ON          SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam 
WHERE       (
            TITRES.affectation IN ('25','1251') --Gov Bonds and Agency Bonds
            AND         
            SECTOR_INSTRUMENT_ASSOCIATION.sector = 6290   --CNTRY_OF_DOMICILE = US
            )
AND SUBSTR(HISTOMVTS.quantite*TITRES.nominal, -3) <> '000' --nominal not in lots of 1000
AND HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) --exclude cancelled trades
AND HISTOMVTS.dateval > sysdate - 7  --recent trades
;

-- ***************************************************************************
-- END OF UST_NON_1000 
-- *************************************************************************** 	

  END UST_NON_1000;
  
 -- *****************************************************************
 -- Description: PROCEDURE NY_ETD_WRONG_ACCOUNT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- ----------------------------------------------------------------   
  PROCEDURE NY_ETD_WRONG_ACCOUNT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF NY_ETD_WRONG_ACCOUNT 
  -- *************************************************************************** 				
		OPEN p_CURSOR FOR
SELECT 
    fund_book_strategy.BOOK_NAME      Strategy_Name
	, fund_book_strategy.Fund_NAME      Fund_Name
	, Trades.sicovam                    Sicovam
	, Trades.refcon                     Trade_ID
	, Instrument.reference              Ticker
	, trunc(Trades.DATENEG)             d$Trade_Date
	, trunc(Trades.DATEVAL)             d$Value_Date
	, DEVISE_TO_STR(Trades.devisepay)   Currency
	, PrimeBroker.NAME                  PrimeBroker
FROM histomvts Trades
INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam
INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE
INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL > = 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 44
AND btg_mapping_code.source_id = 9
WHERE Trades.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND FUND_BOOK_STRATEGY.BOOK_ID IN 
    (
		SELECT nyfolio.input_code
    FROM btg_mapping_code nyfolio
		WHERE nyfolio.output_code = 'NY'
    AND nyfolio.type_id = 33 
		) --NY strategies
AND (
        (
          Instrument.TYPE = 'F'
          AND 
         (Instrument.affectation != 33 or Instrument.affectation is null)
        )
		OR 
        (
          Instrument.TYPE = 'D'
          AND 
          Instrument.affectation = 10
        )
		) -- futures and listed options
AND trades.dateneg > sysdate - 5 --recent trades
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.ident NOT IN 
		(
		SELECT int_dep.input_code
    FROM btg_mapping_code int_dep
		WHERE int_dep.type_id = 35 
		)--exclude internal trades depositaries
ORDER BY 1,2 ASC;


  -- ***************************************************************************
  -- END OF NY_ETD_WRONG_ACCOUNT 
  -- *************************************************************************** 	
	END NY_ETD_WRONG_ACCOUNT;
  
  


 -- *****************************************************************
 -- Description: PROCEDURE ENTITY_WRONG_ACCT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --	10 Jan 2014		Oliver South	Added QSF
 -- 20 JUL 2016		Gustavo Binnie  PMOG-1019
 -- 29 SEP 2017    Jeff Yu  PMGMPMO-234 - Add GDO fund
 -- ----------------------------------------------------------------     
 PROCEDURE ENTITY_WRONG_ACCT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF ENTITY_WRONG_ACCT 
  -- *************************************************************************** 			
		OPEN p_CURSOR FOR

      SELECT          
                      Trades.sicovam          Sicovam,
                      Trades.refcon           Trade_ID,
                      trader.name             Trader,
                      Instrument.libelle      Name,
                      Instrument.reference    Ticker,
                      trunc(Trades.DATENEG)   d$Trade_Date,
                      trunc(Trades.DATEVAL)   d$Value_Date,
                      Trades.QUANTITE         n$Quantity,
                      PrimeBroker.NAME        PrimeBroker
      FROM            histomvts Trades 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam   = Trades.sicovam 
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT    = Trades.DEPOSITAIRE
      INNER JOIN      riskusers trader
      ON              trader.ident         = Trades.operateur
      WHERE           (             
                                       (Trades.entite = (10003506) --ARF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10007442) 
                                      and PrimeBroker.IDENT<>10021570)--PACTUAL-2689-ARF2
                      OR              (Trades.entite = (10003503) --ARF2
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10006862))
                      OR              (Trades.entite = (10003512) --GEMM
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr in (10006703,10025790)))
                      OR              (Trades.entite = (10010625) --GEO
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010626))
                      OR              (Trades.entite = (10010267) --FOCUS
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010269))
                      OR              (Trades.entite = (10010365) --Global
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010388))
                      OR              (Trades.entite = (10006762) --DMF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10007102))
                      OR              (Trades.entite = (10010602) --EMBL
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010592))
                      OR              (Trades.entite = (10005323) --Leonis
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10008782))
					  OR              (Trades.entite = (10019917) --QSF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10019916))
                      OR              (Trades.entite = (10026005) --GDO
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10026010))
                        )
                      
      AND             trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252) -- cancelled trades
	  and instrument.affectation ! = 20
      ORDER BY        6 ASC;

  -- ***************************************************************************
  -- END OF ENTITY_WRONG_ACCT 
  -- *************************************************************************** 		
	END ENTITY_WRONG_ACCT;
 
 -- *****************************************************************
 -- Description: PROCEDURE TRADE_MISS_CP_DEP_BKR
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 -- ----------------------------------------------------------------     
  PROCEDURE TRADE_MISS_CP_DEP_BKR
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADE_MISS_CP_DEP_BKR 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

    SELECT
                    FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name,
                    FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name, 
                    Trades.sicovam                Sicovam,
                    Trades.refcon                 Trade_Id,
                    trader.name                   Trader,
                    Instrument.libelle            Name,
                    Instrument.reference          Ticker,
                    trunc(Trades.DATENEG)         d$Trade_Date
    FROM            histomvts Trades 
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    INNER JOIN      devisev2 Currency
    ON              Currency.code= Trades.devisepay
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam       
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    WHERE
            (     (Trades.courtier is null) 
               OR (Trades.contrepartie is null) 
               OR (Trades.depositaire is null)
            )
    AND     Trades.dateneg                          > '31-Dec-2010'
    AND     Instrument.TYPE != 'L' --repos
    AND     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
	ORDER BY 1,2;

  -- ***************************************************************************
  -- END OF TRADE_MISS_CP_DEP_BKR 
  -- *************************************************************************** 		
	END TRADE_MISS_CP_DEP_BKR;


-- *****************************************************************
-- Description:PROCEDURE TRADES_EQ_WRONG_ACCT
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
--    2012      Jun Guan			Created.
-- 30-Apr-2013  Gustavo Binnie    Included two depositaries
-- 22-Jul-2014  Oliver South	  Added a check for CNH settled bond trades
-- *****************************************************************  
PROCEDURE TRADES_EQ_WRONG_ACCT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_EQ_WRONG_ACCT 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT 
             FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME Fund
            , RISKUSERS.NAME Trader
            , HISTOMVTS.sicovam Sicovam
            , HISTOMVTS.refcon Trade_Id
            , TIERS.NAME Depositary
            , TITRES.libelle Instrument_name
            , TITRES.reference Instrument_reference
            , AFFECTATION.libelle Allotment
            , TRUNC(HISTOMVTS.DATENEG) d$Trade_Date
            , HISTOMVTS.QUANTITE Quantity
FROM        HISTOMVTS
INNER JOIN  RISKUSERS 
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  TIERS 
ON          HISTOMVTS.depositaire = TIERS.ident
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN  AFFECTATION
ON          TITRES.affectation = AFFECTATION.ident
INNER JOIN (
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
            FROM FOLIO
            WHERE LEVEL >= 4 START
            WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
            --WITH FOLIO.ident IN (14414)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY 
ON          FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM    
LEFT JOIN   BTG_MAPPING_CODE
ON          BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND         BTG_MAPPING_CODE.type_id=45
AND         BTG_MAPPING_CODE.source_id=9
WHERE       HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
AND         (
                (
                TITRES.TYPE = 'A' --share
                AND         
                HISTOMVTS.devisepay != 54678092 --exclude BRL trades
				AND
                NVL(TITRES.AFFECTATION,0) != 1506 --exclude allotment Shares - Unlisted
                )
            OR
                (
                TITRES.TYPE = 'O' --bond
                AND         
                HISTOMVTS.devisepay = 54742600 --Include CNH traded bonds
                )
            )
AND         HISTOMVTS.dateneg > trunc(sysdate-14) --recent trades
AND         BTG_MAPPING_CODE.output_code is null
ORDER BY    3 ASC;
  -- ***************************************************************************
  -- END OF TRADES_EQ_WRONG_ACCT 
  -- ***************************************************************************		
END TRADES_EQ_WRONG_ACCT;


   -- *****************************************************************
  -- Description  PROCEDURE TRADE_FX_RATE_WRONG
  --
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 28 Feb 2013    Oliver South    FX = 0 caused EOD failure
  -- *****************************************************************
  PROCEDURE TRADE_FX_RATE_WRONG
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADE_FX_RATE_WRONG 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event        
    FROM          histomvts Trades    
    INNER JOIN    riskusers 
    ON            Trades.operateur     = riskusers.ident    
    INNER JOIN    titres security 
    ON            security.sicovam     = trades.sicovam        
    INNER JOIN    tiers CP
    ON            CP.IDENT             = Trades.depositaire    
    INNER JOIN    business_events 
    ON            business_events.id   = Trades.type    
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  Trades.OPCVM    
    WHERE Trades.BACKOFFICE                   NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND business_events.id NOT IN(15) -- NOT 'Instr. modif' Business Event
    AND (
        ( security.type = 'G'
          AND   security.devisectt != trades.devisepay
          AND   Trades.tauxchange=1
          AND   business_events.compta = 1
        ) --CFD position affecting trades that have FX rate =1 where sett ccy <> inst ccy
        OR
        ( security.devisectt != trades.devisepay
          AND   Trades.tauxchange=0
        ) --All trades where sett ccy <> inst ccy and fx = 0
        OR
        ( trades.typecours = 5
          AND   Trades.tauxchange=0
        ) --Trades where the price type is in underlying currency and the FX = 0
        )
	 and  Trades.DATENEG                       >= sysdate-365
    ORDER BY 1,2;


	-- ***************************************************************************
  -- END OF TRADE_FX_RATE_WRONG 
  -- ***************************************************************************	
 END TRADE_FX_RATE_WRONG;
 


-- *****************************************************************
-- Description:     PROCEDURE  US_RATES_TRADES_BAD_ALLOTMENT
--
-- Author:          Ami Talati
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013      Ami Talati           Created.
-- 04 NOV 2014      Gustavo Binnie       Included 'US Energy' (PMOG-615)
-- 04 NOV 2016    Jeff Yu        Included 'Global Rates' strategy (PMOG-1060)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- ***************************************************************** 
  PROCEDURE US_RATES_TRADES_BAD_ALLOTMENT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: US_RATES_TRADES_BAD_ALLOTMENT
  -- *****************************************************************   
          OPEN p_CURSOR FOR
	SELECT
                      FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
                    , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
                    , Trades.sicovam                Sicovam
                    , Trades.refcon                 Trade_Id
                    , trader.name                   Trader
                    , Instrument.libelle            Name
                    , Instrument.reference          Ticker
                    , trunc(Trades.DATENEG)         d$Trade_Date
                    , Allotment.libelle             Allotment
                    , domicile.code       Country_Domicile
    FROM            histomvts Trades 
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    INNER JOIN      devisev2 Currency
    ON              Currency.code= Trades.devisepay
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam   
    INNER JOIN      affectation Allotment
    ON              Allotment.ident= Instrument.affectation   
	
	LEFT JOIN sector_instrument_association sia2
		ON Instrument.sicovam = sia2.sicovam
			AND sia2.sector IN (
					SELECT id
					FROM sectors
					WHERE parent = 5347
				)
	LEFT JOIN sectors domicile
		ON sia2.sector = domicile.id
		
	INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    WHERE   Trades.dateneg                          > trunc(sysdate-5)
    AND     Instrument.TYPE = 'O' --bonds
    AND     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
    AND     (FUND_BOOK_STRATEGY.BOOK_NAME = 'US Rates' or FUND_BOOK_STRATEGY.BOOK_NAME = 'US Energy'  or FUND_BOOK_STRATEGY.BOOK_NAME='Global Rates')
    AND     UPPER(domicile.code) = 'US'
    AND     Allotment.libelle = 'Corp Bonds'
	ORDER BY 1,2;
       
          
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: US_RATES_TRADES_BAD_ALLOTMENT
  -- *****************************************************************   
	END US_RATES_TRADES_BAD_ALLOTMENT; 





  PROCEDURE EXEC_FEES_NOT_CHILD_FEES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EXEC_FEES_NOT_CHILD_FEES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
				SELECT 
							  FUND_BOOK_STRATEGY.BOOK_NAME                    Execution_Folio
							, TA_BLOCK_TO_GENERATED.BLOCK_ID                  Block_ID
							, SUM(CHILD_TRADE.MONTANT)                        n$Sum_Of_Child_Cash
							, BLOCK_TRADE.MONTANT                             n$Block_Level_Cash
							, SUM(CHILD_TRADE.MONTANT)-BLOCK_TRADE.MONTANT    n$Cash_Difference
							, SECURITY.REFERENCE                              Instrument_Reference
							, SECURITY.SICOVAM                                Sicovam
							, CHILD_TRADE.DATENEG                             d$Trade_Date
							, BUSINESS_EVENTS.NAME                            Business_Event
				FROM
				TA_BLOCK_TO_GENERATED
							INNER JOIN  HISTOMVTS CHILD_TRADE
							ON          CHILD_TRADE.REFCON = TA_BLOCK_TO_GENERATED.GENERATED_ID
							AND         CHILD_TRADE.DATENEG > TRUNC(SYSDATE-50) --recent trades
							AND         CHILD_TRADE.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --ignore deleted trades
							INNER JOIN  HISTOMVTS BLOCK_TRADE
							ON          BLOCK_TRADE.REFCON = TA_BLOCK_TO_GENERATED.BLOCK_ID 
							INNER JOIN ( 
												  SELECT       CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
															  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)    AS BOOK_ID
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)     AS BOOK_NAME
															  , FOLIO.ident                                                            AS STRATEGY_ID
															  , FOLIO.name                                                             AS STRATEGY_NAME
															  , level
												  FROM FOLIO
												  WHERE LEVEL                       >= 4
												  START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_EXEC_BOOK)  --Execution book
												  CONNECT BY PRIOR  FOLIO.ident     = FOLIO.mgr  
											  )  FUND_BOOK_STRATEGY
								ON               FUND_BOOK_STRATEGY.STRATEGY_ID     = BLOCK_TRADE.OPCVM
							INNER JOIN  TITRES SECURITY
							ON          SECURITY.SICOVAM = CHILD_TRADE.SICOVAM
							AND         SECURITY.TYPE = 'S' --swaps only
							INNER JOIN  BUSINESS_EVENTS 
							ON          BUSINESS_EVENTS.ID = CHILD_TRADE.TYPE
				HAVING      ABS(SUM(CHILD_TRADE.MONTANT)-BLOCK_TRADE.MONTANT) > 1 --difference more than 1 unit of trade currency
				GROUP BY    FUND_BOOK_STRATEGY.BOOK_NAME, TA_BLOCK_TO_GENERATED.BLOCK_ID, BLOCK_TRADE.MONTANT, SECURITY.REFERENCE, SECURITY.SICOVAM, CHILD_TRADE.DATENEG, BUSINESS_EVENTS.NAME
				ORDER BY 8
				;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: EXEC_FEES_NOT_CHILD_FEES
  -- *****************************************************************   
	END EXEC_FEES_NOT_CHILD_FEES; 

 -- *****************************************************************
 -- Description:     PROCEDURE  CPP_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 31 Jan 2014     Gustavo Binnie       Created.
 -- 28 May 2014		Gustavo Binnie		 COM-107 - Changes to reflect where the restricted ID_BB_COMPAANY are stored (new table BTG_RESTRICTED_LIST_IDS) 
 -- *****************************************************************  

  PROCEDURE CPP_RESTRICTED_LIST_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: CPP_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =0

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;


	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: CPP_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
	END CPP_RESTRICTED_LIST_TRADES;


-- *****************************************************************
-- Description:     PROCEDURE  TRADE_DIR_DIFF_BLOCK_DIR
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 feb 2014      Oliver South            Created.
-- ***************************************************************** 
PROCEDURE TRADE_DIR_DIFF_BLOCK_DIR (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: TRADE_DIR_DIFF_BLOCK_DIR
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
        FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
      , FUND_BOOK_STRATEGY.Fund_NAME            Fund
      , HISTOMVTS.DATENEG                       d$Trade_date
      , TA_BLOCK_TO_GENERATED.BLOCK_ID          Block_ID
      , HISTOMVTS.QUANTITE                      n$Block_Qty
      , TA_BLOCK_TO_GENERATED.GENERATED_ID      Child_ID
      , TA_BLOCK_TO_GENERATED.QUANTITY          n$Child_Qty
      , TITRES.SICOVAM                          Sicovam
      , TITRES.REFERENCE                        Instrument_Reference
      , TITRES.LIBELLE                          Instrument_Name
      , RISKUSERS.NAME                          Trader_Name
FROM TA_BLOCK_TO_GENERATED 
INNER JOIN HISTOMVTS
ON HISTOMVTS.REFCON = TA_BLOCK_TO_GENERATED.BLOCK_ID
INNER JOIN TITRES
ON TITRES.SICOVAM = HISTOMVTS.SICOVAM
INNER JOIN RISKUSERS
ON RISKUSERS.IDENT = HISTOMVTS.OPERATEUR
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  TA_BLOCK_TO_GENERATED.FOLIO
WHERE SIGN(TA_BLOCK_TO_GENERATED.QUANTITY) != SIGN(HISTOMVTS.QUANTITE) --trade direction is different from the block trade direction
AND HISTOMVTS.DATENEG > sysdate-10 --Look back last 10 days
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

TRADE_DIR_DIFF_BLOCK_DIR;

-- *****************************************************************
-- END OF: TRADE_DIR_DIFF_BLOCK_DIR
-- *****************************************************************   


-- *****************************************************************
-- Description:     PROCEDURE  TRADE_EQ_MISS_BR_CODE
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 Jul 2014      Oliver South            Created.
-- 08 Aug 2017    Jeff Yu         Modified (PMOG-1134)
-- ***************************************************************** 

PROCEDURE TRADE_EQ_MISS_BR_CODE (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: TRADE_EQ_MISS_BR_CODE
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT              
                    DISTINCT(TIERS.name)                                 Broker
    FROM            HISTOMVTS
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1
    AND             BUSINESS_EVENTS.id NOT IN (161)
    INNER JOIN      RISKUSERS
    ON              RISKUSERS.ident = HISTOMVTS.operateur
    INNER JOIN      TIERSPROPERTIES UBS
    ON              UBS.code = HISTOMVTS.courtier
    AND             UBS.name = 'UBS CODE'
    INNER JOIN      TIERSPROPERTIES MS
    ON              MS.code = HISTOMVTS.courtier
    AND             MS.name = 'MS PB CODE'
    INNER JOIN      TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam 
    AND             TITRES.type = 'A'
    INNER JOIN      TIERS
    ON              TIERS.ident = histomvts.courtier
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID =  HISTOMVTS.OPCVM
    WHERE          HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    AND            ( UBS.value is null OR MS.value is null )
    AND            HISTOMVTS.dateneg > TRUNC(Sysdate-7) --trades done in the past week
    AND            DEVISE_TO_STR(HISTOMVTS.devisepay) != 'BRL' --exclude Brazil trades as they settle in 2689 account
    AND            HISTOMVTS.courtier NOT IN (10010875, 10012815, 10010876) --exclude internal trades
    ORDER BY       1;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END TRADE_EQ_MISS_BR_CODE;

-- *****************************************************************
-- END OF: TRADE_EQ_MISS_BR_CODE
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  US_RATES_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 09 Sep 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE US_RATES_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: US_RATES_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =12

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;  
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

END US_RATES_RESTRICTED_LIST;

-- *****************************************************************
-- END OF: US_RATES_RESTRICTED_LIST
-- *****************************************************************         
-- *****************************************************************
-- Description:     PROCEDURE  NDF_BACK_TO_FRONT
-- Author:          Jun Guan
-- /* Reports NDF London Strategy trades booked the wrong way round */
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE NDF_BACK_TO_FRONT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: NDF_BACK_TO_FRONT
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

	SELECT FUND_BOOK_STRATEGY.BOOK_NAME Strategy
		,FUND_BOOK_STRATEGY.Fund_NAME Fund
		,Trades.sicovam Sicovam
		,Trades.refcon TradeID
		,Instrument.reference Ticker
		,trunc(Trades.DATENEG) d$TradeDate
		,trunc(Trades.DATEVAL) d$ValueDate
		,Currency.libelle Currency
		,BTG_FN_AUDIT_INST_USER(Instrument.sicovam) Instr_last_amended_by
	FROM histomvts Trades
	INNER JOIN business_events
		ON business_events.id = Trades.type
	INNER JOIN devisev2 Currency
		ON Currency.code = Trades.devisepay
	INNER JOIN titres Instrument
		ON Instrument.sicovam = Trades.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --(14414,90565)--Primary funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	WHERE Trades.BACKOFFICE NOT IN (
			11
			,13
			,17
			,26
			,27
			,192
			,220
			,248
			,252
			) --Deleted/cancelled
		AND Instrument.TYPE = 'K' --NDF
		AND currency.code IN (
			54612563
			,54678092
			,54742096
			,54742617
			,54742864
			,54871888
			,55135826
			,55133266
			,55267927
			,55269972
			,55400786
			,55592270
			,55593040
			,55727426
			,55859012
			,55918920
			,55987780
			)
	ORDER BY 3 ASC;
		/* Reports NDF booked the wrong way round */
		-- *****************************************************************
		-- END OF: NDF_BACK_TO_FRONT
		-- ***************************************************************** 
END

NDF_BACK_TO_FRONT;


 -- *****************************************************************
 -- Description: PROCEDURE ABS_IN_NON_USMORT
 -- Author:          Davi Xavier
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- 24-Nov-2014      Davi Xavier	Creation
 -- 23-MAR-2016		 Gustavo Binnie PMOG-934
  -- ----------------------------------------------------------------   
  PROCEDURE ABS_IN_NON_USMORT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF ABS_IN_NON_USMORT 
  -- *************************************************************************** 				
		OPEN p_CURSOR FOR
    
     select 
   fund_book_strategy.book_name                       top_level_strategy
  ,trades.refcon                                      trade_id
  ,fund_book_strategy.fund_name                       fund_name
  ,titres.libelle                                     instrument_name 
  ,bo_kernel_status.name                              status
  ,titres.reference                                   instrument_reference
  ,riskusers.name                                     trader_name
  ,business_events.name                               business_event 
  ,trades.dateneg                                     trade_date
  ,trades.dateval                                     value_date
  ,nvl(ROUND(Trades.QUANTITE*titres.nominal, 8),0)    nominal
  ,trades.cours                                       gross_price  
  ,trades.montant                                     net_amount
  ,contreparties.libelle                              counterparty_name
  ,b.libelle                                          broker_name
  ,depositaires.libelle                               depositary_name
  ,trades.sicovam                                     sicovam
  ,affectation.libelle                                allotment 
 
FROM histomvts trades

INNER JOIN titres
on titres.sicovam = trades.sicovam

inner join  riskusers
on riskusers.ident = trades.operateur

inner join affectation 
on affectation.ident = titres.affectation

inner join  business_events
on business_events.id = trades.type

inner join bo_kernel_status
on bo_kernel_status.id  = trades.backoffice

inner join contreparties
ON contreparties.IDENT = trades.CONTREPARTIE 

left join tiers 
on tiers.ident = trades.courtier

inner join courtiers b
on b.ident = trades.courtier

inner join depositaires
on depositaires.ident = trades.depositaire 

inner join (     
                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME 
                      , FOLIO.ident AS STRATEGY_ID 
                      , FOLIO.name AS STRATEGY_NAME 
                      , level 
                  FROM FOLIO 
                  where level >= 4 
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                  ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.OPCVM 
                
where AFFECTATION.ident = '38' -- 'ABS' 
                
and fund_book_strategy.book_name not in ('Global ABS', 'US RMBS - Agency', 'US RMBS � Non Agency', 'CMBS', 'Securitized Products' )
               
and trades.backoffice not in (192,11,13,17,26,27,220,248,252) -- Exclude cancelled trades
                
and trades.dateneg > trunc(sysdate)-30;


  -- ***************************************************************************
  -- END OF ABS_IN_NON_USMORT 
  -- *************************************************************************** 	
	END ABS_IN_NON_USMORT;

-- *****************************************************************
-- Description:     PROCEDURE  AML_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 25 Nov 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE AML_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: AML_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =13

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: AML_RESTRICTED_LIST
-- *****************************************************************

   END AML_RESTRICTED_LIST;

-- *****************************************************************
-- Description:     PROCEDURE  EUROPEAN_ABS_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 25 Nov 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE EUROPEAN_ABS_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EUROPEAN_ABS_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =14

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: EUROPEAN_ABS_RESTRICTED_LIST
-- *****************************************************************

   END EUROPEAN_ABS_RESTRICTED_LIST;


-- *****************************************************************
-- Description:     PROCEDURE  CROSS_ASSET_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 30 Jan 2015     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE CROSS_ASSET_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: CROSS_ASSET_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =17

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: CROSS_ASSET_RESTRICTED_LIST
-- *****************************************************************

   END CROSS_ASSET_RESTRICTED_LIST;


 -- *****************************************************************
-- Description:     PROCEDURE  TRADE_REST_CCY
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 06 FEB 2015      Oliver              Created.	
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************  

  PROCEDURE TRADE_REST_CCY
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_REST_CCY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT
              FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME                        Fund
            , HISTOMVTS.refcon                                    Trade_id
            , FUND_BOOK_STRATEGY.STRATEGY_NAME                    Folio
            , HISTOMVTS.sicovam                                   Sicovam
            , TITRES.reference                                    Instrument_reference
            , TRUNC(HISTOMVTS.DATENEG)                            d$Trade_Date 
            , TRUNC(HISTOMVTS.DATEVAL)                            d$Value_Date 
            , DEVISE_TO_STR (HISTOMVTS.devisepay)                 Currency
            , BUSINESS_EVENTS.name                                Business_event
                                         
FROM        HISTOMVTS       
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
AND         TITRES.type = 'A' --any instrument created on the share template
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
WHERE          
          HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades        
AND DEVISE_TO_STR (HISTOMVTS.devisepay) IN ('IDR','INR','KRW','PHP','THB','TWD') --restricted currencies
AND TRUNC(HISTOMVTS.DATEVAL) >= TRUNC(SYSDATE)
ORDER BY 1,2,3 ASC;       


-- *****************************************************************
-- END OF: TRADE_REST_CCY
-- *****************************************************************

   END TRADE_REST_CCY;

 -- *****************************************************************
-- Description:     PROCEDURE  SHORT_MBS
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 APR 2015      Oliver              Created.					
-- 29 APR 2015      Davi                Arrange to be added to the critical errors Package
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  PROCEDURE SHORT_MBS
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: SHORT_MBS
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , FUND_BOOK_STRATEGY.STRATEGY_NAME Folio_Name
          , HISTOMVTS.sicovam                Sicovam
          , TITRES.libelle            Name
          , TITRES.reference          Ticker
          , SUM(HISTOMVTS.QUANTITE*NVL(TITRES.nominal,1)) Quantity
    FROM            HISTOMVTS 
    INNER JOIN      TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam 
    AND             TITRES.affectation IN (35, 38, 1252, 1253, 1450) --MBS - Agency, ABS, MBS - Non Agency, CMBS, ABS - Student Loan
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1 --position affecting tickets only
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.opcvm
    WHERE           HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, HISTOMVTS.sicovam, TITRES.libelle, TITRES.reference   
    HAVING SUM(HISTOMVTS.QUANTITE*NVL(TITRES.nominal,1)) < -1 --excludes the fractional positions between 0 and -1 to remove noise. These trades should be cleaned at some point too
    ORDER BY 1,2,3;     

-- *****************************************************************
-- END OF: SHORT_MBS
-- *****************************************************************

   END SHORT_MBS;
   
-- *****************************************************************
-- Description:     PROCEDURE  TRADE_WRONG_TYPESICO
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30 APR 2015      Oliver              Created.					
-- 30 APR 2015      Davi                Arrange to be added to the critical errors Package

  PROCEDURE TRADE_WRONG_TYPESICO
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_WRONG_TYPESICO
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 SELECT 
	  FUND_BOOK_STRATEGY.BOOK_NAME      Strategy_Name
	, FUND_BOOK_STRATEGY.Fund_NAME      Fund_Name
  , RISKUSERS.name                    Trader
	, HISTOMVTS.sicovam                 Sicovam
	, HISTOMVTS.refcon                  Trade_ID
	, TITRES.reference                  Ticker
	, TRUNC(HISTOMVTS.DATENEG)          d$Trade_Date

FROM HISTOMVTS

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam

INNER JOIN RISKUSERS
ON RISKUSERS.ident = HISTOMVTS.operateur

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND,PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14414,90565,14045)
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm

WHERE HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND HISTOMVTS.typesico !=0 --trade type not Real
ORDER BY 1,2 ASC; 

-- *****************************************************************
-- END OF: TRADE_WRONG_TYPESICO
-- *****************************************************************

   END TRADE_WRONG_TYPESICO;

   -- *****************************************************************
-- Description:     PROCEDURE  PURCHSALE_QTY_0
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUN 2015      Gustavo Binnie      Created.					
-- 20 JUN 2018      Jeff Yu       Modified (PMGMRISK-228)

  PROCEDURE PURCHSALE_QTY_0
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PURCHSALE_QTY_0
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 select
        Trades.refcon                                                                       Trade_ID,        
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.BOOK_NAME                                                        Strategy,
        FUND_BOOK_STRATEGY.STRATEGY_NAME                                                    Folio,
        trader.name                                                                         Trader,
        Trades.DATENEG                                                                      d$Trade_Date,
        Instrument.LIBELLE                                                                  Instrument_Name,
        DEVISE_TO_STR(Instrument.DEVISECTT)                                           Instrument_CCY,
        allot.LIBELLE                                                                       Allotment,
        pb.REFERENCE                                                                        Depositary,
        Trades.QUANTITE                                                                     Qty,
        Trades.MONTANT                                                                      NetAmount,
        DEVISE_TO_STR(Trades.DEVISEPAY)                                               Sett_CCY
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam			 = Trades.sicovam 
INNER JOIN       riskusers trader
ON               trader.ident                = Trades.operateur
left join      tiers cpty
on              cpty.ident					 = trades.contrepartie
left join      tiers pb
on              pb.ident					 = Trades.DEPOSITAIRE                            
left join      affectation allot
on              allot.IDENT					 = Instrument.AFFECTATION
inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME  
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 3
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE 
Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
and Trades.type in (1,140,1444,1494)
and Trades.QUANTITE = 0
And Trades.MONTANT <> 0
;

-- *****************************************************************
-- END OF: PURCHSALE_QTY_0
-- *****************************************************************

   END PURCHSALE_QTY_0;
   
   -- *****************************************************************
-- Description:     PROCEDURE  FEES_ON_EV
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUN 2015      Gustavo Binnie      Created.					

  PROCEDURE FEES_ON_EV
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: FEES_ON_EV
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
              HISTOMVTS.sicovam                   SICOVAM
            , HISTOMVTS.refcon                    TRADE_ID
            , HISTOMVTS.dateneg                   TRADE_DATE
            , HISTOMVTS.dateval                   VALUE_DATE
            , TITRES.Libelle                      INSTRUMENT_NAME
            , TITRES.reference                    INSTRUMENT_REFERENCE
            , DEVISE_TO_STR(TITRES.devisectt)     INSTRUMENT_CCY
            , BUSINESS_EVENTS.name                BUSINESS_EVENT
            , HISTOMVTS.fraismarche               MARKET_FEES
            , HISTOMVTS.fraiscounterparty         COUNTERPARTY_FEES
            , HISTOMVTS.fraiscourtage             BROKER_FEES
            , HISTOMVTS.montant                   NET_AMOUNT
            , DEVISE_TO_STR(HISTOMVTS.devisepay)  PAY_CCY
FROM 
            HISTOMVTS
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 2
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
WHERE
DEVISE_TO_STR(HISTOMVTS.devisepay) != 'BRL'
AND HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND
(
            HISTOMVTS.fraismarche <>0
OR
            HISTOMVTS.fraiscounterparty <>0
OR
            HISTOMVTS.fraiscourtage <>0
)
;

-- *****************************************************************
-- END OF: FEES_ON_EV
-- *****************************************************************

   END FEES_ON_EV;
   
-- *****************************************************************
-- Description:     PROCEDURE  NY_ETD_WRNG_ACCT_EQ
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 04 SEP 2015      Oliver              Created.					
-- 04 SEP 2015      Davi                Arranged the release with AS	
 --16 AUG 2018    Jeff Yu             Modified (PMOGUCITS-60)

  PROCEDURE NY_ETD_WRNG_ACCT_EQ
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: NY_ETD_WRNG_ACCT_EQ
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
                FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name
              , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
              , HISTOMVTS.sicovam                     Sicovam
              , HISTOMVTS.refcon                      Trade_ID
              , TITRES.reference                      Ticker
              , TRUNC(HISTOMVTS.dateneg)              d$Trade_Date
              , TRUNC(HISTOMVTS.dateval)              d$Value_Date
              , DEVISE_TO_STR(HISTOMVTS.devisepay)    Currency
              , TIERS.NAME                            PrimeBroker
FROM          HISTOMVTS
INNER JOIN    TITRES 
ON            TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN    TIERS
ON            TIERS.IDENT = HISTOMVTS.DEPOSITAIRE
INNER JOIN (
              SELECT 
                      CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                    , FOLIO.ident AS STRATEGY_ID
                    , FOLIO.NAME AS STRATEGY_NAME
                    , LEVEL
              FROM  FOLIO
              WHERE LEVEL > = 4 START
              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
          )   FUND_BOOK_STRATEGY 
ON            FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
LEFT JOIN     BTG_MAPPING_CODE --Link to allowed NY ETD depositaries
ON            BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND           BTG_MAPPING_CODE.type_id = 44
AND           BTG_MAPPING_CODE.source_id = 9
WHERE         HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND           FUND_BOOK_STRATEGY.BOOK_ID IN 
                                          (
                                          SELECT  NYFOLIO.input_code
                                          FROM    BTG_MAPPING_CODE NYFOLIO
                                          WHERE   NYFOLIO.output_code = 'NY'
                                          AND     NYFOLIO.type_id = 33 
                                          ) --NY strategies
AND           (
                              (
                                TITRES.TYPE = 'F'
                                AND 
                               (TITRES.affectation != 33 or TITRES.affectation is null)
                              )
                          OR 
                              (
                                TITRES.TYPE = 'D'
                                AND 
                                TITRES.affectation = 10
                              )
              ) -- futures and listed options
AND           HISTOMVTS.dateneg > sysdate - 5 --recent trades
AND           BTG_MAPPING_CODE.output_code IS NULL
AND           TIERS.ident NOT IN 
                                          (
                                          SELECT  INT_DEP.input_code
                                          FROM    BTG_MAPPING_CODE INT_DEP
                                          WHERE   INT_DEP.type_id = 35 
                                          )--exclude internal trades depositaries
AND           FUND_BOOK_STRATEGY.BOOK_NAME IN ('EQ US Cash','EQ US IPO')
ORDER BY 1,2 ASC;

-- *****************************************************************
-- END OF: NY_ETD_WRNG_ACCT_EQ
-- *****************************************************************

   END NY_ETD_WRNG_ACCT_EQ;
   
-- *****************************************************************
-- Description:     PROCEDURE     TRADE_BOND_MIN_SIZE
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 SEP 2015      Oliver              Created.					
-- 16 SEP 2015      Davi                Arranged the release with AS		
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  PROCEDURE TRADE_BOND_MIN_SIZE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_BOND_MIN_SIZE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME                  Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME                  Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME              Strategy
						, TITRES.reference                              ISIN
						, HISTOMVTS.refcon                              n$TradeID
						, RISKUSERS.name                                Trader
						, HISTOMVTS.dateneg                             d$Trade_Date
						, HISTOMVTS.dateval                             d$Value_Date
						, HISTOMVTS.quantite*titres.nominal             n$Nominal
						, HISTOMVTS.quantite                            n$Quantity
						, HISTOMVTS.sicovam                             n$Sicovam
            , BUSINESS_EVENTS.name                          Business_Event
            , TITRES.minimumpiece                           Minimum_Piece
            , TITRES.lowestincrement                        Minimum_Increment
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
                    ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =    HISTOMVTS.OPCVM    
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position affecting trades only
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur        
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam   
AND         TITRES.lowestincrement !=0

WHERE       HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) --exclude cancelled trades
AND         (
            TRUNC((((HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement)) != (((HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement)
			OR
			((abs(HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement) < 0
            )
AND HISTOMVTS.dateval > sysdate - 7  --recent trades
ORDER BY 1,2 
;

-- *****************************************************************
-- END OF: TRADE_BOND_MIN_SIZE
-- *****************************************************************

   END TRADE_BOND_MIN_SIZE;
   
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_LEI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_LEI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_LEI_VALIDATION
  -- *****************************************************************   
  OPEN p_CURSOR FOR
        
SELECT tiers.ident
	,tiers.reference
	,tiers.NAME
	,BTG_EMIR_TIERS.lei
	
FROM BTG_EMIR_TIERS

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

WHERE BTG_EMIR_TIERS.LEI IS NOT NULL
AND length(BTG_EMIR_TIERS.lei) != 20;


-- *****************************************************************
-- END OF: EMIR_LEI_VALIDATION
-- *****************************************************************

 END EMIR_LEI_VALIDATION;
   
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_UTI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_UTI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_UTI_VALIDATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 SELECT DISTINCT histomvts.refcon Trade_ID
  ,btg_emir_confirm.uti UTI
	,titres.reference instrument_reference
	,affectation.libelle allotment
	,titres.sicovam sicovam
	,fund.reference Fund
	,business_events.NAME business_event
	,histomvts.quantite quantity
	,histomvts.cours price
  ,trunc(histomvts.DATENEG)   d$Trade_Date
  ,trunc(histomvts.DATEVAL)   d$Value_Date
	,tiers.reference depositary
	,cpty.reference counterparty

FROM histomvts

INNER JOIN (
	SELECT folio.ident
		,folio.NAME
		,NVL(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'), 3, 4), ident) parent_ident
	FROM folio
	WHERE LEVEL > 2 START
	WITH ident = PCKG_BTG.FOLIO_UCITS_FUND CONNECT BY mgr = prior ident
	) strategy
ON strategy.ident = histomvts.opcvm

INNER JOIN titres fund
ON fund.code_emet = histomvts.entite

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.fund = fund.sicovam
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN business_events
ON business_events.id = histomvts.type
AND business_events.compta = 1

INNER JOIN tiers
ON tiers.ident = histomvts.depositaire

INNER JOIN tiers cpty
ON cpty.ident = histomvts.contrepartie

INNER JOIN AMRECON_EXTSYS_ACCOUNTS depo
ON depo.pb = tiers.ident
AND depo.esid = 3183
AND depo.include = 1

INNER JOIN titres
ON titres.sicovam = histomvts.sicovam

LEFT JOIN affectation
ON affectation.ident = titres.affectation

LEFT JOIN btg_emir_confirm
ON btg_emir_confirm.refcon = histomvts.refcon

WHERE TRUNC(histomvts.DATENEG) >= '12-FEB-2014'
AND histomvts.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
AND cpty.ident not in (10007902,10021768) -- Excluding NDF FIXING and NDF FIXING UCITS
AND (btg_emir_confirm.uti IS NULL
     OR 
     (btg_emir_confirm.uti IS NOT NULL and length(btg_emir_confirm.uti) > 50)
    );


-- *****************************************************************
-- END OF: EMIR_UTI_VALIDATION
-- *****************************************************************

 END EMIR_UTI_VALIDATION;
 
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_ISDA_LAW_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_ISDA_LAW_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_ISDA_LAW_VALIDATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT tiers.ident
	,tiers.reference
	,tiers.NAME
	,tiersagreement.agreement
	,tiersagreement.law
FROM tiersagreement
INNER JOIN tiers
ON tiers.ident = tiersagreement.code

WHERE tiersagreement.law IS NOT NULL
AND (
		substr(tiersagreement.law, 1, 2) NOT IN (19,20)
		OR 
    length(tiersagreement.law) != 4
    )
;

-- *****************************************************************
-- END OF: EMIR_ISDA_LAW_VALIDATION
-- *****************************************************************

 END EMIR_ISDA_LAW_VALIDATION;
 

-- *****************************************************************
-- Description:     PROCEDURE  EMIR_CONFIRM_DATE
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_CONFIRM_DATE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_CONFIRM_DATE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT HISTOMVTS.refcon TradeID
	,HISTOMVTS.dateneg d$Trade_Date
	,BTG_EMIR_CONFIRM.CONFIRM_DATE d$Confirm_Date
	--, HISTOMVTS.quantite                            n$Quantity
	,HISTOMVTS.sicovam n$Sicovam
	,TITRES.reference Instrument_ref
	,TITRES.libelle Instrument_name
	,BUSINESS_EVENTS.NAME Business_Event
	,RISKUSERS.NAME Trader
FROM HISTOMVTS
INNER JOIN BTG_EMIR_CONFIRM
ON BTG_EMIR_CONFIRM.REFCON = HISTOMVTS.REFCON
	
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.id = HISTOMVTS.type

INNER JOIN RISKUSERS
ON RISKUSERS.ident = HISTOMVTS.operateur

INNER JOIN TITRES
ON TITRES.sicovam = HISTOMVTS.sicovam

WHERE HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --exclude cancelled trades
AND (BTG_EMIR_CONFIRM.CONFIRM_DATE < HISTOMVTS.dateneg)

ORDER BY 1,2
;

-- *****************************************************************
-- END OF: EMIR_CONFIRM_DATE
-- *****************************************************************

 END EMIR_CONFIRM_DATE;

  
 -- *****************************************************************
-- Description:     PROCEDURE  EMIR_UCITS_INST_MATURITY
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_UCITS_INST_MATURITY
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_UCITS_INST_MATURITY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT DISTINCT titres.sicovam
	,titres.reference
	,titres.libelle
	,decode(titres.type, 'S', titres.emission, titres.dateregl) start_date
	,decode(titres.type, 'S', titres.datefinal, titres.finper) Maturity_date
FROM titres
INNER JOIN histomvts
	ON histomvts.sicovam = titres.sicovam
INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_UCITS_FUND) -- UCITS funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY
	ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
WHERE titres.type NOT IN (
		'K'
		,'E'
		)
	AND (
		(
			titres.type = 'S'
			AND titres.emission > titres.datefinal
			)
		OR (
			titres.type != 'S'
			AND titres.dateregl > titres.finper
			)
		)
;

-- *****************************************************************
-- END OF: EMIR_UCITS_INST_MATURITY
-- *****************************************************************

 END EMIR_UCITS_INST_MATURITY;
 
 
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_THIRD_PARTY_MISSING_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 feb 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE EMIR_THIRD_PARTY_MISSING_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EMIR_THIRD_PARTY_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT BTG_EMIR_TIERS.tiers_ident Third_party_id
	,tiers.NAME Third_party_name
	,tiers.reference Third_party_Reference
	,group1.NAME Group_Name
	,BTG_EMIR_EEA_ENTITY.NAME EEA_Flag
	,BTG_EMIR_TIERS.lei LEI
	
FROM BTG_EMIR_TIERS

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.PB = BTG_EMIR_TIERS.tiers_ident
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

INNER JOIN tiers group1
ON group1.ident = tiers.mgr

LEFT JOIN BTG_EMIR_EEA_ENTITY
ON BTG_EMIR_EEA_ENTITY.id = BTG_EMIR_TIERS.eea_entity

WHERE BTG_EMIR_TIERS.eea_entity IS NULL
OR BTG_EMIR_TIERS.lei IS NULL;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

EMIR_THIRD_PARTY_MISSING_DATA;

-- *****************************************************************
-- END OF: EMIR_THIRD_PARTY_MISSING_DATA
-- *****************************************************************   


-- *****************************************************************
-- Description:     PROCEDURE  EMIR_FUND_MISSING_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 feb 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE EMIR_FUND_MISSING_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EMIR_FUND_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT DISTINCT BTG_EMIR_TIERS.tiers_ident Fund_id
	,tiers.NAME Fund_name
	,tiers.reference Fund_Reference
	,BTG_EMIR_EEA_ENTITY.NAME EEA_Flag
	,BTG_EMIR_TIERS.lei LEI
	
FROM BTG_EMIR_TIERS

INNER JOIN titres
ON titres.code_emet = BTG_EMIR_TIERS.tiers_ident

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.fund = titres.sicovam
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

INNER JOIN tiers group1
ON group1.ident = tiers.mgr

LEFT JOIN BTG_EMIR_EEA_ENTITY
ON BTG_EMIR_EEA_ENTITY.id = BTG_EMIR_TIERS.eea_entity

WHERE BTG_EMIR_TIERS.eea_entity IS NULL
OR BTG_EMIR_TIERS.lei IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

-- *****************************************************************
-- END OF: EMIR_FUND_MISSING_DATA
-- ***************************************************************** 

EMIR_FUND_MISSING_DATA;

  -- *****************************************************************
  -- Description: PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 16 June 2015     Gustavo Binnie    Created.
  -- 19 OCT 2015      Davi Xavier       Moved from PCKG_BTG_EMAILER_EXCEPTION_BO
  
PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: HKD_FUT_OPTION_NOT_IN_UBS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT		
          
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, PB.NAME                               Depositary
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Sec.libelle                           Instrument_Name
					, Sec.reference                         Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
        FROM histomvts Trades
				inner join titres Sec
				on Trades.sicovam = Sec.sicovam
				INNER JOIN
					(   SELECT 
						CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
						CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
						FOLIO.ident                                                         AS STRATEGY_ID ,
						FOLIO.name                                                          AS STRATEGY_NAME ,
						level
						FROM FOLIO
						WHERE LEVEL                                        >= 4
						START WITH FOLIO.ident                            IN (14414, 90565) -- Primary funds and UCITs funds
						CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
					) FUND_BOOK_STRATEGY 
				ON          FUND_BOOK_STRATEGY.STRATEGY_ID                = Trades.OPCVM 
				INNER JOIN  business_events
				ON          business_events.id                            = Trades.type
				INNER JOIN  riskusers trader
				ON          trader.ident                                  = Trades.operateur
        INNER JOIN  tiers PB
				ON          PB.IDENT                                      = Trades.DEPOSITAIRE
        LEFT JOIN extrnl_ref_market_value mc
        ON          mc.market                                     = Sec.marche
        AND         mc.currency                                   = Sec.devisectt
        AND         mc.ref_ident                                  = 7
        LEFT JOIN btg_mapping_CODE BM
        ON          BM.INPUT_CODE                                 = Sec.MARCHE
        AND         BM.TYPE_ID                                    = 23
        AND         BM.SOURCE_ID                                  = 3
        WHERE         
             Trades.BACKOFFICE						          NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
        AND 
        (
            (Sec.TYPE = 'F' AND BM.OUTPUT_CODE='XHKF') -- HKD FUTURES - Market HKFE - Hong Kong Future Exchange
             OR
            (sec.AFFECTATION = 10 AND sec.DEVISECTT=55069508 and (mc.value='XHKF' or mc.value = 'XHKG')) --HKD OPTIONS (Market HKG - Hong Kong Stock Exchange or HKFE - Hong Kong Future Exchange)
        )
        AND UPPER(PB.NAME) NOT LIKE '%UBS%%ETD%' --NOT UBS ETD Depositaries
        AND Trades.DATENEG > TRUNC(SYSDATE-30)  
        ;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

-- *****************************************************************
-- END OF: HKD_FUT_OPTION_NOT_IN_UBS
-- *****************************************************************  

END

HKD_FUT_OPTION_NOT_IN_UBS;

-- *****************************************************************
-- Description: PROCEDURE CORR_SW_BAD_FX
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 03 DEC 2015      PMOG-877
-- *****************************************************************
  
PROCEDURE CORR_SW_BAD_FX(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CORR_SW_BAD_FX
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
            TITRES.sicovam                                                      Sicovam
          , TITRES.libelle                                                      Instrument_Name
          , TITRES.reference                                                    Instrument_reference
          , CASE
                WHEN DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
                      AND TITRES.FOREX_ORDER1 NOT IN (1,2)  --no FX pair direction chosen
                            THEN 'Rec Leg Missing FX pair'
                WHEN DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) 
                      AND TITRES.FOREX_ORDER1 NOT IN (1,2)  --no FX pair direction chosen
                            THEN 'Pay Leg Missing FX pair'
                WHEN DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
                      AND TITRES.j1refcon3 = 0 --FX rate = 0
                            THEN 'Rec Leg Missing FX rate'
                WHEN DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) 
                      AND TITRES.j2refcon3 = 0 --FX rate = 0
                            THEN 'Pay Leg Missing FX pair'
                ELSE 'Unknown'
            END                                                                 Problem
          , BTG_FN_AUDIT_INST_USER(TITRES.sicovam)                              Sophis_User
FROM      TITRES
WHERE 
          TITRES.modele = 'Correlation Swap'
AND  
    (
      (
          (
          DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
          AND
          TITRES.FOREX_ORDER1 NOT IN (1,2) --no FX pair direction chosen
          )
          OR
          (
          DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) --Pay leg ccy <> swap ccy
          AND
          TITRES.FOREX_ORDER2 NOT IN (1,2) --no FX pair direction chosen
          )
      )
      OR
      (
          (
          DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
          AND
          TITRES.j1refcon3 = 0 --FX rate = 0
          )
          OR
          (
          DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) --Pay leg ccy <> swap ccy
          AND
          TITRES.j2refcon3 = 0 --FX rate = 0
          )
      )
    )
;

END

CORR_SW_BAD_FX;

-- *****************************************************************
-- END OF: CORR_SW_BAD_FX
-- ***************************************************************** 

END PCKG_BTG_EMAILER_CRITICAL;