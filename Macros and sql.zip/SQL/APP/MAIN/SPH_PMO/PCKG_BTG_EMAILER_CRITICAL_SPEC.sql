create or replace
PACKAGE            "PCKG_BTG_EMAILER_CRITICAL" 
AS

	TYPE T_CURSOR IS REF CURSOR;


  
  -- *****************************************************************
  -- Description: PROCEDURE CASH_DIR_WRONG
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE CASH_DIR_WRONG
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE UST_ACC_CHECK
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE UST_ACC_CHECK
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE TRADES_NOT_IN_STRAT
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE TRADES_NOT_IN_STRAT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE TRADEFUND_NOT_FOLIOFUND
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE TRADEFUND_NOT_FOLIOFUND
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE FXOPTION_EXERCISE_WITH_CASH
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE FXOPTION_EXERCISE_WITH_CASH
	(
		p_CURSOR OUT T_CURSOR
	);

  

  -- *****************************************************************
  -- Description: PROCEDURE TRADE_DEAD_CCY
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE TRADE_DEAD_CCY
	(
		p_CURSOR OUT T_CURSOR
	);
 

  
  -- *****************************************************************
  -- Description: PROCEDURE BOND_WRONG_DEP
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE BOND_WRONG_DEP
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE MBS_EURO_WRONG_DEP
	--
  -- Author:          Matt Kelly
  --
  -- Revision History
  -- Date				Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 05/06/2013			Matt Kelly		Created.
  -- *****************************************************************
	PROCEDURE MBS_EURO_WRONG_DEP
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE EQ_1_2_STRAT_TRADE
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE EQ_1_2_STRAT_TRADE
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE FOCUS_ELECTRONIC_TRADES
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE FOCUS_ELECTRONIC_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE EQTEAM_WRONG_UBS_ETD
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
	PROCEDURE EQTEAM_WRONG_UBS_ETD
	(
		p_CURSOR OUT T_CURSOR
	);
  

  
  -- *****************************************************************
  -- Description: PROCEDURE UST_NON_1000
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE UST_NON_1000
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description:  PROCEDURE NY_ETD_WRONG_ACCOUNT
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE NY_ETD_WRONG_ACCOUNT
	(
		p_CURSOR OUT T_CURSOR
	);
  

  
  
  -- *****************************************************************
  -- Description: PROCEDURE ENTITY_WRONG_ACCT
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE ENTITY_WRONG_ACCT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE TRADE_MISS_CP_DEP_BKR
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE TRADE_MISS_CP_DEP_BKR
	(
		p_CURSOR OUT T_CURSOR
	);
      
 
  
  -- *****************************************************************
  -- Description: PROCEDURE TRADES_EQ_WRONG_ACCT
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE TRADES_EQ_WRONG_ACCT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  

  
  -- *****************************************************************
  -- Description: PROCEDURE TRADE_FX_RATE_WRONG
	--
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 28 Feb 2013    Oliver South    FX = 0 caused EOD failure
  -- *****************************************************************
  PROCEDURE TRADE_FX_RATE_WRONG
	(
		p_CURSOR OUT T_CURSOR
	);



  

  
 



 -- *****************************************************************
 -- Description:     PROCEDURE  US_RATES_TRADES_BAD_ALLOTMENT
 --                  
 --
 -- Author:          Ami Talati
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 29 Aug 2013      Ami Talati       Created.
 -- *****************************************************************  
 
   PROCEDURE US_RATES_TRADES_BAD_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	); 


 -- *****************************************************************
 -- Description:     PROCEDURE  EXEC_FEES_NOT_CHILD_FEES
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 20 Nov 2013     Oliver South       Created.
 -- *****************************************************************  
 
   PROCEDURE EXEC_FEES_NOT_CHILD_FEES
	(
		p_CURSOR OUT T_CURSOR
	); 

 -- *****************************************************************
 -- Description:     PROCEDURE  CPP_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 31 Jan 2014     Gustavo Binnie       Created.
 -- *****************************************************************  
 
   PROCEDURE CPP_RESTRICTED_LIST_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);  

  
-- *****************************************************************
-- Description:     PROCEDURE  TRADE_DIR_DIFF_BLOCK_DIR
--
-- Author:          Oliver South
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 FEB 2014      Oliver South            Created.
-- ***************************************************************** 

  PROCEDURE TRADE_DIR_DIFF_BLOCK_DIR

	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  TRADE_EQ_MISS_BR_CODE
--
-- Author:          Oliver South
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 15 JUL 2014      Oliver South            Created.
-- ***************************************************************** 

  PROCEDURE TRADE_EQ_MISS_BR_CODE

	(
		p_CURSOR OUT T_CURSOR
	);

				
-- *****************************************************************
-- Description:     PROCEDURE  US_RATES_RESTRICTED_LIST
--
-- Author:          Ami Talati
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 SEP 2014      Ami Talati            Created.
-- *****************************************************************

   PROCEDURE US_RATES_RESTRICTED_LIST
   
	(
					p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE NDF_BACK_TO_FRONT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  

	  PROCEDURE NDF_BACK_TO_FRONT
	(
		p_CURSOR OUT T_CURSOR
	);
  				
  -- *****************************************************************
-- Description:     PROCEDURE     ABS_IN_NON_USMORT
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 24 Nov 2014      Davi Xavier   Created.
-- *****************************************************************  


	  PROCEDURE ABS_IN_NON_USMORT
	(
		p_cursor out t_cursor
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  AML_RESTRICTED_LIST
--
-- Author:          Ami Talati
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 NOV 2014      Ami Talati            Created.
-- *****************************************************************

   PROCEDURE AML_RESTRICTED_LIST
   
	(
					p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  EUROPEAN_ABS_RESTRICTED_LIST
--
-- Author:          Ami Talati
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 28 NOV 2014      Ami Talati            Created.
-- *****************************************************************

   PROCEDURE EUROPEAN_ABS_RESTRICTED_LIST
   
	(
					p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  CROSS_ASSET_RESTRICTED_LIST
--
-- Author:          Ami Talati
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JAN 2015      AMI TALATI            Created.					

PROCEDURE CROSS_ASSET_RESTRICTED_LIST
   
	(
					p_CURSOR OUT T_CURSOR
	);
 
 -- *****************************************************************
-- Description:     PROCEDURE  TRADE_REST_CCY
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 06 FEB 2015      Oliver              Created.					

PROCEDURE TRADE_REST_CCY
   
	(
					p_cursor out t_cursor
	);
 -- *****************************************************************
-- Description:     PROCEDURE  SHORT_MBS
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 APR 2015      Oliver              Created.					
-- 29 APR 2015      Davi                Arrange to be added to the critical errors Package

PROCEDURE SHORT_MBS
   
	(
					p_cursor out t_cursor
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  TRADE_WRONG_TYPESICO
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30 APR 2015      Oliver              Created.					
-- 30 APR 2015      Davi                Arrange to be added to the critical errors Package

PROCEDURE TRADE_WRONG_TYPESICO
   
	(
					p_cursor out t_cursor
	);


   -- *****************************************************************
-- Description:     PROCEDURE  PURCHSALE_QTY_0
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUN 2015      Gustavo Binnie      Created.
-- *****************************************************************				

  PROCEDURE PURCHSALE_QTY_0
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  FEES_ON_EV
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 18 AUG 2015      Oliver      Created.
-- 18 AUG 2015      Davi        Arranged the release with AS
-- *****************************************************************				

  PROCEDURE FEES_ON_EV
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  NY_ETD_WRNG_ACCT_EQ
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 04 SEP 2015      Oliver              Created.					
-- 04 SEP 2015      Davi                Arranged the release with AS					

  PROCEDURE NY_ETD_WRNG_ACCT_EQ
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  TRADE_BOND_MIN_SIZE
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 SEP 2015      Oliver              Created.					
-- 16 SEP 2015      Davi                Arranged the release with AS					

  PROCEDURE TRADE_BOND_MIN_SIZE
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  EMIR_LEI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      Jun Guan              Created.						

  PROCEDURE EMIR_LEI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  EMIR_UTI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      Jun Guan              Created.						

  PROCEDURE EMIR_UTI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	);
      
        
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_ISDA_LAW_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      Jun Guan              Created.						

  PROCEDURE EMIR_ISDA_LAW_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	);
  
          
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_CONFIRM_DATE
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      Jun Guan              Created.						

  PROCEDURE EMIR_CONFIRM_DATE
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  EMIR_UCITS_INST_MATURITY
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      Jun Guan              Created.						

  PROCEDURE EMIR_UCITS_INST_MATURITY
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
   -- *****************************************************************
-- Description:     PROCEDURE  EMIR_THIRD_PARTY_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 FEB 2014      JUN GUAN            Created.
-- ***************************************************************** 

  PROCEDURE EMIR_THIRD_PARTY_MISSING_DATA

	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_FUND_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 FEB 2014      JUN GUAN            Created.
-- ***************************************************************** 

  PROCEDURE EMIR_FUND_MISSING_DATA

	(
		p_CURSOR OUT T_CURSOR
	);
    
  
	-- *****************************************************************
  -- Description: PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 16 June 2015     Gustavo Binnie    Created.
  -- 19 OCT 2015      Davi Xavier       Moved from PCKG_BTG_EMAILER_EXCEPTION_BO
  -- *****************************************************************
  PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS
	(
		p_CURSOR OUT T_CURSOR
	);
  
    
-- *****************************************************************
-- Description: PROCEDURE CORR_SW_BAD_FX
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 03 DEC 2015      PMOG-877
-- *****************************************************************

  PROCEDURE CORR_SW_BAD_FX
	(
		p_CURSOR OUT T_CURSOR
	);
  
END PCKG_BTG_EMAILER_CRITICAL;