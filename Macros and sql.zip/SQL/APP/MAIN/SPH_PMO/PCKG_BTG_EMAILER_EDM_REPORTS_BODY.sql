create or replace PACKAGE BODY "PCKG_BTG_EMAILER_EDM_REPORTS" AS




-- *****************************************************************
-- Description:     PROCEDURE UNNECESSARY_SEDOLS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author			Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2015		Matt Kelly      Created.
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- *****************************************************************
PROCEDURE UNNECESSARY_SEDOLS_REPORT (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: UNNECESSARY_SEDOLS_REPORT
	-- *****************************************************************
	OPEN p_CURSOR
	FOR


select  t.sicovam
        ,t.libelle    Instrument_Name
        ,t.reference  Instrument_Reference
        ,a.libelle    Allotment
        ,sedol.value  Sedol
        ,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
        
from titres t

left join affectation a
  on t.affectation = a.ident
  
left join extrnl_references_instruments sedol
  on t.sicovam = sedol.sophis_ident
    and ref_ident = 2
    
where sedol.value is not null
 AND t.reference NOT LIKE ('*%') 
and t.affectation not in (
46,  --External fund series
45,  --External funds
18,  --Listed Warrants
1,  --Others
14,  --Packages
1140,  --Share - Dummy
4,  --Shares
1500,  --Shares - ADR and GDR
1502,  --Shares - ETF
1601,  --Shares - MLP
1701, --Shares - REIT
1504,  --Shares - Suspended
1600,  --Shares - Preferred
1505,  --Shares - Ticker Change
1102  --TRS(Fully Funded)
)   
;


  -- *****************************************************************
  -- END OF: UNNECESSARY_SEDOLS_REPORT
  -- *****************************************************************

END  UNNECESSARY_SEDOLS_REPORT;


-- *****************************************************************
-- Description:     PROCEDURE NEW_MARKETS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 14 NOV 2013    Matt Kelly      Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- *****************************************************************
PROCEDURE NEW_MARKETS_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: NEW_MARKETS_REPORT
	-- *****************************************************************
	OPEN p_CURSOR
	FOR

	SELECT num_to_str(marche.mnemomarche) "Market Code"
		,marche.libelle "Market Name"
		,marche.modelemarche "Model"
		,devise_to_str(marche.codedevise) "Currency"
		,place.libelle "Ccy Site"
		,marche.DECALAGEREGLEMENT "Delivery"
		,marche.DECALAGEPAIEMENT "Payment Offset"
		,DECODE(marche.EX_DIVIDEND_DATE_CALC_TYPE, 0, 'European', 1, 'American') "Type of Ex-Div Date Calc"
		,marche.DECIMALESCC "Acc Interest Decimal Units"
		,ISO_Code.value CTRY_ISO_Code
		,MIC_Code.value MIC_Code
		,ESMA_REGULATED.value ESMA_Regulated
		,CHECKED_BY_EDM.value Checked_By_EDM
	FROM marche
	LEFT JOIN extrnl_ref_market_value ESMA_REGULATED
		ON ESMA_REGULATED.market = marche.mnemomarche
			AND ESMA_REGULATED.currency = marche.codedevise
			AND ESMA_REGULATED.ref_ident = 8
	LEFT JOIN extrnl_ref_market_value MIC_Code
		ON MIC_Code.market = marche.mnemomarche
			AND MIC_Code.currency = marche.codedevise
			AND MIC_Code.ref_ident = 7
	LEFT JOIN extrnl_ref_market_value ISO_Code
		ON ISO_Code.market = marche.mnemomarche
			AND ISO_Code.currency = marche.codedevise
			AND ISO_Code.ref_ident = 6
	LEFT JOIN place
		ON marche.placedecotationv2 = place.code
	LEFT JOIN extrnl_ref_market_value CHECKED_BY_EDM
		ON CHECKED_BY_EDM.market = marche.mnemomarche
			AND CHECKED_BY_EDM.currency = marche.codedevise
			AND CHECKED_BY_EDM.ref_ident = 9
	WHERE CHECKED_BY_EDM.value IS NULL
		OR CHECKED_BY_EDM.value <> 'Y'
	ORDER BY marche.libelle;
  -- *****************************************************************
  -- END OF: NEW_MARKETS_REPORT
  -- *****************************************************************

END  NEW_MARKETS_REPORT;



-- *****************************************************************
-- Description:     PROCEDURE EQUITY_EXCEPTION_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 02 MAY 2013    Matt Kelly      Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- 03 JUL 2014    Matt Kelly      Added Market at EDM's request
-- 30 JUL 2014	  Matt Kelly	  Added Allotment at EDM's request
-- 14 AUG 2014	  Matt Kelly	  Added space logic for instrument name and reference
-- 08 OCT 2015    Matt Kelly      Added "Rights Issues" to list of allotments
-- 09 DEC 2016	  Gustavo Binnie  PMOG-1050 - Checks Pricing Ticker 	
-- 02 NOV 2017    Jeff Yu     PMOG-1138 Add filter to exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- *****************************************************************
PROCEDURE EQUITY_EXCEPTION_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: EQUITY_EXCEPTION_REPORT
	-- *****************************************************************
	OPEN p_CURSOR
	FOR


	SELECT titres.sicovam Sicovam
		,titres.libelle Instrument_Name
		,titres.reference Instrument_Reference
		,affectation.libelle Allotment
		,REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
				case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
				case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
				case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
				case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
				case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
			  
			  case when titres.SICOVAM IS NULL then 'SICOVAM' ELSE NULL END || ',' ||
			  case when titres.libelle IS NULL then 'Name' ELSE NULL END || ',' ||
			  case when titres.reference IS NULL then 'Reference' ELSE NULL END || ',' ||
			  case when titres.marche = 0 then 'Market' ELSE NULL END || ',' ||
			  case when ticker.servisen IS NULL then 'Ticker' ELSE NULL END || ',' ||
			  case when ISIN.value IS NULL then 'ISIN' ELSE NULL END || ',' ||
			  case when SEDOL.VALUE is null then 'SEDOL' ELSE NULL END || ',' ||
			  case when cusip.value IS NULL AND extrnl_ref_market_value.ref_ident = 7 AND extrnl_ref_market_value.value = 'Y' AND (titres.reference LIKE '%US Equity%' OR titres.reference LIKE '%UQ Equity%' OR titres.reference LIKE '%CN Equity%') then 'CUSIP' ELSE NULL END || ',' ||
			  case when titres.nbtitres IS NULL then 'Shares Outstanding' ELSE NULL END || ',' ||
			  case when risk.code IS NULL then 'Country_Of_Risk' ELSE NULL END || ',' ||
			  case when domicile.code IS NULL then 'Country_Of_Domicile' ELSE NULL END || ',' ||
			  case when incorp.code IS NULL then 'Country_Of_Incorp' ELSE NULL END || ',' ||
			  case when issue.code IS NULL then 'Country_Of_Issue' ELSE NULL END || ',' ||
			  case when GLOB_CODE.VALUE IS NULL then 'Global_Code' ELSE NULL END || ',' ||
			  case when titres.reference NOT LIKE '% Equity' AND titres.reference NOT LIKE '%Pfd%' then 'Wrong Reference' ELSE NULL END || ',' ||
			  case when fidlist.item NOT IN (- 7,5) AND titres.reference NOT LIKE '%UN Equity' AND titres.reference NOT LIKE '%UQ Equity' AND titres.reference NOT LIKE '%UW Equity' AND titres.reference NOT LIKE '%UA Equity' AND titres.reference NOT LIKE '%UB Equity' AND titres.reference NOT LIKE '%JT Equity' then 'Wrong FID' ELSE NULL END || ',' ||
			  case when Issuer.libelle IS NULL then 'Issuer_Name' ELSE NULL END || ',' ||
			  case when Issuer.reference IS NULL then 'Issuer_Ref' ELSE NULL END || ',' ||
			  case when Issuer.libelle like '%to be created%' then 'Issuer_Name-TO_BE_CREATED' ELSE NULL END || ',' ||
			  case when Issuer.reference like '%to be created%' then 'Issuer_Ref-TO_BE_CREATED' ELSE NULL END || ',' ||
			  case when sectors.NAME IS NULL then 'Bloomberg_Country' ELSE NULL END || ',' ||
			  case when TITRES.beta IS NULL then 'Beta' ELSE NULL END || ',' ||                    
			  case when id_bb_company.value is null then 'ID_BB_COMPANY' ELSE NULL END || ',' ||
			  case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END || ',' ||
			  case when TICKER.servisen IS NULL OR TICKER.prefixe != 'Global' OR TICKER.prefixe IS NULL then 'Pricing Ticker' ELSE NULL END 
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
			 "MISSING_DATA"
        ,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
        
	FROM titres
	LEFT JOIN extrnl_references_instruments ISIN
		ON titres.sicovam = ISIN.sophis_ident
			AND ISIN.ref_ident = 1
	LEFT JOIN extrnl_references_instruments SEDOL
		ON titres.sicovam = SEDOL.sophis_ident
			AND SEDOL.ref_ident = 2
	LEFT JOIN ric TICKER
		ON titres.sicovam = ticker.sicovam
	LEFT JOIN extrnl_references_instruments CUSIP
		ON titres.sicovam = CUSIP.sophis_ident
			AND CUSIP.ref_ident = 3
	--CNTRY OF DOMICILE
	LEFT JOIN sector_instrument_association sia2
		ON titres.sicovam = sia2.sicovam
			AND sia2.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5347
				)
	LEFT JOIN sectors domicile
		ON sia2.sector = domicile.id
	--CNTRY OF RISK
	LEFT JOIN sector_instrument_association sia3
		ON titres.sicovam = sia3.sicovam
			AND sia3.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5350
				)
  --CNTRY OF INCORP
	LEFT JOIN sector_instrument_association sia4
		ON titres.sicovam = sia4.sicovam
			AND sia4.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5348
				)
  LEFT JOIN sectors incorp
		ON sia4.sector = incorp.id
        
	--CNTRY OF ISSUE
	LEFT JOIN sector_instrument_association sia5
		ON titres.sicovam = sia5.sicovam
			AND sia5.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5349
				)
  LEFT JOIN sectors issue
		ON sia5.sector = issue.id
        
	LEFT JOIN sectors risk
		ON sia3.sector = risk.id
	LEFT JOIN extrnl_references_instruments GLOB_CODE
		ON titres.sicovam = GLOB_CODE.sophis_ident
			AND GLOB_CODE.ref_ident = 666
	LEFT JOIN fidlist
		ON TICKER.fid = fidlist.item
	LEFT JOIN titres Issuer
		ON Issuer.sicovam = titres.base1
	LEFT JOIN marche
		ON titres.marche = marche.mnemomarche
			AND titres.devisectt = marche.codedevise
	-- Extra Cusip logic
	LEFT JOIN extrnl_ref_market_value
		ON marche.mnemomarche = extrnl_ref_market_value.market
			AND extrnl_ref_market_value.ref_ident = 7
			AND extrnl_ref_market_value.value = 'Y'
	LEFT JOIN sector_instrument_association sia
		ON titres.sicovam = sia.sicovam
			AND sia.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 1364
				)
	LEFT JOIN sectors
		ON sia.sector = sectors.id    
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674      
   LEFT JOIN extrnl_references_instruments ADR_UND_ISIN
    on titres.sicovam = ADR_UND_ISIN.sophis_ident
      and ADR_UND_ISIN.ref_ident = 672
   LEFT JOIN extrnl_references_instruments ADR_SH_PER_ADR
    on titres.sicovam = ADR_SH_PER_ADR.sophis_ident
      and ADR_SH_PER_ADR.ref_ident = 681      
   LEFT JOIN extrnl_references_instruments ADR_UND_Security
    on ADR_UND_Security.VALUE = ADR_UND_ISIN.value
      and ADR_UND_Security.ref_ident=1
	LEFT JOIN affectation
		on titres.affectation = affectation.ident
	WHERE titres.type = 'A'
		AND titres.affectation IN (
			4
			,1500
			,1502
			,1601
			,1751
			) --Shares, Shares - ADR/GDR, Shares - ETF, Shares - MLP, Rights Issues
        AND  titres.reference NOT LIKE ('*%') 
		AND (
			titres.SICOVAM IS NULL
			OR titres.libelle IS NULL
			OR titres.reference IS NULL
			OR (titres.marche = 0 AND titres.affectation not in (1502))
			OR ticker.servisen IS NULL
			OR ISIN.value IS NULL
			OR SEDOL.value IS NULL
			OR (
				cusip.value IS NULL
				AND extrnl_ref_market_value.ref_ident = 7
				AND extrnl_ref_market_value.value = 'Y'
				AND (
					titres.reference LIKE '%US Equity%'
					OR titres.reference LIKE '%UQ Equity%'
					OR titres.reference LIKE '%CN Equity%'
					)
				)
			OR titres.nbtitres IS NULL
			OR risk.code IS NULL
			OR domicile.code IS NULL
      OR incorp.code IS NULL
      OR issue.code IS NULL
			OR GLOB_CODE.VALUE IS NULL
			OR (
				titres.reference NOT LIKE '% Equity'
				AND titres.reference NOT LIKE '%Pfd%'
				)
			OR (fidlist.item NOT IN (
				- 7
				,5
				) 
        AND titres.reference NOT LIKE '%UN Equity'
        AND titres.reference NOT LIKE '%UQ Equity'
        AND titres.reference NOT LIKE '%UW Equity'
        AND titres.reference NOT LIKE '%UA Equity'
        AND titres.reference NOT LIKE '%UB Equity'
        AND titres.reference NOT LIKE '%JT Equity'        
        )--('EQ No Live - LAST Close','EQ LAST Live - LAST Close')
			OR Issuer.libelle IS NULL
			OR Issuer.reference IS NULL
			OR Issuer.reference like '%to be created%'
			OR Issuer.libelle like '%to be created%'
			OR sectors.NAME IS NULL
			OR TITRES.beta IS NULL
      OR id_bb_company.value is null
      OR ID_BB_UNIQUE.value is null
      OR (
				TICKER.servisen IS NULL
				OR TICKER.prefixe != 'Global'
				OR TICKER.prefixe IS NULL
				) -- pricing ticker is missing/bad set up
      
			)
	ORDER BY 2;



-- *****************************************************************
-- END OF: EQUITY_EXCEPTION_REPORT
-- *****************************************************************
END

EQUITY_EXCEPTION_REPORT;


-- *****************************************************************
-- Description:     PROCEDURE  FUT_MISSING_DATA
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan          Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- 14 AUG 2014	  Matt Kelly	  Added space logic for instrument name and reference
-- 02 NOV 2017    Jeff Yu     PMOG-1138 Add filter to exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 09 NOV 2017    Jeff Yu     PMOG-1171  Replace "BTG Notional" with "Notionnel" due to sophis 7 UI change.
-- 04 DEC 2017     Jeff Yu     PMGMPMO-243  Add logic to flag bond futures having underly.code setup.
-- 12 DEC 2017     Jeff Yu     PMOG-1177  Add logic to check ISIN for both sec and underlyer level.
-- 15 DEC 2017    Jeff Yu     PMOG-1180  Revert changes made in PMOG-1168 and Update filter to only look into Maturity Date
-- ***************************************************************** 
PROCEDURE FUT_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: FUT_MISSING_DATA
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

SELECT DISTINCT TITRES.sicovam Sicovam
		,TITRES.libelle Instrument_Name
		,TITRES.reference Instrument_Reference
		,r.servisen TICKER
    ,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
		
			case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
			case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
			case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
			case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
			case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
			case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		
        case when (r.servisen IS NULL or ((r.prefixe != 'Global' OR r.prefixe IS NULL) and upper(titres.reference) not like '%COMDTY%') OR r.fid = 0) and TITRES.affectation !=1020 then 'Pricing Ticker' ELSE NULL END || ',' || --pricing ticker is missing/bad set up
        case when futmarket.nom IS NULL then 'Market' ELSE NULL END || ',' || -- market is missing
				case when	(TITRES.code_EMET IS NULL OR TITRES.code_EMET = 0 ) AND (TITRES.modele NOT IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future')) then 'Underlying' ELSE NULL END || ',' ||  --underlying missing, except where bond future
        case when UBS_REF.value IS NULL AND titres.affectation != 1020 then 'SwissKey_Code' ELSE NULL END || ',' || --missing swisskey code/excludes dividend futures
        case when	exch_Product_code.value IS NULL then 'Exchange Product Code' ELSE NULL END || ',' ||
        case when	CreditSuisse.value IS NULL then 'CreditSuisse' ELSE NULL END || ',' ||
        case when	CUSIP.value IS NULL AND TITRES.REFERENCE LIKE '%Index%' then 'CUSIP' ELSE NULL END || ',' ||
        case when titres.affectation = 1020 AND (inst2.EXTERNREF IS NULL OR (inst2.EXTERNREF LIKE '%Equity%' and (UndISIN.value is null or UndSEDOL.value is null or UndID_BB_COMPANY.value is null))) then 'Underlying_Data' ELSE NULL END || ',' ||
        case when id_bb_company.value is null then 'ID_BB_COMPANY' ELSE NULL END || ',' ||
        case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END || ',' ||
        case when (BTG_GET_INSTRUMENT_TYPE_CODE(TITRES.SICOVAM) = 42 AND TITRES.CODE_EMET <> 0) then 'Bond Future Has Underl.Code Populated' ELSE NULL END   || ',' ||       
        case when (MAP_ESMA.output_code = 'Y' AND ISIN.value is null) then 'ESMA Regulated Y Missing ISIN' ELSE NULL END  || ',' ||     
        case when (TITRES.AFFECTATION = 1020 AND  (MAP_ESMA.output_code = 'Y' AND UndISIN.value is NOT null)) then 'ESMA Regulated Y Dividend Fut Underlyer has ISIN' ELSE NULL END  || ',' ||   
        case when (TITRES.AFFECTATION = 1020 AND  (MAP_ESMA.output_code = 'N' AND UndISIN.value is null)) then 'ESMA Regulated N Dividend Fut Underlyer missing ISIN' ELSE NULL END  
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA" 
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN titres inst2
		ON TITRES.code_EMET = inst2.sicovam
  LEFT JOIN extrnl_references_instruments UndISIN
    on inst2.sicovam = UndISIN.sophis_ident
      and UndISIN.ref_ident = 1
  LEFT JOIN extrnl_references_instruments UndSEDOL
    on inst2.sicovam = UndSEDOL.sophis_ident
      and UndSEDOL.ref_ident = 2     
  LEFT JOIN extrnl_references_instruments UndCUSIP
    on inst2.sicovam = UndCUSIP.sophis_ident
      and UndCUSIP.ref_ident = 3
  LEFT JOIN extrnl_references_instruments UndID_BB_COMPANY
    on inst2.sicovam = UndID_BB_COMPANY.sophis_ident
      and UndID_BB_COMPANY.ref_ident = 673      
	LEFT JOIN marcheorganise futmarket
		ON futmarket.ident = TITRES.marche
	LEFT JOIN ric r
		ON r.sicovam = titres.sicovam
	LEFT JOIN fidlist
		ON fidlist.item = r.fid
	LEFT JOIN extrnl_references_instruments UBS_REF
		ON UBS_REF.sophis_ident = titres.sicovam
			AND UBS_REF.ref_ident = 9
	LEFT JOIN extrnl_references_instruments exch_Product_code
		ON exch_Product_code.sophis_ident = titres.sicovam
			AND exch_Product_code.ref_ident = 25
  LEFT JOIN extrnl_references_instruments CUSIP
		ON CUSIP.sophis_ident = titres.sicovam
			AND CUSIP.ref_ident = 3      
  LEFT JOIN extrnl_references_instruments ISIN
		ON ISIN.sophis_ident = titres.sicovam
			AND ISIN.ref_ident = 1         
  LEFT JOIN extrnl_references_instruments CreditSuisse
		ON CreditSuisse.sophis_ident = titres.sicovam
			AND CreditSuisse.ref_ident = 15
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674       
  LEFT JOIN btg_mapping_code MAP_ESMA 
    ON  titres.marche = MAP_ESMA.input_code 
    AND MAP_ESMA.source_id=3  
    AND MAP_ESMA.type_id=25
         
	WHERE TITRES.type IN ('F') --futures
		AND TITRES.echeance > sysdate - 1  --not expired
		AND TITRES.affectation NOT IN ('33') --FRA
		AND titres.reference NOT LIKE ('*%') 
		AND (
			(
				(r.servisen IS NULL
				or 
        ((r.prefixe != 'Global' OR r.prefixe IS NULL) and upper(titres.reference) not like '%COMDTY%') 
				OR r.fid = 0)
        and TITRES.affectation !=1020
				) --pricing ticker is missing/bad set up
			OR (futmarket.nom IS NULL) -- market is missing
			OR (
				(
					TITRES.code_EMET IS NULL
					OR TITRES.code_EMET = 0
					)
				AND TITRES.modele NOT IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future')
				) --underlying missing, except where bond future
			OR (
				UBS_REF.value IS NULL
				AND titres.affectation != 1020
				) --missing swisskey code/excludes dividend futures
			OR (exch_Product_code.value IS NULL) -- missing ther exchange product code
      OR (CreditSuisse.value IS NULL) -- missing CreditSuisse external reference
      OR (CUSIP.value IS NULL AND TITRES.REFERENCE LIKE '%Index%') -- missing CUSIP
      OR id_bb_company.value is null -- Missing ID_BB_COMPANY
      OR ID_BB_UNIQUE.value is null -- Missing ID_BB_UNIQUE
      OR ( 
             BTG_GET_INSTRUMENT_TYPE_CODE(TITRES.SICOVAM) = 42
       AND TITRES.CODE_EMET <> 0             
             )  ------Bond Future Has Underl.Code Populated
      OR (
          titres.affectation = 1020
          AND
          (
          inst2.EXTERNREF IS NULL
          OR
          (
            inst2.EXTERNREF LIKE '%Equity%' 
            and 
              (   UndISIN.value is null 
              or UndSEDOL.value is null 
              or UndID_BB_COMPANY.value is null 
              ) 
            )
          )
          )--Missing Underlying Data
      OR (
         MAP_ESMA.output_code = 'Y' AND ISIN.value is null
        )  ------Instrument Missing ISIN if market is ESMA Regulated Y
      OR (
          TITRES.AFFECTATION = 1020 
        AND  (MAP_ESMA.output_code = 'Y' AND UndISIN.value is NOT null)
        )   ---ESMA regulated Y dividend future underlyer ISIN should be blank
       OR (
          TITRES.AFFECTATION = 1020 
        AND  (MAP_ESMA.output_code = 'N' AND UndISIN.value is null)
        )   ---ESMA regulated N dividend future underlyer ISIN should NOT be blank  
    
			)
	ORDER BY 2;
		-- *****************************************************************
		-- END OF: FUT_MISSING_DATA
		-- ***************************************************************** 
END

FUT_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  OPT_MISSING_DATA
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan          Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- 14 AUG 2014	  Matt Kelly	  Added space logic for instrument name and reference
-- 02 NOV 2017    Jeff Yu     PMOG-1138 Add filter to exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 12 DEC 2017    Jeff Yu      PMOG-1177  Add logic to check ISIN missing for ESMA regulated Y; add Dividend options into scope.
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE OPT_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: OPT_MISSING_DATA
	-- ***************************************************************** 
	OPEN p_CURSOR
	FOR

SELECT DISTINCT TITRES.sicovam Sicovam
		,TITRES.libelle Instrument_Name
		,affectation.libelle   AS  Allotment
		,TITRES.reference Instrument_Reference
    ,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
		case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
		case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		
        case when r.servisen IS NULL OR r.prefixe != 'Global' OR r.prefixe IS NULL OR r.fid = 0 then 'Pricing Ticker' ELSE NULL END || ',' || --Missing CUSIP
        case when market.libelle IS NULL then 'Market' ELSE NULL END || ',' || -- market is missing
        case when MS_CODE.value IS NULL then 'Exchange Code' ELSE NULL END || ',' ||
        case when	r2.servisen IS NULL OR r2.prefixe != 'Global' OR r2.prefixe IS NULL OR r2.fid = 0 then 'Uly Pricing Ticker' ELSE NULL END || ',' ||
        case when	exch_Product_code.value IS NULL then 'Exchange Product Code' ELSE NULL END || ',' ||
        case when	CUSIP.value IS NULL AND BTG_GET_INSTRUMENT_TYPE(titres.sicovam)='Interest Rate Derivatives' then 'CUSIP' ELSE NULL END || ',' ||
        case when id_bb_company.value is null and UPPER(TITRES.LIBELLE) NOT LIKE '%COMDTY%' AND UPPER(TITRES.REFERENCE) NOT LIKE '%COMDTY%' and TITRES.affectation != 1060 and (BTG_GET_INSTRUMENT_TYPE(titres.sicovam)!='Stock Derivatives' OR titres.affectation != 10) then 'ID_BB_COMPANY' ELSE NULL END || ',' ||
        case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END  || ',' ||
        case when (MARKET_ESMA.value = 'Y' AND ISIN.value is null) then 'ESMA Regulated Y Missing ISIN' ELSE NULL END
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA" 
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN titres inst2
		ON TITRES.code_EMET = inst2.sicovam
	LEFT JOIN marche market
		ON market.mnemomarche = TITRES.marche
			AND market.libelle != 'OTC Market' --not OTC options
			AND market.codedevise = titres.devisectt
	LEFT JOIN ric r
		ON r.sicovam = titres.sicovam
	LEFT JOIN fidlist
		ON fidlist.item = r.fid
	LEFT JOIN affectation
		ON affectation.IDENT = titres.affectation
	LEFT JOIN extrnl_ref_market_value MS_CODE
		ON market.MNEMOMARCHE = MS_CODE.market
			AND MS_CODE.ref_ident = 5
			AND MS_CODE.currency = titres.devisectt
	LEFT JOIN TITRES UNDERLYING
		ON UNDERLYING.sicovam = TITRES.codesJ
	LEFT JOIN ric r2
		ON r2.sicovam = UNDERLYING.sicovam
	LEFT JOIN fidlist f2
		ON f2.item = r2.fid
	LEFT JOIN extrnl_references_instruments exch_Product_code
		ON exch_Product_code.sophis_ident = titres.sicovam
			AND exch_Product_code.ref_ident = 25
  LEFT JOIN extrnl_references_instruments CUSIP
    on titres.sicovam = CUSIP.sophis_ident
      and CUSIP.ref_ident = 3      
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674       
  LEFT JOIN extrnl_ref_market_value MARKET_ESMA 
on titres.marche = MARKET_ESMA.market 
and MARKET_ESMA.ref_ident=8 
and MARKET_ESMA.CURRENCY = titres.devisectt 
left join EXTRNL_REFERENCES_INSTRUMENTS ISIN
on titres.sicovam = ISIN.sophis_ident
and ISIN.REF_IDENT=1    
      
	WHERE TITRES.type IN (
			'M'
			,'D'
			)
		AND TITRES.finper > (SYSDATE - 1) --Not expired
		AND (
      TITRES.affectation IN (10,1041) ----Listed Options/Volatility Options
     OR (TITRES.affectation = 1060 and MARKET_ESMA.value = 'Y') ----ESMA Regulated Dividend Options
			)
        AND titres.reference NOT LIKE ('*%') 
		AND devise_to_str(titres.devisectt) != 'BRL'
		AND (
			(
				r.servisen IS NULL
				OR r.prefixe != 'Global'
				OR r.prefixe IS NULL
				OR r.fid = 0
				) --pricing ticker is missing/bad set up
			OR (market.libelle IS NULL) -- market is missing
			OR (MS_CODE.value IS NULL) -- no exchange code
			OR (
				r2.servisen IS NULL
				OR r2.prefixe != 'Global'
				OR r2.prefixe IS NULL
				OR r2.fid = 0
				) -- Uly pricing ticker is missing/bad set up
			OR (exch_Product_code.value IS NULL) -- missing ther exchange product code      
      OR (
          id_bb_company.value is null 
          and UPPER(TITRES.LIBELLE) NOT LIKE '%COMDTY%' 
          AND UPPER(TITRES.REFERENCE) NOT LIKE '%COMDTY%'
          AND TITRES.affectation != 1060
		      AND (BTG_GET_INSTRUMENT_TYPE(titres.sicovam) != 'Stock Derivatives' OR titres.affectation != 10)
         )     -- Missing ID_BB_COMPANY
      OR ID_BB_UNIQUE.value is null -- Missing ID_BB_UNIQUE      
      OR (
          CUSIP.VALUE IS NULL 
          AND BTG_GET_INSTRUMENT_TYPE(titres.sicovam)='Interest Rate Derivatives'
          ) --Missing CUSIP
      OR (
          MARKET_ESMA.value = 'Y' AND ISIN.value is null
         )  ---ESMA Regulated Y missing ISIN
			)
	ORDER BY 2;

		-- *****************************************************************
		-- END OF: OPT_MISSING_DATA
		-- ***************************************************************** 
END

OPT_MISSING_DATA;


-- *****************************************************************
-- Description:     PROCEDURE  FUT_MARKET_MISSING_DATA
-- Check to see if any Future Markets are missing static data                
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 12 JUN 2013    Jun Guan      Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- 05 MAY 2016	  Gustavo Binnie  GAMACN-24 - ESMA Flag Input Validation
-- ***************************************************************** 
PROCEDURE FUT_MARKET_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: FUT_MARKET_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT marcheorganise.nom MarketName
		,marcheorganise.ident MarketID
		,MIC_Code.output_code MIC_Code
		,ESMA_REGULATED.output_code ESMA_Regulated
	FROM marcheorganise
	LEFT JOIN btg_mapping_code MIC_Code
		ON MIC_Code.input_code = marcheorganise.ident
			AND MIC_Code.source_id = 3
			AND MIC_Code.type_id = 23
	LEFT JOIN btg_mapping_code ESMA_REGULATED
		ON ESMA_REGULATED.input_code = marcheorganise.ident
			AND ESMA_REGULATED.source_id = 3
			AND ESMA_REGULATED.type_id = 25
	WHERE mic_code.output_code IS NULL
		OR DECODE(ESMA_Regulated.output_code,'Y',1,'N',1,0) = 0 --ESMA Y/N is not Y (capital Y) or N (capital N).
	ORDER BY marcheorganise.Nom;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: FUT_MARKET_MISSING_DATA
		-- *****************************************************************   
END

FUT_MARKET_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  MARKET_MISSING_DATA
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- 05 MAY 2016	  Gustavo Binnie  GAMACN-24 - ESMA Flag Input Validation
-- *****************************************************************   
PROCEDURE MARKET_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MARKET_MISSING_DATA
	-- *****************************************************************   		
	OPEN p_CURSOR
	FOR

	SELECT devise_to_str(marche.codedevise) Currency
		,place.libelle PlaceName
		,marche.libelle MarketName
		,marche.mnemomarche MarketID
		,ISO_Code.value CTRY_ISO_Code
		,MIC_Code.value MIC_Code
		,ESMA_REGULATED.value ESMA_Regulated
		,REGEXP_REPLACE
			(
			REGEXP_REPLACE( (
			  
				case when MIC_Code.value IS NULL then 'MIC Code' ELSE NULL END || ',' ||
        case when ISO_Code.value IS NULL then 'CTRY_ISO_Code' ELSE NULL END || ',' ||
			  case when decode(ESMA_REGULATED.value,'Y',1,'N',1,0) = 0 then 'ESMA Flag not valid' ELSE NULL END --ESMA Y/N is not Y (capital Y) or N (capital N).
			  ) 
			  ,',+(,|$)','\1'),
			  '^,'     )
			 MISSING_DATA
	FROM marche
	LEFT JOIN extrnl_ref_market_value ESMA_REGULATED
		ON ESMA_REGULATED.market = marche.mnemomarche
			AND ESMA_REGULATED.currency = marche.codedevise
			AND ESMA_REGULATED.ref_ident = 8
	LEFT JOIN extrnl_ref_market_value MIC_Code
		ON MIC_Code.market = marche.mnemomarche
			AND MIC_Code.currency = marche.codedevise
			AND MIC_Code.ref_ident = 7
	LEFT JOIN extrnl_ref_market_value ISO_Code
		ON ISO_Code.market = marche.mnemomarche
			AND ISO_Code.currency = marche.codedevise
			AND ISO_Code.ref_ident = 6
	LEFT JOIN place
		ON marche.placedecotationv2 = place.code
	WHERE MIC_Code.value IS NULL
		OR ISO_Code.value IS NULL
    OR decode(ESMA_REGULATED.value,'Y',1,'N',1,0) = 0 --ESMA Y/N is not Y (capital Y) or N (capital N).
	ORDER BY marche.libelle;
		-- *****************************************************************
		-- END OF: MARKET_MISSING_DATA
		-- *****************************************************************   
END

MARKET_MISSING_DATA;


-- *****************************************************************
-- Description:     PROCEDURE  CFD_BAD_DATA
--
-- Author:          Jun Guan 
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013   Jun Guan            Created.
-- 14 Aug 2013	 Oliver South	     Added details checking funding/borrow currency
-- 01 JAN 2014   Gustavo Binnie      Moved from EXCEPTION_BO to EDM package.
-- 09 DEC 2016	 Gustavo Binnie		 PMOG-1050 - Check underlying pricing ticker
-- 19 DEC 2016    Jeff Yu           PMOG-1068  Remove unused reference with name start with * from extraction.
-- 30 MAR 2017   Jeff Yu           PMOG-1106  Check CFD Und to only include certain types of shares.
-- 31 OCT 2017    Jeff Yu           PMOG-1082  Exclude those with underlyer expired.
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CFD_BAD_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CFD_BAD_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
		,titres.libelle Instrument_Name
		,titres.reference Instrument_Reference
		,devise_to_str(titres.devisectt) Funding_CCY
		,devise_to_str(titres.deviseac) Stock_Borrow_CCY
		,isin.value ISIN
		,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
        case when titres.devisectt != titres.deviseac AND titres.deviseac != 0 then 'Funding and stock borrow CCY mismatch' ELSE NULL END || ',' ||
        case when	und_ric.servisen IS NULL OR und_ric.prefixe != 'Global' OR und_ric.prefixe IS NULL then 'Uly Pricing Ticker' ELSE NULL END || ',' ||
        case when isin.value IS NOT NULL then 'ISIN on CFD' ELSE NULL END           
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "REASON" 
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN extrnl_references_instruments ISIN
		ON ISIN.sophis_ident = titres.sicovam
			AND ISIN.ref_ident = 1
  LEFT JOIN titres underlying
    ON titres.code_emet = underlying.sicovam
	LEFT JOIN ric und_ric
		ON und_ric.sicovam = UNDERLYING.sicovam    
	WHERE (
       (titres.type = 'G' and underlying.type != 'A') ----Und Non-Shares Allotments
         OR 
       (titres.type = 'G' and underlying.type = 'A' and underlying.affectation IN (4,1500,1502,1601,1751))  --Shares, Shares - ADR/GDR, Shares - ETF, Shares - MLP, Rights Issues
                 )
	AND  titres.reference NOT LIKE ('*%') 
    AND ((underlying.type = 'F' and underlying.ECHEANCE > trunc(sysdate) ) or (underlying.type != 'F' and 1=1)) ----Exclude underlyings expired
		AND (
			(
				titres.devisectt != titres.deviseac
				AND titres.deviseac != 0
				)
			OR isin.value IS NOT NULL
      OR (
				und_ric.servisen IS NULL
				OR und_ric.prefixe != 'Global'
				OR und_ric.prefixe IS NULL
				--OR und_ric.fid = 0
				) -- Uly pricing ticker is missing/bad set up
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: CFD_BAD_DATA
		-- *****************************************************************   
END  CFD_BAD_DATA;


-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISSING_DATA
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author			Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan			Created.
-- 01 JAN 2014    Gustavo Binnie	- Moved from EXCEPTION_BO to EDM package.
--									- Changed the format to display all missing
--                                  data in a single column.
-- 14 AUG 2014	  Matt Kelly		Added space logic for instrument name and reference.
-- 04 AUG 2015    Matt Kelly		- Added check for field IS_UNIT_TRADED.
--									- Added filter to ignore insts with *s in name or ref.
-- 05 MAY 2016	  Gustavo Binnie	GAMACN-24 - ESMA Flag Input Validation
-- 08 NOV 2017    Jeff Yu           PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu           PMOG-1180 (Revert changes made in PMOG-1168)
-- 15 DEC 2017    Jeff Yu           PMOG-980  Add back ABS/MBS/CMBS instruments into scope
-- 30 JAN 2018    Luis Magalhaes    PMOCRR-96 Adding ISIN validations for the Rapptr Project
-- ***************************************************************** 
PROCEDURE BOND_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BOND_MISSING_DATA
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR


SELECT titres.sicovam Sicovam
	,titres.reference   Instrument_Reference
	,titres.libelle     Instrument_Name 
	,affectation.libelle Allotment
	,REGEXP_REPLACE(REGEXP_REPLACE((
				CASE 
					WHEN titres.libelle LIKE ' %'
						THEN 'Leading space in Name'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN titres.libelle LIKE '% '
						THEN 'Trailing space in Name'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN titres.libelle LIKE '%  %'
						THEN 'Double space in Name'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN titres.reference LIKE ' %'
						THEN 'Leading space in Reference'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN titres.reference LIKE '% '
						THEN 'Trailing space in Reference'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN titres.reference LIKE '%  %'
						THEN 'Double space in Reference'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN cusip.value IS NULL
						THEN 'CUSIP'
					ELSE NULL
					END || ',' || --Missing CUSIP
				CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and risk.code IS NULL)
						THEN 'Country_Of_Risk'
					ELSE NULL
					END || ',' || --Missing country of risk
				CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and domicile.code IS NULL)
						THEN 'Country_Of_Domicile'
					ELSE NULL
					END || ',' || --Missing country of domicile
				CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and incorp.code IS NULL)
						THEN 'Country_Of_Incorp'
					ELSE NULL
					END || ',' || --Missing country of incorporation
        CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and is_unit_traded_sector.name IS NULL)
						THEN 'IS_UNIT_TRADED'
					ELSE NULL
					END || ',' || --Missing IS_UNIT_TRADED
				CASE 
					WHEN (titres.affectation = 9 and titres.marche = 0)
						THEN 'Missing Market'
					ELSE NULL
					END || ',' || --Missing market
				CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and issue.code IS NULL)
						THEN 'Country_Of_Issue'
					ELSE NULL
					END || ',' || 
        CASE 
					WHEN (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and decode(esma.value,'Y',1,'N',1,0) = 0)
						THEN 'ESMA_Regulated'
					ELSE NULL
					END || ',' || --ESMA Y/N is not Y (capital Y) or N (capital N).
				CASE 
					WHEN  (
                  issue.code <> 'US'
                  AND issuer.reference IS NULL
                  AND titres.affectation IN (25,26)
                )
            THEN 'Issuer'
          ELSE NULL
					END || ',' || --Missing Issuer 
        CASE
          WHEN (issuer.reference like '%reated%' or issuer.libelle like '%reated%')
            THEN 'ISSUER-TO_BE_CREATED'
					ELSE NULL
					END || ',' || --Issuer to be created
				CASE 
					WHEN id_bb_company.value IS NULL
						THEN 'ID_BB_COMPANY'
					ELSE NULL
					END || ',' || 
        
        -- CHECK IF ISIN IS DIFFERENT FROM REFERENCE FOR BONDS
        CASE
        WHEN isin.value != titres.reference 
            THEN 'ISIN different from Reference'        
        ELSE 
            NULL
        END || ',' || 
        
        -- CHECK IF ISIN IS EMPTY
        CASE
        WHEN isin.value is null
            THEN 'ISIN empty in the External References'
        ELSE 
            NULL
        END || ',' ||         
        
        -- CHECK IF ISIN LOOKS INVALID
        CASE
        WHEN length(isin.value) !=12
            THEN 'ISIN does not seem valid'        
        ELSE 
            NULL
        END || ',' ||         
        
        CASE 
					WHEN ID_BB_UNIQUE.value IS NULL
						THEN 'ID_BB_UNIQUE'
					ELSE NULL
					END
				), ',+(,|$)', '\1'), '^,') "MISSING_DATA"
	,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
  
FROM titres

left join SECTOR_INSTRUMENT_ASSOCIATION is_unit_traded_sia
  on titres.sicovam = is_unit_traded_sia.sicovam
    and is_unit_traded_sia.type = 6540
left join sectors is_unit_traded_sector
  on is_unit_traded_sia.sector = is_unit_traded_sector.id
LEFT JOIN extrnl_references_instruments cusip
	ON titres.sicovam = cusip.sophis_ident
		AND cusip.ref_ident = 3
--CNTRY OF DOMICILE
LEFT JOIN sector_instrument_association sia2
	ON titres.sicovam = sia2.sicovam
		AND sia2.sector IN (
			SELECT id
			FROM sectors
			WHERE parent = 5347
			)
LEFT JOIN sectors domicile
	ON sia2.sector = domicile.id
--CNTRY OF RISK
LEFT JOIN sector_instrument_association sia3
	ON titres.sicovam = sia3.sicovam
		AND sia3.sector IN (
			SELECT id
			FROM sectors
			WHERE parent = 5350
			)
LEFT JOIN sectors risk
	ON sia3.sector = risk.id
--CNTRY OF INCORP
LEFT JOIN sector_instrument_association sia4
	ON titres.sicovam = sia4.sicovam
		AND sia4.sector IN (
			SELECT id
			FROM sectors
			WHERE parent = 5348
			)
LEFT JOIN sectors incorp
	ON sia4.sector = incorp.id
--CNTRY OF ISSUE
LEFT JOIN sector_instrument_association sia5
	ON titres.sicovam = sia5.sicovam
		AND sia5.sector IN (
			SELECT id
			FROM sectors
			WHERE parent = 5349
			)
LEFT JOIN sectors issue
	ON sia5.sector = issue.id
LEFT JOIN titres Issuer
	ON Issuer.sicovam = titres.code_emet
LEFT JOIN extrnl_references_instruments esma
	ON titres.sicovam = esma.sophis_ident
		AND esma.ref_ident = 26
LEFT JOIN affectation
	ON affectation.ident = titres.affectation
LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
	ON titres.sicovam = ID_BB_COMPANY.sophis_ident
		AND ID_BB_COMPANY.ref_ident = 673
LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
	ON titres.sicovam = ID_BB_UNIQUE.sophis_ident
		AND ID_BB_UNIQUE.ref_ident = 674
LEFT JOIN extrnl_references_instruments isin 
          ON titres.sicovam = isin.sophis_ident 
          AND isin.ref_ident = 1 
          
WHERE (
        (titres.type = 'O') --Bond
        OR (titres.type = 'D' AND titres.affectation = 9) --Convertible bonds
      )
AND  titres.reference NOT LIKE ('*%') 
AND (
      titres.affectation NOT IN (
        '1102'
        ,'34'
        ,'13'
        ,'20'
        ,'1180'
        ,'1200'   
        ,'7'
        ,'17'
        ,'1400'   
		,'1801'
      )
		--Excludes: TRS(Fully Funded), TBA, Debt Instruments, Cash, Bond - Dummy, Bond - Time Deposit, Repos, Indexes, Bank Loan, Cash Loan
		OR titres.affectation IS NULL
		)
AND (
      cusip.value IS NULL --Missing CUSIP
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and risk.code IS NULL) --Missing country of risk
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and domicile.code IS NULL) --Missing country of domicile
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and incorp.code IS NULL) --Missing country of incorp
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and is_unit_traded_sector.name IS NULL) --Missing IS_UNIT_TRADED
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and issue.code IS NULL) --Missing country of issue
      OR (titres.affectation NOT IN (35,38,1252,1253,1353,1450) and decode(esma.value,'Y',1,'N',1,0) = 0) --ESMA Y/N is not Y (capital Y) or N (capital N).
      OR id_bb_company.value IS NULL -- Missing ID_BB_COMPANY
      OR ID_BB_UNIQUE.value IS NULL -- Missing ID_BB_UNIQUE
      OR (issue.code <> 'US' AND issuer.reference IS NULL AND titres.affectation IN (25,26))
      OR (issuer.reference like '%reated%' OR issuer.libelle like '%reated%')
      OR (titres.affectation = 9 and titres.marche = 0) --convertibles missing market
      OR isin.value is null or length(isin.value) !=12 or isin.value != titres.reference or length(titres.reference) != 12
		)
ORDER BY 4,3;


		-- *****************************************************************
		-- END OF: BOND_MISSING_DATA
		-- ***************************************************************** 
END

BOND_MISSING_DATA;

-- *****************************************************************
-- Description:   PROCEDURE  ADR_MISSING_UNDERLYING_INFO
-- Author:        Jun Guan
--      
-- Revision History
-- Date           Author        	Reason for Change
-- ----------------------------------------------------------------
-- 01 JAN 2014    Gustavo Binnie  	Created.
-- 14 AUG 2014	  Matt Kelly	  	Added space logic for instrument name and reference
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 05 DEC 2017    Jeff Yu      PMCMIFID2-35  Update logic to flag Shares-ADR/GDR missing CFI_Code in external reference window.
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE ADR_MISSING_UNDERLYING_INFO(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: ADR_MISSING_UNDERLYING_INFO
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR
SELECT  t.sicovam
        , AF.LIBELLE ALLOTMENT
        , BTG_GET_INSTRUMENT_TYPE(T.SICOVAM) INTRUMENT_TYPE
        ,t.libelle "Name"
        ,T.REFERENCE
        , REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
          	case when t.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
			case when t.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
			case when t.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
			case when t.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
			case when t.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
			case when t.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		  
		  case when ADR_UND_SICOVAM.VALUE is null AND T.AFFECTATION IN (18,1500) then 'Underlying Sicovam' ELSE NULL END || ',' ||
          case when ADR_SH_PER_ADR.VALUE is null AND T.AFFECTATION IN (18,1500) then 'Underlying Ratio' ELSE NULL END || ',' ||
          case when ADR_UND_Security.sicovam is null AND T.AFFECTATION IN (18,1500) then 'Underlying Security' ELSE NULL END || ',' ||
          case when T.AFFECTATION=1500 and ADR_CFI_CODE.VALUE IS NULL then 'Missing CFI Code' ELSE NULL END
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
        "MISSING_VALUES"
        ,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
FROM titres t

   LEFT JOIN AFFECTATION AF
   ON AF.IDENT = T.AFFECTATION

   LEFT JOIN ric 
   ON ric.sicovam=t.sicovam
      
   LEFT JOIN extrnl_references_instruments ADR_UND_SICOVAM
    on t.sicovam = ADR_UND_SICOVAM.sophis_ident
      and ADR_UND_SICOVAM.ref_ident = 672

   LEFT JOIN extrnl_references_instruments ADR_SH_PER_ADR
    on t.sicovam = ADR_SH_PER_ADR.sophis_ident
      and ADR_SH_PER_ADR.ref_ident = 681      
      
  LEFT JOIN extrnl_references_instruments ADR_CFI_CODE
    on t.sicovam = ADR_CFI_CODE.sophis_ident
      and ADR_CFI_CODE.ref_ident = 690

   LEFT JOIN TITRES ADR_UND_Security
    on ADR_UND_Security.SICOVAM like ADR_UND_SICOVAM.value

where
      T.TYPE IN 'A'
AND
      T.AFFECTATION IN (1500,18) 
AND   T.reference NOT LIKE ('*%') 
AND ( 
      ADR_UND_SICOVAM.VALUE IS NULL 
      OR 
      ADR_SH_PER_ADR.VALUE IS NULL 
      or 
      ADR_UND_Security.sicovam IS NULL 
      or
      (T.AFFECTATION=1500 and ADR_CFI_CODE.VALUE IS NULL)
     )
order by t.affectation;

		-- *****************************************************************
		-- END OF: ADR_MISSING_UNDERLYING_INFO
		-- ***************************************************************** 
END

ADR_MISSING_UNDERLYING_INFO;



-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_BOND_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 JAN 2014      Matt Kelly            Created.
-- 04 FEB 2014		Gustavo Binnie		- Moved from EXCEPTION_BO to EDM package.
--		                                - Changed the format to display all missing
--			                              data in a single column.
-- 14 AUG 2014	  Matt Kelly	  		Added space logic for instrument name and reference
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CONVERT_BOND_EXCEPTION_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
-- *****************************************************************
-- BEGIN OF: CONVERT_BOND_EXCEPTION_REPORT
-- *****************************************************************   
	OPEN p_CURSOR
	FOR
	
	SELECT  unique titres.sicovam                       SICOVAM
			,titres.reference                           REFERENCE
			,titres.libelle                             NAME
      , REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
			case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
			case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
			case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
			case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
			case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
			case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		
          case when finper = '01-JAN-1904' then 'END PERIOD/PERIOD END DATE' ELSE NULL END || ',' ||
          case when j2refcon1 = 0 then 'PAYMENT DATE/REDEMPTION DATE' ELSE NULL END
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
        "MISSING_VALUES"
        
	FROM titres        
	WHERE affectation = 9 --Convertible
	AND  titres.reference NOT LIKE ('*%') 
    AND (finper = '01-JAN-1904' or j2refcon1 = 0)

	ORDER BY titres.libelle;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END

CONVERT_BOND_EXCEPTION_REPORT;
-- *****************************************************************
-- END OF: CONVERT_BOND_EXCEPTION_REPORT
-- *****************************************************************

-- *****************************************************************
-- Description:     PROCEDURE  TBA_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date   			Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2014		Gustavo Binnie		- Created
-- 14 AUG 2014	  	Matt Kelly	  		Added space logic for instrument name and reference
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE TBA_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
-- *****************************************************************
-- BEGIN OF: TBA_MISSING_DATA
-- *****************************************************************   
	OPEN p_CURSOR
	FOR
	
SELECT titres.sicovam Sicovam
        ,titres.reference Instrument_Reference
        ,titres.libelle Instrument_Name
        ,affectation.libelle Allotment
        ,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
		case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
		case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		
        case when cusip.value IS NULL then 'CUSIP' ELSE NULL END || ',' || --Missing CUSIP
        case when id_bb_company.value is null then 'ID_BB_COMPANY' ELSE NULL END || ',' ||
        case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END           
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA"
        
        ,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN extrnl_references_instruments cusip
		ON titres.sicovam = cusip.sophis_ident
			AND cusip.ref_ident = 3
    
	LEFT JOIN affectation
		ON affectation.ident = titres.affectation
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674 
    
	WHERE 
			titres.type = 'O' --Bond
		AND titres.affectation= 34
       AND titres.reference NOT LIKE ('*%') 
		AND
			titres.finper >= trunc(sysdate)
		AND (
			cusip.value IS NULL --Missing CUSIP
			OR id_bb_company.value is null -- Missing ID_BB_COMPANY
			OR ID_BB_UNIQUE.value is null -- Missing ID_BB_UNIQUE
			) 
	ORDER BY 4
		,3;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END

TBA_MISSING_DATA;
-- *****************************************************************
-- END OF: TBA_MISSING_DATA
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  TRS_FULLY_FUNDED_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 FEB 2014		Gustavo Binnie		- Created
-- 14 AUG 2014	  	Matt Kelly	  		Added space logic for instrument name and reference
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE TRS_FULLY_FUNDED_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
-- *****************************************************************
-- BEGIN OF: TRS_FULLY_FUNDED_MISSING_DATA
-- *****************************************************************   
	OPEN p_CURSOR
	FOR
	
SELECT titres.sicovam Sicovam
        ,titres.reference Instrument_Reference
        ,titres.libelle Instrument_Name
        ,affectation.libelle Allotment
        ,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
		case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
		case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
		case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
		case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
		
		case when cusip.value IS NULL then 'CUSIP' ELSE NULL END || ',' || --Missing CUSIP
        case when domicile.code IS NULL then 'Country_Of_Domicile' ELSE NULL END || ',' ||--Missing country of domicile
        case when incorp.code IS NULL  then 'Country_Of_Incorp' ELSE NULL END || ',' ||--Missing country of incorporation
        case when isin.value IS NULL then 'ISIN' ELSE NULL END || ',' ||       --Missing ISIN
        case when id_bb_company.value is null then 'ID_BB_COMPANY' ELSE NULL END || ',' || -- Missing id_bb_company
        case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END           -- Missing id_bb_unique
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA"
        
        ,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN extrnl_references_instruments cusip
		ON titres.sicovam = cusip.sophis_ident
			AND cusip.ref_ident = 3
	--CNTRY OF DOMICILE
	LEFT JOIN sector_instrument_association sia2
		ON titres.sicovam = sia2.sicovam
			AND sia2.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5347
				)
	LEFT JOIN sectors domicile
		ON sia2.sector = domicile.id    

	--CNTRY OF INCORP
	LEFT JOIN sector_instrument_association sia4
		ON titres.sicovam = sia4.sicovam
			AND sia4.sector IN (
				SELECT id
				FROM sectors
				WHERE parent = 5348
				)
  LEFT JOIN sectors incorp
		ON sia4.sector = incorp.id

	LEFT JOIN extrnl_references_instruments isin
		ON titres.sicovam = isin.sophis_ident
			AND isin.ref_ident = 1
	LEFT JOIN affectation
		ON affectation.ident = titres.affectation
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674 
    
	WHERE 
			--titres.type = 'O') --Bond
			--and
			titres.affectation=1102
	AND   titres.reference NOT LIKE ('*%') 
    AND
      titres.finper >= trunc(sysdate)
		AND (
			cusip.value IS NULL --Missing CUSIP
      OR incorp.code IS NULL --Missing country of incorp
			OR isin.value IS NULL --Missing ISIN
      OR id_bb_company.value is null -- Missing ID_BB_COMPANY
      OR ID_BB_UNIQUE.value is null -- Missing ID_BB_UNIQUE
			) 
	ORDER BY 4
		,3;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END

TRS_FULLY_FUNDED_MISSING_DATA;
-- *****************************************************************
-- END OF: TRS_FULLY_FUNDED_MISSING_DATA
-- *****************************************************************

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_25HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 

PROCEDURE NEW_INSTRUMENTS_T_25HRS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR

SELECT 
      TITRES.reference                                                                                       Reference_Code
		, TITRES.libelle                                                                                     Instrument_Name
		, RISKUSERS.NAME                                                                                     Set_Up_By
		, TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS')                           Created
		, TITRES.sicovam                                                                                     Sicovam
		, btg_get_instrument_type(TITRES.sicovam)                                                            Instrument_Type
		, AFFECTATION.libelle                                                                                Allotment
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       Market
        , decode(titres.type,'S',cds_issuer.reference,'O',bond_issuer.reference)                             Issuer_Reference
        , decode(titres.type,'S',cds_issuer.libelle,'O',bond_issuer.libelle)                                 Issuer_Name
        , decode(titres.type,'S',cds_issuer_cntryofissuer_name.NAME,'O',bond_issuer_cntryofissuer_name.NAME) ISSUER_CNTRY_OF_ISSUE
	    , decode(titres.type,'S',cds_issuer_bloomberg_name.NAME,'O',bond_issuer_bloomberg_name.NAME)         ISSUER_Industry_Sector
    
	FROM TITRES
	INNER JOIN INFOS_HISTO 
    ON TITRES.sicovam = INFOS_HISTO.sicovam
		AND INFOS_HISTO.modif = 1 --just the intial creation
		AND INFOS_HISTO.type_table = 3 --list only the addition to the titres table so we don't get dupes
		AND num_to_date(INFOS_HISTO.date_validite) > SYSDATE - ((1 / 24) * 25) --last day (25 hours)
    
	LEFT JOIN AFFECTATION 
    ON TITRES.affectation = AFFECTATION.ident
	LEFT JOIN RISKUSERS 
    ON infos_histo.userident = RISKUSERS.ident
	LEFT JOIN MARCHE 
    ON TITRES.marche = MARCHE.mnemomarche
		AND TITRES.devisectt = MARCHE.codedevise
	LEFT JOIN MARCHEORGANISE 
    ON TITRES.marche = MARCHEORGANISE.ident
  LEFT JOIN titres cds_issuer
  on cds_issuer.sicovam=titres.coupon1
  
  LEFT JOIN sector_instrument_association cds_issuer_cntryofissue
	ON cds_issuer_cntryofissue.sicovam = cds_issuer.sicovam
	AND cds_issuer_cntryofissue.type = 5349 --Country of Issue
  
  LEFT JOIN sector_instrument_association cds_issuer_bloomberg
	ON cds_issuer_bloomberg.sicovam = cds_issuer.sicovam
	AND cds_issuer_bloomberg.type = 1363 --Bloomberg (Industry sector)
  
  LEFT JOIN sectors cds_issuer_cntryofissuer_name
	ON cds_issuer_cntryofissuer_name.id = cds_issuer_cntryofissue.sector
  
  LEFT JOIN sectors cds_issuer_bloomberg_name
	ON cds_issuer_bloomberg_name.id = cds_issuer_bloomberg.sector
  
  LEFT JOIN titres bond_issuer
  on bond_issuer.sicovam=titres.code_emet
  
  LEFT JOIN sector_instrument_association bond_issuer_cntryofissue
	ON bond_issuer_cntryofissue.sicovam = bond_issuer.sicovam
	AND bond_issuer_cntryofissue.type = 5349 --Country of Issue
  
  LEFT JOIN sector_instrument_association bond_issuer_bloomberg
	ON bond_issuer_bloomberg.sicovam = bond_issuer.sicovam
	AND bond_issuer_bloomberg.type = 1363 --Bloomberg (Industry sector)
  
  LEFT JOIN sectors bond_issuer_cntryofissuer_name
	ON bond_issuer_cntryofissuer_name.id = bond_issuer_cntryofissue.sector
  
  LEFT JOIN sectors bond_issuer_bloomberg_name
	ON bond_issuer_bloomberg_name.id = bond_issuer_bloomberg.sector
  
	WHERE TITRES.type ! = 'L' -- not a repo
  AND AFFECTATION.ident ! = 20 --excluding cash/commission
	ORDER BY Created,Instrument_Name;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END NEW_INSTRUMENTS_T_25HRS;

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_13HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 

PROCEDURE NEW_INSTRUMENTS_T_13HRS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR


		SELECT 
      TITRES.reference                                                                                       Reference_Code
		, TITRES.libelle                                                                                     Instrument_Name
		, RISKUSERS.NAME                                                                                     Set_Up_By
		, TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS')                           Created
		, TITRES.sicovam                                                                                     Sicovam
		, btg_get_instrument_type(TITRES.sicovam)                                                            Instrument_Type
		, AFFECTATION.libelle                                                                                Allotment
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       Market
        , decode(titres.type,'S',cds_issuer.reference,'O',bond_issuer.reference)                             Issuer_Reference
        , decode(titres.type,'S',cds_issuer.libelle,'O',bond_issuer.libelle)                                 Issuer_Name
        , decode(titres.type,'S',cds_issuer_cntryofissuer_name.NAME,'O',bond_issuer_cntryofissuer_name.NAME) ISSUER_CNTRY_OF_ISSUE
	    , decode(titres.type,'S',cds_issuer_bloomberg_name.NAME,'O',bond_issuer_bloomberg_name.NAME)         ISSUER_Industry_Sector
    
	FROM TITRES
	INNER JOIN INFOS_HISTO 
    ON TITRES.sicovam = INFOS_HISTO.sicovam
		AND INFOS_HISTO.modif = 1 --just the intial creation
		AND INFOS_HISTO.type_table = 3 --list only the addition to the titres table so we don't get dupes
		AND num_to_date(INFOS_HISTO.date_validite) > SYSDATE - ((1 / 24) * 13) --last 13 hours
    
	LEFT JOIN AFFECTATION 
    ON TITRES.affectation = AFFECTATION.ident
	LEFT JOIN RISKUSERS 
    ON infos_histo.userident = RISKUSERS.ident
	LEFT JOIN MARCHE 
    ON TITRES.marche = MARCHE.mnemomarche
		AND TITRES.devisectt = MARCHE.codedevise
	LEFT JOIN MARCHEORGANISE 
    ON TITRES.marche = MARCHEORGANISE.ident
  LEFT JOIN titres cds_issuer
  on cds_issuer.sicovam=titres.coupon1
  
  LEFT JOIN sector_instrument_association cds_issuer_cntryofissue
	ON cds_issuer_cntryofissue.sicovam = cds_issuer.sicovam
	AND cds_issuer_cntryofissue.type = 5349 --Country of Issue
  
  LEFT JOIN sector_instrument_association cds_issuer_bloomberg
	ON cds_issuer_bloomberg.sicovam = cds_issuer.sicovam
	AND cds_issuer_bloomberg.type = 1363 --Bloomberg (Industry sector)
  
  LEFT JOIN sectors cds_issuer_cntryofissuer_name
	ON cds_issuer_cntryofissuer_name.id = cds_issuer_cntryofissue.sector
  
  LEFT JOIN sectors cds_issuer_bloomberg_name
	ON cds_issuer_bloomberg_name.id = cds_issuer_bloomberg.sector
  
  LEFT JOIN titres bond_issuer
  on bond_issuer.sicovam=titres.code_emet
  
  LEFT JOIN sector_instrument_association bond_issuer_cntryofissue
	ON bond_issuer_cntryofissue.sicovam = bond_issuer.sicovam
	AND bond_issuer_cntryofissue.type = 5349 --Country of Issue
  
  LEFT JOIN sector_instrument_association bond_issuer_bloomberg
	ON bond_issuer_bloomberg.sicovam = bond_issuer.sicovam
	AND bond_issuer_bloomberg.type = 1363 --Bloomberg (Industry sector)
  
  LEFT JOIN sectors bond_issuer_cntryofissuer_name
	ON bond_issuer_cntryofissuer_name.id = bond_issuer_cntryofissue.sector
  
  LEFT JOIN sectors bond_issuer_bloomberg_name
	ON bond_issuer_bloomberg_name.id = bond_issuer_bloomberg.sector
  
	WHERE TITRES.type ! = 'L' -- not a repo
  AND AFFECTATION.ident ! = 20 --excluding cash/commission
	ORDER BY Created,Instrument_Name;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END NEW_INSTRUMENTS_T_13HRS;



-- *****************************************************************
-- Description:     PROCEDURE  RAPPTR_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 08 APR 2014		Matt Kelly          Created
-- 10 NOV 2015		Matt Kelly			Don't flag missing issue date when 
--										affectation in (1140,1501,1506) and
--										return allotment name instead of code
-- 24 MAR 2016		Gustavo Binnie		PMGMEDM-236 - Exclude allotments 32 and 45
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 

PROCEDURE RAPPTR_EXCEPTION_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR

	SELECT  t.sicovam                     	Sicovam
			,t.libelle                        	Instrument_Name
			,t.reference                      	Instrument_Ref
			,ISIN.value                       	ISIN
			,t.type
			,a.libelle                    	    Allotment
      
      ,REGEXP_REPLACE (
        REGEXP_REPLACE( (
            
            case when (
                        ((t.type = 'A' or t.affectation = 18) and sec_incorp.name is null)
                        or
                        (t.type = 'I' and sec_incorp.name <> 'IND')
                      ) 
                      then 'Country_Of_Incorp' ELSE NULL END || ',' ||
            case when (
                        ((t.type = 'A' or t.affectation = 18) and sec_issue.name is null)
                        or
                        (t.type = 'I' and sec_issue.name <> 'IND')
                      )
                      then 'Country_Of_Issue' ELSE NULL END || ',' ||
            case when (t.affectation = 9 or t.affectation = 18) and sec_control_conv.name is null then 'In Control Of Conversion' ELSE NULL END || ',' ||
            case when (t.affectation = 18) and sec_cov_warrant.name is null then 'Is Covered Warrant' ELSE NULL END || ',' ||
            
            case when (t.type = 'A')
                  then (
                          case when (Issue_Date.value is null and t.affectation not in (1140,1501,1506)) then 'Issue Date' ELSE NULL END
                       )
                       else null end
            
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA"
        
      ,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
      
FROM titres t

LEFT JOIN affectation a
  ON t.affectation = a.IDENT

--ISIN
LEFT JOIN extrnl_references_instruments ISIN
  ON t.sicovam = ISIN.sophis_ident
    AND ISIN.ref_ident = 1  

--Country of Incorporation
LEFT JOIN sector_instrument_association sia_incorp
  ON t.sicovam = sia_incorp.sicovam
    AND sia_incorp.type = 5348
LEFT JOIN sectors sec_incorp
  ON sia_incorp.sector = sec_incorp.id
  
--Country of Issue
LEFT JOIN sector_instrument_association sia_issue
  ON t.sicovam = sia_issue.sicovam
    AND sia_issue.type = 5349
LEFT JOIN sectors sec_issue
  ON sia_issue.sector = sec_issue.id

--In Control of Conversion
LEFT JOIN sector_instrument_association sia_control_conv
  ON t.sicovam = sia_control_conv.sicovam
    AND sia_control_conv.type = 5351
LEFT JOIN sectors sec_control_conv
  ON sia_control_conv.sector = sec_control_conv.id

--Is Covered Warrant
LEFT JOIN sector_instrument_association sia_cov_warrant
  ON t.sicovam = sia_cov_warrant.sicovam
    AND sia_cov_warrant.type = 5352
LEFT JOIN sectors sec_cov_warrant
  ON sia_cov_warrant.sector = sec_cov_warrant.id
  
--Issue Date
LEFT JOIN extrnl_references_instruments Issue_Date
		ON t.sicovam = Issue_Date.sophis_ident
			AND Issue_Date.ref_ident = 675
  
WHERE (
        t.sicovam in 
                      (
                          SELECT T1.SICOVAM 
                          FROM TITRES T1 
                          WHERE T1.TYPE in ('G','D','F') 
                          AND T1.CODE_EMET IN (
                                                  SELECT TITRES.SICOVAM 
                                                  FROM TITRES 
                                                  WHERE TITRES.TYPE IN ('I', 'A')
                                              )
                      )
        
        OR t.SICOVAM IN (
                          SELECT T2.SICOVAM  
                          FROM TITRES T2 
                          WHERE T2.codesj IN (
                                              SELECT TITRES.SICOVAM FROM TITRES WHERE TITRES.TYPE IN ('I', 'A')
                                              )
                        ) 
        OR t.SICOVAM IN (
                          SELECT T3.SICOVAM 
                          FROM TITRES T3 
                          where T3.TYPE = 'A')
                          ) 
AND   t.reference NOT LIKE ('*%') 
AND (
          (
            ((t.type = 'A' or t.affectation = 18) and NVL(t.affectation,0) NOT IN (32,45) and sec_incorp.name is null)
            or
            (t.type = 'I' and sec_incorp.name <> 'IND')
          )
      OR  (
            ((t.type = 'A' or t.affectation = 18) and NVL(t.affectation,0) NOT IN (32,45) and sec_issue.name is null)
            or
            (t.type = 'I' and sec_issue.name <> 'IND')
          )
      OR  ((t.affectation = 9 or t.affectation = 18) and sec_control_conv.name is null)
      OR  ((t.affectation = 18) and sec_cov_warrant.name is null)
      OR  ((t.type = 'A' and NVL(t.affectation,0) not in (1140,1501,1506,32,45)) and Issue_Date.value is null)
    )

ORDER BY t.libelle;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END RAPPTR_EXCEPTION_REPORT;

-- *****************************************************************
-- END OF: RAPPTR_EXCEPTION_REPORT
-- *****************************************************************



-- *****************************************************************
-- Description:     PROCEDURE  ISSUE_DATE_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 24 APR 2014		Matt Kelly          Created
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 


PROCEDURE ISSUE_DATE_EXCEPTION_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR


select  sicovam
        ,libelle    Instrument_Name
        ,reference  Instrument_Ref
        ,eri.value  Issue_Date
        
from titres t

inner join extrnl_references_instruments eri
  on t.sicovam = eri.sophis_ident
    and eri.ref_ident = 675
    
where (eri.value not like '__/__/____' and eri.value not like 'N/A')
AND   t.reference NOT LIKE ('*%') 
order by libelle
;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END ISSUE_DATE_EXCEPTION_REPORT;



-- *****************************************************************
-- END OF: ISSUE_DATE_EXCEPTION_REPORT
-- *****************************************************************





-- *****************************************************************
-- Description:     PROCEDURE  FUT_OPT_BAD_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 MAR 2014		  Jun guan		        Created
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE FUT_OPT_BAD_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
-- *****************************************************************
-- BEGIN OF: FUT_OPT_BAD_DATA
-- *****************************************************************   
	OPEN p_CURSOR
	FOR
	
SELECT 

titres.sicovam ,
titres.libelle Instrumentname,
titres.reference instrumentreference,
extrnl_references_instruments.value ISIN

FROM titres
INNER JOIN extrnl_references_instruments	
ON extrnl_references_instruments.sophis_ident = titres.sicovam
AND ref_ident = 1

WHERE (
		(
			titres.type = 'F'
			AND 
			titres.echeance >= sysdate
		)
		OR 
		(
			TITRES.type IN ('M','D')
			AND TITRES.finper >= SYSDATE
			AND TITRES.affectation IN (10,23,47,1060,1301,1041,1250)
		)
	  )
AND  titres.reference NOT LIKE ('*%') 
AND extrnl_references_instruments.value IS NOT NULL
AND length(extrnl_references_instruments.value) != 12;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END

FUT_OPT_BAD_DATA;
-- *****************************************************************
-- END OF: FUT_OPT_BAD_DATA
-- *****************************************************************

-- *****************************************************************
-- Description:     PROCEDURE  MISSING_BUS_CENTER_MAP
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 JUL 2013      Gustavo Binnie      Created.
-- 04 Jul 2014		Gustavo Binnie		Moved from PCKG_BTG_EMAILER_EXCEPTION_BO
-- ***************************************************************** 
PROCEDURE MISSING_BUS_CENTER_MAP(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MISSING_BUS_CENTER_MAP
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT 	devise_to_str(CODE) CCY
			,libelle CURRENCY_NAME
	FROM DEVISEV2
	WHERE devise_to_str(CODE) NOT IN (
			SELECT INPUT_CODE
			FROM BTG_MAPPING_CODE
			WHERE SOURCE_ID = 7
				AND TYPE_ID = 29
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISSING_BUS_CENTER_MAP
		-- *****************************************************************   
END MISSING_BUS_CENTER_MAP;




-- *****************************************************************
-- Description:     PROCEDURE  CFD_CROSS_CURRENCY
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 11 JUL 2014      Matt Kelly		Created
-- 01 SEP 2014      Matt Kelly      Updated to pull PB from Ext. Ref instead of sectors. Also add PB validation.
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CFD_CROSS_CURRENCY(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CFD_CROSS_CURRENCY
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	
SELECT	titres.sicovam							Sicovam
				,titres.libelle							Instrument_Name
				,titres.reference						Instrument_Reference
				,REGEXP_REPLACE
					(
					REGEXP_REPLACE( (
          
						case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
						case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
						case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
						case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
						case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
						case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
          
						case when titres.SICOVAM IS NULL then 'SICOVAM' ELSE NULL END || ',' ||
						case when titres.libelle IS NULL then 'Name' ELSE NULL END || ',' ||
						case when titres.reference IS NULL then 'Reference' ELSE NULL END || ',' ||
						case when underlying.reference is null then 'Principal_Ref' ELSE NULL END || ',' ||
						case when titres.modele is null then 'Model' ELSE NULL END || ',' ||
						case when titres.type is null then 'Type' ELSE NULL END || ',' ||
          
						case when titres.freq_coupon is null then 'inverse_H_and_H' ELSE NULL END || ',' ||
						case when titres.beta is null then 'Hedging' ELSE NULL END || ',' ||
						case when titres.affectation is null then 'Allotment' ELSE NULL END || ',' ||
						case when titres.perimeterid is null then 'Convention' ELSE NULL END || ',' ||
						case when titres.nbpts is null then 'Computation' ELSE NULL END || ',' ||
						case when titres.adjusted_coupons is null then 'P_and_L_Pricing' ELSE NULL END || ',' ||
          
						case when titres.amort is null then 'Type_SB' ELSE NULL END || ',' ||
						case when titres.commission is null then 'Rate' ELSE NULL END || ',' ||
						case when titres.typederive is null then 'calc_basis' ELSE NULL END || ',' ||
						case when titres.j1refcon2 is null then 'billing_frequency' ELSE NULL END || ',' ||
						case when titres.deviseac is null then 'billing_currency' ELSE NULL END || ',' ||
          
						case when titres.typeamort is null then 'Type_FC' ELSE NULL END || ',' ||
						case when titres.capitalise2 is null then 'Pricing_Type' ELSE NULL END || ',' ||
						case when titres.taux_var is null then 'Rate_Spread' ELSE NULL END || ',' ||
						case when titres.taux is null then 'Rate_Spread2' ELSE NULL END || ',' ||
						case when titres.h is null then 'Hair_cut' ELSE NULL END || ',' ||
						case when titres.devisectt is null then 'Currency' ELSE NULL END || ',' ||
            case when Prime_Broker.value is null then 'Prime_Broker (missing)' ELSE NULL END || ',' ||
            case when Prime_Broker.value not in (select code from sectors where parent = 6523) then 'Prime_Broker (invalid)' ELSE NULL END || ',' ||
						case when underlying.devisectt is null then 'Underlying Currency' ELSE NULL END
          
						)
						,',+(,|$)','\1'),
						'^,'     
					)									MISSING_OR_INCORRECT_DATA
				,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
        
		FROM titres
    
		LEFT JOIN titres underlying
		ON titres.code_emet = underlying.sicovam
    
    LEFT JOIN extrnl_references_instruments Prime_Broker
      ON titres.sicovam = Prime_Broker.sophis_ident
        AND Prime_Broker.ref_ident = 683
  
		WHERE titres.type = 'G'
		AND  titres.reference NOT LIKE ('*%') 
		AND titres.devisectt <> underlying.devisectt --Cross-Currency CFDs
			AND (
				titres.libelle like ' %'
				OR titres.libelle like '% '
				OR titres.libelle like '%  %'
				OR titres.reference like ' %'
				OR titres.reference like '% '
				OR titres.reference like '%  %'
          
				OR titres.SICOVAM IS NULL
				OR titres.libelle IS NULL
				OR titres.reference IS NULL
				OR titres.marche = 0

				OR underlying.reference is null
				OR titres.modele is null
				OR titres.type is null
          
				OR titres.freq_coupon is null
				OR titres.beta is null
				OR titres.affectation is null
				OR titres.perimeterid is null
				OR titres.nbpts is null
				OR titres.adjusted_coupons is null
          
				OR titres.amort is null
				OR titres.commission is null
				OR titres.typederive is null
				OR titres.j1refcon2 is null
				OR titres.deviseac is null
          
				OR titres.typeamort is null
				OR titres.capitalise2 is null
				OR titres.taux_var is null
				OR titres.taux is null
				OR titres.h is null
				OR titres.devisectt is null
				OR underlying.devisectt is null
        OR Prime_Broker.value is null
        OR Prime_Broker.value not in (select code from sectors where parent = 6523)
				)
		ORDER BY titres.libelle;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: CFD_CROSS_CURRENCY
	-- *****************************************************************   
END CFD_CROSS_CURRENCY;



-- *****************************************************************
-- Description:     PROCEDURE  CFD_NON_CROSS_CURRENCY
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 11 JUL 2014      Matt Kelly			Created
-- 01 SEP 2014      Matt Kelly      Updated to pull PB from Ext. Ref instead of sectors. Also add PB validation.
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CFD_NON_CROSS_CURRENCY(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CFD_NON_CROSS_CURRENCY
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	
		SELECT titres.sicovam                                     Sicovam
			,titres.libelle                                     Instrument_Name
			,titres.reference                                   Instrument_Reference
			,REGEXP_REPLACE
				(
				REGEXP_REPLACE( (
            
				case when titres.libelle like ' %' then 'Leading space in Name' ELSE NULL END || ',' ||
				case when titres.libelle like '% ' then 'Trailing space in Name' ELSE NULL END || ',' ||
				case when titres.libelle like '%  %' then 'Double space in Name' ELSE NULL END || ',' ||
				case when titres.reference like ' %' then 'Leading space in Reference' ELSE NULL END || ',' ||
				case when titres.reference like '% ' then 'Trailing space in Reference' ELSE NULL END || ',' ||
				case when titres.reference like '%  %' then 'Double space in Reference' ELSE NULL END || ',' ||
            
				case when titres.SICOVAM IS NULL then 'SICOVAM' ELSE NULL END || ',' ||
				case when titres.libelle IS NULL then 'Name' ELSE NULL END || ',' ||
				case when titres.reference IS NULL then 'Reference' ELSE NULL END || ',' ||
				case when underlying.reference is null then 'Principal_Ref' ELSE NULL END || ',' ||
				case when titres.modele is null then 'Model' ELSE NULL END || ',' ||
				case when titres.type is null then 'Type' ELSE NULL END || ',' ||
            
				case when titres.freq_coupon is null then 'inverse_H_and_H' ELSE NULL END || ',' ||
				case when titres.beta is null then 'Hedging' ELSE NULL END || ',' ||
				case when titres.affectation is null then 'Allotment' ELSE NULL END || ',' ||
				case when titres.perimeterid is null then 'Convention' ELSE NULL END || ',' ||
				case when titres.nbpts is null then 'Computation' ELSE NULL END || ',' ||
				case when titres.adjusted_coupons is null then 'P_and_L_Pricing' ELSE NULL END || ',' ||
            
				case when titres.amort is null then 'Type_SB' ELSE NULL END || ',' ||
				case when titres.commission is null then 'Rate' ELSE NULL END || ',' ||
				case when titres.typederive is null then 'calc_basis' ELSE NULL END || ',' ||
				case when titres.j1refcon2 is null then 'billing_frequency' ELSE NULL END || ',' ||
				case when titres.deviseac is null then 'billing_currency' ELSE NULL END || ',' ||
            
				case when titres.typeamort is null then 'Type_FC' ELSE NULL END || ',' ||
				case when titres.capitalise2 is null then 'Pricing_Type' ELSE NULL END || ',' ||
				case when titres.taux_var is null then 'Rate_Spread' ELSE NULL END || ',' ||
				case when titres.taux is null then 'Rate_Spread2' ELSE NULL END || ',' ||
				case when titres.h is null then 'Hair_cut' ELSE NULL END || ',' ||
				case when titres.devisectt is null then 'Currency' ELSE NULL END || ',' ||
        
        case when Prime_Broker.value is null then 'Prime_Broker (missing)' ELSE NULL END || ',' ||
        case when Prime_Broker.value not in (select code from sectors where parent = 6523) then 'Prime_Broker (invalid)' ELSE NULL END || ',' ||
        
				case when underlying.devisectt is null then 'Underlying Currency' ELSE NULL END
				)
				,',+(,|$)','\1'),
				'^,'     
			)                                             MISSING_OR_INCORRECT_DATA
			,BTG_FN_AUDIT_INST_USER(titres.sicovam)       Instr_last_amended_by
        
		FROM titres
  
		LEFT JOIN titres underlying
		  ON titres.code_emet = underlying.sicovam
      
    LEFT JOIN extrnl_references_instruments Prime_Broker
      ON titres.sicovam = Prime_Broker.sophis_ident
        AND Prime_Broker.ref_ident = 683

		WHERE titres.type = 'G'
		AND  titres.reference NOT LIKE ('*%') 
		  AND (titres.devisectt = underlying.devisectt OR titres.devisectt is null OR underlying.devisectt is null) --Non Cross Currency CFDs
		  AND (
				titres.libelle like ' %'
				OR titres.libelle like '% '
				OR titres.libelle like '%  %'
				OR titres.reference like ' %'
				OR titres.reference like '% '
				OR titres.reference like '%  %'
        
				OR titres.SICOVAM IS NULL
				OR titres.libelle IS NULL
				OR titres.reference IS NULL
				OR titres.marche = 0

				OR underlying.reference is null
				OR titres.modele is null
				OR titres.type is null
        
				OR titres.freq_coupon is null
				OR titres.beta is null
				OR titres.affectation is null
				OR titres.perimeterid is null
				OR titres.nbpts is null
				OR titres.adjusted_coupons is null
        
				OR titres.amort is null
				OR titres.commission is null
				OR titres.typederive is null
				OR titres.j1refcon2 is null
				OR titres.deviseac is null
        
				OR titres.typeamort is null
				OR titres.capitalise2 is null
				OR titres.taux_var is null
				OR titres.taux is null
				OR titres.h is null
				OR titres.devisectt is null
				OR underlying.devisectt is null
        OR Prime_Broker.value is null
        OR Prime_Broker.value not in (select code from sectors where parent = 6523)
			)
		ORDER BY 2;



	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: CFD_NON_CROSS_CURRENCY
	-- *****************************************************************   
END CFD_NON_CROSS_CURRENCY;





-- *****************************************************************
-- Description:     PROCEDURE  CFD_DUPLICATES
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 15 AUG 2014      Matt Kelly			    Created
-- 01 SEP 2014      Matt Kelly          Updated to pull PB from Ext. Ref instead of sectors
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CFD_DUPLICATES(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CFD_DUPLICATES
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR


     SELECT  
        TITRES.sicovam                        CFD_Sicovam
      , TITRES.libelle                        CFD_Name
      , TITRES.reference                      CFD_Reference
      , EXTRNL_REFERENCES_INSTRUMENTS.value   Prime_Broker
      , TITRES.code_emet                      Underlying_Sicovam
      , DEVISE_TO_STR(TITRES.devisectt)       Currency
        
      FROM TITRES
        
      INNER JOIN EXTRNL_REFERENCES_INSTRUMENTS
        ON TITRES.sicovam = EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
          AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 683
        
      INNER JOIN (
                    SELECT  PRIME_BROKER.value
                            ,CFD_DUPE.code_emet
                            ,CFD_DUPE.devisectt
                            ,COUNT(CFD_DUPE.sicovam)
                                
                    FROM TITRES CFD_DUPE
                    
                    INNER JOIN EXTRNL_REFERENCES_INSTRUMENTS PRIME_BROKER
                      ON CFD_DUPE.sicovam = PRIME_BROKER.sophis_ident
                        AND PRIME_BROKER.ref_ident = 683
                      
                    WHERE CFD_DUPE.type = 'G'
					AND CFD_DUPE.reference NOT LIKE ('*%') 
                    GROUP BY PRIME_BROKER.value, CFD_DUPE.code_emet, CFD_DUPE.devisectt
                    HAVING COUNT(CFD_DUPE.sicovam) > 1
                  ) DUPLICATES
                  
        ON DUPLICATES.code_emet = TITRES.code_emet
          AND DUPLICATES.value = EXTRNL_REFERENCES_INSTRUMENTS.value
            AND DUPLICATES.devisectt = TITRES.devisectt
      
      WHERE TITRES.type = 'G'
	  AND   titres.reference NOT LIKE ('*%') 
      ORDER BY 5, 6, 4;
      
    

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: CFD_DUPLICATES
	-- *****************************************************************   
END CFD_DUPLICATES;

-- *****************************************************************
-- Description:     PROCEDURE  CFD_PRICING
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 2 Sep 2014      Oliver South         Created
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CFD_PRICING(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CFD_PRICING
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT
        TITRES.sicovam Sicovam
      , TITRES.libelle CFD_name
      , TITRES.reference CFD_Reference
      , RIC.servisen CFD_Ticker
      , BTG_FN_AUDIT_INST_USER(TITRES.sicovam) CFD_Last_Amended_By
FROM
      TITRES
INNER JOIN RIC
ON RIC.sicovam = TITRES.sicovam
WHERE
      TITRES.type = 'G'
AND  titres.reference NOT LIKE ('*%') 
AND RIC.servisen IS NOT NULL
AND RIC.prefixe = 'Global'
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: CFD_PRICING
	-- *****************************************************************   
END CFD_PRICING;

PROCEDURE COMMOD_AUTO(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: COMMOD_AUTO

-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"	 
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
        TITRES.libelle      Commodity_name
      , TITRES.reference    Commodity_reference
FROM  TITRES
INNER JOIN COMMODITY
ON COMMODITY.id = TITRES.sicovam
AND COMMODITY.AUTOFUTUREGENERATION = 1 --flag is checked
WHERE  
        titres.reference NOT LIKE ('*%') 
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: COMMOD_AUTO
	-- *****************************************************************   
END COMMOD_AUTO;



-- *****************************************************************
-- Description:     PROCEDURE  FORW_VS_UND
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE FORW_VS_UND (p_CURSOR OUT T_CURSOR) AS

BEGIN

	OPEN p_CURSOR
	FOR

SELECT Forward.sicovam,
       Forward.libelle Instrument_Name,
       Forward.reference Instrument_Reference
          
          FROM titres Forward
          INNER JOIN titres Underlying
          ON Forward.CODE_EMET = Underlying.sicovam 
     
where upper(Underlying.modele) = 'LME' 
  AND upper(Forward.modele) <> 'LME FUTURE'
   AND   Forward.reference NOT LIKE ('*%') 
  AND (
			Forward.echeance > sysdate - 1
			OR Forward.dateregl > sysdate - 1
	  ) --not expired
	  ;

END FORW_VS_UND;


-- *****************************************************************
-- Description:     PROCEDURE  UND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 

PROCEDURE UND_DEL_DATE(p_CURSOR OUT T_CURSOR) AS

BEGIN

	OPEN p_CURSOR
	FOR

Select  AUX_TAB1.REFERENCE Underlying_Reference,
        AUX_TAB2.Instrument_SICOVAM,
        AUX_TAB2.Instrument_Reference,
        AUX_TAB2.Instrument_Name,
        AUX_TAB1.dateregl Delivery_Date
from
(
SELECT 
       Underlying.REFERENCE,
       forward.dateregl
       
          FROM titres Forward
          INNER JOIN titres Underlying
          ON Forward.CODE_EMET = Underlying.sicovam 
     
where upper(Underlying.modele) = 'LME'
AND  Forward.reference NOT LIKE ('*%') 
  AND (
			Forward.echeance > sysdate - 1
			OR Forward.dateregl > sysdate - 1
	  ) --not expired

GROUP BY Underlying.REFERENCE, forward.dateregl 
HAVING COUNT(forward.dateregl) > 1
) AUX_TAB1 

LEFT JOIN 

(SELECT 
       Underlying.sicovam Undelying_Sicovam,
       Underlying.REFERENCE,
       Underlying.libelle  Undelying_Libelle,
       Forward.sicovam Instrument_SICOVAM,
       Forward.reference Instrument_Reference,
       Forward.libelle Instrument_Name,
       forward.dateregl
 
          FROM titres Forward
          INNER JOIN titres Underlying
          ON Forward.CODE_EMET = Underlying.sicovam 
     
	   where upper(Underlying.modele) = 'LME'
	   AND  Forward.reference NOT LIKE ('*%') 
		AND (
				  Forward.echeance > sysdate - 1
			   OR Forward.dateregl > sysdate - 1
			) --not expired
)AUX_TAB2

on AUX_TAB1.REFERENCE = AUX_TAB2.REFERENCE and AUX_TAB1.dateregl = AUX_TAB2.dateregl
order by delivery_date;

END UND_DEL_DATE;



-- *****************************************************************
-- Description:     PROCEDURE  WEEKEND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE WEEKEND_DEL_DATE (p_CURSOR OUT T_CURSOR) AS

BEGIN

	OPEN p_CURSOR
	FOR

SELECT Forward.sicovam,
       Forward.libelle Instrument_Name,
       Forward.reference Instrument_Reference
          
          FROM titres Forward
          INNER JOIN titres Underlying
          ON Forward.CODE_EMET = Underlying.sicovam 
     
where	upper(Underlying.modele) = 'LME' 
AND  Forward.reference NOT LIKE ('*%') 
		AND TO_CHAR(Forward.dateregl,'D') in (1,7)
		AND (
				  Forward.echeance > sysdate - 1
			   OR Forward.dateregl > sysdate - 1
			) --not expired
;
END WEEKEND_DEL_DATE;


-- *****************************************************************
-- Description:     PROCEDURE  DUMMY_INSTRUMENTS_NEW_EDIT
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 Oct 2014      Gustavo Binnie         Created
-- ***************************************************************** 
PROCEDURE DUMMY_INSTRUMENTS_NEW_EDIT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: DUMMY_INSTRUMENTS_NEW_EDIT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT 
		  TITRES.reference                                                          Reference_Code
		, TITRES.libelle                                                            Instrument_Name
		, RISKUSERS.NAME                                                            Last_Amended_By
		, TO_CHAR(num_to_date(AUDIT_TITRES.date_validite), 'YYYY-MM-DD HH24:MI:SS') Modification_Date
		, TITRES.sicovam                                                            Sicovam
		, btg_get_instrument_type(TITRES.sicovam)                                   Instrument_Type
		, OLD_ALLOTMENT.LIBELLE                                                     Old_Allotment
		, AFFECTATION.libelle                                                       Allotment
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)              Market
	FROM TITRES
	LEFT JOIN AFFECTATION 
    ON TITRES.affectation = AFFECTATION.ident
	LEFT JOIN MARCHE 
    ON TITRES.marche = MARCHE.mnemomarche
		AND TITRES.devisectt = MARCHE.codedevise
	LEFT JOIN MARCHEORGANISE 
    ON TITRES.marche = MARCHEORGANISE.ident
  INNER JOIN 
  (
  select USERIDENT, DATE_VALIDITE, SICOVAM,
    row_number() over(partition by SICOVAM 
                        order by DATE_VALIDITE desc) seq
  from INFOS_HISTO
  WHERE num_to_date(DATE_VALIDITE) > (SYSDATE - 7)
  AND  INFOS_HISTO.TYPE_TABLE = 3
  ) AUDIT_TITRES  -- INSTRUMENTS CHANGES/CREATED IN THE PAST 7 DAYS
  ON AUDIT_TITRES.SICOVAM = TITRES.SICOVAM
  AND AUDIT_TITRES.seq = 1
  LEFT JOIN 
  (
  select USERIDENT, DATE_VALIDITE, SICOVAM, NEW_SICOVAM,
    row_number() over(partition by SICOVAM 
                        order by DATE_VALIDITE desc) seq
  from INFOS_HISTO
  WHERE num_to_date(DATE_VALIDITE) <= (SYSDATE - 7)
  AND  INFOS_HISTO.TYPE_TABLE = 3
  ) AUDIT_TITRES_OLD  -- LAST MODIFICATION BEFORE PAST 7 DAYS
  ON AUDIT_TITRES_OLD.SICOVAM = TITRES.SICOVAM
  AND AUDIT_TITRES_OLD.seq = 1
  LEFT JOIN TITRES_HISTO -- LAST VERSION OF INSTRUMENT BEFORE PAST 7 DAYS
  ON TITRES_HISTO.SICOVAM = AUDIT_TITRES_OLD.NEW_SICOVAM
  LEFT JOIN AFFECTATION OLD_ALLOTMENT
  ON TITRES_HISTO.AFFECTATION = OLD_ALLOTMENT.IDENT 
  LEFT JOIN RISKUSERS
  ON AUDIT_TITRES.USERIDENT = RISKUSERS.IDENT
	WHERE  
    (AFFECTATION.ident in (1180,1140) -- Share - Dummy / Bond - Dummy
    or UPPER(AFFECTATION.libelle) LIKE '%DUMMY%') 
    AND (TITRES.AFFECTATION <> TITRES_HISTO.AFFECTATION --ALLOTMENT CHANGED
        OR
        TITRES_HISTO.AFFECTATION IS NULL) -- INSTRUMENT WAS CREATED IN THE PAST 7 DAYS
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: DUMMY_INSTRUMENTS_NEW_EDIT
	-- *****************************************************************   
END DUMMY_INSTRUMENTS_NEW_EDIT;


-- *****************************************************************
-- Description:     PROCEDURE  NEW_ISSUERS_T_25HRS
--
-- Author:          Ami Talati
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 JAN 2015		Ami Talati		
-- ***************************************************************** 

PROCEDURE NEW_ISSUERS_T_25HRS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR
 
    SELECT TITRES.reference Reference_Code
	,TITRES.libelle Issuer_Name
	,RISKUSERS.NAME Set_Up_By
	,TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS') Created
	,TITRES.sicovam Sicovam
	,DEVISE_TO_STR(TITRES.devisectt) CCY
	,SECTORS.NAME CNTRY_of_DOMICILE
	,cntryofissuer_name.NAME CNTRY_OF_ISSUE
	,bloomberg_name.NAME Industry_Sector
	,EXTRNL_REFERENCES_INSTRUMENTS.value CGE_Code
FROM TITRES
INNER JOIN INFOS_HISTO
	ON TITRES.sicovam = INFOS_HISTO.sicovam
	AND INFOS_HISTO.modif = 1 --just the intial creation
	AND INFOS_HISTO.type_table = 3 --list only the addition to the titres table so we don't get dupes
  AND num_to_date(INFOS_HISTO.date_validite) > SYSDATE - ((1 / 24) * 25) --last day (25 hours)
LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION
	ON TITRES.sicovam = SECTOR_INSTRUMENT_ASSOCIATION.sicovam
	AND SECTOR_INSTRUMENT_ASSOCIATION.type = 5347 --Country of Domicile
LEFT JOIN sector_instrument_association cntryofissue
	ON cntryofissue.sicovam = TITRES.sicovam
	AND cntryofissue.type = 5349 --Country of Issue
LEFT JOIN sector_instrument_association bloomberg
	ON bloomberg.sicovam = TITRES.sicovam
	AND bloomberg.type = 1363 --Bloomberg (Industry sector)
LEFT JOIN SECTORS
	ON SECTORS.id = SECTOR_INSTRUMENT_ASSOCIATION.sector
LEFT JOIN sectors cntryofissuer_name
	ON cntryofissuer_name.id = cntryofissue.sector
LEFT JOIN sectors bloomberg_name
	ON bloomberg_name.id = bloomberg.sector
LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
	ON EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident = TITRES.sicovam
	AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 665 --CGE Code
LEFT JOIN RISKUSERS
	ON INFOS_HISTO.userident = RISKUSERS.ident
WHERE TITRES.type = 'H' -- ISSUER
ORDER BY Created
	,Issuer_Name;

    

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END NEW_ISSUERS_T_25HRS;


-- *****************************************************************
-- Description:     PROCEDURE  CROSS_ASSET_BOND_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 MAR 2015       JUN GUAN           Created
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- 15 DEC 2017    Jeff Yu     PMOG-1180 (Revert changes made in PMOG-1168)
-- ***************************************************************** 
PROCEDURE CROSS_ASSET_BOND_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CROSS_ASSET_BOND_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT DISTINCT *
FROM (
	SELECT DISTINCT bonds.sicovam bond_sicovam
		,bonds.reference ISIN
		,bonds.libelle bond_name
		,bonds.seniority Seniority
	FROM titres bonds
	INNER JOIN histomvts trades
		ON trades.sicovam = bonds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
			AND upper(FUND_BOOK_STRATEGY.BOOK_NAME) = 'CROSS ASSET' -- filter to Cross Asset trades only
	WHERE (
			bonds.type = 'O'
			and bonds.affectation != 1400-- exclude Bank Loan
			)
        AND    bonds.reference NOT LIKE ('*%') 
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
		AND bonds.seniority = 0
	) -- this is to pick up any bond that have been traded in Cross Asset does not have seniority set

UNION

(
	SELECT DISTINCT bonds.sicovam bond_sicovam
		,bonds.reference ISIN
		,bonds.libelle bond_name
		,bonds.seniority Seniority
	FROM titres bonds
	INNER JOIN titres cds
		ON cds.j1refcon2 = bonds.sicovam
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
			AND upper(FUND_BOOK_STRATEGY.BOOK_NAME) = 'CROSS ASSET' -- filter to Cross Asset trades only
	WHERE (
			bonds.type = 'O'
			and bonds.affectation != 1400-- exclude Bank Loan
			)
 AND   bonds.reference NOT LIKE ('*%') 
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
		AND bonds.seniority = 0
	); -- this is to pick up any bond whose CDS have been traded in Cross Asset are missing seniority


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: CROSS_ASSET_BOND_MISSING_DATA
	-- *****************************************************************   
END CROSS_ASSET_BOND_MISSING_DATA;


-- *****************************************************************
-- Description:     PROCEDURE  ISSUERS_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 MAR 2015      JUN GUAN            Created
-- ***************************************************************** 
PROCEDURE ISSUERS_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: ISSUERS_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
DISTINCT issuer.sicovam Issuer_sicovam
,issuer.reference Issuer_reference
,bond.sicovam instrument_sicovam
,bond.reference instrument_Reference
,bond.libelle instrument_name
,cntryofissuer_name.NAME ISSUER_SECTOR_CNTRY_OF_ISSUE
,bloomberg_name.NAME ISSUER_SECTOR_BLOOMBERG

FROM titres issuer

INNER JOIN titres bond
ON bond.code_emet = issuer.sicovam
AND (
bond.type = 'O'
OR (
				bond.type = 'D'
				AND bond.affectation = 9
				)
			)
AND bond.finper >= sysdate

INNER JOIN histomvts trades
ON trades.sicovam = bond.sicovam
AND trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)

LEFT JOIN sector_instrument_association cntryofissue
ON cntryofissue.sicovam = issuer.sicovam
AND cntryofissue.type = 5349

LEFT JOIN sector_instrument_association bloomberg
ON bloomberg.sicovam = issuer.sicovam
AND bloomberg.type = 1363

LEFT JOIN sectors cntryofissuer_name
ON cntryofissuer_name.id = cntryofissue.sector

LEFT JOIN sectors bloomberg_name
ON bloomberg_name.id = bloomberg.sector

WHERE cntryofissue.sector IS NULL
OR bloomberg.sector IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: ISSUERS_MISSING_DATA
	-- *****************************************************************   
END ISSUERS_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  NEW_ISSUERS_T_1HRS
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 APR 2015		  Jun Guan		
-- ***************************************************************** 

PROCEDURE NEW_ISSUERS_T_1HRS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR

	
SELECT TITRES.reference Reference_Code
	,TITRES.libelle Issuer_Name
	,RISKUSERS.NAME Set_Up_By
	,TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS') Created
	,TITRES.sicovam Sicovam
	,DEVISE_TO_STR(TITRES.devisectt) CCY
	,SECTORS.NAME CNTRY_of_DOMICILE
	,cntryofissuer_name.NAME CNTRY_OF_ISSUE
	,bloomberg_name.NAME Industry_Sector
	,EXTRNL_REFERENCES_INSTRUMENTS.value CGE_Code
FROM TITRES
INNER JOIN INFOS_HISTO
	ON TITRES.sicovam = INFOS_HISTO.sicovam
	AND INFOS_HISTO.modif = 1 --just the intial creation
	AND INFOS_HISTO.type_table = 3 --list only the addition to the titres table so we don't get dupes
	AND num_to_date(INFOS_HISTO.date_validite) >= (sysdate - 1 / 24) --last hour
LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION
	ON TITRES.sicovam = SECTOR_INSTRUMENT_ASSOCIATION.sicovam
	AND SECTOR_INSTRUMENT_ASSOCIATION.type = 5347 --Country of Domicile
LEFT JOIN sector_instrument_association cntryofissue
	ON cntryofissue.sicovam = TITRES.sicovam
	AND cntryofissue.type = 5349 --Country of Issue
LEFT JOIN sector_instrument_association bloomberg
	ON bloomberg.sicovam = TITRES.sicovam
	AND bloomberg.type = 1363 --Bloomberg (Industry sector)
LEFT JOIN SECTORS
	ON SECTORS.id = SECTOR_INSTRUMENT_ASSOCIATION.sector
LEFT JOIN sectors cntryofissuer_name
	ON cntryofissuer_name.id = cntryofissue.sector
LEFT JOIN sectors bloomberg_name
	ON bloomberg_name.id = bloomberg.sector
LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
	ON EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident = TITRES.sicovam
	AND EXTRNL_REFERENCES_INSTRUMENTS.ref_ident = 665 --CGE Code
LEFT JOIN RISKUSERS
	ON INFOS_HISTO.userident = RISKUSERS.ident
WHERE TITRES.type = 'H' -- ISSUER
ORDER BY Created
	,Issuer_Name;

    

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END NEW_ISSUERS_T_1HRS;


-- *****************************************************************
-- Description:     PROCEDURE  CDS_BOND_MISSING_SPREAD_TYPE
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 28 APR 2015		  Jun Guan		
-- ***************************************************************** 

PROCEDURE CDS_BOND_MISSING_SPREAD_TYPE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR

	
	SELECT DISTINCT undelrying.sicovam Bond_sicovam
	,undelrying.reference Bond_Reference
	,decode(undelrying.fixedspread, 1, 'CDS Fixed', 2, 'CDS Spread', 3, 'YTM Fixed', 4, 'YTM Spread', 5, 'Zero Coupon Spread', 6, 'Forward Spread', 7, 'Static Spread', 8, 'ASW Spread', 9, 'CDI + Spread', 10, 'CDI % SPread', 'Not Set') Bond_Spread_Type
	,bondspread_default_event.NAME BondSpread_Default_Event
	,defaultevent.NAME Issuer_Default_Event
	,issuer.sicovam Issuer_Sicovam
	,issuer.reference Issuer_ref
	,extrnl_references_instruments.value Issuer_REDID
FROM titres undelrying
INNER JOIN titres cds
	ON undelrying.sicovam = cds.j1refcon2
INNER JOIN titres issuer
	ON issuer.sicovam = undelrying.code_emet
LEFT JOIN extrnl_references_instruments
	ON extrnl_references_instruments.sophis_ident = issuer.sicovam
		AND extrnl_references_instruments.ref_ident = 16
LEFT JOIN extrnl_references_instruments cdsisin
	ON cdsisin.sophis_ident = cds.sicovam
		AND cdsisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments issuerisin
	ON issuerisin.sophis_ident = issuer.sicovam
		AND issuerisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments cdsref
	ON cdsref.sophis_ident = cds.sicovam
		AND cdsref.ref_ident = 16
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
						PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.coupon1
	INNER JOIN credit_model
		ON credit_model.code = undelrying.sicovam
	-- and credit_model.def_cdsrate!=0
	WHERE cds.affectation = 22
		AND undelrying.type != 'I'
		AND upper(cds.reference) NOT LIKE '%ABX%'
		AND upper(cds.reference) NOT LIKE '%CMBX%'
		AND upper(cds.reference) NOT LIKE '%IOS%'
		AND upper(cds.reference) NOT LIKE '%MBX%'
		AND upper(cds.reference) NOT LIKE '%INDEX%'
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position-- Only check CDS that has open position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN CREDITRISK_RECORATE
	ON CREDITRISK_RECORATE.code = issuer.sicovam
		AND CREDITRISK_RECORATE.default_event = cds.default_event_leg1
		AND CREDITRISK_RECORATE.seniority = cds.senjambe1
LEFT JOIN defaultevent
	ON defaultevent.id = CREDITRISK_RECORATE.default_event
LEFT JOIN defaultevent bondspread_default_event
	ON bondspread_default_event.id = undelrying.default_event
LEFT JOIN seniority
	ON seniority.id = cds.senjambe1
WHERE undelrying.type IN (
		'O'
		,'D'
		) -- Only check if undelrying is the actual bond for the CDS
	AND undelrying.devisectt=cds.devisectt -- Only check if undelrying is the same ccy as the ccy of the cds
	AND (
		undelrying.fixedspread != 2 -- 2 means CDS Spread in the drop down list
		OR undelrying.default_event = 0 -- 0 means the defualt event is not set
		OR undelrying.default_event != CREDITRISK_RECORATE.default_event -- also pick up if the defualt events on the issuer is not same as the one set on the bond
		);
    

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END CDS_BOND_MISSING_SPREAD_TYPE;



-- *****************************************************************
-- Description:     PROCEDURE  BOND_FUTURE_MISSING_DATA
--
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 13 OCT 2017		  Jeff Yu		Created (PMGMRISK-79)
-- 05 FEB 2018      Jeff Yu       Modified (PMGMRISK-167) -- Update logic to flag those without underlying bond setup
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- ***************************************************************** 

PROCEDURE BOND_FUTURE_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	OPEN p_CURSOR
	FOR

select Sec.REFERENCE Bond_Future, UnderlyingBonds.reference Underlying_Bond
,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (	
        case when r.servisen IS NULL then 'Underlying User reference blank' ELSE NULL END || ', ' || 
        case when r.prefixe != 'Global' OR r.prefixe IS NULL then 'Underlying Global Prefix not checked' ELSE NULL END || ', ' || 
        case when r.fid != 1 then 'Underlying incorrect FID' ELSE NULL END  || ', ' ||          
		case when UnderlyingFutures.CODE_OAT IS NULL then 'Missing Underlying Bond' ELSE NULL END
          ) 
          ,', +(,|$)','\1'),
          '^,'     )
         "MISSING_DATA" 
,BTG_FN_AUDIT_INST_USER(UnderlyingBonds.sicovam) Instr_last_amended_by         
from titres Sec
LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam      
LEFT JOIN titres UnderlyingBonds
      ON UnderlyingFutures.CODE_oat = UnderlyingBonds.sicovam      
LEFT JOIN ric r
		ON r.sicovam = UnderlyingBonds.sicovam
INNER JOIN
(
              SELECT DISTINCT trades.sicovam
								FROM 		HISTOMVTS trades
								INNER JOIN 	titres instrument
								ON 			trades.sicovam 			= instrument.sicovam
								INNER JOIN 	BUSINESS_EVENTS
								ON 			BUSINESS_EVENTS.Id      = trades.Type
								AND 		BUSINESS_EVENTS.COMPTA 	= 1
								INNER JOIN
								(	 SELECT CONNECT_BY_ROOT(FOLIO.ident)                                  		AS TOP_FUND_ID ,
											CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
											REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
											REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
											REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
											REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
											FOLIO.ident                                                         AS STRATEGY_ID ,
											FOLIO.name                                                          AS STRATEGY_NAME ,
											level
											FROM FOLIO
											WHERE LEVEL                   >= 4
											START WITH FOLIO.ident      IN  (14414,90565)--Primary funds --(PCKG_BTG.FOLIO_PRIMARY_FUNDS) --
											CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
								) FUND_BOOK_STRATEGY
								ON 			FUND_BOOK_STRATEGY.STRATEGY_ID 	= trades.opcvm
								WHERE 	  instrument.type	  		= 'F'
                and       instrument.modele     = 'Notionnel'
								AND 		  trades.backoffice 				NOT IN (192,11,13,17,26,27,220,248,252)
								GROUP BY 	instrument.reference, trades.sicovam, trades.depositaire
								HAVING 		round(SUM(trades.quantite),6) <> 0.000000
) OPEN_POSITIONS
ON OPEN_POSITIONS.sicovam = Sec.SICOVAM
where ( r.servisen IS NULL
				OR r.prefixe != 'Global'
				OR r.prefixe IS NULL
				OR r.fid != 1  ---Only Last is allowed for bond
				OR UnderlyingFutures.CODE_OAT IS NULL  --Without underlying bond setup
        )
; 

EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END BOND_FUTURE_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_NEW_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_NEW_INST(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MIFID2_NEW_INST
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
      TITRES.reference                                                                                       Reference_Code
		, TITRES.libelle                                                                                     Instrument_Name
		,   CASE 
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(TITRES.REFERENCE)=12 THEN TITRES.REFERENCE
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(ISIN.VALUE)=12 THEN ISIN.VALUE
           ELSE    ''
        END
        AS ISIN
    ,  CASE
          WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
          ELSE SPH_OWNER.BTG_GET_CFI_CODE(TITRES.SICOVAM)
        END AS CFI
    , TITRES.sicovam                                                                                     Sicovam            
    , DEVISE_TO_STR(TITRES.DEVISECTT)                                                                    CCY
    , btg_get_instrument_type(TITRES.sicovam)                                                            Instrument_Type
    , AFFECTATION.libelle                                                                                Allotment
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       Market    
    , DECODE(titres.type, 'F', MAP_ESMA.OUTPUT_CODE, MARKET_ESMA.VALUE)                                  ESMA_Flag_on_Market
    
    , RISKUSERS.NAME                                                                                     Set_Up_By
		, TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS')                           Created
		
    
		, LISTAGG(UNDERLYING_INFO.UND_REF,';') WITHIN GROUP(order by null) Underlying_Reference
    , LISTAGG(UNDERLYING_INFO.UND_NAME,';') WITHIN GROUP(order by null) Underlying_Instrument_Name
    , LISTAGG(UNDERLYING_INFO.UND_ISIN,';') WITHIN GROUP(order by null) Underlying_ISIN
    , LISTAGG(UNDERLYING_INFO.UND_CFI,';') WITHIN GROUP(order by null) Underlying_CFI
    , LISTAGG(UNDERLYING_INFO.UND_sicovam,';') WITHIN GROUP(order by null) Underlying_Sicovam
    , LISTAGG(UNDERLYING_INFO.UND_CCY,';') WITHIN GROUP(order by null) Underlying_Currency
    , LISTAGG(UNDERLYING_INFO.UND_instrument_type,';') WITHIN GROUP(order by null) Underlying_Instrument_Type
    , LISTAGG(UNDERLYING_INFO.UND_ALLOTMENT,';') WITHIN GROUP(order by null) Underlying_Allotment 
    , (SELECT COUNT(*) FROM AMRECON_VACATIONS av 
    left join histomvts h on h.refcon = av.refcon 
    INNER JOIN USERINFOS ON h.OPERATEUR = USERINFOS.IDENT
    LEFT JOIN TITRES SEC ON h.SICOVAM = SEC.SICOVAM
    inner join tiers cpty on cpty.ident = h.contrepartie
    inner join tiers broker on broker.ident = h.courtier  
    LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = 
      case when Sec.type='A' then Sec.base1 
      when Sec.type='D' then Sec.codesj      
      when Sec.type='B' then Sec.taux_var   
      when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
    LEFT JOIN btg_mapping_code MAP_ESMA 
    ON SEC.marche = MAP_ESMA.input_code 
    AND MAP_ESMA.source_id=3  
    AND MAP_ESMA.type_id=25
    ---INSTRUMENT ESMA FLAGS---
------UNDERLYING FUTURE MARKET 'ESMA Regulated (Y/N)' INFORMATION STORED IN BTG_MAPPING_CODE------
LEFT JOIN btg_mapping_code UND_MAP_ESMA
ON  Underlying1.marche = UND_MAP_ESMA.input_code
AND UND_MAP_ESMA.source_id=3 
AND UND_MAP_ESMA.type_id=25

------INSTRUMENT MARKET EXTERNAL REFERENCE 'ESMA Regulated (Y/N)'------
LEFT JOIN extrnl_ref_market_value MARKET_ESMA 
on sec.marche = MARKET_ESMA.market
and MARKET_ESMA.ref_ident=8
and MARKET_ESMA.CURRENCY = sec.devisectt

------UNDERLYING MARKET EXTERNAL REFERENCE 'ESMA Regulated (Y/N)'------
LEFT JOIN extrnl_ref_market_value UND_MARKET_ESMA
on Underlying1.marche = UND_MARKET_ESMA.market
and UND_MARKET_ESMA.ref_ident=8
and UND_MARKET_ESMA.CURRENCY = Underlying1.devisectt  

    
    WHERE av.esid = 4334 and h.sicovam = titres.sicovam
    AND upper(userinfos.country) = 'UK'
    AND             (broker.name not like ('INTERNAL%') and broker.name not like ('PB TRANSFER%') and broker.ident not in (10012815,10010875,10010876,10010878,10003642))
    AND             (cpty.name not like ('INTERNAL%') and cpty.name not like ('PB TRANSFER%')and cpty.ident not in (10012815,10010875,10010876,10010878,10003642))
    AND             h.dateneg > '02-JAN-2018'  --MiFIR starts post this date 
    AND (
(
  sec.AFFECTATION = 5 
  and
  (
    --Futures which isnt type is (Commodity Futures or Exchange Rate Futures or Interest Rate Futures) must have market in EEA
    (BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) in (24,25,26) and MAP_ESMA.OUTPUT_CODE='Y')
     or
    BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) not in (24,25,26)
  )
)
or
(
  --Listed Option or TBA which isnt type is (Commodity Derivatives or Exchange Rate Option or Interest Rate Option) must have market in EEA or the underlying instrument market in EEA
  sec.AFFECTATION in (10,34)
  and
  (
   (BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) in (38,39,40) and (MARKET_ESMA.VALUE = 'Y' or UND_MARKET_ESMA.VALUE = 'Y' or UND_MAP_ESMA.OUTPUT_CODE = 'Y') )
   or
   BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) not in (38,39,40)
  )
)
or
(
  --CDS which underlying is not index or if index must be a 5Y on iTraxx Europe Main or iTraxx Europe Crossover
  sec.AFFECTATION = 22
  and
  (
   Underlying1.type = 'I' and (UPPER(sec.REFERENCE) LIKE '%ITXEB%' OR  UPPER(sec.REFERENCE) LIKE '%ITXEX%') and round(months_between(sec.DATEFINAL,sec.EMISSION),0) = 63 
   or
   Underlying1.type != 'I'
  )
)
or
(
  --Underlying CDS must be a 5Y on iTraxx Europe Main or iTraxx Europe Crossover
  sec.AFFECTATION = 1250
  and  
  (UPPER(Underlying1.REFERENCE) LIKE '%ITXEB%' OR  UPPER(Underlying1.REFERENCE) LIKE '%ITXEX%') and round(months_between(Underlying1.DATEFINAL,Underlying1.EMISSION),0) = 63   
)
or
sec.AFFECTATION not in (10,34,5,22,1250)
) ) Allocations_trades_MiFIR_file
,'' Comments


	FROM TITRES
LEFT JOIN
(
                       SELECT      CASE WHEN Underlying1.TYPE = 'H' THEN ''
                                        WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN
                                                    CASE 
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying_Bond_Futures.REFERENCE)=12 THEN Underlying_Bond_Futures.REFERENCE
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE
                                                    END
                                        WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN                                         
                                                    CASE 
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying_Basket_Inst.REFERENCE)=12 THEN Underlying_Basket_Inst.REFERENCE
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE
                                                    END
                                        WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying1.REFERENCE)=12 THEN Underlying1.REFERENCE
                                        WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE                                                                                        
                                        ELSE    ''
                                        END
                    AS UND_ISIN
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.REFERENCE 
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.REFERENCE  
                                         ELSE Underlying1.REFERENCE END AS UND_REF
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.libelle
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.libelle 
                                         ELSE Underlying1.libelle END AS UND_NAME
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END as UND_sicovam
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN btg_get_instrument_type(Underlying_Basket_Inst.SICOVAM)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN btg_get_instrument_type(Underlying_Bond_Futures.SICOVAM)
                                         ELSE btg_get_instrument_type(Underlying1.SICOVAM) END as UND_instrument_type
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN DEVISE_TO_STR(Underlying_Basket_Inst.DEVISECTT)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN DEVISE_TO_STR(Underlying_Bond_Futures.DEVISECTT)
                                         ELSE DEVISE_TO_STR(Underlying1.DEVISECTT) END as UND_CCY                                         
                  , CASE
                                        WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
                                        WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN SPH_OWNER.BTG_GET_CFI_CODE(Underlying_Basket_Inst.SICOVAM)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN SPH_OWNER.BTG_GET_CFI_CODE(Underlying_Bond_Futures.SICOVAM)
                                         ELSE SPH_OWNER.BTG_GET_CFI_CODE(Underlying1.SICOVAM) 
                                        END AS UND_CFI
                  , UND_ALLOT.LIBELLE as UND_ALLOTMENT                                        
                  , SEC.SICOVAM AS SICOVAM

        FROM TITRES Sec

        LEFT JOIN extrnl_references_instruments UND_ADR
        ON UND_ADR.ref_ident = 672 and sophis_ident=Sec.sicovam
        

        ------ UNDERLYING INSTRUMENT ------
        LEFT JOIN   titres Underlying1
        ON Underlying1.sicovam =
        case when Sec.type='A' then to_number(nvl(COALESCE(TO_NUMBER(REGEXP_SUBSTR(UND_ADR.value, '^\d+')), 0),Sec.base1))
        when Sec.type='D' then Sec.codesj
        when Sec.type='B' then Sec.taux_var
        when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) 
        else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end
        
        ------ UNDERLYING BASKET ------ 
        LEFT JOIN panier UNDERLYING_BASKET
        ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM
        and Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=13107
        
        ------ UNDERLYING BASKET INSTRUMENT ------
        LEFT JOIN titres Underlying_Basket_Inst
        ON Underlying_Basket_Inst.sicovam = UNDERLYING_BASKET.sicopanier

        ------ UNDERLYING BOND FUTURES INSTRUMENT ------
        LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
        ON UnderlyingFutures.CODE = Sec.sicovam
        AND UnderlyingFutures.NUMERO = 0
        
        LEFT JOIN TITRES Underlying_Bond_Futures
        ON Underlying_Bond_Futures.SICOVAM = UnderlyingFutures.CODE_OAT
        
        ---UNDERLYING ID---
        left join EXTRNL_REFERENCES_INSTRUMENTS Und_ISIN
        ON Und_ISIN.SOPHIS_IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END)
        AND Und_ISIN.REF_IDENT = 1

        left join references UND_UR_REF
        on UND_UR_REF.allotment = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.AFFECTATION 
                                        WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM  
                                        ELSE Underlying1.AFFECTATION END)
        and UND_UR_REF.reference ='ISIN'
        
          
        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CFI_CODE
        ON CFI_CODE.SOPHIS_IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END)
        AND CFI_CODE.REF_IDENT = 690                                         
                                                   
        LEFT JOIN AFFECTATION UND_ALLOT
        ON UND_ALLOT.IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.AFFECTATION
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.AFFECTATION 
                                         ELSE Underlying1.AFFECTATION END)
        
        ---END OF UNDERLYING ID---
        
  
  ) UNDERLYING_INFO
  ON UNDERLYING_INFO.SICOVAM = TITRES.SICOVAM
  
	INNER JOIN INFOS_HISTO 
    ON TITRES.sicovam = INFOS_HISTO.sicovam
		AND INFOS_HISTO.modif = 1 --just the intial creation
		AND INFOS_HISTO.type_table = 3 --list only the addition to the titres table so we don't get dupes
		AND num_to_date(INFOS_HISTO.date_validite) > SYSDATE - ((1 / 24) * 25) --last day (25 hours)
    
	LEFT JOIN AFFECTATION 
    ON TITRES.affectation = AFFECTATION.ident
	LEFT JOIN RISKUSERS 
    ON infos_histo.userident = RISKUSERS.ident
	LEFT JOIN MARCHE 
    ON TITRES.marche = MARCHE.mnemomarche
		AND TITRES.devisectt = MARCHE.codedevise
	LEFT JOIN MARCHEORGANISE 
    ON TITRES.marche = MARCHEORGANISE.ident

  
  LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISIN
  ON ISIN.SOPHIS_IDENT = TITRES.SICOVAM
  AND ISIN.REF_IDENT = 1

  LEFT JOIN references UR_REF
  ON UR_REF.allotment = TITRES.AFFECTATION
  AND UR_REF.reference ='ISIN'  
  
  LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CFI_CODE
  ON CFI_CODE.SOPHIS_IDENT = TITRES.SICOVAM
  AND CFI_CODE.REF_IDENT = 690
  
  LEFT JOIN extrnl_ref_market_value MARKET_ESMA 
  on TITRES.marche = MARKET_ESMA.market 
  and MARKET_ESMA.ref_ident=8 
  and MARKET_ESMA.CURRENCY = TITRES.devisectt 

  LEFT JOIN btg_mapping_code MAP_ESMA 
  ON  TITRES.marche = MAP_ESMA.input_code 
  AND MAP_ESMA.source_id=3  
  AND MAP_ESMA.type_id=25 
  
	WHERE TITRES.type ! = 'L' -- not a repo
  AND AFFECTATION.ident ! = 20 --excluding cash/commission
  GROUP BY
 TITRES.reference                                                                                       
		, TITRES.libelle                                                                                    
		,   CASE 
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(TITRES.REFERENCE)=12 THEN TITRES.REFERENCE
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(ISIN.VALUE)=12 THEN ISIN.VALUE
           ELSE    ''
        END
        
    ,  CASE
          WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
          ELSE SPH_OWNER.BTG_GET_CFI_CODE(TITRES.SICOVAM)
        END 
    , TITRES.sicovam                                                                                     
    , DEVISE_TO_STR(TITRES.DEVISECTT)                                                                    
    , btg_get_instrument_type(TITRES.sicovam)                                                            
    , AFFECTATION.libelle                                                                                
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       
    , DECODE(titres.type, 'F', MAP_ESMA.OUTPUT_CODE, MARKET_ESMA.VALUE)                                  
    
    , RISKUSERS.NAME                                                                                     
	, TO_CHAR(num_to_date(INFOS_HISTO.date_validite), 'YYYY-MM-DD HH24:MI:SS')
  order by btg_get_instrument_type(TITRES.sicovam) , AFFECTATION.libelle 
    ;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: MIFID2_NEW_INST
	-- *****************************************************************   
END MIFID2_NEW_INST;

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_AMEND_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_AMEND_INST(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MIFID2_AMEND_INST
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
      TITRES.reference                                                                                       Reference_Code
		, TITRES.libelle                                                                                     Instrument_Name
		,   CASE 
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(TITRES.REFERENCE)=12 THEN TITRES.REFERENCE
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(ISIN.VALUE)=12 THEN ISIN.VALUE
           ELSE    ''
        END
        AS ISIN
    ,  CASE
          WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
          ELSE SPH_OWNER.BTG_GET_CFI_CODE(TITRES.SICOVAM)
        END AS CFI
    , TITRES.sicovam                                                                                     Sicovam            
    , DEVISE_TO_STR(TITRES.DEVISECTT)                                                                    CCY
    , btg_get_instrument_type(TITRES.sicovam)                                                            Instrument_Type
    , AFFECTATION.libelle                                                                                Allotment
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       Market    
    , DECODE(titres.type, 'F', MAP_ESMA.OUTPUT_CODE, MARKET_ESMA.VALUE)                                  ESMA_Flag_on_Market
    
    ,  NVL(RISKUSERS.NAME,    audit_ext.AUDIT_USER_NAME)                                                                                    Changed_By
		, TO_CHAR(num_to_date(AUDIT_TITRES.date_validite), 'YYYY-MM-DD HH24:MI:SS')                           Created
		
    
		, LISTAGG(UNDERLYING_INFO.UND_REF,';') WITHIN GROUP(order by null) Underlying_Reference
    , LISTAGG(UNDERLYING_INFO.UND_NAME,';') WITHIN GROUP(order by null) Underlying_Instrument_Name
    , LISTAGG(UNDERLYING_INFO.UND_ISIN,';') WITHIN GROUP(order by null) Underlying_ISIN
    , LISTAGG(UNDERLYING_INFO.UND_CFI,';') WITHIN GROUP(order by null) Underlying_CFI
    , LISTAGG(UNDERLYING_INFO.UND_sicovam,';') WITHIN GROUP(order by null) Underlying_Sicovam
    , LISTAGG(UNDERLYING_INFO.UND_CCY,';') WITHIN GROUP(order by null) Underlying_Currency
    , LISTAGG(UNDERLYING_INFO.UND_instrument_type,';') WITHIN GROUP(order by null) Underlying_Instrument_Type
    , LISTAGG(UNDERLYING_INFO.UND_ALLOTMENT,';') WITHIN GROUP(order by null) Underlying_Allotment 
    , (SELECT COUNT(*) FROM AMRECON_VACATIONS av 
    left join histomvts h on h.refcon = av.refcon 
    INNER JOIN USERINFOS ON h.OPERATEUR = USERINFOS.IDENT
    LEFT JOIN TITRES SEC ON h.SICOVAM = SEC.SICOVAM
    inner join tiers cpty on cpty.ident = h.contrepartie
    inner join tiers broker on broker.ident = h.courtier  
    LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = 
      case when Sec.type='A' then Sec.base1 
      when Sec.type='D' then Sec.codesj      
      when Sec.type='B' then Sec.taux_var   
      when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
    LEFT JOIN btg_mapping_code MAP_ESMA 
    ON SEC.marche = MAP_ESMA.input_code 
    AND MAP_ESMA.source_id=3  
    AND MAP_ESMA.type_id=25
    ---INSTRUMENT ESMA FLAGS---
------UNDERLYING FUTURE MARKET 'ESMA Regulated (Y/N)' INFORMATION STORED IN BTG_MAPPING_CODE------
LEFT JOIN btg_mapping_code UND_MAP_ESMA
ON  Underlying1.marche = UND_MAP_ESMA.input_code
AND UND_MAP_ESMA.source_id=3 
AND UND_MAP_ESMA.type_id=25

------INSTRUMENT MARKET EXTERNAL REFERENCE 'ESMA Regulated (Y/N)'------
LEFT JOIN extrnl_ref_market_value MARKET_ESMA 
on sec.marche = MARKET_ESMA.market
and MARKET_ESMA.ref_ident=8
and MARKET_ESMA.CURRENCY = sec.devisectt

------UNDERLYING MARKET EXTERNAL REFERENCE 'ESMA Regulated (Y/N)'------
LEFT JOIN extrnl_ref_market_value UND_MARKET_ESMA
on Underlying1.marche = UND_MARKET_ESMA.market
and UND_MARKET_ESMA.ref_ident=8
and UND_MARKET_ESMA.CURRENCY = Underlying1.devisectt  

    
    WHERE av.esid = 4334 and h.sicovam = titres.sicovam
    AND upper(userinfos.country) = 'UK'
    AND             (broker.name not like ('INTERNAL%') and broker.name not like ('PB TRANSFER%') and broker.ident not in (10012815,10010875,10010876,10010878,10003642))
    AND             (cpty.name not like ('INTERNAL%') and cpty.name not like ('PB TRANSFER%')and cpty.ident not in (10012815,10010875,10010876,10010878,10003642))
    AND             h.dateneg > '02-JAN-2018'  --MiFIR starts post this date 
    AND (
(
  sec.AFFECTATION = 5 
  and
  (
    --Futures which isnt type is (Commodity Futures or Exchange Rate Futures or Interest Rate Futures) must have market in EEA
    (BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) in (24,25,26) and MAP_ESMA.OUTPUT_CODE='Y')
     or
    BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) not in (24,25,26)
  )
)
or
(
  --Listed Option or TBA which isnt type is (Commodity Derivatives or Exchange Rate Option or Interest Rate Option) must have market in EEA or the underlying instrument market in EEA
  sec.AFFECTATION in (10,34)
  and
  (
   (BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) in (38,39,40) and (MARKET_ESMA.VALUE = 'Y' or UND_MARKET_ESMA.VALUE = 'Y' or UND_MAP_ESMA.OUTPUT_CODE = 'Y') )
   or
   BTG_GET_INSTRUMENT_TYPE_CODE(sec.sicovam) not in (38,39,40)
  )
)
or
(
  --CDS which underlying is not index or if index must be a 5Y on iTraxx Europe Main or iTraxx Europe Crossover
  sec.AFFECTATION = 22
  and
  (
   Underlying1.type = 'I' and (UPPER(sec.REFERENCE) LIKE '%ITXEB%' OR  UPPER(sec.REFERENCE) LIKE '%ITXEX%') and round(months_between(sec.DATEFINAL,sec.EMISSION),0) = 63 
   or
   Underlying1.type != 'I'
  )
)
or
(
  --Underlying CDS must be a 5Y on iTraxx Europe Main or iTraxx Europe Crossover
  sec.AFFECTATION = 1250
  and  
  (UPPER(Underlying1.REFERENCE) LIKE '%ITXEB%' OR  UPPER(Underlying1.REFERENCE) LIKE '%ITXEX%') and round(months_between(Underlying1.DATEFINAL,Underlying1.EMISSION),0) = 63   
)
or
sec.AFFECTATION not in (10,34,5,22,1250)
) ) Allocations_trades_MiFIR_file
, '' Comments


	FROM TITRES
LEFT JOIN
(
                       SELECT      CASE WHEN Underlying1.TYPE = 'H' THEN ''
                                        WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN
                                                    CASE 
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying_Bond_Futures.REFERENCE)=12 THEN Underlying_Bond_Futures.REFERENCE
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE
                                                    END
                                        WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN                                         
                                                    CASE 
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying_Basket_Inst.REFERENCE)=12 THEN Underlying_Basket_Inst.REFERENCE
                                                      WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE
                                                    END
                                        WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(Underlying1.REFERENCE)=12 THEN Underlying1.REFERENCE
                                        WHEN DECODE(UND_UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(Und_ISIN.VALUE)=12 THEN Und_ISIN.VALUE                                                                                        
                                        ELSE    ''
                                        END
                    AS UND_ISIN
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.REFERENCE 
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.REFERENCE  
                                         ELSE Underlying1.REFERENCE END AS UND_REF
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.libelle
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.libelle 
                                         ELSE Underlying1.libelle END AS UND_NAME
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END as UND_sicovam
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN btg_get_instrument_type(Underlying_Basket_Inst.SICOVAM)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN btg_get_instrument_type(Underlying_Bond_Futures.SICOVAM)
                                         ELSE btg_get_instrument_type(Underlying1.SICOVAM) END as UND_instrument_type
                  , CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN DEVISE_TO_STR(Underlying_Basket_Inst.DEVISECTT)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN DEVISE_TO_STR(Underlying_Bond_Futures.DEVISECTT)
                                         ELSE DEVISE_TO_STR(Underlying1.DEVISECTT) END as UND_CCY                                         
                  , CASE
                                        WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
                                        WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN SPH_OWNER.BTG_GET_CFI_CODE(Underlying_Basket_Inst.SICOVAM)
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN SPH_OWNER.BTG_GET_CFI_CODE(Underlying_Bond_Futures.SICOVAM)
                                         ELSE SPH_OWNER.BTG_GET_CFI_CODE(Underlying1.SICOVAM) 
                                        END AS UND_CFI
                  , UND_ALLOT.LIBELLE as UND_ALLOTMENT                                        
                  , SEC.SICOVAM AS SICOVAM

        FROM TITRES Sec

        LEFT JOIN extrnl_references_instruments UND_ADR
        ON UND_ADR.ref_ident = 672 and sophis_ident=Sec.sicovam
        

        ------ UNDERLYING INSTRUMENT ------
        LEFT JOIN   titres Underlying1
        ON Underlying1.sicovam =
        case when Sec.type='A' then to_number(nvl(COALESCE(TO_NUMBER(REGEXP_SUBSTR(UND_ADR.value, '^\d+')), 0),Sec.base1))
        when Sec.type='D' then Sec.codesj
        when Sec.type='B' then Sec.taux_var
        when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) 
        else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end
        
        ------ UNDERLYING BASKET ------ 
        LEFT JOIN panier UNDERLYING_BASKET
        ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM
        and Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=13107
        
        ------ UNDERLYING BASKET INSTRUMENT ------
        LEFT JOIN titres Underlying_Basket_Inst
        ON Underlying_Basket_Inst.sicovam = UNDERLYING_BASKET.sicopanier

        ------ UNDERLYING BOND FUTURES INSTRUMENT ------
        LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
        ON UnderlyingFutures.CODE = Sec.sicovam
        AND UnderlyingFutures.NUMERO = 0
        
        LEFT JOIN TITRES Underlying_Bond_Futures
        ON Underlying_Bond_Futures.SICOVAM = UnderlyingFutures.CODE_OAT
        
        ---UNDERLYING ID---
        left join EXTRNL_REFERENCES_INSTRUMENTS Und_ISIN
        ON Und_ISIN.SOPHIS_IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END)
        AND Und_ISIN.REF_IDENT = 1

        left join references UND_UR_REF
        on UND_UR_REF.allotment = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.AFFECTATION 
                                        WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM  
                                        ELSE Underlying1.AFFECTATION END)
        and UND_UR_REF.reference ='ISIN'
        
          
        LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CFI_CODE
        ON CFI_CODE.SOPHIS_IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.SICOVAM
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.SICOVAM 
                                         ELSE Underlying1.SICOVAM END)
        AND CFI_CODE.REF_IDENT = 690                                         
                                                   
        LEFT JOIN AFFECTATION UND_ALLOT
        ON UND_ALLOT.IDENT = (CASE WHEN Underlying1.TYPE = 'I' AND Underlying1.NBTITRES=131072 THEN Underlying_Basket_Inst.AFFECTATION
                                         WHEN SEC.TYPE = 'F' AND SEC.MODELE IN ('Notionnel','SFE 10 Year Bond Future','SFE 3 Year Bond Future') THEN Underlying_Bond_Futures.AFFECTATION 
                                         ELSE Underlying1.AFFECTATION END)
        
        ---END OF UNDERLYING ID---
        
  
  ) UNDERLYING_INFO
  ON UNDERLYING_INFO.SICOVAM = TITRES.SICOVAM
  
  LEFT join (
			select ih.sicovam as original_sico, DATE_VALIDITE, ih.userident ,  th.* from TITRES_HISTO th
			inner join INFOS_HISTO ih
			on ih.NEW_SICOVAM = th.sicovam
			and ih.MODIF = 2
			and ih.nom_table = 'titres'
			and ih.DATE_VALIDITE = (select min(INFOS_HISTO.DATE_VALIDITE) from INFOS_HISTO where MODIF = 2 and nom_table = 'titres' and sicovam = ih.sicovam and num_to_date(date_validite) > SYSDATE - ((1 / 24) * 25))  
			and ih.sicovam not in (select sicovam from INFOS_HISTO where MODIF = 1 and nom_table = 'titres' and sicovam = ih.sicovam and num_to_date(date_validite) > SYSDATE - ((1 / 24) * 25))
  ) AUDIT_TITRES
  on AUDIT_TITRES.original_sico = TITRES.SICOVAM
  
  left join
  (
			select sophis_ident, ext_audit.AUDIT_USER_NAME, ext_audit.AUDIT_DATE  from btg_extrnl_ref_instr_audit ext_audit
			where ext_audit.audit_date = (select Min(AUDIT_DATE) from btg_extrnl_ref_instr_audit where sophis_ident = ext_audit.sophis_ident and  audit_date > SYSDATE - ((1 / 24) * 25) )
			and ext_audit.REF_IDENT = 1
			and sophis_ident not in (select sicovam from INFOS_HISTO where MODIF = 1 and nom_table = 'titres' and sicovam = ext_audit.sophis_ident and num_to_date(date_validite) > SYSDATE - ((1 / 24) * 25))
  ) audit_ext
  on audit_ext.sophis_ident = titres.sicovam
    
	LEFT JOIN AFFECTATION 
    ON TITRES.affectation = AFFECTATION.ident
	LEFT JOIN RISKUSERS 
    ON AUDIT_TITRES.userident = RISKUSERS.ident
	LEFT JOIN MARCHE 
    ON TITRES.marche = MARCHE.mnemomarche
		AND TITRES.devisectt = MARCHE.codedevise
	LEFT JOIN MARCHEORGANISE 
    ON TITRES.marche = MARCHEORGANISE.ident

  
  LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ISIN
  ON ISIN.SOPHIS_IDENT = TITRES.SICOVAM
  AND ISIN.REF_IDENT = 1

  LEFT JOIN references UR_REF
  ON UR_REF.allotment = TITRES.AFFECTATION
  AND UR_REF.reference ='ISIN'  
  
  LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS CFI_CODE
  ON CFI_CODE.SOPHIS_IDENT = TITRES.SICOVAM
  AND CFI_CODE.REF_IDENT = 690
  
  LEFT JOIN extrnl_ref_market_value MARKET_ESMA 
  on TITRES.marche = MARKET_ESMA.market 
  and MARKET_ESMA.ref_ident=8 
  and MARKET_ESMA.CURRENCY = TITRES.devisectt 

  LEFT JOIN btg_mapping_code MAP_ESMA 
  ON  TITRES.marche = MAP_ESMA.input_code 
  AND MAP_ESMA.source_id=3  
  AND MAP_ESMA.type_id=25 
  
	WHERE TITRES.type ! = 'L' -- not a repo
  AND AFFECTATION.ident ! = 20 --excluding cash/commission
  AND ( 
        (AUDIT_TITRES.SICOVAM IS NOT NULL AND 
        ( TITRES.REFERENCE != AUDIT_TITRES.REFERENCE OR  TITRES.LIBELLE != AUDIT_TITRES.LIBELLE OR  TITRES.codesj != AUDIT_TITRES.codesj
        OR  TITRES.taux_var != AUDIT_TITRES.taux_var  OR  TITRES.taux_var != AUDIT_TITRES.taux_var
        OR decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) ! = decode(AUDIT_TITRES.jambe1,1,AUDIT_TITRES.j2refcon2,decode(AUDIT_TITRES.j1refcon2,0,AUDIT_TITRES.j2refcon2,AUDIT_TITRES.j1refcon2))
        OR TITRES.AFFECTATION != AUDIT_TITRES.AFFECTATION OR  TITRES.DEVISECTT != AUDIT_TITRES.DEVISECTT OR TITRES.MODELE != AUDIT_TITRES.MODELE 
        OR TITRES.NBTITRES != AUDIT_TITRES.NBTITRES OR TITRES.FINPER != AUDIT_TITRES.FINPER OR TITRES.prixexer != AUDIT_TITRES.prixexer
        OR TITRES.typesj ! = AUDIT_TITRES.typesj))
        OR
        audit_ext.SOPHIS_IDENT IS NOT NULL
      )
  GROUP BY
 TITRES.reference                                                                                       
		, TITRES.libelle                                                                                    
		,   CASE 
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=1 AND LENGTH(TITRES.REFERENCE)=12 THEN TITRES.REFERENCE
           WHEN DECODE(UR_REF.MODEL,'Reference',1,0)=0 AND LENGTH(ISIN.VALUE)=12 THEN ISIN.VALUE
           ELSE    ''
        END
    ,  CASE
          WHEN CFI_CODE.VALUE IS NOT NULL THEN CFI_CODE.VALUE
          ELSE SPH_OWNER.BTG_GET_CFI_CODE(TITRES.SICOVAM)
        END 
    , TITRES.sicovam                                                                                     
    , DEVISE_TO_STR(TITRES.DEVISECTT)                                                                    
    , btg_get_instrument_type(TITRES.sicovam)                                                            
    , AFFECTATION.libelle                                                                                
		, DECODE(titres.type, 'F', MARCHEORGANISE.nom, MARCHE.libelle)                                       
    , DECODE(titres.type, 'F', MAP_ESMA.OUTPUT_CODE, MARKET_ESMA.VALUE)                                  
    
   ,  NVL(RISKUSERS.NAME,    audit_ext.AUDIT_USER_NAME)                                                                                 
		, TO_CHAR(num_to_date(AUDIT_TITRES.date_validite), 'YYYY-MM-DD HH24:MI:SS')         
    order by btg_get_instrument_type(TITRES.sicovam) , AFFECTATION.libelle 
    ;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
	-- *****************************************************************
	-- END OF: MIFID2_AMEND_INST
	-- *****************************************************************   
END MIFID2_AMEND_INST;

-- *****************************************************************
-- Description:     PROCEDURE  FUT_BRL_MISSING_LAST_TRADE_DT
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 16 JAN 2018      Andre Bresslau  PMGMRISK-165 Created
-- ***************************************************************** 

PROCEDURE FUT_BRL_MISSING_LAST_TRADE_DT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: FUT_BRL_MISSING_LAST_TRADE_DT
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

SELECT T.SICOVAM
	,T.LIBELLE NAME
	,T.REFERENCE
	,A.LIBELLE ALLOTMENT	
	,TO_CHAR(T.ECHEANCE,'DD-MON-YYYY') MATURITY
	,ERI.VALUE LAST_TRADEABLE_DT
	,BTG_FN_AUDIT_INST_USER(T.SICOVAM) INSTR_LAST_AMENDED_BY
  ,DECODE(ERI.VALUE,NULL,'Date missing. Input format YYYYMMDD','Invalid input. Date should have only 8 characters and YYYYMMDD format') COMMENTS
FROM TITRES T
INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
LEFT JOIN RIC ON (T.SICOVAM = RIC.SICOVAM)
LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ERI ON ERI.SOPHIS_IDENT = T.SICOVAM AND ERI.REF_IDENT = 691 --LAST_TRADEABLE_DT
WHERE DEVISE_TO_STR(T.DEVISECTT) = 'BRL' -- Only BRL
	AND T.TYPE IN ('F') -- Only check Futures
	AND T.ECHEANCE > '01-JAN-18' -- Maturity greater than 01-JAN-18
	AND (
		REPLACE(TRANSLATE(ERI.VALUE, '1234567890', '0000000000'), '0', NULL) IS NOT NULL -- Date input non numeric
		OR LENGTH(ERI.VALUE) != 8 -- Date input different than 8 characters 
		OR ERI.VALUE IS NULL
    )
ORDER BY 1,2,5;

EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);	
  -- *****************************************************************
	-- END OF: FUT_BRL_MISSING_LAST_TRADE_DT
	-- *****************************************************************   
END FUT_BRL_MISSING_LAST_TRADE_DT;

-- *****************************************************************
-- Description:     PROCEDURE  INST_WITH_FIXED_VOL
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 31 JAN 2018      Andre Bresslau  PMGMPMO-258 Created
-- ***************************************************************** 

PROCEDURE INST_WITH_FIXED_VOL(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INST_WITH_FIXED_VOL
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

SELECT T.SICOVAM
	,T.REFERENCE
	,A.LIBELLE ALLOTMENT
	,TO_CHAR(T.FINPER, 'DD-MON-YYYY') MATURITY
	,C.VALEUR FIXED_VOLATILITY
	,BTG_FN_AUDIT_INST_USER(T.SICOVAM) INSTR_LAST_AMENDED_BY
FROM TITRES T
INNER JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
INNER JOIN CLAUSE C ON C.SICOVAM = T.SICOVAM
	AND C.TYPE = 25
WHERE A.LIBELLE IN ('Listed Options','Swaptions')
	AND T.FINPER >= TRUNC(SYSDATE)
ORDER BY 2;

EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);	
  -- *****************************************************************
	-- END OF: INST_WITH_FIXED_VOL
	-- *****************************************************************   
END INST_WITH_FIXED_VOL;

END PCKG_BTG_EMAILER_EDM_REPORTS;