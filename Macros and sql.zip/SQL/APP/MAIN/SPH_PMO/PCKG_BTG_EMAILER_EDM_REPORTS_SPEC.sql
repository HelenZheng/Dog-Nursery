create or replace PACKAGE            "PCKG_BTG_EMAILER_EDM_REPORTS" 
AS

	TYPE T_CURSOR IS REF CURSOR;



-- *****************************************************************
-- Description:     PROCEDURE UNNECESSARY_SEDOLS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author			Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2015		Matt Kelly      Created.
-- *****************************************************************
  PROCEDURE UNNECESSARY_SEDOLS_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);



-- *****************************************************************
-- Description:     PROCEDURE NEW_MARKETS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 14 NOV 2013    Matt Kelly      Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- *****************************************************************
  PROCEDURE NEW_MARKETS_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
-- Description:     PROCEDURE EQUITY_EXCEPTION_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 02 MAY 2013    Matt Kelly       Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************
  PROCEDURE EQUITY_EXCEPTION_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  FUT_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan          Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE FUT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  OPT_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE OPT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
   -- *****************************************************************
 -- Description:     PROCEDURE  FUT_MARKET_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 12 Jun 2013    Jun Guan        Created.
 -- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
 --
 -- *****************************************************************  
  
  PROCEDURE FUT_MARKET_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  MARKET_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 11 JAN 2013    Jun Guan        Report Market missing data
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- *****************************************************************
  PROCEDURE MARKET_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_BAD_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 12 Aug 2013   Jun Guan          Created.
 -- 14 Aug 2013		Oliver South	    Added details checking funding/borrow currency
 -- 01 JAN 2014   Gustavo Binnie    Moved from EXCEPTION_BO to EDM package.
 -- *****************************************************************  
  
  PROCEDURE CFD_BAD_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE BOND_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  ADR_MISSING_UNDERLYING_INFO
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 JAN 2014    Gustavo Binnie  Created
-- *****************************************************************  
  PROCEDURE ADR_MISSING_UNDERLYING_INFO
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_BOND_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 JAN 2014      Matt Kelly          - Created.
-- 04 FEB 2014		Gustavo Binnie		- Moved from EXCEPTION_BO to EDM package.
--		                                - Changed the format to display all missing
--			                              data in a single column.
-- ***************************************************************** 
PROCEDURE CONVERT_BOND_EXCEPTION_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  TBA_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2014		Gustavo Binnie		- Created
-- ***************************************************************** 
PROCEDURE TBA_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  TRS_FULLY_FUNDED_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 FEB 2014		Gustavo Binnie		- Created
-- ***************************************************************** 
PROCEDURE TRS_FULLY_FUNDED_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_25HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 
	PROCEDURE NEW_INSTRUMENTS_T_25HRS
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_13HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 
PROCEDURE NEW_INSTRUMENTS_T_13HRS
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  RAPPTR_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 08 APR 2014		Matt Kelly			Created
-- ***************************************************************** 
PROCEDURE RAPPTR_EXCEPTION_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  ISSUE_DATE_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 24 APR 2014		Matt Kelly			Created
-- ***************************************************************** 
PROCEDURE ISSUE_DATE_EXCEPTION_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );



-- *****************************************************************
-- Description:     PROCEDURE  FUT_OPT_BAD_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 MAR 2014		  Jun Guan		        UnaVista file does not like ISIN for Future/Options
-- ***************************************************************** 
PROCEDURE FUT_OPT_BAD_DATA
  (
    p_CURSOR OUT T_CURSOR
  );

 -- *****************************************************************
 -- Description:     PROCEDURE  MISSING_BUS_CENTER_MAP
 --                  
 --
 -- Author:          Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 04 Jul 2014		 Gustavo Binnie Moved from PCKG_BTG_EMAILER_EXCEPTION_BO
 -- *****************************************************************  
  
  PROCEDURE MISSING_BUS_CENTER_MAP
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_CROSS_CURRENCY
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 11 Jul 2014      Matt Kelly		Created
 -- *****************************************************************  
  
  PROCEDURE CFD_CROSS_CURRENCY
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_NON_CROSS_CURRENCY
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 11 Jul 2014      Matt Kelly		Created
 -- *****************************************************************  
  
  PROCEDURE CFD_NON_CROSS_CURRENCY
	(
		p_CURSOR OUT T_CURSOR
	);


  
-- *****************************************************************
 -- Description:     PROCEDURE  CFD_DUPLICATES
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 15 AUG 2014      Matt Kelly			Created
 -- *****************************************************************  
  
  PROCEDURE CFD_DUPLICATES
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
 -- Description:     PROCEDURE  CFD_PRICING
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 02 Sep 2014     Oliver South			Created
 -- *****************************************************************  
  
  PROCEDURE CFD_PRICING
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
 -- Description:     PROCEDURE  COMMOD_AUTO
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 22 Sep 2014     Oliver South			Created
 -- *****************************************************************  

  PROCEDURE COMMOD_AUTO
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  FORW_VS_UND
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- ***************************************************************** 
  
  PROCEDURE FORW_VS_UND
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  UND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- ***************************************************************** 
 
  PROCEDURE UND_DEL_DATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  WEEKEND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- *****************************************************************

  PROCEDURE WEEKEND_DEL_DATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE DUMMY_INSTRUMENTS_NEW_EDIT 
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 OCT 2014      Gustavo Binnie         Created
-- *****************************************************************

  PROCEDURE DUMMY_INSTRUMENTS_NEW_EDIT
	(
		p_CURSOR OUT T_CURSOR
	);


  -- *****************************************************************
-- Description:     NEW_ISSUERS_T_25HRS
--
-- Author:          Ami Talati
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 Jan 2015      Ami Talati          Created
-- *****************************************************************

  PROCEDURE NEW_ISSUERS_T_25HRS
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     CROSS_ASSET_BOND_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 MAR 2015      JUN GUAN          Created
-- *****************************************************************

  PROCEDURE CROSS_ASSET_BOND_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     ISSUERS_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 MAR 2015      JUN GUAN            Created
-- *****************************************************************

  PROCEDURE ISSUERS_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     NEW_ISSUERS_T_1HRS
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 Apr 2015      Jun Guan          Created
-- *****************************************************************

  PROCEDURE NEW_ISSUERS_T_1HRS
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     CDS_BOND_MISSING_SPREAD_TYPE
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 28 Apr 2015      Jun Guan          Created
-- *****************************************************************

  PROCEDURE CDS_BOND_MISSING_SPREAD_TYPE
	(
		p_CURSOR OUT T_CURSOR
	);

  
-- *****************************************************************
-- Description:     BOND_FUTURE_MISSING_DATA
--
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 13 OCT 2017      Jeff Yu          Created
-- *****************************************************************

  PROCEDURE BOND_FUTURE_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_NEW_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_NEW_INST
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_AMEND_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_AMEND_INST
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FUT_BRL_MISSING_LAST_TRADEABLE_DT
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 16 JAN 2018      Andre Bresslau  PMGMRISK-165 Created
-- ***************************************************************** 
PROCEDURE FUT_BRL_MISSING_LAST_TRADE_DT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  INST_WITH_FIXED_VOL
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 31 JAN 2018      Andre Bresslau  PMGMPMO-258 Created
-- ***************************************************************** 
PROCEDURE INST_WITH_FIXED_VOL
	(
		p_CURSOR OUT T_CURSOR
	);

END PCKG_BTG_EMAILER_EDM_REPORTS;