create or replace
PACKAGE BODY "PCKG_BTG_EMAILER_EXCEPTION_BO" AS
	-- *****************************************************************
	-- Description:     PROCEDURE  WRONG_FOLIO_ENTITY
	-- Check to see that folio has the same entity as the root level fund                  
	--
	-- Author:          Jun Guan
	--
	-- Revision History
	-- Date             Author        Reason for Change
	-- ----------------------------------------------------------------
	-- 01 DEC 2012    Jun Guan      Created.
	-- *****************************************************************
	PROCEDURE WRONG_FOLIO_ENTITY (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: WRONG_FOLIO_ENTITY
	-- *****************************************************************    
	OPEN p_CURSOR
	FOR

SELECT 
		  ds.ident                Folio_ID
		, ds.NAME                 Folio_Name
		, nvl(tiers.NAME, 'XXX')  Folio_Entity
		, folio.NAME              Folio_Reside_Entity
		, ds.Path                 Path
	FROM (
		SELECT 
			  folio.ident
			, folio.NAME
			, folio.entite
			, nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'), 3, 4), ident) Fund
      , SYS_CONNECT_BY_PATH(FOLIO.NAME, '\') AS Path
		FROM folio
		WHERE LEVEL > 2 START
WITH ident = PCKG_BTG.FOLIO_BTG_FUND CONNECT BY mgr = prior ident
		) ds
	INNER JOIN folio
		ON folio.ident = ds.Fund
	LEFT JOIN tiers
		ON tiers.ident = ds.entite
	WHERE folio.NAME != nvl(tiers.NAME, 'XXX')
	ORDER BY 5;


	-- ***************************************************************************
	-- Check to see that folio has the same entity as the root level fund
	-- ***************************************************************************
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: WRONG_FOLIO_ENTITY
		-- *****************************************************************   
END

WRONG_FOLIO_ENTITY;

-- *****************************************************************
-- Description:     PROCEDURE  FRA_MISSING_DATA
-- Check to see that folio has the same entity as the root level fund                  
-- fra instruments with missing payment date 
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE FRA_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: FRA_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT DISTINCT inst.sicovam Sicovam
		,inst.libelle FRA_Name
		,inst.reference FRA_Reference
		,clause.datepaye d$Payment_date
		,BTG_FN_AUDIT_INST_USER(inst.sicovam) Instr_last_amended_by
	FROM titres inst
	LEFT JOIN clause
		ON inst.sicovam = clause.sicovam
			AND clause.type = 1
	WHERE inst.affectation = 33 --FRA
		AND inst.code_emet NOT IN (67602941) --BRL CDI O/N Rate are excluded
		AND clause.datepaye IS NULL --Missing payment date
		AND inst.echeance >= trunc(sysdate) --FRA has not matured
		;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: FRA_MISSING_DATA
		-- *****************************************************************   
END

FRA_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISSING_DATA_UCITS
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan			 Created.
-- 27 AGO 2013    Gustavo Binnie	-Included Blackstone and Russell funds
--									-Changed the name of the procedure
-- ***************************************************************** 
PROCEDURE BOND_MISSING_DATA_UCITS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: BOND_MISSING_DATA_UCITS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT DISTINCT inst.sicovam Instrument_Sicovam
		,inst.libelle Instrument_Name
		,inst.reference Instruemnt_Reference
		,inst.code_emet Issuer_ID
		,issuer.libelle Issuer_Name
		,issuer.reference Issuer_Reference
		,inst.marche Market
		,sector.sector Issuer_Country
		,BIC.value Market_BIC
		,BTG_FN_AUDIT_INST_USER(inst.sicovam) Instr_last_amended_by
	FROM titres inst
	INNER JOIN histomvts trade
		ON inst.sicovam = trade.sicovam
	INNER JOIN titres issuer
		ON issuer.sicovam = inst.code_emet
	LEFT JOIN sector_instrument_association sector
		ON issuer.sicovam = sector.sicovam
			AND sector.type = 1364
	LEFT JOIN extrnl_ref_market_value BIC
		ON inst.marche = BIC.market
			AND BIC.ref_ident = 3
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
		FROM FOLIO
		WHERE LEVEL > 2 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_EMBL_FUND
				,86244
				,90107
				) --(66762)--GLEM fund --BLACKSTONE -- RUSSELL
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = trade.OPCVM
	WHERE trade.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			) --Not deleted trades
		AND inst.type IN ('O') --Bonds
		AND inst.affectation NOT IN (1102) --Not TRS
		AND (
			(
				devise_to_str(inst.devisectt) NOT IN (
					'BRO'
					,'BRL'
					)
				AND inst.marche = 0
				) --Non BRL bond missing a market. BRL bonds default to Euroclear
			OR (sector.sector IS NULL) --country sector is missing from issuer
			OR (
				devise_to_str(inst.devisectt) NOT IN (
					'BRO'
					,'BRL'
					)
				AND bic.value IS NULL
				) --BIC code is missing from market
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: BOND_MISSING_DATA_UCITS  
		-- *****************************************************************   
END

BOND_MISSING_DATA_UCITS;

-- *****************************************************************
-- Description:     PROCEDURE  CASH_ACCT_FILTER_COUNT
--  /*Highlights any cash account filters that are duplicated*/               
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************   
PROCEDURE CASH_ACCT_FILTER_COUNT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CASH_ACCT_FILTER_COUNT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT COUNT(1) NOFILTERS
		,x.libelle FUND
		,t.NAME PBACCOUNT
		,DEVISE_TO_STR(b.currency) CCY
		,BTG_FN_AUDIT_THIRD_USER(t.ident) Third_party_last_amended_by
	FROM AM_ACCOUNT_FILTER b
		,tiers t
		,titres x
		,devisev2 d
	WHERE b.fund IN (
			SELECT sicovam
			FROM titres
			WHERE type = 'Z'
			)
		AND t.ident = b.pb
		AND x.sicovam = b.fund
		AND d.code = b.currency
	GROUP BY x.libelle
		,t.NAME
		,DEVISE_TO_STR(b.currency)
		,BTG_FN_AUDIT_THIRD_USER(t.ident)
	HAVING COUNT(1) > 1;

	/*Highlights any cash account filters that are duplicated*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: CASH_ACCT_FILTER_COUNT
		-- *****************************************************************   	
END

CASH_ACCT_FILTER_COUNT;

-- *****************************************************************
-- Description:     PROCEDURE  CASH_ACCT_COUNT
--    /*Highlights any cash accounts that are duplicated*/             
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
PROCEDURE CASH_ACCT_COUNT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CASH_ACCT_COUNT
	-- *****************************************************************    
	OPEN p_CURSOR
	FOR

	SELECT COUNT(1)
		,fund.NAME Fund
		,DEVISE_TO_STR(BO_TREASURY_ACCOUNT.ccy) CCY
		,BO_TREASURY_ACCOUNT.account_name accountName
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM BO_TREASURY_ACCOUNT
	LEFT JOIN devisev2
		ON devisev2.code = BO_TREASURY_ACCOUNT.ccy
	LEFT JOIN tiers
		ON tiers.ident = BO_TREASURY_ACCOUNT.depositary
	INNER JOIN tiers fund
		ON fund.ident = BO_TREASURY_ACCOUNT.entity
			AND fund.options = 18
			AND fund.mgr = 10003502
			AND fund.ident != 10003510
	GROUP BY fund.NAME
		,DEVISE_TO_STR(BO_TREASURY_ACCOUNT.ccy)
		,BO_TREASURY_ACCOUNT.account_name
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident)
	HAVING COUNT(1) > 1;

	/*Highlights any cash accounts that are duplicated*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: CASH_ACCT_COUNT
		-- *****************************************************************    	
END

CASH_ACCT_COUNT;

-- *****************************************************************
-- Description:     PROCEDURE  IR_MISSING28
-- /* Interest rates set up with external reference not set to 28 */             
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************      
PROCEDURE IR_MISSING28(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: IR_MISSING28
	-- *****************************************************************    
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,libelle NAME
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	WHERE type = 'R'
		AND (
			EXTERNREF != 28
			OR EXTERNREF IS NULL
			)
	ORDER BY 1 DESC;

	/* Interest rates set up with external reference not set to 28 */
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: IR_MISSING28
		-- *****************************************************************   
END

IR_MISSING28;

-- *****************************************************************
-- *****************************************************************
-- Description:     PROCEDURE  COMMA_IN_NAME
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************    
PROCEDURE COMMA_IN_NAME(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: COMMA_IN_NAME
	-- *****************************************************************          
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,libelle
		,REFERENCE NAME
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	WHERE (
			REFERENCE LIKE '%"%'
			OR REFERENCE LIKE '%,%'
			OR libelle LIKE '%"%'
			OR libelle LIKE '%,%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR libelle LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR upper(libelle) LIKE '%�%'
			OR upper(REFERENCE) LIKE '%�%'
			OR upper(libelle) LIKE '%�%'
			OR upper(REFERENCE) LIKE '%�%'
			OR upper(libelle) LIKE '%�%'
			OR upper(REFERENCE) LIKE '%�%'
            OR regexp_like(libelle,'[^ -'||chr(126)||']') 
            OR regexp_like(REFERENCE,'[^ -'||chr(126)||']')
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: COMMA_IN_NAME
		-- *****************************************************************            
END

COMMA_IN_NAME;

-- *****************************************************************
-- Description:     PROCEDURE  MISSING_AX_CODE
-- Author:          Jun Guan
--/* Counterparties missing an Aexeo code - causes problems in Citco files*/
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 05 Jun 2013	  Oliver South	PMWM-1
-- 02 FEB 2018   Jeff Yu    PMOG-1195
-- *****************************************************************  
PROCEDURE MISSING_AX_CODE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MISSING_AX_CODE
	-- *****************************************************************             
	OPEN p_CURSOR
	FOR

	SELECT TIERS.NAME COUNTERPARTY_NAME
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM TIERS TIERS
	LEFT JOIN TIERSPROPERTIES
		ON TIERSPROPERTIES.CODE = TIERS.ident
			AND TIERSPROPERTIES.NAME = 'AEXEO CODE'
	WHERE TIERS.OPTIONS IN (
			14
			,6
			) --Broker and counterparty
		AND TIERSPROPERTIES.VALUE IS NULL --missing Aexeo code
		AND TIERS.MGR NOT IN (10016967,10026581) --Wealth management group
		;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISSING_AX_CODE
		-- *****************************************************************            
END

MISSING_AX_CODE;

-- *****************************************************************
-- Description:     PROCEDURE  DUPE_BARRIER
-- Author:          Jun Guan
--/* FX Options with duplicate barriers - causes problems in Citco files*/
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE DUPE_BARRIER(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- END OF: DUPE_BARRIER
	-- *****************************************************************            
	OPEN p_CURSOR
	FOR

	SELECT COUNT(1) NOBarriers
		,c.sicovam
		,DECODE(c.type, 11, 'Barrier', 26, 'Up In', 27, 'Up Out', 28, 'Down In', 29, 'Down Out', 'Not A Barrier Type') BarrierType
		,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
	FROM clause c
		,titres t
	WHERE t.sicovam = c.sicovam
		AND c.type IN (
			11
			,26
			,27
			,28
			,29
			)
	GROUP BY c.sicovam
		,DECODE(c.type, 11, 'Barrier', 26, 'Up In', 27, 'Up Out', 28, 'Down In', 29, 'Down Out', 'Not A Barrier Type')
		,BTG_FN_AUDIT_INST_USER(t.sicovam)
	HAVING COUNT(1) > 1;

	/* FX Options with duplicate barriers - causes problems in Citco files*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: DUPE_BARRIER
		-- *****************************************************************            
END

DUPE_BARRIER;

-- *****************************************************************
-- Description:     PROCEDURE  INVALID_CALC_AGENT
-- Author:          Jun Guan
-- /* Swaps with invalid calculation agents*/
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE INVALID_CALC_AGENT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INVALID_CALC_AGENT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,SUM(montant) position
		,BTG_FN_AUDIT_INST_USER(histomvts.sicovam) Instr_last_amended_by
	FROM histomvts
	WHERE sicovam IN (
			SELECT titres.sicovam
			FROM titres /*REVIEW LINK BETWEEEN THESE TWO TABLES */
				,tiers
			WHERE calc_agent NOT IN (
					SELECT ident
					FROM tiers
					)
				AND type = 'S'
				AND calc_agent IS NOT NULL
				AND calc_agent != 0
			)
	GROUP BY sicovam
		,BTG_FN_AUDIT_INST_USER(histomvts.sicovam)
	HAVING SUM(montant) != 0;

	/* Swaps with invalid calculation agents*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: INVALID_CALC_AGENT
		-- *****************************************************************  
END

INVALID_CALC_AGENT;

-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_NOTIONAL
-- Author:          Jun Guan
--    The underlying IRS of a swaption must have the Notional set to 'No Exchange' 
--    in the notional tab for Pnull in 4.1 to calculate correctly
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE SWAPTION_NOTIONAL(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: SWAPTION_NOTIONAL
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT FUND_BOOK_STRATEGY.Fund_NAME Fund
		,FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
		,FUND_BOOK_STRATEGY.STRATEGY_NAME Strategy
		,security.reference NAME
		,SUM(histomvts.quantite) n$Quantity
		,histomvts.sicovam
		,BTG_FN_AUDIT_INST_USER(histomvts.sicovam) Instr_last_amended_by
	FROM histomvts
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --(14414,90565)--Primary funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.opcvm
	INNER JOIN titres security
		ON security.sicovam = histomvts.sicovam
	WHERE security.sicovam = histomvts.sicovam
		AND security.type IN ('D')
		AND security.codesj IN (
			SELECT g.sicovam
			FROM titres g
			WHERE g.type = 'S'
				AND g.quotite != 0
			)
	GROUP BY FUND_BOOK_STRATEGY.Fund_NAME
		,FUND_BOOK_STRATEGY.BOOK_NAME
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,security.reference
		,histomvts.sicovam
		,BTG_FN_AUDIT_INST_USER(histomvts.sicovam)
	HAVING SUM(histomvts.quantite) != 0
	ORDER BY 1
		,2;

	/* The underlying IRS of a swaption must have the Notional set to 'No Exchange' in the notional tab for Pnull in 4.1 to calculate correctly*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: SWAPTION_NOTIONAL
		-- ***************************************************************** 
END

SWAPTION_NOTIONAL;

-- *****************************************************************
-- Description:     PROCEDURE  OPTION_MISSING_VALIDATION
-- Author:          Jun Guan
--   All options that have been traded and are still active that do not have the validation box checked
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE OPTION_MISSING_VALIDATION(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: OPTION_MISSING_VALIDATION
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,libelle NAME
		,REFERENCE
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	WHERE type = 'D'
		AND JAMBE2 = 0
		AND sicovam IN (
			SELECT sicovam
			FROM histomvts
			)
		AND (
			(debutper > TRUNC(sysdate))
			OR (finper > TRUNC(sysdate))
			OR (datecalcul > TRUNC(sysdate))
			);

	-- ***************************************************************************
	-- All options that have been traded and are still active that do not have the validation box checked
	-- ***************************************************************************
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: OPTION_MISSING_VALIDATION
		-- ***************************************************************** 
END

OPTION_MISSING_VALIDATION;

-- *****************************************************************
-- Description:     PROCEDURE  FXOPTION_MISSING_VOL
-- Author:          Jun Guan
--     All FX options that are missing a fixed volatility
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE FXOPTION_MISSING_VOL(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- END OF: FXOPTION_MISSING_VOL
	-- ***************************************************************** 
	OPEN p_CURSOR
	FOR

	SELECT DISTINCT t.sicovam
		,t.reference
		,t.libelle NAME
		,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
	FROM titres t
	INNER JOIN clause c
		ON c.sicovam = t.sicovam
	INNER JOIN histomvts trades
		ON trades.sicovam = t.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --(14414,90565)--Primary funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	WHERE t.type = 'D'
		AND c.valeur = 0
		AND c.type = 25
		AND Trades.BACKOFFICE NOT IN (
			11
			,13
			,17
			,26
			,27
			,192
			,220
			,248
			,252
			);

	-- ***************************************************************************
	-- All FX options that are missing a fixed volatility
	-- ***************************************************************************
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: FXOPTION_MISSING_VOL
		-- ***************************************************************** 
END

FXOPTION_MISSING_VOL;

-- *****************************************************************
-- Description:     PROCEDURE  BOVESPA_NOT_INDFUT
-- Author:          Jun Guan
--      All Futures that are missing an underlying
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE BOVESPA_NOT_INDFUT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BOVESPA_NOT_INDFUT
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,libelle NAME
		,REFERENCE
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	WHERE j1refcon1 != 1
		AND libelle LIKE '%BOVESPA%'
		AND type = 'F';

	-- ***************************************************************************
	-- All Futures that are missing an underlying
	-- ***************************************************************************
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: BOVESPA_NOT_INDFUT
		-- ***************************************************************** 
END

BOVESPA_NOT_INDFUT;

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_INTERPOLATION
-- Author:          Jun Guan
--      Curves cannot use Cubic Spline as an interpolation method in 3.3.4. Need to change to RT-linear
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE WRONG_INTERPOLATION(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: WRONG_INTERPOLATION
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

	SELECT c.libelle AS curve_name
		,t.libelle AS family_name
		,SUBSTR(num_to_str(t.codedev), 2) AS currency
	FROM courbetaux c
		,typecourbetaux t
	WHERE c.codetypecourbetaux = t.code
		AND c.modele = 'Cubic Spline';

	-- ***************************************************************************
	-- Curves cannot use Cubic Spline as an interpolation method in 3.3.4. Need to change to RT-linear
	-- ***************************************************************************
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: WRONG_INTERPOLATION
		-- ***************************************************************** 
END

WRONG_INTERPOLATION;



-- *****************************************************************
-- Description:     PROCEDURE  ALLOC_RULE_POSTPROC
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE ALLOC_RULE_POSTPROC(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- END OF: ALLOC_RULE_POSTPROC
	-- ***************************************************************** 		 
	OPEN p_CURSOR
	FOR

	SELECT ta_rules.NAME RULE
		,riskusers.NAME Culprit
	FROM ta_rules
		,riskusers
	WHERE riskusers.ident = ta_rules.user_id
		AND ta_rules.postproc != 'Swap Paying Leg Check Deal';
		-- *****************************************************************
		-- END OF: ALLOC_RULE_POSTPROC
		-- ***************************************************************** 
END

ALLOC_RULE_POSTPROC;

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_BASIS_UNDERLYING
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE CCY_CURVE_BASIS_UNDERLYING(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CCY_CURVE_BASIS_UNDERLYING
	-- ***************************************************************** 		
	OPEN p_CURSOR
	FOR

	SELECT libelle
	FROM TITRES
	WHERE TYPE = 'R'
		AND TAUX_VAR IN (
			SELECT SICOVAM
			FROM TITRES
			WHERE modele <> 'Standard'
			);
		-- *****************************************************************
		-- END OF: CCY_CURVE_BASIS_UNDERLYING
		-- ***************************************************************** 
END

CCY_CURVE_BASIS_UNDERLYING;

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_FX_IN_PARENT
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE CCY_CURVE_FX_IN_PARENT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CCY_CURVE_FX_IN_PARENT
	-- ***************************************************************** 		
	OPEN p_CURSOR
	FOR

	SELECT libelle
	FROM devisev2
	WHERE (
			typecourbemonetaire IN (
				SELECT codetypecourbetaux
				FROM courbetaux
				WHERE modele = 'Forex Curve'
				)
			)
		OR (
			typecourbemonetaire IS NULL
			AND CODE IN (
				SELECT CODEDEV
				FROM TYPECOURBETAUX
				WHERE CODE IN (
						SELECT codetypecourbetaux
						FROM courbetaux
						WHERE modele = 'Forex Curve'
						)
				)
			);
		-- *****************************************************************
		-- END OF: CCY_CURVE_FX_IN_PARENT
		-- ***************************************************************** 
END

CCY_CURVE_FX_IN_PARENT;

-- *****************************************************************
-- Description:     PROCEDURE  CDS_WRONG_RE
-- Author:          Jun Guan
--      
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
PROCEDURE CDS_WRONG_RE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CDS_WRONG_RE
	-- ***************************************************************** 	
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam
		,titres.libelle
		,titres2.sicovam
		,titres2.libelle
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN titres titres2
		ON titres.coupon1 = titres2.sicovam
	WHERE titres.TYPE = 'S' --swaps
		AND titres.default_event_leg1 != 0 -- CDS property
		AND (
			titres2.type NOT IN (
				'O'
				,'H'
				,'I'
				)
			) --underlyer must be bond, issuer or index
		;
		-- *****************************************************************
		-- END OF: CDS_WRONG_RE
		-- ***************************************************************** 
END

CDS_WRONG_RE;

-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_MISSING_MARKET_CREDIT
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 24 FEB 2017     Jeff Yu       Modified. (PMGMRISK-88 Modify position definition and exclude closed positions)
-- *****************************************************************  
PROCEDURE CONVERT_MISSING_MARKET_CREDIT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CONVERT_MISSING_MARKET_CREDIT
	-- ***************************************************************** 	 
	OPEN p_CURSOR
	FOR

	SELECT  SICOVAM, NAME, REFERENCE, BTG_FN_AUDIT_INST_USER(SICOVAM) INSTR_LAST_AMENDED_BY 
	FROM (
    SELECT DISTINCT TITRES.SICOVAM
                                ,TITRES.LIBELLE NAME
                                ,TITRES.REFERENCE

    FROM TITRES
    INNER JOIN HISTOMVTS
    ON HISTOMVTS.SICOVAM = TITRES.SICOVAM

    INNER JOIN (
                               SELECT FOLIO.IDENT AS STRATEGY_ID
                                                ,FOLIO.NAME AS STRATEGY_NAME
                                FROM FOLIO START WITH FOLIO.IDENT IN 
								(PCKG_BTG.FOLIO_PRIMARY_FUNDS
								,PCKG_BTG.FOLIO_UCITS_FUND
								) --(14414, 90565)
                                 CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
                                ) STRATEGIES
    ON STRATEGIES.STRATEGY_ID = HISTOMVTS.OPCVM

    LEFT JOIN BO_KERNEL_STATUS_COMPONENT   ------Exclude cancelled trades
    ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.BACKOFFICE
    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415  

    INNER JOIN BUSINESS_EVENTS BE  ----Deal quantity affects the number of security 
    ON  BE.ID = HISTOMVTS.TYPE
    AND BE.COMPTA = 1

    INNER JOIN TIERS
    ON TIERS.IDENT=HISTOMVTS.DEPOSITAIRE

    WHERE TITRES.AFFECTATION = 9
    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID IS NULL
    AND TITRES.SICOVAM NOT IN (
                                                SELECT SICOVAM
                                                FROM HISTORIQUE
                                                WHERE SPREAD IS NOT NULL
                                                )
    GROUP BY   TITRES.SICOVAM
                                ,TITRES.LIBELLE 
                                ,TITRES.REFERENCE
                                ,STRATEGY_ID
                                ,TIERS.NAME
    HAVING  SUM(HISTOMVTS.QUANTITE) != 0   -- Exclude closed positions.
    )
    ORDER BY  SICOVAM;
		-- *****************************************************************
		-- END OF: CONVERT_MISSING_MARKET_CREDIT
		-- ***************************************************************** 		
END

CONVERT_MISSING_MARKET_CREDIT;


-- *****************************************************************
-- Description:     PROCEDURE  EXCHANGE_MANY_DP
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
PROCEDURE EXCHANGE_MANY_DP(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: EXCHANGE_MANY_DP
	-- ***************************************************************** 
	OPEN p_CURSOR
	FOR

	SELECT DEVISE_TO_STR(codedevise) AS Currency
		,libelle AS "Exchange Name"
	FROM marche
	WHERE 9 IN (
			decimalescc
			,decimalesta
			)
	ORDER BY 1;
		-- *****************************************************************
		-- END OF: EXCHANGE_MANY_DP
		-- *****************************************************************
END

EXCHANGE_MANY_DP;

-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_GLBL_ABS_FOLIOS
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
PROCEDURE INCONSISTENT_GLBL_ABS_FOLIOS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INCONSISTENT_GLBL_ABS_FOLIOS
	-- *****************************************************************	 
	OPEN p_CURSOR
	FOR

	SELECT '"' || COALESCE(ARF2.path, GEMM.path) || '"' AS PATH
		,CASE 
			WHEN ARF2.path IS NULL
				THEN 'N'
			ELSE 'Y'
			END AS A_R_F_2
		,CASE 
			WHEN GEMM.path IS NULL
				THEN 'N'
			ELSE 'Y'
			END AS G_E_M_M
	FROM (
		SELECT SYS_CONNECT_BY_PATH(FOLIO.NAME, '\') AS PATH
		FROM FOLIO START WITH FOLIO.ident IN (44984) --Global ABS
			CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
		) ARF2
	FULL OUTER JOIN (
		SELECT SYS_CONNECT_BY_PATH(FOLIO.NAME, '\') AS PATH
		FROM FOLIO START WITH FOLIO.ident IN (52364) --Global ABS
			CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
		) GEMM
		ON GEMM.path = ARF2.path
	WHERE ARF2.path IS NULL
		OR GEMM.path IS NULL
	ORDER BY 1;
		-- *****************************************************************
		-- END OF: INCONSISTENT_GLBL_ABS_FOLIOS
		-- *****************************************************************
END

INCONSISTENT_GLBL_ABS_FOLIOS;


-- *****************************************************************
-- Description:     PROCEDURE  PUBLIC_ALLOC_RULE
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************   
PROCEDURE PUBLIC_ALLOC_RULE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: PUBLIC_ALLOC_RULE
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT ta_rules.NAME RULE
		,riskusers.NAME Culprit
	FROM ta_rules
		,riskusers
	WHERE riskusers.ident = ta_rules.user_id
		AND ta_rules.private = 0;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: PUBLIC_ALLOC_RULE
		-- *****************************************************************  	
END

PUBLIC_ALLOC_RULE;

-- *****************************************************************
-- Description:     PROCEDURE  TRS_MISSING_ISIN
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 17 FEB 2013	Oliver South	Changed it as part of SR-68
-- *****************************************************************  
PROCEDURE TRS_MISSING_ISIN(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: TRS_MISSING_ISIN
	-- *****************************************************************  	 
	OPEN p_CURSOR
	FOR

	SELECT DISTINCT Instrument.sicovam sicovam
		,Instrument.libelle InstrumentName
		,Instrument.reference InstrumentReference
		,extrnl_references_instruments.value ISIN
		,BTG_FN_AUDIT_INST_USER(instrument.sicovam) Instr_last_amended_by
	FROM titres instrument
	LEFT JOIN extrnl_references_instruments
		ON extrnl_references_instruments.sophis_ident = instrument.sicovam
			AND extrnl_references_instruments.ref_ident = 1
	WHERE Instrument.affectation = 1102
		AND extrnl_references_instruments.value IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: TRS_MISSING_ISIN
		-- *****************************************************************  		
END

TRS_MISSING_ISIN;

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_FIFO
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************   
PROCEDURE WRONG_FIFO(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: WRONG_FIFO
	-- ***************************************************************** 		
	OPEN p_CURSOR
	FOR

	SELECT CASE 
			WHEN type_report = 0
				THEN 'FIFO'
			WHEN type_report = 1
				THEN 'LIFO'
			WHEN type_report = 2
				THEN 'WAP'
			ELSE 'No idea of PnL method - revert to FIFO Futures'
			END AS PnLMethod
	FROM REPORTING
	WHERE type_report != 4;
		-- *****************************************************************
		-- END OF: WRONG_FIFO
		-- ***************************************************************** 	
END

WRONG_FIFO;

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_TERM_OIS_RATE
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************    
PROCEDURE WRONG_TERM_OIS_RATE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: WRONG_TERM_OIS_RATE
	-- ***************************************************************** 	 
	OPEN p_CURSOR
	FOR

	SELECT sicovam
		,libelle NAME
		,REFERENCE
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	WHERE family IN (
			2398
			,2558
			)
		AND type = 'R'
		AND to_date(echeance, 'DD-MON-YY') != to_date('07-JUN-83', 'DD-MON-YY');
		/* Traded equities missing SEDOL*/
		-- *****************************************************************
		-- END OF: WRONG_TERM_OIS_RATE
		-- ***************************************************************** 	
END

WRONG_TERM_OIS_RATE;


-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_MISSING_DATA
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************    
PROCEDURE SWAPTION_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: SWAPTION_MISSING_DATA
	-- *****************************************************************    
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
		,titres.libelle Swaption_Name
		,titres.reference Swaption_Reference
		,marche.libelle Market_Name
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN marche
		ON marche.mnemomarche = titres.marche
			AND titres.devisectt = marche.codedevise
	WHERE titres.affectation = 31 --swaption
		AND titres.finper > trunc(sysdate) - 1 --not expired
		AND marche.libelle IS NULL --market missing name
		;
		-- *****************************************************************
		-- END OF: SWAPTION_MISSING_DATA
		-- *****************************************************************  	
END

SWAPTION_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  CDS_OPTION_WRONG_ALLOTMENT
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************          
PROCEDURE CDS_OPTION_WRONG_ALLOTMENT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CDS_OPTION_WRONG_ALLOTMENT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
		,titres.libelle Instrument_Name
		,titres.reference Instrument_Reference
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	INNER JOIN titres cds
		ON cds.sicovam = titres.codesj
	WHERE titres.type = 'D'
		AND (
			titres.affectation != 1250
			OR titres.affectation IS NULL
			)
		AND cds.type = 'S'
		AND (
			(
				cds.jambe1 = 1
				AND cds.jambe2 = 8
				)
			OR (
				cds.jambe1 = 8
				AND cds.jambe2 = 1
				)
			);
		-- *****************************************************************
		-- END OF: CDS_OPTION_WRONG_ALLOTMENT
		-- *****************************************************************  
END

CDS_OPTION_WRONG_ALLOTMENT;

-- *****************************************************************
-- Description:     PROCEDURE  VARSWAP_OPTION_WRONG_ALLOTMENT
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************   
PROCEDURE VARSWAP_OPTION_WRONG_ALLOTMENT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: VARSWAP_OPTION_WRONG_ALLOTMENT
	-- *****************************************************************    
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
		,titres.libelle Instrument_Name
		,titres.reference Instrument_Reference
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	INNER JOIN titres VarSwap
		ON VarSwap.sicovam = titres.codesj
	WHERE (
			titres.affectation != 1301
			OR titres.affectation IS NULL
			)
		AND VarSwap.affectation = 16;
		-- *****************************************************************
		-- END OF: VARSWAP_OPTION_WRONG_ALLOTMENT
		-- *****************************************************************   
END

VARSWAP_OPTION_WRONG_ALLOTMENT;

-- *****************************************************************
-- Description:     PROCEDURE  CDS_OPTION_MISSING_DATA
-- Author:          Jun Guan
-- 
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- *****************************************************************   
PROCEDURE CDS_OPTION_MISSING_WRONG_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CDS_OPTION_MISSING_DATA
	-- *****************************************************************   		
	OPEN p_CURSOR
	FOR

	
SELECT DISTINCT cdso.sicovam CDS_Option_sicovam
	,cdso.reference CDS_Option_Reference
	,cdso.libelle CDS_Option_Name
	,cdso.finper Expiry_Date
	,cdso.modele Calculation_Data_Model -- For CDS Option the modle MUST be CDX Option
	,marche.libelle Market_Name -- Market must be set for CDS Option
	,cds.reference CDS_REFERENCE
	,cds.libelle CDS_Name
	,decode(cdsunderlying.type, 'H', 'Issuer', 'I', 'Index', cdsunderlying.type) Index_TYPE -- For Index CDS the undelrying must be an Index
  ,cdsunderlying.modele Index_Model
  ,decode(cdsunderlying.credit_method,1,'Components',2,'Index',3,'Index + Components',4 ,'Components + Index',5,'Components Spread',6,'Very Synthetic') Index_Credit_Risk_Method
	,devise_to_str(cdsunderlying.devisectt) Index_Currency
  ,devise_to_str(volatilityref.devisectt) Index_CDS_Volatility_Currency -- The Currency in the CDS Volatilit MUST be same as the currency of the Index
	,volatilityref.reference Index_CDS_Volatility -- The name of the CDS Volatility must be the right one for the corresponding CCY of the Index. E,g if the Index has ccy EUR then the CDS Volatilit must be INDEX CDS VOL EUR
	,composition.reference Index_Composition -- The composition of the Indec MUSTN'T be blank and should always choose the DUMMY ISSUER FOR ITRAXX
	,BTG_FN_AUDIT_INST_USER(cdso.sicovam) Instr_last_amended_by
FROM titres cdso
INNER JOIN titres cds
	ON cds.sicovam = cdso.codesj
INNER JOIN titres cdsunderlying
	ON cdsunderlying.sicovam = cds.j1refcon2
LEFT JOIN ISSUER_VOLATILITY_REF
	ON ISSUER_VOLATILITY_REF.sico = cdsunderlying.sicovam
LEFT JOIN titres volatilityref
	ON volatilityref.sicovam = ISSUER_VOLATILITY_REF.issuer
INNER JOIN histomvts trades
	ON trades.sicovam = cdso.sicovam
INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY
	ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
LEFT JOIN marche
	ON marche.mnemomarche = cdso.marche
LEFT JOIN panier
	ON panier.sicovam = cdsunderlying.sicovam
LEFT JOIN titres composition
	ON composition.sicovam = panier.sicopanier
WHERE cdso.affectation = 1250
	AND cdso.finper >= sysdate
	AND ( 
        cdso.reference NOT LIKE ('*%') 
        and upper(cdso.reference) NOT LIKE ('%FAKE%') 
        and upper(cdso.reference) NOT LIKE ('%TEST%') 
        and upper(cdso.reference) NOT LIKE ('%DUMMY%') 
        and upper(cdso.reference) NOT LIKE ('%DONT USE%')
        and upper(cdso.reference) NOT LIKE ('%DO NOT USE%')
        )
	AND trades.backoffice NOT IN (
		192
		,11
		,13
		,17
		,26
		,27
		,220
		,248
		,252
		)
	AND (
		cdso.modele != 'CDX Option'
		OR marche.libelle IS NULL
		OR cdsunderlying.type != 'I'
		OR ISSUER_VOLATILITY_REF.currency != cdsunderlying.devisectt
		OR ISSUER_VOLATILITY_REF.sico IS NULL
    OR cdsunderlying.modele !='Credit Risk'
    OR cdsunderlying.credit_method !=2
    OR composition.reference is null
		);

		-- *****************************************************************
		-- END OF: CDS_OPTION_MISSING_DATA
		-- *****************************************************************   
END

CDS_OPTION_MISSING_WRONG_DATA;

-- Description:     PROCEDURE  BOND_MISS_ISSUER
-- /*Bonds missing an issuer*/
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 31 JAN 2017     Jeff Yu         Modified per PMGMPMO-211 request-Add ARF for re-launch.
-- 31 MAR 2017   Jeff Yu         APPSUPP-1891
-- 31 OCT 2017    Jeff Yu         PMOG-1119
-- *****************************************************************    
PROCEDURE BOND_MISS_ISSUER(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BOND_MISS_ISSUER
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

		SELECT DISTINCT (t.sicovam) Sicovam
	,t.libelle Bond_Name
	,t.reference Bond_Reference
	,BTG_FN_AUDIT_INST_USER(t.sicovam) Instr_last_amended_by
FROM histomvts
INNER JOIN titres t 
ON t.sicovam = histomvts.sicovam
	AND t.reference NOT LIKE 'US912%' --not UST
	AND t.type = 'O' --bond
    AND T.AFFECTATION NOT IN (1400,1801,1180) --Exclude Bank Loan and Cash Loan and Bond Dummy
    AND t.reference not like '*%'  --Exclude old/incorrect setup instruments
	AND t.code_emet = 0 --missing issuer      
    AND t.FINPER >= TRUNC(SYSDATE)  --Exclude matured instruments
WHERE histomvts.backoffice NOT IN ( 
		SELECT KERNEL_STATUS_ID
		FROM BO_KERNEL_STATUS_COMPONENT
		WHERE KERNEL_STATUS_GROUP_ID = 68415
		) --canceled trades trades
ORDER BY 1 DESC;

	/*Bonds missing an issuer*/
	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: BOND_MISS_ISSUER
		-- *****************************************************************        
END

BOND_MISS_ISSUER;

-- *****************************************************************
-- Description  PROCEDURE RED_OVER_300
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 22 Feb 2013   Oliver South     Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- *****************************************************************
PROCEDURE RED_OVER_300(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- ***************************************************************************
	-- BEGIN OF RED_OVER_300 
	-- ***************************************************************************		
	OPEN p_CURSOR
	FOR

SELECT count_table.RED
FROM (
    SELECT COUNT(DISTINCT(value)) AS "RED"
		FROM extrnl_references_instruments
		WHERE ref_ident = 16
		) count_table
WHERE count_table.RED >= 300
;

		-- ***************************************************************************
		-- END OF RED_OVER_300 
		-- ***************************************************************************	
END

RED_OVER_300;

PROCEDURE DF_NDF_LAST_PRICE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- ***************************************************************************
	-- BEGIN OF DF_NDF_LAST_PRICE 
	-- ***************************************************************************		
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
		,titres.libelle FX_Name
		,historique.jour d$Rate_Date
		,historique.d Rate
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	INNER JOIN historique
		ON historique.sicovam = titres.sicovam
	WHERE historique.d IS NOT NULL
		AND titres.type IN (
			'X'
			,'K'
			)
		AND titres.echeance >= trunc(sysdate)
	ORDER BY 3 DESC;
		-- ***************************************************************************
		-- END OF DF_NDF_LAST_PRICE 
		-- ***************************************************************************	
END

DF_NDF_LAST_PRICE;


-- *****************************************************************
-- Description:     PROCEDURE  SOPHIS_USER_MISSING_DATA
-- Check to see if any Sophis user is missing static data                
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 17 JUN 2013      Jun Guan       Created.
-- 18 MAY 2018		Gustavo Binnie APPSUPP-4647 (Exclude Manager user)
-- ***************************************************************** 
PROCEDURE SOPHIS_USER_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: SOPHIS_USER_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT groupname.NAME UserGroup
		,riskusers.ident Sophis_ID
		,riskusers.NAME Sophis_Username
		,userinfos.country Country
	FROM riskusers
	LEFT JOIN userinfos
		ON userinfos.ident = riskusers.ident
	LEFT JOIN riskusers groupname
		ON groupname.ident = riskusers.gident
	WHERE userinfos.country IS NULL
		AND riskusers.gident NOT IN (
			2349
			,3267
			,NULL
			)
		AND riskusers.type = 'U';

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: SOPHIS_USER_MISSING_DATA
		-- *****************************************************************   
END

SOPHIS_USER_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  SOPHIS_USER_MISSING_DATA
-- Check to see if any Sophis user is missing static data                
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 17 JUN 2013      Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE ALLOTMENT_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: ALLOTMENT_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT affectation.ident Allotment_ID
		,affectation.libelle Allotment
		,UnaVista_Code.output_code UnaVista_Code
		,Aexeo_Suffix.output_code Aexeo_Suffix
	FROM affectation
	LEFT JOIN btg_mapping_code UnaVista_Code
		ON UnaVista_Code.input_code = affectation.ident
			AND UnaVista_Code.source_id = 6
			AND UnaVista_Code.type_id = 24
	LEFT JOIN btg_mapping_code Aexeo_Suffix
		ON substr(Aexeo_Suffix.input_code, 1, instr(Aexeo_Suffix.input_code, '_') - 1) = to_char(affectation.ident)
			AND Aexeo_Suffix.source_id = 2
			AND Aexeo_Suffix.type_id = 28
	WHERE UnaVista_Code.output_code IS NULL
		OR Aexeo_Suffix.output_code IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: ALLOTMENT_MISSING_DATA
		-- *****************************************************************   
END

ALLOTMENT_MISSING_DATA;

-- *****************************************************************
-- Description:     PROCEDURE  MISS_MAP_CL_BIC_UCITS
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 JUL 2013      Gustavo Binnie      Created.
-- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
--										-Changed the procedure's name
-- ***************************************************************** 
PROCEDURE MISS_MAP_CL_BIC_UCITS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MISS_MAP_CL_BIC_UCITS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT Ident
		,NAME
		,LISTAGG(FUND, ', ') within
	GROUP (
			ORDER BY FUND
			) AS Funds
		,BTG_FN_AUDIT_THIRD_USER(ident) Third_party_last_amended_by
	FROM (
		SELECT TIERSUCITS.IDENT Ident
			,TIERSUCITS.NAME NAME
			,T2.NAME FUND
		FROM (
			SELECT DISTINCT (TIERS.IDENT) || '%' AS INPUT
				,TIERS.IDENT AS IDENT
				,NAME AS NAME
				,FT.entity AS ENTITY
			FROM TIERS
			INNER JOIN fraistiers FT
				ON TIERS.IDENT = FT.ident
					AND FT.entity IN (
						10010602
						,10016615
						,10018467
						) -- embl, blackstone, russell
					AND FT.options IN (
						1
						,2
						) -- COUNTERPARTY,BROKER
			) TIERSUCITS
		INNER JOIN TIERS T2
			ON T2.IDENT = TIERSUCITS.ENTITY
		LEFT JOIN BTG_MAPPING_CODE
			ON input_code LIKE TIERSUCITS.INPUT
				AND BTG_MAPPING_CODE.source_id = 1 -- Settlement Instruction
				AND BTG_MAPPING_CODE.type_id = 1 -- Clearer BIC Code      
		WHERE OUTPUT_CODE IS NULL
		)
	GROUP BY Ident
		,NAME
		,BTG_FN_AUDIT_THIRD_USER(ident);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISS_MAP_CL_BIC_UCITS
		-- *****************************************************************   
END

MISS_MAP_CL_BIC_UCITS;

-- *****************************************************************
-- Description:     PROCEDURE  MISS_MAP_EUCL_BIC_UCITS
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 JUL 2013      Gustavo Binnie      Created.
-- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
--										-Changed the procedure's name
-- ***************************************************************** 
PROCEDURE MISS_MAP_EUCL_BIC_UCITS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MISS_MAP_EUCL_BIC_UCITS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT Ident
		,NAME
		,LISTAGG(FUND, ', ') within
	GROUP (
			ORDER BY FUND
			) AS Funds
		,BTG_FN_AUDIT_THIRD_USER(ident) Third_party_last_amended_by
	FROM (
		SELECT TIERSUCITS.IDENT Ident
			,TIERSUCITS.NAME NAME
			,T2.NAME FUND
		FROM (
			SELECT DISTINCT (TIERS.IDENT) || '%' AS INPUT
				,TIERS.IDENT AS IDENT
				,NAME AS NAME
				,FT.entity AS ENTITY
			FROM TIERS
			INNER JOIN fraistiers FT
				ON TIERS.IDENT = FT.ident
					AND FT.entity IN (
						10010602
						,10016615
						,10018467
						) -- embl, blackstone, russell
					AND FT.options IN (
						1
						,2
						) -- COUNTERPARTY,BROKER
			) TIERSUCITS
		INNER JOIN TIERS T2
			ON T2.IDENT = TIERSUCITS.ENTITY
		LEFT JOIN BTG_MAPPING_CODE
			ON input_code LIKE TIERSUCITS.INPUT
				AND BTG_MAPPING_CODE.source_id = 1 -- Settlement Instruction
				AND BTG_MAPPING_CODE.type_id = 2 -- EuroClearer BIC Code     
		WHERE OUTPUT_CODE IS NULL
		)
	GROUP BY Ident
		,NAME
		,BTG_FN_AUDIT_THIRD_USER(ident);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISS_MAP_EUCL_BIC_UCITS
		-- *****************************************************************   
END

MISS_MAP_EUCL_BIC_UCITS;

-- *****************************************************************
-- Description:     PROCEDURE  MISS_MAP_CL_SAFEACC_UCITS
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 JUL 2013      Gustavo Binnie      Created.
-- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
--										-Changed the procedure's name
-- ***************************************************************** 
PROCEDURE MISS_MAP_CL_SAFEACC_UCITS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MISS_MAP_CL_SAFEACC_UCITS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT Ident
		,NAME
		,LISTAGG(FUND, ', ') within
	GROUP (
			ORDER BY FUND
			) AS Funds
		,BTG_FN_AUDIT_THIRD_USER(ident) Third_party_last_amended_by
	FROM (
		SELECT TIERSUCITS.IDENT Ident
			,TIERSUCITS.NAME NAME
			,T2.NAME FUND
		FROM (
			SELECT DISTINCT (TIERS.IDENT) || '%' AS INPUT
				,TIERS.IDENT AS IDENT
				,NAME AS NAME
				,FT.entity AS ENTITY
			FROM TIERS
			INNER JOIN fraistiers FT
				ON TIERS.IDENT = FT.ident
					AND FT.entity IN (
						10010602
						,10016615
						,10018467
						) -- embl, blackstone, russell
					AND FT.options IN (
						1
						,2
						) -- COUNTERPARTY,BROKER
			) TIERSUCITS
		INNER JOIN TIERS T2
			ON T2.IDENT = TIERSUCITS.ENTITY
		LEFT JOIN BTG_MAPPING_CODE
			ON input_code LIKE TIERSUCITS.INPUT
				AND BTG_MAPPING_CODE.source_id = 1 -- Settlement Instruction
				AND BTG_MAPPING_CODE.type_id = 3 -- Clearer Safe Account Code      
		WHERE OUTPUT_CODE IS NULL
		)
	GROUP BY Ident
		,NAME
		,BTG_FN_AUDIT_THIRD_USER(ident);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISS_MAP_CL_SAFEACC_UCITS
		-- *****************************************************************   
END

MISS_MAP_CL_SAFEACC_UCITS;

-- *****************************************************************
-- Description:     PROCEDURE  MISSING_BUS_CENTER_MAP
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 JUL 2013      Gustavo Binnie      Created.
-- ***************************************************************** 
PROCEDURE MISSING_BUS_CENTER_MAP(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: MISSING_BUS_CENTER_MAP
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT devise_to_str(CODE) CCY
		,libelle CURRENCY_NAME
	FROM DEVISEV2
	WHERE devise_to_str(CODE) NOT IN (
			SELECT INPUT_CODE
			FROM BTG_MAPPING_CODE
			WHERE SOURCE_ID = 7
				AND TYPE_ID = 29
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: MISSING_BUS_CENTER_MAP
		-- *****************************************************************   
END

MISSING_BUS_CENTER_MAP;

-- *****************************************************************
-- Description:     PROCEDURE  BD_CPTY_MISSING_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013      Jun Guan            Created.
-- 19 APR 2016      Gustavo Binnie		PMOG-947  - Rename Unavista FRN CODE to FRN CODE
-- ***************************************************************** 
PROCEDURE BD_CPTY_MISSING_DATA(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: BD_CPTY_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT tiers.ident CounterpartyID
		,tiers.NAME CounterpartyName
		,tiers.reference CounterpartyReference
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM tiers
	LEFT JOIN tiersproperties
		ON tiersproperties.code = tiers.ident
			AND tiersproperties.NAME = 'FRN CODE'
	WHERE tiersproperties.value IS NULL
		AND tiers.mgr = 10018174;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: BD_CPTY_MISSING_DATA
		-- *****************************************************************   
END

BD_CPTY_MISSING_DATA;


PROCEDURE CP_FEES_ON_BOND(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: CP_FEES_ON_BOND
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT 
        FRAISTIERS.formula                   Fees
      , TIERS.NAME                           Counterparty
      , BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM FRAISTIERS
	INNER JOIN TIERS
	ON TIERS.ident = FRAISTIERS.ident
	AND TIERS.mgr = 10007662
	WHERE FRAISTIERS.allotment IN (
                                  - 1
                                  ,25
                                  ,26
                                  ,34
                                  ,35
                                  ,1102
                                  ,1180
                                  ,1200
                                  ,1251
                                  ,1252
                                  ,1253
                                  ,1353
                                  ,1400
                                  ,1450
                                  ) --Gov, Corp, TBA, MBS-Agency, TRS FF, Bond - Dummy, Bond - Time Deposit, Agency Bond, MBS - Non Agency, CMBS, MBS - European, Bank Loan, ABS - Student Loan
		AND FRAISTIERS.formula NOT IN (
                                  '0'
                                  ,'.00'
                                  ,'0 '
                                  ,'0.00'
                                  ,'0.0'
                                  ,'*'
                                  )
    AND FRAISTIERS.business_event IN (
                                      -1
                                      ,1
                                      ) -- * and Purchase/Sale
	ORDER BY 2;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: CP_FEES_ON_BOND
		-- *****************************************************************   
END

CP_FEES_ON_BOND;

-- *****************************************************************
-- Description:     PROCEDURE  DEPO_INST_ACCT_ALLOTMENT
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 20 SEP 2013      Jun Guan            Created.
-- 29 OCT 2014      Davi Xavier         Change the depositary filter
-- 06 APR 2017      Jeff Yu                AP-783
-- ***************************************************************** 
PROCEDURE DEPO_INST_ACCT_ALLOTMENT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: DEPO_INST_ACCT_ALLOTMENT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT tiers.ident DepositaryID
		,tiers.NAME Depositaryname
		,tiers.reference DepositaryReference
		,groupname.reference GroupName
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM tiers
	LEFT JOIN am_instrument_account_filter
		ON tiers.ident = am_instrument_account_filter.pb
			AND am_instrument_account_filter.allot = 0
	LEFT JOIN tiers groupname
		ON groupname.ident = tiers.mgr
	WHERE ESTDEPOSITAIRE(tiers.options) = 1
		AND (am_instrument_account_filter.accountid IS NULL or am_instrument_account_filter.accountid = 0)  --Pick up instrument account without filter setup or filter missing account name
		AND tiers.mgr NOT IN (
			10016965
			,10018175
			,10008862
			,10010628
			,10008942
			,10010087
			);-- exclude Welth Management, Broker dealer, PBL DEPOSITARIES, XXX DEPOSITARIES, EXECUTION DEPOSITARIES  ,PBL - European Eq DEP  

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: DEPO_INST_ACCT_ALLOTMENT
		-- *****************************************************************   
END

DEPO_INST_ACCT_ALLOTMENT;

-- *****************************************************************
-- Description:     PROCEDURE  RESTRICT_CHAR_TIERS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 SEP 2013   Oliver South            Created.
-- ***************************************************************** 
PROCEDURE RESTRICT_CHAR_TIERS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: RESTRICT_CHAR_TIERS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT BTG_FN_AUDIT_THIRD_USER(IDENT) BTG_Culprit
		,NAME Third_Party_Name
		,REFERENCE Third_Party_Reference
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM TIERS
	WHERE (
			REFERENCE LIKE '%"%'
			OR REFERENCE LIKE '%,%'
			OR NAME LIKE '%"%'
			OR NAME LIKE '%,%'
			OR NAME LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR NAME LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			OR NAME LIKE '%�%'
			OR REFERENCE LIKE '%�%'
			);

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: RESTRICT_CHAR_TIERS
		-- *****************************************************************   
END

RESTRICT_CHAR_TIERS;

PROCEDURE ISSUER_CREDIT_CURVE(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: ISSUER_CREDIT_CURVE
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT TITRES.sicovam Issuer_Sicovam
		,TITRES.reference Issuer_Reference
		,TITRES.libelle Issuer_Name
		,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM CREDIT_MODEL
	INNER JOIN TITRES
		ON TITRES.sicovam = CREDIT_MODEL.code
	WHERE CREDIT_MODEL.model_name != 'BootStrap'
	ORDER BY 2;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: ISSUER_CREDIT_CURVE
		-- *****************************************************************   
END

ISSUER_CREDIT_CURVE;

PROCEDURE FOLIO_STRATEGY_MATCH(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: FOLIO_STRATEGY_MATCH
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT Folios.Ident
		,Folios.NAME
		,Folios.Path
	FROM (
		SELECT Folio.Ident
			,Folio.NAME
			,SYS_CONNECT_BY_PATH(FOLIO.NAME, '\') AS Path
			,Folio.Mgr
		FROM Folio START WITH Folio.Ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) CONNECT BY PRIOR Folio.Ident = Folio.Mgr
		) Folios
	INNER JOIN Folio_Strategies
		ON Folio_Strategies.NAME = Folios.NAME
	INNER JOIN Folio ParentFolio
		ON ParentFolio.Ident = Folios.Mgr
	WHERE ParentFolio.NAME != 'Strategies'
	    AND ParentFolio.NAME != 'X-Closed Strats'
		AND Folio_Strategies.NAME NOT IN (
			'Fees'
			,'Cash &' || ' S/R'
			)
	ORDER BY 3;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: FOLIO_STRATEGY_MATCH
		-- *****************************************************************   
END

FOLIO_STRATEGY_MATCH;

PROCEDURE EXT_REF_BLANKS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EXT_REF_BLANKS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
              EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident    Sicovam
            , TITRES.reference                              Instrument_Reference
            , TITRES.libelle                                Instrument_Name
            , EXTRNL_REFERENCES_DEFINITION.ref_name         External_Reference
            , EXTRNL_REFERENCES_INSTRUMENTS.value           Value
            , AFFECTATION.libelle                           Allotment
            , BTG_FN_AUDIT_INST_USER(TITRES.sicovam)        Last_amended_by
FROM        EXTRNL_REFERENCES_INSTRUMENTS
INNER JOIN  EXTRNL_REFERENCES_DEFINITION
ON          EXTRNL_REFERENCES_DEFINITION.ref_ident = EXTRNL_REFERENCES_INSTRUMENTS.ref_ident
INNER JOIN  TITRES
ON          TITRES.sicovam = EXTRNL_REFERENCES_INSTRUMENTS.sophis_ident
LEFT JOIN   AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation
WHERE       EXTRNL_REFERENCES_INSTRUMENTS.value like '%'||chr(9)||'%' --checks for a tab character in any external reference
OR          (
                (
                EXTRNL_REFERENCES_INSTRUMENTS.value LIKE ' %'
                OR 
                EXTRNL_REFERENCES_INSTRUMENTS.value LIKE '% '
                ) 
            AND 
            EXTRNL_REFERENCES_INSTRUMENTS.ref_ident IN (1,2,3) --checks leading or trailing blanks in ISIN, CUSIP, SEDOL
            )
ORDER BY 1
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: EXT_REF_BLANKS
		-- *****************************************************************   
END

EXT_REF_BLANKS;

 -- *****************************************************************
-- Description:     PROCEDURE  MBS_BOND_EXCEPTION_REPORT
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 02 FEB 2014      Gustavo Binnie      Created.
-- ***************************************************************** 

PROCEDURE MBS_BOND_EXCEPTION_REPORT(p_CURSOR OUT T_CURSOR) AS

BEGIN
-- *****************************************************************
-- BEGIN OF: MBS_BOND_EXCEPTION_REPORT
-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT titres.sicovam Sicovam
        ,titres.reference Instrument_Reference
        ,titres.libelle Instrument_Name
        ,affectation.libelle Allotment
        ,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
        case when cusip.value IS NULL then 'CUSIP' ELSE NULL END || ',' || --Missing CUSIP                
        case when id_bb_company.value is null then 'ID_BB_COMPANY' ELSE NULL END || ',' ||
        case when ID_BB_UNIQUE.value is null then 'ID_BB_UNIQUE' ELSE NULL END           
          ) 
          ,',+(,|$)','\1'),
          '^,'     )
         "MISSING_DATA"
        
        ,BTG_FN_AUDIT_INST_USER(titres.sicovam) Instr_last_amended_by
	FROM titres
	LEFT JOIN extrnl_references_instruments cusip
		ON titres.sicovam = cusip.sophis_ident
			AND cusip.ref_ident = 3

	LEFT JOIN affectation
		ON affectation.ident = titres.affectation
  LEFT JOIN extrnl_references_instruments ID_BB_COMPANY
    on titres.sicovam = ID_BB_COMPANY.sophis_ident
      and ID_BB_COMPANY.ref_ident = 673      
  LEFT JOIN extrnl_references_instruments ID_BB_UNIQUE
    on titres.sicovam = ID_BB_UNIQUE.sophis_ident
      and ID_BB_UNIQUE.ref_ident = 674 
    
	WHERE 
  titres.type = 'O'
  AND
			titres.affectation  IN (
				'35',
'38',
'1252',
'1253',
'1353',
'1450')			
		AND (
			cusip.value IS NULL --Missing CUSIP			
      OR id_bb_company.value is null -- Missing ID_BB_COMPANY
      OR ID_BB_UNIQUE.value is null -- Missing ID_BB_UNIQUE
			) 
	ORDER BY 4
		,3;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END

MBS_BOND_EXCEPTION_REPORT;
-- *****************************************************************
-- END OF: MBS_BOND_EXCEPTION_REPORT
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  ALLOT_MISSING_SEC_TYPE_AEXEO
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 11 Aug 2014      Gustavo Binnie      Created.
-- ***************************************************************** 
PROCEDURE ALLOT_MISSING_SEC_TYPE_AEXEO (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: ALLOT_MISSING_SEC_TYPE_AEXEO
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

    SELECT DISTINCT AFFECTATION.IDENT		Allotment_ID
				  , AFFECTATION.LIBELLE		Allotment
                    
    FROM  AMRECON_EXTSYS_ACCOUNTS AES
                    
    LEFT JOIN BTG_MAPPING_CODE
    ON AES.allotment = BTG_MAPPING_CODE.INPUT_CODE
    AND BTG_MAPPING_CODE.SOURCE_ID=2 
    AND BTG_MAPPING_CODE.TYPE_ID=27
                                        
    LEFT JOIN AFFECTATION
    ON AES.allotment=AFFECTATION.IDENT                                        
                    
    WHERE 
		AES.esid IN (2631,2632)
    AND AES.include=1
    AND BTG_MAPPING_CODE.OUTPUT_CODE IS NULL;
		
END

ALLOT_MISSING_SEC_TYPE_AEXEO;

-- *****************************************************************
-- END OF: ALLOT_MISSING_SEC_TYPE_AEXEO
-- *****************************************************************      



  -- *****************************************************************
  -- Description: PROCEDURE BROKER_DEALER_WRONG_BROKER
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 2013-07-19       Jun Guan      Created.  
  
  PROCEDURE BROKER_DEALER_WRONG_BROKER
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF BROKER_DEALER_WRONG_BROKER
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

      SELECT refcon Trade_ID
            ,titres.sicovam Sicovam
            ,titres.reference InstrumentReference
            ,titres.libelle InstrumentName
            ,BrokerName.NAME Broker
            ,CounterpartyName.NAME Counterparty
  
      FROM histomvts

      INNER JOIN (
                  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS FUND_ID
                        ,CONNECT_BY_ROOT(FOLIO.NAME) AS FUND_NAME
                        ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
                        ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                        ,FOLIO.ident AS STRATEGY_ID
                        ,FOLIO.NAME AS STRATEGY_NAME
                  FROM FOLIO
                  WHERE LEVEL > 2 START
                  WITH FOLIO.ident IN (89631) -- -Broker Dealer funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FUND_BOOK_STRATEGY 
      ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM

      LEFT JOIN fraistiers 
      ON fraistiers.ident = histomvts.courtier
      AND fraistiers.entity = 10018177
      AND fraistiers.options = 2

      LEFT JOIN fraistiers fraistiers2 
      ON fraistiers2.ident = histomvts.contrepartie
      AND fraistiers2.entity = 10018177
      AND fraistiers2.options = 1
  
      LEFT JOIN tiers Broker 
      ON Broker.ident = fraistiers.ident

      LEFT JOIN tiers CP 
      ON CP.ident = fraistiers2.ident

      INNER JOIN Titres 
      ON Titres.sicovam = Histomvts.sicovam

      LEFT JOIN tiers BrokerName 
      ON BrokerName.ident = Histomvts.courtier

      LEFT JOIN tiers CounterpartyName 
      ON CounterpartyName.ident = Histomvts.contrepartie

      WHERE histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
      AND (
            broker.NAME IS NULL OR CP.NAME IS NULL
          );

 
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF BROKER_DEALER_WRONG_BROKER 
  -- ***************************************************************************         
	END BROKER_DEALER_WRONG_BROKER;


-- *****************************************************************
-- Description:     PROCEDURE  INDEX_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30 Jan 2015      Jun Guan            Created.
-- 02 NOV 2017   Jeff Yu           PMOG-1138  Exclude instrument reference starts with *
-- 08 NOV 2017    Jeff Yu     PMOG-1168  Exclude ticker whose reference includes word "Fake","Dummy","Test" or "Do not use"
-- ***************************************************************** 
PROCEDURE INDEX_CDS_MISSING_WRONG_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: INDEX_CDS_MISSING_WRONG_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

 
SELECT DISTINCT cds.reference CDS_REFERENCE
	,cds.libelle CDS_Name
	,decode(cdsunderlying.type, 'H', 'Issuer', 'I', 'Index', cdsunderlying.type) Index_TYPE -- For Index CDS the undelrying must be an Index
  ,extrnl_references_instruments.VALUE Generic_Ticker
   ,red.VALUE RED_ID_ON_INDEX
	,cdsunderlying.modele Index_Model
	,decode(cdsunderlying.credit_method, 1, 'Components', 2, 'Index', 3, 'Index + Components', 4, 'Components + Index', 5, 'Components Spread', 6, 'Very Synthetic') Index_Credit_Risk_Method
	,devise_to_str(cdsunderlying.devisectt) Index_Currency
	,devise_to_str(volatilityref.devisectt) Index_CDS_Volatility_Currency -- The Currency in the CDS Volatilit MUST be same as the currency of the Index
	,volatilityref.reference Index_CDS_Volatility -- The name of the CDS Volatility must be the right one for the corresponding CCY of the Index. E,g if the Index has ccy EUR then the CDS Volatilit must be INDEX CDS VOL EUR
	,composition.reference Index_Composition -- The composition of the Indec MUSTN'T be blank and should always choose the DUMMY ISSUER FOR ITRAXX
	,BTG_FN_AUDIT_INST_USER(cds.sicovam) Instr_last_amended_by
FROM titres cds
INNER JOIN titres cdsunderlying
	ON cdsunderlying.sicovam = cds.j1refcon2
LEFT JOIN ISSUER_VOLATILITY_REF
	ON ISSUER_VOLATILITY_REF.sico = cdsunderlying.sicovam
LEFT JOIN titres volatilityref
	ON volatilityref.sicovam = ISSUER_VOLATILITY_REF.issuer
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	WHERE cds.affectation = 22
		AND upper(cds.reference) LIKE '%INDEX%'
		AND ( 
        cds.reference NOT LIKE ('*%') 
        and upper(cds.reference) NOT LIKE ('%FAKE%') 
        and upper(cds.reference) NOT LIKE ('%TEST%') 
        and upper(cds.reference) NOT LIKE ('%DUMMY%') 
        and upper(cds.reference) NOT LIKE ('%DONT USE%')
        and upper(cds.reference) NOT LIKE ('%DO NOT USE%')
        )
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN panier
	ON panier.sicovam = cdsunderlying.sicovam
LEFT JOIN titres composition
	ON composition.sicovam = panier.sicopanier
  
LEFT JOIN extrnl_references_instruments
ON extrnl_references_instruments.SOPHIS_IDENT=cds.SICOVAM
AND extrnl_references_instruments.ref_ident=688 -- Generic ticker

LEFT JOIN extrnl_references_instruments red
ON red.SOPHIS_IDENT=cdsunderlying.SICOVAM
AND red.ref_ident=16 -- RED ID

WHERE (
		cdsunderlying.type != 'I'
		OR ISSUER_VOLATILITY_REF.currency != cdsunderlying.devisectt
		OR ISSUER_VOLATILITY_REF.sico IS NULL
		OR cdsunderlying.modele != 'Credit Risk'
		OR cdsunderlying.credit_method != 2
		OR composition.reference IS NULL
    OR extrnl_references_instruments.VALUE is null
    OR red.VALUE is null
		);
		
		
		
END

INDEX_CDS_MISSING_WRONG_DATA;

-- *****************************************************************
-- END OF: INDEX_CDS_MISSING_WRONG_DATA
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  SINGLE_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 Feb 2015      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE SINGLE_CDS_MISSING_WRONG_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: SINGLE_CDS_MISSING_WRONG_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

  
  SELECT DISTINCT cds.sicovam
	,undelrying.reference Underlyiner_Reference
	,decode(undelrying.type, 'H', 'Issuer', 'O', 'Bond', 'D', 'Convertible Bond', undelrying.type) Undelrying_Type
	,cds.reference cds_ref
	,cds.libelle cds_name
	,cds.emission cds_start_date
	,defaultevent.NAME CDS_Restructuring_Type
  ,cds.modele CDS_Model
  ,seniority.name CDS_Seniority
	,cds.recoveryjambe1 CDS_Recovery_Rate
	,CREDITRISK_RECORATE.rate * 100 Issuer_Recovery_Rate
  ,bondissuer.reference Bond_Issuer_ref
	,issuer.reference CDS_issuer_ref
	,issuer.libelle CDS_issuer_name
  ,CREDITRISK_credit_model.model_name Issuer_CDS_Interpolation_Model
  ,decode(CREDITRISK_credit_model.def_maturity_model, 0, 'XXX', 1, 'IMM', 2, 'Series',3, 'Sovereign', 4, 'Series+1Q',CREDITRISK_credit_model.def_maturity_model) Issuer_CDS_Maturity_Model
  ,CREDITRISK_credit_model.def_maturity_model_serie Issuer_Series_No
	,extrnl_references_instruments.value Issuer_REDID
	,BloombergName.NAME Issuer_Sector_Bloomberg
	,cntry_of_issue_code.code Issuer_Sector_CNTRY_OF_ISSUE

FROM titres cds
INNER JOIN titres undelrying
ON undelrying.sicovam = cds.j1refcon2
  
left JOIN titres bondissuer
ON bondissuer.sicovam = undelrying.code_emet
  
INNER JOIN titres issuer
	ON issuer.sicovam = cds.coupon1
LEFT JOIN extrnl_references_instruments
	ON extrnl_references_instruments.sophis_ident = issuer.sicovam
		AND extrnl_references_instruments.ref_ident = 16
LEFT JOIN extrnl_references_instruments cdsisin
	ON cdsisin.sophis_ident = cds.sicovam
		AND cdsisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments issuerisin
	ON issuerisin.sophis_ident = issuer.sicovam
		AND issuerisin.ref_ident = 1
LEFT JOIN extrnl_references_instruments cdsref
	ON cdsref.sophis_ident = cds.sicovam
		AND cdsref.ref_ident = 16
INNER JOIN (
	SELECT cds.sicovam sicovam
		,cds.reference cds_ref
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
		,sum(trades.quantite)
	FROM titres cds
	INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds and ucits
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
	INNER JOIN business_events
		ON business_events.id = trades.type
			AND business_events.compta = 1
	INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.j1refcon2
	WHERE cds.affectation = 22
		AND undelrying.type != 'I'
		AND upper(cds.reference) NOT LIKE '%ABX%'
		AND upper(cds.reference) NOT LIKE '%CMBX%'
		AND upper(cds.reference) NOT LIKE '%IOS%'
		AND upper(cds.reference) NOT LIKE '%MBX%'
		AND trades.backoffice NOT IN (
			192
			,11
			,13
			,17
			,26
			,27
			,220
			,248
			,252
			)
	GROUP BY cds.sicovam
		,cds.reference
		,cds.libelle
		,FUND_BOOK_STRATEGY.STRATEGY_ID
		,FUND_BOOK_STRATEGY.STRATEGY_NAME
		,depo.ident
		,depo.reference
	HAVING sum(trades.quantite) != 0
	) open_cds_position
	ON open_cds_position.sicovam = cds.sicovam
LEFT JOIN btg_mapping_code
	ON btg_mapping_code.input_code = cds.sicovam
		AND btg_mapping_code.source_id = 3
		AND btg_mapping_code.type_id = 69
		AND output_code = 'Y'
    
LEFT JOIN CREDITRISK_RECORATE
	ON CREDITRISK_RECORATE.code = issuer.sicovam
		AND CREDITRISK_RECORATE.default_event = cds.default_event_leg1
		AND CREDITRISK_RECORATE.seniority = cds.senjambe1
LEFT JOIN sector_instrument_association bloomberg
	ON bloomberg.sicovam = issuer.sicovam
		AND bloomberg.type = 1363
LEFT JOIN sectors BloombergName
	ON BloombergName.id = bloomberg.sector
LEFT JOIN sector_instrument_association cntry_of_issue
	ON cntry_of_issue.sicovam = issuer.sicovam
		AND cntry_of_issue.type = 5349
LEFT JOIN sectors cntry_of_issue_code
	ON cntry_of_issue_code.id = cntry_of_issue.sector
LEFT JOIN defaultevent
	ON defaultevent.id = cds.default_event_leg1
  
LEFT JOIN seniority
on seniority.id=cds.senjambe1

LEFT JOIN CREDITRISK_credit_model
ON CREDITRISK_credit_model.code = issuer.sicovam

WHERE cds.affectation = 22


	
	AND (
    (cds.recoveryjambe1 != CREDITRISK_RECORATE.rate * 100 AND cds.fixedrecoveryrate1 = 1)-- flag if recovery rate on CDS is different from the one specified on issuer
		OR CREDITRISK_RECORATE.rate IS NULL -- flag if there is no recovery rate set up on the issuer
		OR extrnl_references_instruments.value IS NULL --flag if the 6 digits red is not set up on the issuer
		OR length(extrnl_references_instruments.value) !=6 --flag if the 6 digits red is not set up on the issuer as 6 digits
		OR BloombergName.NAME IS NULL --flag if the Bloomberg sector is not set up on the issuer
		OR cntry_of_issue_code.code IS NULL -- flag if the CNTRY_OF_ISSUE sector is not set up on the issuer
		OR (
			cds.emission >= to_date('20-sep-2014', 'dd-mon-yyyy')
			AND defaultevent.NAME NOT LIKE '%14%'
			) -- flag if the start date is after 2014 but the restructuring is not using the 2014 ISDA
    OR cds.modele !='Standard' -- flag if the model is not statndard
    OR cds.senjambe1 =0 -- flag if the seniority is not set
    OR cds.default_event_leg1 =0-- flag if the default event is not set
    OR CREDITRISK_credit_model.def_maturity_model_serie !=100 -- pick up issuer if CDS maturity model is not set to Series 100
    OR CREDITRISK_credit_model.model_name !='BootStrap' -- pick up issuer if the interpolation modle is not set to BootStrap
		);
		
END

SINGLE_CDS_MISSING_WRONG_DATA;

-- *****************************************************************
-- END OF: SINGLE_CDS_MISSING_WRONG_DATA
-- *****************************************************************
    



-- *****************************************************************
-- Description:     PROCEDURE  BROKER_MIFID_NOT_SET
-- Check to see if any broker didn't have the MiFID set                  
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 20 May 2013    Jun Guan        Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- ***************************************************************** 
PROCEDURE BROKER_MIFID_NOT_SET(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BROKER_MIFID_NOT_SET
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT tiers.ident CounterpartyID
		,tiers.NAME CounterpartyName
		,tiers.reference CounterpartyReference
		,BTG_FN_AUDIT_THIRD_USER(tiers.ident) Third_party_last_amended_by
	FROM tiers
	LEFT JOIN tiersproperties
		ON tiersproperties.code = tiers.ident
			AND tiersproperties.NAME = 'MiFID (Y/N)'
	WHERE tiersproperties.value IS NULL
		AND tiers.mgr = 10007662;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		-- *****************************************************************
		-- END OF: BROKER_MIFID_NOT_SET
		-- *****************************************************************   
END

BROKER_MIFID_NOT_SET;


  -- *****************************************************************
  -- Description: PROCEDURE INCONSIS_BROKER_DEP_OTC
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 03 July 2015     Davi Xavier     Created.
  -- 17 May 2018	  Gustavo Binnie	APPSUPP-4638 - Bug fix
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE INCONSIS_BROKER_DEP_OTC(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INCONSIS_BROKER_DEP_OTC
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT  
          INCLIST.Strategy
        , INCLIST.Fund_NAME
        , INCLIST.Trader
        , INCLIST.Counterparty
        , INCLIST.PrimeBroker             Current_Depositary
        , DEPOSITARY.name                 Depositary_Suggested
        , INCLIST.TradeId 
        , INCLIST.Sicovam
        , INCLIST.iNSTRUMENT_NAME           
        , INCLIST.Instrument_Allotment
        , INCLIST.Instrument_Type
        , INCLIST.TradeDate
FROM      (    SELECT  
                          ALLINFO.TradeId
                        , ALLINFO.Sicovam
                        , ALLINFO.Instrument_name
                        , ALLINFO.Instrument_Allotment
                        , ALLINFO.Instrument_Type
                        , ALLINFO.TradeDate
                        , ALLINFO.Fund_NAME
                        , ALLINFO.Counterparty
                        , ALLINFO.PrimeBroker
                        , ALLINFO.Trader
                        , ALLINFO.Strategy
                        , ALLINFO.Key_sug                    
            FROM                (     SELECT /* Bring all the OTC trade data together with the suggested mapping code*/
                                                  TRADES_OTC.*
                                                , DEP.KEY1 
                                      FROM        (       SELECT /* select all OTC trade from the past 7 days */
                                                                  HISTOMVTS.refcon                                                                TradeId
                                                                , HISTOMVTS.sicovam                                                               Sicovam
                                                                , TITRES.libelle                                                                  Instrument_name              
                                                                , AFFECTATION.ident                                                               Allotment_id
                                                                , AFFECTATION.libelle                                                             Instrument_Allotment
                                                                , btg_get_instrument_type (HISTOMVTS.sicovam)                                     Instrument_Type
                                                                , TRUNC(HISTOMVTS.dateneg)                                                        TradeDate
                                                                , FUND_BOOK_STRATEGY.FUND_ID||'_'||CPNAME.ident||'_'||PB.ident                    MAPPING_KEY
                                                                , CASE /*identify/flag some exceptions that have to be handled in a different way*/
                                                                        WHEN AFFECTATION.ident IN (2,1060,1080,1101,16,1041,1101,1041,1301) 
                                                                        AND upper(PB.NAME) LIKE '%MS%%PB%' THEN 'MS_PB' 
                                                                        WHEN AFFECTATION.ident IN (27) 
                                                                        AND btg_get_instrument_type (HISTOMVTS.sicovam) = 'Total Return Swaps'
                                                                        AND UPPER(PB.NAME) LIKE '%LOAN%' THEN 'LOAN' 
                                                                        ELSE ''                                                                                                                                                                                                                                                                                                                                                                                                                                             
                                                                END                                                                               PB_EXCEPTIONS
                                                                , FUND_BOOK_STRATEGY.FUND_ID                                                      FUND_ID
                                                                , FUND_BOOK_STRATEGY.Fund_NAME                                                    Fund_NAME
                                                                , CPNAME.ident                                                                    Counterparty_ID
                                                                , PB.ident                                                                        PrimeBroker_ID                   
                                                                , CPNAME.NAME                                                                     Counterparty
                                                                , PB.NAME                                                                         PrimeBroker
                                                                , RISKUSERS.name                                                                  Trader
                                                                , FUND_BOOK_STRATEGY.BOOK_NAME                                                    Strategy
                                                                , FUND_BOOK_STRATEGY.FUND_ID||'_'||CPNAME.ident                                   KEY_Sug
                                                FROM            HISTOMVTS
                                                INNER JOIN      TITRES
                                                ON              TITRES.sicovam = HISTOMVTS.sicovam 
                                                INNER JOIN (  SELECT 
                                                                    CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                                                  , CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                                                  , FOLIO.ident AS STRATEGY_ID
                                                                  , FOLIO.NAME AS STRATEGY_NAME
                                                                  , LEVEL
                                                              FROM FOLIO
                                                              WHERE LEVEL >= 4 START
                                                              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)--(14414,90565) --
                                                              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                                      ) FUND_BOOK_STRATEGY 
                                                ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM     
                                                INNER JOIN      TIERS PB     
                                                ON              PB.IDENT = HISTOMVTS.DEPOSITAIRE
                                                INNER JOIN      RISKUSERS
                                                ON              RISKUSERS.ident = HISTOMVTS.operateur
                                                INNER JOIN AFFECTATION
                                                ON AFFECTATION.ident = TITRES.affectation
                                                AND   AFFECTATION.ident IN (36,22,1250,44,1101,13,27,33,48,50,24,1550,2,3,31,1102,16,1080,1081,1000,1301) -- Caps and Floors,CDS,CDS Options,Commodity Swaps,Correlation Swap,Debt Instruments,Equity Swap,FRA,Inflation Caps and Floors,Inflation Swaps,IRS,OTC Commodity Derivatives,OTC Stock Derivatives,Swaps,Swaptions,TRS(Fully Funded),Variance SWAP,Volatility Swap,Ascot,xccy swap (no USD),Variance Options
                                                LEFT JOIN TIERS CPNAME 
                                                ON CPNAME.ident = HISTOMVTS.contrepartie
                                                INNER JOIN TIERSPROPERTIES
                                                ON HISTOMVTS.depositaire = TIERSPROPERTIES.code
                                                AND TIERSPROPERTIES.NAME = 'MarkIT CH CODE' 
                                                AND TIERSPROPERTIES.value IS NULL --no value in MarkIT CH CODE indicates that this is a non-cleared trade and therefore should be checked
                                                WHERE HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                                                AND   HISTOMVTS.dateneg > trunc(SYSDATE)-7 --Trades done in the past 7 dayes
                                                ) TRADES_OTC
                                    LEFT JOIN ( SELECT /* concatenate all the depositaries to counterparties*/
                                                      OTCDEP.input_code||'_'||OTCDEP.output_code KEY1 
                                                FROM  BTG_MAPPING_CODE OTCDEP
                                                WHERE OTCDEP.source_id = 9 AND OTCDEP.type_id = 72
                                              ) DEP
                                    ON TRADES_OTC.MAPPING_KEY = DEP.KEY1)   ALLINFO
                    WHERE ALLINFO.KEY1 IS NULL
                    AND   ALLINFO.PB_EXCEPTIONS IS NULL
                    AND   ALLINFO.counterparty NOT like '%INTERNAL%')INCLIST
INNER JOIN BTG_MAPPING_CODE PB_SUGGEST
ON Inclist.Key_sug = PB_SUGGEST.input_code
and PB_SUGGEST.source_id = 9 AND PB_SUGGEST.type_id = 72
INNER JOIN  TIERS DEPOSITARY
ON DEPOSITARY.ident = PB_SUGGEST.output_code;

END

-- *****************************************************************
-- END OF: INCONSIS_BROKER_DEP_OTC
-- *****************************************************************

INCONSIS_BROKER_DEP_OTC;

  -- *****************************************************************
  -- Description: PROCEDURE FOLIO_NOT_USING_1USD
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************  
PROCEDURE FOLIO_NOT_USING_1USD(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: FOLIO_NOT_USING_1USD
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR
  SELECT                  SYS_CONNECT_BY_PATH(FOLIO.name, '\')                               AS FOLIO_PATH            
                        , FOLIO.ident                                                        AS FOLIO_ID
                        , (SELECT LIBELLE FROM TITRES WHERE SICOVAM = FOLIO.SICOVAM)         AS UND_SEC
                        ,  FOLIO.SICOVAM                                                     AS UND_SICOVAM
                        , LEVEL
  FROM FOLIO
  WHERE 
  (LEVEL > 3 AND SICOVAM <> 67601761) -- NOT 1USD
  OR
  (LEVEL = 3 AND SICOVAM <> 67601761 AND SICOVAM <> 67603242 AND SICOVAM <> 68694384 ) -- FEES AND CASH S/R LEVEL CAN USE SP 500 INDEX or JPMorgan GBI Index
  START WITH FOLIO.ident IN (14414,90565)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
  order by 1, 2;

END

-- *****************************************************************
-- END OF: FOLIO_NOT_USING_1USD
-- *****************************************************************

FOLIO_NOT_USING_1USD;

  -- *****************************************************************
  -- Description: PROCEDURE REPO_TRADES_W_ACCRUED
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************
PROCEDURE REPO_TRADES_W_ACCRUED(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: REPO_TRADES_W_ACCRUED
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR
 select
        Trades.refcon                                                                       Trade_ID,        
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.BOOK_NAME                                                        Strategy,
        FUND_BOOK_STRATEGY.STRATEGY_NAME                                                    Folio,
        trader.name                                                                         Trader,
        BUSINESS_EVENTS.NAME                                                                Business_Event,
        Trades.DATENEG                                                                      d$Trade_Date,
        Instrument.LIBELLE                                                                  Instrument_Name,
        DEVISE_TO_STR(Instrument.DEVISECTT)                                           Instrument_CCY,
        allot.LIBELLE                                                                       Allotment,
        pb.REFERENCE                                                                        Depositary,
        Trades.MONTANT                                                                      p$NetAmount,
        Trades.MONTANTCOURU                                                                 p$AccruedAmount
        
from			histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam		= Trades.sicovam 
INNER JOIN      riskusers trader
ON              trader.ident			= Trades.operateur
left join       tiers pb
on              pb.ident				= Trades.DEPOSITAIRE                            
left join       affectation allot
on              allot.IDENT				= Instrument.AFFECTATION
LEFT JOIN       BUSINESS_EVENTS
ON              BUSINESS_EVENTS.ID      = Trades.TYPE 
inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME  
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 3
  START WITH FOLIO.ident IN (14414)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE 
Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND Instrument.type = 'L'
AND Trades.MONTANTCOURU <> 0;

END

-- *****************************************************************
-- END OF: REPO_TRADES_W_ACCRUED
-- *****************************************************************

REPO_TRADES_W_ACCRUED;


END PCKG_BTG_EMAILER_EXCEPTION_BO;