create or replace
PACKAGE            "PCKG_BTG_EMAILER_EXCEPTION_BO" 
AS

	TYPE T_CURSOR IS REF CURSOR;

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_FOLIO_ENTITY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE WRONG_FOLIO_ENTITY
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FRA_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE FRA_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE BOND_MISSING_DATA_UCITS
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan			 Created.
-- 27 AGO 2013    Gustavo Binnie	-Included Blackstone and Russell funds
--									-Changed the name of the procedure
-- *****************************************************************  
  PROCEDURE BOND_MISSING_DATA_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE CASH_ACCT_FILTER_COUNT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CASH_ACCT_FILTER_COUNT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE CASH_ACCT_COUNT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CASH_ACCT_COUNT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  IR_MISSING28
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE IR_MISSING28
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  COMMA_IN_NAME
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE COMMA_IN_NAME
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE  MISSING_AX_CODE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE MISSING_AX_CODE 
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE DUPE_BARRIER
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE DUPE_BARRIER
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE  INVALID_CALC_AGENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE INVALID_CALC_AGENT
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_NOTIONAL
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE SWAPTION_NOTIONAL
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  OPTION_MISSING_VALIDATION
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE OPTION_MISSING_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FXOPTION_MISSING_VOL
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE FXOPTION_MISSING_VOL
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  BOVESPA_NOT_INDFUT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE BOVESPA_NOT_INDFUT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_INTERPOLATION
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE WRONG_INTERPOLATION
	(
		p_CURSOR OUT T_CURSOR
	);




-- *****************************************************************
-- Description:     PROCEDURE  ALLOC_RULE_POSTPROC
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE ALLOC_RULE_POSTPROC
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_FX_IN_PARENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CCY_CURVE_FX_IN_PARENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_BASIS_UNDERLYING
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CCY_CURVE_BASIS_UNDERLYING
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  CDS_WRONG_RE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CDS_WRONG_RE
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_MISSING_MARKET_CREDIT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CONVERT_MISSING_MARKET_CREDIT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
  -- *****************************************************************
-- Description:     PROCEDURE EXCHANGE_MANY_DP
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EXCHANGE_MANY_DP 
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_GLBL_ABS_FOLIOS
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE INCONSISTENT_GLBL_ABS_FOLIOS
	(
		p_CURSOR OUT T_CURSOR
	);
    
  
  -- *****************************************************************
-- Description:     PROCEDURE  PUBLIC_ALLOC_RULE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE PUBLIC_ALLOC_RULE
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  TRS_MISSING_ISIN
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE TRS_MISSING_ISIN
	(
		P_CURSOR OUT T_CURSOR
	);
  


-- *****************************************************************
-- Description:     PROCEDURE  WRONG_FIFO
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE WRONG_FIFO
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  WRONG_TERM_OIS_RATE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE WRONG_TERM_OIS_RATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE SWAPTION_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE CDS_OPTION_WRONG_ALLOTMENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************    
  PROCEDURE CDS_OPTION_WRONG_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  VARSWAP_OPTION_WRONG_ALLOTMENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE VARSWAP_OPTION_WRONG_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CDS_OPTION_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CDS_OPTION_MISSING_WRONG_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISS_ISSUER
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE BOND_MISS_ISSUER
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE RED_OVER_300
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 22 Feb 2013   Oliver South     Moved from PCKG_BTG_EMAILER_OPSREPORTS
  -- *****************************************************************
  PROCEDURE RED_OVER_300
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE DF_NDF_LAST_PRICE
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 04 Mar 2013   Oliver South     New
  -- *****************************************************************
  PROCEDURE DF_NDF_LAST_PRICE
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
 -- *****************************************************************
 -- Description:     PROCEDURE  SOPHIS_USER_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 17 Jun 2013      Jun Guan      Created.
 -- *****************************************************************  
  
  PROCEDURE SOPHIS_USER_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  ALLOTMENT_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 17 Jun 2013      Jun Guan      Created.
 -- *****************************************************************  
  
  PROCEDURE ALLOTMENT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

   -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_CL_BIC_UCITS
 --                  
 --
 -- Author:           Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_CL_BIC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);
  
     -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_EUCL_BIC_UCITS
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_EUCL_BIC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_CL_SAFEACC_UCITS
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_CL_SAFEACC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
 -- *****************************************************************
 -- Description:     PROCEDURE  MISSING_BUS_CENTER_MAP
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- *****************************************************************  
  
  PROCEDURE MISSING_BUS_CENTER_MAP
	(
		p_CURSOR OUT T_CURSOR
	);
  
 -- *****************************************************************
 -- Description:     PROCEDURE  BD_CPTY_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 29 Jul 2013      Jun Guan       Created.
 -- *****************************************************************  
  
  PROCEDURE BD_CPTY_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

 -- *****************************************************************
 -- Description:     PROCEDURE  CP_FEES_ON_BOND
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 14 Aug 2013		Oliver South	Created
 -- *****************************************************************  
  
  PROCEDURE CP_FEES_ON_BOND
	(
		p_CURSOR OUT T_CURSOR
	);
	 
 -- *****************************************************************
 -- Description:     PROCEDURE  DEPO_INST_ACCT_ALLOTMENT
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 20 sep 2013		   Jun Guan	      Created
 -- *****************************************************************  
  
  PROCEDURE DEPO_INST_ACCT_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  RESTRICT_CHAR_TIERS
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 25 sep 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE RESTRICT_CHAR_TIERS
	(
		p_CURSOR OUT T_CURSOR
	);
	  
 -- *****************************************************************
 -- Description:     PROCEDURE  ISSUER_CREDIT_CURVE
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 4 Oct 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE ISSUER_CREDIT_CURVE
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  FOLIO_STRATEGY_MATCH
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 15 Nov 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE FOLIO_STRATEGY_MATCH

	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  EXT_REF_BLANKS
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 07 Jan 2014		 Oliver South	 Created
 -- *****************************************************************  
  
  PROCEDURE EXT_REF_BLANKS

	(
		p_CURSOR OUT T_CURSOR
	);
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  MBS_BOND_EXCEPTION_REPORT
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 02 FEB 2014      Gustavo Binnie      Created.
-- ***************************************************************** 
  
  PROCEDURE MBS_BOND_EXCEPTION_REPORT

	(
		p_CURSOR OUT T_CURSOR
	);

  
   -- *****************************************************************
-- Description:     PROCEDURE  ALLOT_MISSING_SEC_TYPE_AEXEO
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 11 Aug 2014      Gustavo Binnie      Created.
-- ***************************************************************** 

  PROCEDURE ALLOT_MISSING_SEC_TYPE_AEXEO

	(
		p_CURSOR OUT T_CURSOR
	);



  -- *****************************************************************
  -- Description: PROCEDURE BROKER_DEALER_WRONG_BROKER
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 2013-07-19       Jun Guan      Created.
  -- *****************************************************************
	PROCEDURE BROKER_DEALER_WRONG_BROKER
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  INDEX_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30-Jan-2015      Jun Guan            Created.
-- ***************************************************************** 

  PROCEDURE INDEX_CDS_MISSING_WRONG_DATA

	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  SINGLE_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16-Feb-2015      Jun Guan            Created.
-- ***************************************************************** 

  PROCEDURE SINGLE_CDS_MISSING_WRONG_DATA

	(
		p_CURSOR OUT T_CURSOR
	);


  -- *****************************************************************
  -- Description: PROCEDURE BROKER_MIFID_NOT_SET
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 20 May 2013   Jun Guan         Created.
  -- 01 JAN 2014   Gustavo Binnie   Moved from EXCEPTION_BO to EDM package.
   -- 10 APR 2015   L Iniesta   Moved back
  -- *****************************************************************
  PROCEDURE BROKER_MIFID_NOT_SET
	(
		p_CURSOR OUT T_CURSOR
	);

  
  -- *****************************************************************
  -- Description: PROCEDURE INCONSIS_BROKER_DEP_OTC
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 03 July 2015     Davi Xavier     Created.
  -- *****************************************************************
  PROCEDURE INCONSIS_BROKER_DEP_OTC
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE FOLIO_NOT_USING_1USD
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************
  PROCEDURE FOLIO_NOT_USING_1USD
	(
		p_CURSOR OUT T_CURSOR
	);

	  -- *****************************************************************
  -- Description: PROCEDURE REPO_TRADES_W_ACCRUED
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************
  PROCEDURE REPO_TRADES_W_ACCRUED
	(
		p_CURSOR OUT T_CURSOR
	);


  
END PCKG_BTG_EMAILER_EXCEPTION_BO;