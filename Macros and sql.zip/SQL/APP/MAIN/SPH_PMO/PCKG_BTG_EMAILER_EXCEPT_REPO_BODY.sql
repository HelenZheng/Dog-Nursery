create or replace
PACKAGE BODY            "PCKG_BTG_EMAILER_EXCEPT_REPO" 
AS

 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_START_END_CASH_DIFF
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  

  PROCEDURE REPO_START_END_CASH_DIFF
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REPO_START_END_CASH_DIFF
  -- *****************************************************************   
          OPEN p_CURSOR FOR
		SELECT    'Diff On Cash Flow'    
         , TITRES.SICOVAM                                        
         , TITRES.LIBELLE                                         
         , SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.MONTANT ELSE 0.0 END) DIFF_ON_CASH_FLOW
         , REPLACE(BTG_FOLIONAMEPATH(OPCVM),'/BTG - Portfolio Structure/BTG - Funds/Primary Funds/','') strategy
           FROM          histomvts t0                                             
           INNER JOIN    titres                                                   
           ON            titres.sicovam = t0.sicovam                              
           AND           titres.TYPE = 'L' --only repo instruments                
           INNER JOIN    business_events                                          
           ON            business_events.ID = t0.TYPE   
		   INNER JOIN    tiers depositary
           ON            depositary.ident=t0.depositaire
           AND           depositary.ident             not in (10008642,10007082) -- exclude PACT-2689-ARF and BTG-PACTUAL-GEMM                          
           INNER JOIN    TITRES ULY    
           ON            ULY.SICOVAM = TITRES.CODE_EMET --links to bond notional   
           AND           ULY.TYPE IN ('O','D') --only repo instruments  
		             
                     
		    
      
      WHERE                                                           
                         T0.BACKOFFICE  IN 
                                            ( 
                                              SELECT      BO_KERNEL_STATUS.ID 
                                              FROM        BO_KERNEL_STATUS_GROUP      
                                              INNER JOIN  BO_KERNEL_BLOTTERS                       
                                              ON          BO_KERNEL_BLOTTERS.STATUS_GROUP_ID =  BO_KERNEL_STATUS_GROUP.ID                      
                                              INNER JOIN  BO_KERNEL_STATUS_COMPONENT                      
                                              ON          BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID  =  BO_KERNEL_BLOTTERS.STATUS_GROUP_ID                      
                                              INNER JOIN  BO_KERNEL_STATUS                      
                                              ON          BO_KERNEL_STATUS.ID  =  BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID                      
                                              WHERE                     
                                              BO_KERNEL_STATUS_GROUP.NAME = 'Pending FM'                     
                                              AND BO_KERNEL_BLOTTERS.ID  = 280
                                             )  

                         AND EXISTS (                                                                                                                     
                                         SELECT      1 
                                         FROM FOLIO                          
                                         WHERE              IDENT  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS)                                                   
                                         START WITH         IDENT = T0.OPCVM                
                                         CONNECT BY PRIOR    MGR = IDENT            
                                   )                                             
           HAVING                                                                  
           ABS( SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.QUANTITE ELSE 0.0 END) )  <= 0.000001                                                
           AND SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.MONTANT ELSE 0.0 END) != 0.0                                                                
           GROUP BY                                                                
           TITRES.LIBELLE,                                                         
           TITRES.SICOVAM,                                                         
           T0.OPCVM,                                                               
           T0.MVTIDENT,                                                            
           ULY.LIBELLE,                                                            
           ULY.SICOVAM     
           ORDER BY ABS( DIFF_ON_CASH_FLOW) DESC;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- *****************************************************************
  -- END OF: REPO_START_END_CASH_DIFF
  -- *****************************************************************   
	END REPO_START_END_CASH_DIFF; 
  
 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_MORE_THAN_ONE_CPTY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  

  PROCEDURE REPO_MORE_THAN_ONE_CPTY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REPO_MORE_THAN_ONE_CPTY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
		SELECT 
                    'Closed Repo Positions using more than one CounterPatie' ,
                    SICOVAM,
                    NAME ,
                    CASE WHEN (ABS(QTD) <=0.0000001) 
                              THEN 'Closed' 
                              ELSE 'Oppened'                                         
                    END STATUS ,  
                    NB_CP NUMBER_OF_COUNTER_PARTIES,
                    REPLACE(BTG_FOLIONAMEPATH(OPCVM),'/BTG - Portfolio Structure/BTG - Funds/Primary Funds/','') STRATEGY
                    FROM
                               (       SELECT                                                                 
                                                        SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.QUANTITE ELSE 0.0 END)     QTD
                                                        , SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.COUPON ELSE 0.0 END)   
                                                           , SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.MONTANTCOURU ELSE 0.0 END)  MONTANTACRRUED
                                                        , SUM( T0.MONTANTCOURU )      
                                                        , SUM(ULY.NOMINAL*T0.QUANTITE)  
                                                        , COUNT(DISTINCT T0.CONTREPARTIE) NB_CP  
                                                        , TITRES.LIBELLE    NAME                                      
                                                        , TITRES.SICOVAM                                          
                                                        , T0.MVTIDENT                                             
                                                        , T0.OPCVM       
                                                        
                                                        , ULY.LIBELLE         BOND_NAME                                    
                                                        , ULY.SICOVAM UNDERLYINGBOND                              
                                                        , SUBSTR(TO_CHAR(MAX(T0.DATENEG), 'DD/MM/YYYY'),4,12) AS DATENEG_MAX     
                                                        , SUBSTR(TO_CHAR(MAX(T0.DATEVAL), 'DD/MM/YYYY'),4,12) AS DATEVAL_MAX     
                                                        , SUBSTR(TO_CHAR(MIN(T0.DATENEG), 'DD/MM/YYYY'),4,12) AS DATENEG_MIN     
                                                        , SUBSTR(TO_CHAR(MIN(T0.DATEVAL), 'DD/MM/YYYY'),4,12) AS DATEVAL_MIN     
                                                        , MIN(T0.DATEVAL) OPENDATE                                                          
                                          FROM          HISTOMVTS T0                                              
                                          INNER JOIN    TITRES                                                    
                                          ON            TITRES.SICOVAM = T0.SICOVAM                               
                                          AND           TITRES.TYPE = 'L' --only repo instruments                 
                                          INNER JOIN    BUSINESS_EVENTS                                           
                                          ON            BUSINESS_EVENTS.ID = T0.TYPE                              
                                          INNER JOIN    TITRES ULY     
                                          ON            ULY.SICOVAM = TITRES.CODE_EMET --links to bond notional    
                                          AND           ULY.TYPE IN ('O','D') --only repo instruments              
                                          WHERE                                                                    
                                                        T0.BACKOFFICE  IN  
                                                                             ( SELECT      BO_KERNEL_STATUS.ID  
                                                                               FROM        BO_KERNEL_STATUS_GROUP       
                                                                               INNER JOIN  BO_KERNEL_BLOTTERS                        
                                                                               ON          BO_KERNEL_BLOTTERS.STATUS_GROUP_ID =  BO_KERNEL_STATUS_GROUP.ID                       
                                                                               INNER JOIN  BO_KERNEL_STATUS_COMPONENT                       
                                                                               ON          BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID  =  BO_KERNEL_BLOTTERS.STATUS_GROUP_ID                       
                                                                               INNER JOIN  BO_KERNEL_STATUS                       
                                                                               ON          BO_KERNEL_STATUS.ID  =  BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID                       
                                                                               WHERE                      
                                                                               BO_KERNEL_STATUS_GROUP.NAME = 'Pending FM'                      
                                                                               AND BO_KERNEL_BLOTTERS.ID  = 280   )   
                                                        AND EXISTS (                                                                                     
                                                                        SELECT         1  
                                                                        FROM             FOLIO                           
                                                                        WHERE            IDENT  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS)                                                                                                                                      
                                                                        START WITH       IDENT = T0.OPCVM                 
                                                                        CONNECT BY PRIOR MGR = IDENT             
                                                                    )                                              
                                          HAVING                                                                   
                                         
                                         COUNT(DISTINCT T0.CONTREPARTIE) >1  
                                          GROUP BY                                                                 
                                          TITRES.LIBELLE,                                                          
                                          TITRES.SICOVAM,                                                          
                                          T0.OPCVM,                                                                
                                          T0.MVTIDENT,                                                             
                                          ULY.LIBELLE,                                                             
                                          ULY.SICOVAM  
                                       )      ;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- *****************************************************************
  -- END OF: REPO_MORE_THAN_ONE_CPTY
  -- *****************************************************************   
	END REPO_MORE_THAN_ONE_CPTY; 
  
 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_TRADE_NO_CCY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  

  PROCEDURE REPO_TRADE_NO_CCY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REPO_TRADE_NO_CCY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
		SELECT
            'Currency without its fx pair/cash comission ',
            RISKUSERS.name Trader,
            T0.SICOVAM ,
            TITRES.LIBELLE NAME , 
            T0.REFCON TRADE_ID,
            BUSINESS_EVENTS.NAME BUSINESS_EVENT ,
            REPLACE(BTG_FOLIONAMEPATH(OPCVM),'/BTG - Portfolio Structure/BTG - Funds/Primary Funds/','') STRATEGY                                                                                             
            FROM          HISTOMVTS T0                                              
            INNER JOIN    TITRES                                                    
            ON            TITRES.SICOVAM = T0.SICOVAM                               
            AND           TITRES.TYPE = 'L' --only repo instruments                 
            INNER JOIN    BUSINESS_EVENTS                                           
            ON            BUSINESS_EVENTS.ID = T0.TYPE                              
            LEFT JOIN     RISKUSERS
            ON            RISKUSERS.ident=T0.OPERATEUR
            INNER JOIN    TITRES ULY     
            ON            ULY.SICOVAM = TITRES.CODE_EMET --links to bond notional    
            AND           ULY.TYPE IN ('O','D') --only repo instruments              
            WHERE                                                                    
            T0.BACKOFFICE  IN  
                                 ( SELECT      BO_KERNEL_STATUS.ID  
                                   FROM        BO_KERNEL_STATUS_GROUP       
                                   INNER JOIN  BO_KERNEL_BLOTTERS                        
                                   ON          BO_KERNEL_BLOTTERS.STATUS_GROUP_ID =  BO_KERNEL_STATUS_GROUP.ID                       
                                   INNER JOIN  BO_KERNEL_STATUS_COMPONENT                       
                                   ON          BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID  =  BO_KERNEL_BLOTTERS.STATUS_GROUP_ID                       
                                   INNER JOIN  BO_KERNEL_STATUS                       
                                   ON          BO_KERNEL_STATUS.ID  =  BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID                       
                                   WHERE                      
                                   BO_KERNEL_STATUS_GROUP.NAME = 'Pending FM'                      
                                   AND BO_KERNEL_BLOTTERS.ID  = 280   )   

            AND EXISTS (                                                                                                                                            
                          SELECT       1 
                          FROM            FOLIO                           
                          WHERE            IDENT  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS)                                                                                                         
                          START WITH       IDENT = T0.OPCVM                 
                          CONNECT BY PRIOR MGR = IDENT             
                        )                                              

           AND T0.DEVISEPAY =0 ;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- *****************************************************************
  -- END OF: REPO_TRADE_NO_CCY
  -- *****************************************************************   
	END REPO_TRADE_NO_CCY; 


 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_OPEN_CLOSE_QTY_DIFF
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  

  PROCEDURE REPO_OPEN_CLOSE_QTY_DIFF
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REPO_OPEN_CLOSE_QTY_DIFF
  -- *****************************************************************   
          OPEN p_CURSOR FOR
		SELECT 
                          'Diff on Closing quantity'
                          SICOVAM,
                          NAME ,
                          QTD,
                          REPLACE(BTG_FOLIONAMEPATH(OPCVM),'/BTG - Portfolio Structure/BTG - Funds/Primary Funds/','')      
                          FROM
                                     (       SELECT                                                                 
                                                              SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.QUANTITE ELSE 0.0 END)     QTD
                                                              , SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.COUPON ELSE 0.0 END)   
                                                                 , SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.MONTANTCOURU ELSE 0.0 END)  MONTANTACRRUED
                                                              , SUM( T0.MONTANTCOURU )      
                                                              , SUM(ULY.NOMINAL*T0.QUANTITE)                            
                                                              , TITRES.LIBELLE    NAME                                      
                                                              , TITRES.SICOVAM                                          
                                                              , T0.MVTIDENT                                             
                                                              , T0.OPCVM       
                                                              
                                                              , ULY.LIBELLE         BOND_NAME                                    
                                                              , ULY.SICOVAM UNDERLYINGBOND                              
                                                              , SUBSTR(TO_CHAR(MAX(T0.DATENEG), 'DD/MM/YYYY'),4,12) AS DATENEG_MAX     
                                                              , SUBSTR(TO_CHAR(MAX(T0.DATEVAL), 'DD/MM/YYYY'),4,12) AS DATEVAL_MAX     
                                                              , SUBSTR(TO_CHAR(MIN(T0.DATENEG), 'DD/MM/YYYY'),4,12) AS DATENEG_MIN     
                                                              , SUBSTR(TO_CHAR(MIN(T0.DATEVAL), 'DD/MM/YYYY'),4,12) AS DATEVAL_MIN     
                                                              , MIN(T0.DATEVAL) OPENDATE                                                          
                                                FROM          HISTOMVTS T0                                              
                                                INNER JOIN    TITRES                                                    
                                                ON            TITRES.SICOVAM = T0.SICOVAM                               
                                                AND           TITRES.TYPE = 'L' --only repo instruments                 
                                                INNER JOIN    BUSINESS_EVENTS                                           
                                                ON            BUSINESS_EVENTS.ID = T0.TYPE                              
                                                INNER JOIN    TITRES ULY     
                                                ON            ULY.SICOVAM = TITRES.CODE_EMET --links to bond notional    
                                                AND           ULY.TYPE IN ('O','D') --only repo instruments              
                                                WHERE                                                                    
                                                              T0.BACKOFFICE  IN  
                                                                                   ( SELECT      BO_KERNEL_STATUS.ID  
                                                                                     FROM        BO_KERNEL_STATUS_GROUP       
                                                                                     INNER JOIN  BO_KERNEL_BLOTTERS                        
                                                                                     ON          BO_KERNEL_BLOTTERS.STATUS_GROUP_ID =  BO_KERNEL_STATUS_GROUP.ID                       
                                                                                     INNER JOIN  BO_KERNEL_STATUS_COMPONENT                       
                                                                                     ON          BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID  =  BO_KERNEL_BLOTTERS.STATUS_GROUP_ID                       
                                                                                     INNER JOIN  BO_KERNEL_STATUS                       
                                                                                     ON          BO_KERNEL_STATUS.ID  =  BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID                       
                                                                                     WHERE                      
                                                                                     BO_KERNEL_STATUS_GROUP.NAME = 'Pending FM'                      
                                                                                     AND BO_KERNEL_BLOTTERS.ID  = 280   )   
                                                              AND EXISTS (                                                                                                                                                                                
                                                                                SELECT    1 
                                                                                FROM      FOLIO                           
                                                                                WHERE            IDENT  IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS)                  
                                                                                START WITH       IDENT = T0.OPCVM                 
                                                                                CONNECT BY PRIOR  MGR = IDENT             
                                                                          )                                              
                                                HAVING                                                                   
                                                ABS( SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.QUANTITE ELSE 0.0 END) )  <= 0.001
                                                AND  ABS( SUM(CASE WHEN BUSINESS_EVENTS.COMPTA =1 THEN T0.QUANTITE ELSE 0.0 END) )  != 0.0
                                                GROUP BY                                                                 
                                                TITRES.LIBELLE,                                                          
                                                TITRES.SICOVAM,                                                          
                                                T0.OPCVM,                                                                
                                                T0.MVTIDENT,                                                             
                                                ULY.LIBELLE,                                                             
                                                ULY.SICOVAM  
                                             )      

               ORDER BY ABS(QTD) DESC ;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- *****************************************************************
  -- END OF: REPO_OPEN_CLOSE_QTY_DIFF
  -- *****************************************************************   
	END REPO_OPEN_CLOSE_QTY_DIFF; 
  
  
  
 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_MISSED_EXPIRY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 22 Nov 2013      Jun Guan       Created.
 -- 06 DEC 2017     Jeff Yu    Modified (PMOG-1176).--exclude QSF fund
 -- *****************************************************************  

  PROCEDURE REPO_MISSED_EXPIRY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: REPO_MISSED_EXPIRY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
		SELECT      
                  security.FINPER                   d$Expiry
                , affectation.libelle               Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME      Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME      Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME  Folio_name
                , security.reference                Instrument_Name
                , sum(histomvts.quantite)           n$Quantity
                , histomvts.sicovam                 Sicovam
				, FUND_BOOK_STRATEGY.STRATEGY_ID	Folio_ID
FROM            histomvts

INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM

INNER JOIN  titres security
ON          security.sicovam          = histomvts.sicovam

INNER JOIN  business_events
ON          business_events.id = histomvts.type

LEFT JOIN affectation
ON        affectation.ident = security.affectation

WHERE       
          histomvts.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       business_events.compta = 1 --position trades only
AND       FUND_BOOK_STRATEGY.Fund_NAME NOT IN ('BTG PACTUAL INTERNATIONAL B','QSF MASTER Fund') --out of scope
AND       (security.type = 'L' and to_date(security.finper,'DD-MON-YY')!=to_date('01-JAN-04','DD-MON-YY') and trunc(security.FINPER) <= trunc(sysdate-1)) --Repo
          
GROUP BY          security.FINPER, 
                  affectation.libelle,
                  FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, security.reference, histomvts.sicovam, FUND_BOOK_STRATEGY.STRATEGY_ID                                 
HAVING round(sum(histomvts.quantite),5) !=0
ORDER BY 1,6,3;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- *****************************************************************
  -- END OF: REPO_MISSED_EXPIRY
  -- *****************************************************************   
	END REPO_MISSED_EXPIRY; 

 -- *****************************************************************
 -- Description: PROCEDURE REPO_TERM_RERATE
 --/*collects all re-rates done on term repos. These should not exist*/
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date        Author        Reason for Change
 -- ----------------------------------------------------------------
 --   2012      Jun Guan      Created.
 -- *****************************************************************

  PROCEDURE REPO_TERM_RERATE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN  OF: REPO_TERM_RERATE
  -- ***************************************************************** 
    OPEN p_CURSOR FOR

    SELECT          
                     Trades.sicovam                        Sicovam
                    ,Trades.refcon                         Trade_Id
                    ,trader.name                           Trader
                    ,Instrument.libelle                    Repo_Name
                    ,Instrument.reference                  Ticker
                    ,business_events.name                  BusinesEvent    
    FROM            
                    histomvts                              Trades 
    INNER JOIN      business_events
    ON              business_events.id            =        Trades.type
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam            =        Trades.sicovam 
    INNER JOIN      riskusers trader
    ON              trader.ident                  =        Trades.operateur
    WHERE
                    Instrument.type               =        'L' --Repo
    AND             Instrument.finper            !=       '01-Jan-1904' --Term Repo
    AND             Trades.type                   =        28 --Rerate
    AND             Trades.dateneg                >        sysdate-5 --recent trades
    ORDER BY        1 asc;
       
      EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

  -- *****************************************************************
  -- END  OF: REPO_TERM_RERATE
  -- ***************************************************************** 
        END REPO_TERM_RERATE;


 -- *****************************************************************
 -- Description: PROCEDURE REPO_CLOSE_CP
 -- Repos closed out with a different counterparty from which they were opened.
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 --    2012      Jun Guan     Created.
 -- *****************************************************************

  PROCEDURE REPO_CLOSE_CP
       (
    p_CURSOR OUT T_CURSOR
       )
       AS
       BEGIN
  -- *****************************************************************
  -- BEGIN  OF: REPO_CLOSE_CP
  -- **************************************************************** 
    OPEN p_CURSOR FOR
    
      SELECT     repo_trades_close.sicovam
                , repo_trades_close.contrepartie
                , repo_trades_close.amount close_count
                , repo_trades_open.amount open_count
                , riskusers.name trader
      FROM (
                 SELECT   histomvts.sicovam
                        , histomvts.type
                        , histomvts.contrepartie
                        , count(*)                      amount
                FROM histomvts
                WHERE histomvts.sicovam IN 
                                            (
                                              SELECT       titres.sicovam 
                                              FROM         titres
                                              INNER JOIN   histomvts 
                                              ON           histomvts.sicovam = titres.sicovam
                                              WHERE        titres.type       = 'L'
                                              AND          histomvts.type    = 9
                                            ) 
               AND histomvts.type            = 9
               AND histomvts.backoffice      NOT IN (192,11,13,17,26,27,220,248,252)
               GROUP BY   histomvts.sicovam
                        , histomvts.type
                        , histomvts.contrepartie
            ) repo_trades_close
      RIGHT OUTER JOIN   (
                           SELECT              histomvts.sicovam
                                             , histomvts.type
                                             , histomvts.contrepartie
                                             , count(*) amount
                                FROM          histomvts
                                WHERE         histomvts.sicovam IN 
                                                                    (
                                                                      SELECT        titres.sicovam 
                                                                      FROM          titres
                                                                      INNER JOIN    histomvts 
                                                                      ON            histomvts.sicovam = titres.sicovam
                                                                      WHERE         titres.type       = 'L'
                                                                      AND           histomvts.type    = 9
                                                                    ) 
                                AND           histomvts.type          = 1
                                AND           histomvts.backoffice    NOT IN (192,11,13,17,26,27,220,248,252)
                                GROUP BY      histomvts.sicovam
                                            , histomvts.type
                                            , histomvts.contrepartie
                            )   repo_trades_open
      ON                        repo_trades_close.sicovam            = repo_trades_open.sicovam
      AND                       repo_trades_close.contrepartie       = repo_trades_open.contrepartie
      
      left join histomvts
      on histomvts.sicovam=repo_trades_open.sicovam
      and histomvts.type=1
      
      left join riskusers
      ON riskusers.ident=histomvts.operateur
      
      WHERE                     repo_trades_open.amount              < repo_trades_close.amount
      AND                       repo_trades_close.sicovam            != 68171902
      ORDER BY                  repo_trades_close.sicovam
                              , repo_trades_close.contrepartie;

    EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	 

  -- ***************************************************************************
  -- END OF REPO_CLOSE_CP 
  -- ***************************************************************************

 END REPO_CLOSE_CP;

 -- *****************************************************************
 -- Description: PROCEDURE REPO_MANY_CLOSEOUT
 -- 
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------

  PROCEDURE REPO_MANY_CLOSEOUT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF REPO_MANY_CLOSEOUT 
  -- *************************************************************************** 
     OPEN p_CURSOR FOR


      SELECT 
                    histomvts.sicovam                 Sicovam 
                  , repo.reference                    REPO_Reference
      FROM 
                    histomvts
      INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                                AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                              AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)      AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)       AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)      AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)       AS BOOK_NAME
                          , FOLIO.ident                                                              AS STRATEGY_ID
                          , FOLIO.name                                                               AS STRATEGY_NAME
                          ,level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
      ON        FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
      INNER JOIN  tiers counterparty
      ON          counterparty.ident            = histomvts.contrepartie
      INNER JOIN  tiers depositary
      ON          depositary.ident              = histomvts.depositaire
	  AND         depositary.ident             not in (10008642,10007082) -- exclude PACT-2689-ARF and BTG-PACTUAL-GEMM 
      INNER JOIN  titres repo
      ON          repo.sicovam                  = histomvts.sicovam
      WHERE       histomvts.type                =1 
      AND         repo.type                     ='L' 
      AND         trunc(dateneg)                >'06-sep-2011'
      AND         backoffice                   NOT IN (252,13)
      AND         (
                     counterparty.name         NOT LIKE '%INTERNAL%' 
                     AND 
                     counterparty.name         != 'UBS BOOK TRANSFER'
                  )
      AND         depositary.name               NOT LIKE '%INTERNAL%' 
      AND         histomvts.BACKOFFICE          NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
      GROUP BY    histomvts.sicovam
                 ,repo.reference
      HAVING COUNT(*)>1;
	
     EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

  -- ***************************************************************************
  -- END OF REPO_MANY_CLOSEOUT 
  -- *************************************************************************** 
        END REPO_MANY_CLOSEOUT; 
        
        
   -- *****************************************************************
 -- Description: PROCEDURE XCCY_REPO_DIFF_RATE
 -- 
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------

  PROCEDURE XCCY_REPO_DIFF_RATE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF XCCY_REPO_DIFF_RATE 
  -- *************************************************************************** 
     OPEN p_CURSOR FOR

SELECT 
	 CLOSED_XCCY_REPO_TRADES.FUND
	,CLOSED_XCCY_REPO_TRADES.strategy
	,CLOSED_XCCY_REPO_TRADES.Folio
	,CLOSED_XCCY_REPO_TRADES.sicovam
	,CLOSED_XCCY_REPO_TRADES.instrument_reference
	,CLOSED_XCCY_REPO_TRADES.instrument_name
	,CLOSED_XCCY_REPO_TRADES.instrument_ccy
	,CLOSED_XCCY_REPO_TRADES.sett_ccy
	,CLOSED_XCCY_REPO_TRADES.rate
	,count(CLOSED_XCCY_REPO_TRADES.sicovam)
FROM (
	SELECT riskusers.NAME trader
		,FUND_BOOK_STRATEGY.Fund_NAME Fund
		,FUND_BOOK_STRATEGY.book_name Strategy
		,FUND_BOOK_STRATEGY.strategy_NAME Folio
		,trades.refcon TradeID
		,trades.dateneg Trade_Date
		,trades.dateval Settlement_Date
		,trades.sicovam sicovam
		,titres.reference instrument_reference
		,titres.libelle instrument_name
		,devise_to_str(inst.code) instrument_ccy
		,trades.montant Net_Amount
		,devise_to_str(sett.code) sett_ccy
		,trades.tauxchange rate
		,business_events.NAME business_event
	FROM histomvts trades
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) 
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
	ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	
	INNER JOIN titres
	ON titres.sicovam = trades.sicovam
	AND titres.type = 'L'
	
	INNER JOIN (
		SELECT trades.sicovam
			,trades.entite
			,FUND_BOOK_STRATEGY.FUND_ID
			,FUND_BOOK_STRATEGY.Fund_NAME
			,FUND_BOOK_STRATEGY.book_id
			,FUND_BOOK_STRATEGY.book_name
			,FUND_BOOK_STRATEGY.strategy_id
			,FUND_BOOK_STRATEGY.strategy_name
			,sum(trades.quantite)
		FROM histomvts trades
		INNER JOIN (
			SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
				,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
				,FOLIO.ident AS STRATEGY_ID
				,FOLIO.NAME AS STRATEGY_NAME
				,LEVEL
			FROM FOLIO
			WHERE LEVEL >= 4 START
			WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) 
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
			) FUND_BOOK_STRATEGY
			ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
		INNER JOIN titres
		ON titres.sicovam = trades.sicovam
		AND titres.type = 'L'
		
		INNER JOIN business_events
		ON business_events.id = trades.type
		AND business_events.compta = 1
		WHERE trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
		AND trades.quantite != 0
		
		GROUP BY 
		     trades.sicovam
			,trades.entite
			,FUND_BOOK_STRATEGY.FUND_ID
			,FUND_BOOK_STRATEGY.Fund_NAME
			,FUND_BOOK_STRATEGY.book_id
			,FUND_BOOK_STRATEGY.book_name
			,FUND_BOOK_STRATEGY.strategy_id
			,FUND_BOOK_STRATEGY.strategy_name
			
		HAVING sum(trades.quantite) = 0
		) close_position
	ON close_position.sicovam = trades.sicovam
	AND close_position.entite = trades.entite
	AND FUND_BOOK_STRATEGY.STRATEGY_ID = close_position.strategy_id
	
	INNER JOIN devisev2 sett
	ON sett.code = trades.devisepay
	
	INNER JOIN devisev2 inst
	ON inst.code = titres.devisectt
	
	INNER JOIN business_events
	ON business_events.id = trades.type
	AND business_events.compta = 1
	
	LEFT JOIN RISKUSERS
	ON RISKUSERS.ident = trades.operateur
	
	WHERE titres.devisectt != trades.devisepay
	AND trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
	AND 
  (
  titres.devisectt not IN (54805837,55137356,54940230) or 
  (titres.devisectt IN (54805837,55137356,54940230) AND trades.devisepay != 54875474)
  )-- Ignore trades if instrument ccy are in (DEM,FRF,ITL) and settle in EUR
	ORDER BY titres.sicovam DESC
	) CLOSED_XCCY_REPO_TRADES
	
GROUP BY CLOSED_XCCY_REPO_TRADES.FUND
	,CLOSED_XCCY_REPO_TRADES.strategy
	,CLOSED_XCCY_REPO_TRADES.Folio
	,CLOSED_XCCY_REPO_TRADES.sicovam
	,CLOSED_XCCY_REPO_TRADES.instrument_reference
	,CLOSED_XCCY_REPO_TRADES.instrument_name
	,CLOSED_XCCY_REPO_TRADES.instrument_ccy
	,CLOSED_XCCY_REPO_TRADES.sett_ccy
	,CLOSED_XCCY_REPO_TRADES.rate
	
HAVING count(CLOSED_XCCY_REPO_TRADES.sicovam) < 2

ORDER BY CLOSED_XCCY_REPO_TRADES.sicovam;

     EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

  -- ***************************************************************************
  -- END OF XCCY_REPO_DIFF_RATE 
  -- *************************************************************************** 
        END XCCY_REPO_DIFF_RATE; 
        
        
 -- *****************************************************************
 -- Description: PROCEDURE REPO_WITH_FEES
 -- 
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------

  PROCEDURE REPO_WITH_FEES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF REPO_WITH_FEES 
  -- *************************************************************************** 
     OPEN p_CURSOR FOR

select 
riskusers.name trader, 
FUND_BOOK_STRATEGY.Fund_NAME Fund, 
FUND_BOOK_STRATEGY.book_name Strategy, 
FUND_BOOK_STRATEGY.strategy_NAME Folio, 
histomvts.refcon TradeID, 
histomvts.dateneg Trade_Date, 
histomvts.dateval Settlement_Date, 
titres.reference instrument_reference, 
titres.libelle instrument_name, 
histomvts.fraismarche Market_Fee, 
histomvts.fraiscounterparty Counterparty_Fee, 
histomvts.fraiscourtage Broker_Fee, 
histomvts.quantite QTY, 
histomvts.cours price, 
histomvts.montant Net_Amount, 
business_events.name business_event 
 
 
from histomvts 
 
INNER JOIN 
        ( SELECT 
                CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID , 
                CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME , 
                FOLIO.ident AS STRATEGY_ID , 
                FOLIO.name AS STRATEGY_NAME , 
                level 
             FROM FOLIO 
             WHERE LEVEL >= 4 
             START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) 
          CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
        ) FUND_BOOK_STRATEGY 
        ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM 
 
left join business_events 
on business_events.id=histomvts.type 
 
left join riskusers 
on riskusers.ident=histomvts.operateur 
 
inner join titres 
on titres.sicovam=histomvts.sicovam 
and titres.type='L'
 
where 
histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
and (histomvts.fraiscounterparty !=0 or histomvts.fraiscourtage !=0 or histomvts.fraismarche !=0);

     EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

  -- ***************************************************************************
  -- END OF REPO_WITH_FEES 
  -- *************************************************************************** 
        END REPO_WITH_FEES; 


 -- *****************************************************************
 -- Description: PROCEDURE REPO_INVALID_HC
 -- 
 -- Author:          Jeff Yu
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- 06-FEB-2018     Jeff Yu     Created (APPSUPP-2587)
 -- 08-FEB-2018     Jeff Yu     Modified (APPSUPP-2587) --only show past 5 business days trades
 -- ----------------------------------------------------------------

  PROCEDURE REPO_INVALID_HC
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF REPO_INVALID_HC 
  -- *************************************************************************** 
     OPEN p_CURSOR FOR

SELECT HISTOMVTS.refcon AS TRADE_ID
, TRUNC(HISTOMVTS.dateneg)   AS   d$TRADE_DATE
, FOLIOS.path AS PATH
, TITRES.reference AS REFERENCE
, ROUND(HISTOMVTS.quantite) AS QUANTITY
, HISTOMVTS.infos AS INVALID_FORMAT_HAIRCUT_VALUE

FROM HISTOMVTS
INNER JOIN TITRES
ON TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN (
  SELECT FOLIO.ident,
  SUBSTR(SYS_CONNECT_BY_PATH(NAME, '\'), 2) AS PATH
  FROM FOLIO  
  START WITH FOLIO.mgr IN (14414)
  CONNECT BY FOLIO.mgr = PRIOR FOLIO.ident
) FOLIOS
ON FOLIOS.ident = HISTOMVTS.opcvm
LEFT OUTER JOIN BO_KERNEL_STATUS
ON BO_KERNEL_STATUS.id = HISTOMVTS.backoffice
WHERE HISTOMVTS.type = 1 
AND HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) 
AND TITRES.type = 'L'
AND TRUNC(HISTOMVTS.dateneg) >= BTG_BUSINESS_DATE(SYSDATE, - 5)
AND NOT REGEXP_LIKE(HISTOMVTS.infos, '^-?[0-9]?+(\.[0-9]+)?$')
;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

  -- ***************************************************************************
  -- END OF REPO_INVALID_HC 
  -- *************************************************************************** 
        END REPO_INVALID_HC; 


END PCKG_BTG_EMAILER_EXCEPT_REPO;