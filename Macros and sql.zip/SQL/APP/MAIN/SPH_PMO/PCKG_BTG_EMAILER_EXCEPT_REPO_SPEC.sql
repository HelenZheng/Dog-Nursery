create or replace
PACKAGE            "PCKG_BTG_EMAILER_EXCEPT_REPO" 
AS

	TYPE T_CURSOR IS REF CURSOR;

 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_START_END_CASH_DIFF
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  
 
   PROCEDURE REPO_START_END_CASH_DIFF
	(
		p_CURSOR OUT T_CURSOR
	); 

 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_MORE_THAN_ONE_CPTY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  
 
   PROCEDURE REPO_MORE_THAN_ONE_CPTY
	(
		p_CURSOR OUT T_CURSOR
	); 
  
 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_TRADE_NO_CCY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  
 
   PROCEDURE REPO_TRADE_NO_CCY
	(
		p_CURSOR OUT T_CURSOR
	); 

 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_OPEN_CLOSE_QTY_DIFF
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 21 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  
 
   PROCEDURE REPO_OPEN_CLOSE_QTY_DIFF
	(
		p_CURSOR OUT T_CURSOR
	); 
  
 -- *****************************************************************
 -- Description:     PROCEDURE  REPO_MISSED_EXPIRY
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 22 Nov 2013      Jun Guan       Created.
 -- *****************************************************************  
 
   PROCEDURE REPO_MISSED_EXPIRY
	(
		p_CURSOR OUT T_CURSOR
	); 

  -- *****************************************************************
  -- Description: PROCEDURE REPO_TERM_RERATE
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************

    PROCEDURE REPO_TERM_RERATE
	 (
	         p_CURSOR OUT T_CURSOR
	 );

  -- *****************************************************************
  -- Description: PROCEDURE REPO_CLOSE_CP
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************

    PROCEDURE REPO_CLOSE_CP
	 (
		 p_CURSOR OUT T_CURSOR
	 );

  -- *****************************************************************
  -- Description: PROCEDURE REPO_MANY_CLOSEOUT
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************

    PROCEDURE REPO_MANY_CLOSEOUT
	 (
		 p_CURSOR OUT T_CURSOR
	 );
   
     -- *****************************************************************
  -- Description: PROCEDURE XCCY_REPO_DIFF_RATE
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 10-Jun-2014      Jun Guan     Created.
  -- *****************************************************************

    PROCEDURE XCCY_REPO_DIFF_RATE
	 (
		 p_CURSOR OUT T_CURSOR
	 );
   
   
  -- *****************************************************************
  -- Description: PROCEDURE REPO_WITH_FEES
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 13-Jun-2014      Jun Guan      Created.
  -- *****************************************************************

    PROCEDURE REPO_WITH_FEES
	 (
		 p_CURSOR OUT T_CURSOR
	 );

END PCKG_BTG_EMAILER_EXCEPT_REPO;