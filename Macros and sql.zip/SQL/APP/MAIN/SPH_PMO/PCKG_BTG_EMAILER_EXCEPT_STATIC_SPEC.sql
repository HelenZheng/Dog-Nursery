create or replace PACKAGE            "PCKG_BTG_EMAILER_EXCEPT_STATIC" 
AS

	TYPE T_CURSOR IS REF CURSOR;

 -- *****************************************************************
 -- Description:     PROCEDURE  UNLISTED_EQUITIES_ALLOTMENT
 --                  
 --
 -- Author:          Luis Magalhaes
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 20 MAR 2018      Luis Magalhaes       Created.
 -- *****************************************************************  
 
   PROCEDURE UNLISTED_EQUITIES_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	); 

-- *****************************************************************
-- Description:     PROCEDURE  WRONG_FOLIO_ENTITY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE WRONG_FOLIO_ENTITY
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FRA_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE FRA_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE BOND_MISSING_DATA_UCITS
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan			 Created.
-- 27 AGO 2013    Gustavo Binnie	-Included Blackstone and Russell funds
--									-Changed the name of the procedure
-- *****************************************************************  
  PROCEDURE BOND_MISSING_DATA_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE CASH_ACCT_FILTER_COUNT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CASH_ACCT_FILTER_COUNT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE CASH_ACCT_COUNT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CASH_ACCT_COUNT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  IR_MISSING28
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE IR_MISSING28
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  COMMA_IN_NAME
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE COMMA_IN_NAME
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE  MISSING_AX_CODE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE MISSING_AX_CODE 
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE DUPE_BARRIER
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE DUPE_BARRIER
	(
		p_CURSOR OUT T_CURSOR
	);
-- *****************************************************************
-- Description:     PROCEDURE  INVALID_CALC_AGENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE INVALID_CALC_AGENT
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_NOTIONAL
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE SWAPTION_NOTIONAL
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  OPTION_MISSING_VALIDATION
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE OPTION_MISSING_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FXOPTION_MISSING_VOL
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE FXOPTION_MISSING_VOL
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  BOVESPA_NOT_INDFUT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE BOVESPA_NOT_INDFUT
	(
		p_CURSOR OUT T_CURSOR
	);



-- *****************************************************************
-- Description:     PROCEDURE  ALLOC_RULE_POSTPROC
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE ALLOC_RULE_POSTPROC
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_FX_IN_PARENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CCY_CURVE_FX_IN_PARENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CCY_CURVE_BASIS_UNDERLYING
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CCY_CURVE_BASIS_UNDERLYING
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  CDS_WRONG_RE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CDS_WRONG_RE
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_MISSING_MARKET_CREDIT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE CONVERT_MISSING_MARKET_CREDIT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
  -- *****************************************************************
-- Description:     PROCEDURE EXCHANGE_MANY_DP
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EXCHANGE_MANY_DP 
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_GLBL_ABS_FOLIOS
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE INCONSISTENT_GLBL_ABS_FOLIOS
	(
		p_CURSOR OUT T_CURSOR
	);
    
  
  -- *****************************************************************
-- Description:     PROCEDURE  PUBLIC_ALLOC_RULE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE PUBLIC_ALLOC_RULE
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  TRS_MISSING_ISIN
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE TRS_MISSING_ISIN
	(
		P_CURSOR OUT T_CURSOR
	);
  


-- *****************************************************************
-- Description:     PROCEDURE  WRONG_FIFO
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE WRONG_FIFO
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  WRONG_TERM_OIS_RATE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE WRONG_TERM_OIS_RATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  SWAPTION_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE SWAPTION_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE CDS_OPTION_WRONG_ALLOTMENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************    
  PROCEDURE CDS_OPTION_WRONG_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  VARSWAP_OPTION_WRONG_ALLOTMENT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE VARSWAP_OPTION_WRONG_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  CDS_OPTION_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE CDS_OPTION_MISSING_WRONG_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISS_ISSUER
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE BOND_MISS_ISSUER
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE RED_OVER_300
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 22 Feb 2013   Oliver South     Moved from PCKG_BTG_EMAILER_OPSREPORTS
  -- *****************************************************************
  PROCEDURE RED_OVER_300
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE DF_NDF_LAST_PRICE
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 04 Mar 2013   Oliver South     New
  -- *****************************************************************
  PROCEDURE DF_NDF_LAST_PRICE
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
 -- *****************************************************************
 -- Description:     PROCEDURE  SOPHIS_USER_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 17 Jun 2013      Jun Guan      Created.
 -- *****************************************************************  
  
  PROCEDURE SOPHIS_USER_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  ALLOTMENT_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 17 Jun 2013      Jun Guan      Created.
 -- *****************************************************************  
  
  PROCEDURE ALLOTMENT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

   -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_CL_BIC_UCITS
 --                  
 --
 -- Author:           Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_CL_BIC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);
  
     -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_EUCL_BIC_UCITS
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_EUCL_BIC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  MISS_MAP_CL_SAFEACC_UCITS
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- 27 AGO 2013		Gustavo Binnie      -Included EMBL and Russell funds
 --										-Changed the procedure's name
 -- *****************************************************************  
  
  PROCEDURE MISS_MAP_CL_SAFEACC_UCITS
	(
		p_CURSOR OUT T_CURSOR
	);
  
  
 -- *****************************************************************
 -- Description:     PROCEDURE  MISSING_BUS_CENTER_MAP
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 19 Jul 2013      Gustavo Binnie Created.
 -- *****************************************************************  
  
  PROCEDURE MISSING_BUS_CENTER_MAP
	(
		p_CURSOR OUT T_CURSOR
	);
  
 -- *****************************************************************
 -- Description:     PROCEDURE  BD_CPTY_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 29 Jul 2013      Jun Guan       Created.
 -- *****************************************************************  
  
  PROCEDURE BD_CPTY_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

 -- *****************************************************************
 -- Description:     PROCEDURE  CP_FEES_ON_BOND
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 14 Aug 2013		Oliver South	Created
 -- *****************************************************************  
  
  PROCEDURE CP_FEES_ON_BOND
	(
		p_CURSOR OUT T_CURSOR
	);
	 
 -- *****************************************************************
 -- Description:     PROCEDURE  DEPO_INST_ACCT_ALLOTMENT
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 20 sep 2013		   Jun Guan	      Created
 -- *****************************************************************  
  
  PROCEDURE DEPO_INST_ACCT_ALLOTMENT
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  RESTRICT_CHAR_TIERS
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 25 sep 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE RESTRICT_CHAR_TIERS
	(
		p_CURSOR OUT T_CURSOR
	);
	  
 -- *****************************************************************
 -- Description:     PROCEDURE  ISSUER_CREDIT_CURVE
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 4 Oct 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE ISSUER_CREDIT_CURVE
	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  FOLIO_STRATEGY_MATCH
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 15 Nov 2013		 Oliver South	      Created
 -- *****************************************************************  
  
  PROCEDURE FOLIO_STRATEGY_MATCH

	(
		p_CURSOR OUT T_CURSOR
	);

 -- *****************************************************************
 -- Description:     PROCEDURE  EXT_REF_BLANKS
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 07 Jan 2014		 Oliver South	 Created
 -- *****************************************************************  
  
  PROCEDURE EXT_REF_BLANKS

	(
		p_CURSOR OUT T_CURSOR
	);
  
  
  
   -- *****************************************************************
-- Description:     PROCEDURE  ALLOT_MISSING_SEC_TYPE_AEXEO
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 11 Aug 2014      Gustavo Binnie      Created.
-- ***************************************************************** 

  PROCEDURE ALLOT_MISSING_SEC_TYPE_AEXEO

	(
		p_CURSOR OUT T_CURSOR
	);



  -- *****************************************************************
  -- Description: PROCEDURE BROKER_DEALER_WRONG_BROKER
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 2013-07-19       Jun Guan      Created.
  -- *****************************************************************
	PROCEDURE BROKER_DEALER_WRONG_BROKER
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  INDEX_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30-Jan-2015      Jun Guan            Created.
-- ***************************************************************** 

  PROCEDURE INDEX_CDS_MISSING_WRONG_DATA

	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  SINGLE_CDS_MISSING_WRONG_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16-Feb-2015      Jun Guan            Created.
-- ***************************************************************** 

  PROCEDURE SINGLE_CDS_MISSING_WRONG_DATA

	(
		p_CURSOR OUT T_CURSOR
	);


  -- *****************************************************************
  -- Description: PROCEDURE BROKER_MIFID_NOT_SET
  --
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 20 May 2013   Jun Guan         Created.
  -- 01 JAN 2014   Gustavo Binnie   Moved from EXCEPTION_BO to EDM package.
   -- 10 APR 2015   L Iniesta   Moved back
  -- *****************************************************************
  PROCEDURE BROKER_MIFID_NOT_SET
	(
		p_CURSOR OUT T_CURSOR
	);

  
  -- *****************************************************************
  -- Description: PROCEDURE INCONSIS_BROKER_DEP_OTC
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 03 July 2015     Davi Xavier     Created.
  -- *****************************************************************
  PROCEDURE INCONSIS_BROKER_DEP_OTC
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE FOLIO_NOT_USING_1USD
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************
  PROCEDURE FOLIO_NOT_USING_1USD
	(
		p_CURSOR OUT T_CURSOR
	);

	  -- *****************************************************************
  -- Description: PROCEDURE REPO_TRADES_W_ACCRUED
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 16 Feb 2016      Gustavo Binnie        Created.
  -- *****************************************************************
  PROCEDURE REPO_TRADES_W_ACCRUED
	(
		p_CURSOR OUT T_CURSOR
	);


  

-- *****************************************************************
-- Description:     PROCEDURE UNNECESSARY_SEDOLS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author			Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2015		Matt Kelly      Created.
-- *****************************************************************
  PROCEDURE UNNECESSARY_SEDOLS_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);



-- *****************************************************************
-- Description:     PROCEDURE NEW_MARKETS_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 14 NOV 2013    Matt Kelly      Created.
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- *****************************************************************
  PROCEDURE NEW_MARKETS_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
-- Description:     PROCEDURE EQUITY_EXCEPTION_REPORT
--                  
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 02 MAY 2013    Matt Kelly       Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************
  PROCEDURE EQUITY_EXCEPTION_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  FUT_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan          Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE FUT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  OPT_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE OPT_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
   -- *****************************************************************
 -- Description:     PROCEDURE  FUT_MARKET_MISSING_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 12 Jun 2013    Jun Guan        Created.
 -- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
 --
 -- *****************************************************************  
  
  PROCEDURE FUT_MARKET_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  MARKET_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 11 JAN 2013    Jun Guan        Report Market missing data
-- 01 JAN 2014    Gustavo Binnie  Moved from EXCEPTION_BO to EDM package.
-- *****************************************************************
  PROCEDURE MARKET_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_BAD_DATA
 --                  
 --
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 12 Aug 2013   Jun Guan          Created.
 -- 14 Aug 2013		Oliver South	    Added details checking funding/borrow currency
 -- 01 JAN 2014   Gustavo Binnie    Moved from EXCEPTION_BO to EDM package.
 -- *****************************************************************  
  
  PROCEDURE CFD_BAD_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  

-- *****************************************************************
-- Description:     PROCEDURE  BOND_MISSING_DATA
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 01 JAN 2014    Gustavo Binnie  - Moved from EXCEPTION_BO to EDM package.
--                                - Changed the format to display all missing
--                                  data in a single column.
-- *****************************************************************  
  PROCEDURE BOND_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     PROCEDURE  ADR_MISSING_UNDERLYING_INFO
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 JAN 2014    Gustavo Binnie  Created
-- *****************************************************************  
  PROCEDURE ADR_MISSING_UNDERLYING_INFO
	(
		p_CURSOR OUT T_CURSOR
	); 


-- *****************************************************************
-- Description:     PROCEDURE  CONVERT_BOND_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 JAN 2014      Matt Kelly          - Created.
-- 04 FEB 2014		Gustavo Binnie		- Moved from EXCEPTION_BO to EDM package.
--		                                - Changed the format to display all missing
--			                              data in a single column.
-- ***************************************************************** 
PROCEDURE CONVERT_BOND_EXCEPTION_REPORT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  TBA_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 FEB 2014		Gustavo Binnie		- Created
-- ***************************************************************** 
PROCEDURE TBA_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  TRS_FULLY_FUNDED_MISSING_DATA
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 FEB 2014		Gustavo Binnie		- Created
-- ***************************************************************** 
PROCEDURE TRS_FULLY_FUNDED_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_25HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 
	PROCEDURE NEW_INSTRUMENTS_T_25HRS
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  NEW_INSTRUMENTS_T_13HRS
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 MAR 2014		Oliver South		Moved from PCKG_BTG_EMAILER_OPSREPORTS
-- ***************************************************************** 
PROCEDURE NEW_INSTRUMENTS_T_13HRS
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  RAPPTR_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 08 APR 2014		Matt Kelly			Created
-- ***************************************************************** 
PROCEDURE RAPPTR_EXCEPTION_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  ISSUE_DATE_EXCEPTION_REPORT
--
-- Author:          Matt Kelly
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 24 APR 2014		Matt Kelly			Created
-- ***************************************************************** 
PROCEDURE ISSUE_DATE_EXCEPTION_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );



-- *****************************************************************
-- Description:     PROCEDURE  FUT_OPT_BAD_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 MAR 2014		  Jun Guan		        UnaVista file does not like ISIN for Future/Options
-- ***************************************************************** 
PROCEDURE FUT_OPT_BAD_DATA
  (
    p_CURSOR OUT T_CURSOR
  );



 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_CROSS_CURRENCY
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 11 Jul 2014      Matt Kelly		Created
 -- *****************************************************************  
  
  PROCEDURE CFD_CROSS_CURRENCY
	(
		p_CURSOR OUT T_CURSOR
	);


 -- *****************************************************************
 -- Description:     PROCEDURE  CFD_NON_CROSS_CURRENCY
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 11 Jul 2014      Matt Kelly		Created
 -- *****************************************************************  
  
  PROCEDURE CFD_NON_CROSS_CURRENCY
	(
		p_CURSOR OUT T_CURSOR
	);


  
-- *****************************************************************
 -- Description:     PROCEDURE  CFD_DUPLICATES
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 15 AUG 2014      Matt Kelly			Created
 -- *****************************************************************  
  
  PROCEDURE CFD_DUPLICATES
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
 -- Description:     PROCEDURE  CFD_PRICING
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 02 Sep 2014     Oliver South			Created
 -- *****************************************************************  
  
  PROCEDURE CFD_PRICING
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
 -- Description:     PROCEDURE  COMMOD_AUTO
 --                  
 --
 -- Author:          Matt Kelly
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 22 Sep 2014     Oliver South			Created
 -- *****************************************************************  

  PROCEDURE COMMOD_AUTO
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  FORW_VS_UND
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- ***************************************************************** 
  
  PROCEDURE FORW_VS_UND
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  UND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- ***************************************************************** 
 
  PROCEDURE UND_DEL_DATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  WEEKEND_DEL_DATE
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 OCT 2014      Davi Xavier         Created
-- *****************************************************************

  PROCEDURE WEEKEND_DEL_DATE
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE DUMMY_INSTRUMENTS_NEW_EDIT 
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 OCT 2014      Gustavo Binnie         Created
-- *****************************************************************

  PROCEDURE DUMMY_INSTRUMENTS_NEW_EDIT
	(
		p_CURSOR OUT T_CURSOR
	);


  -- *****************************************************************
-- Description:     NEW_ISSUERS_T_25HRS
--
-- Author:          Ami Talati
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 07 Jan 2015      Ami Talati          Created
-- *****************************************************************

  PROCEDURE NEW_ISSUERS_T_25HRS
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     CROSS_ASSET_BOND_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 09 MAR 2015      JUN GUAN          Created
-- *****************************************************************

  PROCEDURE CROSS_ASSET_BOND_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     ISSUERS_MISSING_DATA
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 27 MAR 2015      JUN GUAN            Created
-- *****************************************************************

  PROCEDURE ISSUERS_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     NEW_ISSUERS_T_1HRS
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 Apr 2015      Jun Guan          Created
-- *****************************************************************

  PROCEDURE NEW_ISSUERS_T_1HRS
	(
		p_CURSOR OUT T_CURSOR
	);
  
-- *****************************************************************
-- Description:     CDS_BOND_MISSING_SPREAD_TYPE
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 28 Apr 2015      Jun Guan          Created
-- *****************************************************************

  PROCEDURE CDS_BOND_MISSING_SPREAD_TYPE
	(
		p_CURSOR OUT T_CURSOR
	);

  
-- *****************************************************************
-- Description:     BOND_FUTURE_MISSING_DATA
--
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 13 OCT 2017      Jeff Yu          Created
-- *****************************************************************

  PROCEDURE BOND_FUTURE_MISSING_DATA
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_NEW_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_NEW_INST
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MIFID2_AMEND_INST
--
-- Author:          Gustavo Binnie
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Gustavo Binnie            Created
-- ***************************************************************** 
PROCEDURE MIFID2_AMEND_INST
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  FUT_BRL_MISSING_LAST_TRADEABLE_DT
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 16 JAN 2018      Andre Bresslau  PMGMRISK-165 Created
-- ***************************************************************** 
PROCEDURE FUT_BRL_MISSING_LAST_TRADE_DT
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  INST_WITH_FIXED_VOL
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 31 JAN 2018      Andre Bresslau  PMGMPMO-258 Created
-- ***************************************************************** 
PROCEDURE INST_WITH_FIXED_VOL
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  INST_MISSING_MARKED_VOL
-- Author:          Andre Bresslau
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 27 FEB 2018      Andre Bresslau  PMGMRISK-185 Created
-- ***************************************************************** 
PROCEDURE INST_MISSING_MARKED_VOL
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  XCCY_SWAP_WRONG_SETUP
-- Author:          Jeff Yu
--      
-- Revision History
-- Date             Author          Reason for Change
-- ----------------------------------------------------------------
-- 01 MAR 2018      Jeff Yu   PMOG-1174     Created
-- ***************************************************************** 
PROCEDURE XCCY_SWAP_WRONG_SETUP
	(
		p_CURSOR OUT T_CURSOR
	);


END PCKG_BTG_EMAILER_EXCEPT_STATIC;