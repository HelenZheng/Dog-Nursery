create or replace
PACKAGE BODY PCKG_BTG_EMAILER_EXCEPT_TRANS AS

  
  -- *****************************************************************
  -- Description: PROCEDURE CASH_DIR_WRONG
	--/* checks that buy trades have us paying cash and vice versa*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE CASH_DIR_WRONG
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: CASH_DIR_WRONG 
 -- *****************************************************************
     OPEN p_CURSOR FOR

     SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, Instrument.libelle                    Name
						, Instrument.reference                  Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
     FROM       histomvts Trades
     INNER JOIN ( 
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH          FOLIO.ident   IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)-- IN (14414,90565)--Primary funds
                CONNECT BY PRIOR    FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =   Trades.OPCVM
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam          = Trades.sicovam
    INNER JOIN      riskusers trader
    ON              trader.ident                = Trades.operateur
    INNER JOIN      business_events
    ON              business_events.id          = Trades.type
    AND             (
                      ( Instrument.type in ('O','A') )
                      OR 
                      ( Instrument.type = 'D'  AND instrument.affectation = 9 )
                    )
    AND            ( 
                     (Trades.quantite < 0 AND Trades.montant >0) 
                      OR 
                     (Trades.quantite > 0 AND Trades.montant <0)
                    )
   AND              business_events.compta = 1 -- position affecting results
   AND              business_events.id    NOT IN (9, 244) --Conv bond exercise and ADR conversion events can have fees
   AND              Trades.backoffice     NOT IN (192,11,13,17,26,27,220,248,252)
   ORDER BY         1,2;

/* checks that buy trades have us paying cash and vice versa*/
 -- *****************************************************************
 -- END  OF: CASH_DIR_WRONG
 -- *****************************************************************
END CASH_DIR_WRONG;

  
  -- *****************************************************************
  -- Description: PROCEDURE TRADES_NOT_IN_STRAT
	--/* Trades booked directly in Strategy folder rather than within the relevant strategy*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADES_NOT_IN_STRAT
  (
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: TRADES_NOT_IN_STRAT
 -- ***************************************************************** 
     OPEN p_CURSOR FOR
     
      SELECT          
						  FUND_BOOK_STRATEGY.FUND_NAME        Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME    Strategy_Name
						, Trades.sicovam                      Sicovam
						, Trades.refcon                       Trade_Id
						, trader.name                         Trader
						, Instrument.libelle                  Instrument_Name
						, Instrument.reference                Instrument_Reference
						, trunc(Trades.DATENEG)               d$Trade_Date
						, trunc(Trades.DATEVAL)               d$Value_Date
						, business_events.name                Busines_Event
      FROM            histomvts                           Trades 
      INNER JOIN      business_events
      ON              business_events.id                  = Trades.type
      INNER JOIN      riskusers trader
      ON              trader.ident                        = Trades.operateur
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                  = Trades.sicovam 
      INNER JOIN ( 
                      SELECT     CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                , FOLIO.ident                                                           AS STRATEGY_ID
                                , FOLIO.name                                                            AS STRATEGY_NAME
                                , level
                      FROM FOLIO
                      WHERE LEVEL     <= 3
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- in (14414,90565)--Primary funds
                      CONNECT BY PRIOR FOLIO.ident      = FOLIO.mgr  
                    ) FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID      = Trades.OPCVM 
      WHERE 
                    FUND_BOOK_STRATEGY.STRATEGY_NAME    != 'Fees'
      AND           FUND_BOOK_STRATEGY.STRATEGY_NAME    NOT LIKE'Cash _ S/R'
      AND           Trades.backoffice                   NOT IN (192,11,13,17,26,27,220,248,252)
      ORDER BY      1,2 ASC;

/* Trades booked directly in Strategy folder rather than within the relevant strategy*/
 -- *****************************************************************
 -- END  OF: TRADES_NOT_IN_STRAT
 -- ****************************************************************
END TRADES_NOT_IN_STRAT;

  -- *****************************************************************
  -- Description: PROCEDURE TRADEFUND_NOT_FOLIOFUND
	-- Report a trade that has the entity field different to the fund folder
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADEFUND_NOT_FOLIOFUND
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- BEGIN  OF: TRADEFUND_NOT_FOLIOFUND
 -- ****************************************************************
    OPEN p_CURSOR FOR
      SELECT      
						Strategy.name                     Strategy_Name
					, StrategyFund.name                   Strategy_Fund
					, TransactionFund.name                Transaction_Fund
					, Transactions.refcon                 Transaction_ID
					, Transactions.dateneg                Trade_Date
					, security.reference                  Ticker
					, security.libelle                    Name
					, trader.name                         Trader
					, business_events.name                BusinesEvent
					, bo_kernel_status.name               Status      
      FROM        histomvts                           Transactions      
      INNER JOIN  riskusers trader
      ON          trader.ident                     = Transactions.operateur      
      INNER JOIN  business_events
      ON          business_events.id               = Transactions.type      
      INNER JOIN  bo_kernel_status
      ON          bo_kernel_status.id              = Transactions.backoffice      
      INNER JOIN  titres security
      ON          security.sicovam                 = Transactions.sicovam      
      INNER JOIN  folio Strategy
      ON          Strategy.ident                   = Transactions.opcvm
      
      INNER JOIN  tiers StrategyFund
      ON          StrategyFund.ident               = Strategy.entite
      
      INNER JOIN  tiers TransactionFund
      ON          TransactionFund.ident            = Transactions.entite
      
   INNER JOIN ( 
            SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                  , FOLIO.ident                                                            AS STRATEGY_ID
                  , FOLIO.name                                                             AS STRATEGY_NAME
                  , level
            FROM  FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)  --IN (14414,90565)--Primary funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
          ) FUND_BOOK_STRATEGY
    ON      FUND_BOOK_STRATEGY.STRATEGY_ID      =   Transactions.OPCVM
    WHERE    TransactionFund.name               != StrategyFund.name
    AND      Transactions.backoffice            NOT IN (192,11,13,17,26,27,220,248,252)
    AND      StrategyFund.ident                 NOT IN (10003582,10012566)--- ignore testfund and EQ EXECUTION BOOK
	ORDER BY 1,2 ASC
  ;

  -- ***************************************************************************
  -- Report a trade that has the entity field different to the fund folder
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
-- *****************************************************************
 -- END  OF: TRADEFUND_NOT_FOLIOFUND
 -- ****************************************************************      
END TRADEFUND_NOT_FOLIOFUND; 


  -- *****************************************************************
  -- Description: PROCEDURE FXOPTION_EXERCISE_WITH_CASH
	-- All FX options that have been expired with cash when the fx trades should have been delivered
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013	Oliver South	Formatted SQL
  --30 Jul 2018	Gustavo Binnie	PMOG-1250 Excluded trades on FX options which delivery type is cash
  -- *****************************************************************
  PROCEDURE FXOPTION_EXERCISE_WITH_CASH
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: FXOPTION_EXERCISE_WITH_CASH
 -- ****************************************************************    
    OPEN p_CURSOR FOR
    SELECT 
					   h1.refcon     		         	TradeID
					  ,h1.sicovam           	  		SICOVAM
					  ,h1.dateneg						d$TradeDate
					  ,h1.dateval						d$ValueDate
					  ,PrimeBroker.NAME  				Account
					  ,Instrument.reference  			Reference
					  ,trader.name						Trader    
    FROM 
                    histomvts         h1    
    INNER JOIN      tiers             PrimeBroker     
    ON              PrimeBroker.IDENT         = h1.DEPOSITAIRE
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam        = h1.sicovam 
    INNER JOIN      riskusers trader
    ON              trader.ident              = h1.operateur
    
    WHERE 
    h1.montant                                !=0
    AND h1.type                               IN (9,360)
    AND Instrument.type                       = 'D'
	AND Instrument.typesj					  != 3 --Delivery type is not cash
    AND Instrument.codesj                     IN (SELECT r.sicovam
                                                   FROM titres r  
                                                  WHERE r.type = 'E')
    AND Instrument.marche                     = 0
    AND h1.dateneg                            > '31-Dec-2010';

  -- ***************************************************************************
  -- All FX options that have been expired with cash when the fx trades should have been delivered
  -- ***************************************************************************
   
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
 -- *****************************************************************
 -- END  OF: FXOPTION_EXERCISE_WITH_CASH
 -- ****************************************************************    
END FXOPTION_EXERCISE_WITH_CASH;




   -- *****************************************************************
  -- Description: PROCEDURE TRADE_DEAD_CCY
	-- GET CANCELED TRADES WHERE PAYMENT CURRENCY IS IN (GERMAN MARK, ITALIAN LIRA, FRENCH FRANC)
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************
  PROCEDURE TRADE_DEAD_CCY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADE_DEAD_CCY 
  -- ***************************************************************************
    OPEN p_CURSOR FOR
    
    SELECT              
                     FUND_BOOK_STRATEGY.BOOK_NAME                   Strategy_Name 
                   , FUND_BOOK_STRATEGY.Fund_NAME                   Fund_Name
                   , Trades.sicovam                                 Sicovam
                   , Trades.refcon                                  Trade_Id
                   , trader.name                                    Trader
                   , Instrument.libelle                             Instrument_Name
                   , Instrument.reference                           Instrument_Reference
                   , trunc(Trades.DATENEG)                          d$Trade_Date
                   , trunc(Trades.DATEVAL)                          d$Value_Date
                   , devise_to_str(Trades.devisepay)                Currency
                   , business_events.name                           BusinesEvent
    FROM                            
                    histomvts                        Trades 
    INNER JOIN      business_events
    ON              business_events.id              = Trades.type
    INNER JOIN      riskusers trader
    ON              trader.ident                    = Trades.operateur
    INNER JOIN      tiers fund
    on              fund.ident                      = Trades.entite
    inner join      titres Instrument
    ON              Instrument.sicovam              = Trades.sicovam 
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
    WHERE          Trades.devisepay                   IN (54805837
                                                        , 55137356
                                                        , 54940230) --GERMAN MARK, ITALIAN LIRA, FRENCH FRANC
    AND            Trades.backoffice                  NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    ORDER BY       1,2 ASC;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF TRADE_DEAD_CCY 
  -- ***************************************************************************
END TRADE_DEAD_CCY;


-- *****************************************************************
-- Description: PROCEDURE BOND_WRONG_DEP
-- 
-- Author:          Jun Guan
--
-- Revision History
-- Date           Author			Reason for Change
----------------------------------------------------------------------------------
-- 05/06/2013		Matt Kelly		Filtered out MBS_EURO instruments, increased 
--                                scope to include primary funds and all strats.
-- 22 Jul 2014		Oliver South	      Excluded CNH traded bonds
-- 08 FEB 2018    Jeff Yu       PMOG-1194  consolidate this with UST book errors report
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- -------------------------------------------------------------------------------

PROCEDURE BOND_WRONG_DEP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF BOND_WRONG_DEP 
  -- ***************************************************************************
     OPEN p_CURSOR FOR

 SELECT         
              FUND_BOOK_STRATEGY.BOOK_NAME           Fund_Strategy
						, FUND_BOOK_STRATEGY.Fund_NAME           Fund
						, histomvts.dateneg                      d$Trade_Date
						, histomvts.refcon                       TradeID
          	, histomvts.sicovam                      Sicovam 
						, security.reference                    
						, pb.name                                Depositary
						, histomvts.quantite                 Quantity
            , affectation.libelle                    Allotment
      FROM          histomvts
      LEFT JOIN     tiers PB
      ON            pb.ident=histomvts.depositaire
      INNER JOIN ( 
                    SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                          ,  CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                          , FOLIO.ident                                                             AS STRATEGY_ID
                          , FOLIO.name                                                              AS STRATEGY_NAME
                          , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident  IN  (14414,90565)--Primary funds and Ucits funds
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM
      INNER JOIN  titres security
      ON          security.sicovam                            = histomvts.sicovam
      AND         security.type                               = 'O' --Bonds
      AND         security.affectation                        IN (25,1251,26) --Gov Bonds and Agency Bonds and Corp Bonds
      INNER JOIN  affectation
      ON          affectation.ident = security.affectation
      INNER JOIN  business_events
      ON          business_events.id                          = histomvts.TYPE
      AND         business_events.compta                      = 1 --position affecting trades only
      LEFT JOIN  sector_instrument_association
      ON          sector_instrument_association.sicovam       = security.sicovam 
      AND sector_instrument_association.TYPE = 5347  --CNTRY_OF_DOMICILE 
      WHERE       histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Not deleted trades
      AND         (security.reference NOT LIKE 'BR%' and sector_instrument_association.sector != 6181) ----Domicile as Brazil
      AND         histomvts.depositaire NOT IN (
                                                SELECT btg_mapping_code.input_code 
                                                FROM btg_mapping_code 
                                                WHERE btg_mapping_code.type_id =47
                                                AND btg_mapping_code.source_id = 9
                                                )  ----UST Depos
      AND         histomvts.dateneg > sysdate - 5 --Recent Trades
      AND         FUND_BOOK_STRATEGY.BOOK_NAME != 'Treasury Offshore' --treasury team book in many depositaries for collateral purposes

UNION

SELECT 
             FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME Fund
            , TRUNC(HISTOMVTS.DATENEG)   d$Trade_Date
            , HISTOMVTS.refcon  TradeID
            , HISTOMVTS.sicovam 
            , TITRES.reference 
            , TIERS.NAME   Depositary
            , HISTOMVTS.QUANTITE Quantity
            , AFFECTATION.libelle  Allotment
       
FROM        HISTOMVTS
INNER JOIN  TIERS 
ON          HISTOMVTS.depositaire = TIERS.ident
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN  AFFECTATION
ON          TITRES.affectation = AFFECTATION.ident
INNER JOIN (
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
            FROM FOLIO
            WHERE LEVEL >= 4 START
            WITH FOLIO.ident IN (14414,90565)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY 
ON          FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
LEFT JOIN   BTG_MAPPING_CODE 
ON          BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND         BTG_MAPPING_CODE.type_id = 40   ----Bond depos
AND         BTG_MAPPING_CODE.source_id = 9
WHERE       TITRES.type IN ('O') --bonds
AND         HISTOMVTS.devisepay != 54742600 --ignore CNH traded bonds since these don't settle in the fixed income accounts
AND         TITRES.affectation NOT IN (13,20,1102,1353,1400,25,26,1251) --exclude Debt Instruments, Cash, TRS(Fully Funded), MBS - European and Bank Loans
AND         HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --deleted trades
AND         BTG_MAPPING_CODE.output_code IS NULL
AND         HISTOMVTS.dateneg > sysdate - 5 --recent trades
ORDER BY    1,2,3,9 ASC;

-- ***************************************************************************
-- END OF BOND_WRONG_DEP 
-- ***************************************************************************
	END BOND_WRONG_DEP; 
  

  -- *****************************************************************
  -- Description: PROCEDURE MBS_EURO_WRONG_DEP
  --
  --
  -- Revision History
  --
  -- Date           Author			Reason for Change
  ----------------------------------------------------------------------------------
  -- 05/06/2013		Matt Kelly		Created.
  --24 Jun 2013		Oliver South	Added Global Depositary
  --25 Jul 2013		Oliver South	Added to only look at trades in past 7 days PMOG-298
  -- -------------------------------------------------------------------------------
  PROCEDURE MBS_EURO_WRONG_DEP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF MBS_EURO_WRONG_DEP 
  -- ***************************************************************************
     OPEN p_CURSOR FOR

SELECT 
	 FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
	,FUND_BOOK_STRATEGY.Fund_NAME Fund
	,trader.NAME Trader
	,Trades.sicovam Sicovam
	,Trades.refcon Trade_Id
	,depositary.NAME Depositary
	,Instrument.libelle Instrument_name
	,Instrument.reference Instrument_reference
	,Allotment.libelle Allotment
	,trunc(Trades.DATENEG) d$Trade_Date
	,Trades.QUANTITE Quantity

FROM histomvts Trades

INNER JOIN riskusers trader 
ON trader.ident = Trades.operateur

INNER JOIN tiers depositary 
ON trades.depositaire = depositary.ident

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN affectation Allotment 
ON instrument.affectation = allotment.ident

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (
			PCKG_BTG.FOLIO_PRIMARY_FUNDS
			,PCKG_BTG.FOLIO_UCITS_FUND
			) -- (14414,90565)--Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.source_id = 9
AND btg_mapping_code.type_id = 41

WHERE Instrument.TYPE IN ('O') --bonds
AND Instrument.affectation = 1353 --MBS European
AND Trades.backoffice NOT IN (
		192
		,11
		,13
		,17
		,26
		,27
		,220
		,248
		,252
		) --deleted trades
AND Trades.dateneg >= trunc(sysdate) - 7 --traded in the last week
AND btg_mapping_code.output_code IS NULL
ORDER BY 1
	,2
	,3
	,11 ASC;

  -- ***************************************************************************
  -- END OF MBS_EURO_WRONG_DEP 
  -- ***************************************************************************
	END MBS_EURO_WRONG_DEP; 


 -- *****************************************************************
  -- Description: PROCEDURE EQ_1_2_STRAT_TRADE
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  --11 March 2014	Oliver South	Re-write
  -- ----------------------------------------------------------------  
  PROCEDURE EQ_1_2_STRAT_TRADE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQ_1_2_STRAT_TRADE 
  -- ***************************************************************************  
     OPEN p_CURSOR FOR

      SELECT
				FUND_BOOK_STRATEGY.BOOK_NAME              Fund_Strategy
			  , FUND_BOOK_STRATEGY.Fund_NAME              Fund
			  , HISTOMVTS.refcon                          Trade_ID
			  , FUND_BOOK_STRATEGY.STRATEGY_NAME          Folio
			  , HISTOMVTS.sicovam				          Sicovam
			  , TITRES.reference                          Instrument_Reference
			  , TRUNC(HISTOMVTS.DATENEG)                  d$Trade_Date
			  , TRUNC(HISTOMVTS.DATEVAL)                  d$Value_Date

		FROM            HISTOMVTS           
		INNER JOIN      TITRES
		ON              TITRES.sicovam = HISTOMVTS.sicovam         
		INNER JOIN (
				SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
				  ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
				  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
				  ,FOLIO.ident AS STRATEGY_ID
				  ,FOLIO.NAME AS STRATEGY_NAME
				  ,LEVEL
				FROM FOLIO
				WHERE LEVEL IN (4,5) START --Booked in top 2 strategy levels
				WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
				  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
				) FUND_BOOK_STRATEGY 
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm    
		INNER JOIN BTG_MAPPING_CODE
		ON BTG_MAPPING_CODE.INPUT_CODE = FUND_BOOK_STRATEGY.BOOK_ID
		AND BTG_MAPPING_CODE.TYPE_ID = 34 --EQ strategies
		WHERE HISTOMVTS.backoffice not in (11,13,17,26,27,192,220,248,252) --Ignore cancelled trades
		AND FUND_BOOK_STRATEGY.BOOK_NAME NOT IN ('EQ US IPO') --Exclude EQ US IPO since no complaints from Brazil teams to date for Boletas bookings
		AND FUND_BOOK_STRATEGY.STRATEGY_NAME != 'Financing' --trades in financing folio is OK
		ORDER BY 1,2,7;

  -- ***************************************************************************
  -- END OF EQ_1_2_STRAT_TRADE 
  -- ***************************************************************************  
	END EQ_1_2_STRAT_TRADE; 
  
   -- *****************************************************************
  -- Description: PROCEDURE FOCUS_ELECTRONIC_TRADES
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date                 Author             Reason for Change
  --18 Feb 2013     Oliver South		Formatting SQL
  --28 Mar 2017    Jeff Yu               PMOG-1090
  -- ----------------------------------------------------------------  
  PROCEDURE FOCUS_ELECTRONIC_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF FOCUS_ELECTRONIC_TRADES 
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

    SELECT
                          trades.refcon                    tradeID
                         ,fund.name                        Fund
                         ,fund_strategy.name               Fund_Strategy
                         ,strategy.name                    Strategy
                         ,PrimeBroker.name                 Depositary
                         ,trader.name                      Trader
                         ,Trades.sicovam				   Sicovam
                         ,Instrument.reference             REPO_Reference
                         ,trunc(Trades.DATENEG)            TradeDate
                         ,trunc(Trades.DATEVAL)            ValueDate

      FROM            histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam       
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE      
      INNER JOIN  (
                      SELECT       folio.ident
                                  ,folio.name
                                  ,nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident)    parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_FOCUS_FUND_RATE -- 62880 -- Focus
        CONNECT BY  mgr         = prior ident
      ) strategy
      ON          strategy.ident            = Trades.opcvm
      INNER JOIN      folio fund_strategy
      ON              fund_strategy.ident   = strategy.parent_ident    
      INNER JOIN      tiers fund
      ON              fund.ident            = Trades.entite
      INNER JOIN      riskusers trader
      ON              trader.ident          = Trades.operateur      
      WHERE           trades.creation       = 2
	  AND           trunc(Trades.DATENEG) >= BTG_BUSINESS_DATE(trunc(sysdate),-3)   ---Only report trades booked within past 3 business days
      AND            ( 
                          trades.contrepartie IN (10004042,10004782) 
                          OR trades.courtier  IN (10004042,10004782)
                     )    
	  AND            TRADES.backoffice not in (11,13,17,26,27,192,220,248,252) ;
	
 -- ***************************************************************************
  -- END OF FOCUS_ELECTRONIC_TRADES 
  -- ***************************************************************************   
	END FOCUS_ELECTRONIC_TRADES; 
  
  
  

  -- *****************************************************************
  -- Description: PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- ---------------------------------------------------------------- 

  PROCEDURE WRONG_TRADER_UBS_ETD_9ARF2B
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- ***************************************************************************
  -- BEGIN OF WRONG_TRADER_UBS_ETD_9ARF2B 
  -- ***************************************************************************   
  OPEN p_CURSOR FOR

 SELECT 
	 FUND_BOOK_STRATEGY.BOOK_NAME         Strategy_Name
	,FUND_BOOK_STRATEGY.Fund_NAME         Fund_Name
	,Trades.sicovam                       Sicovam
	,Trades.refcon                        Trade_ID
	,Instrument.reference                 Ticker
	,trunc(Trades.DATENEG)                d$Trade_Date
	,trunc(Trades.DATEVAL)                d$Value_Date
	,DEVISE_TO_STR(Trades.devisepay)      Currency
	,PrimeBroker.NAME                     Prime_Broker
FROM histomvts Trades

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE

INNER JOIN (
		SELECT FOLIO.IDENT
		FROM FOLIO START WITH FOLIO.IDENT IN 
                    (
                    SELECT EQFOLIO.INPUT_CODE
                    FROM btg_mapping_code EQFOLIO
                    WHERE EQFOLIO.TYPE_ID = '34' --London EQ strategies
                    ) 
			CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
          ) strategy
ON strategy.IDENT = trades.OPCVM

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 42
AND btg_mapping_code.source_id = 9

WHERE Trades.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND (Instrument.TYPE = 'F'
		OR 
      (
      Instrument.TYPE = 'D'
      AND 
      Instrument.affectation = 10
      )
		) --futures or listed options
AND trades.dateneg >= sysdate - 5 --recent trades
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.ident NOT IN 
		(
		SELECT int_dep.input_code
    FROM btg_mapping_code int_dep
		WHERE int_dep.type_id = 35 
		)--exclude internal trades depositaries
ORDER BY 1,2 ASC;
 
  -- ***************************************************************************
  -- END OF WRONG_TRADER_UBS_ETD_9ARF2B 
  -- ***************************************************************************      
	END WRONG_TRADER_UBS_ETD_9ARF2B; 
  
  -- *****************************************************************
  -- Description: PROCEDURE EQTEAM_WRONG_UBS_ETD
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- ----------------------------------------------------------------

   PROCEDURE EQTEAM_WRONG_UBS_ETD
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQTEAM_WRONG_UBS_ETD 
  -- ***************************************************************************       
     OPEN p_CURSOR FOR
SELECT FUND_BOOK_STRATEGY.BOOK_NAME Strategy
	,FUND_BOOK_STRATEGY.Fund_NAME Fund
	,Trades.sicovam Sicovam
	,Trades.refcon Trade_ID
	,Instrument.reference Ticker
	,trunc(Trades.DATENEG) d$Trade_Date
	,trunc(Trades.DATEVAL) d$Value_Date
	,DEVISE_TO_STR(Trades.devisepay) Currency
	,PrimeBroker.NAME PrimeBroker
	
FROM histomvts Trades

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (
			PCKG_BTG.FOLIO_PRIMARY_FUNDS
			,PCKG_BTG.FOLIO_UCITS_FUND
			) --Primary funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm

LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 43
AND btg_mapping_code.source_id = 9

WHERE Trades.BACKOFFICE NOT IN (
		11
		,13
		,17
		,26
		,27
		,192
		,220
		,248
		,252
		) --cancelled trades
AND (
		(
			Instrument.TYPE = 'F'
			AND Instrument.affectation != 33 --check all futures, but exclude FRA
			)
		OR (
			Instrument.TYPE = 'D'
			AND Instrument.affectation = 10 --checks all listed options
			)
		)
AND trades.dateneg > btg_business_date(sysdate, - 5) --recent trades
AND NVL(Instrument.marche,0) NOT IN (781) -- Exclude BMF trades (PMOG-668)
AND FUND_BOOK_STRATEGY.BOOK_NAME IN (
		'EM (EMEA) Rates'
		,'EM Credit'
		,'Europe Rates and FX'
		,'Global Credit'
		,'Systematic'
		)
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.NAME NOT LIKE '%INTERNAL%'
ORDER BY 3 ASC;
  
  -- ***************************************************************************
  -- END OF EQTEAM_WRONG_UBS_ETD 
  -- ***************************************************************************       
	END EQTEAM_WRONG_UBS_ETD; 
 
  

  
-- *****************************************************************
-- Description: PROCEDURE UST_NON_1000
--  New query on the Trade Booking Errors report that brings to our attention any US Treasury bond trades that have
--      a traded nominal less than a multiple of 1,000.
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
--18 Feb 2013 Oliver South	Changed column order PROJ-26
--03 Jul 2014 Oliver South	clean up and removed coupons PMWM-7
------------------------------------------------------------------  
  PROCEDURE UST_NON_1000
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN		
-- ***************************************************************************
-- BEGIN OF UST_NON_1000 
-- *************************************************************************** 	
		OPEN p_CURSOR FOR

      SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME                  Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME                  Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME              Strategy
						, TITRES.reference                              ISIN
						, HISTOMVTS.refcon                              n$TradeID
						, RISKUSERS.name                                Trader
						, HISTOMVTS.dateneg                             d$Trade_Date
						, HISTOMVTS.dateval                             d$Value_Date
						, HISTOMVTS.quantite*titres.nominal             n$Nominal
						, HISTOMVTS.quantite                            n$Quantity
						, HISTOMVTS.sicovam                             n$Sicovam
            , BUSINESS_EVENTS.name                          Business_Event
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
                    ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =    HISTOMVTS.OPCVM    
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position affecting trades only
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur        
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam    
INNER JOIN  SECTOR_INSTRUMENT_ASSOCIATION
ON          SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam 
WHERE       (
            TITRES.affectation IN ('25','1251') --Gov Bonds and Agency Bonds
            AND         
            SECTOR_INSTRUMENT_ASSOCIATION.sector = 6290   --CNTRY_OF_DOMICILE = US
            )
AND SUBSTR(HISTOMVTS.quantite*TITRES.nominal, -3) <> '000' --nominal not in lots of 1000
AND HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) --exclude cancelled trades
AND HISTOMVTS.dateval > sysdate - 7  --recent trades
;

-- ***************************************************************************
-- END OF UST_NON_1000 
-- *************************************************************************** 	

  END UST_NON_1000;
  
 -- *****************************************************************
 -- Description: PROCEDURE NY_ETD_WRONG_ACCOUNT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- ----------------------------------------------------------------   
  PROCEDURE NY_ETD_WRONG_ACCOUNT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF NY_ETD_WRONG_ACCOUNT 
  -- *************************************************************************** 				
		OPEN p_CURSOR FOR
SELECT 
    fund_book_strategy.BOOK_NAME      Strategy_Name
	, fund_book_strategy.Fund_NAME      Fund_Name
	, Trades.sicovam                    Sicovam
	, Trades.refcon                     Trade_ID
	, Instrument.reference              Ticker
	, trunc(Trades.DATENEG)             d$Trade_Date
	, trunc(Trades.DATEVAL)             d$Value_Date
	, DEVISE_TO_STR(Trades.devisepay)   Currency
	, PrimeBroker.NAME                  PrimeBroker
FROM histomvts Trades
INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam
INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE
INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL > = 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
LEFT JOIN btg_mapping_code 
ON btg_mapping_code.input_code = trades.depositaire
AND btg_mapping_code.type_id = 44
AND btg_mapping_code.source_id = 9
WHERE Trades.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND FUND_BOOK_STRATEGY.BOOK_ID IN 
    (
		SELECT nyfolio.input_code
    FROM btg_mapping_code nyfolio
		WHERE nyfolio.output_code = 'NY'
    AND nyfolio.type_id = 33 
		) --NY strategies
AND (
        (
          Instrument.TYPE = 'F'
          AND 
         (Instrument.affectation != 33 or Instrument.affectation is null)
        )
		OR 
        (
          Instrument.TYPE = 'D'
          AND 
          Instrument.affectation = 10
        )
		) -- futures and listed options
AND trades.dateneg > sysdate - 5 --recent trades
AND btg_mapping_code.output_code IS NULL
AND PrimeBroker.ident NOT IN 
		(
		SELECT int_dep.input_code
    FROM btg_mapping_code int_dep
		WHERE int_dep.type_id = 35 
		)--exclude internal trades depositaries
ORDER BY 1,2 ASC;


  -- ***************************************************************************
  -- END OF NY_ETD_WRONG_ACCOUNT 
  -- *************************************************************************** 	
	END NY_ETD_WRONG_ACCOUNT;
  
  


 -- *****************************************************************
 -- Description: PROCEDURE ENTITY_WRONG_ACCT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --	10 Jan 2014		Oliver South	Added QSF
 -- 20 JUL 2016		Gustavo Binnie  PMOG-1019
 -- 29 SEP 2017     Jeff Yu          PMGMPMO-234 - Add GDO fund
 -- 20 Jun 2018     AppSupport      APPSUPP-4825 - add date filter 
 -- ----------------------------------------------------------------     
 PROCEDURE ENTITY_WRONG_ACCT
                (
                                p_CURSOR OUT T_CURSOR
                )
  AS
                BEGIN
  -- ***************************************************************************
  -- BEGIN OF ENTITY_WRONG_ACCT 
  -- ***************************************************************************                                  
                                OPEN p_CURSOR FOR

      SELECT          
                      Trades.sicovam          Sicovam,
                      Trades.refcon           Trade_ID,
                      trader.name             Trader,
                      Instrument.libelle      Name,
                      Instrument.reference    Ticker,
                      trunc(Trades.DATENEG)   d$Trade_Date,
                      trunc(Trades.DATEVAL)   d$Value_Date,
                      Trades.QUANTITE         n$Quantity,
                      PrimeBroker.NAME        PrimeBroker
      FROM            histomvts Trades 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam   = Trades.sicovam 
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT    = Trades.DEPOSITAIRE
      INNER JOIN      riskusers trader
      ON              trader.ident         = Trades.operateur
      WHERE           (             
                                       (Trades.entite = (10003506) --ARF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10007442) 
                                      and PrimeBroker.IDENT<>10021570)--PACTUAL-2689-ARF2
                      OR              (Trades.entite = (10003503) --ARF2
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10006862))
                      OR              (Trades.entite = (10003512) --GEMM
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr in (10006703,10025790)))
                      OR              (Trades.entite = (10010625) --GEO
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010626))
                      OR              (Trades.entite = (10010267) --FOCUS
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010269))
                      OR              (Trades.entite = (10010365) --Global
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010388))
                      OR              (Trades.entite = (10006762) --DMF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10007102))
                      OR              (Trades.entite = (10010602) --EMBL
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10010592))
                      OR              (Trades.entite = (10005323) --Leonis
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10008782))
                                                                                  OR              (Trades.entite = (10019917) --QSF
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10019916))
                      OR              (Trades.entite = (10026005) --GDO
                                      AND trades.depositaire NOT IN (SELECT ident FROM tiers WHERE mgr=10026010))
                        )

      AND             trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252) -- cancelled trades
                  and instrument.affectation ! = 20
                  and trades.dateval > = sysdate -30
      ORDER BY        6 ASC;

  -- ***************************************************************************
  -- END OF ENTITY_WRONG_ACCT 
  -- ***************************************************************************                  
                END ENTITY_WRONG_ACCT;

 
 -- *****************************************************************
 -- Description: PROCEDURE TRADE_MISS_CP_DEP_BKR
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 -- ----------------------------------------------------------------     
  PROCEDURE TRADE_MISS_CP_DEP_BKR
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADE_MISS_CP_DEP_BKR 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

    SELECT
                    FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name,
                    FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name, 
                    Trades.sicovam                Sicovam,
                    Trades.refcon                 Trade_Id,
                    trader.name                   Trader,
                    Instrument.libelle            Name,
                    Instrument.reference          Ticker,
                    trunc(Trades.DATENEG)         d$Trade_Date
    FROM            histomvts Trades 
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    INNER JOIN      devisev2 Currency
    ON              Currency.code= Trades.devisepay
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam       
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    WHERE
            (     (Trades.courtier is null) 
               OR (Trades.contrepartie is null) 
               OR (Trades.depositaire is null)
            )
    AND     Trades.dateneg                          > '31-Dec-2010'
    AND     Instrument.TYPE != 'L' --repos
    AND     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
	ORDER BY 1,2;

  -- ***************************************************************************
  -- END OF TRADE_MISS_CP_DEP_BKR 
  -- *************************************************************************** 		
	END TRADE_MISS_CP_DEP_BKR;


-- *****************************************************************
-- Description:PROCEDURE TRADES_EQ_WRONG_ACCT
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
--    2012      Jun Guan			Created.
-- 30-Apr-2013  Gustavo Binnie    Included two depositaries
-- 22-Jul-2014  Oliver South	  Added a check for CNH settled bond trades
-- *****************************************************************  
PROCEDURE TRADES_EQ_WRONG_ACCT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_EQ_WRONG_ACCT 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT 
             FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME Fund
            , RISKUSERS.NAME Trader
            , HISTOMVTS.sicovam Sicovam
            , HISTOMVTS.refcon Trade_Id
            , TIERS.NAME Depositary
            , TITRES.libelle Instrument_name
            , TITRES.reference Instrument_reference
            , AFFECTATION.libelle Allotment
            , TRUNC(HISTOMVTS.DATENEG) d$Trade_Date
            , HISTOMVTS.QUANTITE Quantity
FROM        HISTOMVTS
INNER JOIN  RISKUSERS 
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  TIERS 
ON          HISTOMVTS.depositaire = TIERS.ident
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN  AFFECTATION
ON          TITRES.affectation = AFFECTATION.ident
INNER JOIN (
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
            FROM FOLIO
            WHERE LEVEL >= 4 START
            WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
            --WITH FOLIO.ident IN (14414)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY 
ON          FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM    
LEFT JOIN   BTG_MAPPING_CODE
ON          BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND         BTG_MAPPING_CODE.type_id=45
AND         BTG_MAPPING_CODE.source_id=9
WHERE       HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
AND         (
                (
                TITRES.TYPE = 'A' --share
                AND         
                HISTOMVTS.devisepay != 54678092 --exclude BRL trades
				AND
                NVL(TITRES.AFFECTATION,0) != 1506 --exclude allotment Shares - Unlisted
                )
            OR
                (
                TITRES.TYPE = 'O' --bond
                AND         
                HISTOMVTS.devisepay = 54742600 --Include CNH traded bonds
                )
            )
AND         HISTOMVTS.dateneg > trunc(sysdate-14) --recent trades
AND         BTG_MAPPING_CODE.output_code is null
ORDER BY    3 ASC;
  -- ***************************************************************************
  -- END OF TRADES_EQ_WRONG_ACCT 
  -- ***************************************************************************		
END TRADES_EQ_WRONG_ACCT;


   -- *****************************************************************
  -- Description  PROCEDURE TRADE_FX_RATE_WRONG
  --
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 28 Feb 2013    Oliver South    FX = 0 caused EOD failure
  -- *****************************************************************
  PROCEDURE TRADE_FX_RATE_WRONG
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADE_FX_RATE_WRONG 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event        
    FROM          histomvts Trades    
    INNER JOIN    riskusers 
    ON            Trades.operateur     = riskusers.ident    
    INNER JOIN    titres security 
    ON            security.sicovam     = trades.sicovam        
    INNER JOIN    tiers CP
    ON            CP.IDENT             = Trades.depositaire    
    INNER JOIN    business_events 
    ON            business_events.id   = Trades.type    
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  Trades.OPCVM    
    WHERE Trades.BACKOFFICE                   NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND business_events.id NOT IN(15) -- NOT 'Instr. modif' Business Event
    AND (
        ( security.type = 'G'
          AND   security.devisectt != trades.devisepay
          AND   Trades.tauxchange=1
          AND   business_events.compta = 1
        ) --CFD position affecting trades that have FX rate =1 where sett ccy <> inst ccy
        OR
        ( security.devisectt != trades.devisepay
          AND   Trades.tauxchange=0
        ) --All trades where sett ccy <> inst ccy and fx = 0
        OR
        ( trades.typecours = 5
          AND   Trades.tauxchange=0
        ) --Trades where the price type is in underlying currency and the FX = 0
        )
	 and  Trades.DATENEG                       >= sysdate-365
    ORDER BY 1,2;


	-- ***************************************************************************
  -- END OF TRADE_FX_RATE_WRONG 
  -- ***************************************************************************	
 END TRADE_FX_RATE_WRONG;
 


-- *****************************************************************
-- Description:     PROCEDURE  US_RATES_TRADES_BAD_ALLOTMENT
--
-- Author:          Ami Talati
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013      Ami Talati           Created.
-- 04 NOV 2014      Gustavo Binnie       Included 'US Energy' (PMOG-615)
-- 04 NOV 2016    Jeff Yu        Included 'Global Rates' strategy (PMOG-1060)
-- ***************************************************************** 
  PROCEDURE US_RATES_TRADES_BAD_ALLOTMENT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: US_RATES_TRADES_BAD_ALLOTMENT
  -- *****************************************************************   
          OPEN p_CURSOR FOR
	SELECT
                      FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
                    , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
                    , Trades.sicovam                Sicovam
                    , Trades.refcon                 Trade_Id
                    , trader.name                   Trader
                    , Instrument.libelle            Name
                    , Instrument.reference          Ticker
                    , trunc(Trades.DATENEG)         d$Trade_Date
                    , Allotment.libelle             Allotment
                    , domicile.code       Country_Domicile
    FROM            histomvts Trades 
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    INNER JOIN      devisev2 Currency
    ON              Currency.code= Trades.devisepay
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam   
    INNER JOIN      affectation Allotment
    ON              Allotment.ident= Instrument.affectation   
	
	LEFT JOIN sector_instrument_association sia2
		ON Instrument.sicovam = sia2.sicovam
			AND sia2.sector IN (
					SELECT id
					FROM sectors
					WHERE parent = 5347
				)
	LEFT JOIN sectors domicile
		ON sia2.sector = domicile.id
		
	INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    WHERE   Trades.dateneg                          > trunc(sysdate-5)
    AND     Instrument.TYPE = 'O' --bonds
    AND     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
    AND     (FUND_BOOK_STRATEGY.BOOK_NAME = 'US Rates' or FUND_BOOK_STRATEGY.BOOK_NAME = 'US Energy'  or FUND_BOOK_STRATEGY.BOOK_NAME='Global Rates')
    AND     UPPER(domicile.code) = 'US'
    AND     Allotment.libelle = 'Corp Bonds'
	ORDER BY 1,2;
       
          
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: US_RATES_TRADES_BAD_ALLOTMENT
  -- *****************************************************************   
	END US_RATES_TRADES_BAD_ALLOTMENT; 





  PROCEDURE EXEC_FEES_NOT_CHILD_FEES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EXEC_FEES_NOT_CHILD_FEES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
				SELECT 
							  FUND_BOOK_STRATEGY.BOOK_NAME                    Execution_Folio
							, TA_BLOCK_TO_GENERATED.BLOCK_ID                  Block_ID
							, SUM(CHILD_TRADE.MONTANT)                        n$Sum_Of_Child_Cash
							, BLOCK_TRADE.MONTANT                             n$Block_Level_Cash
							, SUM(CHILD_TRADE.MONTANT)-BLOCK_TRADE.MONTANT    n$Cash_Difference
							, SECURITY.REFERENCE                              Instrument_Reference
							, SECURITY.SICOVAM                                Sicovam
							, CHILD_TRADE.DATENEG                             d$Trade_Date
							, BUSINESS_EVENTS.NAME                            Business_Event
				FROM
				TA_BLOCK_TO_GENERATED
							INNER JOIN  HISTOMVTS CHILD_TRADE
							ON          CHILD_TRADE.REFCON = TA_BLOCK_TO_GENERATED.GENERATED_ID
							AND         CHILD_TRADE.DATENEG > TRUNC(SYSDATE-50) --recent trades
							AND         CHILD_TRADE.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --ignore deleted trades
							INNER JOIN  HISTOMVTS BLOCK_TRADE
							ON          BLOCK_TRADE.REFCON = TA_BLOCK_TO_GENERATED.BLOCK_ID 
							INNER JOIN ( 
												  SELECT       CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
															  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)    AS BOOK_ID
															  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)     AS BOOK_NAME
															  , FOLIO.ident                                                            AS STRATEGY_ID
															  , FOLIO.name                                                             AS STRATEGY_NAME
															  , level
												  FROM FOLIO
												  WHERE LEVEL                       >= 4
												  START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_EXEC_BOOK)  --Execution book
												  CONNECT BY PRIOR  FOLIO.ident     = FOLIO.mgr  
											  )  FUND_BOOK_STRATEGY
								ON               FUND_BOOK_STRATEGY.STRATEGY_ID     = BLOCK_TRADE.OPCVM
							INNER JOIN  TITRES SECURITY
							ON          SECURITY.SICOVAM = CHILD_TRADE.SICOVAM
							AND         SECURITY.TYPE = 'S' --swaps only
							INNER JOIN  BUSINESS_EVENTS 
							ON          BUSINESS_EVENTS.ID = CHILD_TRADE.TYPE
				HAVING      ABS(SUM(CHILD_TRADE.MONTANT)-BLOCK_TRADE.MONTANT) > 1 --difference more than 1 unit of trade currency
				GROUP BY    FUND_BOOK_STRATEGY.BOOK_NAME, TA_BLOCK_TO_GENERATED.BLOCK_ID, BLOCK_TRADE.MONTANT, SECURITY.REFERENCE, SECURITY.SICOVAM, CHILD_TRADE.DATENEG, BUSINESS_EVENTS.NAME
				ORDER BY 8
				;
       
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: EXEC_FEES_NOT_CHILD_FEES
  -- *****************************************************************   
	END EXEC_FEES_NOT_CHILD_FEES; 

 -- *****************************************************************
 -- Description:     PROCEDURE  CPP_RESTRICTED_LIST_TRADES
 --                  
 --
 -- Author:         Gustavo Binnie
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 31 Jan 2014     Gustavo Binnie       Created.
 -- 28 May 2014		Gustavo Binnie		 COM-107 - Changes to reflect where the restricted ID_BB_COMPAANY are stored (new table BTG_RESTRICTED_LIST_IDS) 
 -- *****************************************************************  

  PROCEDURE CPP_RESTRICTED_LIST_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: CPP_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =0

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;


	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	-- *****************************************************************
  -- END OF: CPP_RESTRICTED_LIST_TRADES
  -- *****************************************************************   
	END CPP_RESTRICTED_LIST_TRADES;


-- *****************************************************************
-- Description:     PROCEDURE  TRADE_DIR_DIFF_BLOCK_DIR
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 feb 2014      Oliver South            Created.
-- ***************************************************************** 
PROCEDURE TRADE_DIR_DIFF_BLOCK_DIR (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: TRADE_DIR_DIFF_BLOCK_DIR
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
        FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
      , FUND_BOOK_STRATEGY.Fund_NAME            Fund
      , HISTOMVTS.DATENEG                       d$Trade_date
      , TA_BLOCK_TO_GENERATED.BLOCK_ID          Block_ID
      , HISTOMVTS.QUANTITE                      n$Block_Qty
      , TA_BLOCK_TO_GENERATED.GENERATED_ID      Child_ID
      , TA_BLOCK_TO_GENERATED.QUANTITY          n$Child_Qty
      , TITRES.SICOVAM                          Sicovam
      , TITRES.REFERENCE                        Instrument_Reference
      , TITRES.LIBELLE                          Instrument_Name
      , RISKUSERS.NAME                          Trader_Name
FROM TA_BLOCK_TO_GENERATED 
INNER JOIN HISTOMVTS
ON HISTOMVTS.REFCON = TA_BLOCK_TO_GENERATED.BLOCK_ID
INNER JOIN TITRES
ON TITRES.SICOVAM = HISTOMVTS.SICOVAM
INNER JOIN RISKUSERS
ON RISKUSERS.IDENT = HISTOMVTS.OPERATEUR
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  TA_BLOCK_TO_GENERATED.FOLIO
WHERE SIGN(TA_BLOCK_TO_GENERATED.QUANTITY) != SIGN(HISTOMVTS.QUANTITE) --trade direction is different from the block trade direction
AND HISTOMVTS.DATENEG > sysdate-10 --Look back last 10 days
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

TRADE_DIR_DIFF_BLOCK_DIR;

-- *****************************************************************
-- END OF: TRADE_DIR_DIFF_BLOCK_DIR
-- *****************************************************************   


-- *****************************************************************
-- Description:     PROCEDURE  TRADE_EQ_MISS_BR_CODE
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 Jul 2014      Oliver South            Created.
-- 08 Aug 2017    Jeff Yu         Modified (PMOG-1134)
-- ***************************************************************** 

PROCEDURE TRADE_EQ_MISS_BR_CODE (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: TRADE_EQ_MISS_BR_CODE
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT              
                    DISTINCT(TIERS.name)                                 Broker
    FROM            HISTOMVTS
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1
    AND             BUSINESS_EVENTS.id NOT IN (161)
    INNER JOIN      RISKUSERS
    ON              RISKUSERS.ident = HISTOMVTS.operateur
    INNER JOIN      TIERSPROPERTIES UBS
    ON              UBS.code = HISTOMVTS.courtier
    AND             UBS.name = 'UBS CODE'
    INNER JOIN      TIERSPROPERTIES MS
    ON              MS.code = HISTOMVTS.courtier
    AND             MS.name = 'MS PB CODE'
    INNER JOIN      TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam 
    AND             TITRES.type = 'A'
    INNER JOIN      TIERS
    ON              TIERS.ident = histomvts.courtier
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID =  HISTOMVTS.OPCVM
    WHERE          HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    AND            ( UBS.value is null OR MS.value is null )
    AND            HISTOMVTS.dateneg > TRUNC(Sysdate-7) --trades done in the past week
    AND            DEVISE_TO_STR(HISTOMVTS.devisepay) != 'BRL' --exclude Brazil trades as they settle in 2689 account
    AND            HISTOMVTS.courtier NOT IN (10010875, 10012815, 10010876) --exclude internal trades
    ORDER BY       1;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END TRADE_EQ_MISS_BR_CODE;

-- *****************************************************************
-- END OF: TRADE_EQ_MISS_BR_CODE
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  US_RATES_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 09 Sep 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE US_RATES_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: US_RATES_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =12

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;  
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       

END US_RATES_RESTRICTED_LIST;

-- *****************************************************************
-- END OF: US_RATES_RESTRICTED_LIST
-- *****************************************************************         
-- *****************************************************************
-- Description:     PROCEDURE  NDF_BACK_TO_FRONT
-- Author:          Jun Guan
-- /* Reports NDF London Strategy trades booked the wrong way round */
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
PROCEDURE NDF_BACK_TO_FRONT(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: NDF_BACK_TO_FRONT
	-- *****************************************************************  
	OPEN p_CURSOR
	FOR

	SELECT FUND_BOOK_STRATEGY.BOOK_NAME Strategy
		,FUND_BOOK_STRATEGY.Fund_NAME Fund
		,Trades.sicovam Sicovam
		,Trades.refcon TradeID
		,Instrument.reference Ticker
		,trunc(Trades.DATENEG) d$TradeDate
		,trunc(Trades.DATEVAL) d$ValueDate
		,Currency.libelle Currency
		,BTG_FN_AUDIT_INST_USER(Instrument.sicovam) Instr_last_amended_by
	FROM histomvts Trades
	INNER JOIN business_events
		ON business_events.id = Trades.type
	INNER JOIN devisev2 Currency
		ON Currency.code = Trades.devisepay
	INNER JOIN titres Instrument
		ON Instrument.sicovam = Trades.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (
				PCKG_BTG.FOLIO_PRIMARY_FUNDS
				,PCKG_BTG.FOLIO_UCITS_FUND
				) --(14414,90565)--Primary funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	WHERE Trades.BACKOFFICE NOT IN (
			11
			,13
			,17
			,26
			,27
			,192
			,220
			,248
			,252
			) --Deleted/cancelled
		AND Instrument.TYPE = 'K' --NDF
		AND currency.code IN (
			54612563
			,54678092
			,54742096
			,54742617
			,54742864
			,54871888
			,55135826
			,55133266
			,55267927
			,55269972
			,55400786
			,55592270
			,55593040
			,55727426
			,55859012
			,55918920
			,55987780
			)
	ORDER BY 3 ASC;
		/* Reports NDF booked the wrong way round */
		-- *****************************************************************
		-- END OF: NDF_BACK_TO_FRONT
		-- ***************************************************************** 
END

NDF_BACK_TO_FRONT;


 -- *****************************************************************
 -- Description: PROCEDURE ABS_IN_NON_USMORT
 -- Author:          Davi Xavier
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- 24-Nov-2014      Davi Xavier	Creation
 -- 23-MAR-2016		 Gustavo Binnie PMOG-934
 -- 10-AUG-2018		 Gustavo Binnie APPSUPP-5045 (Added 'Consumer Loans' strat)
  -- ----------------------------------------------------------------   
  PROCEDURE ABS_IN_NON_USMORT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF ABS_IN_NON_USMORT 
  -- *************************************************************************** 				
		OPEN p_CURSOR FOR
    
     select 
   fund_book_strategy.book_name                       top_level_strategy
  ,trades.refcon                                      trade_id
  ,fund_book_strategy.fund_name                       fund_name
  ,titres.libelle                                     instrument_name 
  ,bo_kernel_status.name                              status
  ,titres.reference                                   instrument_reference
  ,riskusers.name                                     trader_name
  ,business_events.name                               business_event 
  ,trades.dateneg                                     trade_date
  ,trades.dateval                                     value_date
  ,nvl(ROUND(Trades.QUANTITE*titres.nominal, 8),0)    nominal
  ,trades.cours                                       gross_price  
  ,trades.montant                                     net_amount
  ,contreparties.libelle                              counterparty_name
  ,b.libelle                                          broker_name
  ,depositaires.libelle                               depositary_name
  ,trades.sicovam                                     sicovam
  ,affectation.libelle                                allotment 
 
FROM histomvts trades

INNER JOIN titres
on titres.sicovam = trades.sicovam

inner join  riskusers
on riskusers.ident = trades.operateur

inner join affectation 
on affectation.ident = titres.affectation

inner join  business_events
on business_events.id = trades.type

inner join bo_kernel_status
on bo_kernel_status.id  = trades.backoffice

inner join contreparties
ON contreparties.IDENT = trades.CONTREPARTIE 

left join tiers 
on tiers.ident = trades.courtier

inner join courtiers b
on b.ident = trades.courtier

inner join depositaires
on depositaires.ident = trades.depositaire 

inner join (     
                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID 
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME 
                      , FOLIO.ident AS STRATEGY_ID 
                      , FOLIO.name AS STRATEGY_NAME 
                      , level 
                  FROM FOLIO 
                  where level >= 4 
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                  ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.OPCVM 
                
where AFFECTATION.ident = '38' -- 'ABS' 
                
and fund_book_strategy.book_name not in ('Global ABS', 'US RMBS - Agency', 'US RMBS � Non Agency', 'CMBS', 'Securitized Products', 'Consumer Loans' )
               
and trades.backoffice not in (192,11,13,17,26,27,220,248,252) -- Exclude cancelled trades
                
and trades.dateneg > trunc(sysdate)-30;


  -- ***************************************************************************
  -- END OF ABS_IN_NON_USMORT 
  -- *************************************************************************** 	
	END ABS_IN_NON_USMORT;

-- *****************************************************************
-- Description:     PROCEDURE  AML_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 25 Nov 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE AML_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: AML_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =13

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: AML_RESTRICTED_LIST
-- *****************************************************************

   END AML_RESTRICTED_LIST;

-- *****************************************************************
-- Description:     PROCEDURE  EUROPEAN_ABS_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 25 Nov 2014     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE EUROPEAN_ABS_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EUROPEAN_ABS_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =14

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: EUROPEAN_ABS_RESTRICTED_LIST
-- *****************************************************************

   END EUROPEAN_ABS_RESTRICTED_LIST;


-- *****************************************************************
-- Description:     PROCEDURE  CROSS_ASSET_RESTRICTED_LIST
--                  
--
-- Author:         Ami Talati
--
-- Revision History
-- Date             Author         Reason for Change
-- ----------------------------------------------------------------
-- 30 Jan 2015     Ami Talati       Created.

-- *****************************************************************  

  PROCEDURE CROSS_ASSET_RESTRICTED_LIST
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: CROSS_ASSET_RESTRICTED_LIST
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT   distinct FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
                , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
                , Trades.sicovam                        Sicovam
                , Trades.refcon                         Trade_Id
                , trader.name                           Trader
                , Sec.libelle                           Instrument_Name
                , Sec.reference                         Instrument_Reference
                , trunc(Trades.DATENEG)                 d$Trade_Date
                , RLI.ISSUER_NAME                       Issuer

FROM histomvts Trades

INNER JOIN titres Sec
on Trades.sicovam = Sec.sicovam

INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (61950,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (61950,14414,14405,90565)
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 

INNER JOIN  business_events
      ON          business_events.id                            = Trades.type
      
INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur

LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 

LEFT JOIN   titres Underlying2
      ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end 
      and Underlying1.type <> 'H'
      
LEFT JOIN   panier UNDERLYING_BASKET
      ON UNDERLYING_BASKET.sicovam = Underlying1.SICOVAM

LEFT JOIN GISEMENTS_MATIF UnderlyingFutures
      ON UnderlyingFutures.CODE = Sec.sicovam

LEFT JOIN   extrnl_references_instruments ID_BB_COMPANY
      ON  (
      ID_BB_COMPANY.sophis_ident =  Sec.sicovam 
      OR
      ID_BB_COMPANY.sophis_ident = Underlying1.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = Underlying2.sicovam
      OR
      ID_BB_COMPANY.sophis_ident = UNDERLYING_BASKET.sicopanier
      OR      
      ID_BB_COMPANY.sophis_ident = UnderlyingFutures.CODE_OAT 
          )
      AND ID_BB_COMPANY.ref_ident = 673



INNER JOIN BTG_RESTRICTED_LIST_VALUES RLI
          ON TRIM(RLI.ID_BB_COMPANY) = ID_BB_COMPANY.value
          AND RLI.LIST_ID =17

INNER JOIN BTG_RESTRICTED_LIST RL
		  ON RLI.LIST_ID = RL.ID

INNER JOIN BTG_RESTRICTED_LIST_ENTITY RLE
          ON RLE.LIST_ID = RLI.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_USERS RLU
     ON RLI.LIST_ID = RLU.LIST_ID

LEFT JOIN BTG_RESTRICTED_LIST_ACK RLA
          ON RLA.TRADE_ID = trades.refcon
		 AND RLA.LIST_ID  = RL.ID		            

WHERE 
(
(RLE.BOOK_NAME_PATTERN IS NULL
  AND  
  RLE.BOOK_ID IS NULL
  And
EXISTS (                                                                                                                                                    
                                       SELECT 1  FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT FUND_FOLIO_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID)                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
 )
OR
EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (  SELECT BOOK_ID FROM BTG_RESTRICTED_LIST_ENTITY WHERE  LIST_ID =  RLI.LIST_ID  )                                                                                    
                                       START WITH IDENT = Trades.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
                                        )
OR
(
  (RLE.FUND_FOLIO_ID IS NULL AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
    OR
  (RLE.FUND_FOLIO_ID LIKE FUND_BOOK_STRATEGY.TOP_FUND_ID AND FUND_BOOK_STRATEGY.BOOK_NAME LIKE RLE.BOOK_NAME_PATTERN)
)
)
AND Trades.BACKOFFICE                         NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
AND TRUNC(Trades.DATENEG) >= TRUNC(SYSDATE-30)
AND business_events.compta                         = 1                                     --trades affecting position
AND (RLI.ACTIVE_FROM IS NULL OR TRUNC(ACTIVE_FROM) <= TRUNC(Trades.DATENEG))
AND (RLI.ACTIVE_TO IS NULL OR TRUNC(ACTIVE_TO) >= TRUNC(Trades.DATENEG))
AND (RL.USER_FILTERED = 'N' OR (RL.USER_FILTERED = 'Y' AND RLU.USER_ID = Trades.OPERATEUR))
AND RLA.TRADE_ID IS NULL
;
                EXCEPTION
                
                                WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);       


-- *****************************************************************
-- END OF: CROSS_ASSET_RESTRICTED_LIST
-- *****************************************************************

   END CROSS_ASSET_RESTRICTED_LIST;


 -- *****************************************************************
-- Description:     PROCEDURE  TRADE_REST_CCY
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 06 FEB 2015      Oliver              Created.	
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************  

  PROCEDURE TRADE_REST_CCY
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_REST_CCY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT
              FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME                        Fund
            , HISTOMVTS.refcon                                    Trade_id
            , FUND_BOOK_STRATEGY.STRATEGY_NAME                    Folio
            , HISTOMVTS.sicovam                                   Sicovam
            , TITRES.reference                                    Instrument_reference
            , TRUNC(HISTOMVTS.DATENEG)                            d$Trade_Date 
            , TRUNC(HISTOMVTS.DATEVAL)                            d$Value_Date 
            , DEVISE_TO_STR (HISTOMVTS.devisepay)                 Currency
            , BUSINESS_EVENTS.name                                Business_event
                                         
FROM        HISTOMVTS       
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
AND         TITRES.type = 'A' --any instrument created on the share template
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
WHERE          
          HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades        
AND DEVISE_TO_STR (HISTOMVTS.devisepay) IN ('IDR','INR','KRW','PHP','THB','TWD') --restricted currencies
AND TRUNC(HISTOMVTS.DATEVAL) >= TRUNC(SYSDATE)
ORDER BY 1,2,3 ASC;       


-- *****************************************************************
-- END OF: TRADE_REST_CCY
-- *****************************************************************

   END TRADE_REST_CCY;

 -- *****************************************************************
-- Description:     PROCEDURE  SHORT_MBS
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 APR 2015      Oliver              Created.					
-- 29 APR 2015      Davi                Arrange to be added to the critical errors Package
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  PROCEDURE SHORT_MBS
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: SHORT_MBS
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , FUND_BOOK_STRATEGY.STRATEGY_NAME Folio_Name
          , HISTOMVTS.sicovam                Sicovam
          , TITRES.libelle            Name
          , TITRES.reference          Ticker
          , SUM(HISTOMVTS.QUANTITE*NVL(TITRES.nominal,1)) Quantity
    FROM            HISTOMVTS 
    INNER JOIN      TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam 
    AND             TITRES.affectation IN (35, 38, 1252, 1253, 1450) --MBS - Agency, ABS, MBS - Non Agency, CMBS, ABS - Student Loan
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1 --position affecting tickets only
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.opcvm
    WHERE           HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, HISTOMVTS.sicovam, TITRES.libelle, TITRES.reference   
    HAVING SUM(HISTOMVTS.QUANTITE*NVL(TITRES.nominal,1)) < -1 --excludes the fractional positions between 0 and -1 to remove noise. These trades should be cleaned at some point too
    ORDER BY 1,2,3;     

-- *****************************************************************
-- END OF: SHORT_MBS
-- *****************************************************************

   END SHORT_MBS;
   
-- *****************************************************************
-- Description:     PROCEDURE  TRADE_WRONG_TYPESICO
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 30 APR 2015      Oliver              Created.					
-- 30 APR 2015      Davi                Arrange to be added to the critical errors Package

  PROCEDURE TRADE_WRONG_TYPESICO
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_WRONG_TYPESICO
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 SELECT 
	  FUND_BOOK_STRATEGY.BOOK_NAME      Strategy_Name
	, FUND_BOOK_STRATEGY.Fund_NAME      Fund_Name
  , RISKUSERS.name                    Trader
	, HISTOMVTS.sicovam                 Sicovam
	, HISTOMVTS.refcon                  Trade_ID
	, TITRES.reference                  Ticker
	, TRUNC(HISTOMVTS.DATENEG)          d$Trade_Date

FROM HISTOMVTS

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam

INNER JOIN RISKUSERS
ON RISKUSERS.ident = HISTOMVTS.operateur

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND,PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14414,90565,14045)
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm

WHERE HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND HISTOMVTS.typesico !=0 --trade type not Real
ORDER BY 1,2 ASC; 

-- *****************************************************************
-- END OF: TRADE_WRONG_TYPESICO
-- *****************************************************************

   END TRADE_WRONG_TYPESICO;

   -- *****************************************************************
-- Description:     PROCEDURE  PURCHSALE_QTY_0
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUN 2015      Gustavo Binnie      Created.					
-- 20 JUN 2018      Jeff Yu     Modified (PMGMRISK-228)

  PROCEDURE PURCHSALE_QTY_0
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: PURCHSALE_QTY_0
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 select
        Trades.refcon                                                                       Trade_ID,        
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.BOOK_NAME                                                        Strategy,
        FUND_BOOK_STRATEGY.STRATEGY_NAME                                                    Folio,
        trader.name                                                                         Trader,
        Trades.DATENEG                                                                      d$Trade_Date,
        Instrument.LIBELLE                                                                  Instrument_Name,
        DEVISE_TO_STR(Instrument.DEVISECTT)                                           Instrument_CCY,
        allot.LIBELLE                                                                       Allotment,
        pb.REFERENCE                                                                        Depositary,
        Trades.QUANTITE                                                                     Qty,
        Trades.MONTANT                                                                      NetAmount,
        DEVISE_TO_STR(Trades.DEVISEPAY)                                               Sett_CCY
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam			 = Trades.sicovam 
INNER JOIN       riskusers trader
ON               trader.ident                = Trades.operateur
left join      tiers cpty
on              cpty.ident					 = trades.contrepartie
left join      tiers pb
on              pb.ident					 = Trades.DEPOSITAIRE                            
left join      affectation allot
on              allot.IDENT					 = Instrument.AFFECTATION
inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME  
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 3
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE 
Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
and Trades.type in (1,140,1444,1494)
and Trades.QUANTITE = 0
And Trades.MONTANT <> 0
;

-- *****************************************************************
-- END OF: PURCHSALE_QTY_0
-- *****************************************************************

   END PURCHSALE_QTY_0;
   
   -- *****************************************************************
-- Description:     PROCEDURE  FEES_ON_EV
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 JUN 2015      Gustavo Binnie      Created.					

  PROCEDURE FEES_ON_EV
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: FEES_ON_EV
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
              HISTOMVTS.sicovam                   SICOVAM
            , HISTOMVTS.refcon                    TRADE_ID
            , HISTOMVTS.dateneg                   TRADE_DATE
            , HISTOMVTS.dateval                   VALUE_DATE
            , TITRES.Libelle                      INSTRUMENT_NAME
            , TITRES.reference                    INSTRUMENT_REFERENCE
            , DEVISE_TO_STR(TITRES.devisectt)     INSTRUMENT_CCY
            , BUSINESS_EVENTS.name                BUSINESS_EVENT
            , HISTOMVTS.fraismarche               MARKET_FEES
            , HISTOMVTS.fraiscounterparty         COUNTERPARTY_FEES
            , HISTOMVTS.fraiscourtage             BROKER_FEES
            , HISTOMVTS.montant                   NET_AMOUNT
            , DEVISE_TO_STR(HISTOMVTS.devisepay)  PAY_CCY
FROM 
            HISTOMVTS
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 2
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
WHERE
DEVISE_TO_STR(HISTOMVTS.devisepay) != 'BRL'
AND HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND
(
            HISTOMVTS.fraismarche <>0
OR
            HISTOMVTS.fraiscounterparty <>0
OR
            HISTOMVTS.fraiscourtage <>0
)
;

-- *****************************************************************
-- END OF: FEES_ON_EV
-- *****************************************************************

   END FEES_ON_EV;
   
-- *****************************************************************
-- Description:     PROCEDURE  NY_ETD_WRNG_ACCT_EQ
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 04 SEP 2015      Oliver              Created.					
-- 04 SEP 2015      Davi                Arranged the release with AS	
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)

  PROCEDURE NY_ETD_WRNG_ACCT_EQ
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: NY_ETD_WRNG_ACCT_EQ
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT 
                FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name
              , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
              , HISTOMVTS.sicovam                     Sicovam
              , HISTOMVTS.refcon                      Trade_ID
              , TITRES.reference                      Ticker
              , TRUNC(HISTOMVTS.dateneg)              d$Trade_Date
              , TRUNC(HISTOMVTS.dateval)              d$Value_Date
              , DEVISE_TO_STR(HISTOMVTS.devisepay)    Currency
              , TIERS.NAME                            PrimeBroker
FROM          HISTOMVTS
INNER JOIN    TITRES 
ON            TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN    TIERS
ON            TIERS.IDENT = HISTOMVTS.DEPOSITAIRE
INNER JOIN (
              SELECT 
                      CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                    , FOLIO.ident AS STRATEGY_ID
                    , FOLIO.NAME AS STRATEGY_NAME
                    , LEVEL
              FROM  FOLIO
              WHERE LEVEL > = 4 START
              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
          )   FUND_BOOK_STRATEGY 
ON            FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
LEFT JOIN     BTG_MAPPING_CODE --Link to allowed NY ETD depositaries
ON            BTG_MAPPING_CODE.input_code = HISTOMVTS.depositaire
AND           BTG_MAPPING_CODE.type_id = 44
AND           BTG_MAPPING_CODE.source_id = 9
WHERE         HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND           FUND_BOOK_STRATEGY.BOOK_ID IN 
                                          (
                                          SELECT  NYFOLIO.input_code
                                          FROM    BTG_MAPPING_CODE NYFOLIO
                                          WHERE   NYFOLIO.output_code = 'NY'
                                          AND     NYFOLIO.type_id = 33 
                                          ) --NY strategies
AND           (
                              (
                                TITRES.TYPE = 'F'
                                AND 
                               (TITRES.affectation != 33 or TITRES.affectation is null)
                              )
                          OR 
                              (
                                TITRES.TYPE = 'D'
                                AND 
                                TITRES.affectation = 10
                              )
              ) -- futures and listed options
AND           HISTOMVTS.dateneg > sysdate - 5 --recent trades
AND           BTG_MAPPING_CODE.output_code IS NULL
AND           TIERS.ident NOT IN 
                                          (
                                          SELECT  INT_DEP.input_code
                                          FROM    BTG_MAPPING_CODE INT_DEP
                                          WHERE   INT_DEP.type_id = 35 
                                          )--exclude internal trades depositaries
AND           FUND_BOOK_STRATEGY.BOOK_NAME IN ('EQ US Cash','EQ US IPO')
ORDER BY 1,2 ASC;

-- *****************************************************************
-- END OF: NY_ETD_WRNG_ACCT_EQ
-- *****************************************************************

   END NY_ETD_WRNG_ACCT_EQ;
   
-- *****************************************************************
-- Description:     PROCEDURE     TRADE_BOND_MIN_SIZE
--
-- Author:          Oliver
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 16 SEP 2015      Oliver              Created.					
-- 16 SEP 2015      Davi                Arranged the release with AS		
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  PROCEDURE TRADE_BOND_MIN_SIZE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADE_BOND_MIN_SIZE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME                  Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME                  Fund_Name
						, FUND_BOOK_STRATEGY.STRATEGY_NAME              Strategy
						, TITRES.reference                              ISIN
						, HISTOMVTS.refcon                              n$TradeID
						, RISKUSERS.name                                Trader
						, HISTOMVTS.dateneg                             d$Trade_Date
						, HISTOMVTS.dateval                             d$Value_Date
						, HISTOMVTS.quantite*titres.nominal             n$Nominal
						, HISTOMVTS.quantite                            n$Quantity
						, HISTOMVTS.sicovam                             n$Sicovam
            , BUSINESS_EVENTS.name                          Business_Event
            , TITRES.minimumpiece                           Minimum_Piece
            , TITRES.lowestincrement                        Minimum_Increment
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
                    ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =    HISTOMVTS.OPCVM    
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position affecting trades only
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur        
INNER JOIN  TITRES 
ON          TITRES.sicovam = HISTOMVTS.sicovam   
AND         TITRES.lowestincrement !=0

WHERE       HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) --exclude cancelled trades
AND         (
            TRUNC((((HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement)) != (((HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement)
			OR
			((abs(HISTOMVTS.quantite*titres.nominal) - TITRES.minimumpiece)/TITRES.lowestincrement) < 0
            )
AND HISTOMVTS.dateval > sysdate - 7  --recent trades
ORDER BY 1,2 
;

-- *****************************************************************
-- END OF: TRADE_BOND_MIN_SIZE
-- *****************************************************************

   END TRADE_BOND_MIN_SIZE;
   
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_LEI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_LEI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_LEI_VALIDATION
  -- *****************************************************************   
  OPEN p_CURSOR FOR
        
SELECT tiers.ident
	,tiers.reference
	,tiers.NAME
	,BTG_EMIR_TIERS.lei
	
FROM BTG_EMIR_TIERS

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

WHERE BTG_EMIR_TIERS.LEI IS NOT NULL
AND length(BTG_EMIR_TIERS.lei) != 20;


-- *****************************************************************
-- END OF: EMIR_LEI_VALIDATION
-- *****************************************************************

 END EMIR_LEI_VALIDATION;
   
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_UTI_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_UTI_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_UTI_VALIDATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
 SELECT DISTINCT histomvts.refcon Trade_ID
  ,btg_emir_confirm.uti UTI
	,titres.reference instrument_reference
	,affectation.libelle allotment
	,titres.sicovam sicovam
	,fund.reference Fund
	,business_events.NAME business_event
	,histomvts.quantite quantity
	,histomvts.cours price
  ,trunc(histomvts.DATENEG)   d$Trade_Date
  ,trunc(histomvts.DATEVAL)   d$Value_Date
	,tiers.reference depositary
	,cpty.reference counterparty

FROM histomvts

INNER JOIN (
	SELECT folio.ident
		,folio.NAME
		,NVL(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'), 3, 4), ident) parent_ident
	FROM folio
	WHERE LEVEL > 2 START
	WITH ident = PCKG_BTG.FOLIO_UCITS_FUND CONNECT BY mgr = prior ident
	) strategy
ON strategy.ident = histomvts.opcvm

INNER JOIN titres fund
ON fund.code_emet = histomvts.entite

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.fund = fund.sicovam
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN business_events
ON business_events.id = histomvts.type
AND business_events.compta = 1

INNER JOIN tiers
ON tiers.ident = histomvts.depositaire

INNER JOIN tiers cpty
ON cpty.ident = histomvts.contrepartie

INNER JOIN AMRECON_EXTSYS_ACCOUNTS depo
ON depo.pb = tiers.ident
AND depo.esid = 3183
AND depo.include = 1

INNER JOIN titres
ON titres.sicovam = histomvts.sicovam

LEFT JOIN affectation
ON affectation.ident = titres.affectation

LEFT JOIN btg_emir_confirm
ON btg_emir_confirm.refcon = histomvts.refcon

WHERE TRUNC(histomvts.DATENEG) >= '12-FEB-2014'
AND histomvts.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
AND cpty.ident not in (10007902,10021768) -- Excluding NDF FIXING and NDF FIXING UCITS
AND (btg_emir_confirm.uti IS NULL
     OR 
     (btg_emir_confirm.uti IS NOT NULL and length(btg_emir_confirm.uti) > 50)
    );


-- *****************************************************************
-- END OF: EMIR_UTI_VALIDATION
-- *****************************************************************

 END EMIR_UTI_VALIDATION;
 
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_ISDA_LAW_VALIDATION
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_ISDA_LAW_VALIDATION
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_ISDA_LAW_VALIDATION
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT tiers.ident
	,tiers.reference
	,tiers.NAME
	,tiersagreement.agreement
	,tiersagreement.law
FROM tiersagreement
INNER JOIN tiers
ON tiers.ident = tiersagreement.code

WHERE tiersagreement.law IS NOT NULL
AND (
		substr(tiersagreement.law, 1, 2) NOT IN (19,20)
		OR 
    length(tiersagreement.law) != 4
    )
;

-- *****************************************************************
-- END OF: EMIR_ISDA_LAW_VALIDATION
-- *****************************************************************

 END EMIR_ISDA_LAW_VALIDATION;
 

-- *****************************************************************
-- Description:     PROCEDURE  EMIR_CONFIRM_DATE
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_CONFIRM_DATE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_CONFIRM_DATE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT HISTOMVTS.refcon TradeID
	,HISTOMVTS.dateneg d$Trade_Date
	,BTG_EMIR_CONFIRM.CONFIRM_DATE d$Confirm_Date
	--, HISTOMVTS.quantite                            n$Quantity
	,HISTOMVTS.sicovam n$Sicovam
	,TITRES.reference Instrument_ref
	,TITRES.libelle Instrument_name
	,BUSINESS_EVENTS.NAME Business_Event
	,RISKUSERS.NAME Trader
FROM HISTOMVTS
INNER JOIN BTG_EMIR_CONFIRM
ON BTG_EMIR_CONFIRM.REFCON = HISTOMVTS.REFCON
	
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.id = HISTOMVTS.type

INNER JOIN RISKUSERS
ON RISKUSERS.ident = HISTOMVTS.operateur

INNER JOIN TITRES
ON TITRES.sicovam = HISTOMVTS.sicovam

WHERE HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --exclude cancelled trades
AND (BTG_EMIR_CONFIRM.CONFIRM_DATE < HISTOMVTS.dateneg)

ORDER BY 1,2
;

-- *****************************************************************
-- END OF: EMIR_CONFIRM_DATE
-- *****************************************************************

 END EMIR_CONFIRM_DATE;

  
 -- *****************************************************************
-- Description:     PROCEDURE  EMIR_UCITS_INST_MATURITY
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 23 SEP 2015      JUN GUAN              Created.					

  PROCEDURE EMIR_UCITS_INST_MATURITY
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: EMIR_UCITS_INST_MATURITY
  -- *****************************************************************   
          OPEN p_CURSOR FOR
        
SELECT DISTINCT titres.sicovam
	,titres.reference
	,titres.libelle
	,decode(titres.type, 'S', titres.emission, titres.dateregl) start_date
	,decode(titres.type, 'S', titres.datefinal, titres.finper) Maturity_date
FROM titres
INNER JOIN histomvts
	ON histomvts.sicovam = titres.sicovam
INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_UCITS_FUND) -- UCITS funds
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY
	ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
WHERE titres.type NOT IN (
		'K'
		,'E'
		)
	AND (
		(
			titres.type = 'S'
			AND titres.emission > titres.datefinal
			)
		OR (
			titres.type != 'S'
			AND titres.dateregl > titres.finper
			)
		)
;

-- *****************************************************************
-- END OF: EMIR_UCITS_INST_MATURITY
-- *****************************************************************

 END EMIR_UCITS_INST_MATURITY;
 
 
-- *****************************************************************
-- Description:     PROCEDURE  EMIR_THIRD_PARTY_MISSING_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 feb 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE EMIR_THIRD_PARTY_MISSING_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EMIR_THIRD_PARTY_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT BTG_EMIR_TIERS.tiers_ident Third_party_id
	,tiers.NAME Third_party_name
	,tiers.reference Third_party_Reference
	,group1.NAME Group_Name
	,BTG_EMIR_EEA_ENTITY.NAME EEA_Flag
	,BTG_EMIR_TIERS.lei LEI
	
FROM BTG_EMIR_TIERS

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.PB = BTG_EMIR_TIERS.tiers_ident
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

INNER JOIN tiers group1
ON group1.ident = tiers.mgr

LEFT JOIN BTG_EMIR_EEA_ENTITY
ON BTG_EMIR_EEA_ENTITY.id = BTG_EMIR_TIERS.eea_entity

WHERE BTG_EMIR_TIERS.eea_entity IS NULL
OR BTG_EMIR_TIERS.lei IS NULL;


	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

EMIR_THIRD_PARTY_MISSING_DATA;

-- *****************************************************************
-- END OF: EMIR_THIRD_PARTY_MISSING_DATA
-- *****************************************************************   


-- *****************************************************************
-- Description:     PROCEDURE  EMIR_FUND_MISSING_DATA
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 feb 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE EMIR_FUND_MISSING_DATA (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: EMIR_FUND_MISSING_DATA
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT DISTINCT BTG_EMIR_TIERS.tiers_ident Fund_id
	,tiers.NAME Fund_name
	,tiers.reference Fund_Reference
	,BTG_EMIR_EEA_ENTITY.NAME EEA_Flag
	,BTG_EMIR_TIERS.lei LEI
	
FROM BTG_EMIR_TIERS

INNER JOIN titres
ON titres.code_emet = BTG_EMIR_TIERS.tiers_ident

INNER JOIN AMRECON_EXTSYS_ACCOUNTS
ON AMRECON_EXTSYS_ACCOUNTS.fund = titres.sicovam
AND AMRECON_EXTSYS_ACCOUNTS.esid = 3183
AND AMRECON_EXTSYS_ACCOUNTS.include = 1

INNER JOIN tiers
ON tiers.ident = BTG_EMIR_TIERS.tiers_ident

INNER JOIN tiers group1
ON group1.ident = tiers.mgr

LEFT JOIN BTG_EMIR_EEA_ENTITY
ON BTG_EMIR_EEA_ENTITY.id = BTG_EMIR_TIERS.eea_entity

WHERE BTG_EMIR_TIERS.eea_entity IS NULL
OR BTG_EMIR_TIERS.lei IS NULL;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

-- *****************************************************************
-- END OF: EMIR_FUND_MISSING_DATA
-- ***************************************************************** 

EMIR_FUND_MISSING_DATA;

  -- *****************************************************************
  -- Description: PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 16 June 2015     Gustavo Binnie    Created.
  -- 19 OCT 2015      Davi Xavier       Moved from PCKG_BTG_EMAILER_EXCEPTION_BO
  
PROCEDURE HKD_FUT_OPTION_NOT_IN_UBS(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: HKD_FUT_OPTION_NOT_IN_UBS
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT		
          
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, PB.NAME                               Depositary
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Sec.libelle                           Instrument_Name
					, Sec.reference                         Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
        FROM histomvts Trades
				inner join titres Sec
				on Trades.sicovam = Sec.sicovam
				INNER JOIN
					(   SELECT 
						CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
						CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID ,
						REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)  AS BOOK_NAME ,
						FOLIO.ident                                                         AS STRATEGY_ID ,
						FOLIO.name                                                          AS STRATEGY_NAME ,
						level
						FROM FOLIO
						WHERE LEVEL                                        >= 4
						START WITH FOLIO.ident                            IN (14414, 90565) -- Primary funds and UCITs funds
						CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
					) FUND_BOOK_STRATEGY 
				ON          FUND_BOOK_STRATEGY.STRATEGY_ID                = Trades.OPCVM 
				INNER JOIN  business_events
				ON          business_events.id                            = Trades.type
				INNER JOIN  riskusers trader
				ON          trader.ident                                  = Trades.operateur
        INNER JOIN  tiers PB
				ON          PB.IDENT                                      = Trades.DEPOSITAIRE
        LEFT JOIN extrnl_ref_market_value mc
        ON          mc.market                                     = Sec.marche
        AND         mc.currency                                   = Sec.devisectt
        AND         mc.ref_ident                                  = 7
        LEFT JOIN btg_mapping_CODE BM
        ON          BM.INPUT_CODE                                 = Sec.MARCHE
        AND         BM.TYPE_ID                                    = 23
        AND         BM.SOURCE_ID                                  = 3
        WHERE         
             Trades.BACKOFFICE						          NOT IN (192,11,13,17,26,27,220,248,252)      -- checked mo canceled
        AND 
        (
            (Sec.TYPE = 'F' AND BM.OUTPUT_CODE='XHKF') -- HKD FUTURES - Market HKFE - Hong Kong Future Exchange
             OR
            (sec.AFFECTATION = 10 AND sec.DEVISECTT=55069508 and (mc.value='XHKF' or mc.value = 'XHKG')) --HKD OPTIONS (Market HKG - Hong Kong Stock Exchange or HKFE - Hong Kong Future Exchange)
        )
        AND UPPER(PB.NAME) NOT LIKE '%UBS%%ETD%' --NOT UBS ETD Depositaries
        AND Trades.DATENEG > TRUNC(SYSDATE-30)  
        ;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

-- *****************************************************************
-- END OF: HKD_FUT_OPTION_NOT_IN_UBS
-- *****************************************************************  

END

HKD_FUT_OPTION_NOT_IN_UBS;

-- *****************************************************************
-- Description: PROCEDURE CORR_SW_BAD_FX
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 03 DEC 2015      PMOG-877
-- *****************************************************************
  
PROCEDURE CORR_SW_BAD_FX(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CORR_SW_BAD_FX
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT 
            TITRES.sicovam                                                      Sicovam
          , TITRES.libelle                                                      Instrument_Name
          , TITRES.reference                                                    Instrument_reference
          , CASE
                WHEN DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
                      AND TITRES.FOREX_ORDER1 NOT IN (1,2)  --no FX pair direction chosen
                            THEN 'Rec Leg Missing FX pair'
                WHEN DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) 
                      AND TITRES.FOREX_ORDER1 NOT IN (1,2)  --no FX pair direction chosen
                            THEN 'Pay Leg Missing FX pair'
                WHEN DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
                      AND TITRES.j1refcon3 = 0 --FX rate = 0
                            THEN 'Rec Leg Missing FX rate'
                WHEN DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) 
                      AND TITRES.j2refcon3 = 0 --FX rate = 0
                            THEN 'Pay Leg Missing FX pair'
                ELSE 'Unknown'
            END                                                                 Problem
          , BTG_FN_AUDIT_INST_USER(TITRES.sicovam)                              Sophis_User
FROM      TITRES
WHERE 
          TITRES.modele = 'Correlation Swap'
AND  
    (
      (
          (
          DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
          AND
          TITRES.FOREX_ORDER1 NOT IN (1,2) --no FX pair direction chosen
          )
          OR
          (
          DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) --Pay leg ccy <> swap ccy
          AND
          TITRES.FOREX_ORDER2 NOT IN (1,2) --no FX pair direction chosen
          )
      )
      OR
      (
          (
          DEVISE_TO_STR(TITRES.deviseexer) != DEVISE_TO_STR(TITRES.devisectt) --Rec leg ccy <> swap ccy
          AND
          TITRES.j1refcon3 = 0 --FX rate = 0
          )
          OR
          (
          DEVISE_TO_STR(TITRES.deviseac) != DEVISE_TO_STR(TITRES.devisectt) --Pay leg ccy <> swap ccy
          AND
          TITRES.j2refcon3 = 0 --FX rate = 0
          )
      )
    )
;

END

CORR_SW_BAD_FX;

-- *****************************************************************
-- END OF: CORR_SW_BAD_FX
-- ***************************************************************** 


   -- *****************************************************************
  -- Description: PROCEDURE NO_COMMISSION
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- 18 FEB 13	Oliver South   Set the date format and correct fund join
PROCEDURE NO_COMMISSION
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
  -- ***************************************************************************
  -- BEGIN OF NO_COMMISSION 
  -- ***************************************************************************
    OPEN p_CURSOR FOR
        SELECT      
                      FUND_BOOK_STRATEGY.BOOK_NAME					Strategy_Name
                     ,FUND_BOOK_STRATEGY.Fund_NAME					Fund_Name
                     ,Trades.sicovam				   				Sicovam
                     ,Trades.refcon									TradeId
                     ,Instrument.libelle							Name
                     ,trunc(Trades.DATENEG)							d$Trade_Date
                     ,trunc(Trades.DATEVAL)							d$Value_Date
                     ,Trades.quantite								n$Quantity
                     ,Trades.Montant								n$Net_Amount
                     ,DEVISE_TO_STR(Trades.devisepay)				Currency
                     ,trader.name									Trader
                     ,business_events.name							Busines_Event
      FROM            histomvts Trades 
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      INNER JOIN      riskusers trader
      ON              trader.ident                                  = Trades.operateur      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam       
      INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
	  ON           FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
      
      WHERE           
            Trades.BACKOFFICE               NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades                 
      AND   Instrument.TYPE                 = 'C' --Comission
      AND   trades.type                    NOT IN (50,7,694) -- not commission, Subscription/Redemption or Cash Transfer
      AND   ( trades.quantite = 0 
              OR 
              trades.quantite IS NULL
            )
      AND   trades.operateur               != 1
      ORDER BY 1,2 ASC;
 
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	  
  -- ***************************************************************************
  -- END OF NO_COMMISSION 
  -- ***************************************************************************
	END NO_COMMISSION; 



  -- *****************************************************************
  -- Description:PROCEDURE TRADES_CFD_BKR_CP_WRONG
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --11 Mar 2013 Oliver South	Added Block Id into report SR-74
  -- *****************************************************************
 PROCEDURE TRADES_CFD_BKR_CP_WRONG
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_CFD_BKR_CP_WRONG 
  -- ***************************************************************************			
		OPEN p_CURSOR FOR
       SELECT          
                      FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name
                    , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name 
                    , Trades.sicovam                        Sicovam
                    , ta_block_to_generated.block_id        Block_id
                    , Trades.refcon                         Refcon
                    , Instrument.libelle                    Name
                    , Instrument.reference                  Ticker
                    , trunc(Trades.DATENEG)                 d$Trade_Date
                    , trunc(Trades.DATEVAL)                 d$Value_Date
                    , Trades.QUANTITE                       n$Quantity
                    , counterparty.name                     Counterparty
                    , broker.name                           Broker
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    LEFT JOIN       ta_block_to_generated
    ON              ta_block_to_generated.generated_id = Trades.refcon
    INNER JOIN ( 
                   SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                          , FOLIO.ident                                                            AS STRATEGY_ID
                          , FOLIO.name                                                             AS STRATEGY_NAME
                          , level
                    FROM FOLIO
                    WHERE LEVEL                       >= 4
                    START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                    CONNECT BY PRIOR   FOLIO.ident    = FOLIO.mgr
                  ) FUND_BOOK_STRATEGY
    ON              FUND_BOOK_STRATEGY.STRATEGY_ID    = Trades.OPCVM
    LEFT JOIN       riskusers trader
    ON              trader.ident                      = Trades.operateur
    LEFT JOIN       tiers counterparty
    ON              counterparty.ident                = trades.contrepartie
    LEFT JOIN       tiers broker
    ON              broker.ident                      = trades.courtier
    WHERE           instrument.affectation			  = 12  --CFD
    AND             (  counterparty.ident             != '10011565' 
                       OR broker.ident                = '10011565' ) --CP not CFD-COUNTERPARTY and Broker is CFD-COUNTERPARTY
    AND             Trades.BACKOFFICE                 NOT IN (192,11,13,17,26,27,220,248,252) -- checked mo canceled
    ORDER BY 1,4;
  -- ***************************************************************************
  -- END OF TRADES_CFD_BKR_CP_WRONG 
  -- ***************************************************************************
	END TRADES_CFD_BKR_CP_WRONG;



  -- *****************************************************************
 -- Description: PROCEDURE TRADES_MISSING_FEES
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 --11 Mar 2013 Oliver South	Add in Block ID SR-73
 --02 Jan 2014 Oliver South	Exclude PB transfer trades PMOG-402
 --18 June 2018  Jeff Yu   Add new business event PMGMRISK-228
 -- ----------------------------------------------------------------     
  PROCEDURE TRADES_MISSING_FEES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_MISSING_FEES 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

SELECT          
					  FUND_BOOK_STRATEGY.BOOK_NAME			Strategy_Name
					, FUND_BOOK_STRATEGY.Fund_NAME			Fund_Name
					, Trades.sicovam						Sicovam
					, ta_block_to_generated.block_id		Block_id
					, Trades.refcon							Trade_Id
					, trader.name							Trader
					, Instrument.libelle					Name
					, Instrument.reference					Ticker
					, trunc(Trades.DATENEG)					d$Trade_Date
					, trunc(Trades.DATEVAL)					d$Value_Date
					, Trades.QUANTITE						n$Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    LEFT JOIN       ta_block_to_generated
    ON              ta_block_to_generated.generated_id = trades.refcon
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    WHERE           Trades.DATENEG                     > trunc(sysdate) - 5 --recent trades
    AND             (
                       (Instrument.TYPE               = 'A') --shares
                    OR 
                        (Instrument.TYPE               = 'F' 
                        AND instrument.affectation    !=33) --Futures excluding FRA
                    )
    AND             trades.type                                   in (1,140,1444,1494)  --Purchase/Sale
    AND             trades.fraismarche                            =0  --market fees
    AND             trades.fraiscounterparty                      =0  --CP fees
    AND             trades.fraiscourtage                          =0  --broker fees  
    AND             trades.courtier                               NOT IN (
                                                                          SELECT BTG_MAPPING_CODE.INPUT_CODE
                                                                          FROM BTG_MAPPING_CODE
                                                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = '9'
                                                                          AND BTG_MAPPING_CODE.TYPE_ID = '46'
                                                                          ) --exclude PB Transfer as broker
    AND             Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252)   -- exclude cancelled trades
    AND             devise_to_str(trades.devisepay)               != 'BRL'  --exclude BRL trades
    ORDER BY        1,4 ASC;

  -- ***************************************************************************
  -- END OF TRADES_MISSING_FEES 
  -- ***************************************************************************
	END TRADES_MISSING_FEES;




 -- *****************************************************************
 -- Description:     PROCEDURE  BOND_TRADES_WITH_FEE
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 13 Sep 2013     Oliver South       Created.
 -- 13 Sep 2013     Oliver South       Updated/Davi arranged the release with App Support
 -- *****************************************************************  

  PROCEDURE BOND_TRADES_WITH_FEE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOND_TRADES_WITH_FEE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
			SELECT          
                        FUND_BOOK_STRATEGY.FUND_NAME        Fund_Name
                      , FUND_BOOK_STRATEGY.STRATEGY_NAME    Strategy_Name
                      , HISTOMVTS.sicovam                   Sicovam
                      , HISTOMVTS.refcon                    Trade_Id
                      , RISKUSERS.name                      Trader
                      , TITRES.libelle                      Instrument_Name
                      , TITRES.reference                    Instrument_Reference
                      , TRUNC(HISTOMVTS.dateneg)            d$Trade_Date
                      , TRUNC(HISTOMVTS.dateval)            d$Value_Date
                      , HISTOMVTS.fraismarche               Market_fees
                      , HISTOMVTS.fraiscounterparty         Counterparty_fees
                      , HISTOMVTS.fraiscourtage             Broker_fees
                      , BUSINESS_EVENTS.name                Busines_Event
			FROM            HISTOMVTS
			INNER JOIN      BUSINESS_EVENTS
			ON              BUSINESS_EVENTS.id = HISTOMVTS.type
      AND             BUSINESS_EVENTS.compta = 1 --position affecting tickets only
			INNER JOIN      RISKUSERS
			ON              RISKUSERS.ident = HISTOMVTS.operateur
			INNER JOIN      TITRES
			ON              TITRES.sicovam = HISTOMVTS.sicovam 
      AND             DEVISE_TO_STR(TITRES.devisectt) != 'BRL' --exclude BRL instruments since they can take the IOF tax in the fees if realising PnL within a month of the purchase
      AND             TITRES.type = 'O' --any instrument on the bond template
			INNER JOIN ( 
                      SELECT     
                                    CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                  , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                  , FOLIO.ident                                                           AS STRATEGY_ID
                                  , FOLIO.name                                                            AS STRATEGY_NAME
                                  , level
                      FROM        FOLIO
                      WHERE       LEVEL     <= 4
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                      CONNECT BY PRIOR FOLIO.ident      = FOLIO.mgr  
                   ) FUND_BOOK_STRATEGY
			ON              FUND_BOOK_STRATEGY.STRATEGY_ID      = HISTOMVTS.OPCVM 
			WHERE        ( 
                            HISTOMVTS.fraismarche                            !=0  --market fees
                      OR    HISTOMVTS.fraiscounterparty                      !=0  --CP fees
                      OR    HISTOMVTS.fraiscourtage                          !=0  --broker fees  
                    )
			AND           HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --deleted/cancelled trades
			;
      
	-- *****************************************************************
  -- END OF: BOND_TRADES_WITH_FEE
  -- *****************************************************************   
	END BOND_TRADES_WITH_FEE; 


 -- *****************************************************************
 -- Description: PROCEDURE TRADEDT_IS_VALUEDT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb	      Oliver South		Order of columns and checking for trades with TD > VD SR-64
 --01 May 2013    Gustavo Binnie    Excluded Repo Trades
 --20 Jun 2018      Jeff Yu      Modified (PMGMRISK-228)  Add new business event
 -- ----------------------------------------------------------------     

  PROCEDURE TRADEDT_IS_VALUEDT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADEDT_IS_VALUEDT 
  -- *************************************************************************** 			
		OPEN p_CURSOR FOR

    SELECT          
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, Instrument.libelle                    Name
						, Instrument.reference                  Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam                 =  Trades.sicovam 
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON              FUND_BOOK_STRATEGY.STRATEGY_ID           = Trades.OPCVM
    INNER JOIN      riskusers trader
    ON              trader.ident                             = Trades.operateur
    WHERE           Trades.DATENEG                           > trunc(sysdate) - 5
    AND             (
                       (Instrument.TYPE in ('A','O') --shares and bonds
                       AND instrument.affectation           not in (20,1801,45) --Cash, Cash Loan and External funds
                       AND trades.dateneg = trades.dateval) 
                    OR 
                       (Instrument.TYPE = 'D' 
                       AND Instrument.Affectation           = 23 --FXO
                       AND trades.dateneg = trades.dateval) 
                    OR
                      (trades.dateneg > trades.dateval)
                    )
    AND             trades.type                             in (1,140,1444,1494) --only trades, not CA
    AND             Instrument.TYPE                         NOT IN ('L') -- not Repos
    AND             Trades.BACKOFFICE                       NOT IN (192,11,13,17,26,27,220,248,252)   -- checked not canceled
    AND             devise_to_str(trades.devisepay) != 'BRL'  --exclude BRL trades
    ORDER BY        1,2 ASC;


  -- ***************************************************************************
  -- BEGIN OF TRADEDT_IS_VALUEDT 
  -- *************************************************************************** 	
	END TRADEDT_IS_VALUEDT;


  -- *****************************************************************
  -- Description: PROCEDURE OPS_AS_TRADERS
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan			Created.
  -- 06-May-2013  Gustavo Binnie	Christopher Cade moved to FO on 15-Mar-2013
  -- 08-Nov-2016   Jeff Yu        Add Craig McCormack in the exception list       
  -- 23-May-2017  Jeff Yu        PMOG-1086 add Acquisition - Mandatory, Acquisition - Elected into exclusion list
  -- 02 FEB 2018   Jeff Yu         PMOG-1194  Exclude Rafael Rocha as he still books trades per Brazil traders
  -- *****************************************************************
  PROCEDURE OPS_AS_TRADERS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: OPS_AS_TRADERS
  -- *****************************************************************  

    OPEN p_CURSOR FOR    
SELECT        
              FUND_BOOK_STRATEGY.Fund_NAME            Fund
            , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
            , HISTOMVTS.sicovam                       Sicovam
            , HISTOMVTS.refcon                        TradeID
            , TITRES.reference                        Ticker
            , TRUNC(HISTOMVTS.dateneg)                d$TradeDate
            , TRUNC(HISTOMVTS.dateval)                d$ValueDate
            , BUSINESS_EVENTS.name                    BusinesEvent
            , RISKUSERS.name                          Trader
    FROM      HISTOMVTS
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
    INNER JOIN    BUSINESS_EVENTS
    ON            BUSINESS_EVENTS.id  = HISTOMVTS.type
    AND           BUSINESS_EVENTS.compta = 1 --position affecting tickets only
    INNER JOIN    RISKUSERS
    ON            RISKUSERS.ident = HISTOMVTS.operateur
    AND           RISKUSERS.gident = 4572 --Trader name in OPERATIONS_TD group
    INNER JOIN    USERINFOS
    ON            USERINFOS.ident = RISKUSERS.ident
    AND           USERINFOS.country != 'BRAZIL' --Brazil users are expected to book trades
    INNER JOIN    TITRES
    ON            TITRES.sicovam  = HISTOMVTS.sicovam
    AND           TITRES.type NOT IN ('C', 'L') --ignore cash events and repo bookings
    WHERE         HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND           HISTOMVTS.type NOT IN (744, 121, 9, 360, 161, 221,846,3,1194,1196) --CFD Roll, Acquisition, Exercise, Expire, Transfer, Exchange,Loan Paydown,Split, Acquisition - Mandatory, Acquisition - Elected
    AND           TRUNC(HISTOMVTS.dateneg) > TRUNC(SYSDATE-30) --trades from past 30 days
    AND           HISTOMVTS.operateur NOT IN (2707, 1889, 2928, 7462, 3387, 3227,4427,12816) --Joe Ilardi, Bill Rose (wrose), Marcos Flaks, Moshumi Seewoogolam, Neila Sula, Jaclyn Barnes, Craig McCormack, Rafael Rocha
    AND           HISTOMVTS.contrepartie NOT IN (10007902) --NDF Fixing tickets are excluded
    ORDER BY 4;
	
  -- *****************************************************************
  -- END OF: OPS_AS_TRADERS
  -- *****************************************************************   
	END OPS_AS_TRADERS; 



  -- *****************************************************************
  -- Description:PROCEDURE  TRADES_NDF_BOOKED_DELIVERABLE
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013	Oliver South	Changed column ordering PROJ-26
  --01 JUL 2016 Gustavo Binnie PMOG-971 - USD/BRL TRADES ON 2689 ACCOUNTS ARE ALLOWED
  -- *****************************************************************
PROCEDURE TRADES_NDF_BOOKED_DELIVERABLE
     (
          p_CURSOR OUT T_CURSOR
     )
AS
BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADES_NDF_BOOKED_DELIVERABLE
  -- *****************************************************************   
  OPEN p_CURSOR FOR         
         SELECT               
								  FUND_BOOK_STRATEGY.BOOK_NAME Strategy
								, FUND_BOOK_STRATEGY.Fund_NAME Fund
								, Trades.sicovam Sicovam
								, Trades.refcon Trade_ID
								, FUND_BOOK_STRATEGY.BOOK_NAME Strategy
								, Instrument.reference Ticker
								, TRUNC(Trades.DATENEG) d$Trade_Date
								, TRUNC(Trades.DATEVAL) d$Value_Date
								, PrimeBroker.NAME PrimeBroker 
        FROM					histomvts Trades 
        INNER JOIN				titres Instrument 
        ON						Instrument.sicovam = Trades.sicovam 
        INNER JOIN				tiers PrimeBroker 
        ON						PrimeBroker.IDENT = Trades.DEPOSITAIRE 
        INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
        ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 
        WHERE
              Trades.BACKOFFICE                                 NOT IN (192,11,13,17,26,27,220,248,252)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   -- checked mo canceled
              AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate                            -5)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --recent trades
              AND Instrument.TYPE                               IN ( 'E','X')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         --booked as FX or swap
              AND (   Trades.devisepay                          IN (54612563,54678092,54742096,54742617,54742864,54871888,55135826,55133266,55267927,55269972,55400786,55592270,55593040,55727426,55859012,55918920,55987780) 
                      OR 
                      Instrument.marche                         IN (54612563,54678092,54742096,54742617,54742864,54871888,55135826,55133266,55267927,55269972,55400786,55592270,55593040,55727426,55859012,55918920,55987780) 
                  ) 
             AND PrimeBroker.NAME NOT IN ('UBS- ETD- 009BTG2','UBS- EQTY- I0055470','BTG- PACTUAL- GEMM','INTERNAL TRADES ARF','UBS -ETD- 009BTGAB','INTERNAL TRADES GEMM') --allowed depositaries
             AND (Trades.SICOVAM <> 67607864 OR PrimeBroker.NAME NOT LIKE '%2689%') -- USD/BRL TRADES ON 2689 ACCOUNTS ARE ALLOWED
			 AND (Trades.SICOVAM <> 67603204 OR PrimeBroker.NAME NOT LIKE '%CELFIN%') -- USD/CLP TRADES ON CELFIN ACCOUNTS ARE ALLOWED
        order by 3 ASC;
        /* Reports all London Strategy FX trades that should be set as NDFs */
  -- *****************************************************************
  -- END OF: TRADES_NDF_BOOKED_DELIVERABLE
  -- *****************************************************************          
END TRADES_NDF_BOOKED_DELIVERABLE;


-- *****************************************************************
  -- Description:PROCEDURE OTC_BOX_SWAP
	--
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 27 Jul 2013    Oliver South     Created.
  -- 20 March 2014  Oliver South	 Excluded swaps on bank loans
  -- 14 March 2016  Gustavo Binnie	 PMOG-894 - Bug Fix
  -- 02 FEB 2018    Jeff Yu   PMOG-1194 update logic to only capture positions having opposite Qty direction
  -- *****************************************************************
PROCEDURE OTC_BOX_SWAP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN OF: OTC_BOX_SWAP
 -- *****************************************************************   
     OPEN p_CURSOR FOR

			SELECT 
            BOXED.Fund_NAME                     Fund_NAME
          , BOXED.BOOK_NAME                     BOOK_NAME
          , BOXED.sicovam                       sicovam
          , TITRES.Reference                    
          , TIERS2.name                         Depositary
          , SUM(TRADES.quantite)                Quantity
    
FROM 
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (14414,90565) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
            SELECT
                    POSITION.Fund_NAME
                  , POSITION.BOOK_NAME
                  , POSITION.sicovam
                  , COUNT(POSITION.depositaire)
            FROM (
                          SELECT 
                                    FUND_BOOK_STRATEGY.Fund_NAME
                                  , FUND_BOOK_STRATEGY.BOOK_NAME
                                  , TIERS.name
                                  , HISTOMVTS.sicovam
                                  , HISTOMVTS.depositaire
                                  , SUM(HISTOMVTS.quantite)
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM  HISTOMVTS
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (14414,90565) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire

                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                          
							 AND  HISTOMVTS.depositaire NOT IN (SELECT BTG_MAPPING_CODE.INPUT_CODE
                                          FROM BTG_MAPPING_CODE
                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = 9
                                          AND BTG_MAPPING_CODE.TYPE_ID IN (54, 35)
                                          )--Bank Loan Depositaries, BTG Internal Depostiaries
              GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, TIERS.name, HISTOMVTS.sicovam, HISTOMVTS.depositaire 
						  HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000
              order by FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                          )       POSITION --this creates a table of all positions and indicates if long or short
            GROUP BY POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            HAVING COUNT(POSITION.depositaire) >1 and COUNT(DISTINCT POSITION.DIRECTION) > 1
            order by  POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            )     BOXED --this table shows the positions where there is a long and a short position
ON BOXED.Fund_NAME = FUND_BOOK_STRATEGY2.Fund_NAME
AND BOXED.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXED.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam

WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
AND 	(
									(TITRES.type = 'S' AND  TITRES.default_event_leg1 = 0) --include swaps but not CDS
									OR
									(TITRES.type = 'D' AND TITRES.affectation = 31) --include swaption
									)
GROUP BY boxed.fund_name, boxed.book_name, boxed.sicovam, titres.REFERENCE, tiers2.NAME
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000

UNION ALL--ABOVE ARE THE BOXED POSITIONS WITHIN THE FUND (IN THE SAME STRATEGY) / BELOW ARE THE BOXED POSITIONS IN DIFFERENT FUNDS (IN THE SAME STRATEGY) 

SELECT 
            FUND_BOOK_STRATEGY2.Fund_NAME
          , BOXEDFUND.BOOK_NAME
          , BOXEDFUND.sicovam
          , TITRES.Reference                    
          , TIERS2.name                         Depositary
          , SUM(TRADES.quantite)                Quantity
       
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (14414,90565) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
Select DIRECTION.BOOK_NAME,DIRECTION.sicovam,count(DIRECTION.direction) FROM (
                  SELECT DISTINCT   FUND_BOOK_STRATEGY.BOOK_NAME
                                  , HISTOMVTS.sicovam
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM  HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (14414,90565) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                          AND  HISTOMVTS.depositaire NOT IN (SELECT BTG_MAPPING_CODE.INPUT_CODE
                                          FROM BTG_MAPPING_CODE
                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = 9
                                          AND BTG_MAPPING_CODE.TYPE_ID IN (54, 35)
                                          )   --Bank Loan Depositaries, BTG Internal Depostiaries
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                         HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000) DIRECTION
                          GROUP BY DIRECTION.BOOK_NAME,DIRECTION.sicovam
                          HAVING count(DIRECTION.direction)>1)   BOXEDFUND
                          
ON BOXEDFUND.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXEDFUND.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam

WHERE     trades.backoffice not in (11,13,17,26,27,192,220,248,252)
AND 	(
									(TITRES.type = 'S' AND  TITRES.default_event_leg1 = 0) --include swaps but not CDS
									OR
									(TITRES.type = 'D' AND TITRES.affectation = 31) --include swaption
									)
GROUP BY FUND_BOOK_STRATEGY2.Fund_NAME, BOXEDFUND.book_name, BOXEDFUND.sicovam, titres.REFERENCE, tiers2.NAME
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000
ORDER BY 3,1,2;
      

 -- *****************************************************************
 -- END OF: OTC_BOX_SWAP
 -- *****************************************************************             
END OTC_BOX_SWAP;


  -- *****************************************************************
  -- Description: PROCEDURE CDS_NOT_T3
	-- collects all CDS trades for ARF ARF 2 and GEMM that do not settle cash on T+3*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE CDS_NOT_T3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: CDS_NOT_T3
 -- *****************************************************************  
      OPEN p_CURSOR FOR
      SELECT          
        Trades.sicovam            Sicovam,
        Trades.refcon             TradeId,
        trader.name               Trader,
        Instrument.libelle        Name,
        trunc(Trades.DATENEG)     d$TradeDate,
        trunc(Trades.DATEVAL)     d$ValueDate,
        PrimeBroker.NAME          PrimeBroker,
        business_events.name      BusinesEvent    
      FROM
        histomvts                 Trades 
      INNER JOIN ( 
                  SELECT 
                      CONNECT_BY_ROOT(FOLIO.ident)          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)           AS TOP_FUND_NAME
                    , FOLIO.ident AS STRATEGY_ID
                    ,level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- IN (14414,90565)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID  =    Trades.OPCVM            
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam    
      INNER JOIN      riskusers trader
      ON              trader.ident                                  = Trades.operateur   
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE    
      WHERE           
              Trades.DATENEG             >     trunc(sysdate)-5
      AND     Instrument.affectation     =     22 --CDS
      AND     business_events.compta     =     1 --Not coupons
      AND     trunc(Trades.DATEVAL)      <     BTG_BUSINESS_DATE(Trades.DATENEG, +3) --settlement date less than 3 business days
      AND     Trades.backoffice         NOT IN (192,11,13,17,26,27,220,248,252) --Deleted/Cancelled trades
      ORDER BY 3;

 -- *****************************************************************
 -- END  OF: CDS_NOT_T3
 -- *****************************************************************  
END CDS_NOT_T3;



-- *****************************************************************
  -- Description: PROCEDURE SWAP_SETTLE_DT_WRONG
	-- collects all IRS trades for ARF ARF 2 and GEMM that do not settle cash on T+2*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --11 SEP 2018  Jeff Yu    Modified (APPSUPP-5134)
  -- *****************************************************************

  PROCEDURE SWAP_SETTLE_DT_WRONG
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: SWAP_SETTLE_DT_WRONG
 -- *****************************************************************      
      OPEN p_CURSOR FOR
      SELECT       
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Instrument.libelle                    Instrument_Name
					, Instrument.reference                  Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
					, trunc(Trades.DATEVAL)                 d$Value_Date
					, Trades.Montant                        n$Net_Amount
					, DEVISE_TO_STR(trades.devisepay)       Sett_Currency
					, DEVISE_TO_STR(instrument.devisectt)   Inst_Currency
					, business_events.name                  Business_Event    
      FROM            
                  histomvts Trades    
      INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                     AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                  , FOLIO.ident                                                           AS STRATEGY_ID
                  , FOLIO.name                                                            AS STRATEGY_NAME
                  ,level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- IN (14414,90565)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
      ON          FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
      INNER JOIN  business_events
      ON          business_events.id                            = Trades.type 
      INNER JOIN  titres Instrument
      ON          Instrument.sicovam                            = Trades.sicovam    
      INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur
      WHERE       Trades.DATENEG                                > trunc(sysdate) - 5 --recent trades
      AND         Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --Not deleted
      AND         business_events.compta = 1 --trades affecting position
      AND         (Instrument.type = 'S' AND (Instrument.default_event_leg1 =0 OR Instrument.default_event_leg1 is null)) --swaps, not CDS
      AND         Trades.Montant !=0 --trades with cash flow
	  AND      (
                        (Trades.type=360 and 
                          Trades.DEPOSITAIRE NOT IN (select code from TIERSPROPERTIES where NAME= 'MarkIT CH CODE' and value is not null)
                        )
                 OR Trades.type != 360
                   )
      AND             
                  (
                  (instrument.devisectt NOT IN (55400526,55001680,55857753,55727426,54739268,54613316,55923524) AND trunc(Trades.DATEVAL) < BTG_BUSINESS_DATE(Trades.DATENEG, +2)) 
                  OR 
                  (instrument.devisectt IN (55400526,55001680,55857753,55727426,54739268,54613316,55923524) AND trunc(Trades.DATEVAL) < BTG_BUSINESS_DATE(Trades.DATENEG, +1))
                  ) --CAD, GBP, MXN, RUB, TRY, AUD, USD all settle T+1
      ORDER BY        1,2 ASC;

/*collects all IRS trades for ARF ARF 2 and GEMM that do not settle cash on T+2*/
 -- *****************************************************************
 -- END  OF: SWAP_SETTLE_DT_WRONG
 -- *****************************************************************    
END SWAP_SETTLE_DT_WRONG;



  -- *****************************************************************
  -- Description: PROCEDURE FXSWAP_SPLIT
	-- get the two trades that compose a full operation of forex.
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --08 Jul 2014 Oliver South	Changed the check to look at trades booked in different strategies
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE FXSWAP_SPLIT
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: FXSWAP_SPLIT
 -- **************************************************************** 
    OPEN p_CURSOR FOR
    
SELECT        
                  FUND_BOOK_STRATEGY.BOOK_NAME           Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME           Fund_Name
                , TRADE_SWAP.REFCON                      Swap_Leg_1
                , TRADE_SWAP.LINKEDREFCON                Swap_Leg_2
                , SECURITY.LIBELLE                       FX_NAME
                , TRADE.DATENEG                          D$TRADEDATE
                , TRADER.NAME                            Trader
    FROM        HISTOMVTS                                TRADE
    INNER JOIN  FOREX_SWAP                               TRADE_SWAP
    ON          TRADE_SWAP.REFCON  = TRADE.REFCON
    INNER JOIN  TITRES   SECURITY
    ON          SECURITY.SICOVAM   = TRADE.SICOVAM
    INNER JOIN  riskusers trader
    ON          trader.ident       = Trade.operateur
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                      , FOLIO.ident                                                           AS STRATEGY_ID
                      , FOLIO.name                                                            AS STRATEGY_NAME
                      ,level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident  in  (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident    = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON        FUND_BOOK_STRATEGY.STRATEGY_ID    = TRADE.OPCVM
    WHERE     TRADE.BACKOFFICE                  NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
    AND       TRADE_SWAP.LINKEDREFCON !=0 --some trades appear in the FOREX_SWAP table but don't have the other leg so this removes them. Likely booked as swap but meant to be outright.
    AND       TRADE.dateneg > TRUNC(SYSDATE)-40 --looks back over the previous month + some days to enable month end problems to be caught
MINUS  --above select is picking up all the first legs and below the second leg. If a different fund/strategy then they will be reported
  SELECT        
                  FUND_BOOK_STRATEGY.BOOK_NAME           Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME           Fund_Name
                , TRADE_SWAP.REFCON                      Swap_Leg_1
                , TRADE_SWAP.LINKEDREFCON                Swap_Leg_2
                , SECURITY.LIBELLE                       FX_NAME
                , TRADE.DATENEG                          D$TRADEDATE
                , TRADER.NAME                            Trader
    FROM        HISTOMVTS                                TRADE
    INNER JOIN  FOREX_SWAP                               TRADE_SWAP
    ON          TRADE_SWAP.LINKEDREFCON  = TRADE.REFCON
    INNER JOIN  TITRES   SECURITY
    ON          SECURITY.SICOVAM   = TRADE.SICOVAM
    INNER JOIN  riskusers trader
    ON          trader.ident       = Trade.operateur
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                      , FOLIO.ident                                                           AS STRATEGY_ID
                      , FOLIO.name                                                            AS STRATEGY_NAME
                      ,level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident  in  (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident    = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON        FUND_BOOK_STRATEGY.STRATEGY_ID    = TRADE.OPCVM
    WHERE     TRADE.BACKOFFICE                  NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
    AND       TRADE_SWAP.LINKEDREFCON !=0
    AND       TRADE.dateneg > TRUNC(SYSDATE)-40
	ORDER BY 1,2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

 -- *****************************************************************
 -- END  OF: FXSWAP_SPLIT
 -- **************************************************************** 
 
END FXSWAP_SPLIT;


  -- *****************************************************************
  -- Description: PROCEDURE EQ_SHARES_FRACTIONAL_QUANTITY
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  --03 Jul 2013		Oliver South	     Added futures and all strategies.
  --23 Nov 2016    Jeff Yu     Filter out trades older than 1 year from report (PMOG-1058).
  -- ----------------------------------------------------------------
   PROCEDURE EQ_SHARES_FRACTIONAL_QUANTITY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQ_SHARES_FRACTIONAL_QUANTITY 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR
            SELECT 
            FUND_BOOK_STRATEGY.BOOK_NAME                Strategy
          , FUND_BOOK_STRATEGY.Fund_NAME                FUND
          , TRADES.refcon                               TRADE_ID
          , TRADES.sicovam                              SICOVAM
          , TITRES.reference                            REFERENCE
          , TITRES.libelle                              NAME
          , TRADES.dateneg                              d$TRADE_DATE
          , TRADES.DATEVAL                              d$VALUE_DATE
          , TRADES.QUANTITE                             QUANTITY
          , RISKUSERS.name                                  Operator    
          , AFFECTATION.libelle                         Allotment
      FROM histomvts TRADES
  INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
              ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
              --START WITH FOLIO.ident IN (14414)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
            ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm
    INNER JOIN TITRES
    ON         TITRES.sicovam =   TRADES.sicovam
    AND        TITRES.type IN ('A','G','F') --Share template, CFD, Futures
    AND        TITRES.affectation NOT IN (33, 45) --FRA, External Funds
    INNER JOIN RISKUSERS
    ON        RISKUSERS.ident =  TRADES.operateur   
    INNER JOIN BUSINESS_EVENTS
    ON        BUSINESS_EVENTS.ID = TRADES.TYPE
    AND BUSINESS_EVENTS.COMPTA = 1 --position affecting tickets only
    INNER JOIN AFFECTATION
    ON AFFECTATION.IDENT = TITRES.AFFECTATION
    WHERE     TRADES.DATENEG>=add_months( sysdate, -12 ) --Exclude trades older than 1 year
    AND       TRADES.backoffice NOT IN (11, 13, 180, 182, 186, 190, 192, 220, 246, 248, 250, 252) --ignore cancelled trades
    AND       TRADES.quantite != round(TRADES.quantite) --Quantity is not an integer
    AND       TRADES.courtier NOT IN (10010875, 10010878) --ignore RESET(CFD) and INTERNAL TRANSFER (STRAT)
    ORDER BY 1,2,7;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF EQ_SHARES_FRACTIONAL_QUANTITY 
  -- *************************************************************************** 		
 END EQ_SHARES_FRACTIONAL_QUANTITY;




 -- *****************************************************************
 -- Description: PROCEDURE TRADES_DEP_INTERNAL
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013	Oliver South	Changed column order PROJ-26
 --28 Mar 2014	Oliver South	Added NY strategies within this check
 --25 Nov 2016   Jeff Yu    Ignore X-Closed Strats from report
 -- ----------------------------------------------------------------    
  PROCEDURE TRADES_DEP_INTERNAL
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_DEP_INTERNAL 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

    SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event        
    FROM          histomvts Trades    
    INNER JOIN    riskusers 
    ON            Trades.operateur     = riskusers.ident    
    INNER JOIN    titres security 
    ON            security.sicovam     = trades.sicovam        
    INNER JOIN    tiers CP
    ON            CP.IDENT             = Trades.depositaire    
    INNER JOIN    business_events 
    ON            business_events.id   = Trades.type    
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  Trades.OPCVM    
    WHERE Trades.BACKOFFICE                   NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND TRADES.depositaire                    IN     
              (
              SELECT int_dep.input_code
              FROM btg_mapping_code int_dep
              WHERE int_dep.type_id = 35 
              )
    AND BOOK_ID                               IN   
              (
              SELECT ldn_folio.input_code
              FROM btg_mapping_code ldn_folio
              WHERE ldn_folio.type_id = 33
              AND   ldn_folio.output_code IN ('LDN','NY')
              )
    AND business_events.compta = 1
    AND FUND_BOOK_STRATEGY.BOOK_NAME NOT IN ('Systematic Rates','X-Closed Strats')
    AND security.type != 'L'
	ORDER BY 1,2;
 
  -- ***************************************************************************
  -- END OF TRADES_DEP_INTERNAL 
  -- *************************************************************************** 		 
	END TRADES_DEP_INTERNAL;



 -- *****************************************************************
 -- Description: PROCEDURE TRADES_DEP_INTERNAL
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 -- ----------------------------------------------------------------        
  PROCEDURE INTERNAL_TRADE_NO_TRANSFER
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF INTERNAL_TRADE_NO_TRANSFER 
  -- *************************************************************************** 		 	
		OPEN p_CURSOR FOR

      SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event    
        FROM        histomvts Trades            
        INNER JOIN  riskusers 
        ON          Trades.operateur = riskusers.ident        
        INNER JOIN  titres security 
        ON          security.sicovam = trades.sicovam      
		AND         security.type != 'L'					--exclude repos      
        INNER JOIN  tiers CP
        ON          CP.IDENT = Trades.contrepartie        
        INNER JOIN  business_events 
        ON          business_events.id = Trades.type        
        INNER JOIN ( 
                      SELECT       CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                                  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                                  , FOLIO.ident                                                            AS STRATEGY_ID
                                  , FOLIO.name                                                             AS STRATEGY_NAME
                                  , level
                      FROM FOLIO
                      WHERE LEVEL                       >= 4
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                      CONNECT BY PRIOR  FOLIO.ident     = FOLIO.mgr  
                  )  FUND_BOOK_STRATEGY
    ON               FUND_BOOK_STRATEGY.STRATEGY_ID     = Trades.OPCVM
    WHERE            trades.dateneg                     >  sysdate - 5 --recent trades
    AND              Trades.BACKOFFICE                 NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND              business_events.id                NOT IN ('161', '6','274','2','187') --Transfer, FX, CFD - Financing Closeout, Coupon, Swap Rest
	AND		         security.type					   NOT IN ('X','E','C') --Not FX or Commission
    AND TRADES.contrepartie IN
                                (10010898    --PB TRANSFER WELLS - GEMM
                                ,10010899    --PB TRANSFER WELLS - DMF
                                ,10011155    --PB TRANSFER UBS-ML
                                ,10010769    --PB TRANSFER UBS
                                ,10010768    --PB TRANSFER MS
                                ,10010876    --INTERNAL TRANSFER (INT)
                                ,10010875    --INTERNAL TRANSFER (STRAT)
                                ,10010767    --PB TRNSFR UBS
                                ,10010766)	 --PB TRNSFR MS
	ORDER BY 1,2;  
    

  -- ***************************************************************************
  -- END OF INTERNAL_TRADE_NO_TRANSFER 
  -- *************************************************************************** 	
	END INTERNAL_TRADE_NO_TRANSFER;



  -- *****************************************************************
 -- Description: PROCEDURE TRADES_INTERNAL_NOT_NET_ZERO
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- 02 FEB 2018    Jeff Yu   PMOG-1194 Limit to only show trades for past 5 business days
 -- ----------------------------------------------------------------  
   PROCEDURE TRADES_INTERNAL_NOT_NET_ZERO
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_INTERNAL_NOT_NET_ZERO 
  -- ***************************************************************************			
      OPEN p_CURSOR FOR
      SELECT          
                      Trades.sicovam                                  Sicovam
                      ,FUND_BOOK_STRATEGY.Fund_NAME                   Fund_name
                      ,Instrument.libelle                             Name
                      ,Instrument.reference                           Ticker
                      ,trunc(Trades.DATENEG)                          d$Trade_Date
                      ,trunc(Trades.DATEVAL)                          d$Value_Date
                      ,round(sum(Trades.QUANTITE*Instrument.nominal),6)      Quantity
                      ,sum(Trades.montant)                            n$Net_Amount
      FROM            histomvts Trades 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      INNER JOIN ( 
                  SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                          , FOLIO.ident                                                           AS STRATEGY_ID
                          , FOLIO.name                                                            AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 3
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                )     FUND_BOOK_STRATEGY
      ON              FUND_BOOK_STRATEGY.STRATEGY_ID     =   Trades.OPCVM
      INNER JOIN      riskusers trader
      ON              trader.ident                       =   Trades.operateur
      WHERE           Trades.DATENEG      >=   BTG_BUSINESS_DATE(SYSDATE,-5)
      AND             Instrument.type                    != 'L' --not repos
      AND             trades.contrepartie                IN (10010875, 10010876) --Internal transfer
      AND             Trades.BACKOFFICE                 NOT IN (192,11,13,17,26,27,220,248,252) -- checked mo canceled
      GROUP BY 
                      Trades.sicovam, 
                      FUND_BOOK_STRATEGY.Fund_NAME, 
                      Instrument.libelle, 
                      Instrument.reference, 
                      trunc(Trades.DATENEG), 
                      trunc(Trades.DATEVAL)   
      HAVING 
      abs(sum(Trades.QUANTITE*Instrument.nominal)) > 0.01 
      OR abs(SUM(Trades.montant)) > 0.5
      ORDER by        5,1,2 ASC;

  -- ***************************************************************************
  -- END OF TRADES_INTERNAL_NOT_NET_ZERO 
  -- ***************************************************************************	
	END TRADES_INTERNAL_NOT_NET_ZERO;



 -- *****************************************************************
  -- Description  PROCEDURE CLEARED_WRONG_BUSINESS_EVENT
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- 20 Jun 2018     Jeff Yu     Modified (PMGMRISK-228)
  -- *****************************************************************
  PROCEDURE CLEARED_WRONG_BUSINESS_EVENT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CLEARED_WRONG_BUSINESS_EVENT
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
    SELECT                  Trades.refcon                   Trade_ID
                          , be.name                         Business_Event
                          , FUND_BOOK_STRATEGY.BOOK_NAME    Top_Level_Strategy
                          , folio.name                      Folio_Name
                          , FUND_BOOK_STRATEGY.FUND_NAME    Fund
                          , PrimeBroker.NAME                Depositary
                          , Trades.sicovam                  SICOVAM
                          , Instrument.reference            REFERENCE
                          , trader.name                     Trader
                          , Trades.quantite                 Quantity
                          , Trades.dateneg                  d$Trade_Date
                          , Trades.dateval                  d$Value_Date


      from                histomvts Trades
      INNER JOIN          tiers PrimeBroker
      ON                  PrimeBroker.IDENT   =  Trades.DEPOSITAIRE
      INNER JOIN          titres Instrument
      ON                  Instrument.sicovam  =  Trades.sicovam
      INNER JOIN          riskusers trader
      ON                  trader.ident        =  Trades.operateur
      INNER JOIN          folio
      ON                  folio.ident         =  Trades.opcvm
      INNER JOIN          business_events BE
      ON                  BE.id = Trades.TYPE and BE.COMPTA=1
      INNER JOIN          tiersproperties tp
      ON                  Trades.depositaire = tp.code
      INNER JOIN         ( 
                                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                 AS TOP_FUND_ID
                                            , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME 
                                            , FOLIO.ident                                                         AS STRATEGY_ID 
                                            , FOLIO.name                                                          AS STRATEGY_NAME
                                            FROM FOLIO
                                            WHERE LEVEL                    > 2
                                                START WITH FOLIO.ident      IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                                               CONNECT BY PRIOR FOLIO.ident          = FOLIO.mgr                                 
                           )        FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID  = Trades.opcvm
      WHERE
                            Trades.backoffice not in (192,11,13,17,26,27,220,248,252) and
                            be.id not in (161,360)  and --Not transfer trades nor expires
                            Trades.TYPE not in (1,140,1444,1494) and
                            tp.name = 'MarkIT CH CODE' and
                            tp.value is not null
       ORDER BY 5,4,11;                    
  
  
	-- ***************************************************************************
  -- END OF CLEARED_WRONG_BUSINESS_EVENT 
  -- ***************************************************************************	
  END CLEARED_WRONG_BUSINESS_EVENT;



  -- *****************************************************************
  -- Description  PROCEDURE TRADES_BOOKED_IN_THE_FUTURE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
 PROCEDURE TRADES_BOOKED_IN_THE_FUTURE
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADES_BOOKED_IN_THE_FUTURE
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
    SELECT
								  FUND_BOOK_STRATEGY.BOOK_NAME                     Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME                     Fund
								, Trades.sicovam                                   Sicovam
                , ta_block_to_generated.block_id                   Block_ID
								, Trades.refcon                                    Trade_ID
                , trader.name                                      Trader
								, Instrument.libelle                               Instrument_Name
                , Instrument.reference                             Ticker
								, trunc(Trades.DATENEG)                            d$Trade_Date
      FROM                   histomvts Trades       
      INNER JOIN             titres Instrument 
      ON                     Instrument.sicovam                 =  Trades.sicovam
      INNER JOIN  business_events
      ON          business_events.id                            =  Trades.type 
      INNER JOIN ( 
                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                    , FOLIO.ident                                                           AS STRATEGY_ID
                                    , FOLIO.name                                                            AS STRATEGY_NAME
                                    , level
                              FROM FOLIO
                              WHERE 
                              LEVEL >= 4
                              START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                              CONNECT BY PRIOR FOLIO.ident       =  FOLIO.mgr  
                            ) FUND_BOOK_STRATEGY
      ON                    FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
      LEFT JOIN             riskusers trader
      ON                    trader.ident                         =  Trades.operateur
      LEFT JOIN             ta_block_to_generated
      ON                    ta_block_to_generated.generated_id   =  Trades.refcon
      WHERE          
          Trades.BACKOFFICE                                           NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
          AND               trades.dateneg                       >  trunc(sysdate)                        
          AND               business_events.compta               =  1 --trades affecting position
          AND               Instrument.type                     != 'L' 
      ORDER BY        2 ASC;
    
  -- ***************************************************************************
  -- END OF TRADES_BOOKED_IN_THE_FUTURE
  -- ***************************************************************************	
  END TRADES_BOOKED_IN_THE_FUTURE;



  PROCEDURE CFD_WRONG_ACCOUNT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF CFD_WRONG_ACCOUNT
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

    SELECT              
                     FUND_BOOK_STRATEGY.BOOK_NAME                   Strategy_Name 
                   , FUND_BOOK_STRATEGY.Fund_NAME                   Fund_Name
                   , Trades.sicovam                                 Sicovam
                   , Trades.refcon                                  Trade_Id
                   , trader.name                                    Trader
                   , Instrument.libelle                             Instrument_Name
                   , Instrument.reference                           Instrument_Reference
                   , trunc(Trades.DATENEG)                          d$Trade_Date
                   , trunc(Trades.DATEVAL)                          d$Value_Date
                   , devise_to_str(Trades.devisepay)                Currency
                   , depositary.name                                Depositary
                   , business_events.name                           BusinesEvent
    FROM                            
                    histomvts                        Trades 
    INNER JOIN      business_events
    ON              business_events.id              = Trades.type
    INNER JOIN      riskusers trader
    ON              trader.ident                    = Trades.operateur
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam              = Trades.sicovam 
    INNER JOIN      tiers depositary
    ON              depositary.ident = trades.depositaire
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
    WHERE     Instrument.affectation = 12 --CFD
    AND       Trades.dateneg > '01-Jul-2013' --start date for report
    AND       depositary.name not like '%CFD%' --depostiary name must contain this text string
    AND       Trades.backoffice  NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
	;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF CFD_WRONG_ACCOUNT 
  -- ***************************************************************************         
	END CFD_WRONG_ACCOUNT;


-- *****************************************************************
-- Description:     PROCEDURE  DIVIDEND_WITH_FEES
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 Jun 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE DIVIDEND_WITH_FEES (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: DIVIDEND_WITH_FEES
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

select 
riskusers.name trader, 
FUND_BOOK_STRATEGY.Fund_NAME Fund, 
FUND_BOOK_STRATEGY.book_name Strategy, 
FUND_BOOK_STRATEGY.strategy_NAME Folio, 
histomvts.refcon TradeID, 
histomvts.dateneg Trade_Date, 
histomvts.dateval Settlement_Date, 
titres.reference instrument_reference, 
titres.libelle instrument_name, 
histomvts.fraismarche Market_Fee, 
histomvts.fraiscounterparty Counterparty_Fee, 
histomvts.fraiscourtage Broker_Fee, 
histomvts.quantite QTY, 
histomvts.cours price, 
histomvts.montant Net_Amount, 
business_events.name business_event 
 
 
 
 
from histomvts 
 
INNER JOIN 
        ( SELECT 
                CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID , 
                CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME , 
                FOLIO.ident AS STRATEGY_ID , 
                FOLIO.name AS STRATEGY_NAME , 
                level 
             FROM FOLIO 
             WHERE LEVEL >= 4 
             START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) 
          CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
        ) FUND_BOOK_STRATEGY 
        ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM 
 
left join business_events 
on business_events.id=histomvts.type 
 
left join riskusers 
on riskusers.ident=histomvts.operateur 
 
left join titres 
on titres.sicovam=histomvts.sicovam 
 
where 
histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
and histomvts.type=147 
and (histomvts.fraiscounterparty !=0 or histomvts.fraiscourtage !=0 or histomvts.fraismarche !=0)
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

DIVIDEND_WITH_FEES;

-- *****************************************************************
-- END OF: DIVIDEND_WITH_FEES
-- *****************************************************************


  
   -- *****************************************************************
  -- Description  PROCEDURE CLEARED_2DIFFERENT_CHS
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- 24-OCT-2014  Gustavo Binnie	 PMOG-621 - Changes to show only recent trades or open positions
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE CLEARED_2DIFFERENT_CHS
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CLEARED_2DIFFERENT_CHS
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
SELECT                        h1.refcon                     Trade_ID
                            , be1.name                      Business_Event
                            , FUND_BOOK_STRATEGY.BOOK_NAME  Top_Level_Strategy
                            , folio.name                    Folio_Name
                            , FUND_BOOK_STRATEGY.FUND_NAME  Fund
                            , PrimeBroker.NAME              Depositary
                            , h1.sicovam                    SICOVAM
                            , Instrument.reference          REFERENCE
                            , trader.name                   Trader
                            , h1.quantite                   Quantity                            
                            , h1.dateneg                    d$Trade_Date
                            , h1.dateval                    d$Value_Date
                            
            FROM            histomvts h1
            INNER JOIN      tiers PrimeBroker
            ON              PrimeBroker.IDENT = h1.DEPOSITAIRE
            INNER JOIN      titres Instrument
            ON              Instrument.sicovam = h1.sicovam
            INNER JOIN      riskusers trader
            ON              trader.ident = h1.operateur
            INNER JOIN      business_events BE1
            ON              BE1.id = h1.TYPE
            and             be1.compta = 1
            INNER JOIN      folio
            ON              folio.ident =h1.opcvm
            INNER JOIN         ( 
                                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                 AS TOP_FUND_ID
                                            , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME 
                                            , FOLIO.ident                                                         AS STRATEGY_ID 
                                            , FOLIO.name                                                          AS STRATEGY_NAME
                                            FROM FOLIO
                                            WHERE LEVEL                    > 2
                                                START WITH FOLIO.ident     IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                                               CONNECT BY PRIOR FOLIO.ident          = FOLIO.mgr                                 
                                )        FUND_BOOK_STRATEGY
            ON FUND_BOOK_STRATEGY.STRATEGY_ID  = h1.opcvm
            inner join (                                
                                                           SELECT SICOVAM, OPCVM 
                           FROM
                           (
                           SELECT H2.sicovam, H2.opcvm 
                                FROM histomvts h2
                                JOIN titres
                                ON h2.sicovam = titres.sicovam
                                INNER JOIN business_events BE
                                ON         BE.id                             = H2.type
                                AND        be.compta                         = 1
                                INNER JOIN tiersproperties tp
                                ON         h2.depositaire                    = tp.code
                                AND        tp.name                           = 'MarkIT CH CODE'
                                WHERE     
                                    tp.value is not null
                                    AND h2.backoffice NOT  IN (192,11,13,17,26,27,220,248,252)                                   
                                GROUP BY 
                                   h2.opcvm, h2.sicovam, h2.depositaire
                                HAVING 
                                  ( sum(H2.QUANTITE) <> 0 OR MAX(H2.DATENEG) >= BTG_BUSINESS_DATE(SYSDATE,-5))
                                  ) POSITIONS_0
                                GROUP BY SICOVAM, OPCVM
                                HAVING COUNT(SICOVAM || OPCVM) > 1
                              ) Positions
                      on Positions.opcvm    = h1.opcvm
                      and Positions.sicovam = h1.sicovam                                    
			WHERE
            h1.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Not cancelled trades                
            order by 5,4,11;
 
 	-- ***************************************************************************
  -- END OF CLEARED_2DIFFERENT_CHS
  -- ***************************************************************************	
  END CLEARED_2DIFFERENT_CHS;

     -- *****************************************************************
  -- Description  PROCEDURE TRADES_OFFBOARDED_CPTIES
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 05-MAY-2016      Gustavo Binnie    Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *********************************************************
  PROCEDURE TRADES_OFFBOARDED_CPTIES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADES_OFFBOARDED_CPTIES
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
SELECT  Fund_NAME                             Fund,
        BOOK_NAME                             Strategy,
        TRADES.refcon                         Trade_ID,
        Instrument.sicovam                    sicovam,
        Instrument.reference                  Instrument_Name,
        CPTY.NAME                             Counterparty,
        BRKR.NAME                             Broker,
        CPTY2.NAME                            Counterparty2,
        TRADES.dateneg                        d$Trade_Date,        
        TRADES.dateval                        d$Value_Date,
        to_char(audit_mvt.datemodif,'DD-MON-YYYY HH:MM:SS')                   Insertion_Date,
        booked.name                           Booked_By,
        trader.name                           Operator,
        business_events.NAME                  Busines_Event,
        TRADES.cours                          Price,
        TRADES.quantite                       QTY,
        TRADES.montant                        Net_Amount



FROM HISTOMVTS TRADES


INNER JOIN audit_mvt
on audit_mvt.refcon = TRADES.REFCON
and audit_mvt.version = 1 
and audit_mvt.datemodif >= trunc(sysdate-14)

INNER JOIN      riskusers booked
ON              booked.ident = audit_mvt.USERID

INNER JOIN      riskusers trader
ON              trader.ident = TRADES.OPERATEUR

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) -- 
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM

    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam    

    INNER JOIN AFFECTATION
    ON AFFECTATION.ident = Instrument.affectation

    INNER JOIN     business_events
    ON             business_events.id = Trades.type
    
    INNER JOIN    TIERS CPTY
    ON CPTY.IDENT = TRADES.CONTREPARTIE
    
    LEFT JOIN    TIERS CPTY2
    ON CPTY2.IDENT = TRADES.CONTREPARTIE2
    
    INNER JOIN    TIERS BRKR
    ON BRKR.IDENT = TRADES.COURTIER
    
WHERE 
TRADES.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)
AND (CPTY.MGR = 10025747 OR CPTY2.MGR=10025747 OR BRKR.MGR =10025747 )
    
ORDER BY 1,2,3 ;

 	-- ***************************************************************************
  -- END OF TRADES_OFFBOARDED_CPTIES
  -- ***************************************************************************	
  END TRADES_OFFBOARDED_CPTIES;
  
END PCKG_BTG_EMAILER_EXCEPT_TRANS;