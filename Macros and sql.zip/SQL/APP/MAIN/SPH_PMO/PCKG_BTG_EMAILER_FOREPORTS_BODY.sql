create or replace PACKAGE BODY         "PCKG_BTG_EMAILER_FOREPORTS" 
AS


-- *****************************************************************
-- Description:     PROCEDURE  EMLATAMRATES_POS_ACT
--                  
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 05 JAN 2018     Jeff Yu      Modified (PMGMPMO-253)
-- *****************************************************************
  PROCEDURE EMLATAMRATES_POS_ACT
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  -- *****************************************************************
-- START OF: EMLATAMRATES_POS_ACT
-- ***************************************************************** 
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           DataSet.Position_Yesterday  n$Yesterdays_Position
      ,           DataSet.Position_Today      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      FROM        (
                    SELECT      fund.name                           Fund
                    ,           folio.name                          Strategy
                    ,           security.libelle                    Instrument
                    ,           NVL(PositionYesterday.quantite, 0)  Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)      Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)  Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 134107 -- ARF
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 126251 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 134107 -- EM (Latam) Rates( ARF)
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 126251 -- EM (Latam) Rates(GEMM)
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                SELECT      folio.ident
                                                FROM        folio
                                                WHERE       level       > 1
                                                START WITH  ident       = 134107 -- EM (Latam) Rates (ARF)
                                                CONNECT BY  mgr         = prior ident
                                                UNION
                                                SELECT      folio.ident
                                                FROM        folio
                                                WHERE       level       > 1
                                                START WITH  ident       = 126251 -- EM (Latam) Rates(GEMM)
                                                CONNECT BY  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
-- *****************************************************************
-- END OF: EMLATAMRATES_POS_ACT
-- *****************************************************************       
	END EMLATAMRATES_POS_ACT;


-- *****************************************************************
-- Description:     PROCEDURE  EMFX_POS_ACT
--                  
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- 05 JAN 2018    Jeff Yu       PMGMPMO-253
-- *****************************************************************
  PROCEDURE EMFX_POS_ACT
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
       
-- *****************************************************************
-- START OF: EMFX_POS_ACT
-- ***************************************************************** 
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
                 ,DataSet.Strategy
                 ,DataSet.Instrument
                 ,ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
                 ,ROUND(DataSet.Position_Today,2)      n$Todays_Position
                 ,CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      FROM        (
                    SELECT      fund.name                           Fund
                    ,           folio.name                          Strategy
                    ,           security.libelle                    Instrument
                    ,           NVL(PositionYesterday.quantite, 0)  Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)      Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)  Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 134108 -- ARF EM FX  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14102 -- GEMM EM FX 
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 134108 -- ARF EM FX 
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14102 -- GEMM EM FX 
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 134108 -- ARF EM FX 
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14102 -- GEMM EM FX 
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
-- END OF: EMFX_POS_ACT
-- *****************************************************************      
	END EMFX_POS_ACT;


-- *****************************************************************
-- Description:     PROCEDURE  USRATES_TRADEREPORT
--    * US Rates trades done today*/            
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 20 JUN 2018    Jeff Yu     Modified (PMGMRISK-228)
-- *****************************************************************

  PROCEDURE USRATES_TRADEREPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- START OF: USRATES_TRADEREPORT
 -- *****************************************************************   
     OPEN p_CURSOR FOR

     SELECT
                      fund.name                                          Fund
                     ,STRATEGY.BOOK_NAME                                 Fund_Strategy
                     ,Trades.sicovam				               	     n$Sicovam
                     ,Trades.refcon                                      n$TradeID
                     ,trades.datecomptable                               d$EntryDate
                     ,trunc(Trades.DATENEG)                         	 d$TradeDate
                     ,trunc(Trades.DATEVAL)                         	 d$ValueDate
                     ,trader.name                                        Trader
                     ,Instrument.reference                          	 Ticker
                     ,Instrument.libelle                              	 Name
                     ,Trades.quantite                              	 	 n$Qty
                     ,nvl(Trades.QUANTITE*titres.nominal,0)              n$Nominal
                     ,Trades.Montant                                	 n$NetAmount
                     ,Trades.montantcouru                                n$Accrued
                     ,Trades.cours                                       p$8$Price
                     ,trades.fraismarche                                 n$MarketFees
                     ,trades.fraiscounterparty                           n$CounterpartyFees
                     ,trades.fraiscourtage                               n$BrokerFees
                     ,btg_get_instrument_type (Trades.sicovam)           Type
                     ,counterparty.name                                  Counterparty
      FROM            titres, histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      INNER JOIN      tiers Counterparty     
      ON              Counterparty.IDENT                             = Trades.Contrepartie
      
	  LEFT JOIN		(
                      SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
					  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)  AS SUB_BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )     STRATEGY
      ON            STRATEGY.STRATEGY_ID            = Trades.opcvm
    
      INNER JOIN    tiers fund
      ON            fund.ident                                          =        trades.entite

      INNER JOIN    riskusers trader
      ON            trader.ident                                        =        Trades.operateur
      
      WHERE         titres.sicovam                                      =        trades.sicovam
      AND Trades.backoffice                                              NOT IN  (192,11,13,17,26,27,220,248,252)
      AND titres.type                                                   !=        'L'
      AND strategy.BOOK_ID												in		(14114,33644,13275,103242,62956) --US Rates--why two US rates for ARF
      AND trunc(trades.datecomptable)                                    =       trunc(sysdate)
      AND trades.type in (1,1444)
      ORDER BY        1,2,6,13 asc;
      
/* US Rates trades done today*/
 -- *****************************************************************
 -- END OF: USRATES_TRADEREPORT
 -- *****************************************************************   
END USRATES_TRADEREPORT;
 
-- *****************************************************************
-- Description:     PROCEDURE  USRATES_TRADEREPORT
--    * US Credit trades done today*/            
-- Author:          Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 28 Jan 2012    Iniesta      Created.
-- 20 JUN 2018    Jeff Yu     Modified (PMGMRISK-228)
-- *****************************************************************

  PROCEDURE USCREDIT_TRADEREPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- START OF: USCREDIT_TRADEREPORT
 -- *****************************************************************   
     OPEN p_CURSOR FOR

     SELECT
                      fund.name                                          Fund
                     ,fund_strategy.name                                 Fund_Strategy
                     ,Trades.sicovam				               	             n$Sicovam
                     ,Trades.refcon                                      n$TradeID
                     ,trades.datecomptable                               d$EntryDate
                     ,trunc(Trades.DATENEG)                         		 d$TradeDate
                     ,trunc(Trades.DATEVAL)                         		 d$ValueDate
                     ,trader.name                                        Trader
                     ,Instrument.reference                          		 Ticker
                     ,Instrument.libelle                              	 Name
                     ,Trades.quantite                              	 	   n$Qty
                     ,nvl(Trades.QUANTITE*titres.nominal,0)              n$Nominal
                     ,Trades.Montant                                		 n$NetAmount
                     ,Trades.montantcouru                                n$Accrued
                     ,Trades.cours                                       p$8$Price
                     ,trades.fraismarche                                 n$MarketFees
                     ,trades.fraiscounterparty                           n$CounterpartyFees
                     ,trades.fraiscourtage                               n$BrokerFees
                     ,CASE
                        WHEN Instrument.type = 'A' THEN 'Share'
                        WHEN Instrument.type = 'B' THEN 'Cap and Floor'
                        WHEN Instrument.type = 'C' THEN 'Commission'
                        WHEN Instrument.type = 'D' THEN 'Derivative'
                        WHEN Instrument.type = 'E' THEN 'Exchange'
                        WHEN Instrument.type = 'F' THEN 'Future'
                        WHEN Instrument.type = 'G' THEN 'CFD'
                        WHEN Instrument.type = 'I' THEN 'Index'
                        WHEN Instrument.type = 'K' THEN 'NDF'
                        WHEN Instrument.type = 'L' THEN 'Repo'
                        WHEN Instrument.type = 'M' THEN 'Option on listed market'
                        WHEN Instrument.type = 'N' THEN 'Package'
                        WHEN Instrument.type = 'O' THEN 'Bond'
                        WHEN Instrument.type = 'P' THEN 'Loan'
                        WHEN Instrument.type = 'Q' THEN 'Commodity'
                        WHEN Instrument.type = 'R' THEN 'Rate'
                        WHEN Instrument.type = 'S' THEN 'Swap'
                        WHEN Instrument.type = 'T' THEN 'NCD'
                        WHEN Instrument.type = 'W' THEN 'Option swap'       
                        WHEN Instrument.type = 'X' THEN 'Forward'
                        ELSE 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                       END                                           	     Type
                      ,counterparty.name                                   Counterparty
      FROM            titres, histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      INNER JOIN      tiers Counterparty     
      ON              Counterparty.IDENT                             = Trades.Contrepartie
      
      INNER JOIN  (
                      SELECT      folio.ident
                                , folio.name
                                , nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND -- 93654 -- QSF
                      CONNECT BY  mgr         = prior ident
                      UNION
                      SELECT      folio.ident
                      ,           folio.name
                      ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_ARF2_MASTER_FUND --12642 -- ARF2
                      CONNECT BY  mgr         = prior ident
                      UNION
                      SELECT      folio.ident
                      ,           folio.name
                      ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND --12505 -- GEMM
                      CONNECT BY  mgr         = prior ident
                  ) strategy
      ON            strategy.ident            = Trades.opcvm

      INNER JOIN    folio fund_strategy
      ON            fund_strategy.ident                                 =        strategy.parent_ident
    
      INNER JOIN    tiers fund
      ON            fund.ident                                          =        trades.entite

      INNER JOIN    riskusers trader
      ON            trader.ident                                        =        Trades.operateur
      
      WHERE         titres.sicovam                                      =        trades.sicovam
      AND Trades.backoffice                                              NOT IN  (192,11,13,17,26,27,220,248,252)
      AND titres.type                                                   !=        'L'
      AND strategy.parent_ident                                           in     (70093,74736,103099) --US Credit
      AND trunc(trades.datecomptable)                                    =       trunc(sysdate)
      AND trades.type in (1,1444)
      ORDER BY        1,2,6,13 asc;
      
/* US Credit trades done today*/
 -- *****************************************************************
 -- END OF: USCREDIT_TRADEREPORT
 -- *****************************************************************   
END USCREDIT_TRADEREPORT;


-- *****************************************************************
-- Description:     PROCEDURE  CMBS_TRADEREPORT
--    * CMBS trades done today*/            
-- Author:          Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 20 Feb 2012    Iniesta      Created.
-- 20 JUN 2018    Jeff Yu     Modified (PMGMRISK-228)
-- *****************************************************************

  PROCEDURE CMBS_TRADEREPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- START OF: CMBS_TRADEREPORT
 -- *****************************************************************   
     OPEN p_CURSOR FOR

     SELECT
                      fund.name                                          Fund
                     ,fund_strategy.name                                 Fund_Strategy
                     ,Trades.sicovam				               	             n$Sicovam
                     ,Trades.refcon                                      n$TradeID
                     ,trades.datecomptable                               d$EntryDate
                     ,trunc(Trades.DATENEG)                         		 d$TradeDate
                     ,trunc(Trades.DATEVAL)                         		 d$ValueDate
                     ,trader.name                                        Trader
                     ,Instrument.reference                          		 Ticker
                     ,Instrument.libelle                              	 Name
                     ,Trades.quantite                              	 	   n$Qty
                     ,nvl(Trades.QUANTITE*titres.nominal,0)              n$Nominal
                     ,Trades.Montant                                		 n$NetAmount
                     ,Trades.montantcouru                                n$Accrued
                     ,Trades.cours                                       p$8$Price
                     ,trades.fraismarche                                 n$MarketFees
                     ,trades.fraiscounterparty                           n$CounterpartyFees
                     ,trades.fraiscourtage                               n$BrokerFees
                     ,CASE
                        WHEN Instrument.type = 'A' THEN 'Share'
                        WHEN Instrument.type = 'B' THEN 'Cap and Floor'
                        WHEN Instrument.type = 'C' THEN 'Commission'
                        WHEN Instrument.type = 'D' THEN 'Derivative'
                        WHEN Instrument.type = 'E' THEN 'Exchange'
                        WHEN Instrument.type = 'F' THEN 'Future'
                        WHEN Instrument.type = 'G' THEN 'CFD'
                        WHEN Instrument.type = 'I' THEN 'Index'
                        WHEN Instrument.type = 'K' THEN 'NDF'
                        WHEN Instrument.type = 'L' THEN 'Repo'
                        WHEN Instrument.type = 'M' THEN 'Option on listed market'
                        WHEN Instrument.type = 'N' THEN 'Package'
                        WHEN Instrument.type = 'O' THEN 'Bond'
                        WHEN Instrument.type = 'P' THEN 'Loan'
                        WHEN Instrument.type = 'Q' THEN 'Commodity'
                        WHEN Instrument.type = 'R' THEN 'Rate'
                        WHEN Instrument.type = 'S' THEN 'Swap'
                        WHEN Instrument.type = 'T' THEN 'NCD'
                        WHEN Instrument.type = 'W' THEN 'Option swap'       
                        WHEN Instrument.type = 'X' THEN 'Forward'
                        ELSE 'Unknown ' || Instrument.type                                                                                                                                                                                                                                                                                                                                                                                                                                               
                       END                                           	     Type
                      ,counterparty.name                                   Counterparty
      FROM            titres, histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      INNER JOIN      tiers Counterparty     
      ON              Counterparty.IDENT                             = Trades.Contrepartie
      
      INNER JOIN  (
                      SELECT      folio.ident
                                , folio.name
                                , nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND -- 93654 -- QSF
                      CONNECT BY  mgr         = prior ident
                      UNION
                      SELECT      folio.ident
                      ,           folio.name
                      ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_ARF2_MASTER_FUND --12642 -- ARF2
                      CONNECT BY  mgr         = prior ident
                      UNION
                      SELECT      folio.ident
                      ,           folio.name
                      ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND --12505 -- GEMM
                      CONNECT BY  mgr         = prior ident
                  ) strategy
      ON            strategy.ident            = Trades.opcvm

      INNER JOIN    folio fund_strategy
      ON            fund_strategy.ident                                 =        strategy.parent_ident
    
      INNER JOIN    tiers fund
      ON            fund.ident                                          =        trades.entite

      INNER JOIN    riskusers trader
      ON            trader.ident                                        =        Trades.operateur
      
      WHERE         titres.sicovam                                      =        trades.sicovam
      AND Trades.backoffice                                              NOT IN  (192,11,13,17,26,27,220,248,252)
      AND titres.type                                                   !=        'L'
      AND strategy.parent_ident                                           in     (72686,76133,93685) --CMBS
      AND trunc(trades.datecomptable)                                    =       trunc(sysdate)
      AND trades.type in (1,1444)
      ORDER BY        1,2,6,13 asc;
      
/* CMBS trades done today*/
 -- *****************************************************************
 -- END OF: CMBS_TRADEREPORT
 -- *****************************************************************   
END CMBS_TRADEREPORT;
  

   -- *****************************************************************
-- Description:     PROCEDURE  GEMM_TODAYSTRADES
-- * GEMM Trades Today*
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan			Created.
-- 19 JAN 2017    Andre Bresslau	Modified.		PMGMRISK-89
-- ********************************************************** 
  PROCEDURE GEMM_TODAYSTRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  -- *****************************************************************
 -- START OF: GEMM_TODAYSTRADES
 -- *****************************************************************  
    OPEN p_CURSOR FOR
      SELECT      fund.name               Fund
      ,           fund_strategy.name                      Fund_Strategy
      ,           SUBSTR(BTG_FOLIONAMEPATH(HISTOMVTS.OPCVM),INSTR(BTG_FOLIONAMEPATH(HISTOMVTS.OPCVM),'/',82,1)+1,200) "Strategy Full"
      ,           trader.name                             Trader
      ,           security.reference                      Ticker
      ,           security.libelle                        Name
      ,           sum(histomvts.quantite)                 n$Quantity
      ,           Round(avg(histomvts.cours),8)           Avg_Price
      ,           DEVISE_TO_STR(histomvts.devisepay)      CCY      
      

        
      FROM        histomvts
      
      INNER JOIN  tiers fund
      ON          fund.ident                = histomvts.entite
        
      INNER JOIN  (
                    SELECT      folio.ident
                    ,           folio.name
                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                    FROM        folio
                    WHERE       level       > 2
                    START WITH  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND-- 12505 -- GEMM
                    CONNECT BY  mgr         = prior ident
                  ) strategy
      ON          strategy.ident            = histomvts.opcvm
      
      INNER JOIN  folio fund_strategy
      ON          fund_strategy.ident       = strategy.parent_ident
      
      INNER JOIN  riskusers trader
      ON          trader.ident              = histomvts.operateur
      
      INNER JOIN  titres security
      ON          security.sicovam          = histomvts.sicovam
      
      WHERE       trunc(histomvts.dateneg)  = trunc(sysdate - 1)
      AND         security.type             not in ('L')
      
      GROUP BY    fund.name
      ,           fund_strategy.name
      ,           strategy.name
      ,           trader.name
      ,           security.reference
      ,           security.libelle
      ,           histomvts.devisepay
      ,           histomvts.opcvm
      
      ORDER BY    1,2,3,4,5,6;

  -- ***************************************************************************
  -- GEMM Trades Today
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
 -- *****************************************************************
 -- END OF: GEMM_TODAYSTRADES
 -- *****************************************************************       
	END GEMM_TODAYSTRADES;
  
  
 -- *****************************************************************
-- Description:     PROCEDURE  EMCREDIT_POSCHANGE
--  * EM Credit Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- ********************************************************** 
  
  PROCEDURE EMCREDIT_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
   -- *****************************************************************
 -- START OF: EMCREDIT_POSCHANGE
 -- *****************************************************************   
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      FROM        (
                    SELECT      fund.name                           Fund
                    ,           folio.name                          Strategy
                    ,           security.libelle                    Instrument
                    ,           NVL(PositionYesterday.quantite, 0)  Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)      Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)  Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 13264 -- ARF EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 26166 -- ARF2 EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14081 -- GEMM EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 24010 -- PBL EM Credit
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 13264 -- ARF EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 26166 -- ARF2 EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14081 -- GEMM EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 24010 -- PBL EM Credit
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 13264 -- ARF EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 26166 -- ARF2 EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14081 -- GEMM EM Credit
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 24010 -- PBL EM Credit
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3;
      
  -- ***************************************************************************
  -- EM Credit Position Change
  -- ***************************************************************************

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
  -- *****************************************************************
 -- END OF: EMCREDIT_POSCHANGE
 -- *****************************************************************        
	END EMCREDIT_POSCHANGE;




 -- *****************************************************************
-- Description:     PROCEDURE  GEMM_POSCHANGE_SUMMARY
--  * EM Credit Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- **********************************************************   
  PROCEDURE GEMM_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: GEMM_POSCHANGE_SUMMARY
 -- *****************************************************************     
    OPEN p_CURSOR FOR
      SELECT FUND
      , Book
      , SUM(CASE WHEN Action_Taken IN('New Position')
                 THEN pos_count 
                 ELSE 0 
             END)                                                                AS N$OPEN
      , SUM(CASE WHEN Action_Taken IN('Full Long Unwind', 'Full Short Unwind') 
                 THEN pos_count 
                 ELSE 0 
            END)                                                                 AS N$CLOSE
      , SUM(CASE WHEN Action_Taken IN('Increase In Position'
                                    , 'Decrease In Position'
                                    , 'Full Long Unwind Crossing Zero'
                                    , 'Full Short Unwind Crossing Zero') 
                 THEN pos_count ELSE 0 
            END)                                                                 AS N$CHANGE 
      , SUM(pos_count) AS N$TOTAL
        FROM (
                SELECT FUND
                , Book
                , Action_Taken
                , count(*) pos_count
                FROM (
                          SELECT      DataSet.Fund
                          ,           DataSet.Book
                          ,           DataSet.Strategy
                          ,           DataSet.Instrument
                          ,           DataSet.Position_Yesterday  
                          ,           DataSet.Position_Today      
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Yesterdays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Todays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Long Unwind'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'Full Long Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Short Unwind'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'Full Short Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'Decrease In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'Decrease In Position'
                                        ELSE
                                          'UNKNOWN'
                                      END Action_Taken
                          ,           DataSet.Strategy_Full
                          FROM        (
                                        SELECT      fund.name                                                 Fund
                                        ,           book.name                                                 Book
                                        ,           folio.name                                                Strategy
                                        ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                                              , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                                              , folio.name)                                   Strategy_Full
                                        ,           security.libelle                                          Instrument
                                        ,           NVL(PositionYesterday.quantite, 0)                        Position_Yesterday
                                        ,           NVL(PositionToday.quantite, 0)                            Position_Today
                                        ,           NVL(PositionToday.quantite, 0)
                                                    -
                                                    NVL(PositionYesterday.quantite, 0)                         Delta
                                        FROM        (
                                                      SELECT      DISTINCT
                                                                  HISTOMVTS.entite
                                                      ,           FOLIOS.parent_ident
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND -- 12505 -- GEMM
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                    ) ReportKey
                                                    
                                        INNER JOIN  tiers fund
                                        ON          fund.ident                = ReportKey.entite
                                        
                                        INNER JOIN  folio book
                                        ON          book.ident                = ReportKey.parent_ident
                                        
                                        INNER JOIN  folio
                                        ON          folio.ident               = ReportKey.opcvm
                                        
                                        INNER JOIN  titres security
                                        ON          security.sicovam          = ReportKey.sicovam
                                        AND         security.type             not in ('L')
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND-- 12505 -- GEMM
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionYesterday
                                        ON          PositionYesterday.entite    = ReportKey.entite
                                        AND         PositionYesterday.opcvm     = ReportKey.opcvm
                                        AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND--12505 -- GEMM
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionToday
                                        ON          PositionToday.entite      = ReportKey.entite
                                        AND         PositionToday.opcvm       = ReportKey.opcvm
                                        AND         PositionToday.sicovam     = ReportKey.sicovam
                                        
                                        WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                                    ) DataSet
                      ) 
                 GROUP BY   FUND
                          , Book
                          , Action_Taken
              ) 
        GROUP BY    FUND
                  , Book
       ORDER BY 1, 2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
 -- END OF: GEMM_POSCHANGE_SUMMARY
 -- *****************************************************************          
	END GEMM_POSCHANGE_SUMMARY;
  
  
-- *****************************************************************
-- Description:     PROCEDURE  GEMM_POSCHANGE
--  * GGEMM Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- 03 MAR 2017    Jeff Yu          PMGMRISK-91

  PROCEDURE GEMM_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- START OF: GEMM_POSCHANGE
 -- *****************************************************************          
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                             Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND --12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND --12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GEMM_MASTER_FUND --12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

  -- ***************************************************************************
  -- GEMM Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
-- *****************************************************************
 -- END OF: GEMM_POSCHANGE
 -- *****************************************************************              
	END GEMM_POSCHANGE;
  

  -- *****************************************************************
-- Description:     PROCEDURE  QSF_POSCHANGE_SUMMARY
--  * QSF Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 08 JAN 2014    Jun Guan      Created.
-- **********************************************************   
  PROCEDURE QSF_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: QSF_POSCHANGE_SUMMARY
 -- *****************************************************************     
    OPEN p_CURSOR FOR
      SELECT FUND
      , Book
      , SUM(CASE WHEN Action_Taken IN('New Position')
                 THEN pos_count 
                 ELSE 0 
             END)                                                                AS N$OPEN
      , SUM(CASE WHEN Action_Taken IN('Full Long Unwind', 'Full Short Unwind') 
                 THEN pos_count 
                 ELSE 0 
            END)                                                                 AS N$CLOSE
      , SUM(CASE WHEN Action_Taken IN('Increase In Position'
                                    , 'Decrease In Position'
                                    , 'Full Long Unwind Crossing Zero'
                                    , 'Full Short Unwind Crossing Zero') 
                 THEN pos_count ELSE 0 
            END)                                                                 AS N$CHANGE 
      , SUM(pos_count) AS N$TOTAL
        FROM (
                SELECT FUND
                , Book
                , Action_Taken
                , count(*) pos_count
                FROM (
                          SELECT      DataSet.Fund
                          ,           DataSet.Book
                          ,           DataSet.Strategy
                          ,           DataSet.Instrument
                          ,           DataSet.Position_Yesterday  
                          ,           DataSet.Position_Today      
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Yesterdays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Todays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Long Unwind'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'Full Long Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Short Unwind'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'Full Short Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'Decrease In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'Decrease In Position'
                                        ELSE
                                          'UNKNOWN'
                                      END Action_Taken
                          ,           DataSet.Strategy_Full
                          FROM        (
                                        SELECT      fund.name                                                 Fund
                                        ,           book.name                                                 Book
                                        ,           folio.name                                                Strategy
                                        ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                                              , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                                              , folio.name)                                   Strategy_Full
                                        ,           security.libelle                                          Instrument
                                        ,           NVL(PositionYesterday.quantite, 0)                        Position_Yesterday
                                        ,           NVL(PositionToday.quantite, 0)                            Position_Today
                                        ,           NVL(PositionToday.quantite, 0)
                                                    -
                                                    NVL(PositionYesterday.quantite, 0)                         Delta
                                        FROM        (
                                                      SELECT      DISTINCT
                                                                  HISTOMVTS.entite
                                                      ,           FOLIOS.parent_ident
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND -- 93654 -- QSF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                    ) ReportKey
                                                    
                                        INNER JOIN  tiers fund
                                        ON          fund.ident                = ReportKey.entite
                                        
                                        INNER JOIN  folio book
                                        ON          book.ident                = ReportKey.parent_ident
                                        
                                        INNER JOIN  folio
                                        ON          folio.ident               = ReportKey.opcvm
                                        
                                        INNER JOIN  titres security
                                        ON          security.sicovam          = ReportKey.sicovam
                                        AND         security.type             not in ('L')
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND-- 93654 -- QSF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionYesterday
                                        ON          PositionYesterday.entite    = ReportKey.entite
                                        AND         PositionYesterday.opcvm     = ReportKey.opcvm
                                        AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND--93654 -- QSF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionToday
                                        ON          PositionToday.entite      = ReportKey.entite
                                        AND         PositionToday.opcvm       = ReportKey.opcvm
                                        AND         PositionToday.sicovam     = ReportKey.sicovam
                                        
                                        WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                                    ) DataSet
                      ) 
                 GROUP BY   FUND
                          , Book
                          , Action_Taken
              ) 
        GROUP BY    FUND
                  , Book
       ORDER BY 1, 2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
 -- END OF: QSF_POSCHANGE_SUMMARY
 -- *****************************************************************          
	END QSF_POSCHANGE_SUMMARY;

-- *****************************************************************
-- Description:     PROCEDURE  QSF_POSCHANGE
--  * QSF Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 08 JAN 2014    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.

  PROCEDURE QSF_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- START OF: QSF_POSCHANGE
 -- *****************************************************************          
    OPEN p_CURSOR FOR
SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND --93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND --93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_QSF_MASTER_FUND --93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

  -- ***************************************************************************
  -- QSF Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
-- *****************************************************************
 -- END OF: QSF_POSCHANGE
 -- *****************************************************************              
	END QSF_POSCHANGE;

  
  
  -- *****************************************************************
-- Description:     PROCEDURE  USRATES_POSCHANGE
--  * US Rates Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- 31 JAN 2017    Jeff Yu        ARF Re-launch Emailer Procedure Update.(PMGMPMO-211)

  PROCEDURE USRATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN

-- *****************************************************************
 -- START OF: USRATES_POSCHANGE
 -- *****************************************************************      
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                        Fund
                    ,           folio.name                                       Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(fund.name) + 55)
                                          , folio.name)                          Strategy_Full
                    ,           security.libelle                                 Instrument
                    ,           NVL(PositionYesterday.quantite, 0)               Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                   Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 129603 -- ARF US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 33644 -- ARF2  US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14114 -- GEMM  US Rates  
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 129603 -- ARF  US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 33644 -- ARF2  US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14114 -- GEMM  US Rates  
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 129603 -- ARF  US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 33644 -- ARF2  US Rates  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 14114 -- GEMM  US Rates  
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                    AND         ReportKey.opcvm not in
                                                        (
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 129604 -- ARF Financing
                                                          connect by  mgr         = prior ident
                                                          union
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 44784 -- ARF2 Financing
                                                          connect by  mgr         = prior ident
                                                          union
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 14116 -- GEMM Financing
                                                          connect by  mgr         = prior ident
                                                        )
                ) DataSet
                
      ORDER BY  1,2,3;

  -- ***************************************************************************
  -- US Rates Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: USRATES_POSCHANGE
 -- *****************************************************************          
	END USRATES_POSCHANGE;

  
  -- *****************************************************************
  -- Description:     PROCEDURE  EUCORPORATE_6M
  --  * Positions in EU Corporate with last trade more than 6M ago*
  -- Author:          lUIS iNIESTA
  --  
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 01 DEC 2012    Jun Guan      Created.
    PROCEDURE EUCORPORATE_6M
  	(
       p_CURSOR OUT T_CURSOR
  	)
  	AS
  	BEGIN
     -- *****************************************************************
   -- START OF: EUCORPORATE_6M
   -- *****************************************************************
       OPEN p_CURSOR FOR
  
        SELECT      FUND_BOOK_STRATEGY.Fund_NAME                                                    AS   Fund
        ,           max(histomvts.dateneg)                                                          AS   d$LastTrade
        ,           FUND_BOOK_STRATEGY.STRATEGY_NAME                                                AS   Strategy
        ,           security.libelle                                                                AS   Name
        ,           security.reference                                                              AS   ISIN
        ,           sum(histomvts.QUANTITE*security.nominal)                                        AS   n$Position
          
        FROM        histomvts
          
        INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                                AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                              AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)      AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)       AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)      AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)       AS BOOK_NAME
                            , FOLIO.ident                                                              AS STRATEGY_ID
                            , FOLIO.name                                                               AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)--Primary funds
                            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                   ) FUND_BOOK_STRATEGY
        ON           FUND_BOOK_STRATEGY.STRATEGY_ID          =          histomvts.opcvm
        AND          FUND_BOOK_STRATEGY.BOOK_NAME            =          'EU Corporate'
        
        INNER JOIN   titres security
        ON           security.sicovam                       =           histomvts.sicovam
        
        WHERE      (security.affectation = 9 
                    OR security.type='O')
        AND         histomvts.backoffice                    NOT IN       (192,11,13,17,26,27,220,248,252)
        AND         histomvts.type                          NOT IN       (2,46,7)
        
        GROUP BY   FUND_BOOK_STRATEGY.Fund_NAME
                 , FUND_BOOK_STRATEGY.STRATEGY_NAME
                 , security.libelle
                 , security.reference
                 
        HAVING   SUM(histomvts.QUANTITE*security.nominal)    !=           0
        AND      MAX(histomvts.dateneg)                      <=           sysdate -180
        ORDER BY 2,1,3,4;
  
  /* Positions in EU Corporate with last trade more than 6M ago*/
   -- *****************************************************************
   -- END OF: EUCORPORATE_6M
   -- *****************************************************************
  END EUCORPORATE_6M;  

 
-- *****************************************************************
-- Description:     PROCEDURE  EUCORPORATE_1M
--  * Positions in Global Credit with last trade less than 6M ago and more than 3M ago*
-- Author:          Luis Iniesta
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 JAN 2015 Luis Iniesta      Created.
    PROCEDURE EUCORPORATE_1M
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
-- *****************************************************************
 -- START OF: EUCORPORATE_1M
 -- *****************************************************************
     OPEN p_CURSOR FOR

      SELECT      FUND_BOOK_STRATEGY.Fund_NAME               Fund
      ,           max(histomvts.dateneg)                     d$LastTrade
      ,           FUND_BOOK_STRATEGY.STRATEGY_NAME           Strategy
      ,           security.libelle                           Name
      ,           security.reference                         ISIN
      ,           sum(histomvts.QUANTITE*security.nominal)   n$Position  
      FROM         histomvts  
      INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                         AS TOP_FUND_ID
                        , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                        , FOLIO.ident                                                         AS STRATEGY_ID
                        , FOLIO.name                                                          AS STRATEGY_NAME
                        , level
                        FROM FOLIO
                        WHERE LEVEL >= 4
                        START WITH FOLIO.ident IN ( PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)--Primary funds
                        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                 )FUND_BOOK_STRATEGY
      ON          FUND_BOOK_STRATEGY.STRATEGY_ID               =      histomvts.opcvm
      AND         FUND_BOOK_STRATEGY.BOOK_NAME                 =      'EU Corporate'
      
      INNER JOIN  titres security
      ON          security.sicovam                              =     histomvts.sicovam
      
      WHERE       (security.affectation = 9 
                   OR security.type='O')
      AND histomvts.backoffice not in (192,11,13,17,26,27,220,248,252)
      AND histomvts.type not in (2,46,7)
      
      GROUP BY   FUND_BOOK_STRATEGY.Fund_NAME
               , FUND_BOOK_STRATEGY.STRATEGY_NAME
               , security.libelle
               , security.reference
               
      HAVING   SUM(histomvts.QUANTITE*security.nominal)         !=    0
      AND      MAX(histomvts.dateneg)                           >     sysdate -180
      AND      MAX(histomvts.dateneg)                           <=    sysdate -90
      ORDER BY 2,1,3,4;

/* Positions in EU Corporate with last trade less than 6M ago and more than 3M ago*/
 -- *****************************************************************
 -- END OF: EUCORPORATE_1M
 -- *****************************************************************
END EUCORPORATE_1M;
 
 
 -- *****************************************************************
 -- Description:     PROCEDURE  EUCORPORATE_1W
 --  * * Positions in EU Corporate with last trade less than 3M ago and more than 1M ago*/
 -- Author:          Luis Iniesta
 --  
 -- Revision History
 -- Date             Author        Reason for Change
 -- ----------------------------------------------------------------
 -- 01 DEC 2015			Luis Iniesta     Created.
     PROCEDURE EUCORPORATE_1W
 	(
      p_CURSOR OUT T_CURSOR
 	)
 	AS
 	BEGIN
  -- *****************************************************************
  -- START OF: EUCORPORATE_1W
  -- *****************************************************************
      OPEN p_CURSOR FOR
       
       SELECT      FUND_BOOK_STRATEGY.Fund_NAME               Fund
       ,           max(histomvts.dateneg)                     d$LastTrade
       ,           FUND_BOOK_STRATEGY.STRATEGY_NAME           Strategy
       ,           security.libelle                           Name
       ,           security.reference                         ISIN
       ,           sum(histomvts.QUANTITE*security.nominal)   n$Position
         
       FROM        histomvts
       
       INNER JOIN ( 
                   SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                         , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                         , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                         , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                         , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                         , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                         , FOLIO.ident                                                          AS STRATEGY_ID
                         , FOLIO.name                                                           AS STRATEGY_NAME
                         , level
                         FROM FOLIO
                         WHERE LEVEL >= 4
                         START WITH FOLIO.ident   IN  (PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)--Primary funds
                         CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
       ON           FUND_BOOK_STRATEGY.STRATEGY_ID     =       histomvts.opcvm
       AND          FUND_BOOK_STRATEGY.BOOK_NAME       =       'EU Corporate'
       
       INNER JOIN  titres security
       ON          security.sicovam                   =        histomvts.sicovam
       
       WHERE       (security.affectation = 9 
                    OR security.type='O')
       AND         histomvts.backoffice               NOT IN  (192,11,13,17,26,27,220,248,252)
       AND histomvts.type                             NOT IN  (2,46,7)
       
       GROUP BY    FUND_BOOK_STRATEGY.Fund_NAME
                 , FUND_BOOK_STRATEGY.STRATEGY_NAME
                 , security.libelle
                 , security.reference
                 
       HAVING   SUM(histomvts.QUANTITE*security.nominal)  !=  0
                AND MAX(histomvts.dateneg)                >   sysdate -90
                AND MAX(histomvts.dateneg)                <=  sysdate -30
                
       ORDER BY 2,1,3,4;
 
 /* Positions in Global Credit with last trade less than 3M ago and more than 1M ago*/
  -- *****************************************************************
  -- END OF: EUCORPORATE_1W
  -- *****************************************************************
  END EUCORPORATE_1W;


-- *****************************************************************
-- Description:     PROCEDURE  EUCORPORATE_NOW
--  * Positions in EU Corporate more than 1W and less than 1M*
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
  PROCEDURE EUCORPORATE_NOW
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
 -- START OF: EUCORPORATE_NOW
 -- ***************************************************************** 
     OPEN p_CURSOR FOR

        SELECT      FUND_BOOK_STRATEGY.Fund_NAME               Fund
        ,           max(histomvts.dateneg)                     d$LastTrade
        ,           FUND_BOOK_STRATEGY.STRATEGY_NAME           Strategy
        ,           security.libelle                           Name
        ,           security.reference                         ISIN
        ,           sum(histomvts.QUANTITE*security.nominal)   n$Position
          
        FROM        histomvts
        
        INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                            , FOLIO.ident                                                          AS STRATEGY_ID
                            , FOLIO.name                                                           AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident IN  (PCKG_BTG.FOLIO_PRIMARY_FUNDS)--(14414)--Primary funds
                            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                     ) FUND_BOOK_STRATEGY
        ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =      histomvts.opcvm
        AND            FUND_BOOK_STRATEGY.BOOK_NAME       =     'EU Corporate'
        
        INNER JOIN     titres security
        ON             security.sicovam                  =       histomvts.sicovam
        
        WHERE       (security.affectation = 9 
                     OR security.type='O')
        AND         histomvts.backoffice                NOT IN  (192,11,13,17,26,27,220,248,252)
        AND         histomvts.type NOT IN (2,46,7)
        
        GROUP BY    FUND_BOOK_STRATEGY.Fund_NAME
                  , FUND_BOOK_STRATEGY.STRATEGY_NAME
                  , security.libelle
                  , security.reference
                  
        HAVING      SUM(histomvts.QUANTITE*security.nominal)   !=   0
        AND         MAX(histomvts.dateneg) > sysdate -30
        AND         MAX(histomvts.dateneg) <= sysdate -7
        ORDER BY 2,1,3,4;

/* Positions in EU Corporate more than 1W and less than 1M*/
 -- *****************************************************************
 -- END OF: EUCORPORATE_NOW
 -- *****************************************************************
END EUCORPORATE_NOW;
  
  
-- *****************************************************************
-- Description:     PROCEDURE  GLOCREDIT_POSCHANGE
--  *Global Credit Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.

  PROCEDURE GLOCREDIT_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
   -- *****************************************************************
 -- START OF: GLOCREDIT_POSCHANGE
 -- *****************************************************************
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      FROM        (
                    SELECT      fund.name                           Fund
                    ,           folio.name                          Strategy
                    ,           security.libelle                    Instrument
                    ,           NVL(PositionYesterday.quantite, 0)  Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)      Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)  Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59370 -- ARF2 Global Credit  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59371 -- GEMM Global Credit  
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59370 -- ARF2 Global Credit  
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59371 -- GEMM Global Credit  
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON            PositionYesterday.entite    = ReportKey.entite
                    AND           PositionYesterday.opcvm     = ReportKey.opcvm
                    AND           PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59370 -- ARF2 Global Credit 
                                                connect by  mgr         = prior ident
                                                union
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 59371 -- GEMM Global Credit 
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3;
      
  -- ***************************************************************************
  -- Global Credit Position Change
  -- ***************************************************************************
 -- *****************************************************************
 -- END OF: GLOCREDIT_POSCHANGE
 -- *****************************************************************
 END GLOCREDIT_POSCHANGE;
 

-- *****************************************************************
-- Description:     PROCEDURE  EMEARATES_POSCHANGE
-- * EMEA Rates Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan        Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- 14 JUL 2016	  Gustavo Binnie  PMOG-1023

  PROCEDURE EMEARATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
   -- *****************************************************************
 -- END OF: EMEARATES_POSCHANGE
 -- ****************************************************************  
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      FROM        (
                    SELECT      fund.name                           Fund
                    ,           folio.name                          Strategy
                    ,           security.libelle                    Instrument
                    ,           NVL(PositionYesterday.quantite, 0)  Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)      Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)  Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 126578-- GEMM EM (EMEA) Rates 2016
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 126578-- GEMM EM (EMEA) Rates 2016
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 1
                                                start with  ident       = 126578-- GEMM EM (EMEA) Rates 2016
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3;
      
  -- ***************************************************************************
  -- EMEA Rates Position Change
  -- ***************************************************************************
 -- *****************************************************************
 -- END OF: EMEARATES_POSCHANGE
 -- ****************************************************************
 
 
 
 
 END EMEARATES_POSCHANGE;


-- *****************************************************************
-- Description:     PROCEDURE  EQ_VOLATILITY_TRADES
-- 
-- 'EQ Volatility'
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- 31 JAN 2017      Jeff Yu      Modified per PMGMPMO-211.
-- 27 SEP 2017      Jeff Yu      Add GDO EQ VOLATILITY in scope per PMOG-1150
-- 20 JUN 2018     Jeff Yu      Modified PMGMRISK-228 --Add new business event
-- ----------------------------------------------------------------
PROCEDURE EQ_VOLATILITY_TRADES
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
 -- *****************************************************************
 -- START OF: EQ_VOLATILITY_TRADES
 -- ****************************************************************
  OPEN p_CURSOR FOR
     SELECT   HISTOMVTS.refcon                                                               AS TRADE_ID
              ,(SELECT name 
                        FROM tiers 
                        WHERE ident=histomvts.entite)                                         AS FUND
              , HISTOMVTS.dateneg                                                             AS d$TRADE_DATE
              , BO_KERNEL_STATUS.Name                                                         AS STATUS
              , STRATEGIES.STRATEGY_NAME                                                      AS PORTFOLIO
              , COALESCE( UNDERLYING1.reference
                        , UNDERLYING2.reference
                        , UNDERLYING3.reference)                                             AS UNDERLYING
              , TITRES.prixexer                                                               AS p$2$STRIKE
              , HISTOMVTS.quantite                                                            AS n$QUANTITY
              , COALESCE(TITRES.echeance, TITRES.datefinal)                                   AS d$MATURITY
              , HISTOMVTS.cours                                                               AS p$2$PRICE
              , DECODE( TITRES.type,
                        'D', DECODE(TITRES.typepro, 
                                     1, 'Call', 
                                     2, 'Put', 
                                     3, 'Convertible Bond', 
                                     4, 'Redeemable Bond', 
                                     5, 'Index Loan', 
                                     6, 'Lock in Bond', 
                                     7, 'Redeemable Bond', 
                                     null
                                    ),
                        'M', DECODE(TITRES.typepro, 
                                     2, 'Call', 
                                     3, 'Put',     
                                     null
                                    ),
                        'F','Future',    
                        BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam)      
                      )                                                                     AS PRODUCT_TYPE
            , TITRES.reference                                                              AS INSTRUMENT
            , COURTIERS.libelle                                                             AS BROKER
      FROM    HISTOMVTS
      INNER JOIN ( 
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 128254 --'EQ Volatility' --ARF
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
					UNION
					SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 63039 --'EQ Volatility' --ARF2
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 67315 --'EQ Volatility' ---GEO
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 132412 --'EQ Volatility' ---GDO
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT   FOLIO.ident                   AS STRATEGY_ID
                           , FOLIO.name                    AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 68435 --'EQ Volatility' ----GEMM
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) STRATEGIES
    ON              STRATEGIES.strategy_id        =    HISTOMVTS.opcvm
    
    LEFT OUTER JOIN CLIENTS
    ON              CLIENTS.ident = HISTOMVTS.entite
    
    LEFT OUTER JOIN TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam
    
    LEFT OUTER JOIN TITRES UNDERLYING1 
    ON              UNDERLYING1.sicovam = TITRES.code_emet 
    
    LEFT OUTER JOIN TITRES UNDERLYING2 
    ON              UNDERLYING2.sicovam = TITRES.codesj 
    
    LEFT OUTER JOIN TITRES UNDERLYING3 
    ON              UNDERLYING3.sicovam = TITRES.codesj2
    
    LEFT OUTER JOIN COURTIERS
    ON              COURTIERS.ident = HISTOMVTS.courtier
    
    LEFT OUTER JOIN AFFECTATION
    ON              TITRES.affectation = AFFECTATION.ident
    
    LEFT OUTER JOIN BO_KERNEL_STATUS
    ON              BO_KERNEL_STATUS.id = HISTOMVTS.backoffice
    
    WHERE           HISTOMVTS.type in (1,1444)
    AND             HISTOMVTS.dateneg = trunc(BTG_BUSINESS_DATE(sysdate, -1)) 
    AND             BO_KERNEL_STATUS.ID not in (192)
    
    ORDER BY PORTFOLIO
            , UNDERLYING
            , PRODUCT_TYPE;

    
   -- *****************************************************************
 -- END OF: EQ_VOLATILITY_TRADES
 -- ****************************************************************  
    
 END EQ_VOLATILITY_TRADES;
 
 

-- *****************************************************************
-- Description:     PROCEDURE  EQ_EVENTS_TRADES
-- 
-- 'EQ Events'
-- Author:          Luis Iniesta
--  
-- Revision History
-- Date             Author        Reason for Change
-- 31 JAN 2017      Jeff Yu       Modofied for PMGMPMO-211.
-- 20 JUN 2018     Jeff Yu      Modified PMGMRISK-228 --Add new business event
-- ----------------------------------------------------------------
PROCEDURE EQ_EVENTS_TRADES
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
 -- *****************************************************************
 -- START OF: EQ_EVENTS_TRADES
 -- ****************************************************************
  OPEN p_CURSOR FOR
      SELECT   HISTOMVTS.refcon                                                               AS TRADE_ID
              ,(SELECT name 
                        FROM tiers 
                        WHERE ident=histomvts.entite)                                         AS FUND
              , HISTOMVTS.dateneg                                                             AS d$TRADE_DATE
              , BO_KERNEL_STATUS.Name                                                         AS STATUS
              , STRATEGIES.STRATEGY_NAME                                                      AS PORTFOLIO
              , COALESCE( UNDERLYING1.reference
                        , UNDERLYING2.reference
                        , UNDERLYING3.reference)                                             AS UNDERLYING
              , TITRES.prixexer                                                               AS p$2$STRIKE
              , HISTOMVTS.quantite                                                            AS n$QUANTITY
              , COALESCE(TITRES.echeance, TITRES.datefinal)                                   AS d$MATURITY
              , HISTOMVTS.cours                                                               AS p$2$PRICE
              , DECODE( TITRES.type,
                        'D', DECODE(TITRES.typepro, 
                                     1, 'Call', 
                                     2, 'Put', 
                                     3, 'Convertible Bond', 
                                     4, 'Redeemable Bond', 
                                     5, 'Index Loan', 
                                     6, 'Lock in Bond', 
                                     7, 'Redeemable Bond', 
                                     null
                                    ),
                        'M', DECODE(TITRES.typepro, 
                                     2, 'Call', 
                                     3, 'Put',     
                                     null
                                    ),
                        'F','Future',    
                        BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam)      
                      )                                                                     AS PRODUCT_TYPE
            , TITRES.reference                                                              AS INSTRUMENT
            , COURTIERS.libelle                                                             AS BROKER
      FROM    HISTOMVTS
      INNER JOIN ( 
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 127378 --'EQ Events ARF'
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
					UNION
					SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 63034 --'EQ Events ARF2'
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 68373 --'EQ Events GEMM'
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT   FOLIO.ident                   AS STRATEGY_ID
                           , FOLIO.name                    AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 95962 --'EQ Events QSF'
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) STRATEGIES
    ON              STRATEGIES.strategy_id        =    HISTOMVTS.opcvm
    
    LEFT OUTER JOIN CLIENTS
    ON              CLIENTS.ident = HISTOMVTS.entite
    
    LEFT OUTER JOIN TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam
    
    LEFT OUTER JOIN TITRES UNDERLYING1 
    ON              UNDERLYING1.sicovam = TITRES.code_emet 
    
    LEFT OUTER JOIN TITRES UNDERLYING2 
    ON              UNDERLYING2.sicovam = TITRES.codesj 
    
    LEFT OUTER JOIN TITRES UNDERLYING3 
    ON              UNDERLYING3.sicovam = TITRES.codesj2
    
    LEFT OUTER JOIN COURTIERS
    ON              COURTIERS.ident = HISTOMVTS.courtier
    
    LEFT OUTER JOIN AFFECTATION
    ON              TITRES.affectation = AFFECTATION.ident
    
    LEFT OUTER JOIN BO_KERNEL_STATUS
    ON              BO_KERNEL_STATUS.id = HISTOMVTS.backoffice
    
    WHERE           HISTOMVTS.type in (1,1444)
    AND             HISTOMVTS.dateneg = trunc(BTG_BUSINESS_DATE(sysdate, -1)) 
    AND             BO_KERNEL_STATUS.ID not in (192)
    
    ORDER BY PORTFOLIO
            , UNDERLYING
            , PRODUCT_TYPE;

    
   -- *****************************************************************
 -- END OF: EQ_EVENTS_TRADES
 -- ****************************************************************  
    
 END EQ_EVENTS_TRADES;

  
-- *****************************************************************
-- Description:     PROCEDURE  FOCUS_POSCHANGE
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------   
  PROCEDURE FOCUS_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: FOCUS_POSCHANGE
 -- ****************************************************************    
    OPEN p_CURSOR FOR
      SELECT    CLIENTS.libelle                                                                                AS FUND
              , FOLIOS.BOOK_NAME                                                                               AS BOOK
              , FOLIOS.FOLIO_NAME                                                                              AS STRATEGY
              , TITRES.libelle                                                                                 AS INSTRUMENT
              , POSITIONS.YESTERDAY                                                                            AS n$YESTERDAYS_POSITION
              , POSITIONS.TODAY                                                                                AS n$TODAYS_POSITION
              , CASE 
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'FLAT'
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'FLAT'
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'SHORT'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'SHORT' 
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                  ELSE 'UNKNOWN'
                END                                                                                           AS YESTERDAYS_STATE
              , CASE 
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'SHORT'
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'SHORT'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                  ELSE 'UNKNOWN'
                END                                                                                         AS TODAYS_STATE
              , CASE 
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'NEW POSITION'
                  WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'NEW POSITION'
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL LONG UNWIND'
                  WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'FULL LONG UNWIND CROSSING ZERO'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL SHORT UNWIND'
                  WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'FULL SHORT UNWIND CROSSING ZERO'
                  WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
                  WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
                  ELSE 'UNKNOWN'
                END                                                                                       AS ACTION_TAKEN
              , FOLIOS.FOLIO_FULL_NAME                                                                    AS STRATEGY_FULL_NAME
      FROM   (
                SELECT    HISTOMVTS.entite                                   AS FUND_ID
                        , HISTOMVTS.opcvm                                    AS FOLIO_ID
                        , HISTOMVTS.sicovam                                  AS INSTRUMENT_ID
                        , SUM(HISTOMVTS.quantite)                            AS TODAY
                        , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) 
                                   THEN HISTOMVTS.quantite 
                                   ELSE 0 
                              END)                                           AS YESTERDAY  
                FROM       HISTOMVTS
                INNER JOIN BO_KERNEL_STATUS_COMPONENT
                ON         BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                AND        BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                INNER JOIN BUSINESS_EVENTS 
                ON         BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                AND        BUSINESS_EVENTS.COMPTA                            = 1
                WHERE      HISTOMVTS.dateneg                                 <= trunc(sysdate)
                GROUP BY   HISTOMVTS.entite
                ,          HISTOMVTS.opcvm
                ,          HISTOMVTS.sicovam
              )  POSITIONS
      INNER JOIN (
                    SELECT    REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS FOLIO_ID
                            , FOLIO.name                                                             AS FOLIO_NAME
                            , SYS_CONNECT_BY_PATH(FOLIO.name, '\')                                   AS FOLIO_FULL_NAME        
                    FROM FOLIO  
                    WHERE LEVEL > 2
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_FOCUS_FUND_RATE) --(62880) BTG Pactual Focus Fund - Rates
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FOLIOS
      ON            FOLIOS.FOLIO_ID          =   POSITIONS.FOLIO_ID
      
      INNER JOIN    TITRES       
      ON            TITRES.sicovam           =   POSITIONS.INSTRUMENT_ID
      AND           TITRES.type             !=   'L'
      
      INNER JOIN    CLIENTS
      ON            CLIENTS.ident           =    POSITIONS.fund_id
      
      WHERE POSITIONS.TODAY                 !=   POSITIONS.YESTERDAY
      
      ORDER BY  CLIENTS.libelle
              , FOLIOS.BOOK_NAME
              , FOLIOS.FOLIO_NAME
              , TITRES.libelle;


 -- *****************************************************************
 -- END OF: FOCUS_POSCHANGE
 -- ****************************************************************              
  END FOCUS_POSCHANGE;

-- *****************************************************************
-- Description:     PROCEDURE  FOCUS_POSCHANGE_SUMMARY
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------    
  PROCEDURE FOCUS_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
  -- *****************************************************************
 -- START OF: FOCUS_POSCHANGE_SUMMARY
 -- ****************************************************************    
    OPEN p_CURSOR FOR
      SELECT    FUND                                                                           AS FUND 
              , BOOK                                                                           AS BOOK
              , SUM(CASE WHEN ACTION_TAKEN IN( 'NEW POSITION') 
                          THEN POSITION_COUNT 
                          ELSE 0 
                    END)                                                                       AS N$OPEN
              , SUM(CASE WHEN ACTION_TAKEN IN( 'FULL LONG UNWIND'
                                             , 'FULL SHORT UNWIND') 
                         THEN POSITION_COUNT 
                         ELSE 0 
                    END) AS N$CLOSE
              , SUM(CASE WHEN ACTION_TAKEN IN( 'INCREASE IN POSITION'
                                             , 'DECREASE IN POSITION'
                                             , 'FULL LONG UNWIND CROSSING ZERO'
                                             , 'FULL SHORT UNWIND CROSSING ZERO') 
                          THEN POSITION_COUNT 
                          ELSE 0 
                    END)                                                                      AS N$CHANGE 
              , SUM(POSITION_COUNT)                                                           AS N$TOTAL
      FROM (
            SELECT      FUND
                      , BOOK
                      , ACTION_TAKEN
                      , COUNT(*)                                 AS POSITION_COUNT
            FROM (
              SELECT      CLIENTS.libelle                                                      AS FUND
                        , FOLIOS.BOOK_NAME                                                     AS BOOK
                        , CASE 
                          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'NEW POSITION'
                          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'NEW POSITION'
                          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
                          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
                          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL LONG UNWIND'
                          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'FULL LONG UNWIND CROSSING ZERO'
                          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL SHORT UNWIND'
                          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'FULL SHORT UNWIND CROSSING ZERO'
                          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
                          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
                          ELSE 'UNKNOWN'
                          END                                                                  AS ACTION_TAKEN
          FROM     (
                    SELECT    HISTOMVTS.entite                                                   AS FUND_ID
                            , HISTOMVTS.opcvm                                                    AS FOLIO_ID
                            , HISTOMVTS.sicovam                                                  AS INSTRUMENT_ID
                            , SUM(HISTOMVTS.quantite)                                            AS TODAY
                            , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) 
                                       THEN HISTOMVTS.quantite 
                                       ELSE 0 
                                  END)                                                           AS YESTERDAY  
                    FROM       HISTOMVTS
                    INNER JOIN BO_KERNEL_STATUS_COMPONENT
                    ON         BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                    AND        BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                    INNER JOIN BUSINESS_EVENTS 
                    ON         BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                    AND        BUSINESS_EVENTS.COMPTA                            = 1
                    WHERE      HISTOMVTS.dateneg                                 <= trunc(sysdate)
                    GROUP BY   HISTOMVTS.entite
                    ,          HISTOMVTS.opcvm
                    ,          HISTOMVTS.sicovam
                     ) POSITIONS
          INNER JOIN (
                      SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)  AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)   AS BOOK_NAME
                            , FOLIO.ident                                                          AS FOLIO_ID
                            , FOLIO.name                                                           AS FOLIO_NAME
                            , SYS_CONNECT_BY_PATH(FOLIO.name, '\')                                 AS FOLIO_FULL_NAME        
                      FROM   FOLIO  
                      WHERE   LEVEL > 2
                      START   WITH FOLIO.ident IN  (PCKG_BTG.FOLIO_FOCUS_FUND_RATE) --(62880)
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                     )  FOLIOS
          ON            FOLIOS.FOLIO_ID = POSITIONS.FOLIO_ID
          
          INNER JOIN    TITRES 
          ON            TITRES.sicovam = POSITIONS.INSTRUMENT_ID
          
          AND           TITRES.type != 'L'
          
          INNER JOIN    CLIENTS
          ON            CLIENTS.ident = POSITIONS.fund_id
          
          WHERE         POSITIONS.TODAY != POSITIONS.YESTERDAY
        ) 
        GROUP BY       FUND
                      , BOOK
                      , ACTION_TAKEN
      )
      GROUP BY     FUND
                 , BOOK
      ORDER BY     FUND
                 , BOOK;
 
  -- *****************************************************************
 -- END OF: FOCUS_POSCHANGE_SUMMARY
 -- ****************************************************************       
  END FOCUS_POSCHANGE_SUMMARY;
  
  
-- *****************************************************************
-- Description:     PROCEDURE  EQ_CONVERTIBLE_BONDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------  
  PROCEDURE EQ_CONVERTIBLE_BONDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_CONVERTIBLE_BONDS
 -- ****************************************************************        
    OPEN p_CURSOR FOR
      SELECT      HISTORIQUE.jour                                               AS d$DATE
                , POSITION_DETAILS.name                                         AS name
                , HISTORIQUE.d                                                  AS p$6$LAST
                , HISTORIQUE.t                                                  AS p$6$THEO
                , HISTORIQUE.d - HISTORIQUE.t                                   AS "p$6$LAST_-_THEO"
                , ROUND(BTG_GET_VALUE_IN_USD(
                                              ( POSITION_DETAILS.quantity * POSITION_DETAILS.contract_size * HISTORIQUE.d) 
                                              + POSITION_DETAILS.contract_size * POSITION_DETAILS.quantity * COALESCE(HISTORIQUE.coupon, 0)
                                              , POSITION_DETAILS.quote_currency, HISTORIQUE.jour
                                             )
                         , 8)                                                   AS "p$2$MARKET_VALUE_(LAST)_IN_USD"
                , ROUND(BTG_GET_VALUE_IN_USD(
                                              ( POSITION_DETAILS.quantity * POSITION_DETAILS.contract_size * HISTORIQUE.t) 
                                              + POSITION_DETAILS.contract_size * POSITION_DETAILS.quantity * COALESCE(HISTORIQUE.coupon, 0)
                                              , POSITION_DETAILS.quote_currency, HISTORIQUE.jour
                                            )
                         , 8)                                                   AS "p$2$MARKET_VALUE_(THEO)_IN_USD"
                , ROUND(BTG_GET_VALUE_IN_USD(
                                              ( POSITION_DETAILS.quantity * POSITION_DETAILS.contract_size * (HISTORIQUE.d - HISTORIQUE.t)) 
                                              + POSITION_DETAILS.contract_size * POSITION_DETAILS.quantity * COALESCE(HISTORIQUE.coupon, 0)
                                              , POSITION_DETAILS.quote_currency, HISTORIQUE.jour
                                             )
                         , 8)                                                   AS p$2$IMPACT_IN_USD
      FROM (
             SELECT    TITRES.sicovam 
                     , TITRES.libelle                               AS NAME
                     , DECODE(TITRES.quotation_type
                            , 2
                            , TITRES.nominal / 100
                            , 1)                                   AS CONTRACT_SIZE
                    , TITRES.quotation_type
                    , TITRES.devisectt                             AS QUOTE_CURRENCY
                    , POSITION.quantity
              FROM (
                        SELECT       HISTOMVTS.sicovam
                                ,   SUM(HISTOMVTS.quantite) AS QUANTITY
                        FROM        HISTOMVTS
                        INNER JOIN (
                                       SELECT    FOLIO.ident
                                       FROM       FOLIO  
                                       START WITH FOLIO.ident IN (63040, 63034, 62389, 63041, 63039) --ARF2 --EQ Long Short,EQ Events ,EQ Volatility,EQ Convertible Bonds,EQ Management  
                                       CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                                    ) FOLIOS
                        ON            FOLIOS.ident         =     HISTOMVTS.opcvm
                        
                        INNER JOIN     TITRES
                        ON             TITRES.sicovam      =      HISTOMVTS.sicovam
                        
                        INNER JOIN     BUSINESS_EVENTS 
                        ON             BUSINESS_EVENTS.id  =     HISTOMVTS.type      
                        
                        WHERE          HISTOMVTS.backoffice         NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
                        AND            TITRES.type                   =     'D' 
                        AND            TITRES.typepro                =      3
                        AND            BUSINESS_EVENTS.compta        =      1
                        AND            HISTOMVTS.dateneg             <     TRUNC(SYSDATE)
                        
                        GROUP BY       HISTOMVTS.sicovam
                        
                        HAVING         SUM(HISTOMVTS.quantite)       !=    0
                   )    POSITION                    
             INNER JOIN TITRES 
             ON         TITRES.sicovam   =   POSITION.sicovam             
          )           POSITION_DETAILS
      LEFT OUTER JOIN HISTORIQUE
      ON              HISTORIQUE.sicovam     =     POSITION_DETAILS.sicovam
      
      WHERE           HISTORIQUE.jour        =     BTG_BUSINESS_DATE(TRUNC(SYSDATE), -1)
      
      ORDER BY 8 DESC;
 -- *****************************************************************
 -- END OF: EQ_CONVERTIBLE_BONDS
 -- ****************************************************************          
  END EQ_CONVERTIBLE_BONDS;
  
-- *****************************************************************
-- Description:     PROCEDURE  EQ_CB_UPCMNG_DVDNDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------    
  PROCEDURE EQ_CB_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_CB_UPCMNG_DVDNDS
 -- ****************************************************************        
    OPEN p_CURSOR FOR
        SELECT      CASE DIVIDENDE.dateexdiv    WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (68801) --GEMM EQ Convertible Bonds
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;         
 -- *****************************************************************
 -- END OF: EQ_CB_UPCMNG_DVDNDS
 -- ****************************************************************          
  END EQ_CB_UPCMNG_DVDNDS;
 
 
 
 -- *****************************************************************
-- Description:     PROCEDURE  EQ_EVNTS_UPCMNG_DVDNDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- 31 JAN 2017       Jeff Yu      Modofied per PMGMPMO-211.
-- ----------------------------------------------------------------  
  PROCEDURE EQ_EVNTS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_EVNTS_UPCMNG_DVDNDS
 -- ****************************************************************    
    OPEN p_CURSOR FOR
        SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (68373)--GEMM EQ Events
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (127378)--ARF EQ Events
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7;     
 -- *****************************************************************
 -- END OF: EQ_EVNTS_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_EVNTS_UPCMNG_DVDNDS;
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_LS_UPCMNG_DVDNDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------  
  PROCEDURE EQ_LS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_LS_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
          SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (68394)--GEMM EQ Long Short 
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7;  
      
 -- *****************************************************************
 -- END OF: EQ_LS_UPCMNG_DVDNDS
 -- ****************************************************************         
  END EQ_LS_UPCMNG_DVDNDS;
 
 
-- *****************************************************************
-- Description:     PROCEDURE  EQ_MGNT_UPCMNG_DVDNDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------   
  PROCEDURE EQ_MGNT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_MGNT_UPCMNG_DVDNDS
 -- ****************************************************************     
    OPEN p_CURSOR FOR
           SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (68424)--GEMM EQ Management
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7;  
 
 -- *****************************************************************
 -- END OF: EQ_MGNT_UPCMNG_DVDNDS
 -- ****************************************************************          
  END EQ_MGNT_UPCMNG_DVDNDS;
 
 
 
 -- *****************************************************************
-- Description:     PROCEDURE  EQ_VOL_UPCMNG_DVDNDS
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- 31 Jan 2017       Jeff Yu       Modified per PMGMPMO-211.
-- 27 Sep 2017      Jeff Yu       Add GDO EQ Volatility in scope per PMOG-1150.
-- ----------------------------------------------------------------    
  PROCEDURE EQ_VOL_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_VOL_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
          SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (68435)--GEMM EQ Volatility  
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (128254)--ARF EQ Volatility  
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr 
               UNION
						   SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (132412)--GDO EQ Volatility  
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr             
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7; 
 -- *****************************************************************
 -- END OF: EQ_VOL_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_VOL_UPCMNG_DVDNDS;  
 
 PROCEDURE EQ_EUR_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_EUR_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
           SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (76079)--ARF2 EQ Euro Cash
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7; 
 -- *****************************************************************
 -- END OF: EQ_EUR_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_EUR_UPCMNG_DVDNDS;  

  PROCEDURE EQ_US_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_US_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
           SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (105710)--GEMM EQ US Cash
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7; 
 -- *****************************************************************
 -- END OF: EQ_US_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_US_UPCMNG_DVDNDS;  
     

 -- *****************************************************************
-- Description:     PROCEDURE  ARF2_POSCHANGE_SUMMARY
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------    
  PROCEDURE ARF2_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: ARF2_POSCHANGE_SUMMARY
 -- ****************************************************************     
    OPEN p_CURSOR FOR
      SELECT CLIENTS.libelle                                                                                   AS FUND
      , FOLIOS.book_name                                                                                       AS BOOK      
      , SUM (
          CASE 
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN  1
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN  1
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 0
            ELSE 0
          END
        )                                                                                                      AS n$OPEN
      , SUM (
          CASE             
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 0
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 1
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 0
            ELSE 0
          END 
        )                                                                                                      AS n$CLOSE
      , SUM (
          CASE 
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 0
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 1
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 0
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 1
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 1
            ELSE 0
          END 
        )                                                                                                      AS n$CHANGE
     , SUM (
          CASE 
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 1
            WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 1    
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 1            
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 1           
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 1          
            WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 1          
            WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 1
            WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 1
            WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 1
            ELSE 0
          END 
        )                                                                                                      AS n$TOTAL
      FROM   (
                SELECT      HISTOMVTS.entite                                 AS FUND_ID
                          , HISTOMVTS.opcvm                                  AS FOLIO_ID
                          , HISTOMVTS.sicovam                                AS INSTRUMENT_ID
                          , SUM(HISTOMVTS.quantite)                          AS TODAY
                          , SUM(CASE 
                                    WHEN HISTOMVTS.dateneg < trunc(sysdate) 
                                    THEN HISTOMVTS.quantite 
                                    ELSE 0 
                               END)                                          AS YESTERDAY  
                FROM        HISTOMVTS
                
                INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id = HISTOMVTS.backoffice
                
                INNER JOIN BUSINESS_EVENTS 
                ON         BUSINESS_EVENTS.Id             =     HISTOMVTS.Type
                AND        BUSINESS_EVENTS.COMPTA         =     1
                
                WHERE      HISTOMVTS.dateneg              <=    trunc(sysdate)
                AND        HISTOMVTS.backoffice          NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
                
                GROUP BY   HISTOMVTS.entite
                        ,  HISTOMVTS.opcvm
                        ,  HISTOMVTS.sicovam
              ) POSITIONS
      INNER JOIN (
                    SELECT      FOLIO.ident                                                        AS FOLIO_ID
                              , FOLIO.name                                                         AS FOLIO_NAME        
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                              , SYS_CONNECT_BY_PATH(FOLIO.name, '\')                               AS FOLIO_FULL_NAME        
                    FROM FOLIO  
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_ARF2_MASTER_FUND)--(12642) ARF2
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FOLIOS
      ON            FOLIOS.FOLIO_ID     =   POSITIONS.FOLIO_ID
      
      INNER JOIN    TITRES 
      ON            TITRES.sicovam      =   POSITIONS.INSTRUMENT_ID      
      AND           TITRES.type        !=   'L' --EXCLUDE REPOS
      
      INNER JOIN    CLIENTS
      ON            CLIENTS.ident       =   POSITIONS.fund_id
      
      WHERE         POSITIONS.TODAY    !=   POSITIONS.YESTERDAY      
      GROUP BY      CLIENTS.libelle
                  , FOLIOS.book_name
                  
      ORDER BY      CLIENTS.libelle
                  , FOLIOS.book_name;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
 -- *****************************************************************
 -- END OF: ARF2_POSCHANGE_SUMMARY
 -- ****************************************************************           
	END ARF2_POSCHANGE_SUMMARY;
 
 
 
-- *****************************************************************
-- Description:     PROCEDURE  ARF2_POSCHANGE
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- 16 SEP 2015      Davi Xavier     PMOF-197.
-- ----------------------------------------------------------------    
  PROCEDURE ARF2_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: ARF2_POSCHANGE
 -- ****************************************************************             
    OPEN p_CURSOR FOR
      SELECT      CLIENTS.libelle                                                                                AS FUND
                , FOLIOS.book_name                                                                               AS BOOK
                , FOLIOS.folio_name                                                                              AS STRATEGY
                , TITRES.libelle                                                                                 AS INSTRUMENT
                , ROUND(POSITIONS.YESTERDAY,2)                                                                   AS n$YESTERDAYS_POSITION
                , ROUND(POSITIONS.TODAY,2)                                                                       AS n$TODAYS_POSITION
                , CASE 
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'FLAT'
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'FLAT'
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'SHORT'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'SHORT' 
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                    ELSE 'UNKNOWN'
                  END                                                                                           AS YESTERDAYS_STATE
                , CASE 
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'SHORT'
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'SHORT'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                    ELSE 'UNKNOWN'
                  END                                                                                          AS TODAYS_STATE
                , CASE 
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'NEW POSITION'
                    WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'NEW POSITION'
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL LONG UNWIND'
                    WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'FULL LONG UNWIND CROSSING ZERO'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL SHORT UNWIND'
                    WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'FULL SHORT UNWIND CROSSING ZERO'
                    WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
                    WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
                    ELSE 'UNKNOWN'
                  END                                                                                            AS ACTION_TAKEN
                , FOLIOS.FOLIO_FULL_NAME                                                                         AS FULL_STRATEGY_NAME
      FROM   (
                SELECT       HISTOMVTS.entite                                         AS  FUND_ID
                           , HISTOMVTS.opcvm                                          AS FOLIO_ID
                           , HISTOMVTS.sicovam                                        AS INSTRUMENT_ID
                           , SUM(HISTOMVTS.quantite)                                  AS TODAY
                           , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) 
                                      THEN HISTOMVTS.quantite 
                                      ELSE 0 
                                 END)                                                 AS YESTERDAY  
                FROM         HISTOMVTS
                INNER JOIN   BO_KERNEL_STATUS_COMPONENT
                ON           BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                AND          BO_KERNEL_STATUS_COMPONENT.kernel_status_id = HISTOMVTS.backoffice
                
                INNER JOIN   BUSINESS_EVENTS 
                ON           BUSINESS_EVENTS.Id        =     HISTOMVTS.Type
                AND          BUSINESS_EVENTS.COMPTA    =     1
                
                WHERE        HISTOMVTS.dateneg         <=    trunc(sysdate)
                AND          HISTOMVTS.backoffice    NOT IN  (11,13,17,26,27,192,220,248,252)
                
                GROUP BY     HISTOMVTS.entite
                           , HISTOMVTS.opcvm
                           , HISTOMVTS.sicovam
              ) POSITIONS
              
      INNER JOIN (
                    SELECT      FOLIO.ident                            AS FOLIO_ID
                              , FOLIO.name                             AS FOLIO_NAME        
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                              , SYS_CONNECT_BY_PATH(FOLIO.name, '\')   AS FOLIO_FULL_NAME        
                    FROM        FOLIO  
                    START WITH  FOLIO.ident IN (PCKG_BTG.FOLIO_ARF2_MASTER_FUND)--ARF2 (12642)
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FOLIOS
      ON            FOLIOS.FOLIO_ID             =           POSITIONS.FOLIO_ID
      
      INNER JOIN    TITRES       
      ON            TITRES.sicovam              =           POSITIONS.INSTRUMENT_ID
      AND           TITRES.type                 !=          'L' --EXCLUDE REPOS
      
      INNER JOIN    CLIENTS
      ON            CLIENTS.ident               =            POSITIONS.fund_id
      WHERE         POSITIONS.TODAY             !=           POSITIONS.YESTERDAY
      
      ORDER BY      CLIENTS.libelle
                  , FOLIOS.BOOK_NAME
                  , TITRES.libelle;

  EXCEPTION

    WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: ARF2_POSCHANGE
 -- ****************************************************************           
 END ARF2_POSCHANGE;


-- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_EUR_RATES_ALLOC
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------   
  PROCEDURE COMPLIANCE_EUR_RATES_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: COMPLIANCE_EUR_RATES_ALLOC
 -- **************************************************************** 	
	  OPEN p_CURSOR FOR
		SELECT          
                    Instrument.libelle                                AS  Instrument_Name
                ,   Instrument.reference                              AS  Instrument_Reference
                ,   FUND_BOOK_STRATEGY.BOOK_NAME                      AS  Strategy
                ,   riskusers.name                                    AS  Trader
                ,   Trades.refcon                                     AS  Trade_Id
                ,   Trades.sicovam                                    AS  Sicovam
                ,   trunc(Trades.DATENEG)                             AS  d$TradeDate
                ,   trunc(Trades.DATEVAL)                             AS  d$ValueDate
                ,   Counterparty.name                                 AS  Counterparty
                ,   btg_get_instrument_type (Trades.sicovam)          AS  Instrument_Type
    FROM            histomvts Trades 
    INNER JOIN      business_events
    ON              business_events.id             =        Trades.type
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam             =        Trades.sicovam 
    LEFT JOIN       riskusers
    ON              riskusers.ident                =        trades.operateur
    LEFT JOIN       Tiers Counterparty
    ON              Counterparty.ident             =        trades.contrepartie
    LEFT JOIN       Tiers Broker
    ON              Broker.ident                   =        trades.courtier
    INNER JOIN ( 
                    SELECT      CONNECT_BY_ROOT(FOLIO.ident)                                         AS TOP_FUND_ID
                              , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)  AS BOOK_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)   AS BOOK_NAME
                              , FOLIO.ident                                                          AS STRATEGY_ID
                              , FOLIO.name                                                           AS STRATEGY_NAME
                              , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK )--(PCKG_BTG.FOLIO_EXECUTION_BOOK) --(14046)--Primary funds
                    CONNECT BY PRIOR FOLIO.ident          =     FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON              FUND_BOOK_STRATEGY.STRATEGY_ID        =     Trades.OPCVM
    WHERE          
                    Trades.BACKOFFICE                     =      264   
                     AND   FUND_BOOK_STRATEGY.BOOK_NAME   =  'Europe Rates EXEC'
;

  EXCEPTION

	WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: COMPLIANCE_EUR_RATES_ALLOC
 -- **************************************************************** 
END COMPLIANCE_EUR_RATES_ALLOC;
  

-- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_X_ASSET_ALLOC
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ---------------------------------------------------------------- 
  PROCEDURE COMPLIANCE_X_ASSET_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: COMPLIANCE_X_ASSET_ALLOC
 -- **************************************************************** 	
	   OPEN p_CURSOR FOR
      SELECT          
                      Instrument.libelle                                AS Instrument_Name
                     , Instrument.reference                             AS Instrument_Reference
                     , FUND_BOOK_STRATEGY.BOOK_NAME                     AS Strategy
                     , riskusers.name                                   AS Trader
                     , Trades.refcon                                    AS Trade_Id
                     , Trades.sicovam                                   AS Sicovam
                     , trunc(Trades.DATENEG)                            AS d$TradeDate
                     , trunc(Trades.DATEVAL)                            AS d$ValueDate
                     , Counterparty.name                                AS Counterparty
                     , btg_get_instrument_type (Trades.sicovam)         AS Instrument_Type
      FROM            histomvts Trades
      
      INNER JOIN      business_events
      ON              business_events.id     = Trades.type
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam     = Trades.sicovam 
      
      LEFT JOIN       riskusers
      ON              riskusers.ident        = trades.operateur
      
      LEFT JOIN       Tiers Counterparty
      ON              Counterparty.ident     = trades.contrepartie
      
      LEFT JOIN       Tiers Broker
      ON              Broker.ident           = trades.courtier
      
      INNER JOIN ( 
                    SELECT         CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                                  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)    AS BOOK_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)     AS BOOK_NAME
                                  , FOLIO.ident                                                            AS STRATEGY_ID
                                  , FOLIO.name                                                             AS STRATEGY_NAME
                                  , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK)--  (14046)--Primary funds
                    CONNECT BY PRIOR FOLIO.ident       =   FOLIO.mgr  
                )   FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID     =   Trades.OPCVM
      WHERE          
                    Trades.BACKOFFICE                  =   264   
      AND           FUND_BOOK_STRATEGY.BOOK_NAME       =  'Cross Asset EXEC'
;

  EXCEPTION

	WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: COMPLIANCE_X_ASSET_ALLOC
 -- **************************************************************** 
  END COMPLIANCE_X_ASSET_ALLOC;  


-- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_US_RATES_ALLOC
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ---------------------------------------------------------------- 

  PROCEDURE COMPLIANCE_US_RATES_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: COMPLIANCE_US_RATES_ALLOC
 -- **************************************************************** 
	OPEN p_CURSOR FOR
		SELECT          
                       Instrument.libelle                               AS   Instrument_Name
                    ,  Instrument.reference                             AS   Instrument_Reference
                    ,  FUND_BOOK_STRATEGY.BOOK_NAME                     AS   Strategy
                    ,  riskusers.name                                   AS   Trader
                    ,  Trades.refcon                                    AS   Trade_Id
                    ,  Trades.sicovam                                   AS   Sicovam
                    ,  trunc(Trades.DATENEG)                            AS   d$TradeDate
                    ,  trunc(Trades.DATEVAL)                            AS   d$ValueDate
                    ,  Counterparty.name                                AS   Counterparty
                    ,  btg_get_instrument_type (Trades.sicovam)          AS   Instrument_Type
      FROM            histomvts Trades 
      INNER JOIN      business_events
      ON              business_events.id              =    Trades.type
      INNER JOIN      titres Instrument 
      ON              Instrument.sicovam              =    Trades.sicovam 
      LEFT JOIN       riskusers
      ON              riskusers.ident                 =    trades.operateur
      LEFT JOIN       Tiers Counterparty
      ON              Counterparty.ident              =    trades.contrepartie
      LEFT JOIN       Tiers Broker
      ON              Broker.ident                    =    trades.courtier
      INNER JOIN ( 
                    SELECT     CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                              , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3)    AS BOOK_ID
                              , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)     AS BOOK_NAME
                              , FOLIO.ident                                                            AS STRATEGY_ID
                              , FOLIO.name                                                             AS STRATEGY_NAME
                              , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK)-- (14046)--exection book
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
    WHERE          
          Trades.BACKOFFICE = 264   
    AND   FUND_BOOK_STRATEGY.BOOK_NAME = 'US Rates EXEC'
;

  EXCEPTION

	WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: COMPLIANCE_US_RATES_ALLOC
 -- **************************************************************** 
  END COMPLIANCE_US_RATES_ALLOC;


  -- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_EQ_ALLOC
-- 
-- 
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- 20 AUG 2013      Jun Guan      Creation
-- ---------------------------------------------------------------- 
  PROCEDURE COMPLIANCE_EQ_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: COMPLIANCE_EQ_ALLOC
 -- **************************************************************** 	
	  OPEN p_CURSOR FOR
		SELECT          
                     Instrument.libelle                                AS  Instrument_Name
                  ,  Instrument.reference                              AS Instrument_Reference
                  ,  FUND_BOOK_STRATEGY.BOOK_NAME                      AS  Strategy
                  ,  riskusers.name                                    AS  Trader
                  ,  Trades.refcon                                     AS  Trade_Id
                  ,  Trades.sicovam                                    AS  Sicovam
                  ,  trunc(Trades.DATENEG)                             AS  d$TradeDate
                  ,  trunc(Trades.DATEVAL)                             AS  d$ValueDate
                  ,  Counterparty.name                                 AS  Counterparty
                  ,  btg_get_instrument_type (Trades.sicovam)          AS  Instrument_Type
    FROM            histomvts Trades 
    
    INNER JOIN      business_events
    ON              business_events.id    =   Trades.type
    
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam    =   Trades.sicovam 
    
    LEFT JOIN       riskusers
    ON              riskusers.ident       =   trades.operateur
    
    LEFT JOIN       Tiers Counterparty
    ON              Counterparty.ident    =   trades.contrepartie
    
    LEFT JOIN       Tiers Broker
    ON              Broker.ident          =   trades.courtier
    
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                    , FOLIO.ident AS STRATEGY_ID
                    , FOLIO.name AS STRATEGY_NAME
                    , level
                    FROM FOLIO
                    WHERE LEVEL >= 4
                    START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK) --(PCKG_BTG.FOLIO_EXECUTION_BOOK) --(14046)--EXECUTION BOOK
                    CONNECT BY PRIOR FOLIO.ident      =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID      =   Trades.OPCVM
    WHERE          
                  Trades.BACKOFFICE                   =   264   
                  AND  FUND_BOOK_STRATEGY.BOOK_NAME   =   'Equity London EXEC'
;

  EXCEPTION

	WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20011, sqlerrm);	
  
 -- *****************************************************************
 -- END OF: COMPLIANCE_EQ_ALLOC
 -- **************************************************************** 
END COMPLIANCE_EQ_ALLOC;

  
-- *****************************************************************
-- Description:     PROCEDURE  EQ_ENERGY_OP_3
--                  
-- /*EQ US Cash positions where the last trade was more than 3 days ago
--
-- Author:          Matt Kelly
--
-- Revision History
-- 
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 25 APR 2013    Matt Kelly      Created.
-- 21 Mar 2016    Gustavo Binnie  PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************

PROCEDURE EQ_ENERGY_OP_3
(
	p_CURSOR OUT T_CURSOR
)
     
AS
BEGIN

    OPEN p_CURSOR FOR
  
  
  SELECT      FUND_BOOK_STRATEGY.Fund_NAME              Fund
          ,           max(histomvts.dateneg)                    LastTrade
          ,           FUND_BOOK_STRATEGY.STRATEGY_NAME          Strategy
          --,           FUND_BOOK_STRATEGY.BOOK_NAME              Strat
          ,           security.libelle                          Name
          ,           security.reference                        ISIN
          ,           affectation.libelle                       Allotment
          ,           sum(histomvts.QUANTITE)					          Position
      
          FROM        histomvts
    
          INNER JOIN ( 
                      SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                         AS TOP_FUND_ID
                             , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                             , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                             , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                             , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                             , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                             , FOLIO.ident                                                          AS STRATEGY_ID
                             , FOLIO.name                                                           AS STRATEGY_NAME
                             , level
                       FROM FOLIO
                       WHERE LEVEL >= 4
                       START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) ---(14414,90565)--Primary funds
                       CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                     ) FUND_BOOK_STRATEGY
          ON           FUND_BOOK_STRATEGY.STRATEGY_ID          =   histomvts.opcvm
          AND          FUND_BOOK_STRATEGY.BOOK_NAME            =   'EQ Energy Oportunities'

          INNER JOIN  titres security
          ON          security.sicovam                         = histomvts.sicovam
          
          LEFT JOIN affectation
          ON security.affectation = affectation.ident
		  
		  /* Added this at Sam Clark's advising */
          INNER JOIN BUSINESS_EVENTS
            ON BUSINESS_EVENTS.id = HISTOMVTS.type 
              AND BUSINESS_EVENTS.compta = 1
              
          WHERE         histomvts.backoffice      NOT IN (192,11,13,17,26,27,220,248,252)
          
		  /* Filtering out Options and Derivatives at David Herzberg's request */
          AND           affectation.libelle not like '%ptions%'
          AND           affectation.libelle not like '%erivatives%'


          GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, security.libelle, security.reference, affectation.libelle
                    
          HAVING      sum(histomvts.QUANTITE) !=0
                      and max(histomvts.dateneg) <= btg_business_date(sysdate, -3)
                      
          ORDER BY 2, 1, 3, 4;
 
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END EQ_ENERGY_OP_3;
	
-- *****************************************************************
-- END OF: EQ_ENERGY_OP_3
-- *****************************************************************


-- *****************************************************************
-- Description:     PROCEDURE  ARF_POSCHANGE
--  * ARF Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013    Jameela Noor      Created.
-- 16 SEP 2015    Davi Xavier     PMOF-197.
-- 03 MAR 2017  Jeff Yu            PMGMRISK-91.

  PROCEDURE ARF_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- START OF: ARF_POSCHANGE
 -- *****************************************************************          
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                             Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND --12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND --12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND --12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

  -- ***************************************************************************
  -- ARF Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
-- *****************************************************************
 -- END OF: ARF_POSCHANGE
 -- *****************************************************************              
	END ARF_POSCHANGE;
	
	-- *****************************************************************
-- Description:     PROCEDURE  Global_POSCHANGE
--  * Global Position Change
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013    Jameela Noor      Created.
-- 16 SEP 2015    Davi Xavier       PMOF-197.

  PROCEDURE Global_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- START OF: Global_POSCHANGE
 -- *****************************************************************          
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND --63809 -- GLobal fund
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND --63809 --global fund
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND --63809 -- global fund
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

  -- ***************************************************************************
  -- GLOBAL Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
-- *****************************************************************
 -- END OF: Global_POSCHANGE
 -- *****************************************************************              
	END Global_POSCHANGE;

-- *****************************************************************
-- Description:     PROCEDURE  ARF_POSCHANGE_SUMMARY
--  * ARF Position Change summary
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 jul       Jameela     Created.
-- **********************************************************   
  PROCEDURE ARF_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: ARF_POSCHANGE_SUMMARY
 -- *****************************************************************     
    OPEN p_CURSOR FOR
      SELECT FUND
      , Book
      , SUM(CASE WHEN Action_Taken IN('New Position')
                 THEN pos_count 
                 ELSE 0 
             END)                                                                AS N$OPEN
      , SUM(CASE WHEN Action_Taken IN('Full Long Unwind', 'Full Short Unwind') 
                 THEN pos_count 
                 ELSE 0 
            END)                                                                 AS N$CLOSE
      , SUM(CASE WHEN Action_Taken IN('Increase In Position'
                                    , 'Decrease In Position'
                                    , 'Full Long Unwind Crossing Zero'
                                    , 'Full Short Unwind Crossing Zero') 
                 THEN pos_count ELSE 0 
            END)                                                                 AS N$CHANGE 
      , SUM(pos_count) AS N$TOTAL
        FROM (
                SELECT FUND
                , Book
                , Action_Taken
                , count(*) pos_count
                FROM (
                          SELECT      DataSet.Fund
                          ,           DataSet.Book
                          ,           DataSet.Strategy
                          ,           DataSet.Instrument
                          ,           DataSet.Position_Yesterday  
                          ,           DataSet.Position_Today      
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Yesterdays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Todays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Long Unwind'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'Full Long Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Short Unwind'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'Full Short Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'Decrease In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'Decrease In Position'
                                        ELSE
                                          'UNKNOWN'
                                      END Action_Taken
                          ,           DataSet.Strategy_Full
                          FROM        (
                                        SELECT      fund.name                                                 Fund
                                        ,           book.name                                                 Book
                                        ,           folio.name                                                Strategy
                                        ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                                              , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                                              , folio.name)                                   Strategy_Full
                                        ,           security.libelle                                          Instrument
                                        ,           NVL(PositionYesterday.quantite, 0)                        Position_Yesterday
                                        ,           NVL(PositionToday.quantite, 0)                            Position_Today
                                        ,           NVL(PositionToday.quantite, 0)
                                                    -
                                                    NVL(PositionYesterday.quantite, 0)                         Delta
                                        FROM        (
                                                      SELECT      DISTINCT
                                                                  HISTOMVTS.entite
                                                      ,           FOLIOS.parent_ident
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND -- 12506 -- ARF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                    ) ReportKey
                                                    
                                        INNER JOIN  tiers fund
                                        ON          fund.ident                = ReportKey.entite
                                        
                                        INNER JOIN  folio book
                                        ON          book.ident                = ReportKey.parent_ident
                                        
                                        INNER JOIN  folio
                                        ON          folio.ident               = ReportKey.opcvm
                                        
                                        INNER JOIN  titres security
                                        ON          security.sicovam          = ReportKey.sicovam
                                        AND         security.type             not in ('L')
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND-- 12506 -- ARF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionYesterday
                                        ON          PositionYesterday.entite    = ReportKey.entite
                                        AND         PositionYesterday.opcvm     = ReportKey.opcvm
                                        AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_ARF_MASTER_FUND--12506 -- ARF
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionToday
                                        ON          PositionToday.entite      = ReportKey.entite
                                        AND         PositionToday.opcvm       = ReportKey.opcvm
                                        AND         PositionToday.sicovam     = ReportKey.sicovam
                                        
                                        WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                                    ) DataSet
                      ) 
                 GROUP BY   FUND
                          , Book
                          , Action_Taken
              ) 
        GROUP BY    FUND
                  , Book
       ORDER BY 1, 2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
 -- END OF: ARF_POSCHANGE_SUMMARY
 -- *****************************************************************          
	END ARF_POSCHANGE_SUMMARY;
	 -- *****************************************************************
-- Description:     PROCEDURE  Global_POSCHANGE_SUMMARY
--  * Global Position Change summary
-- Author:          Jun Guan
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 jul 2013    jameela      Created.
-- **********************************************************   
  PROCEDURE Global_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: Global_POSCHANGE_SUMMARY
 -- *****************************************************************     
    OPEN p_CURSOR FOR
      SELECT FUND
      , Book
      , SUM(CASE WHEN Action_Taken IN('New Position')
                 THEN pos_count 
                 ELSE 0 
             END)                                                                AS N$OPEN
      , SUM(CASE WHEN Action_Taken IN('Full Long Unwind', 'Full Short Unwind') 
                 THEN pos_count 
                 ELSE 0 
            END)                                                                 AS N$CLOSE
      , SUM(CASE WHEN Action_Taken IN('Increase In Position'
                                    , 'Decrease In Position'
                                    , 'Full Long Unwind Crossing Zero'
                                    , 'Full Short Unwind Crossing Zero') 
                 THEN pos_count ELSE 0 
            END)                                                                 AS N$CHANGE 
      , SUM(pos_count) AS N$TOTAL
        FROM (
                SELECT FUND
                , Book
                , Action_Taken
                , count(*) pos_count
                FROM (
                          SELECT      DataSet.Fund
                          ,           DataSet.Book
                          ,           DataSet.Strategy
                          ,           DataSet.Instrument
                          ,           DataSet.Position_Yesterday  
                          ,           DataSet.Position_Today      
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Yesterdays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Todays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Long Unwind'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'Full Long Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Short Unwind'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'Full Short Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'Decrease In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'Decrease In Position'
                                        ELSE
                                          'UNKNOWN'
                                      END Action_Taken
                          ,           DataSet.Strategy_Full
                          FROM        (
                                        SELECT      fund.name                                                 Fund
                                        ,           book.name                                                 Book
                                        ,           folio.name                                                Strategy
                                        ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                                              , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                                              , folio.name)                                   Strategy_Full
                                        ,           security.libelle                                          Instrument
                                        ,           NVL(PositionYesterday.quantite, 0)                        Position_Yesterday
                                        ,           NVL(PositionToday.quantite, 0)                            Position_Today
                                        ,           NVL(PositionToday.quantite, 0)
                                                    -
                                                    NVL(PositionYesterday.quantite, 0)                         Delta
                                        FROM        (
                                                      SELECT      DISTINCT
                                                                  HISTOMVTS.entite
                                                      ,           FOLIOS.parent_ident
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND -- 63809 global
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                    ) ReportKey
                                                    
                                        INNER JOIN  tiers fund
                                        ON          fund.ident                = ReportKey.entite
                                        
                                        INNER JOIN  folio book
                                        ON          book.ident                = ReportKey.parent_ident
                                        
                                        INNER JOIN  folio
                                        ON          folio.ident               = ReportKey.opcvm
                                        
                                        INNER JOIN  titres security
                                        ON          security.sicovam          = ReportKey.sicovam
                                        AND         security.type             not in ('L')
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND -- 63809 GLobal
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionYesterday
                                        ON          PositionYesterday.entite    = ReportKey.entite
                                        AND         PositionYesterday.opcvm     = ReportKey.opcvm
                                        AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_PACTUAL_GLOBAL_FUND -- 63809 global
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionToday
                                        ON          PositionToday.entite      = ReportKey.entite
                                        AND         PositionToday.opcvm       = ReportKey.opcvm
                                        AND         PositionToday.sicovam     = ReportKey.sicovam
                                        
                                        WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                                    ) DataSet
                      ) 
                 GROUP BY   FUND
                          , Book
                          , Action_Taken
              ) 
        GROUP BY    FUND
                  , Book
       ORDER BY 1, 2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
 -- END OF: Global_POSCHANGE_SUMMARY
 -- *****************************************************************          
	END Global_POSCHANGE_SUMMARY;
-- *****************************************************************

-- *****************************************************************
-- Description:     PROCEDURE  EQ_SYS_UPCMNG_DVDNDS
--  * repo audit
-- Author:          
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 SEPT 2013      JAMEELA       Created as per gautier request for EQ syst ARF2 dividends
-- **********************************************************   

 PROCEDURE EQ_SYS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_SYS_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (90411) --GEMM EQ Systematic
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_SYS_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_SYS_UPCMNG_DVDNDS;  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_REL_VAL_UPCMNG_DVDNDS        
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Jan 2014      L.Iniesta       Dirk's request
-- 31 Jan 2017      Jeff Yu           Modified for ARF re-launch (PMGMPMO-211)
-- **********************************************************   

 PROCEDURE EQ_REL_VAL_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_REL_VAL_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (116072) --GEMM EQ Relative Value
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (128101) --ARF EQ Relative Value
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_REL_VAL_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_REL_VAL_UPCMNG_DVDNDS;  
  
  
    -- *****************************************************************
-- Description:     PROCEDURE  EQ_X_ASSET_UPCMNG_DVDNDS        
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Jan 2014      L.Iniesta       Dirk's request
-- 31 Jan 2017      Jeff Yu           Add ARF Strat for ARF Re-launch (PMGMPMO-211)
-- **********************************************************   

 PROCEDURE EQ_X_ASSET_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_X_ASSET_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (116378) --GEMM Cross Asset 
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (127061) --ARF Cross Asset 
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_X_ASSET_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_X_ASSET_UPCMNG_DVDNDS;  
  
  
  
      -- *****************************************************************
-- Description:     PROCEDURE  EQ_G_CREDIT_UPCMNG_DVDNDS        
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Jan 2014      L.Iniesta       Dirk's request
-- **********************************************************   

 PROCEDURE EQ_G_CREDIT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_G_CREDIT_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (59371) --GEMM Global Credit
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_G_CREDIT_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_G_CREDIT_UPCMNG_DVDNDS;  
  
  
    
    
        -- *****************************************************************
  -- Description:     PROCEDURE  EU_CORPORATE_UPCMNG_DVDNDS        
  --  
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 06 Jan 2014      L.Iniesta       Dirk's request
  -- **********************************************************   
  
   PROCEDURE EU_CORPORATE_UPCMNG_DVDNDS
    (
      p_CURSOR OUT T_CURSOR
    )
    AS
    BEGIN
   
   -- *****************************************************************
   -- START OF: EU_CORPORATE_UPCMNG_DVDNDS
   -- ****************************************************************   
  	OPEN p_CURSOR FOR 
   SELECT      CASE DIVIDENDE.dateexdiv    
   WHEN TO_DATE('01-JAN-1904') 
                           THEN DIVIDENDE.datediv 
                           ELSE DIVIDENDE.dateexdiv 
                       END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                    , CASE TITRES.type            WHEN 'A' 
                           THEN TITRES.libelle 
                           ELSE TITRES_UNDERLYING.libelle 
                      END                                                                              AS UNDERLYING
                    , AFFECTATION.libelle                                                              AS TYPE
                    , TITRES.libelle                                                                   AS INSTRUMENT
                    , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                    , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                    , ROUND(
                               ( OPEN_POSITIONS.quantity 
                                 * DECODE( TITRES.quotation_type
                                           , 2
                                           , TITRES.nominal / 100
                                           , 1
                                        ) 
                                 * GRECQUE_SIMPLE.delta
                               )
                            ,8)                                                                        AS N$GLOBAL_DELTA
                    , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                    , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                           THEN DIVIDENDE.datediv 
                           ELSE DIVIDENDE.dateexdiv 
                      END                                                                              AS D$EX_DIV_DATE
                    , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                    , CASE SECTORS.CODE           WHEN  'GB' 
                           THEN DIVIDENDE.VALEUR / 100 
                           ELSE DIVIDENDE.VALEUR 
                      END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                    , ROUND( CASE TITRES.type     WHEN 'D' 
                                  THEN NULL 
                                  ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                         THEN DIVIDENDE.VALEUR / 100 
                                                         ELSE DIVIDENDE.VALEUR 
                                                  END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                                 , 2
                                                                                                 , TITRES.nominal / 100
                                                                                                 , 1)  * GRECQUE_SIMPLE.delta) 
                               END,8)                                                                AS N$DIV_VALUE_TOTAL
                    , COALESCE(  RIC.servisen
                               , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
        FROM (
               SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                      , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite)               AS QUANTITY  
               FROM HISTOMVTS
               INNER JOIN (
                             SELECT      FOLIO.ident
                             FROM        FOLIO  
                             START WITH  FOLIO.ident IN (117709) --GEMM EU Corporate
                             CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                         ) FOLIOS
              ON   FOLIOS.ident   =   HISTOMVTS.opcvm
              INNER JOIN (
                              SELECT     TITRES.sicovam 
                                      ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                              FROM       HISTOMVTS 
                              INNER JOIN TITRES
                              ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                              WHERE      TITRES.type           =    'D'    
                              
                              UNION    
                              
                              SELECT     TITRES.sicovam 
                                      ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                              FROM       HISTOMVTS 
                              INNER JOIN TITRES
                              ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                              WHERE      TITRES.type           =  'G'    
                              
                              UNION    
                              
                              SELECT     TITRES.sicovam
                                        , NULL                              AS SICOVAM_UNDERLYING
                              FROM       HISTOMVTS 
                              INNER JOIN TITRES
                              ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                              WHERE      TITRES.type = 'A'
                         ) INSTRUMENTS
          ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
          
          INNER JOIN       TITRES 
          ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
          
          LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
          ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
          
          INNER JOIN       BUSINESS_EVENTS 
          ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
          
          WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
          
          AND              (    TITRES.type            = 'A' 
                             OR TITRES_UNDERLYING.type = 'A')
          AND               BUSINESS_EVENTS.compta     =  1
          AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
          
          GROUP BY          HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
          HAVING            SUM(HISTOMVTS.quantite) != 0
        )                   OPEN_POSITIONS
        
        INNER JOIN          TITRES
        ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
        
        LEFT OUTER JOIN     AFFECTATION
        ON                  TITRES.affectation        =    AFFECTATION.ident
        
        LEFT JOIN           TITRES TITRES_UNDERLYING
        ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
        
        INNER JOIN DIVIDENDE
        ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
        
        LEFT OUTER JOIN GRECQUE_SIMPLE
        ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
        AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                              OR (  TITRES.type       =   'A' 
                                    AND NOT EXISTS   (  SELECT  * 
                                                        FROM    DEVISEV2 
                                                        WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                  )
                          )
                          
        LEFT OUTER JOIN RIC
        ON              RIC.sicovam                   =  TITRES.sicovam
        
        LEFT OUTER JOIN RIC RIC_UNDERLYING
        ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
        
        LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
        ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
        AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
        
        LEFT OUTER JOIN SECTORS
        ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
        
        WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
        AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
        ORDER BY 1, 2, 3, 7;   
  
   -- *****************************************************************
   -- END OF: EU_CORPORATE_UPCMNG_DVDNDS
   -- ****************************************************************    
  END EU_CORPORATE_UPCMNG_DVDNDS;  
  
  
        -- *****************************************************************
-- Description:     PROCEDURE  EQ_US_IPO_ASSET_UPCMNG_DVDNDS        
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Jan 2014      L.Iniesta       Dirk's request
-- 31 Jan 2017      Jeff Yu           Add ARF strat for ARF re-launch (PMGMPMO-211)
-- **********************************************************   

 PROCEDURE EQ_US_IPO_ASSET_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_US_IPO_ASSET_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (71210) --GEMM EQ US IPO
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (132261) --ARF EQ US IPO
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
						   UNION
						   SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (134813) --GDO EQ US IPO
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_US_IPO_ASSET_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_US_IPO_ASSET_UPCMNG_DVDNDS;  
  
  
  
  
          -- *****************************************************************
-- Description:     PROCEDURE  EQ_CIO_AD_UPCMNG_DVDNDS        
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Jan 2014      L.Iniesta       Dirk's request
-- 31 Jan 2017      Jeff Yu           Add ARF strat for ARF re-launch (PMGMPMO-211)
-- **********************************************************   

 PROCEDURE EQ_CIO_AD_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_CIO_AD_UPCMNG_DVDNDS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT      CASE DIVIDENDE.dateexdiv    
 WHEN TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                     END - TRUNC(SYSDATE)                                                             AS N$DAYS_UNTIL_EX_DIV
                  , CASE TITRES.type            WHEN 'A' 
                         THEN TITRES.libelle 
                         ELSE TITRES_UNDERLYING.libelle 
                    END                                                                              AS UNDERLYING
                  , AFFECTATION.libelle                                                              AS TYPE
                  , TITRES.libelle                                                                   AS INSTRUMENT
                  , DEVISE_TO_STR(TITRES.devisectt)                                                  AS INSTRUMENT_CURRENCY   
                  , OPEN_POSITIONS.quantity                                                          AS N$QUANTITY
                  , ROUND(
                             ( OPEN_POSITIONS.quantity 
                               * DECODE( TITRES.quotation_type
                                         , 2
                                         , TITRES.nominal / 100
                                         , 1
                                      ) 
                               * GRECQUE_SIMPLE.delta
                             )
                          ,8)                                                                        AS N$GLOBAL_DELTA
                  , DIVIDENDE.datepaye                                                               AS D$DIV_PAYMENT_DATE
                  , CASE DIVIDENDE.dateexdiv    WHEN  TO_DATE('01-JAN-1904') 
                         THEN DIVIDENDE.datediv 
                         ELSE DIVIDENDE.dateexdiv 
                    END                                                                              AS D$EX_DIV_DATE
                  , DEVISE_TO_STR(DIVIDENDE.currency)                                                AS DIV_CURRENCY
                  , CASE SECTORS.CODE           WHEN  'GB' 
                         THEN DIVIDENDE.VALEUR / 100 
                         ELSE DIVIDENDE.VALEUR 
                    END                                                                              AS P$6$DIV_VALUE_PER_SHARE
                  , ROUND( CASE TITRES.type     WHEN 'D' 
                                THEN NULL 
                                ELSE          (CASE   SECTORS.code   WHEN  'GB' 
                                                       THEN DIVIDENDE.VALEUR / 100 
                                                       ELSE DIVIDENDE.VALEUR 
                                                END)   *    (OPEN_POSITIONS.quantity  * DECODE(  TITRES.quotation_type
                                                                                               , 2
                                                                                               , TITRES.nominal / 100
                                                                                               , 1)  * GRECQUE_SIMPLE.delta) 
                             END,8)                                                                AS N$DIV_VALUE_TOTAL
                  , COALESCE(  RIC.servisen
                             , RIC_UNDERLYING.servisen)                                            AS BLOOMBERG_CODE
      FROM (
             SELECT   HISTOMVTS.sicovam                     AS SICOVAM
                    , TITRES_UNDERLYING.sicovam             AS SICOVAM_UNDERLYING
                    , SUM(HISTOMVTS.quantite)               AS QUANTITY  
             FROM HISTOMVTS
             INNER JOIN (
                           SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (78986) --GEMM CIO(AD)
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT      FOLIO.ident
                           FROM        FOLIO  
                           START WITH  FOLIO.ident IN (92907) --ARF CIO(AD)
                           CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                       ) FOLIOS
            ON   FOLIOS.ident   =   HISTOMVTS.opcvm
            INNER JOIN (
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.codesj                      AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =    HISTOMVTS.sicovam                            
                            WHERE      TITRES.type           =    'D'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam 
                                    ,  TITRES.code_emet                   AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam        =   HISTOMVTS.sicovam
                            WHERE      TITRES.type           =  'G'    
                            
                            UNION    
                            
                            SELECT     TITRES.sicovam
                                      , NULL                              AS SICOVAM_UNDERLYING
                            FROM       HISTOMVTS 
                            INNER JOIN TITRES
                            ON         TITRES.sicovam       =     HISTOMVTS.sicovam
                            WHERE      TITRES.type = 'A'
                       ) INSTRUMENTS
        ON               INSTRUMENTS.sicovam       =     HISTOMVTS.sicovam
        
        INNER JOIN       TITRES 
        ON               TITRES.sicovam            =     INSTRUMENTS.sicovam
        
        LEFT OUTER JOIN  TITRES TITRES_UNDERLYING 
        ON               TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
        
        INNER JOIN       BUSINESS_EVENTS 
        ON               BUSINESS_EVENTS.id        =     HISTOMVTS.type      
        
        WHERE            HISTOMVTS.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
        
        AND              (    TITRES.type            = 'A' 
                           OR TITRES_UNDERLYING.type = 'A')
        AND               BUSINESS_EVENTS.compta     =  1
        AND               HISTOMVTS.dateneg         <   TRUNC(SYSDATE)
        
        GROUP BY          HISTOMVTS.sicovam
                        , TITRES_UNDERLYING.sicovam
                        
        HAVING            SUM(HISTOMVTS.quantite) != 0
      )                   OPEN_POSITIONS
      
      INNER JOIN          TITRES
      ON                  TITRES.sicovam            =    OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN     AFFECTATION
      ON                  TITRES.affectation        =    AFFECTATION.ident
      
      LEFT JOIN           TITRES TITRES_UNDERLYING
      ON                  TITRES_UNDERLYING.sicovam =    OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN DIVIDENDE
      ON                  DIVIDENDE.sicovam         =     COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON                 GRECQUE_SIMPLE.sicovam     =  TITRES.sicovam            
      AND               (   GRECQUE_SIMPLE.codesj   = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                            OR (  TITRES.type       =   'A' 
                                  AND NOT EXISTS   (  SELECT  * 
                                                      FROM    DEVISEV2 
                                                      WHERE   CODE     =   GRECQUE_SIMPLE.codesj )
                                )
                        )
                        
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                   =  TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam        =  TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                    = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv             >  TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv             <  TRUNC(SYSDATE + 28)      
      ORDER BY 1, 2, 3, 7;   

 -- *****************************************************************
 -- END OF: EQ_G_CREDIT_ASSET_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_CIO_AD_UPCMNG_DVDNDS;  
    
-- *****************************************************************
-- Description:     PROCEDURE  UNALLOCATED_TRADE_T_US_CRED
--                  
--
-- Author: Oliver South         
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 Jun 2014     Oliver South   Created
-- *****************************************************************

 PROCEDURE UNALLOCATED_TRADE_T_US_CRED
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: UNALLOCATED_TRADE_T_US_CRED
 -- ****************************************************************   
	OPEN p_CURSOR FOR 
 SELECT     TIERS.name          Fund
,           RISKUSERS.name      Trader
,           FUND_STRATEGY.name  Strategy
,           HISTOMVTS.dateneg   d$Trade_Date
,           TITRES.libelle      Instrument_Name
,           TITRES.reference    Instrument_Reference
,           HISTOMVTS.refcon    n$BTG_Trade_ID
  
FROM        HISTOMVTS
  
INNER JOIN  ( SELECT      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              FROM        folio
              WHERE       LEVEL       > 1 
              START WITH  ident       = 70347 -- US Credit Exec
              CONNECT BY  mgr         = PRIOR ident
              ) STRATEGY
ON          STRATEGY.ident            = HISTOMVTS.opcvm

INNER JOIN  FOLIO FUND_STRATEGY
ON          FUND_STRATEGY.ident = STRATEGY.parent_ident

INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam

INNER JOIN      RISKUSERS
ON              RISKUSERS.ident = HISTOMVTS.operateur

INNER JOIN  TIERS 
ON TIERS.ident = HISTOMVTS.entite

WHERE HISTOMVTS.backoffice in (260) 
;

 -- *****************************************************************
 -- END OF: UNALLOCATED_TRADE_T_US_CRED
 -- ****************************************************************    
  END UNALLOCATED_TRADE_T_US_CRED;  
  


-- *****************************************************************
-- Description:     PROCEDURE  EQENERGYOP_TODAY_TRADES
--                  
--
-- Author: Gustavo Binnie        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 19 Feb 2015     Gustavo Binnie   Created
-- 18 Mar 2016     Gustavo Binnie   PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
 PROCEDURE EQENERGYOP_TODAY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQENERGYOP_TODAY_TRADES
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT      DISTINCT
            FUND_BOOK_STRATEGY.Fund_NAME            Fund_Name
          , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
          , RISKUSERS.name                          Trader
          , HISTOMVTS.dateneg                       d$Trade_Date
          , trunc(HISTOMVTS.DATEVAL)                d$Value_Date
          , TITRES.reference                        Instrument_Reference
          , TITRES.libelle                          Instrument_Name
          , Underlying1.reference                   Underlying_Reference          
          , HISTOMVTS.quantite                      n$Quantity
          , HISTOMVTS.COURS                         Gross_price
          , BTG_FN_GET_NET_PRICE(HISTOMVTS.refcon)  Net_price          
          , HISTOMVTS.FRAISCOURTAGE                 Broker_Fees
          , HISTOMVTS.FRAISCOUNTERPARTY             Counterparty_Fees
          , HISTOMVTS.FRAISMARCHE                   Market_Fees             
          , HISTOMVTS.montant                       Net_Amount
          , Broker.name                             Broker
          , PB.name                                 Depositary
          , case WHEN Block_Trade.BLOCK_ID IS null then HISTOMVTS.refcon else ABS(Block_Trade.BLOCK_ID) end              Block_ID
          , HISTOMVTS.REFCON                        Trade_ID
          , BE.NAME                                 Business_Event
          , HISTOMVTS.OPCVM                         Folio_ID
          , bo_kernel_status.name                   Status                
       
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14045,14414,90565) 
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
LEFT JOIN   titres Underlying1
ON Underlying1.sicovam = case when TITRES.type='A' then TITRES.base1 when TITRES.type='D' then TITRES.codesj when TITRES.type='S' then decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) else decode(TITRES.code_emet,0,decode(TITRES.codesj,0,TITRES.codesj2,TITRES.codesj),TITRES.code_emet) end 
INNER JOIN  TIERS Broker
ON          Broker.ident = HISTOMVTS.courtier
LEFT JOIN  TIERS PB
ON          PB.ident = HISTOMVTS.DEPOSITAIRE
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  bo_kernel_status
ON          bo_kernel_status.id              = HISTOMVTS.backoffice
LEFT JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE      
LEFT JOIN   TA_BLOCK_TO_GENERATED Block_Trade
ON          Block_Trade.generated_id = HISTOMVTS.REFCON
WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND         HISTOMVTS.dateneg = TRUNC(SYSDATE) --Todays trades only
AND       (  (FUND_BOOK_STRATEGY.BOOK_NAME like 'EQ Energy Oportunities%' or FUND_BOOK_STRATEGY.BOOK_NAME like 'EQ Energy%')
			 --EQ Energy Oportunities/EQ US IPO trades and their correspondent execution trade in EQ Energy
           )
ORDER BY    (case when Status like 'Unallocated' then 0 else 1 end), Block_ID, Trade_ID;


 -- *****************************************************************
 -- END OF: EQENERGYOP_TODAY_TRADES
 -- ****************************************************************    
  END EQENERGYOP_TODAY_TRADES;
  
  
  PROCEDURE STALE_CURVE_CROSS_ASSET
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: STALE_CURVE_CROSS_ASSET
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT stale_issuer.issuer_sicovam Sicovam
	,stale_issuer.issuer_name NAME
	,stale_issuer.issuer_ref Reference
	,stale_issuer.isseur_type Kind
	,max(num_to_Date(infos_histo.date_validite)) Last_Update_Date
	
FROM (
	    SELECT DISTINCT issuer.sicovam Issuer_sicovam
		,issuer.libelle issuer_name
		,issuer.reference Issuer_ref
		,decode(issuer.type, 'I', 'Index', 'Issuer') isseur_type
		,to_char(num_to_Date(infos_histo.date_validite), 'YYYYMMDD-HH24:MM')
	FROM titres issuer
	INNER JOIN titres cds
	ON cds.coupon1 = issuer.sicovam
	INNER JOIN (
		SELECT cds.sicovam sicovam
			,cds.reference cds_ref
			,cds.libelle
			,FUND_BOOK_STRATEGY.STRATEGY_ID
			,FUND_BOOK_STRATEGY.STRATEGY_NAME
			,depo.ident
			,depo.reference
			,sum(trades.quantite)
		FROM titres cds
		INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
		INNER JOIN (
			SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
				,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
				,FOLIO.ident AS STRATEGY_ID
				,FOLIO.NAME AS STRATEGY_NAME
				,LEVEL
			FROM FOLIO
			WHERE LEVEL >= 4 START
			WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds 
				CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
			) FUND_BOOK_STRATEGY
			ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
			AND upper(FUND_BOOK_STRATEGY.BOOK_NAME) like 'CROSS ASSET%' -- Only check open CDS for Cross Asset Desk
		INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
		INNER JOIN business_events
		ON business_events.id = trades.type
		AND business_events.compta = 1
		INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.coupon1
		INNER JOIN credit_model
		ON credit_model.code = undelrying.sicovam
		WHERE cds.affectation = 22
			AND trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
		GROUP BY cds.sicovam
			,cds.reference
			,cds.libelle
			,FUND_BOOK_STRATEGY.STRATEGY_ID
			,FUND_BOOK_STRATEGY.STRATEGY_NAME
			,depo.ident
			,depo.reference
		HAVING sum(trades.quantite) != 0
		) open_position -- Only check open CDS for Cross Asset Desk
		ON open_position.sicovam = cds.sicovam
	LEFT JOIN infos_histo
	ON infos_histo.sicovam = issuer.sicovam
	AND trunc(num_to_Date(infos_histo.date_validite)) >= trunc(sysdate - 1) -- Only hit the report if the issuer was last updated more than 1 day ago.
	WHERE infos_histo.sicovam IS NULL
	) stale_issuer-- Picks up issuers that have stale curves
LEFT JOIN infos_histo
ON stale_issuer.Issuer_sicovam = infos_histo.sicovam
GROUP BY stale_issuer.issuer_sicovam
	,stale_issuer.issuer_name
	,stale_issuer.issuer_ref
	,stale_issuer.isseur_type
ORDER BY stale_issuer.issuer_name;


 -- *****************************************************************
 -- END OF: STALE_CURVE_CROSS_ASSET
 -- ****************************************************************    
  END STALE_CURVE_CROSS_ASSET;  
  
  PROCEDURE STALE_CURVE_GLOBAL_CREDIT
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: STALE_CURVE_GLOBAL_CREDIT
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT stale_issuer.issuer_sicovam Sicovam
	,stale_issuer.issuer_name NAME
	,stale_issuer.issuer_ref Reference
	,stale_issuer.isseur_type Kind
	,max(num_to_Date(infos_histo.date_validite)) Last_Update_Date
	
FROM (
	    SELECT DISTINCT issuer.sicovam Issuer_sicovam
		,issuer.libelle issuer_name
		,issuer.reference Issuer_ref
		,decode(issuer.type, 'I', 'Index', 'Issuer') isseur_type
		,to_char(num_to_Date(infos_histo.date_validite), 'YYYYMMDD-HH24:MM')
	FROM titres issuer
	INNER JOIN titres cds
	ON cds.coupon1 = issuer.sicovam
	INNER JOIN (
		SELECT cds.sicovam sicovam
			,cds.reference cds_ref
			,cds.libelle
			,FUND_BOOK_STRATEGY.STRATEGY_ID
			,FUND_BOOK_STRATEGY.STRATEGY_NAME
			,depo.ident
			,depo.reference
			,sum(trades.quantite)
		FROM titres cds
		INNER JOIN histomvts trades
		ON trades.sicovam = cds.sicovam
		INNER JOIN (
			SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
				,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
				,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
				,FOLIO.ident AS STRATEGY_ID
				,FOLIO.NAME AS STRATEGY_NAME
				,LEVEL
			FROM FOLIO
			WHERE LEVEL >= 4 START
			WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds 
				CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
			) FUND_BOOK_STRATEGY
			ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
			AND upper(FUND_BOOK_STRATEGY.BOOK_NAME) like 'GLOBAL CREDIT%' -- Only check open CDS for Global Credit Desk
		INNER JOIN tiers depo
		ON depo.ident = trades.depositaire
		INNER JOIN business_events
		ON business_events.id = trades.type
		AND business_events.compta = 1
		INNER JOIN titres undelrying
		ON undelrying.sicovam = cds.coupon1
		INNER JOIN credit_model
		ON credit_model.code = undelrying.sicovam
		WHERE cds.affectation = 22
			AND trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
		GROUP BY cds.sicovam
			,cds.reference
			,cds.libelle
			,FUND_BOOK_STRATEGY.STRATEGY_ID
			,FUND_BOOK_STRATEGY.STRATEGY_NAME
			,depo.ident
			,depo.reference
		HAVING sum(trades.quantite) != 0
		) open_position -- Only check open CDS for Global Credit Desk
		ON open_position.sicovam = cds.sicovam
	LEFT JOIN infos_histo
	ON infos_histo.sicovam = issuer.sicovam
	AND trunc(num_to_Date(infos_histo.date_validite)) >= trunc(sysdate - 1)-- Only hit the report if the issuer was last updated more than 1 day ago.
	WHERE infos_histo.sicovam IS NULL
	) stale_issuer-- Picks up issuers that have stale curves
LEFT JOIN infos_histo
ON stale_issuer.Issuer_sicovam = infos_histo.sicovam
GROUP BY stale_issuer.issuer_sicovam
	,stale_issuer.issuer_name
	,stale_issuer.issuer_ref
	,stale_issuer.isseur_type
ORDER BY stale_issuer.issuer_name;


 -- *****************************************************************
 -- END OF: STALE_CURVE_GLOBAL_CREDIT
 -- ****************************************************************    
  END STALE_CURVE_GLOBAL_CREDIT;  
  
 
  PROCEDURE ARF_TIMBER_TODAY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: ARF_TIMBER_TODAY_TRADES
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT      DISTINCT
            FUND_BOOK_STRATEGY.Fund_NAME            Fund_Name
          , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
          , RISKUSERS.name                          Trader
          , HISTOMVTS.dateneg                       d$Trade_Date
          , trunc(HISTOMVTS.DATEVAL)                d$Value_Date
          , TITRES.reference                        Instrument_Reference
          , TITRES.libelle                          Instrument_Name
          , Underlying1.reference                   Underlying_Reference          
          , HISTOMVTS.quantite                      n$Quantity
          , HISTOMVTS.COURS                         Gross_price
          , BTG_FN_GET_NET_PRICE(HISTOMVTS.refcon)  Net_price          
          , HISTOMVTS.FRAISCOURTAGE                 Broker_Fees
          , HISTOMVTS.FRAISCOUNTERPARTY             Counterparty_Fees
          , HISTOMVTS.FRAISMARCHE                   Market_Fees             
          , HISTOMVTS.montant                       Net_Amount
          , Broker.name                             Broker
          , PB.name                                 Depositary
          , case WHEN Block_Trade.BLOCK_ID IS null then HISTOMVTS.refcon else ABS(Block_Trade.BLOCK_ID) end              Block_ID
          , HISTOMVTS.REFCON                        Trade_ID
          , BE.NAME                                 Business_Event
          , HISTOMVTS.OPCVM                         Folio_ID
		  , bo_kernel_status.name                   Status                
       
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK,PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14045,14414) 
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
LEFT JOIN   titres Underlying1
ON Underlying1.sicovam = case when TITRES.type='A' then TITRES.base1 when TITRES.type='D' then TITRES.codesj when TITRES.type='S' then decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) else decode(TITRES.code_emet,0,decode(TITRES.codesj,0,TITRES.codesj2,TITRES.codesj),TITRES.code_emet) end 
INNER JOIN  TIERS Broker
ON          Broker.ident = HISTOMVTS.courtier
LEFT JOIN  TIERS PB
ON          PB.ident = HISTOMVTS.DEPOSITAIRE
INNER JOIN  RISKUSERS
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  bo_kernel_status
ON          bo_kernel_status.id              = HISTOMVTS.backoffice   
LEFT JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE   
LEFT JOIN   TA_BLOCK_TO_GENERATED Block_Trade
ON          Block_Trade.generated_id = HISTOMVTS.REFCON
LEFT JOIN   HISTOMVTS Block_Histo
ON          Block_Trade.BLOCK_ID = Block_Histo.REFCON
LEFT JOIN ( 
              SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID                    
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) --(14045)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) BLOCK_STRATEGY
ON BLOCK_STRATEGY.STRATEGY_ID = Block_Histo.OPCVM
WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND         HISTOMVTS.dateneg = TRUNC(SYSDATE) --Todays trades only
AND         BLOCK_STRATEGY.BOOK_ID = '121145'
ORDER BY    (case when Status like 'Unallocated' then 0 else 1 end), Block_ID, Trade_ID;

 -- *****************************************************************
 -- END OF: ARF_TIMBER_TODAY_TRADES
 -- ****************************************************************    
  END ARF_TIMBER_TODAY_TRADES;  

-- *****************************************************************
  -- Description  PROCEDURE CR_ASSET_LOANS_UNSET_TRADES
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015      Gustavo Binnie     (PMOF-188) Created.
  --   31-JAN-2017     Jeff Yu            Add ARF strat for ARF re-launch.(PMGMPMO-211)
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_UNSET_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CR_ASSET_LOANS_UNSET_TRADES 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT      
            TRUNC(sysdate)                          d$Report_Date
          , HISTOMVTS.SICOVAM                       Instrument_Code
          , TITRES.reference                        Reference
          , LOANXID.VALUE														LOANXID
          , TITRES.libelle                          Name
          , Underlying1.LIBELLE                     Issuer
          , HISTOMVTS.REFCON                        Trade_Id
          , FUND_BOOK_STRATEGY.Fund_NAME            Fund_Name
          , PB.name                                 Depositary
          , CASE WHEN HISTOMVTS.QUANTITE > 0 THEN 'BUY' ELSE 'SELL' END Direction
          , HISTOMVTS.quantite                      p$2$Quantity
          , HISTOMVTS.COURS                         Gross_price
          , Cpty.name                               Counterparty
          , HISTOMVTS.dateneg                       d$Trade_Date
          , TRUNC(sysdate)-TRUNC(HISTOMVTS.dateneg) Days_Since_TD
          , HISTOMVTS.DATEVAL                       d$Payment_Date

       
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS) -- (PCKG_BTG.FOLIO_EXECUTION_BOOK,PCKG_BTG.FOLIO_PRIMARY_FUNDS) --
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam

LEFT JOIN   titres Underlying1
ON Underlying1.sicovam = case when TITRES.type='A' then TITRES.base1 when TITRES.type='D' then TITRES.codesj when TITRES.type='S' then decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) else decode(TITRES.code_emet,0,decode(TITRES.codesj,0,TITRES.codesj2,TITRES.codesj),TITRES.code_emet) end 
AND Underlying1.TYPE = 'H'

INNER JOIN  TIERS Cpty
ON          Cpty.ident = HISTOMVTS.CONTREPARTIE

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS LOANXID
ON LOANXID.SOPHIS_IDENT = HISTOMVTS.SICOVAM
AND LOANXID.REF_IDENT = 27

LEFT JOIN  TIERS PB
ON          PB.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE      
AND         BE.COMPTA = 1


WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (121063,121064,127258)     ---Add ARF fund                                                                               
                                       START WITH IDENT = HISTOMVTS.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
        )
AND         trunc(HISTOMVTS.DATEVAL) > trunc(sysdate)
AND         TITRES.AFFECTATION = 1400 --Bank Loans
order by trunc(HISTOMVTS.DATENEG), TITRES.LIBELLE
;

	-- ***************************************************************************
  -- END OF CR_ASSET_LOANS_UNSET_TRADES 
  -- ***************************************************************************	
 END CR_ASSET_LOANS_UNSET_TRADES;

 -- *****************************************************************
  -- Description  PROCEDURE CR_ASSET_LOANS_NB_UNSET_TRADES
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015      Gustavo Binnie     (PMOF-188) Created.
  --   31-JAN-2017      Jeff Yu                Add ARF strat for ARF re-launch.(PMGMPMO-211)
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_NB_UNSET_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CR_ASSET_LOANS_NB_UNSET_TRADES 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT    COUNT(*)      NB_TRANSACTIONS
FROM        HISTOMVTS
INNER JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE      
AND         BE.COMPTA = 1
INNER JOIN   TITRES
ON          HISTOMVTS.SICOVAM = TITRES.SICOVAM
WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (121063,121064,127258)            --Add ARF fund                                                                        
                                       START WITH IDENT = HISTOMVTS.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
        )
AND         trunc(HISTOMVTS.DATEVAL) > trunc(sysdate)
AND         TITRES.AFFECTATION = 1400 --Bank Loans
;

	-- ***************************************************************************
  -- END OF CR_ASSET_LOANS_NB_UNSET_TRADES 
  -- ***************************************************************************	
 END CR_ASSET_LOANS_NB_UNSET_TRADES;

 -- *****************************************************************
  -- Description  PROCEDURE CR_ASSET_LOANS_SET_TRADES
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015      Gustavo Binnie     (PMOF-188) Created.
  --   31-JAN-2017      Jeff Yu               Add ARF strat for ARF re-launch.(PMGMPMO-211)
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_SET_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CR_ASSET_LOANS_SET_TRADES 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT      
            trunc(sysdate)                          d$Report_Date
          , HISTOMVTS.SICOVAM                       Instrument_Code
          , TITRES.reference                        Reference
          , LOANXID.VALUE														LOANXID
          , TITRES.libelle                          Name
          , Underlying1.LIBELLE                     Issuer
          , HISTOMVTS.REFCON                        Trade_Id
          , FUND_BOOK_STRATEGY.Fund_NAME            Fund_Name
          , PB.name                                 Depositary
          , CASE WHEN HISTOMVTS.QUANTITE > 0 THEN 'BUY' ELSE 'SELL' END Direction
          , HISTOMVTS.quantite                      p$2$Quantity
          , HISTOMVTS.COURS                         Gross_price
          , Cpty.name                               Counterparty
          , HISTOMVTS.dateneg                       d$Trade_Date
          , trunc(sysdate)-TRUNC(HISTOMVTS.dateneg) Days_Since_TD
          , HISTOMVTS.DATEVAL                       d$Payment_Date

       
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- 
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam

LEFT JOIN   titres Underlying1
ON Underlying1.sicovam = case when TITRES.type='A' then TITRES.base1 when TITRES.type='D' then TITRES.codesj when TITRES.type='S' then decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) else decode(TITRES.code_emet,0,decode(TITRES.codesj,0,TITRES.codesj2,TITRES.codesj),TITRES.code_emet) end 
AND Underlying1.TYPE = 'H'

INNER JOIN  TIERS Cpty
ON          Cpty.ident = HISTOMVTS.CONTREPARTIE

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS LOANXID
ON LOANXID.SOPHIS_IDENT = HISTOMVTS.SICOVAM
AND LOANXID.REF_IDENT = 27

LEFT JOIN  TIERS PB
ON          PB.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE      
AND         BE.COMPTA = 1


WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (121063,121064,127258)       ---Add ARF fund                                                                             
                                       START WITH IDENT = HISTOMVTS.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
        )
AND         trunc(HISTOMVTS.DATEVAL) = trunc(sysdate)
AND         TITRES.AFFECTATION = 1400 --Bank Loans
order by trunc(HISTOMVTS.DATENEG), TITRES.LIBELLE
;

	-- ***************************************************************************
  -- END OF CR_ASSET_LOANS_SET_TRADES 
  -- ***************************************************************************	
 END CR_ASSET_LOANS_SET_TRADES;

 -- *****************************************************************
  -- Description  PROCEDURE CR_ASSET_LOANS_NB_SET_TRADES
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015      Gustavo Binnie     (PMOF-188) Created.
  --   31-JAN-2017      Jeff Yu             Modified per PMGMPMO-211.
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_NB_SET_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CR_ASSET_LOANS_NB_SET_TRADES 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
SELECT    COUNT(*)      NB_TRANSACTIONS
FROM        HISTOMVTS
INNER JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE      
AND         BE.COMPTA = 1
INNER JOIN   TITRES
ON          HISTOMVTS.SICOVAM = TITRES.SICOVAM
WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND EXISTS (                                                                                                                                                    
                                       SELECT 1 FROM FOLIO                               
                                       WHERE IDENT  IN (121063,121064,127258)      ---Add ARF Fund                                                                              
                                       START WITH IDENT = HISTOMVTS.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                 
        )
AND         trunc(HISTOMVTS.DATEVAL) = trunc(sysdate)
AND         TITRES.AFFECTATION = 1400 --Bank Loans
;

	-- ***************************************************************************
  -- END OF CR_ASSET_LOANS_NB_SET_TRADES 
  -- ***************************************************************************	
 END CR_ASSET_LOANS_NB_SET_TRADES;

 PROCEDURE EQ_EVENTS_NY_TODAY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: EQ_EVENTS_NY_TODAY_TRADES
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT      DISTINCT
            FUND_BOOK_STRATEGY.Fund_NAME            Fund_Name
          , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
          , RISKUSERS.name                          Trader
          , HISTOMVTS.dateneg                       d$Trade_Date
          , trunc(HISTOMVTS.DATEVAL)                d$Value_Date
          , TITRES.reference                        Instrument_Reference
          , TITRES.libelle                          Instrument_Name
          , Underlying1.reference                   Underlying_Reference          
          , HISTOMVTS.quantite                      n$Quantity
          , HISTOMVTS.COURS                         Gross_price
          , BTG_FN_GET_NET_PRICE(HISTOMVTS.refcon)  Net_price          
          , HISTOMVTS.FRAISCOURTAGE                 Broker_Fees
          , HISTOMVTS.FRAISCOUNTERPARTY             Counterparty_Fees
          , HISTOMVTS.FRAISMARCHE                   Market_Fees             
          , HISTOMVTS.montant                       Net_Amount
          , Broker.name                             Broker
          , PB.name                                 Depositary
          , case WHEN Block_Trade.BLOCK_ID IS null then HISTOMVTS.refcon else ABS(Block_Trade.BLOCK_ID) end              Block_ID
          , HISTOMVTS.REFCON                        Trade_ID
          , BE.NAME                                 Business_Event
          , HISTOMVTS.OPCVM                         Folio_ID
		  , bo_kernel_status.name                   Status                
       
FROM        HISTOMVTS
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID
                    , FOLIO.name                                                            AS STRATEGY_NAME
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK,PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14045,14414,90565) 
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
LEFT JOIN   titres Underlying1 --Underlying Instrument
ON Underlying1.sicovam = case when TITRES.type='A' then TITRES.base1 when TITRES.type='D' then TITRES.codesj when TITRES.type='S' then decode(TITRES.jambe1,1,TITRES.j2refcon2,decode(TITRES.j1refcon2,0,TITRES.j2refcon2,TITRES.j1refcon2)) else decode(TITRES.code_emet,0,decode(TITRES.codesj,0,TITRES.codesj2,TITRES.codesj),TITRES.code_emet) end 
INNER JOIN  TIERS Broker
ON          Broker.ident = HISTOMVTS.courtier
LEFT JOIN  TIERS PB
ON          PB.ident = HISTOMVTS.DEPOSITAIRE
INNER JOIN  RISKUSERS -- Trader
ON          RISKUSERS.ident = HISTOMVTS.operateur
INNER JOIN  bo_kernel_status -- Status
ON          bo_kernel_status.id              = HISTOMVTS.backoffice   
LEFT JOIN   BUSINESS_EVENTS BE
ON          BE.ID                            = HISTOMVTS.TYPE   
LEFT JOIN   TA_BLOCK_TO_GENERATED Block_Trade --Parent Trade
ON          Block_Trade.generated_id = HISTOMVTS.REFCON
LEFT JOIN   HISTOMVTS Block_Histo
ON          Block_Trade.BLOCK_ID = Block_Histo.REFCON
LEFT JOIN ( 
              SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                    , FOLIO.ident                                                           AS STRATEGY_ID                    
                    , level
              FROM FOLIO
              WHERE 
              LEVEL >= 3
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) --(14045)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
             ) BLOCK_STRATEGY --Parent Trade Execution Book Strategy
ON BLOCK_STRATEGY.STRATEGY_ID = Block_Histo.OPCVM
WHERE       HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND         HISTOMVTS.dateneg = TRUNC(SYSDATE) --Todays trades only
AND         (FUND_BOOK_STRATEGY.BOOK_ID = '121693' OR BLOCK_STRATEGY.BOOK_ID = '121693')  --Equity Events NY Execution Book Folio
ORDER BY    (case when Status like 'Unallocated' then 0 else 1 end), Block_ID, Trade_ID; -- First the Unallocated trades, then order by Parent Trade ID and then trade id

 -- *****************************************************************
 -- END OF: EQ_EVENTS_NY_TODAY_TRADES
 -- ****************************************************************    
  END EQ_EVENTS_NY_TODAY_TRADES;  
 
 
  PROCEDURE LOANS_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: LOANS_COUPONS
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT  ALL1.Report_Date			 d$Report_Date,
        ALL1.Instrument_Code,
        ALL1.Reference,
        ALL1.LOANX_ID,
        ALL1.Name,
        ALL1.Fund_Name,
        ALL1.Depositary,
        ALL1.POSITION_PCD            n$POSITION_PREV_COUP_DATE,  
        ALL1.POSITION_TODAY          n$POSITION_TODAY,   
        ALL1.PREVIOUS_Coupon_Date    d$PREVIOUS_Coupon_Date,
        ALL1.Next_Coupon_Date        d$Next_Coupon_Date,
        ALL1.DAYS_TO_COUPON  

FROM (

SELECT  BL2.Report_Date,
        BL2.Instrument_Code,
        BL2.Reference,
        BL2.LOANX_ID,
        BL2.Name,
        BL2.Fund_Name,
        BL2.Depositary,
        CASE
                WHEN BL2.POSITION_PCD IS NULL  THEN 0
                ELSE BL2.POSITION_PCD 
        END                                                                   POSITION_PCD,  
        
        CASE
                WHEN BL2.POSITION_TODAY IS NULL  THEN 0
                ELSE BL2.POSITION_TODAY
        END                                                                   POSITION_TODAY,   
                                                                                                                   
        CASE
                WHEN BL2.PC_DATE IS NULL  THEN SD.START_DATE
                ELSE BL2.PC_DATE 
        END                                                                   PREVIOUS_Coupon_Date,
        
        BL2.Next_Coupon_Date                                                  Next_Coupon_Date,
        TO_NUMBER(TO_DATE(BL2.Next_Coupon_Date)-TO_DATE(BL2.Report_Date))     DAYS_TO_COUPON  
        
FROM (SELECT BL.Report_Date,BL.Instrument_Code,BL.Reference,BL.LOANX_ID,BL.Name,BL.Fund_Name,BL.Depositary,BL.POSITION_PCD,POSTODAY.POSITION_TODAY,BL.PC_DATE,
       MIN(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY'))									  Next_Coupon_Date                        
FROM 

--1--POSITION <= PREVIOUS COUPON ----------------------------------------------------------------------------------------------------------------------------------------
(SELECT BL0.REPORT_DATE,BL0.INSTRUMENT_CODE,BL0.REFERENCE,BL0.LOANX_ID,BL0.NAME,BL0.Fund_NAME,BL0.DEPOSITARY,BL0.PC_DATE,
ROUND(SUM(BL0.quantite),2)                                                                                                    POSITION_PCD
FROM (

SELECT            sysdate                                                                                                                             Report_Date,
                  TITRES.SICOVAM                                                                                                                      Instrument_Code,  
                  TITRES.Reference                                                                                                                    Reference,
                  EXTRNL_REFERENCES_INSTRUMENTS.VALUE                                                                                                 LOANX_ID,
                  TITRES.libelle	                                                                                                                    Name,               
                  FUND_BOOK_STRATEGY.Fund_NAME                                                                                                        Fund_Name,
                  DEPOSITARY.name                                                                                                                     Depositary, 
                  HISTOMVTS.quantite,
                  HISTOMVTS.DATEVAL,
                  PC.PC_DATE,
                  CASE WHEN HISTOMVTS.DATEVAL <= PC.PC_DATE THEN 'IN' ELSE 'OUT' END                                                                   AS  "PC"  --FLAG TRADE_IDS BEFORE THE PREVIOUS_COUPON DATE

FROM            HISTOMVTS

INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) -- Primary funds
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position trades only

INNER JOIN  TIERS DEPOSITARY
ON          DEPOSITARY.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND          AFFECTATION.ident = 1400

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON        EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = TITRES.SICOVAM
AND       EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 27

LEFT JOIN 
(SELECT TITRES.SICOVAM,MAX(trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY'))) PC_DATE FROM TITRES
INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND          AFFECTATION.ident = 1400
INNER JOIN FLUXJAMBE
ON TITRES.SICOVAM = FLUXJAMBE.SICOVAM
AND trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY')) <= TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM
)PC
ON        PC.SICOVAM = TITRES.SICOVAM

WHERE     HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades

)BL0
WHERE     BL0.PC = 'IN' -- ONLY TRADES WHERE THE VALUE DATE < PREVIOUS COUPON DATE
GROUP BY BL0.REPORT_DATE,BL0.INSTRUMENT_CODE,BL0.REFERENCE,BL0.LOANX_ID,BL0.NAME,BL0.Fund_NAME,BL0.DEPOSITARY,BL0.PC_DATE

)BL
--1-------------------------------------------------------------------------------------------------------------------------------
FULL OUTER JOIN

--2--- POSITION <= SYSDATE-------------------------------------------------------------------------------------------------------

(SELECT BLL.Report_Date,BLL.Instrument_Code,BLL.Reference,BLL.LOANX_ID,BLL.Name,BLL.Fund_Name,BLL.Depositary,BLL.POSITION_TODAY                    
FROM (SELECT      sysdate                                                                                                                             Report_Date,
                  TITRES.SICOVAM                                                                                                                      Instrument_Code,  
                  TITRES.Reference                                                                                                                    Reference,
                  EXTRNL_REFERENCES_INSTRUMENTS.VALUE                                                                                                 LOANX_ID,
                  TITRES.libelle	                                                                                                                    Name,               
                  FUND_BOOK_STRATEGY.Fund_NAME                                                                                                        Fund_Name,
                  DEPOSITARY.name                                                                                                                     Depositary,
                  ROUND(SUM(HISTOMVTS.quantite),2)                                                                                                    POSITION_TODAY
                  
FROM            HISTOMVTS

INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN  (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) -- Primary funds
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position trades only

INNER JOIN  TIERS DEPOSITARY
ON          DEPOSITARY.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND         AFFECTATION.ident = 1400

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON        EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = TITRES.SICOVAM
AND       EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 27

WHERE     HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND		  HISTOMVTS.dateval <=sysdate
GROUP BY sysdate,TITRES.SICOVAM,TITRES.Reference,EXTRNL_REFERENCES_INSTRUMENTS.VALUE,TITRES.libelle,FUND_BOOK_STRATEGY.Fund_NAME,DEPOSITARY.name

)BLL)POSTODAY
ON POSTODAY.Instrument_Code = BL.Instrument_Code
AND POSTODAY.Depositary = BL.Depositary
--2-----------------------------------------------------------------------------------------------------------------------------------------------

INNER JOIN FLUXJAMBE
ON BL.Instrument_Code = FLUXJAMBE.SICOVAM
AND trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY')) >= TRUNC(SYSDATE)

group by BL.Report_Date,BL.Instrument_Code,BL.Reference,BL.LOANX_ID,BL.Name,BL.Fund_Name,BL.Depositary,BL.PC_DATE,POSTODAY.POSITION_TODAY,BL.POSITION_PCD)BL2

INNER JOIN (SELECT TITRES.SICOVAM,MIN(trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.DEBUT ),'DD-MON-YYYY'),'DD-MON-YYYY'))) START_DATE FROM TITRES
INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND         AFFECTATION.ident = 1400
INNER JOIN FLUXJAMBE
ON TITRES.SICOVAM = FLUXJAMBE.SICOVAM
GROUP BY TITRES.SICOVAM
)SD
ON        SD.SICOVAM = BL2.Instrument_Code
)ALL1

WHERE (ALL1.POSITION_PCD <> 0
OR ALL1.POSITION_TODAY <> 0)
and ALL1.Instrument_Code > 70377812

ORDER BY 11,2
;

 -- *****************************************************************
 -- END OF: LOANS_COUPONS
 -- ****************************************************************    
  END LOANS_COUPONS;
  

 -- *****************************************************************
  -- Description  PROCEDURE LOANS_COUPONS_POS_0
  --
-- Author: Davi Xavier       
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 19 NOV 2015      Davi Xavier   Created
  -- *****************************************************************
  PROCEDURE LOANS_COUPONS_POS_0
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF LOANS_COUPONS_POS_0 
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT TRADESBL.Report_Date            d$Report_Date,
TRADESBL.Instrument_Code,
TRADESBL.Reference,
TRADESBL.Loanxid,
TRADESBL.Name,
TRADESBL.Issuer,
TRADESBL.Trade_Id ,
TRADESBL.Fund_Name ,
TRADESBL.Depositary_Code ,
TRADESBL.Depositary,
TRADESBL.BUSINESS_EVENTS ,
TRADESBL.Direction ,
TRADESBL.Quantity                       n$Quantity,
TRADESBL.Gross_Price ,
TRADESBL.Counterparty ,
TRADESBL.Tradedate                      d$Tradedate ,
TRADESBL.Payment_Date                   d$Payment_Date ,
BLPOS.PREVIOUS_Coupon_Date              d$PREVIOUS_Coupon_Date,
BLPOS.Next_Coupon_Date                  d$Next_Coupon_Date

from(SELECT  ALL1.Instrument_Code,ALL1.Depositary,ALL1.PREVIOUS_Coupon_Date,ALL1.Next_Coupon_Date

FROM (SELECT  BL2.Report_Date,
        BL2.Instrument_Code,
        BL2.Reference,
        BL2.LOANX_ID,
        BL2.Name,
        BL2.Fund_Name,
        BL2.Depositary,
        CASE
                WHEN BL2.POSITION_PCD IS NULL  THEN 0
                ELSE BL2.POSITION_PCD 
        END                                                                   POSITION_PCD,  
        
        CASE
                WHEN BL2.POSITION_TODAY IS NULL  THEN 0
                ELSE BL2.POSITION_TODAY
        END                                                                   POSITION_TODAY,   
 -----------------------------------***                                                                                                                  
        CASE 
                WHEN BL2.PC_DATE < SD.START_DATE  THEN SD.START_DATE
                ELSE BL2.PC_DATE 
        END                                                                   PREVIOUS_Coupon_Date,
        
        BL2.Next_Coupon_Date                                                  Next_Coupon_Date,
        TO_NUMBER(TO_DATE(BL2.Next_Coupon_Date)-TO_DATE(BL2.Report_Date))     DAYS_TO_COUPON  
       ---------------- 
FROM (SELECT BL.Report_Date,BL.Instrument_Code,BL.Reference,BL.LOANX_ID,BL.Name,BL.Fund_Name,BL.Depositary,BL.POSITION_PCD,POSTODAY.POSITION_TODAY,BL.PC_DATE,
       MIN(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY'))									  Next_Coupon_Date                        
FROM 

--1--POSITION <= PREVIOUS COUPON ----------------------------------------------------------------------------------------------------------------------------------------
(SELECT BL0.REPORT_DATE,BL0.INSTRUMENT_CODE,BL0.REFERENCE,BL0.LOANX_ID,BL0.NAME,BL0.Fund_NAME,BL0.DEPOSITARY,BL0.PC_DATE,
ROUND(SUM(BL0.quantite),2)                                                                                                    POSITION_PCD
FROM (

SELECT            SYSDATE                                                                                                                             Report_Date,
                  TITRES.SICOVAM                                                                                                                      Instrument_Code,  
                  TITRES.Reference                                                                                                                    Reference,
                  EXTRNL_REFERENCES_INSTRUMENTS.VALUE                                                                                                 LOANX_ID,
                  TITRES.libelle	                                                                                                                    Name,               
                  FUND_BOOK_STRATEGY.Fund_NAME                                                                                                        Fund_Name,
                  DEPOSITARY.ident                                                                                                                     Depositary, 
                  CASE WHEN HISTOMVTS.DATEVAL <= PC.PC_DATE THEN HISTOMVTS.quantite ELSE 0 END quantite,
                  HISTOMVTS.DATEVAL,
                  PC.PC_DATE 

FROM            HISTOMVTS

INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN  (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) --Primary funds
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position trades only

INNER JOIN  TIERS DEPOSITARY
ON          DEPOSITARY.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND          AFFECTATION.ident = 1400

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON        EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = TITRES.SICOVAM
AND       EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 27

LEFT JOIN 
(SELECT TITRES.SICOVAM,MAX(trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY'))) PC_DATE FROM TITRES
INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND          AFFECTATION.ident = 1400
INNER JOIN FLUXJAMBE
ON TITRES.SICOVAM = FLUXJAMBE.SICOVAM
AND trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY')) < TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM
)PC
ON        PC.SICOVAM = TITRES.SICOVAM

WHERE     HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades

)BL0
--WHERE     BL0.PC = 'IN' -- ONLY TRADES WHERE THE VALUE DATE < PREVIOUS COUPON DATE
GROUP BY BL0.REPORT_DATE,BL0.INSTRUMENT_CODE,BL0.REFERENCE,BL0.LOANX_ID,BL0.NAME,BL0.Fund_NAME,BL0.DEPOSITARY,BL0.PC_DATE

)BL
--1-------------------------------------------------------------------------------------------------------------------------------
FULL OUTER JOIN

--2--- POSITION <= SYSDATE -------------------------------------------------------------------------------------------------------

(SELECT BLL.Report_Date,BLL.Instrument_Code,BLL.Reference,BLL.LOANX_ID,BLL.Name,BLL.Fund_Name,BLL.Depositary,BLL.POSITION_TODAY                    
FROM (SELECT      SYSDATE                                                                                                                             Report_Date,
                  TITRES.SICOVAM                                                                                                                      Instrument_Code,  
                  TITRES.Reference                                                                                                                    Reference,
                  EXTRNL_REFERENCES_INSTRUMENTS.VALUE                                                                                                 LOANX_ID,
                  TITRES.libelle	                                                                                                                    Name,               
                  FUND_BOOK_STRATEGY.Fund_NAME                                                                                                        Fund_Name,
                  DEPOSITARY.ident                                                                                                                   Depositary,
                  ROUND(SUM(HISTOMVTS.quantite),2)                                                                                                    POSITION_TODAY
                  
FROM            HISTOMVTS

INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN   (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position trades only

INNER JOIN  TIERS DEPOSITARY
ON          DEPOSITARY.ident = HISTOMVTS.DEPOSITAIRE

INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND         AFFECTATION.ident = 1400

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON        EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = TITRES.SICOVAM
AND       EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 27

WHERE     HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND		  HISTOMVTS.dateval <=sysdate
GROUP BY sysdate,TITRES.SICOVAM,TITRES.Reference,EXTRNL_REFERENCES_INSTRUMENTS.VALUE,TITRES.libelle,FUND_BOOK_STRATEGY.Fund_NAME,DEPOSITARY.ident

)BLL)POSTODAY
ON POSTODAY.Instrument_Code = BL.Instrument_Code
AND POSTODAY.Depositary = BL.Depositary
--2-----------------------------------------------------------------------------------------------------------------------------------------------

INNER JOIN FLUXJAMBE
ON BL.Instrument_Code = FLUXJAMBE.SICOVAM
AND trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.FIN ),'DD-MON-YYYY'),'DD-MON-YYYY')) >= TRUNC(SYSDATE)

group by BL.Report_Date,BL.Instrument_Code,BL.Reference,BL.LOANX_ID,BL.Name,BL.Fund_Name,BL.Depositary,BL.PC_DATE,POSTODAY.POSITION_TODAY,BL.POSITION_PCD
--
)BL2

INNER JOIN (SELECT TITRES.SICOVAM,MIN(trunc(to_date(TO_CHAR((to_date('01/01/1904','MM/DD/YYYY') + FLUXJAMBE.DEBUT ),'DD-MON-YYYY'),'DD-MON-YYYY'))) START_DATE FROM TITRES
INNER JOIN   AFFECTATION
ON           AFFECTATION.ident = TITRES.affectation
AND         AFFECTATION.ident = 1400
INNER JOIN FLUXJAMBE
ON TITRES.SICOVAM = FLUXJAMBE.SICOVAM
GROUP BY TITRES.SICOVAM
)SD
ON        SD.SICOVAM = BL2.Instrument_Code
)ALL1

WHERE ALL1.POSITION_PCD = 0
and ALL1.POSITION_TODAY = 0


)BLPOS


inner join 
(select  sysdate                              Report_date,
        trades.sicovam                        Instrument_Code,
        Instrument.reference                  Reference, 	
        EXTRNL_REFERENCES_INSTRUMENTS.VALUE   Loanxid, 	
       	Instrument.libelle                    Name,
        ISSUER.libelle                        Issuer,
        Trades.refcon                         Trade_Id,
        FUND_BOOK_STRATEGY.FUND_NAME          Fund_Name,
        Trades.DEPOSITAIRE                    DEPOSITARY_CODE,
        DEPOSITARY.Name                       Depositary,
        BUSINESS_EVENTS.NAME                   BUSINESS_EVENTS,
        DECODE(SIGN(trades.quantite), - 1, 'SELL', 'BUY') AS Direction,
        Trades.quantite                       Quantity,
        Trades.cours                          Gross_Price,
        Counterparty.name                     Counterparty,
        trunc(Trades.DATENEG)                 TradeDate,
        trunc(Trades.DATEVAL)                 Payment_Date 
        
from            histomvts Trades 

INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id = trades.type
AND             BUSINESS_EVENTS.compta = 1 --position trades only

inner join      titres Instrument
on              Instrument.sicovam = Trades.sicovam 

INNER JOIN      TITRES SEC
ON              SEC.SICOVAM = TRADES.SICOVAM

LEFT JOIN       TITRES ISSUER
ON              SEC.CODE_EMET = ISSUER.SICOVAM

INNER JOIN      TIERS DEPOSITARY
ON              trades.Depositaire = DEPOSITARY.Ident --link to depositary
        
left join       Tiers Counterparty
on              Counterparty.ident = trades.contrepartie

INNER JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS FOLIO_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS FOLIO_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5) AS FOLIO_ID2
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5) AS FOLIO_NAME2
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 5, 6) AS FOLIO_ID3
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 5, 6) AS FOLIO_NAME3
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  , level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- 
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON        EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = Instrument.SICOVAM
AND       EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 27
WHERE     trades.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       trunc(Trades.DATENEG)>='16-JUN-15'
AND       FUND_BOOK_STRATEGY.FOLIO_ID3 IN (121064,121063)

)TRADESBL

on        TRADESBL.INSTRUMENT_CODE = BLPOS.INSTRUMENT_CODE
and        TRADESBL.DEPOSITARY_CODE = BLPOS.DEPOSITARY

WHERE TRADESBL.PAYMENT_DATE > BLPOS.PREVIOUS_Coupon_Date
AND TRADESBL.PAYMENT_DATE <= BLPOS.Next_Coupon_Date
ORDER BY TRADESBL.NAME, TRADESBL.FUND_NAME, TRADESBL.DEPOSITARY, TRADESBL.TRADEDATE;

	-- ***************************************************************************
  -- END OF LOANS_COUPONS_POS_0 
  -- ***************************************************************************	
 END LOANS_COUPONS_POS_0;

 -- *****************************************************************
  -- Description  PROCEDURE GEMM_POS_CHANGE_TDY
  --
-- Author: Davi Xavier       
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 19 NOV 2015      Davi Xavier   Created
-- 28 FEB 2017        Jeff Yu         Modified (PMGMRISK-90)
  -- *****************************************************************
  PROCEDURE GEMM_POS_CHANGE_TDY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF GEMM_POS_CHANGE_TDY
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$SOD_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Now_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END SOD_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Now_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                            Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12505 -- GEMM
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

	-- ***************************************************************************
  -- END OF GEMM_POS_CHANGE_TDY 
  -- ***************************************************************************	
 END GEMM_POS_CHANGE_TDY;
 
  -- *****************************************************************
  -- Description  PROCEDURE QSF_POS_CHANGE_TDY
  --
-- Author: Davi Xavier       
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 19 NOV 2015      Davi Xavier   Created
  -- *****************************************************************
  PROCEDURE QSF_POS_CHANGE_TDY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF QSF_POS_CHANGE_TDY
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$SOD_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Now_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END SOD_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Now_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 93654 -- QSF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

	-- ***************************************************************************
  -- END OF QSF_POS_CHANGE_TDY 
  -- ***************************************************************************	
 END QSF_POS_CHANGE_TDY;

  -- *****************************************************************
  -- Description  PROCEDURE ARF_POS_CHANGE_TDY
  --
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 06 FEB 2017      Gustavo Binnie   Created (PMOG-1091)
-- 28 FEB 2017      Jeff Yu        Modified (PMGMRISK-90)
  -- *****************************************************************
  PROCEDURE ARF_POS_CHANGE_TDY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF ARF_POS_CHANGE_TDY
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$SOD_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Now_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END SOD_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Now_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                            Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 12506 -- ARF
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

	-- ***************************************************************************
  -- END OF ARF_POS_CHANGE_TDY 
  -- ***************************************************************************	
 END ARF_POS_CHANGE_TDY;

 -- *****************************************************************
-- Description:     PROCEDURE  EQ_ENERGYOP_UPCMNG_DVDNDS
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 18 MAR 2016      Gustavo Binnie   PMOG-930 - Created
-- 31 JAN 2017        Jeff Yu              PMGMPMO-211 Modified 
-- *****************************************************************
   PROCEDURE EQ_ENERGYOP_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_ENERGYOP_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
           SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       HISTOMVTS
             
             INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (126187)--GEMM EQ Energy Oportunities
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
						   UNION
						   SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (128616)--ARF EQ Energy Oportunities
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)      
      
      ORDER BY 1, 2, 3, 7; 
 -- *****************************************************************
 -- END OF: EQ_ENERGYOP_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_ENERGYOP_UPCMNG_DVDNDS;  

-- *****************************************************************
-- Description:     PROCEDURE  SEC_PRODUCTS_POSCHANGE
-- Revision History
-- Date             Author         Reason for Change
-- 26-MAY-2016		Gustavo Binnie Created (GAMCP-21)
-- 31-JAN-2017        Jeff Yu   Modified (PMGMPMO-211)
-- ----------------------------------------------------------------       
 PROCEDURE SEC_PRODUCTS_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

 -- *****************************************************************
 -- START OF: SEC_PRODUCTS_POSCHANGE
 -- ****************************************************************      
    OPEN p_CURSOR FOR   
      SELECT    CLIENTS.libelle                                                                         AS FUND
              , FOLIOS.FOLIO_NAME                                                                       AS STRATEGY
              , TITRES.libelle                                                                          AS INSTRUMENT
              , POSITIONS.YESTERDAY                                                                     AS n$YESTERDAYS_POSITION
              , POSITIONS.TODAY                                                                         AS n$TODAYS_POSITION
              , CASE 
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'FLAT'
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'FLAT'
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'SHORT'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'SHORT' 
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                ELSE 'UNKNOWN'
              END                                                                                      AS YESTERDAYS_STATE
              , CASE 
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'SHORT'
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'SHORT'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FLAT'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
                ELSE 'UNKNOWN'
              END                                                                                     AS TODAYS_STATE
              , CASE 
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0)  THEN 'NEW POSITION'
                WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0)  THEN 'NEW POSITION'
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL LONG UNWIND'
                WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0)                          THEN 'FULL LONG UNWIND CROSSING ZERO'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0)                          THEN 'FULL SHORT UNWIND'
                WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0)                          THEN 'FULL SHORT UNWIND CROSSING ZERO'
                WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
                WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
                ELSE 'UNKNOWN'
              END                                                                                   AS ACTION_TAKEN
              ,  FOLIOS.FOLIO_FULL_NAME                                                             AS STRATEGY_FULL_NAME
      FROM     (
                  SELECT  HISTOMVTS.entite                                      AS FUND_ID
                        , HISTOMVTS.opcvm                                       AS FOLIO_ID
                        , HISTOMVTS.sicovam                                     AS INSTRUMENT_ID
                        , SUM(HISTOMVTS.quantite)                               AS TODAY
                        , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) 
                                   THEN HISTOMVTS.quantite 
                                   ELSE 0 
                               END)                                             AS YESTERDAY  
                  FROM       HISTOMVTS
                  INNER JOIN BO_KERNEL_STATUS_COMPONENT
                  ON         BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                  AND        BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                  INNER JOIN BUSINESS_EVENTS 
                  ON         BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                  AND        BUSINESS_EVENTS.COMPTA                            = 1
                  WHERE      HISTOMVTS.dateneg                                 <= trunc(sysdate)
                  GROUP BY   HISTOMVTS.entite
                  ,          HISTOMVTS.opcvm
                  ,          HISTOMVTS.sicovam
                 ) POSITIONS
      INNER JOIN (
                    SELECT FOLIO.ident                                          AS FOLIO_ID
                          , FOLIO.name                                          AS FOLIO_NAME
                          , SYS_CONNECT_BY_PATH(FOLIO.name, '\')                AS FOLIO_FULL_NAME
                    FROM FOLIO  
                    WHERE LEVEL > 1
                    START WITH FOLIO.ident IN (126201) -- Securitized Products (GEMM)
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
					UNION
					SELECT FOLIO.ident                                          AS FOLIO_ID
                          , FOLIO.name                                          AS FOLIO_NAME
                          , SYS_CONNECT_BY_PATH(FOLIO.name, '\')                AS FOLIO_FULL_NAME
                    FROM FOLIO  
                    WHERE LEVEL > 1
                    START WITH FOLIO.ident IN (128696) -- Securitized Products (ARF)
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) FOLIOS
      ON            FOLIOS.FOLIO_ID     =    POSITIONS.FOLIO_ID
      
      INNER JOIN    TITRES 
      ON            TITRES.sicovam       =    POSITIONS.INSTRUMENT_ID      
      AND           TITRES.type         !=    'L'
      
      INNER JOIN    CLIENTS
      ON            CLIENTS.ident        =     POSITIONS.fund_id
      
      WHERE         (NVL(POSITIONS.TODAY, 0) - NVL(POSITIONS.YESTERDAY, 0)) <> 0
      ORDER BY 1, 2, 3;
      
 -- *****************************************************************
 -- END OF: SEC_PRODUCTS_POSCHANGE
 -- ****************************************************************      
  END SEC_PRODUCTS_POSCHANGE;

-- *****************************************************************
-- Description:     PROCEDURE  SEC_PRODUCTS_TODAYSTRADES
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 26-MAY-2016		Gustavo Binnie Created (GAMCP-21)
-- 20-JUN-2018     Jeff Yu  Modified (PMGMRISK-228)
-- *****************************************************************

  PROCEDURE SEC_PRODUCTS_TODAYSTRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- START OF: SEC_PRODUCTS_TODAYSTRADES
 -- *****************************************************************   
     OPEN p_CURSOR FOR

     SELECT
                      FUND_BOOK_STRATEGY.Fund_NAME                       Fund
                     ,FUND_BOOK_STRATEGY.BOOK_NAME                       Strategy
					 ,FUND_BOOK_STRATEGY.SUB_BOOK_NAME					 Sub_Strategy
                     ,Trades.sicovam				               	     n$Sicovam
                     ,Trades.refcon                                      n$TradeID
                     ,trades.datecomptable                               d$EntryDate
                     ,trunc(Trades.DATENEG)                         	 d$TradeDate
                     ,trunc(Trades.DATEVAL)                         	 d$ValueDate
                     ,trader.name                                        Trader
                     ,Instrument.reference                          	 Ticker
                     ,Instrument.libelle                              	 Name
                     ,Trades.quantite                              	 	 n$Qty
                     ,nvl(Trades.QUANTITE*titres.nominal,0)              n$Nominal
                     ,Trades.Montant                                	 n$NetAmount
                     ,Trades.montantcouru                                n$Accrued
                     ,Trades.cours                                       p$8$Price
                     ,trades.fraismarche                                 n$MarketFees
                     ,trades.fraiscounterparty                           n$CounterpartyFees
                     ,trades.fraiscourtage                               n$BrokerFees
                     ,BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam)            Instrument_Type
                      ,counterparty.name                                 Counterparty
      FROM            titres, histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      INNER JOIN      tiers Counterparty     
      ON              Counterparty.IDENT                             = Trades.Contrepartie
      
	  INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
					  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)  AS SUB_BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID            = Trades.opcvm

      INNER JOIN    riskusers trader
      ON            trader.ident                                        =        Trades.operateur
      
      WHERE         titres.sicovam                                      =        trades.sicovam
      AND Trades.backoffice                                              NOT IN  (192,11,13,17,26,27,220,248,252)
      AND titres.type                                                   !=        'L'
      AND FUND_BOOK_STRATEGY.BOOK_ID                                     =       126201
      AND trunc(trades.datecomptable)                                    =       trunc(sysdate)
      AND trades.type in (1,1444)
      ORDER BY        1,2,3,7,14 asc;
      
/* Securitized Products trades done today*/
 -- *****************************************************************
 -- END OF: SEC_PRODUCTS_TODAYSTRADES
 -- *****************************************************************   
END SEC_PRODUCTS_TODAYSTRADES;

-- *****************************************************************
-- Description:     PROCEDURE  GLOBALTRADEREPORT
--    * Global trades done today*/            
-- Author:          Jeff  Yu
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 04 NON 2016  Jeff  Yu     Created (PMOG-1060).
-- 20 JUN 2018    Jeff Yu     Modified (PMGMRISK-228)
-- *****************************************************************

  PROCEDURE GLOBALRATES_TRADEREPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- START OF: GLOBALRATES_TRADEREPORT
 -- *****************************************************************   
     OPEN p_CURSOR FOR

     SELECT
                      fund.name                                          Fund
                     ,STRATEGY.BOOK_NAME                                 Fund_Strategy
                     ,Trades.sicovam				               	     n$Sicovam
                     ,Trades.refcon                                      n$TradeID
                     ,trades.datecomptable                               d$EntryDate
                     ,trunc(Trades.DATENEG)                         	 d$TradeDate
                     ,trunc(Trades.DATEVAL)                         	 d$ValueDate
                     ,trader.name                                        Trader
                     ,Instrument.reference                          	 Ticker
                     ,Instrument.libelle                              	 Name
                     ,Trades.quantite                              	 	 n$Qty
                     ,nvl(Trades.QUANTITE*titres.nominal,0)              n$Nominal
                     ,Trades.Montant                                	 n$NetAmount
                     ,Trades.montantcouru                                n$Accrued
                     ,Trades.cours                                       p$8$Price
                     ,trades.fraismarche                                 n$MarketFees
                     ,trades.fraiscounterparty                           n$CounterpartyFees
                     ,trades.fraiscourtage                               n$BrokerFees
                     ,btg_get_instrument_type (Trades.sicovam)           Type
                     ,counterparty.name                                  Counterparty
      FROM            titres, histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE
      
      INNER JOIN      tiers Counterparty     
      ON              Counterparty.IDENT                             = Trades.Contrepartie
      
	  LEFT JOIN		(
                      SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
					  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)  AS SUB_BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )     STRATEGY
      ON            STRATEGY.STRATEGY_ID            = Trades.opcvm
    
      INNER JOIN    tiers fund
      ON            fund.ident                                          =        trades.entite

      INNER JOIN    riskusers trader
      ON            trader.ident                                        =        Trades.operateur
      
      WHERE         titres.sicovam                                      =        trades.sicovam
      AND Trades.backoffice                                              NOT IN  (192,11,13,17,26,27,220,248,252)
      AND titres.type                                                   !=        'L'
      AND strategy.BOOK_ID												in		(126867)---Global Rates
      AND trunc(trades.datecomptable)                                    =       trunc(sysdate)
      AND trades.type in (1,1444)
      ORDER BY        1,2,6,13 asc;
      
/* Global Rates trades done today*/
 -- *****************************************************************
 -- END OF: GLOBALRATES_TRADEREPORT
 -- *****************************************************************   
END GLOBALRATES_TRADEREPORT;


-- *****************************************************************
-- Description:     PROCEDURE  GLOBALRATES_POSCHANGE
--  * Global Rates Position Change
-- Author:          Jeff Yu
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
--04 NOV 2016     Jeff Yu      Created (PMOG-1060).
--31 JAN 2017      Jeff Yu       Modified (PMGMPMO-211).

  PROCEDURE GLOBALRATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN

-- *****************************************************************
 -- START OF: GLOBALRATES_POSCHANGE
 -- *****************************************************************      
    OPEN p_CURSOR FOR
      SELECT      DataSet.Fund
      ,           DataSet.Strategy
      ,           DataSet.Instrument
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                        Fund
                    ,           folio.name                                       Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(fund.name) + 55)
                                          , folio.name)                          Strategy_Full
                    ,           security.libelle                                 Instrument
                    ,           NVL(PositionYesterday.quantite, 0)               Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                   Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 126867 --GEMM Global Rates
                                                connect by  mgr         = prior ident
												UNION
												select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 128631 --ARF Global Rates
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 126867  --GEMM Global Rates
                                                connect by  mgr         = prior ident
												UNION
												select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 128631  --ARF Global Rates
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 126867 --GEMM Global Rates
                                                connect by  mgr         = prior ident
												UNION
												select      folio.ident
                                                from        folio
                                                where       level       >=1
                                                start with  ident       = 128631 --ARF Global Rates
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                    AND         ReportKey.opcvm not in
                                                        (
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 129604 -- ARF Financing
                                                          connect by  mgr         = prior ident
                                                          union
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 44784 -- ARF2 Financing
                                                          connect by  mgr         = prior ident
                                                          union
                                                          select      folio.ident
                                                          from        folio
                                                          start with  ident       = 14116 -- GEMM Financing
                                                          connect by  mgr         = prior ident
                                                        )
                ) DataSet
                
      ORDER BY  1,2,3;

  -- ***************************************************************************
  -- Global Rates Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
 -- *****************************************************************
 -- END OF: GLOBALRATES_POSCHANGE
 -- *****************************************************************          
	END GLOBALRATES_POSCHANGE;


 -- *****************************************************************
-- Description:     PROCEDURE  GDO_TODAYSTRADES
-- * GDO Trades Today*
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu			Created. (APPSUPP-3230)
-- ********************************************************** 
  PROCEDURE GDO_TODAYSTRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  -- *****************************************************************
 -- START OF: GDO_TODAYSTRADES
 -- *****************************************************************  
    OPEN p_CURSOR FOR

      SELECT      fund.name               Fund
      ,           fund_strategy.name                      Fund_Strategy
      ,           SUBSTR(BTG_FOLIONAMEPATH(HISTOMVTS.OPCVM),INSTR(BTG_FOLIONAMEPATH(HISTOMVTS.OPCVM),'/',82,1)+1,200) "Strategy Full"
      ,           trader.name                             Trader
      ,           security.reference                      Ticker
      ,           security.libelle                        Name
      ,           sum(histomvts.quantite)                 n$Quantity
      ,           Round(avg(histomvts.cours),8)           Avg_Price
      ,           DEVISE_TO_STR(histomvts.devisepay)      CCY      
              
      FROM        histomvts
      
      INNER JOIN  tiers fund
      ON          fund.ident                = histomvts.entite
        
      INNER JOIN  (
                    SELECT      folio.ident
                    ,           folio.name
                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                    FROM        folio
                    WHERE       level       > 2
                    START WITH  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                    CONNECT BY  mgr         = prior ident
                  ) strategy
      ON          strategy.ident            = histomvts.opcvm
      
      INNER JOIN  folio fund_strategy
      ON          fund_strategy.ident       = strategy.parent_ident
      
      INNER JOIN  riskusers trader
      ON          trader.ident              = histomvts.operateur
      
      INNER JOIN  titres security
      ON          security.sicovam          = histomvts.sicovam
      
      WHERE       trunc(histomvts.dateneg)  = trunc(sysdate - 1)
      AND         security.type             not in ('L')
      
      GROUP BY    fund.name
      ,           fund_strategy.name
      ,           strategy.name
      ,           trader.name
      ,           security.reference
      ,           security.libelle
      ,           histomvts.devisepay
      ,           histomvts.opcvm
      
      ORDER BY    1,2,3,4,5,6;

  -- ***************************************************************************
  -- GDO Trades Today
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
 -- *****************************************************************
 -- END OF: GDO_TODAYSTRADES
 -- *****************************************************************       
	END GDO_TODAYSTRADES;


-- *****************************************************************
-- Description:     PROCEDURE  GDO_POSCHANGE
--  * GDO Position Change
-- Author:          Jeff Yu
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu        Created. (APPSUPP-3231)

  PROCEDURE GDO_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
-- *****************************************************************
 -- START OF: GDO_POSCHANGE
 -- *****************************************************************          
    OPEN p_CURSOR FOR

      SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$Yesterdays_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Todays_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Yesterdays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Todays_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                             Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

  -- ***************************************************************************
  -- GDO Position Change
  -- ***************************************************************************
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
-- *****************************************************************
 -- END OF: GDO_POSCHANGE
 -- *****************************************************************              
	END GDO_POSCHANGE;



 -- *****************************************************************
-- Description:     PROCEDURE  GDO_POSCHANGE_SUMMARY
-- Author:          Jeff Yu
--  
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu      Created. (APPSUPP-3232)
-- **********************************************************   
  PROCEDURE GDO_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- START OF: GDO_POSCHANGE_SUMMARY
 -- *****************************************************************     
    OPEN p_CURSOR FOR

      SELECT FUND
      , Book
      , SUM(CASE WHEN Action_Taken IN('New Position')
                 THEN pos_count 
                 ELSE 0 
             END)                                                                AS N$OPEN
      , SUM(CASE WHEN Action_Taken IN('Full Long Unwind', 'Full Short Unwind') 
                 THEN pos_count 
                 ELSE 0 
            END)                                                                 AS N$CLOSE
      , SUM(CASE WHEN Action_Taken IN('Increase In Position'
                                    , 'Decrease In Position'
                                    , 'Full Long Unwind Crossing Zero'
                                    , 'Full Short Unwind Crossing Zero') 
                 THEN pos_count ELSE 0 
            END)                                                                 AS N$CHANGE 
      , SUM(pos_count) AS N$TOTAL
        FROM (
                SELECT FUND
                , Book
                , Action_Taken
                , count(*) pos_count
                FROM (
                          SELECT      DataSet.Fund
                          ,           DataSet.Book
                          ,           DataSet.Strategy
                          ,           DataSet.Instrument
                          ,           DataSet.Position_Yesterday  
                          ,           DataSet.Position_Today      
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Yesterdays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'SHORT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'FLAT'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'LONG'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'SHORT'
                                        ELSE
                                          'UNKNOWN'
                                      END Todays_Position_State
                          ,           CASE 
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                                          'New Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                                          'Increase In Position'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Long Unwind'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                                          'Full Long Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                                          'Full Short Unwind'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                                          'Full Short Unwind Crossing Zero'
                                        WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                                          'Decrease In Position'
                                        WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                                          'Decrease In Position'
                                        ELSE
                                          'UNKNOWN'
                                      END Action_Taken
                          ,           DataSet.Strategy_Full
                          FROM        (
                                        SELECT      fund.name                                                 Fund
                                        ,           book.name                                                 Book
                                        ,           folio.name                                                Strategy
                                        ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                                              , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                                              , folio.name)                                   Strategy_Full
                                        ,           security.libelle                                          Instrument
                                        ,           NVL(PositionYesterday.quantite, 0)                        Position_Yesterday
                                        ,           NVL(PositionToday.quantite, 0)                            Position_Today
                                        ,           NVL(PositionToday.quantite, 0)
                                                    -
                                                    NVL(PositionYesterday.quantite, 0)                         Delta
                                        FROM        (
                                                      SELECT      DISTINCT
                                                                  HISTOMVTS.entite
                                                      ,           FOLIOS.parent_ident
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                    ) ReportKey
                                                    
                                        INNER JOIN  tiers fund
                                        ON          fund.ident                = ReportKey.entite
                                        
                                        INNER JOIN  folio book
                                        ON          book.ident                = ReportKey.parent_ident
                                        
                                        INNER JOIN  folio
                                        ON          folio.ident               = ReportKey.opcvm
                                        
                                        INNER JOIN  titres security
                                        ON          security.sicovam          = ReportKey.sicovam
                                        AND         security.type             not in ('L')
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 < trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionYesterday
                                        ON          PositionYesterday.entite    = ReportKey.entite
                                        AND         PositionYesterday.opcvm     = ReportKey.opcvm
                                        AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                                    
                                        LEFT JOIN   (
                                                      SELECT      HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                      ,           SUM(HISTOMVTS.quantite) quantite
                                                      FROM        HISTOMVTS
                                                      INNER JOIN  (
                                                                    select      folio.ident
                                                                    from        folio
                                                                    where       level       > 2
                                                                    start with  ident       = PCKG_BTG.FOLIO_GDO_MASTER_FUND-- 132408 -- GDO
                                                                    connect by  mgr         = prior ident
                                                                  ) FOLIOS
                                                      ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                                      INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                                      ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                                      AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                                      INNER JOIN  BUSINESS_EVENTS
                                                      ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                                      AND         BUSINESS_EVENTS.COMPTA                            = 1
                                                      WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                                      GROUP BY    HISTOMVTS.entite
                                                      ,           HISTOMVTS.opcvm
                                                      ,           HISTOMVTS.sicovam
                                                    ) PositionToday
                                        ON          PositionToday.entite      = ReportKey.entite
                                        AND         PositionToday.opcvm       = ReportKey.opcvm
                                        AND         PositionToday.sicovam     = ReportKey.sicovam
                                        
                                        WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                                    ) DataSet
                      ) 
                 GROUP BY   FUND
                          , Book
                          , Action_Taken
              ) 
        GROUP BY    FUND
                  , Book
       ORDER BY 1, 2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
      
      
-- *****************************************************************
 -- END OF: GDO_POSCHANGE_SUMMARY
 -- *****************************************************************          
	END GDO_POSCHANGE_SUMMARY;


 -- *****************************************************************
  -- Description  PROCEDURE GDO_POS_CHANGE_TDY

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017     Jeff Yu   Created (APPSUPP-3233).
  -- *****************************************************************
  PROCEDURE GDO_POS_CHANGE_TDY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF GDO_POS_CHANGE_TDY
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT      DataSet.Fund
      ,           DataSet.Book
      ,           DataSet.Strategy
      ,           DataSet.Instrument
	  ,           DataSet.Reference
      ,           ROUND(DataSet.Position_Yesterday,2)  n$SOD_Position
      ,           ROUND(DataSet.Position_Today,2)      n$Now_Position
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END SOD_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'SHORT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'FLAT'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'LONG'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'SHORT'
                    ELSE
                      'UNKNOWN'
                  END Now_Position_State
      ,           CASE 
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta > 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday = 0 AND DataSet.Delta < 0) THEN
                      'New Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  > 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  < 0) THEN
                      'Increase In Position'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today = 0) THEN
                      'Full Long Unwind'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Position_Today < 0) THEN
                      'Full Long Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today = 0) THEN
                      'Full Short Unwind'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Position_Today > 0) THEN
                      'Full Short Unwind Crossing Zero'
                    WHEN (DataSet.Position_Yesterday > 0 AND DataSet.Delta  < 0) THEN
                      'Decrease In Position'
                    WHEN (DataSet.Position_Yesterday < 0 AND DataSet.Delta  > 0) THEN
                      'Decrease In Position'
                    ELSE
                      'UNKNOWN'
                  END Action_Taken
      ,           DataSet.Strategy_Full
      FROM        (
                    SELECT      fund.name                                                         Fund
                    ,           book.name                                                         Book
                    ,           folio.name                                                        Strategy
                    ,           NVL(substr( BTG_FOLIONAMEPATH(folio.ident)
                                          , LENGTH(BTG_FOLIONAMEPATH(book.ident)) + 2)
                                          , folio.name)                                           Strategy_Full
                    ,           security.libelle                                                  Instrument
					,           security.reference                                            Reference
                    ,           NVL(PositionYesterday.quantite, 0)                                Position_Yesterday
                    ,           NVL(PositionToday.quantite, 0)                                    Position_Today
                    ,           NVL(PositionToday.quantite, 0)
                                -
                                NVL(PositionYesterday.quantite, 0)                                 Delta
                    FROM        (
                                  SELECT      DISTINCT
                                              HISTOMVTS.entite
                                  ,           FOLIOS.parent_ident
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                ) ReportKey
                                
                    INNER JOIN  tiers fund
                    ON          fund.ident                = ReportKey.entite
                    
                    INNER JOIN  folio book
                    ON          book.ident                = ReportKey.parent_ident
                    
                    INNER JOIN  folio
                    ON          folio.ident               = ReportKey.opcvm
                    
                    INNER JOIN  titres security
                    ON          security.sicovam          = ReportKey.sicovam
                    AND         security.type             NOT IN ('L')
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate-1)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionYesterday
                    ON          PositionYesterday.entite    = ReportKey.entite
                    AND         PositionYesterday.opcvm     = ReportKey.opcvm
                    AND         PositionYesterday.sicovam   = ReportKey.sicovam
                                
                    LEFT JOIN   (
                                  SELECT      HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                  ,           SUM(HISTOMVTS.quantite) quantite
                                  FROM        HISTOMVTS
                                  INNER JOIN  (
                                                select      folio.ident
                                                from        folio
                                                where       level       > 2
                                                start with  ident       = 132408 -- GDO
                                                connect by  mgr         = prior ident
                                              ) FOLIOS
                                  ON          FOLIOS.ident                                      = HISTOMVTS.opcvm
                                  INNER JOIN  BO_KERNEL_STATUS_COMPONENT
                                  ON          BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                                  AND         BO_KERNEL_STATUS_COMPONENT.kernel_status_id       = HISTOMVTS.backoffice
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.Id                                = HISTOMVTS.Type
                                  AND         BUSINESS_EVENTS.COMPTA                            = 1
                                  WHERE       HISTOMVTS.dateneg                                 <= trunc(sysdate)
                                  GROUP BY    HISTOMVTS.entite
                                  ,           HISTOMVTS.opcvm
                                  ,           HISTOMVTS.sicovam
                                ) PositionToday
                    ON          PositionToday.entite      = ReportKey.entite
                    AND         PositionToday.opcvm       = ReportKey.opcvm
                    AND         PositionToday.sicovam     = ReportKey.sicovam
                    
                    WHERE       (NVL(PositionToday.quantite, 0) - NVL(PositionYesterday.quantite, 0)) <> 0
                ) DataSet
                
      ORDER BY  1,2,3,4;

	-- ***************************************************************************
  -- END OF GDO_POS_CHANGE_TDY 
  -- ***************************************************************************	
 END GDO_POS_CHANGE_TDY;

 
 -- *****************************************************************
  -- Description  PROCEDURE VOL_VAR_SWAP_WRONG_SET_UP

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 22 MAR 2018     Helen Zheng   Created (PMOG-1228).
  -- *****************************************************************
  PROCEDURE VOL_VAR_SWAP_WRONG_SET_UP
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF PROCEDURE VOL_VAR_SWAP_WRONG_SET_UP
  -- ***************************************************************************		
		OPEN p_CURSOR FOR

SELECT	
 Instrument.sicovam                            Sicovam
,Instrument.modele                             Model
,Instrument.reference                          Reference
,Instrument.libelle                            Name
,allotment.libelle                             Allotment

from            titres Instrument
inner join      affectation allotment
on              instrument.affectation = allotment.ident
where Instrument.modele in ('Variance Swap', 'Volatility Swap')
and Instrument.varswap_intradaydelta=0        --One-Day Variance box NOT ticked
order by allotment.libelle,sicovam
;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

-- ***************************************************************************
-- END OF VOL_VAR_SWAP_WRONG_SET_UP 
-- ***************************************************************************	
END VOL_VAR_SWAP_WRONG_SET_UP;


 -- *****************************************************************
  -- Description  PROCEDURE EQ_QUANT_TRADES

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 27 MAR 2018     Olivier Dechazal   Created (APPSUPP-4368).
-- 20 JUN 2018     Jeff Yu     Modified (PMGMRISK-228) Add new business event.
  -- *****************************************************************
 PROCEDURE EQ_QUANT_TRADES
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- *****************************************************************
-- BEGIN OF PROCEDURE EQ_QUANT_TRADES
-- ****************************************************************
  OPEN p_CURSOR FOR
     SELECT   HISTOMVTS.refcon                                                               AS TRADE_ID
              ,(SELECT name 
                        FROM tiers 
                        WHERE ident=histomvts.entite)                                         AS FUND
              , HISTOMVTS.dateneg                                                             AS d$TRADE_DATE
              , BO_KERNEL_STATUS.Name                                                         AS STATUS
              , STRATEGIES.STRATEGY_NAME                                                      AS PORTFOLIO
              , COALESCE( UNDERLYING1.reference
                        , UNDERLYING2.reference
                        , UNDERLYING3.reference)                                             AS UNDERLYING
              , TITRES.prixexer                                                               AS p$2$STRIKE
              , HISTOMVTS.quantite                                                            AS n$QUANTITY
              , COALESCE(TITRES.echeance, TITRES.datefinal)                                   AS d$MATURITY
              , HISTOMVTS.cours                                                               AS p$2$PRICE
              , DECODE( TITRES.type,
                        'D', DECODE(TITRES.typepro, 
                                     1, 'Call', 
                                     2, 'Put', 
                                     3, 'Convertible Bond', 
                                     4, 'Redeemable Bond', 
                                     5, 'Index Loan', 
                                     6, 'Lock in Bond', 
                                     7, 'Redeemable Bond', 
                                     null
                                    ),
                        'M', DECODE(TITRES.typepro, 
                                     2, 'Call', 
                                     3, 'Put',     
                                     null
                                    ),
                        'F','Future',    
                        BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam)      
                      )                                                                     AS PRODUCT_TYPE
            , TITRES.reference                                                              AS INSTRUMENT
            , COURTIERS.libelle                                                             AS BROKER
      FROM    HISTOMVTS
      INNER JOIN ( 
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 134754 --'EQ Quant' --GEMM
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                                                                UNION
                                                                                SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 134755 --'EQ Quant' --GDO
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                    UNION
                    SELECT  FOLIO.ident                    AS STRATEGY_ID
                          , FOLIO.name                     AS STRATEGY_NAME
                    FROM FOLIO  
                    START WITH FOLIO.ident = 134756 --'EQ Quant' ---ARF
                    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                  ) STRATEGIES
    ON              STRATEGIES.strategy_id        =    HISTOMVTS.opcvm
    
    LEFT OUTER JOIN CLIENTS
    ON              CLIENTS.ident = HISTOMVTS.entite
    
    LEFT OUTER JOIN TITRES
    ON              TITRES.sicovam = HISTOMVTS.sicovam
    
    LEFT OUTER JOIN TITRES UNDERLYING1 
    ON              UNDERLYING1.sicovam = TITRES.code_emet 
    
    LEFT OUTER JOIN TITRES UNDERLYING2 
    ON              UNDERLYING2.sicovam = TITRES.codesj 
    
    LEFT OUTER JOIN TITRES UNDERLYING3 
    ON              UNDERLYING3.sicovam = TITRES.codesj2
    
    LEFT OUTER JOIN COURTIERS
    ON              COURTIERS.ident = HISTOMVTS.courtier
    
    LEFT OUTER JOIN AFFECTATION
    ON              TITRES.affectation = AFFECTATION.ident
    
    LEFT OUTER JOIN BO_KERNEL_STATUS
    ON              BO_KERNEL_STATUS.id = HISTOMVTS.backoffice
    
    WHERE           HISTOMVTS.type in (1,1444)
    AND             HISTOMVTS.dateneg = trunc(BTG_BUSINESS_DATE(sysdate, -1)) 
    AND             BO_KERNEL_STATUS.ID not in (192)
    
    ORDER BY PORTFOLIO
            , UNDERLYING
            , PRODUCT_TYPE;

    
   -- *****************************************************************
-- END OF: EQ_QUANT_TRADES
-- ****************************************************************  
    
 END EQ_QUANT_TRADES;


 -- *****************************************************************
-- Description:     PROCEDURE  EQ_EQQUANT_UPCMNG_DVDNDS

-- Revision History
-- Date             Author        Reason for Change
-- 29 Mar 2018      Helen Zheng       Created on EQ Quant launch (APPSUPP-4397)
-- ----------------------------------------------------------------    
  PROCEDURE EQ_EQQUANT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 -- *****************************************************************
 -- START OF: EQ_EQQUANT_UPCMNG_DVDNDS
 -- ****************************************************************       
    OPEN p_CURSOR FOR
         SELECT  CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv  
                END - TRUNC(SYSDATE)                                                                 AS N$DAYS_UNTIL_EX_DIV
              , CASE TITRES.type 
                     WHEN 'A' 
                     THEN TITRES.libelle 
                     ELSE TITRES_UNDERLYING.libelle 
                END                                                                                  AS UNDERLYING
              , AFFECTATION.libelle                                                                  AS TYPE
              , TITRES.libelle                                                                       AS INSTRUMENT
              , DEVISE_TO_STR(TITRES.devisectt)                                                      AS INSTRUMENT_CURRENCY      
              , OPEN_POSITIONS.quantity                                                              AS N$QUANTITY
              , OPEN_POSITIONS.quantity * DECODE(   TITRES.quotation_type
                                                  , 2
                                                  , TITRES.nominal / 100
                                                  , 1)   * GRECQUE_SIMPLE.delta                       AS N$GLOBAL_DELTA
              , DIVIDENDE.datepaye                                                                    AS D$DIV_PAYMENT_DATE
              , CASE  DIVIDENDE.dateexdiv 
                      WHEN TO_DATE('01-JAN-1904') 
                      THEN DIVIDENDE.datediv 
                      ELSE DIVIDENDE.dateexdiv 
                END                                                                                   AS D$EX_DIV_DATE
              , DEVISE_TO_STR(DIVIDENDE.currency)                                                     AS DIV_CURRENCY
              , CASE SECTORS.CODE 
                     WHEN 'GB' 
                     THEN DIVIDENDE.VALEUR / 100 
                     ELSE DIVIDENDE.VALEUR 
                 END                                                                                  AS P$6$DIV_VALUE_PER_SHARE
              , CASE TITRES.type 
                     WHEN 'D' 
                     THEN NULL 
                     ELSE     ( CASE SECTORS.code 
                                     WHEN 'GB' 
                                     THEN DIVIDENDE.VALEUR / 100 
                                     ELSE DIVIDENDE.VALEUR 
                                 END) *  (OPEN_POSITIONS.quantity * DECODE ( TITRES.quotation_type
                                                                            , 2
                                                                            , TITRES.nominal / 100
                                                                            , 1) * GRECQUE_SIMPLE.delta) 
                END                                                                                   AS N$DIV_VALUE_TOTAL
              , COALESCE(RIC.servisen, RIC_UNDERLYING.servisen) AS BLOOMBERG_CODE
      FROM (
             SELECT     HISTOMVTS.sicovam AS SICOVAM
                      , TITRES_UNDERLYING.sicovam AS SICOVAM_UNDERLYING
                      , SUM(HISTOMVTS.quantite) AS QUANTITY  
             FROM       join_position_histomvts HISTOMVTS
             
            
              INNER JOIN (
                           SELECT       FOLIO.ident
                           FROM         FOLIO  
                           START WITH   FOLIO.ident  IN (134754)--GEMM EQ Quant
                           CONNECT BY   PRIOR FOLIO.ident = FOLIO.mgr  
                        )  FOLIOS
             ON            FOLIOS.ident  =  HISTOMVTS.opcvm
             
             INNER JOIN (
                          SELECT        TITRES.sicovam 
                                      , TITRES.codesj            AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam     =  HISTOMVTS.sicovam
                          WHERE         TITRES.type        =  'D'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam 
                                      , TITRES.code_emet          AS SICOVAM_UNDERLYING
                          FROM          HISTOMVTS 
                          INNER JOIN    TITRES
                          ON            TITRES.sicovam   =   HISTOMVTS.sicovam
                          WHERE         TITRES.type      =   'G'    
                          
                          UNION    
                          
                          SELECT        TITRES.sicovam
                                      , NULL                     AS SICOVAM_UNDERLYING
                          FROM         HISTOMVTS 
                          INNER JOIN   TITRES
                          ON           TITRES.sicovam     =   HISTOMVTS.sicovam
                          WHERE        TITRES.type        =   'A'
                        )   INSTRUMENTS
            ON              INSTRUMENTS.sicovam       =    HISTOMVTS.sicovam
            INNER JOIN      TITRES 
            ON              TITRES.sicovam            =    INSTRUMENTS.sicovam
            
            LEFT OUTER JOIN TITRES TITRES_UNDERLYING 
            ON              TITRES_UNDERLYING.sicovam =     INSTRUMENTS.sicovam_underlying
            
            INNER JOIN      BUSINESS_EVENTS 
            ON              BUSINESS_EVENTS.id         =     HISTOMVTS.type      
            
            WHERE           HISTOMVTS.backoffice      NOT IN  (11, 13, 17, 26, 27, 192, 220, 248, 252)
            AND             (    TITRES.type            =        'A' 
                             OR TITRES_UNDERLYING.type  =        'A')
            AND             BUSINESS_EVENTS.compta      = 1
            AND             HISTOMVTS.dateneg           <      TRUNC(SYSDATE)
            
            GROUP BY        HISTOMVTS.sicovam
                          , TITRES_UNDERLYING.sicovam
                          
            HAVING          SUM(HISTOMVTS.quantite)     !=       0
      )               OPEN_POSITIONS
      INNER JOIN      TITRES
      ON              TITRES.sicovam              = OPEN_POSITIONS.sicovam
      
      LEFT OUTER JOIN AFFECTATION
      ON              TITRES.affectation          = AFFECTATION.ident
      
      LEFT JOIN       TITRES TITRES_UNDERLYING
      ON              TITRES_UNDERLYING.sicovam   = OPEN_POSITIONS.sicovam_underlying
      
      INNER JOIN      DIVIDENDE
      ON              DIVIDENDE.sicovam           = COALESCE(OPEN_POSITIONS.sicovam_underlying, OPEN_POSITIONS.sicovam)
      
      LEFT OUTER JOIN GRECQUE_SIMPLE
      ON              GRECQUE_SIMPLE.sicovam      = TITRES.sicovam      
      AND            (GRECQUE_SIMPLE.codesj       = COALESCE(TITRES_UNDERLYING.sicovam, TITRES.sicovam)
                      OR  ( TITRES.type           = 'A' 
                              AND NOT EXISTS        (SELECT * 
                                                     FROM DEVISEV2
                                                     WHERE CODE = GRECQUE_SIMPLE.codesj)
                           )
                      )
                      
      LEFT OUTER JOIN RIC
      ON              RIC.sicovam                 = TITRES.sicovam
      
      LEFT OUTER JOIN RIC RIC_UNDERLYING
      ON              RIC_UNDERLYING.sicovam      = TITRES_UNDERLYING.sicovam
      
      LEFT OUTER JOIN SECTOR_INSTRUMENT_ASSOCIATION
      ON              SECTOR_INSTRUMENT_ASSOCIATION.SICOVAM = COALESCE(TITRES_UNDERLYING.SICOVAM, TITRES.SICOVAM)
      AND             SECTOR_INSTRUMENT_ASSOCIATION.type    = 1364
      
      LEFT OUTER JOIN SECTORS
      ON              SECTORS.id                   = SECTOR_INSTRUMENT_ASSOCIATION.sector
      
      WHERE           DIVIDENDE.datediv            > TRUNC(SYSDATE - 1)
      AND             DIVIDENDE.datediv            < TRUNC(SYSDATE + 28)  
      
      ORDER BY 1, 2, 3, 7; 
 -- *****************************************************************
 -- END OF: EQ_EQQUANT_UPCMNG_DVDNDS
 -- ****************************************************************    
  END EQ_EQQUANT_UPCMNG_DVDNDS;  

-- *****************************************************************
-- Description:     PROCEDURE  EURATES_TRADES

-- Revision History
-- Date           Author            Reason for Change
-- 23 May 2018    Andre Bresslau    Created on PMOF-314
-- ----------------------------------------------------------------  
PROCEDURE EURATES_TRADES
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- *****************************************************************
-- START OF: EURATES_TRADES
-- ****************************************************************       
  OPEN p_CURSOR FOR

SELECT 
    --FUND.NAME FUND
	--STRATEGY.FUND_STRATEGY FUND_STRATEGY
	 TO_CHAR(AUDIT_MVT.DATEMODIF, 'DD-MON-YYYY') D$INSERTION_DATE
	,TO_CHAR(AUDIT_MVT.DATEMODIF, 'HH24:MI:SS') INSERTION_TIME
	,INSTRUMENT.REFERENCE TICKER
	,TRADES.QUANTITE N$QTY
	,TRADES.COURS P$8$PRICE
	,COUNTERPARTY.NAME COUNTERPARTY
	,NVL(TRADES.QUANTITE * TITRES.NOMINAL, 0) N$NOMINAL
	,TRADES.MONTANT N$NETAMOUNT
	,DEVISE_TO_STR(TRADES.DEVISEPAY) CCY
  ,TRADES.MONTANTCOURU N$ACCRUED
	,TRADES.FRAISMARCHE N$MARKET_FEES	
  ,TRADES.FRAISCOURTAGE + TRADES.FRAISCOUNTERPARTY N$CTPY_FEES
	,FOLIO_LEVEL2 FOLIO_NAME
  ,TRADES.SICOVAM SICOVAM
	,TRADES.REFCON TRADE_ID
	,TRUNC(TRADES.DATENEG) D$TRADE_DATE
	,TRUNC(TRADES.DATEVAL) D$VALUE_DATE
	,INSTRUMENT.LIBELLE NAME
	,BTG_GET_INSTRUMENT_TYPE(TRADES.SICOVAM) INSTRUMENT_TYPE
	,ALLOTMENT.LIBELLE  ALLOTMENT
  --,DEPOSITARY.NAME  DEPOSITARY
  --,TRADER.NAME TRADER
  
FROM TITRES
	,HISTOMVTS TRADES

INNER JOIN BUSINESS_EVENTS ON BUSINESS_EVENTS.ID = TRADES.TYPE
INNER JOIN TITRES INSTRUMENT ON INSTRUMENT.SICOVAM = TRADES.SICOVAM
INNER JOIN AFFECTATION ALLOTMENT ON ALLOTMENT.IDENT = INSTRUMENT.AFFECTATION
INNER JOIN TIERS FUND ON FUND.IDENT = TRADES.ENTITE
INNER JOIN TIERS DEPOSITARY ON DEPOSITARY.IDENT = TRADES.DEPOSITAIRE
INNER JOIN TIERS COUNTERPARTY ON COUNTERPARTY.IDENT = TRADES.CONTREPARTIE
INNER JOIN RISKUSERS TRADER ON TRADER.IDENT = TRADES.OPERATEUR

LEFT JOIN AUDIT_MVT ON AUDIT_MVT.REFCON = TRADES.REFCON AND AUDIT_MVT.VERSION = 1
LEFT JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.IDENT) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.IDENT, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS FUND_STRATEGY
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.IDENT, '�'), '[^�]+', 3, 4) AS FOLIO_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 5) AS FOLIO_LEVEL1		
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 4, 6) AS FOLIO_LEVEL2
    ,FOLIO.IDENT AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.IDENT IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565)
		CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
	) STRATEGY ON STRATEGY.STRATEGY_ID = TRADES.OPCVM

WHERE TITRES.SICOVAM = TRADES.SICOVAM
	AND TRADES.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415)		
	AND TITRES.TYPE != 'L' --EXCLUDE
	AND STRATEGY.FOLIO_ID IN (134999) --ARF>EUROPEAN RATES
	AND BUSINESS_EVENTS.COMPTA = 1 --TRADES THAT AFFECT POSITION
	AND TO_CHAR(AUDIT_MVT.DATEMODIF) = TO_CHAR(SYSDATE)
ORDER BY ALLOTMENT, TICKER, 1, 2 ASC; 
-- *****************************************************************
-- END OF: EURATES_TRADES
-- *****************************************************************    
END EURATES_TRADES;  

-- *****************************************************************
-- Description:     PROCEDURE  EM_LATAM_RATES_TRADES

-- Revision History
-- Date           Author            Reason for Change
-- 01 Jun 2018    Gustavo Binnie    Created on PMOF-317
-- 14 JUN 2018   Jeff Yu    Modified (APPSUPP-4698) --Add instrument IM field
-- 19 JUN 2018   Jeff Yu    Modified (APPSUPP-4698) --Modify logic for IM field
-- 19 JUN 2018	 Gustavo Binnie		PMOF-318 - Change of date format
-- ----------------------------------------------------------------  
PROCEDURE EM_LATAM_RATES_TRADES
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- *****************************************************************
-- START OF: EM_LATAM_RATES_TRADES
-- ****************************************************************       
  OPEN p_CURSOR FOR

	SELECT  
   FUND.NAME FUND 
	,FUND_BOOK_STRATEGY.BOOK_NAME STRATEGY 
	,TRADES.SICOVAM SICOVAM 
	,INSTRUMENT.REFERENCE INSTRUMENT_REF 
	,INSTRUMENT.LIBELLE INSTRUMENT_NAME 
    ,ES.VALUE AS IM
	,TRADES.REFCON TRADE_ID 
	,BUSINESS_EVENTS.NAME BUSINESS_EVENT 
	,TRADES.QUANTITE QTY 
	,NVL(TRADES.QUANTITE * INSTRUMENT.NOMINAL, 0) NOMINAL 
	,TRADES.COURS PRICE 
	,TRADES.MONTANT NET_AMOUNT 
	,DEVISE_TO_STR(TRADES.DEVISEPAY) CCY 
	,COUNTERPARTY.NAME COUNTERPARTY 
	,FUND_BOOK_STRATEGY.STRATEGY_NAME FOLIO_NAME 
	,TO_CHAR(TRUNC(TRADES.DATENEG),'YYYY-MM-DD') TRADE_DATE 
	,TO_CHAR(TRUNC(TRADES.DATEVAL),'YYYY-MM-DD') VALUE_DATE	 
	,BTG_GET_INSTRUMENT_TYPE(TRADES.SICOVAM) INSTRUMENT_TYPE 
	,ALLOTMENT.LIBELLE  ALLOTMENT 
	, TO_CHAR(TRUNC(INSTRUMENT.EMISSION),'YYYY-MM-DD') START_DATE 
	, CASE 
                        WHEN INSTRUMENT.type = 'S' THEN TO_CHAR(INSTRUMENT.DATEFINAL,'YYYY-MM-DD') 
                        WHEN INSTRUMENT.type IN  ('O','D','L') THEN TO_CHAR(INSTRUMENT.FINPER,'YYYY-MM-DD') 
                        WHEN INSTRUMENT.type IN ('M','F','N') THEN TO_CHAR(INSTRUMENT.ECHEANCE,'YYYY-MM-DD') 
                        WHEN INSTRUMENT.type = 'K' THEN TO_CHAR(TRADES.dateval,'YYYY-MM-DD') 
                        ELSE TO_CHAR(TRUNC(SYSDATE)-500,'YYYY-MM-DD') 
    END                                                           EXPIRY 
	, CASE WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE1 = 1 THEN 'FIXED' WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE1 <> 1 THEN 'FLOATING' ELSE '' END SWAP_RECEIVING_LEG_TYPE 
	, CASE WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE2 = 1 THEN 'FIXED' WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE2 <> 1 THEN 'FLOATING' ELSE '' END SWAP_PAYING_LEG_TYPE 
	, CASE WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE1 = 1 THEN TO_CHAR(INSTRUMENT.FIXE1,'99.9999') WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE1 <> 1 THEN NVL(REC_RATE.REFERENCE,'') ELSE '' END SWAP_RECEIVING_LEG_RATE 
	, CASE WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE2 = 1 THEN TO_CHAR(INSTRUMENT.FIXE2,'99.9999') WHEN INSTRUMENT.TYPE = 'S' AND INSTRUMENT.JAMBE2 <> 1 THEN NVL(PAY_RATE.REFERENCE,'') ELSE '' END SWAP_PAYING_LEG_RATE 
	,DEPOSITARY.NAME  DEPOSITARY 
	,TRADER.NAME TRADER 
   
FROM HISTOMVTS TRADES 
 
INNER JOIN BUSINESS_EVENTS ON BUSINESS_EVENTS.ID = TRADES.TYPE 
INNER JOIN TITRES INSTRUMENT ON INSTRUMENT.SICOVAM = TRADES.SICOVAM 
LEFT JOIN AFFECTATION ALLOTMENT ON ALLOTMENT.IDENT = INSTRUMENT.AFFECTATION 
LEFT JOIN TIERS FUND ON FUND.IDENT = TRADES.ENTITE 
LEFT JOIN TIERS DEPOSITARY ON DEPOSITARY.IDENT = TRADES.DEPOSITAIRE 
LEFT JOIN TIERS COUNTERPARTY ON COUNTERPARTY.IDENT = TRADES.CONTREPARTIE 
LEFT JOIN RISKUSERS TRADER ON TRADER.IDENT = TRADES.OPERATEUR 
LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ES
ON ES.SOPHIS_IDENT=INSTRUMENT.SICOVAM
AND ES.REF_IDENT=11  -----IM
LEFT JOIN (  
                  SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID 
                          , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME 
                          , FOLIO.ident                                                           AS STRATEGY_ID 
                          , FOLIO.name                                                            AS STRATEGY_NAME 
                          , level 
                  FROM FOLIO 
                  WHERE LEVEL >= 3 
                  START WITH FOLIO.ident IN (14414,14405,90565)

                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr   
                )     FUND_BOOK_STRATEGY 
ON              FUND_BOOK_STRATEGY.STRATEGY_ID     =   TRADES.OPCVM 
 
LEFT JOIN TITRES REC_RATE 
ON REC_RATE.SICOVAM = INSTRUMENT.BASE1 
AND INSTRUMENT.TYPE = 'S' 
 
LEFT JOIN TITRES PAY_RATE 
ON REC_RATE.SICOVAM = INSTRUMENT.BASE2 
AND INSTRUMENT.TYPE = 'S' 
 
WHERE TRADES.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415)		 
	AND INSTRUMENT.TYPE != 'L' 
   
 AND EXISTS (     

                                      SELECT 1  FROM FOLIO                                
                                       WHERE IDENT  IN ( select ENTRYPT from extraction_entrypts where code = 19800 ) 

                                       START WITH IDENT = TRADES.OPCVM                      
                                       CONNECT BY PRIOR    MGR = IDENT                     
                                   )  
                                    
	AND TRADES.DATENEG >= '01-JAN-2018' 
ORDER BY TRADES.DATENEG, INSTRUMENT.SICOVAM, FUND.NAME
; 
-- *****************************************************************
-- END OF: EM_LATAM_RATES_TRADES
-- *****************************************************************    
END EM_LATAM_RATES_TRADES;  


-- *****************************************************************
-- Description:     PROCEDURE  FX_Roll_Trades

-- Revision History
-- Date           Author            Reason for Change
-- 04 Sep 2018    Helen Zheng     Created on PMOG-1260
-- 21 Sep 2018    Helen Zheng     refactored to improve performance
-- 01 Oct 2018    Helen Zheng     Add a filter to exclude close outs

-- ----------------------------------------------------------------  
PROCEDURE FX_Roll_Trades
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- *****************************************************************
-- START OF: FX_Roll_Trades
-- ****************************************************************       
  OPEN p_CURSOR FOR

  --Below query returns result in the exact Templated format required by the TradeLoader tool
 
/*********************Non CAD, TRY: 1st to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/

SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732' WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID,'FX Rolls' AS COMMENTS
,SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT,(Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY		
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   	GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0   ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL =TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))  -- line1
AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs   ON FXROLLSOPEN.operateur=rs.ident
  
  
  

union
/********************* Non CAD, TRY: 2nd to reopen  in FX Rolls folders using Price 2 in Line2 of the Roll trades******************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID,  
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID
		,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH	,T.SICOVAM AS SICOVAM
		,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY ,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
    GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +2))    -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   
   
   
   union   
/********************* Non CAD, TRY: 3rd to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506'  END AS FundID
,CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL   END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude      cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))  
        and h.sicovam not in (67603203,67611267,67603202,67611268)    
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = trunc(sysdate) 
   AND FXROLLSOPEN.DATEVAL =TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))   -- line1
  AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
 
 
 
 
 union 
/*********************Non CAD, TRY: 4th to reopen in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
 SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,CASE   WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL  END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE,OPENPOSITIONS.NAME	,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM         
  GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM  and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +2))     -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   


union
    --Below query returns result in the exact Templated format required by the TradeLoader tool
/*********************CAD, TRY: 1st to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732' WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID,'FX Rolls' AS COMMENTS
,SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT,(Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY		
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = trunc(sysdate) 
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   	GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0   ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL =trunc(sysdate)  -- line1
AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs   ON FXROLLSOPEN.operateur=rs.ident
  



union
/********************* CAD, TRY: 2nd to reopen  in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID,  
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID
		,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH	,T.SICOVAM AS SICOVAM
		,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY ,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = trunc(sysdate)
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
    GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))    -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   
   
   
   union   
/*********************CAD, TRY: 3rd to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506'  END AS FundID
,CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL   END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude      cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = trunc(sysdate) 
        and h.sicovam in (67603203,67611267,67603202,67611268)    
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = trunc(sysdate) 
   AND FXROLLSOPEN.DATEVAL =trunc(sysdate)   -- line1
  AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
 
 
 
 
 
 union 
/********************* CAD, TRY: 4th to reopen in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
 SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,CASE   WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL  END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE,OPENPOSITIONS.NAME	,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = trunc(sysdate)
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= trunc(sysdate)
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM         
  GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM  and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = trunc(sysdate)
AND FXROLLSOPEN.DATEVAL = TO_CHAR(BTG_BUSINESS_DATE(SYSDATE, +1))     -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident;
 
-- *****************************************************************
-- END OF: FX_Roll_Trades
-- *****************************************************************    
END FX_Roll_Trades;  


-- *****************************************************************
-- Description:     PROCEDURE  FX_Roll_Trades_OnDemand

-- Revision History
-- Date           Author            Reason for Change

-- 04 Oct 2018    Helen Zheng     Created an On Demand version of the above

-- ----------------------------------------------------------------  
PROCEDURE FX_Roll_Trades_OnDemand
(
  p_CURSOR OUT T_CURSOR
)
AS
BEGIN
-- *****************************************************************
-- START OF: FX_Roll_Trades_OnDemand
-- ****************************************************************       
  OPEN p_CURSOR FOR

  /* On demand version allows user to specify the dates. This is particularly useful to accommodate any currency holidays. Input required are:
  rolldate
  valuedate
  forwarddate
  rolldateCAD
  valuedateCAD
  forwarddateCAD        all in the 'dd-Mon-yyyy' format. e.g. 04-Oct-2018    */

  -- this on demand version is to be copied out to execute when requried. It will not be called by the emailer for example
   --Below query returns result in the exact Templated format required by the TradeLoader tool   ON DEMAND
 
/*********************Non CAD, TRY: 1st to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/

SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732' WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID,'FX Rolls' AS COMMENTS
,SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT,(Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY		
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedate  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldate
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   	GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0   ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG =:rolldate
AND FXROLLSOPEN.DATEVAL =:valuedate  -- line1
AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs   ON FXROLLSOPEN.operateur=rs.ident
  
  
  

union
/********************* Non CAD, TRY: 2nd to reopen  in FX Rolls folders using Price 2 in Line2 of the Roll trades******************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID,  
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID
		,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH	,T.SICOVAM AS SICOVAM
		,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY ,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedate  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldate
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
    GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = :rolldate
AND FXROLLSOPEN.DATEVAL = :forwarddate    -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   
   
   
   union   
/********************* Non CAD, TRY: 3rd to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506'  END AS FundID
,CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL   END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude      cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedate  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldate
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = :rolldate
   AND FXROLLSOPEN.DATEVAL =:valuedate   -- line1
  AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
 
 
 
 
 union 
/*********************Non CAD, TRY: 4th to reopen in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
 SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,CASE   WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL  END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE,OPENPOSITIONS.NAME	,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedate  
        and h.sicovam not in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldate
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM         
  GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM  and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = :rolldate
AND FXROLLSOPEN.DATEVAL = :forwarddate     -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   


union
    --Below query returns result in the exact Templated format required by the TradeLoader tool
/*********************CAD, TRY: 1st to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID, 
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732' WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID,'FX Rolls' AS COMMENTS
,SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT,(Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY		
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedateCAD
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldateCAD
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   	GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0   ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG = :rolldateCAD
AND FXROLLSOPEN.DATEVAL =:valuedateCAD  -- line1
AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs   ON FXROLLSOPEN.operateur=rs.ident
  



union
/********************* CAD, TRY: 2nd to reopen  in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID,  
CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,Q2.Folio_ID AS FOLIO_ID,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,OPENPOSITIONS.Folio_ID  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (
SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID
		,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH	,T.SICOVAM AS SICOVAM
		,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY ,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedateCAD
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldateCAD
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
    GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG = :rolldateCAD
AND FXROLLSOPEN.DATEVAL = :forwarddateCAD     -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
   
   
   
   
   union   
/*********************CAD, TRY: 3rd to close out in FX Rolls folders using Price 1 in Line1 of the Roll trades********************************************************************************************************/
SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506'  END AS FundID
,CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL   END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731'  END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(-1*Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (-1*Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE	,OPENPOSITIONS.NAME		,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY	,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude  cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedateCAD
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldateCAD
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM          
   GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM   and FXROLLSOPEN.OPCVM IN (138237, 138264)  AND FXROLLSOPEN.DATENEG =:rolldateCAD
   AND FXROLLSOPEN.DATEVAL =:valuedateCAD   -- line1
  AND FXROLLSOPEN.INFOS<>'FX Rolls'  
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident
 
 
 
 
 
 union 
/********************* CAD, TRY: 4th to reopen in FX Rolls folders using Price 2 in Line2 of the Roll trades********************************************************************************************************/
 SELECT 'FX_SPT' AS TYPE,concat(to_char(FXROLLSOPEN.dateneg, 'DD/MM/YYYY'), ' 00:00') AS Trade_Date,rs.name AS TRADER,'10010876' AS COUNTERPARTY_ID
,  CASE WHEN Q2.FUND='GEMM MASTER Fund' THEN '10003512' WHEN Q2.FUND='ARF MASTER Fund' THEN '10003506' END AS FundID
,CASE   WHEN Q2.FUND='GEMM MASTER Fund' THEN 138264  WHEN Q2.FUND='ARF MASTER Fund' THEN 138237  ELSE NULL  END AS FOLIO_ID -- hardcode this
,'10010876' AS BROKER_ID
, CASE  WHEN Q2.FUND='GEMM MASTER Fund' THEN '10027732'  WHEN Q2.FUND='ARF MASTER Fund' THEN '10027731' END AS DESPOSITARY_ID
,'FX Rolls' AS COMMENTS, SUBSTR(Q2.REFERENCE, 1, 3) AS SPT_BASE_CURRENCY,SUBSTR(Q2.REFERENCE, -3) AS SPT_QUOTE_CURRENCY
,(Q2.QUANTITY ) AS SPT_BASE_AMOUNT, (Q2.QUANTITY * FXROLLSOPEN.COURS) AS SPT_QUOTE_AMOUNT
,FXROLLSOPEN.COURS AS SPT_RATE, 'CCY1PERCCY2' AS SPT_QUOTE_BASIS,to_char(FXROLLSOPEN.dateval, 'DD/MM/YYYY') AS SPT_SETTLEMENT_DATE
FROM
(SELECT OPENPOSITIONS.FUND	,OPENPOSITIONS.STRATEGY	,p2.OPCVM  ,SUBSTR(BTG_FOLIONAMEPATH(p2.OPCVM), INSTR(BTG_FOLIONAMEPATH(p2.OPCVM), '/',1,7)+1) AS FOLIO_PATH
	,OPENPOSITIONS.SICOVAM	,OPENPOSITIONS.REFERENCE,OPENPOSITIONS.NAME	,OPENPOSITIONS.QUANTITY * -1 AS QUANTITY,OPENPOSITIONS.CCY	
FROM (SELECT T3.NAME AS FUND,REGEXP_SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), '[^/]+', 5, 6) AS STRATEGY,P.OPCVM AS FOLIO_ID,SUBSTR(BTG_FOLIONAMEPATH(P.OPCVM), INSTR(BTG_FOLIONAMEPATH(P.OPCVM), '/', 1, 7) + 1) AS FOLIO_PATH
		,T.SICOVAM AS SICOVAM,T.REFERENCE AS REFERENCE,T.LIBELLE AS NAME,H.DATEVAL,SUM(H.QUANTITE) AS QUANTITY,DEVISE_TO_STR(NVL(T.DEVISECTT, T.DEVISEAC)) CCY,H.DEPOSITAIRE
        FROM POSITION P
	INNER JOIN HISTOMVTS H ON H.MVTIDENT = P.MVTIDENT
	INNER JOIN FOLIO F ON F.IDENT = P.OPCVM
	INNER JOIN TITRES T ON T.SICOVAM = P.SICOVAM
	INNER JOIN TIERS T3 ON T3.IDENT = H.ENTITE
	INNER JOIN TIERS T3C ON T3C.IDENT = H.CONTREPARTIE
	INNER JOIN BO_KERNEL_STATUS S ON S.ID = H.BACKOFFICE
	INNER JOIN BUSINESS_EVENTS BE ON BE.ID = H.TYPE
	LEFT JOIN AFFECTATION A ON A.IDENT = T.AFFECTATION
	WHERE P.OPCVM IN (SELECT IDENT FROM FOLIO START WITH IDENT IN (135518,138262) CONNECT BY PRIOR IDENT = MGR) --Global FX
		AND P.OPCVM <> 138237 AND P.OPCVM <>138472 -- Exclude Global FX>FX Rolls
		AND H.BACKOFFICE NOT IN (SELECT KERNEL_STATUS_ID FROM BO_KERNEL_STATUS_COMPONENT WHERE KERNEL_STATUS_GROUP_ID = 68415) -- Exclude cancelled trades  
		AND BE.COMPTA = 1 -- Select only Business Events that affect position  
		AND H.DATEVAL = :valuedateCAD
        and h.sicovam in (67603203,67611267,67603202,67611268)
        AND H.DATENEG <= :rolldateCAD
        AND H.DEPOSITAIRE IN (10027731, 10027732) -- UBS-GLOBAL-FX-ARF, UBS-GLOBAL-FX-GEMM         
  GROUP BY T3.NAME ,P.OPCVM ,T.SICOVAM ,T.REFERENCE,H.DATEVAL,T.LIBELLE,T.DEVISECTT,T.DEVISEAC,T.NOMINAL,H.DEPOSITAIRE
    having sum(quantite)<>0 ) OPENPOSITIONS
INNER JOIN POSITION P2 ON P2.SICOVAM = OPENPOSITIONS.SICOVAM AND P2.OPCVM IN (138237, 138264)) Q2
INNER JOIN JOIN_POSITION_HISTOMVTS FXROLLSOPEN ON FXROLLSOPEN.SICOVAM = Q2.SICOVAM  and FXROLLSOPEN.OPCVM IN (138237, 138264) AND FXROLLSOPEN.DATENEG =:rolldateCAD
AND FXROLLSOPEN.DATEVAL = :forwarddateCAD    -- line2
AND FXROLLSOPEN.INFOS<>'FX Rolls'
INNER JOIN riskusers rs    ON FXROLLSOPEN.operateur=rs.ident;


-- *****************************************************************
-- END OF: FX_Roll_Trades_OnDemand
-- *****************************************************************    
END FX_Roll_Trades_OnDemand;  

END PCKG_BTG_EMAILER_FOREPORTS;