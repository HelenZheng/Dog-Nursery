create or replace
PACKAGE         "PCKG_BTG_EMAILER_FOREPORTS" 
AS

  TYPE T_CURSOR IS REF CURSOR;


-- *****************************************************************
-- Description:     PROCEDURE  EMFX_POS_ACT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EMFX_POS_ACT
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  EMLATAMRATES_POS_ACT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EMLATAMRATES_POS_ACT
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  GEMM_TODAYSTRADES
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE GEMM_TODAYSTRADES
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  EMCREDIT_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EMCREDIT_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  GEMM_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE GEMM_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  GEMM_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE GEMM_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
  
    -- *****************************************************************
-- Description:     PROCEDURE  QSF_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 08 JAN 2014    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE QSF_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  QSF_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 08 JAN 2014    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE QSF_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
   
  -- *****************************************************************
-- Description:     PROCEDURE  USRATES_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE USRATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
   
  
-- *****************************************************************
-- Description:     PROCEDURE  USRATES_TRADEREPORT
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE USRATES_TRADEREPORT
  (
    p_CURSOR OUT T_CURSOR
  ); 
 
  
-- *****************************************************************
-- Description:     PROCEDURE  USCREDIT_TRADEREPORT
--                  
--
-- Author:          Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Iniesta     Created.
-- *****************************************************************
  PROCEDURE USCREDIT_TRADEREPORT
  (
    p_CURSOR OUT T_CURSOR
  ); 
  
  -- *****************************************************************
  -- Description:     PROCEDURE  EUCORPORATE_6M
  --                  
  --
  -- Author:          Luis Iniesta
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 01 DEC 2015    Luis Iniesta      Created.
  -- *****************************************************************
    PROCEDURE EUCORPORATE_6M
    (
      p_CURSOR OUT T_CURSOR
  ); 

  -- *****************************************************************
-- Description:     PROCEDURE  EUCORPORATE_1M
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EUCORPORATE_1M
  (
    p_CURSOR OUT T_CURSOR
  ); 
  
  -- *****************************************************************
  -- Description:     PROCEDURE  EUCORPORATE_1W
  --                  
  --
  -- Author:          Luis Iniesta
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 01 DEC 2015   Luis Iniesta      Created.
  -- *****************************************************************
    PROCEDURE EUCORPORATE_1W
    (
      p_CURSOR OUT T_CURSOR
  ); 

  -- *****************************************************************
-- Description:     PROCEDURE  EUCORPORATE_NOW
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2015 Luis Iniesta     Created.
-- *****************************************************************
  PROCEDURE EUCORPORATE_NOW
  (
    p_CURSOR OUT T_CURSOR
  ); 

-- *****************************************************************
-- Description:     PROCEDURE  GLOCREDIT_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE GLOCREDIT_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  ); 

-- *****************************************************************
-- Description:     PROCEDURE  EMEARATES_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EMEARATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  ); 
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_VOLATILITY_TRADES
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EQ_VOLATILITY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_EVENTS_TRADES
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 23 APR 2015    Luis Iniesta     Created.
-- *****************************************************************
  PROCEDURE EQ_EVENTS_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  FOCUS_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE FOCUS_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  FOCUS_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE FOCUS_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );

  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_CONVERTIBLE_BONDS
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE EQ_CONVERTIBLE_BONDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_CB_UPCMNG_DVDNDS
--                  
--
-- Author:          Sam Clark
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Sam Clark      Created.
-- *****************************************************************
  PROCEDURE EQ_CB_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_EVNTS_UPCMNG_DVDNDS
--                  
--
-- Author:          Sam Clark
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Sam Clark      Created.
-- *****************************************************************
  PROCEDURE EQ_EVNTS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_LS_UPCMNG_DVDNDS
--                  
--
-- Author:          Sam Clark
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Sam Clark      Created.
-- *****************************************************************
  PROCEDURE EQ_LS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_MGNT_UPCMNG_DVDNDS
--                  
--
-- Author:          Sam Clark
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Sam Clark      Created.
-- *****************************************************************
  PROCEDURE EQ_MGNT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
-- Description:     PROCEDURE  EQ_VOL_UPCMNG_DVDNDS
--                  
--
-- Author:          Sam Clark
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Sam Clark      Created.
-- *****************************************************************
  PROCEDURE EQ_VOL_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

    -- *****************************************************************
-- Description:     PROCEDURE  EQ_EUR_UPCMNG_DVDNDS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 May 2013    Oliver South      Created.
-- *****************************************************************
  PROCEDURE EQ_EUR_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

    -- *****************************************************************
-- Description:     PROCEDURE  EQ_US_UPCMNG_DVDNDS
--                  
--
-- Author:         Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 May 2013    Oliver South      Created.
-- *****************************************************************
  PROCEDURE EQ_US_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
 -- *****************************************************************
-- Description:     PROCEDURE  EQ_CIO_AD_UPCMNG_DVDNDS
--                  
--
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EQ_CIO_AD_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
  
 -- *****************************************************************
-- Description:     PROCEDURE  EQ_US_IPO_ASSET_UPCMNG_DVDNDS
--                  
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EQ_US_IPO_ASSET_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

  
-- *****************************************************************
-- Description:     PROCEDURE  EQ_G_CREDIT_UPCMNG_DVDNDS
--                  
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EQ_G_CREDIT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
 
-- *****************************************************************
-- Description:     PROCEDURE  EU_CORPORATE_UPCMNG_DVDNDS
--                  
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EU_CORPORATE_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

 

-- *****************************************************************
-- Description:     PROCEDURE  EQ_X_ASSET_UPCMNG_DVDNDS
--                  
--
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EQ_X_ASSET_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );
 
-- *****************************************************************
-- Description:     PROCEDURE  EQ_REL_VAL_UPCMNG_DVDNDS
--                  
--
-- Author:         L. Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- L. Iniesta     Created. 2015
-- *****************************************************************
  PROCEDURE EQ_REL_VAL_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  ); 
 

-- *****************************************************************
-- Description:     PROCEDURE  EQ_ENERGY_OP_3
--                  
-- Author:          Matt Kelly
--
-- Revision History
--
-- Date				Author        	Reason for Change
-- ----------------------------------------------------------------
-- 25 APRIL 2013    Matt Kelly		Created.
-- 21 Mar 2016    Gustavo Binnie  PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- *****************************************************************
  PROCEDURE EQ_ENERGY_OP_3
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  ARF2_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE ARF2_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
-- Description:     PROCEDURE  ARF2_POSCHANGE
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE ARF2_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );
      
  -- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_EUR_RATES_ALLOC
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE COMPLIANCE_EUR_RATES_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  );   
  
-- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_X_ASSET_ALLOC
--                  
--
-- Author:          Luis Iniesta
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 07 JAN 2015    Luis Iniesta      Created.
-- *****************************************************************
  PROCEDURE COMPLIANCE_X_ASSET_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  );      
  
  -- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_US_RATES_ALLOC
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE COMPLIANCE_US_RATES_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  ); 
  
  -- *****************************************************************
-- Description:     PROCEDURE  COMPLIANCE_EQ_ALLOC
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************

 PROCEDURE COMPLIANCE_EQ_ALLOC
  (
    p_CURSOR OUT T_CURSOR
  );

 -- *****************************************************************
-- Description:     PROCEDURE  ARF_POSCHANGE
--                  
--
-- Author:          Jameela
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 Jul 2013   Jameela     Request by Risk team to see ARF positon change
-- *****************************************************************
  PROCEDURE ARF_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  ); 
  -- *****************************************************************
-- Description:     PROCEDURE  Global_POSCHANGE
--                  
--
-- Author:          Jameela
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013   Jameela     Request by Risk team to see Global positon change
-- *****************************************************************
  PROCEDURE Global_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  ); 
   -- *****************************************************************
-- Description:     PROCEDURE  ARF_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jameela
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013   Jameela     Request by Risk team to see Global positon change
-- *****************************************************************
    PROCEDURE ARF_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );  
     -- *****************************************************************
-- Description:     PROCEDURE  Global_POSCHANGE_SUMMARY
--                  
--
-- Author:          Jameela
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 JUL 2013   Jameela     Request by Risk team to see Global positon change
-- *****************************************************************
  PROCEDURE Global_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  EQ_SYS_UPCMNG_DVDNDS
--                  
--
-- Author:          
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 06 Sept 2013     Jameela     request by Gautier for new strategy EQ Systematic ARF2
-- *****************************************************************
  PROCEDURE EQ_SYS_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE CMBS_TRADEREPORT
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  UNALLOCATED_TRADE_T_US_CRED
--                  
--
-- Author: Oliver South         
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 16 Jun 2014     Oliver South   Created
-- *****************************************************************
  PROCEDURE UNALLOCATED_TRADE_T_US_CRED
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  EQENERGYOP_TODAY_TRADES
--                  
--
-- Author: Gustavo Binnie        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 19 Feb 2015     Gustavo Binnie   Created
-- 18 Mar 2016     Gustavo Binnie   PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- *****************************************************************
  PROCEDURE EQENERGYOP_TODAY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
-- Description:     PROCEDURE  STALE_CURVE_CROSS_ASSET
--                  
--
-- Author: Gustavo Binnie        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 17 Apr 2015      Jun Guan      Created
-- *****************************************************************
   PROCEDURE STALE_CURVE_CROSS_ASSET
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
-- *****************************************************************
-- Description:     PROCEDURE  STALE_CURVE_GLOBAL_CREDIT
--                  
--
-- Author: Gustavo Binnie        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 17 Apr 2015      Jun Guan      Created
-- *****************************************************************
   PROCEDURE STALE_CURVE_GLOBAL_CREDIT
  (
    p_CURSOR OUT T_CURSOR
  );

  -- *****************************************************************
  -- Description  ARF_TIMBER_TODAY_TRADES
  --
  -- Author:         Natalie Siegel
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015     ARF_TIMBER_TODAY_TRADES     
  -- *****************************************************************
  PROCEDURE ARF_TIMBER_TODAY_TRADES    
	(
		p_CURSOR OUT T_CURSOR
	);

	
  -- *****************************************************************
  -- Description  CR_ASSET_LOANS_UNSET_TRADES
  --
  -- Author:         Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015     CR_ASSET_LOANS_UNSET_TRADES     
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_UNSET_TRADES    
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description  CR_ASSET_LOANS_NB_UNSET_TRADES
  --
  -- Author:         Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015     CR_ASSET_LOANS_NB_UNSET_TRADES     
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_NB_UNSET_TRADES    
	(
		p_CURSOR OUT T_CURSOR
	);

	  -- *****************************************************************
  -- Description  CR_ASSET_LOANS_UNSET_TRADES
  --
  -- Author:         Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015     CR_ASSET_LOANS_SET_TRADES     
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_SET_TRADES    
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description  CR_ASSET_LOANS_NB_UNSET_TRADES
  --
  -- Author:         Gustavo Binnie
  --
  -- Revision History
  -- Date				Author			   Reason for Change
  -- ----------------------------------------------------------------
  --   15-JUL-2015     CR_ASSET_LOANS_NB_SET_TRADES     
  -- *****************************************************************
  PROCEDURE CR_ASSET_LOANS_NB_SET_TRADES    
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  EQ_EVENTS_NY_TODAY_TRADES
--                  
--
-- Author: Gustavo Binnie        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 14 Aug 2015     Gustavo Binnie   Created
-- *****************************************************************
   PROCEDURE EQ_EVENTS_NY_TODAY_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  LOANS_COUPONS
--                  
--
-- Author: Davi Xavier        
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 19 Oct 2015      Davi Xavier   Created
-- *****************************************************************
   PROCEDURE LOANS_COUPONS
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  LOANS_COUPONS_POS_0
--                  
--
-- Author: Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 19 NOV 2015      Davi Xavier   Created
-- *****************************************************************
   PROCEDURE LOANS_COUPONS_POS_0
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
-- Description:     PROCEDURE  GEMM_POS_CHANGE_TDY
--                  
--
-- Author: Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 10 DEC 2015      Davi Xavier   Created
-- *****************************************************************
   PROCEDURE GEMM_POS_CHANGE_TDY
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
-- Description:     PROCEDURE  QSF_POS_CHANGE_TDY
--                  
--
-- Author: Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 04 FEV 2015      Davi Xavier   Created
-- *****************************************************************
   PROCEDURE QSF_POS_CHANGE_TDY
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description  PROCEDURE ARF_POS_CHANGE_TDY
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 06 FEB 2017      Gustavo Binnie   Created (PMOG-1091)
-- *****************************************************************
  PROCEDURE ARF_POS_CHANGE_TDY
	(
		p_CURSOR OUT T_CURSOR
	);

   -- *****************************************************************
-- Description:     PROCEDURE  EQ_ENERGYOP_UPCMNG_DVDNDS
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 18 MAR 2016      Gustavo Binnie   PMOG-930 - Created
-- *****************************************************************
   PROCEDURE EQ_ENERGYOP_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  SEC_PRODUCTS_POSCHANGE
-- Revision History
-- Date             Author         Reason for Change
-- 26-MAY-2016		Gustavo Binnie Created (GAMCP-21)
-- ----------------------------------------------------------------       
 PROCEDURE SEC_PRODUCTS_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  SEC_PRODUCTS_TODAYSTRADES
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 26-MAY-2016		Gustavo Binnie Created (GAMCP-21)
-- *****************************************************************
  PROCEDURE SEC_PRODUCTS_TODAYSTRADES
	(
     p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
-- Description:     PROCEDURE  GLOBALRATES_TRADEREPORT
--                  
--
-- Author:          Jeff  Yu
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 04 NOV 2016    Jeff Yu     Created.
-- *****************************************************************

  PROCEDURE GLOBALRATES_TRADEREPORT
	(
     p_CURSOR OUT T_CURSOR
	);

	-- *****************************************************************
-- Description:     PROCEDURE GLOBALRATES_POSCHANGE
--                  
--
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 04 NOV 2016    Jeff Yu      Created.
-- *****************************************************************
  PROCEDURE GLOBALRATES_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );


  -- *****************************************************************
-- Description:     PROCEDURE  GDO_TODAYSTRADES
--                  
--
-- Author:          Jeff Yu
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu      Created.
-- *****************************************************************
  PROCEDURE GDO_TODAYSTRADES
  (
    p_CURSOR OUT T_CURSOR
  );

 
  -- *****************************************************************
-- Description:     PROCEDURE  GDO_POSCHANGE

-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu      Created.
-- *****************************************************************
  PROCEDURE GDO_POSCHANGE
  (
    p_CURSOR OUT T_CURSOR
  );

   -- *****************************************************************
-- Description:     PROCEDURE  GDO_POSCHANGE_SUMMARY

-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017    Jeff Yu      Created.
-- *****************************************************************
  PROCEDURE GDO_POSCHANGE_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  GDO_POS_CHANGE_TDY

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 29 SEP 2017      Jeff Yu   Created
-- *****************************************************************
   PROCEDURE GDO_POS_CHANGE_TDY
  (
    p_CURSOR OUT T_CURSOR
  );

 -- *****************************************************************
  -- Description  PROCEDURE VOL_VAR_SWAP_WRONG_SET_UP

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 22 MAR 2018     Helen Zheng   Created
-- *****************************************************************

   PROCEDURE VOL_VAR_SWAP_WRONG_SET_UP
  (
    p_CURSOR OUT T_CURSOR
  );

   -- *****************************************************************
  -- Description  PROCEDURE EQ_QUANT_TRADES

-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 27 MAR 2018     Olivier Dechazal   Created
-- *****************************************************************

   PROCEDURE EQ_QUANT_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );


 -- *****************************************************************
-- Description:     PROCEDURE  EQ_EQQUANT_UPCMNG_DVDNDS

-- Revision History
-- Date             Author        Reason for Change
-- 29 Mar 2018      Helen Zheng       Created on EQ Quant launch (APPSUPP-4397)
-- ----------------------------------------------------------------   

   PROCEDURE EQ_EQQUANT_UPCMNG_DVDNDS
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  EURATES_TRADES

-- Revision History
-- Date           Author            Reason for Change
-- 23 May 2018    Andre Bresslau    Created on PMOF-314
-- ----------------------------------------------------------------

   PROCEDURE EURATES_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );

  
-- *****************************************************************
-- Description:     PROCEDURE  EM_LATAM_RATES_TRADES

-- Revision History
-- Date           Author            Reason for Change
-- 01 Jun 2018    Gustavo Binnie    Created on PMOF-317
-- ----------------------------------------------------------------

   PROCEDURE EM_LATAM_RATES_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );

  
-- *****************************************************************
-- Description:     PROCEDURE  FX_Roll_Trades

-- Revision History
-- Date           Author            Reason for Change
-- 04 Sep 2018    Helen Zheng    Created on PMOG-1260
-- 21 Sep 2018    Helen Zheng    refactored PMOG-1270
-- ----------------------------------------------------------------

   PROCEDURE FX_Roll_Trades
  (
    p_CURSOR OUT T_CURSOR
  );

END PCKG_BTG_EMAILER_FOREPORTS;