create or replace
PACKAGE BODY PCKG_BTG_EMAILER_NON_CRITICAL AS


   -- *****************************************************************
  -- Description: PROCEDURE NO_COMMISSION
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- 18 FEB 13	Oliver South   Set the date format and correct fund join
PROCEDURE NO_COMMISSION
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
  -- ***************************************************************************
  -- BEGIN OF NO_COMMISSION 
  -- ***************************************************************************
    OPEN p_CURSOR FOR
        SELECT      
                      FUND_BOOK_STRATEGY.BOOK_NAME					Strategy_Name
                     ,FUND_BOOK_STRATEGY.Fund_NAME					Fund_Name
                     ,Trades.sicovam				   				Sicovam
                     ,Trades.refcon									TradeId
                     ,Instrument.libelle							Name
                     ,trunc(Trades.DATENEG)							d$Trade_Date
                     ,trunc(Trades.DATEVAL)							d$Value_Date
                     ,Trades.quantite								n$Quantity
                     ,Trades.Montant								n$Net_Amount
                     ,DEVISE_TO_STR(Trades.devisepay)				Currency
                     ,trader.name									Trader
                     ,business_events.name							Busines_Event
      FROM            histomvts Trades 
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      INNER JOIN      riskusers trader
      ON              trader.ident                                  = Trades.operateur      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam       
      INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
	  ON           FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
      
      WHERE           
            Trades.BACKOFFICE               NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades                 
      AND   Instrument.TYPE                 = 'C' --Comission
      AND   trades.type                    NOT IN (50,7,694) -- not commission, Subscription/Redemption or Cash Transfer
      AND   ( trades.quantite = 0 
              OR 
              trades.quantite IS NULL
            )
      AND   trades.operateur               != 1
      ORDER BY 1,2 ASC;
 
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	  
  -- ***************************************************************************
  -- END OF NO_COMMISSION 
  -- ***************************************************************************
	END NO_COMMISSION; 



  -- *****************************************************************
  -- Description:PROCEDURE TRADES_CFD_BKR_CP_WRONG
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --11 Mar 2013 Oliver South	Added Block Id into report SR-74
  -- *****************************************************************
 PROCEDURE TRADES_CFD_BKR_CP_WRONG
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_CFD_BKR_CP_WRONG 
  -- ***************************************************************************			
		OPEN p_CURSOR FOR
       SELECT          
                      FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name
                    , FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name 
                    , Trades.sicovam                        Sicovam
                    , ta_block_to_generated.block_id        Block_id
                    , Trades.refcon                         Refcon
                    , Instrument.libelle                    Name
                    , Instrument.reference                  Ticker
                    , trunc(Trades.DATENEG)                 d$Trade_Date
                    , trunc(Trades.DATEVAL)                 d$Value_Date
                    , Trades.QUANTITE                       n$Quantity
                    , counterparty.name                     Counterparty
                    , broker.name                           Broker
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    LEFT JOIN       ta_block_to_generated
    ON              ta_block_to_generated.generated_id = Trades.refcon
    INNER JOIN ( 
                   SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                          , FOLIO.ident                                                            AS STRATEGY_ID
                          , FOLIO.name                                                             AS STRATEGY_NAME
                          , level
                    FROM FOLIO
                    WHERE LEVEL                       >= 4
                    START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                    CONNECT BY PRIOR   FOLIO.ident    = FOLIO.mgr
                  ) FUND_BOOK_STRATEGY
    ON              FUND_BOOK_STRATEGY.STRATEGY_ID    = Trades.OPCVM
    LEFT JOIN       riskusers trader
    ON              trader.ident                      = Trades.operateur
    LEFT JOIN       tiers counterparty
    ON              counterparty.ident                = trades.contrepartie
    LEFT JOIN       tiers broker
    ON              broker.ident                      = trades.courtier
    WHERE           instrument.affectation			  = 12  --CFD
    AND             (  counterparty.ident             != '10011565' 
                       OR broker.ident                = '10011565' ) --CP not CFD-COUNTERPARTY and Broker is CFD-COUNTERPARTY
    AND             Trades.BACKOFFICE                 NOT IN (192,11,13,17,26,27,220,248,252) -- checked mo canceled
    ORDER BY 1,4;
  -- ***************************************************************************
  -- END OF TRADES_CFD_BKR_CP_WRONG 
  -- ***************************************************************************
	END TRADES_CFD_BKR_CP_WRONG;



  -- *****************************************************************
 -- Description: PROCEDURE TRADES_MISSING_FEES
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 --11 Mar 2013 Oliver South	Add in Block ID SR-73
 --02 Jan 2014 Oliver South	Exclude PB transfer trades PMOG-402
 -- ----------------------------------------------------------------     
  PROCEDURE TRADES_MISSING_FEES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_MISSING_FEES 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

SELECT          
					  FUND_BOOK_STRATEGY.BOOK_NAME			Strategy_Name
					, FUND_BOOK_STRATEGY.Fund_NAME			Fund_Name
					, Trades.sicovam						Sicovam
					, ta_block_to_generated.block_id		Block_id
					, Trades.refcon							Trade_Id
					, trader.name							Trader
					, Instrument.libelle					Name
					, Instrument.reference					Ticker
					, trunc(Trades.DATENEG)					d$Trade_Date
					, trunc(Trades.DATEVAL)					d$Value_Date
					, Trades.QUANTITE						n$Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    LEFT JOIN       ta_block_to_generated
    ON              ta_block_to_generated.generated_id = trades.refcon
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    WHERE           Trades.DATENEG                     > trunc(sysdate) - 5 --recent trades
    AND             (
                       (Instrument.TYPE               = 'A') --shares
                    OR 
                        (Instrument.TYPE               = 'F' 
                        AND instrument.affectation    !=33) --Futures excluding FRA
                    )
    AND             trades.type                                   in (1,140,1494)  --Purchase/Sale, short sale, secondary offering
    AND             trades.fraismarche                            =0  --market fees
    AND             trades.fraiscounterparty                      =0  --CP fees
    AND             trades.fraiscourtage                          =0  --broker fees  
    AND             trades.courtier                               NOT IN (
                                                                          SELECT BTG_MAPPING_CODE.INPUT_CODE
                                                                          FROM BTG_MAPPING_CODE
                                                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = '9'
                                                                          AND BTG_MAPPING_CODE.TYPE_ID = '46'
                                                                          ) --exclude PB Transfer as broker
    AND             Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252)   -- exclude cancelled trades
    AND             devise_to_str(trades.devisepay)               != 'BRL'  --exclude BRL trades
    ORDER BY        1,4 ASC;

  -- ***************************************************************************
  -- END OF TRADES_MISSING_FEES 
  -- ***************************************************************************
	END TRADES_MISSING_FEES;




 -- *****************************************************************
 -- Description:     PROCEDURE  BOND_TRADES_WITH_FEE
 --                  
 --
 -- Author:          Oliver South
 --
 -- Revision History
 -- Date             Author         Reason for Change
 -- ----------------------------------------------------------------
 -- 13 Sep 2013     Oliver South       Created.
 -- 13 Sep 2013     Oliver South       Updated/Davi arranged the release with App Support
 -- *****************************************************************  

  PROCEDURE BOND_TRADES_WITH_FEE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- BEGIN OF: BOND_TRADES_WITH_FEE
  -- *****************************************************************   
          OPEN p_CURSOR FOR
			SELECT          
                        FUND_BOOK_STRATEGY.FUND_NAME        Fund_Name
                      , FUND_BOOK_STRATEGY.STRATEGY_NAME    Strategy_Name
                      , HISTOMVTS.sicovam                   Sicovam
                      , HISTOMVTS.refcon                    Trade_Id
                      , RISKUSERS.name                      Trader
                      , TITRES.libelle                      Instrument_Name
                      , TITRES.reference                    Instrument_Reference
                      , TRUNC(HISTOMVTS.dateneg)            d$Trade_Date
                      , TRUNC(HISTOMVTS.dateval)            d$Value_Date
                      , HISTOMVTS.fraismarche               Market_fees
                      , HISTOMVTS.fraiscounterparty         Counterparty_fees
                      , HISTOMVTS.fraiscourtage             Broker_fees
                      , BUSINESS_EVENTS.name                Busines_Event
			FROM            HISTOMVTS
			INNER JOIN      BUSINESS_EVENTS
			ON              BUSINESS_EVENTS.id = HISTOMVTS.type
      AND             BUSINESS_EVENTS.compta = 1 --position affecting tickets only
			INNER JOIN      RISKUSERS
			ON              RISKUSERS.ident = HISTOMVTS.operateur
			INNER JOIN      TITRES
			ON              TITRES.sicovam = HISTOMVTS.sicovam 
      AND             DEVISE_TO_STR(TITRES.devisectt) != 'BRL' --exclude BRL instruments since they can take the IOF tax in the fees if realising PnL within a month of the purchase
      AND             TITRES.type = 'O' --any instrument on the bond template
			INNER JOIN ( 
                      SELECT     
                                    CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                  , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                  , FOLIO.ident                                                           AS STRATEGY_ID
                                  , FOLIO.name                                                            AS STRATEGY_NAME
                                  , level
                      FROM        FOLIO
                      WHERE       LEVEL     <= 4
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                      CONNECT BY PRIOR FOLIO.ident      = FOLIO.mgr  
                   ) FUND_BOOK_STRATEGY
			ON              FUND_BOOK_STRATEGY.STRATEGY_ID      = HISTOMVTS.OPCVM 
			WHERE        ( 
                            HISTOMVTS.fraismarche                            !=0  --market fees
                      OR    HISTOMVTS.fraiscounterparty                      !=0  --CP fees
                      OR    HISTOMVTS.fraiscourtage                          !=0  --broker fees  
                    )
			AND           HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --deleted/cancelled trades
			;
      
	-- *****************************************************************
  -- END OF: BOND_TRADES_WITH_FEE
  -- *****************************************************************   
	END BOND_TRADES_WITH_FEE; 



  PROCEDURE CFD_ITALIAN_EQUITY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF CFD_ITALIAN_EQUITY
  -- ***************************************************************************   
     OPEN p_CURSOR FOR
	SELECT 
            FUND_BOOK_STRATEGY.BOOK_NAME                Strategy
          , FUND_BOOK_STRATEGY.Fund_NAME                FUND
          , TRADES.refcon                               TRADE_ID
          , TRADES.sicovam                              SICOVAM
          , TITRES.reference                            REFERENCE
          , TITRES.libelle                              NAME
          , TRADES.dateneg                              d$TRADE_DATE
          , TRADES.DATEVAL                              d$VALUE_DATE
          , TRADES.QUANTITE                             QUANTITY
          , USERS.name                                  Operator    
      FROM histomvts TRADES
  INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
              ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
            ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm
    INNER JOIN  TITRES
    ON          TITRES.sicovam =   TRADES.sicovam
    AND         TITRES.type = 'G' --CFD instrument type
    INNER JOIN  TITRES underlying
    ON          underlying.sicovam = titres.code_emet
    AND         underlying.marche in (1480871241, 1296649262, 1230259791) --New Market Milan, Borsa Italiana, Mercato Italiano Futures Exchange
    INNER JOIN  riskusers   users
    ON          users.ident =  TRADES.operateur   
    INNER JOIN  BUSINESS_EVENTS
    ON          BUSINESS_EVENTS.ID = TRADES.TYPE
    AND         BUSINESS_EVENTS.COMPTA = 1 --position affecting tickets only
    WHERE     TRADES.DATENEG > trunc(sysdate)-5 --recent trades
    AND       TRADES.backoffice NOT IN (11, 13, 180, 182, 186, 190, 192, 220, 246, 248, 250, 252) --ignore cancelled trades
    ORDER BY 1,2,7;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF CFD_ITALIAN_EQUITY 
  -- ***************************************************************************         
	END CFD_ITALIAN_EQUITY;



 -- *****************************************************************
 -- Description: PROCEDURE TRADEDT_IS_VALUEDT
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb	      Oliver South		Order of columns and checking for trades with TD > VD SR-64
 --01 May 2013    Gustavo Binnie    Excluded Repo Trades
 -- ----------------------------------------------------------------     

  PROCEDURE TRADEDT_IS_VALUEDT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADEDT_IS_VALUEDT 
  -- *************************************************************************** 			
		OPEN p_CURSOR FOR

    SELECT          
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, Trades.sicovam                        Sicovam
						, Trades.refcon                         Trade_Id
						, trader.name                           Trader
						, Instrument.libelle                    Name
						, Instrument.reference                  Ticker
						, trunc(Trades.DATENEG)                 d$Trade_Date
						, trunc(Trades.DATEVAL)                 d$Value_Date
						, Trades.QUANTITE                       n$Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam                 =  Trades.sicovam 
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON              FUND_BOOK_STRATEGY.STRATEGY_ID           = Trades.OPCVM
    INNER JOIN      riskusers trader
    ON              trader.ident                             = Trades.operateur
    WHERE           Trades.DATENEG                           > trunc(sysdate) - 5
    AND             (
                       (Instrument.TYPE in ('A','O') --shares and bonds
                       AND instrument.affectation           not in (20,1801,45) --Cash, Cash Loan and External funds
                       AND trades.dateneg = trades.dateval) 
                    OR 
                       (Instrument.TYPE = 'D' 
                       AND Instrument.Affectation           = 23 --FXO
                       AND trades.dateneg = trades.dateval) 
                    OR
                      (trades.dateneg > trades.dateval)
                    )
    AND             trades.type                             in (1,140,1494) --only trades, not CA
    AND             Instrument.TYPE                         NOT IN ('L') -- not Repos
    AND             Trades.BACKOFFICE                       NOT IN (192,11,13,17,26,27,220,248,252)   -- checked not canceled
    AND             devise_to_str(trades.devisepay) != 'BRL'  --exclude BRL trades
    ORDER BY        1,2 ASC;


  -- ***************************************************************************
  -- BEGIN OF TRADEDT_IS_VALUEDT 
  -- *************************************************************************** 	
	END TRADEDT_IS_VALUEDT;


  -- *****************************************************************
  -- Description: PROCEDURE OPS_AS_TRADERS
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan			Created.
  -- 06-May-2013  Gustavo Binnie	Christopher Cade moved to FO on 15-Mar-2013
  -- 08-Nov-2016   Jeff Yu        Add Craig McCormack in the exception list       
  -- 23-May-2017  Jeff Yu        PMOG-1086 add Acquisition - Mandatory, Acquisition - Elected into exclusion list
  -- 02 FEB 2018   Jeff Yu         PMOG-1194  Exclude Rafael Rocha as he still books trades per Brazil traders
  -- *****************************************************************
  PROCEDURE OPS_AS_TRADERS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: OPS_AS_TRADERS
  -- *****************************************************************  

    OPEN p_CURSOR FOR    
SELECT        
              FUND_BOOK_STRATEGY.Fund_NAME            Fund
            , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
            , HISTOMVTS.sicovam                       Sicovam
            , HISTOMVTS.refcon                        TradeID
            , TITRES.reference                        Ticker
            , TRUNC(HISTOMVTS.dateneg)                d$TradeDate
            , TRUNC(HISTOMVTS.dateval)                d$ValueDate
            , BUSINESS_EVENTS.name                    BusinesEvent
            , RISKUSERS.name                          Trader
    FROM      HISTOMVTS
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
    INNER JOIN    BUSINESS_EVENTS
    ON            BUSINESS_EVENTS.id  = HISTOMVTS.type
    AND           BUSINESS_EVENTS.compta = 1 --position affecting tickets only
    INNER JOIN    RISKUSERS
    ON            RISKUSERS.ident = HISTOMVTS.operateur
    AND           RISKUSERS.gident = 4572 --Trader name in OPERATIONS_TD group
    INNER JOIN    USERINFOS
    ON            USERINFOS.ident = RISKUSERS.ident
    AND           USERINFOS.country != 'BRAZIL' --Brazil users are expected to book trades
    INNER JOIN    TITRES
    ON            TITRES.sicovam  = HISTOMVTS.sicovam
    AND           TITRES.type NOT IN ('C', 'L') --ignore cash events and repo bookings
    WHERE         HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND           HISTOMVTS.type NOT IN (744, 121, 9, 360, 161, 221,846,3,1194,1196) --CFD Roll, Acquisition, Exercise, Expire, Transfer, Exchange,Loan Paydown,Split, Acquisition - Mandatory, Acquisition - Elected
    AND           TRUNC(HISTOMVTS.dateneg) > TRUNC(SYSDATE-30) --trades from past 30 days
    AND           HISTOMVTS.operateur NOT IN (2707, 1889, 2928, 7462, 3387, 3227,4427,12816) --Joe Ilardi, Bill Rose (wrose), Marcos Flaks, Moshumi Seewoogolam, Neila Sula, Jaclyn Barnes, Craig McCormack, Rafael Rocha
    AND           HISTOMVTS.contrepartie NOT IN (10007902) --NDF Fixing tickets are excluded
    ORDER BY 4;
	
  -- *****************************************************************
  -- END OF: OPS_AS_TRADERS
  -- *****************************************************************   
	END OPS_AS_TRADERS; 



  -- *****************************************************************
  -- Description:PROCEDURE  TRADES_NDF_BOOKED_DELIVERABLE
	--
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013	Oliver South	Changed column ordering PROJ-26
  --01 JUL 2016 Gustavo Binnie PMOG-971 - USD/BRL TRADES ON 2689 ACCOUNTS ARE ALLOWED
  -- *****************************************************************
PROCEDURE TRADES_NDF_BOOKED_DELIVERABLE
     (
          p_CURSOR OUT T_CURSOR
     )
AS
BEGIN
  -- *****************************************************************
  -- BEGIN OF: TRADES_NDF_BOOKED_DELIVERABLE
  -- *****************************************************************   
  OPEN p_CURSOR FOR         
         SELECT               
								  FUND_BOOK_STRATEGY.BOOK_NAME Strategy
								, FUND_BOOK_STRATEGY.Fund_NAME Fund
								, Trades.sicovam Sicovam
								, Trades.refcon Trade_ID
								, FUND_BOOK_STRATEGY.BOOK_NAME Strategy
								, Instrument.reference Ticker
								, TRUNC(Trades.DATENEG) d$Trade_Date
								, TRUNC(Trades.DATEVAL) d$Value_Date
								, PrimeBroker.NAME PrimeBroker 
        FROM					histomvts Trades 
        INNER JOIN				titres Instrument 
        ON						Instrument.sicovam = Trades.sicovam 
        INNER JOIN				tiers PrimeBroker 
        ON						PrimeBroker.IDENT = Trades.DEPOSITAIRE 
        INNER JOIN
        (   SELECT 
                CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID ,
                CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID ,
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME ,
                FOLIO.ident                                                         AS STRATEGY_ID ,
                FOLIO.name                                                          AS STRATEGY_NAME ,
                level
             FROM FOLIO
             WHERE LEVEL                                        >= 4
             START WITH FOLIO.ident                            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565)--Primary funds
          CONNECT BY PRIOR FOLIO.ident                         = FOLIO.mgr
        ) FUND_BOOK_STRATEGY 
        ON                    FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM 
        WHERE
              Trades.BACKOFFICE                                 NOT IN (192,11,13,17,26,27,220,248,252)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   -- checked mo canceled
              AND TRUNC(Trades.DATENEG)                         >= TRUNC(sysdate                            -5)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  --recent trades
              AND Instrument.TYPE                               IN ( 'E','X')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         --booked as FX or swap
              AND (   Trades.devisepay                          IN (54612563,54678092,54742096,54742617,54742864,54871888,55135826,55133266,55267927,55269972,55400786,55592270,55593040,55727426,55859012,55918920,55987780) 
                      OR 
                      Instrument.marche                         IN (54612563,54678092,54742096,54742617,54742864,54871888,55135826,55133266,55267927,55269972,55400786,55592270,55593040,55727426,55859012,55918920,55987780) 
                  ) 
             AND PrimeBroker.NAME NOT IN ('UBS- ETD- 009BTG2','UBS- EQTY- I0055470','BTG- PACTUAL- GEMM','INTERNAL TRADES ARF','UBS -ETD- 009BTGAB','INTERNAL TRADES GEMM') --allowed depositaries
             AND (Trades.SICOVAM <> 67607864 OR PrimeBroker.NAME NOT LIKE '%2689%') -- USD/BRL TRADES ON 2689 ACCOUNTS ARE ALLOWED
			 AND (Trades.SICOVAM <> 67603204 OR PrimeBroker.NAME NOT LIKE '%CELFIN%') -- USD/CLP TRADES ON CELFIN ACCOUNTS ARE ALLOWED
        order by 3 ASC;
        /* Reports all London Strategy FX trades that should be set as NDFs */
  -- *****************************************************************
  -- END OF: TRADES_NDF_BOOKED_DELIVERABLE
  -- *****************************************************************          
END TRADES_NDF_BOOKED_DELIVERABLE;


-- *****************************************************************
  -- Description:PROCEDURE OTC_BOX_SWAP
	--
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 27 Jul 2013    Oliver South     Created.
  -- 20 March 2014  Oliver South	 Excluded swaps on bank loans
  -- 14 March 2016  Gustavo Binnie	 PMOG-894 - Bug Fix
  -- 02 FEB 2018    Jeff Yu   PMOG-1194 update logic to only capture positions having opposite Qty direction
  -- *****************************************************************
PROCEDURE OTC_BOX_SWAP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN OF: OTC_BOX_SWAP
 -- *****************************************************************   
     OPEN p_CURSOR FOR

			SELECT 
            BOXED.Fund_NAME                     Fund_NAME
          , BOXED.BOOK_NAME                     BOOK_NAME
          , BOXED.sicovam                       sicovam
          , TITRES.Reference                    
          , TIERS2.name                         Depositary
          , SUM(TRADES.quantite)                Quantity
    
FROM 
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (14414,90565) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
            SELECT
                    POSITION.Fund_NAME
                  , POSITION.BOOK_NAME
                  , POSITION.sicovam
                  , COUNT(POSITION.depositaire)
            FROM (
                          SELECT 
                                    FUND_BOOK_STRATEGY.Fund_NAME
                                  , FUND_BOOK_STRATEGY.BOOK_NAME
                                  , TIERS.name
                                  , HISTOMVTS.sicovam
                                  , HISTOMVTS.depositaire
                                  , SUM(HISTOMVTS.quantite)
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM  HISTOMVTS
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (14414,90565) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire

                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                          
							 AND  HISTOMVTS.depositaire NOT IN (SELECT BTG_MAPPING_CODE.INPUT_CODE
                                          FROM BTG_MAPPING_CODE
                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = 9
                                          AND BTG_MAPPING_CODE.TYPE_ID IN (54, 35)
                                          )--Bank Loan Depositaries, BTG Internal Depostiaries
              GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, TIERS.name, HISTOMVTS.sicovam, HISTOMVTS.depositaire 
						  HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000
              order by FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                          )       POSITION --this creates a table of all positions and indicates if long or short
            GROUP BY POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            HAVING COUNT(POSITION.depositaire) >1 and COUNT(DISTINCT POSITION.DIRECTION) > 1
            order by  POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            )     BOXED --this table shows the positions where there is a long and a short position
ON BOXED.Fund_NAME = FUND_BOOK_STRATEGY2.Fund_NAME
AND BOXED.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXED.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam

WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
AND 	(
									(TITRES.type = 'S' AND  TITRES.default_event_leg1 = 0) --include swaps but not CDS
									OR
									(TITRES.type = 'D' AND TITRES.affectation = 31) --include swaption
									)
GROUP BY boxed.fund_name, boxed.book_name, boxed.sicovam, titres.REFERENCE, tiers2.NAME
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000

UNION ALL--ABOVE ARE THE BOXED POSITIONS WITHIN THE FUND (IN THE SAME STRATEGY) / BELOW ARE THE BOXED POSITIONS IN DIFFERENT FUNDS (IN THE SAME STRATEGY) 

SELECT 
            FUND_BOOK_STRATEGY2.Fund_NAME
          , BOXEDFUND.BOOK_NAME
          , BOXEDFUND.sicovam
          , TITRES.Reference                    
          , TIERS2.name                         Depositary
          , SUM(TRADES.quantite)                Quantity
       
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (14414,90565) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
Select DIRECTION.BOOK_NAME,DIRECTION.sicovam,count(DIRECTION.direction) FROM (
                  SELECT DISTINCT   FUND_BOOK_STRATEGY.BOOK_NAME
                                  , HISTOMVTS.sicovam
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM  HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (14414,90565) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                          AND  HISTOMVTS.depositaire NOT IN (SELECT BTG_MAPPING_CODE.INPUT_CODE
                                          FROM BTG_MAPPING_CODE
                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = 9
                                          AND BTG_MAPPING_CODE.TYPE_ID IN (54, 35)
                                          )   --Bank Loan Depositaries, BTG Internal Depostiaries
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                         HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000) DIRECTION
                          GROUP BY DIRECTION.BOOK_NAME,DIRECTION.sicovam
                          HAVING count(DIRECTION.direction)>1)   BOXEDFUND
                          
ON BOXEDFUND.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXEDFUND.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam

WHERE     trades.backoffice not in (11,13,17,26,27,192,220,248,252)
AND 	(
									(TITRES.type = 'S' AND  TITRES.default_event_leg1 = 0) --include swaps but not CDS
									OR
									(TITRES.type = 'D' AND TITRES.affectation = 31) --include swaption
									)
GROUP BY FUND_BOOK_STRATEGY2.Fund_NAME, BOXEDFUND.book_name, BOXEDFUND.sicovam, titres.REFERENCE, tiers2.NAME
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000
ORDER BY 3,1,2;
      

 -- *****************************************************************
 -- END OF: OTC_BOX_SWAP
 -- *****************************************************************             
END OTC_BOX_SWAP;


  -- *****************************************************************
  -- Description: PROCEDURE CDS_NOT_T3
	-- collects all CDS trades for ARF ARF 2 and GEMM that do not settle cash on T+3*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  -- *****************************************************************
  PROCEDURE CDS_NOT_T3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: CDS_NOT_T3
 -- *****************************************************************  
      OPEN p_CURSOR FOR
      SELECT          
        Trades.sicovam            Sicovam,
        Trades.refcon             TradeId,
        trader.name               Trader,
        Instrument.libelle        Name,
        trunc(Trades.DATENEG)     d$TradeDate,
        trunc(Trades.DATEVAL)     d$ValueDate,
        PrimeBroker.NAME          PrimeBroker,
        business_events.name      BusinesEvent    
      FROM
        histomvts                 Trades 
      INNER JOIN ( 
                  SELECT 
                      CONNECT_BY_ROOT(FOLIO.ident)          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)           AS TOP_FUND_NAME
                    , FOLIO.ident AS STRATEGY_ID
                    ,level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- IN (14414,90565)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID  =    Trades.OPCVM            
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam    
      INNER JOIN      riskusers trader
      ON              trader.ident                                  = Trades.operateur   
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE    
      WHERE           
              Trades.DATENEG             >     trunc(sysdate)-5
      AND     Instrument.affectation     =     22 --CDS
      AND     business_events.compta     =     1 --Not coupons
      AND     trunc(Trades.DATEVAL)      <     BTG_BUSINESS_DATE(Trades.DATENEG, +3) --settlement date less than 3 business days
      AND     Trades.backoffice         NOT IN (192,11,13,17,26,27,220,248,252) --Deleted/Cancelled trades
      ORDER BY 3;

 -- *****************************************************************
 -- END  OF: CDS_NOT_T3
 -- *****************************************************************  
END CDS_NOT_T3;



-- *****************************************************************
  -- Description: PROCEDURE SWAP_SETTLE_DT_WRONG
	-- collects all IRS trades for ARF ARF 2 and GEMM that do not settle cash on T+2*/
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  -- *****************************************************************

  PROCEDURE SWAP_SETTLE_DT_WRONG
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: SWAP_SETTLE_DT_WRONG
 -- *****************************************************************      
      OPEN p_CURSOR FOR
      SELECT       
					  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_Name  
					, FUND_BOOK_STRATEGY.Fund_NAME          Fund_Name
					, Trades.sicovam                        Sicovam
					, Trades.refcon                         Trade_Id
					, trader.name                           Trader
					, Instrument.libelle                    Instrument_Name
					, Instrument.reference                  Instrument_Reference
					, trunc(Trades.DATENEG)                 d$Trade_Date
					, trunc(Trades.DATEVAL)                 d$Value_Date
					, Trades.Montant                        n$Net_Amount
					, DEVISE_TO_STR(trades.devisepay)       Sett_Currency
					, DEVISE_TO_STR(instrument.devisectt)   Inst_Currency
					, business_events.name                  Business_Event    
      FROM            
                  histomvts Trades    
      INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                     AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                  , FOLIO.ident                                                           AS STRATEGY_ID
                  , FOLIO.name                                                            AS STRATEGY_NAME
                  ,level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- IN (14414,90565)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
      ON          FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
      INNER JOIN  business_events
      ON          business_events.id                            = Trades.type 
      INNER JOIN  titres Instrument
      ON          Instrument.sicovam                            = Trades.sicovam    
      INNER JOIN  riskusers trader
      ON          trader.ident                                  = Trades.operateur
      WHERE       Trades.DATENEG                                > trunc(sysdate) - 5 --recent trades
      AND         Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --Not deleted
      AND         business_events.compta = 1 --trades affecting position
      AND         (Instrument.type = 'S' AND (Instrument.default_event_leg1 =0 OR Instrument.default_event_leg1 is null)) --swaps, not CDS
      AND         Trades.Montant !=0 --trades with cash flow
      AND             
                  (
                  (instrument.devisectt NOT IN (55400526,55001680,55857753,55727426,54739268,54613316,55923524) AND trunc(Trades.DATEVAL) < BTG_BUSINESS_DATE(Trades.DATENEG, +2)) 
                  OR 
                  (instrument.devisectt IN (55400526,55001680,55857753,55727426,54739268,54613316,55923524) AND trunc(Trades.DATEVAL) < BTG_BUSINESS_DATE(Trades.DATENEG, +1))
                  ) --CAD, GBP, MXN, RUB, TRY, AUD, USD all settle T+1
      ORDER BY        1,2 ASC;

/*collects all IRS trades for ARF ARF 2 and GEMM that do not settle cash on T+2*/
 -- *****************************************************************
 -- END  OF: SWAP_SETTLE_DT_WRONG
 -- *****************************************************************    
END SWAP_SETTLE_DT_WRONG;



  -- *****************************************************************
  -- Description: PROCEDURE FXSWAP_SPLIT
	-- get the two trades that compose a full operation of forex.
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2012      Jun Guan     Created.
  --18 Feb 2013 Oliver South	Changed column order PROJ-26
  --08 Jul 2014 Oliver South	Changed the check to look at trades booked in different strategies
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE FXSWAP_SPLIT
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
 -- *****************************************************************
 -- BEGIN  OF: FXSWAP_SPLIT
 -- **************************************************************** 
    OPEN p_CURSOR FOR
    
SELECT        
                  FUND_BOOK_STRATEGY.BOOK_NAME           Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME           Fund_Name
                , TRADE_SWAP.REFCON                      Swap_Leg_1
                , TRADE_SWAP.LINKEDREFCON                Swap_Leg_2
                , SECURITY.LIBELLE                       FX_NAME
                , TRADE.DATENEG                          D$TRADEDATE
                , TRADER.NAME                            Trader
    FROM        HISTOMVTS                                TRADE
    INNER JOIN  FOREX_SWAP                               TRADE_SWAP
    ON          TRADE_SWAP.REFCON  = TRADE.REFCON
    INNER JOIN  TITRES   SECURITY
    ON          SECURITY.SICOVAM   = TRADE.SICOVAM
    INNER JOIN  riskusers trader
    ON          trader.ident       = Trade.operateur
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                      , FOLIO.ident                                                           AS STRATEGY_ID
                      , FOLIO.name                                                            AS STRATEGY_NAME
                      ,level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident  in (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident    = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON        FUND_BOOK_STRATEGY.STRATEGY_ID    = TRADE.OPCVM
    WHERE     TRADE.BACKOFFICE                  NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
    AND       TRADE_SWAP.LINKEDREFCON !=0 --some trades appear in the FOREX_SWAP table but don't have the other leg so this removes them. Likely booked as swap but meant to be outright.
    AND       TRADE.dateneg > TRUNC(SYSDATE)-40 --looks back over the previous month + some days to enable month end problems to be caught
MINUS  --above select is picking up all the first legs and below the second leg. If a different fund/strategy then they will be reported
  SELECT        
                  FUND_BOOK_STRATEGY.BOOK_NAME           Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME           Fund_Name
                , TRADE_SWAP.REFCON                      Swap_Leg_1
                , TRADE_SWAP.LINKEDREFCON                Swap_Leg_2
                , SECURITY.LIBELLE                       FX_NAME
                , TRADE.DATENEG                          D$TRADEDATE
                , TRADER.NAME                            Trader
    FROM        HISTOMVTS                                TRADE
    INNER JOIN  FOREX_SWAP                               TRADE_SWAP
    ON          TRADE_SWAP.LINKEDREFCON  = TRADE.REFCON
    INNER JOIN  TITRES   SECURITY
    ON          SECURITY.SICOVAM   = TRADE.SICOVAM
    INNER JOIN  riskusers trader
    ON          trader.ident       = Trade.operateur
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                      , FOLIO.ident                                                           AS STRATEGY_ID
                      , FOLIO.name                                                            AS STRATEGY_NAME
                      ,level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident  in (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident    = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON        FUND_BOOK_STRATEGY.STRATEGY_ID    = TRADE.OPCVM
    WHERE     TRADE.BACKOFFICE                  NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
    AND       TRADE_SWAP.LINKEDREFCON !=0
    AND       TRADE.dateneg > TRUNC(SYSDATE)-40
	ORDER BY 1,2;
      
  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

 -- *****************************************************************
 -- END  OF: FXSWAP_SPLIT
 -- **************************************************************** 
 
END FXSWAP_SPLIT;


  -- *****************************************************************
  -- Description: PROCEDURE EQ_SHARES_FRACTIONAL_QUANTITY
	-- 
  -- Author:          Jun Guan
  --
  -- Revision History
  -- Date             Author        Reason for Change
  --03 Jul 2013		Oliver South	     Added futures and all strategies.
  --23 Nov 2016    Jeff Yu     Filter out trades older than 1 year from report (PMOG-1058).
  -- ----------------------------------------------------------------
   PROCEDURE EQ_SHARES_FRACTIONAL_QUANTITY
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF EQ_SHARES_FRACTIONAL_QUANTITY 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR
            SELECT 
            FUND_BOOK_STRATEGY.BOOK_NAME                Strategy
          , FUND_BOOK_STRATEGY.Fund_NAME                FUND
          , TRADES.refcon                               TRADE_ID
          , TRADES.sicovam                              SICOVAM
          , TITRES.reference                            REFERENCE
          , TITRES.libelle                              NAME
          , TRADES.dateneg                              d$TRADE_DATE
          , TRADES.DATEVAL                              d$VALUE_DATE
          , TRADES.QUANTITE                             QUANTITY
          , RISKUSERS.name                                  Operator    
          , AFFECTATION.libelle                         Allotment
      FROM histomvts TRADES
  INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                          AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)  AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)   AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)  AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)   AS BOOK_NAME
                    , FOLIO.ident                                                          AS STRATEGY_ID
                    , FOLIO.name                                                           AS STRATEGY_NAME
              ,level
              FROM FOLIO
              WHERE LEVEL >= 4
              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
              --START WITH FOLIO.ident IN (14414)--Primary funds
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
            ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm
    INNER JOIN TITRES
    ON         TITRES.sicovam =   TRADES.sicovam
    AND        TITRES.type IN ('A','G','F') --Share template, CFD, Futures
    AND        TITRES.affectation NOT IN (33, 45) --FRA, External Funds
    INNER JOIN RISKUSERS
    ON        RISKUSERS.ident =  TRADES.operateur   
    INNER JOIN BUSINESS_EVENTS
    ON        BUSINESS_EVENTS.ID = TRADES.TYPE
    AND BUSINESS_EVENTS.COMPTA = 1 --position affecting tickets only
    INNER JOIN AFFECTATION
    ON AFFECTATION.IDENT = TITRES.AFFECTATION
    WHERE     TRADES.DATENEG>=add_months( sysdate, -12 ) --Exclude trades older than 1 year
    AND       TRADES.backoffice NOT IN (11, 13, 180, 182, 186, 190, 192, 220, 246, 248, 250, 252) --ignore cancelled trades
    AND       TRADES.quantite != round(TRADES.quantite) --Quantity is not an integer
    AND       TRADES.courtier NOT IN (10010875, 10010878) --ignore RESET(CFD) and INTERNAL TRANSFER (STRAT)
    ORDER BY 1,2,7;

EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF EQ_SHARES_FRACTIONAL_QUANTITY 
  -- *************************************************************************** 		
 END EQ_SHARES_FRACTIONAL_QUANTITY;




 -- *****************************************************************
 -- Description: PROCEDURE TRADES_DEP_INTERNAL
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013	Oliver South	Changed column order PROJ-26
 --28 Mar 2014	Oliver South	Added NY strategies within this check
 --25 Nov 2016   Jeff Yu    Ignore X-Closed Strats from report
 -- ----------------------------------------------------------------    
  PROCEDURE TRADES_DEP_INTERNAL
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_DEP_INTERNAL 
  -- *************************************************************************** 		
		OPEN p_CURSOR FOR

    SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event        
    FROM          histomvts Trades    
    INNER JOIN    riskusers 
    ON            Trades.operateur     = riskusers.ident    
    INNER JOIN    titres security 
    ON            security.sicovam     = trades.sicovam        
    INNER JOIN    tiers CP
    ON            CP.IDENT             = Trades.depositaire    
    INNER JOIN    business_events 
    ON            business_events.id   = Trades.type    
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  Trades.OPCVM    
    WHERE Trades.BACKOFFICE                   NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND TRADES.depositaire                    IN     
              (
              SELECT int_dep.input_code
              FROM btg_mapping_code int_dep
              WHERE int_dep.type_id = 35 
              )
    AND BOOK_ID                               IN   
              (
              SELECT ldn_folio.input_code
              FROM btg_mapping_code ldn_folio
              WHERE ldn_folio.type_id = 33
              AND   ldn_folio.output_code IN ('LDN','NY')
              )
    AND business_events.compta = 1
    AND FUND_BOOK_STRATEGY.BOOK_NAME NOT IN ('Systematic Rates','X-Closed Strats')
    AND security.type != 'L'
	ORDER BY 1,2;
 
  -- ***************************************************************************
  -- END OF TRADES_DEP_INTERNAL 
  -- *************************************************************************** 		 
	END TRADES_DEP_INTERNAL;



 -- *****************************************************************
 -- Description: PROCEDURE TRADES_DEP_INTERNAL
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 --18 Feb 2013 Oliver South	Changed column order PROJ-26
 -- ----------------------------------------------------------------        
  PROCEDURE INTERNAL_TRADE_NO_TRANSFER
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF INTERNAL_TRADE_NO_TRANSFER 
  -- *************************************************************************** 		 	
		OPEN p_CURSOR FOR

      SELECT 
						  FUND_BOOK_STRATEGY.BOOK_NAME        Strategy_Name
						, FUND_BOOK_STRATEGY.Fund_NAME        Fund_Name
						, Trades.refcon                       TradeId
						, Trades.sicovam                      Sicovam
						, Security.reference                  InstrumentRef
						, Trades.dateneg                      d$TradeDate
						, trunc(Trades.DATEVAL)               d$ValueDate
						, Riskusers.Name                      Trader
						, DEVISE_TO_STR(Trades.devisepay)     Currency
						, CP.NAME                             PrimeBroker
						, business_events.name                Bus_Event    
        FROM        histomvts Trades            
        INNER JOIN  riskusers 
        ON          Trades.operateur = riskusers.ident        
        INNER JOIN  titres security 
        ON          security.sicovam = trades.sicovam      
		AND         security.type != 'L'					--exclude repos      
        INNER JOIN  tiers CP
        ON          CP.IDENT = Trades.contrepartie        
        INNER JOIN  business_events 
        ON          business_events.id = Trades.type        
        INNER JOIN ( 
                      SELECT       CONNECT_BY_ROOT(FOLIO.ident)                                            AS TOP_FUND_ID
                                  , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                                  , FOLIO.ident                                                            AS STRATEGY_ID
                                  , FOLIO.name                                                             AS STRATEGY_NAME
                                  , level
                      FROM FOLIO
                      WHERE LEVEL                       >= 4
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                      CONNECT BY PRIOR  FOLIO.ident     = FOLIO.mgr  
                  )  FUND_BOOK_STRATEGY
    ON               FUND_BOOK_STRATEGY.STRATEGY_ID     = Trades.OPCVM
    WHERE            trades.dateneg                     >  sysdate - 5 --recent trades
    AND              Trades.BACKOFFICE                 NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND              business_events.id                NOT IN ('161', '6','274','2','187') --Transfer, FX, CFD - Financing Closeout, Coupon, Swap Rest
	AND		         security.type					   NOT IN ('X','E','C') --Not FX or Commission
    AND TRADES.contrepartie IN
                                (10010898    --PB TRANSFER WELLS - GEMM
                                ,10010899    --PB TRANSFER WELLS - DMF
                                ,10011155    --PB TRANSFER UBS-ML
                                ,10010769    --PB TRANSFER UBS
                                ,10010768    --PB TRANSFER MS
                                ,10010876    --INTERNAL TRANSFER (INT)
                                ,10010875    --INTERNAL TRANSFER (STRAT)
                                ,10010767    --PB TRNSFR UBS
                                ,10010766)	 --PB TRNSFR MS
	ORDER BY 1,2;  
    

  -- ***************************************************************************
  -- END OF INTERNAL_TRADE_NO_TRANSFER 
  -- *************************************************************************** 	
	END INTERNAL_TRADE_NO_TRANSFER;



  -- *****************************************************************
 -- Description: PROCEDURE TRADES_INTERNAL_NOT_NET_ZERO
 -- Author:          Jun Guan
 --
 -- Revision History
 -- Date             Author        Reason for Change
 -- 02 FEB 2018    Jeff Yu   PMOG-1194 Limit to only show trades for past 5 business days
 -- ----------------------------------------------------------------  
   PROCEDURE TRADES_INTERNAL_NOT_NET_ZERO
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF TRADES_INTERNAL_NOT_NET_ZERO 
  -- ***************************************************************************			
      OPEN p_CURSOR FOR
      SELECT          
                      Trades.sicovam                                  Sicovam
                      ,FUND_BOOK_STRATEGY.Fund_NAME                   Fund_name
                      ,Instrument.libelle                             Name
                      ,Instrument.reference                           Ticker
                      ,trunc(Trades.DATENEG)                          d$Trade_Date
                      ,trunc(Trades.DATEVAL)                          d$Value_Date
                      ,round(sum(Trades.QUANTITE*Instrument.nominal),6)      Quantity
                      ,sum(Trades.montant)                            n$Net_Amount
      FROM            histomvts Trades 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam 
      INNER JOIN ( 
                  SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                          AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                          , FOLIO.ident                                                           AS STRATEGY_ID
                          , FOLIO.name                                                            AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 3
                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                )     FUND_BOOK_STRATEGY
      ON              FUND_BOOK_STRATEGY.STRATEGY_ID     =   Trades.OPCVM
      INNER JOIN      riskusers trader
      ON              trader.ident                       =   Trades.operateur
      WHERE           Trades.DATENEG      >=   BTG_BUSINESS_DATE(SYSDATE,-5)
      AND             Instrument.type                    != 'L' --not repos
      AND             trades.contrepartie                IN (10010875, 10010876) --Internal transfer
      AND             Trades.BACKOFFICE                 NOT IN (192,11,13,17,26,27,220,248,252) -- checked mo canceled
      GROUP BY 
                      Trades.sicovam, 
                      FUND_BOOK_STRATEGY.Fund_NAME, 
                      Instrument.libelle, 
                      Instrument.reference, 
                      trunc(Trades.DATENEG), 
                      trunc(Trades.DATEVAL)   
      HAVING 
      abs(sum(Trades.QUANTITE*Instrument.nominal)) > 0.01 
      OR abs(SUM(Trades.montant)) > 0.5
      ORDER by        5,1,2 ASC;

  -- ***************************************************************************
  -- END OF TRADES_INTERNAL_NOT_NET_ZERO 
  -- ***************************************************************************	
	END TRADES_INTERNAL_NOT_NET_ZERO;



 -- *****************************************************************
  -- Description  PROCEDURE CLEARED_WRONG_BUSINESS_EVENT
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
  PROCEDURE CLEARED_WRONG_BUSINESS_EVENT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CLEARED_WRONG_BUSINESS_EVENT
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
    SELECT                  Trades.refcon                   Trade_ID
                          , be.name                         Business_Event
                          , FUND_BOOK_STRATEGY.BOOK_NAME    Top_Level_Strategy
                          , folio.name                      Folio_Name
                          , FUND_BOOK_STRATEGY.FUND_NAME    Fund
                          , PrimeBroker.NAME                Depositary
                          , Trades.sicovam                  SICOVAM
                          , Instrument.reference            REFERENCE
                          , trader.name                     Trader
                          , Trades.quantite                 Quantity
                          , Trades.dateneg                  d$Trade_Date
                          , Trades.dateval                  d$Value_Date


      from                histomvts Trades
      INNER JOIN          tiers PrimeBroker
      ON                  PrimeBroker.IDENT   =  Trades.DEPOSITAIRE
      INNER JOIN          titres Instrument
      ON                  Instrument.sicovam  =  Trades.sicovam
      INNER JOIN          riskusers trader
      ON                  trader.ident        =  Trades.operateur
      INNER JOIN          folio
      ON                  folio.ident         =  Trades.opcvm
      INNER JOIN          business_events BE
      ON                  BE.id = Trades.TYPE and BE.COMPTA=1
      INNER JOIN          tiersproperties tp
      ON                  Trades.depositaire = tp.code
      INNER JOIN         ( 
                                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                 AS TOP_FUND_ID
                                            , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME 
                                            , FOLIO.ident                                                         AS STRATEGY_ID 
                                            , FOLIO.name                                                          AS STRATEGY_NAME
                                            FROM FOLIO
                                            WHERE LEVEL                    > 2
                                                START WITH FOLIO.ident      IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                                               CONNECT BY PRIOR FOLIO.ident          = FOLIO.mgr                                 
                           )        FUND_BOOK_STRATEGY
      ON FUND_BOOK_STRATEGY.STRATEGY_ID  = Trades.opcvm
      WHERE
                            Trades.backoffice not in (192,11,13,17,26,27,220,248,252) and
                            be.id not in (161,360)  and --Not transfer trades nor expires
                            Trades.TYPE not in (1,140,1494) and
                            tp.name = 'MarkIT CH CODE' and
                            tp.value is not null
       ORDER BY 5,4,11;                    
  
  
	-- ***************************************************************************
  -- END OF CLEARED_WRONG_BUSINESS_EVENT 
  -- ***************************************************************************	
  END CLEARED_WRONG_BUSINESS_EVENT;



  -- *****************************************************************
  -- Description  PROCEDURE TRADES_BOOKED_IN_THE_FUTURE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
 PROCEDURE TRADES_BOOKED_IN_THE_FUTURE
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADES_BOOKED_IN_THE_FUTURE
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
    SELECT
								  FUND_BOOK_STRATEGY.BOOK_NAME                     Strategy_Name
                , FUND_BOOK_STRATEGY.Fund_NAME                     Fund
								, Trades.sicovam                                   Sicovam
                , ta_block_to_generated.block_id                   Block_ID
								, Trades.refcon                                    Trade_ID
                , trader.name                                      Trader
								, Instrument.libelle                               Instrument_Name
                , Instrument.reference                             Ticker
								, trunc(Trades.DATENEG)                            d$Trade_Date
      FROM                   histomvts Trades       
      INNER JOIN             titres Instrument 
      ON                     Instrument.sicovam                 =  Trades.sicovam
      INNER JOIN  business_events
      ON          business_events.id                            =  Trades.type 
      INNER JOIN ( 
                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                    , FOLIO.ident                                                           AS STRATEGY_ID
                                    , FOLIO.name                                                            AS STRATEGY_NAME
                                    , level
                              FROM FOLIO
                              WHERE 
                              LEVEL >= 4
                              START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                              CONNECT BY PRIOR FOLIO.ident       =  FOLIO.mgr  
                            ) FUND_BOOK_STRATEGY
      ON                    FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
      LEFT JOIN             riskusers trader
      ON                    trader.ident                         =  Trades.operateur
      LEFT JOIN             ta_block_to_generated
      ON                    ta_block_to_generated.generated_id   =  Trades.refcon
      WHERE          
          Trades.BACKOFFICE                                           NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
          AND               trades.dateneg                       >  trunc(sysdate)                        
          AND               business_events.compta               =  1 --trades affecting position
          AND               Instrument.type                     != 'L' 
      ORDER BY        2 ASC;
    
  -- ***************************************************************************
  -- END OF TRADES_BOOKED_IN_THE_FUTURE
  -- ***************************************************************************	
  END TRADES_BOOKED_IN_THE_FUTURE;



  PROCEDURE CFD_WRONG_ACCOUNT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- ***************************************************************************
  -- BEGIN OF CFD_WRONG_ACCOUNT
  -- ***************************************************************************   
     OPEN p_CURSOR FOR

    SELECT              
                     FUND_BOOK_STRATEGY.BOOK_NAME                   Strategy_Name 
                   , FUND_BOOK_STRATEGY.Fund_NAME                   Fund_Name
                   , Trades.sicovam                                 Sicovam
                   , Trades.refcon                                  Trade_Id
                   , trader.name                                    Trader
                   , Instrument.libelle                             Instrument_Name
                   , Instrument.reference                           Instrument_Reference
                   , trunc(Trades.DATENEG)                          d$Trade_Date
                   , trunc(Trades.DATEVAL)                          d$Value_Date
                   , devise_to_str(Trades.devisepay)                Currency
                   , depositary.name                                Depositary
                   , business_events.name                           BusinesEvent
    FROM                            
                    histomvts                        Trades 
    INNER JOIN      business_events
    ON              business_events.id              = Trades.type
    INNER JOIN      riskusers trader
    ON              trader.ident                    = Trades.operateur
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam              = Trades.sicovam 
    INNER JOIN      tiers depositary
    ON              depositary.ident = trades.depositaire
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405)--Primary funds and Secondary Funds
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  Trades.OPCVM
    WHERE     Instrument.affectation = 12 --CFD
    AND       Trades.dateneg > '01-Jul-2013' --start date for report
    AND       depositary.name not like '%CFD%' --depostiary name must contain this text string
    AND       Trades.backoffice  NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
	;

	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
  -- ***************************************************************************
  -- END OF CFD_WRONG_ACCOUNT 
  -- ***************************************************************************         
	END CFD_WRONG_ACCOUNT;


-- *****************************************************************
-- Description:     PROCEDURE  DIVIDEND_WITH_FEES
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 05 Jun 2014      Jun Guan            Created.
-- ***************************************************************** 
PROCEDURE DIVIDEND_WITH_FEES (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: DIVIDEND_WITH_FEES
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

select 
riskusers.name trader, 
FUND_BOOK_STRATEGY.Fund_NAME Fund, 
FUND_BOOK_STRATEGY.book_name Strategy, 
FUND_BOOK_STRATEGY.strategy_NAME Folio, 
histomvts.refcon TradeID, 
histomvts.dateneg Trade_Date, 
histomvts.dateval Settlement_Date, 
titres.reference instrument_reference, 
titres.libelle instrument_name, 
histomvts.fraismarche Market_Fee, 
histomvts.fraiscounterparty Counterparty_Fee, 
histomvts.fraiscourtage Broker_Fee, 
histomvts.quantite QTY, 
histomvts.cours price, 
histomvts.montant Net_Amount, 
business_events.name business_event 
 
 
 
 
from histomvts 
 
INNER JOIN 
        ( SELECT 
                CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID , 
                CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID , 
                REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME , 
                FOLIO.ident AS STRATEGY_ID , 
                FOLIO.name AS STRATEGY_NAME , 
                level 
             FROM FOLIO 
             WHERE LEVEL >= 4 
             START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) 
          CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
        ) FUND_BOOK_STRATEGY 
        ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM 
 
left join business_events 
on business_events.id=histomvts.type 
 
left join riskusers 
on riskusers.ident=histomvts.operateur 
 
left join titres 
on titres.sicovam=histomvts.sicovam 
 
where 
histomvts.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
and histomvts.type=147 
and (histomvts.fraiscounterparty !=0 or histomvts.fraiscourtage !=0 or histomvts.fraismarche !=0)
;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
		
END

DIVIDEND_WITH_FEES;

-- *****************************************************************
-- END OF: DIVIDEND_WITH_FEES
-- *****************************************************************


  
   -- *****************************************************************
  -- Description  PROCEDURE CLEARED_2DIFFERENT_CHS
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- 24-OCT-2014  Gustavo Binnie	 PMOG-621 - Changes to show only recent trades or open positions
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE CLEARED_2DIFFERENT_CHS
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF CLEARED_2DIFFERENT_CHS
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
SELECT                        h1.refcon                     Trade_ID
                            , be1.name                      Business_Event
                            , FUND_BOOK_STRATEGY.BOOK_NAME  Top_Level_Strategy
                            , folio.name                    Folio_Name
                            , FUND_BOOK_STRATEGY.FUND_NAME  Fund
                            , PrimeBroker.NAME              Depositary
                            , h1.sicovam                    SICOVAM
                            , Instrument.reference          REFERENCE
                            , trader.name                   Trader
                            , h1.quantite                   Quantity                            
                            , h1.dateneg                    d$Trade_Date
                            , h1.dateval                    d$Value_Date
                            
            FROM            histomvts h1
            INNER JOIN      tiers PrimeBroker
            ON              PrimeBroker.IDENT = h1.DEPOSITAIRE
            INNER JOIN      titres Instrument
            ON              Instrument.sicovam = h1.sicovam
            INNER JOIN      riskusers trader
            ON              trader.ident = h1.operateur
            INNER JOIN      business_events BE1
            ON              BE1.id = h1.TYPE
            and             be1.compta = 1
            INNER JOIN      folio
            ON              folio.ident =h1.opcvm
            INNER JOIN         ( 
                                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                 AS TOP_FUND_ID
                                            , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME 
                                            , FOLIO.ident                                                         AS STRATEGY_ID 
                                            , FOLIO.name                                                          AS STRATEGY_NAME
                                            FROM FOLIO
                                            WHERE LEVEL                    > 2
                                                START WITH FOLIO.ident     IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                                               CONNECT BY PRIOR FOLIO.ident          = FOLIO.mgr                                 
                                )        FUND_BOOK_STRATEGY
            ON FUND_BOOK_STRATEGY.STRATEGY_ID  = h1.opcvm
            inner join (                                
                                                           SELECT SICOVAM, OPCVM 
                           FROM
                           (
                           SELECT H2.sicovam, H2.opcvm 
                                FROM histomvts h2
                                JOIN titres
                                ON h2.sicovam = titres.sicovam
                                INNER JOIN business_events BE
                                ON         BE.id                             = H2.type
                                AND        be.compta                         = 1
                                INNER JOIN tiersproperties tp
                                ON         h2.depositaire                    = tp.code
                                AND        tp.name                           = 'MarkIT CH CODE'
                                WHERE     
                                    tp.value is not null
                                    AND h2.backoffice NOT  IN (192,11,13,17,26,27,220,248,252)                                   
                                GROUP BY 
                                   h2.opcvm, h2.sicovam, h2.depositaire
                                HAVING 
                                  ( sum(H2.QUANTITE) <> 0 OR MAX(H2.DATENEG) >= BTG_BUSINESS_DATE(SYSDATE,-5))
                                  ) POSITIONS_0
                                GROUP BY SICOVAM, OPCVM
                                HAVING COUNT(SICOVAM || OPCVM) > 1
                              ) Positions
                      on Positions.opcvm    = h1.opcvm
                      and Positions.sicovam = h1.sicovam                                    
			WHERE
            h1.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Not cancelled trades                
            order by 5,4,11;
 
 	-- ***************************************************************************
  -- END OF CLEARED_2DIFFERENT_CHS
  -- ***************************************************************************	
  END CLEARED_2DIFFERENT_CHS;

     -- *****************************************************************
  -- Description  PROCEDURE TRADES_OFFBOARDED_CPTIES
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 05-MAY-2016      Gustavo Binnie    Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *********************************************************
  PROCEDURE TRADES_OFFBOARDED_CPTIES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
	-- ***************************************************************************
  -- BEGIN OF TRADES_OFFBOARDED_CPTIES
  -- ***************************************************************************		
		OPEN p_CURSOR FOR
  
SELECT  Fund_NAME                             Fund,
        BOOK_NAME                             Strategy,
        TRADES.refcon                         Trade_ID,
        Instrument.sicovam                    sicovam,
        Instrument.reference                  Instrument_Name,
        CPTY.NAME                             Counterparty,
        BRKR.NAME                             Broker,
        CPTY2.NAME                            Counterparty2,
        TRADES.dateneg                        d$Trade_Date,        
        TRADES.dateval                        d$Value_Date,
        to_char(audit_mvt.datemodif,'DD-MON-YYYY HH:MM:SS')                   Insertion_Date,
        booked.name                           Booked_By,
        trader.name                           Operator,
        business_events.NAME                  Busines_Event,
        TRADES.cours                          Price,
        TRADES.quantite                       QTY,
        TRADES.montant                        Net_Amount



FROM HISTOMVTS TRADES


INNER JOIN audit_mvt
on audit_mvt.refcon = TRADES.REFCON
and audit_mvt.version = 1 
and audit_mvt.datemodif >= trunc(sysdate-14)

INNER JOIN      riskusers booked
ON              booked.ident = audit_mvt.USERID

INNER JOIN      riskusers trader
ON              trader.ident = TRADES.OPERATEUR

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) -- 
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM

    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam    

    INNER JOIN AFFECTATION
    ON AFFECTATION.ident = Instrument.affectation

    INNER JOIN     business_events
    ON             business_events.id = Trades.type
    
    INNER JOIN    TIERS CPTY
    ON CPTY.IDENT = TRADES.CONTREPARTIE
    
    LEFT JOIN    TIERS CPTY2
    ON CPTY2.IDENT = TRADES.CONTREPARTIE2
    
    INNER JOIN    TIERS BRKR
    ON BRKR.IDENT = TRADES.COURTIER
    
WHERE 
TRADES.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252)
AND (CPTY.MGR = 10025747 OR CPTY2.MGR=10025747 OR BRKR.MGR =10025747 )
    
ORDER BY 1,2,3 ;

 	-- ***************************************************************************
  -- END OF TRADES_OFFBOARDED_CPTIES
  -- ***************************************************************************	
  END TRADES_OFFBOARDED_CPTIES;
  
END PCKG_BTG_EMAILER_NON_CRITICAL;