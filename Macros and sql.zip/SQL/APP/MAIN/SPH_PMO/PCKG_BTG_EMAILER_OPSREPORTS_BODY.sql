create or replace
PACKAGE BODY            "PCKG_BTG_EMAILER_OPSREPORTS" 
AS


-- *****************************************************************
-- Description: PROCEDURE VOL_VAR_NUM_OF_EXPIRIES
--
-- Author:      Matt Kelly
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 16/03/2015   Matt Kelly			Created.
-- 23/03/2018   Jeff Yu      Modified (PMOG-1215) --Add new allotments that derived from vol/var/corr swaps
-- *****************************************************************
PROCEDURE VOL_VAR_NUM_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR


--Volatility and variance swaps - number of expiries in next year
SELECT 	t.datefinal                  "Expiry Date"
        ,count(t.sicovam)            "Number of expiries"
        
FROM titres t

LEFT JOIN affectation a
  ON t.affectation = a.ident

WHERE t.affectation IN (16,1080, 1101,1802,1807,1808,1809,1810,1852,1811,1812) --VarSwp, VolSwps and Correlation Swap
AND t.datefinal > sysdate --expire after today
AND t.datefinal <= (sysdate + 365) --expire before a year from now
AND t.sicovam in (
                    select sicovam
                    from histomvts h
                    INNER JOIN (
                                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (
                                                      14414   --PCKG_BTG.FOLIO_PRIMARY_FUNDS
                                                      ,90565  --PCKG_BTG.FOLIO_UCITS_FUND
                                                    )
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                ) FUND_BOOK_STRATEGY
                      ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.opcvm --used to filter out parent trades
                    INNER JOIN BUSINESS_EVENTS
                      ON BUSINESS_EVENTS.id = h.type
                        AND BUSINESS_EVENTS.compta = 1                    
                    WHERE h.backoffice NOT IN (192,11,13,17,26,27,220,248,252)                     
                    GROUP BY sicovam
                    having sum(h.quantite) <> 0 --instrument with open positions
                  )
GROUP BY t.datefinal 

ORDER BY t.datefinal
;

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END VOL_VAR_NUM_OF_EXPIRIES;
-- *****************************************************************
-- END OF: VOL_VAR_NUM_OF_EXPIRIES
-- *****************************************************************




-- *****************************************************************
-- Description: PROCEDURE VOL_VAR_LIST_OF_EXPIRIES
--
-- Author:      Matt Kelly
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 16/03/2015   Matt Kelly			Created.
-- 23/03/2018   Jeff Yu      Modified (PMOG-1215) --Add new allotments that derived from vol/var/corr swaps
-- *****************************************************************
PROCEDURE VOL_VAR_LIST_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR


--Volatility and variance swaps - list of expiries in next year
SELECT 	t.sicovam                     "Sicovam"
        ,t.libelle                    "Instrument Name"
        ,t.reference                  "Instrument Reference"
        ,a.libelle                    "Swap Type"
        ,devise_to_str(t.devisectt)   "Currency"
        ,t.datefinal                  "Expiry Date"

FROM titres t

LEFT JOIN affectation a
  ON t.affectation = a.ident

WHERE t.affectation IN (16,1080, 1101,1802,1807,1808,1809,1810,1852,1811,1812)  --VarSwp, VolSwps and Correlation Swap
AND t.datefinal > sysdate --expire after today
AND t.datefinal <= (sysdate + 365) --expire before a year from now
AND t.sicovam in (
                    select sicovam
                    from histomvts h
                    INNER JOIN (
                                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (
                                                      14414   --PCKG_BTG.FOLIO_PRIMARY_FUNDS
                                                      ,90565  --PCKG_BTG.FOLIO_UCITS_FUND
                                                    )
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                ) FUND_BOOK_STRATEGY
                      ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.opcvm --used to filter out parent trades
                    INNER JOIN BUSINESS_EVENTS
                      ON BUSINESS_EVENTS.id = h.type
                        AND BUSINESS_EVENTS.compta = 1                    
                    WHERE h.backoffice NOT IN (192,11,13,17,26,27,220,248,252)                     
                    GROUP BY sicovam
                    having sum(h.quantite) <> 0 --instrument with open positions
                  )

ORDER BY t.datefinal, t.libelle
;

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END VOL_VAR_LIST_OF_EXPIRIES;
-- *****************************************************************
-- END OF: VOL_VAR_LIST_OF_EXPIRIES
-- *****************************************************************


  
  PROCEDURE NY_MO_BLOTTER2
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

SELECT 	fund.NAME Fund
		,FUND_BOOK_STRATEGY.BOOK_NAME Fund_Strategy
		,FUND_BOOK_STRATEGY.STRATEGY_NAME Strategy
		,trader.NAME Trader
		,Trades.sicovam Sicovam
		,Trades.refcon TradeID
		,Instrument.reference Ticker
		,trunc(Trades.DATENEG) TradeDate
		,trunc(Trades.DATEVAL) ValueDate
FROM 	titres
		,histomvts Trades
		
INNER JOIN business_events 
ON business_events.id = Trades.type

INNER JOIN devisev2 Currency 
ON Currency.code = Trades.devisepay

INNER JOIN titres Instrument 
ON Instrument.sicovam = Trades.sicovam

INNER JOIN tiers PrimeBroker 
ON PrimeBroker.IDENT = Trades.DEPOSITAIRE

INNER JOIN (
			SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
			FROM FOLIO
			WHERE LEVEL >= 4 START
			WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
			) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.OPCVM
	
INNER JOIN tiers fund 
ON fund.ident = Trades.entite

INNER JOIN riskusers trader 
ON trader.ident = Trades.operateur

WHERE Trades.BACKOFFICE IN (8,10,11,19,21,186,190,248,250) -- on MO blotter
AND titres.sicovam = trades.sicovam
AND trunc(Trades.dateneg) <= trunc(sysdate - 1)
AND trades.operateur IN (3827,3307,2487,2387,3047,2607,2307,2587,1774,2488,3227,3448,3727,1776,1777,2567,2707,2928,2167,1775,3447,2007,1889,4227,7863)

ORDER BY 1,8 ASC;


/* Reports all trades not MO confirmed for NY users */

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END NY_MO_BLOTTER2;


    PROCEDURE LONDON_UST_SETT_TODAY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR
     
SELECT      FUND_BOOK_STRATEGY.Fund_NAME                                              Fund
          , FUND_BOOK_STRATEGY.BOOK_NAME                                              Strategy
          , HISTOMVTS.dateneg                                                         d$Trade_Date
          , HISTOMVTS.dateval                                                         d$Value_Date
          , TITRES.libelle                                                            Name
          , TITRES.reference                                                          ISIN
          , CASE
                WHEN SIGN(HISTOMVTS.quantite*TITRES.nominal) = 1  THEN 'BTG BUY'
                WHEN SIGN(HISTOMVTS.quantite*TITRES.nominal) = -1 THEN 'BTG SELL'
                ELSE 'FLAT' 
            END                                                                       Direction
          , HISTOMVTS.quantite*TITRES.nominal                                         n$Quantity
          , HISTOMVTS.cours                                                           Price
          , HISTOMVTS.montant                                                         n$Net_Amount
          , devise_to_str(HISTOMVTS.devisepay)                                        Currency
          , TIERS.name                                                                Counterparty
          , HISTOMVTS.refcon                                                          n$BTG_Trade_ID
          , TA_BLOCK_TO_GENERATED.BLOCK_ID                                            n$BTG_Block_ID
FROM        HISTOMVTS
INNER JOIN  TIERS
ON          TIERS.ident                        = HISTOMVTS.contrepartie
INNER JOIN  TITRES
ON          TITRES.sicovam                          = histomvts.sicovam
AND         TITRES.affectation                      IN ('25','1251') --Gov Bonds and Agency Bonds
AND         TITRES.type                             = 'O' --Bonds
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.ID                        = HISTOMVTS.TYPE
AND         BUSINESS_EVENTS.COMPTA                    = 1 --Position affecting trades only
INNER JOIN  SECTOR_INSTRUMENT_ASSOCIATION
ON          SECTOR_INSTRUMENT_ASSOCIATION.sicovam     = TITRES.sicovam 
AND         SECTOR_INSTRUMENT_ASSOCIATION.sector      = 6290   --CNTRY_OF_DOMICILE = US
LEFT JOIN   TA_BLOCK_TO_GENERATED
ON          TA_BLOCK_TO_GENERATED.GENERATED_ID = HISTOMVTS.REFCON
INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID          = histomvts.OPCVM
INNER JOIN BTG_MAPPING_CODE
ON BTG_MAPPING_CODE.INPUT_CODE = FUND_BOOK_STRATEGY.BOOK_ID
AND BTG_MAPPING_CODE.TYPE_ID = 33
AND BTG_MAPPING_CODE.OUTPUT_CODE = 'LDN' --London strageies only
WHERE HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
AND HISTOMVTS.dateval = TRUNC(sysdate) --Todays trades only
order by 14,1;

/* London traded UST settling today*/

END LONDON_UST_SETT_TODAY;

PROCEDURE INSTRUMENT_CHANGE_MTM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select titres.sicovam,
        titres.libelle      reference,
        num_to_date(trunc(infos_histo_KEYS.modifydate))  Modifydate,
        max(amrecon_vacations.sending_date) Last_time_sent 

from titres 

INNER JOIN (
  SELECT infos_histo.sicovam AS sicovam
  , MAX(infos_histo.date_validite) AS modifydate
  , infos_histo.type_table as typetable
  FROM infos_histo
  where infos_histo.modif !=1 and infos_histo.type_table=3
  group by infos_histo.sicovam,infos_histo.type_table
) infos_histo_KEYS
ON infos_histo_KEYS.sicovam = titres.sicovam

INNER JOIN 
histomvts Trades
on Trades.sicovam=titres.sicovam

INNER JOIN amrecon_vacations
on amrecon_vacations.refcon = Trades.refcon 
and esid=1487 and sent not in (0)

where  trunc(num_to_date(trunc(infos_histo_KEYS.modifydate)))>trunc(sysdate-1)
and    titres.type in ('S','W','F','D')
and    titres.affectation in (3,
24,
31,
48,
33,
1000)
and    exists (select 1 from amrecon_vacations where refcon = Trades.refcon and esid=1487 and sent=1)

Group by titres.sicovam,titres.libelle,num_to_date(trunc(infos_histo_KEYS.modifydate));
END INSTRUMENT_CHANGE_MTM;

    PROCEDURE NEW_2LEVEL_EQ_STRAT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR


select 
name new_folio_name,
(select name from folio where ident in secondlevel.mgr) Top_Strategy_Name
from folio secondlevel where secondlevel.mgr in (63040, 63034, 63041, 63039, 62389)
and secondlevel.name not in (
'CM Consumer',
'DW',
'CT',
'Special Sits',
'Share Class',
'Merger Arb',
'Financing',
'Closed Positions FX Hedge',
'Scraps',
'Options',
'Dir',
'Exotics',
'Variance Swaps',
'Disp Vol Swaps',
'BT',
'Asia',
'Europe',
'US',
'Financing',
'Trading',
'FX',
'Macro'
)
;

END NEW_2LEVEL_EQ_STRAT;

 PROCEDURE TURKEY_BOND_TRADES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT
              FUND_BOOK_STRATEGY.TOP_FUND_NAME  Fund
            , FUND_BOOK_STRATEGY.BOOK_NAME      Strategy
            , HISTOMVTS.sicovam                 Sicovam
            , HISTOMVTS.refcon                  Trade_ID
            , TITRES.reference                  ISIN
            , TITRES.libelle                    Bond_Name
            , TRUNC(HISTOMVTS.DATENEG)          d$Trade_Date
            , TRUNC(HISTOMVTS.DATEVAL)          d$Value_Date
            , BROKER.name                       Broker_Name                    
            , DEPOSITARY.name                   Depositary
FROM        HISTOMVTS 
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam 
AND         TITRES.type='O' --show bonds
AND         TITRES.affectation !=1102 --excludes TRS(Fully Funded)
AND         TITRES.reference like 'TR%' --ISIN starts with TR
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position affecting tickets only
INNER JOIN  TIERS DEPOSITARY
ON          DEPOSITARY.ident = HISTOMVTS.DEPOSITAIRE
INNER JOIN  TIERS BROKER     
ON          BROKER.ident = HISTOMVTS.courtier
INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
WHERE       TRUNC(HISTOMVTS.DATEVAL)>=TRUNC(SYSDATE) --Trades settling today or later
AND         TRUNC(HISTOMVTS.DATEVAL)<=TRUNC(BTG_BUSINESS_DATE(SYSDATE,2)) --and trades settling in the next 2 business days
ORDER BY 3,8 ASC;


END TURKEY_BOND_TRADES;


 PROCEDURE JPM_GDS_STATIC_CHANGE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

        select titres.sicovam,titres.libelle reference ,trades.refcon TradeID
from titres 

INNER JOIN (
  SELECT infos_histo.sicovam AS sicovam
  , MAX(infos_histo.date_validite) AS modifydate
  , infos_histo.type_table as typetable
  FROM infos_histo
  where infos_histo.modif !=1 and infos_histo.type_table=3
  group by infos_histo.sicovam, infos_histo.type_table
) infos_histo_KEYS
ON infos_histo_KEYS.sicovam = titres.sicovam

INNER JOIN 
histomvts Trades
on Trades.sicovam=titres.sicovam

where  trunc(num_to_date(trunc(infos_histo_KEYS.modifydate)))=trunc(sysdate-1)
and    titres.type in ('S','W','F','D','O')
and trades.type in (1,140,1444,1494)
and trades.entite=10010602
and    exists (select 1 from amrecon_vacations where refcon = Trades.refcon and esid=1712 and sent=1);


END JPM_GDS_STATIC_CHANGE;

 PROCEDURE UNALLOCATED_TRADE_T_1
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

      select      trader.name                	Trader
,           fund_strategy.name      Strategy
,           histomvts.dateneg       d$TradeDate
,           security.libelle        Name
,           security.reference      ISIN
,           histomvts.refcon        n$BTGTradeID
  
from        histomvts
  
inner join  (select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       > 1
              start with  ident       = 14046 -- Trades Import
              connect by  mgr         = prior ident
            ) strategy
on          strategy.ident            = histomvts.opcvm

inner join  folio fund_strategy
on          fund_strategy.ident       = strategy.parent_ident

inner join  titres security
on          security.sicovam          = histomvts.sicovam

inner join      riskusers trader
on              trader.ident              = histomvts.operateur

where histomvts.backoffice in (260,8,19) --Unallocated, Checked FM and Modifed FM/Pending MO
and histomvts.dateneg < trunc(sysdate)
;


END UNALLOCATED_TRADE_T_1;


-- *****************************************************************
	-- Description:     PROCEDURE  UNALLOCATED_TRADE_T_1_NY
	-- Check to see unallocated transaction on T-1 basis for NY execution book.           
	--
	-- Author:          Jun Guan
	--
	-- Revision History
	-- Date             Author        Reason for Change
	-- ----------------------------------------------------------------
	-- 31 JAN 2017    Jeff Yu              Modified ARF ident per PMGMPMO-211 request.
	-- *****************************************************************

PROCEDURE UNALLOCATED_TRADE_T_1_NY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

   select      fund.name               Fund
,           trader.name                	Trader
,           fund_strategy.name      Strategy
,           histomvts.dateneg       d$TradeDate
,           security.libelle        Name
,           security.reference      ISIN
,           histomvts.refcon        n$BTGTradeID
  
from        histomvts
  
inner join  (select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       > 1
              start with  ident       in  (select INPUT_CODE from BTG_MAPPING_CODE WHERE TYPE_ID=70 and OUTPUT_CODE='NY') -- All NY Execution Books
              connect by  mgr         = prior ident
            union            
              select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       > 1 
              start with  ident       in ('129643', '69042','69093','69064') -- ARF, ARF2, FOCUS, GEMM #ECN Trades
              connect by  mgr         = prior ident
            union
              select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       = 1 
              start with  ident       in ('129656','69049','69097','69065') -- ARF, ARF2, FOCUS, GEMM #Voice Trades
              connect by  mgr         = prior ident
            ) strategy
on          strategy.ident            = histomvts.opcvm

inner join  folio fund_strategy
on          fund_strategy.ident       = strategy.parent_ident

inner join  titres security
on          security.sicovam          = histomvts.sicovam

inner join      riskusers trader
on              trader.ident              = histomvts.operateur

inner join  tiers fund 
on fund.ident = histomvts.entite

where histomvts.backoffice in (260) 
and histomvts.dateneg = trunc(sysdate)-1

;

END UNALLOCATED_TRADE_T_1_NY;


-- *****************************************************************
	-- Description:     PROCEDURE  UNALLOCATED_TRADE_T_NY
	-- Check to see unallocated transaction on T basis for NY execution book.           
	--
	-- Author:          Jun Guan
	--
	-- Revision History
	-- Date             Author        Reason for Change
	-- ----------------------------------------------------------------
	-- 31 JAN 2017    Jeff Yu              Modified ARF ident per PMGMPMO-211 request.
	-- *****************************************************************

PROCEDURE UNALLOCATED_TRADE_T_NY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

 select      fund.name               Fund
,           trader.name                	Trader
,           fund_strategy.name      Strategy
,           histomvts.dateneg       d$TradeDate
,           security.libelle        Name
,           security.reference      ISIN
,           histomvts.refcon        n$BTGTradeID
  
from        histomvts
  
inner join  (select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       > 1
              start with  ident       in  (select INPUT_CODE from BTG_MAPPING_CODE WHERE TYPE_ID=70 and OUTPUT_CODE='NY') -- All NY Execution Books
              connect by  mgr         = prior ident            
            union
              select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       > 1 
              start with  ident       in ('129643', '69042','69093','69064') -- ARF, ARF2, FOCUS, GEMM #ECN Trades
              connect by  mgr         = prior ident
            union
              select      folio.ident
              ,           folio.name
              ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
              from        folio
              where       level       = 1 
              start with  ident       in ('129656','69049','69097','69065') -- ARF, ARF2, FOCUS, GEMM #Voice Trades
              connect by  mgr         = prior ident
            ) strategy
on          strategy.ident            = histomvts.opcvm

inner join  folio fund_strategy
on          fund_strategy.ident       = strategy.parent_ident

inner join  titres security
on          security.sicovam          = histomvts.sicovam

inner join      riskusers trader
on              trader.ident              = histomvts.operateur

inner join  tiers fund 
on fund.ident = histomvts.entite

where histomvts.backoffice in (260) 
and histomvts.dateneg = trunc(sysdate)

;

END UNALLOCATED_TRADE_T_NY;



 PROCEDURE UNSETTLED_BOND_GLEM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

          select
histomvts.refcon as "Client Trade ID",
to_char(histomvts.dateneg,'DD-MON-YYYY') as "Trade Date",
to_char(histomvts.dateval,'DD-MON-YYYY') as "Settle Date",
histomvts.dateval-histomvts.dateneg as "No Days",
DECODE(SIGN(histomvts.quantite),-1,'SELL','BUY') as "Action Code",
nvl(histomvts.QUANTITE*titres.nominal,0) as "Quantity",
titres.reference as "Security IS",
titres.libelle as "Security Description",
ABS(histomvts.cours) as "Trade Price/Yield",
ABS(histomvts.montant) as "Net Amount",
ABS(histomvts.montantcouru) as "Accrued Interest"
from
HISTOMVTS
INNER JOIN (
      SELECT FOLIO.IDENT
      FROM FOLIO 
      START WITH FOLIO.IDENT IN (66762)---GLEM
       CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR  
    ) strategy
    ON strategy.IDENT = HISTOMVTS.OPCVM
   
  
inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM 

inner join  titres 
on          titres.sicovam          = histomvts.sicovam

where titres.type = 'O' --Bond
and histomvts.dateval > trunc(sysdate)
and histomvts.type in (1,140) --purchase/sale, short sale only
;


END UNSETTLED_BOND_GLEM;


--****************************************************
-- 11-DEC-2017        Jeff Yu        Modified (PMGMRISK-147)

PROCEDURE BTG_STRAT_REGION_GLOBAL
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT
                FOLIO.NAME          Strategy_Name
              , FOLIO.IDENT         Strategy_Ident
              , TIERS.NAME          Fund_Name
FROM FOLIO
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    = 4
                START WITH FOLIO.ident         IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID          =  FOLIO.IDENT  
    INNER JOIN TIERS
    ON TIERS.IDENT = FOLIO.ENTITE
    LEFT JOIN AUDIT_FOLIO
    ON AUDIT_FOLIO.IDENT = FUND_BOOK_STRATEGY.STRATEGY_ID
WHERE FOLIO.IDENT NOT IN
          (
          SELECT 
                BTG_MAPPING_CODE.INPUT_CODE
          FROM BTG_MAPPING_CODE 
          WHERE BTG_MAPPING_CODE.TYPE_ID = 33
          ) --All regional mappings
   AND AUDIT_FOLIO.DATE_MODIF >= TRUNC(SYSDATE) - 7
   AND AUDIT_FOLIO.VERSION=0 -----New Created
;

  /*Strategies missing from BTG_STRAT_REGION*/

END BTG_STRAT_REGION_GLOBAL;


--*****************************************************************--
--11 DEC 2017         Jeff Yu        Created (PMGMRISK-147)
--12 DEC 2017         Jeff Yu        Modified (PMGMRISK-148) - Column change

PROCEDURE GDO_NEW_FOLIO
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select  distinct FOLIO.IDENT      
, FOLIO.NAME AS FOLIO_NAME
, TOP_LEVEL_STRATEGY
, BOOK_NAME   AS  Strategy_level_2
, Strategy_level_3
from folio
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3)   AS TOP_LEVEL_STRATEGY
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)       as  Strategy_level_3
                      , FOLIO.ident                                                            AS STRATEGY_ID
                      , FOLIO.name                                                             AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL                    >= 4
                START WITH FOLIO.ident         IN  (PCKG_BTG.FOLIO_GDO_MASTER_FUND)  -----GDO Fund
                CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID  =  FOLIO.IDENT  
inner join audit_folio
on folio.ident = audit_folio.ident
where  AUDIT_FOLIO.DATE_MODIF >= TRUNC(SYSDATE) - 7   -----Folios created past 7 days
AND  AUDIT_FOLIO.VERSION=0 -----New Created folios
;

END GDO_NEW_FOLIO;



PROCEDURE BTG_STRAT_REGION_SUMMARY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT 
      BTG_MAPPING_CODE.INPUT_CODE       Strategy_id
    , FOLIO.NAME                        Strategy_Name
    , BTG_MAPPING_CODE.OUTPUT_CODE      Strategy_Grouping
    , TIERS.NAME                        Fund
FROM BTG_MAPPING_CODE 
INNER JOIN  FOLIO
ON          FOLIO.IDENT = BTG_MAPPING_CODE.INPUT_CODE
INNER JOIN  TIERS
ON          TIERS.IDENT = FOLIO.ENTITE
WHERE BTG_MAPPING_CODE.TYPE_ID IN (33,34) --All regional and London EQ mappings
ORDER BY 4,3,2;

  /*Summary information*/

END BTG_STRAT_REGION_SUMMARY;


PROCEDURE EMFX_FXO_INTB
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

 select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX'
and FUND_BOOK_STRATEGY.Fund_NAME = 'BTG PACTUAL INTERNATIONAL B'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMFX_FXO_INTB;

PROCEDURE EMFX_FXO_INTB_EXP_NXT_3

	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

 select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) )
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX'
and FUND_BOOK_STRATEGY.Fund_NAME = 'BTG PACTUAL INTERNATIONAL B'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMFX_FXO_INTB_EXP_NXT_3;


PROCEDURE EMFX_FXO_GEMM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID 
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX'
and FUND_BOOK_STRATEGY.Fund_NAME = 'GEMM MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMFX_FXO_GEMM;

PROCEDURE EMFX_FXO_GEMM_EXP_NXT_3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX'
and FUND_BOOK_STRATEGY.Fund_NAME = 'GEMM MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;
END EMFX_FXO_GEMM_EXP_NXT_3;

-----------
PROCEDURE EMFX_FXO_ARF
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID 
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX 2018'
and FUND_BOOK_STRATEGY.Fund_NAME = 'ARF MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMFX_FXO_ARF;

PROCEDURE EMFX_FXO_ARF_EXP_NXT_3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM FX 2018'
and FUND_BOOK_STRATEGY.Fund_NAME = 'ARF MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;
END EMFX_FXO_ARF_EXP_NXT_3;

----------
PROCEDURE LDN_NON_ALLOC_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR
select 
  histomvts.Sicovam, 
  refcon                            Tradeid , 
  security.libelle                  Name,
  dateneg                           d$Tradedate,
  FUND_BOOK_STRATEGY.Fund_NAME      Fund,
  FUND_BOOK_STRATEGY.BOOK_NAME      Fund_Strategy,
  riskusers.name                    Trader,
  fund2.name                        Depositary,
  business_events.name              BusEvent
from histomvts

inner join riskusers 
on histomvts.operateur = riskusers.ident

inner join titres security 
on security.sicovam = histomvts.sicovam  

inner join  tiers fund2 
on fund2.ident = histomvts.depositaire

inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM

inner join business_events 
on business_events.id = histomvts.type

where 
    backoffice not in (11, 13, 180, 182, 186, 190, 192, 220, 244, 246, 248, 250, 252,260,262,264,266,268) --exclude cancelled trades and trades with allocated status
and histomvts.courtier not in (10004782,10004042,10007902,10003642,10005682,10010878, 10010875, 10010876, 10010877, 10021768) --excludes INTERNAL TRADES, ESPEED ELECTRONIC BROKERAGE, BROKERTEC, UBS BOOK TRANSFER, NDF FIXING, RESET (CFD), INTERNAL TRANSFERS, CORPORATE ACTION, NDF FIXING UCITS
and dateneg > btg_business_date(sysdate,-3) --look back 3 days
and business_events.compta = 1 --position events only
and business_events.id in ('394','250','190','4','344','241','243','294','45','247','240','242','1','444','140','160','1394','1444','1494') -- Includes: 'Buy/Sell Back','Conv Bonds-Delta Hedge','Delta Hedge - Purchase/Sale','Free','Free Of Payment','Full Assignment','Full Unwind','IPO','Loan Booking','Options-Delta Hedge','Partial Assignment','Partial Unwind','Purchase/Sale','Purchase/Sale Off Market','Short sell / Buy coverage','Unwind'
and FUND_BOOK_STRATEGY.BOOK_ID in (SELECT nyfolio.input_code
    FROM btg_mapping_code nyfolio
		WHERE nyfolio.output_code = 'LDN'
    AND nyfolio.type_id = 33 )--london strategies
and riskusers.name not in ('Neila Sula', 'Andrew Westaway','Marcos Flaks','Jaclyn Barnes','wrose', 'Moshumi Seewoogolam') --exclude financing team
order by 4,5,6,7;


END LDN_NON_ALLOC_TRADES;
  
    
PROCEDURE NY_NON_ALLOC_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

--trades not booked via block trades using allocation rules 03/23/2012 AT
--updated to look at all funds - OS
--exclude espeed and brokertec cp
--remove US Mortgages
--Modified on July 20th 2017 by Jeff Yu; JIRA-PMOG-1132
-------------------------------------------------------------------------
select 
  histomvts.Sicovam, 
  refcon                            Tradeid , 
  security.libelle                  Name,
  dateneg                           d$Tradedate,
  FUND_BOOK_STRATEGY.Fund_NAME      Fund,
  FUND_BOOK_STRATEGY.BOOK_NAME      Fund_Strategy,
  riskusers.name                    Trader,
  fund2.name                        Depositary,
  business_events.name              BusEvent
from histomvts

inner join riskusers 
on histomvts.operateur = riskusers.ident

inner join titres security 
on security.sicovam = histomvts.sicovam  

inner join  tiers fund2 
on fund2.ident = histomvts.depositaire

inner JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM

inner join business_events 
on business_events.id = histomvts.type

where 
    backoffice not in (11, 13, 180, 182, 186, 190, 192, 220, 244,246, 248, 250, 252,260,262,264,266,268) --exclude cancelled trades and trades with allocated status
and histomvts.courtier not in (10007902,10003642,10005682,10010878, 10010875, 10010876, 10010877) --excludes INTERNAL TRADES, UBS BOOK TRANSFER, NDF FIXING, RESET (CFD), INTERNAL TRANSFERS, CORPORATE ACTION
and dateneg > btg_business_date(sysdate,-3) --look back 3 days
and business_events.compta = 1 --position events only
and business_events.id not in ('161','360','9','274','221') -- Excludes: Exercise, Transfer, Expire, CFD - Financing Closeout, exchanges
and FUND_BOOK_STRATEGY.BOOK_ID in (SELECT nyfolio.input_code
    FROM btg_mapping_code nyfolio
		WHERE nyfolio.output_code = 'NY'
    AND nyfolio.type_id = 33 )--NY strategies
and security.type not in ('E','L') --exclude Repo and FX trades
--and riskusers.name not in ('Neila Sula', 'Andrew Westaway','Marcos Flaks','Jaclyn Barnes','wrose') --exclude financing team
order by 4,5,6,7;


END NY_NON_ALLOC_TRADES;
  
PROCEDURE COMPLIANCE_TRADES_PEND_REVIEW
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* All trades pending compliance review*/

select          
      Instrument.libelle                                  Instrument_Name,
      Instrument.reference                                Instrument_Reference,
      FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy,
      riskusers.name                                      Trader,
      Trades.refcon                                       Trade_Id,
      Trades.sicovam                                      Sicovam,
      trunc(Trades.DATENEG)                               d$TradeDate,
      trunc(Trades.DATEVAL)                               d$ValueDate,
      Counterparty.name                                   Counterparty,
      btg_get_instrument_type (Trades.sicovam)            Instrument_Type
from            histomvts Trades 
inner join      business_events
on              business_events.id = Trades.type
inner join      titres Instrument
on              Instrument.sicovam = Trades.sicovam 
left join       riskusers
on              riskusers.ident = trades.operateur
left join       Tiers Counterparty
on              Counterparty.ident = trades.contrepartie
left join       Tiers Broker
on              Broker.ident = trades.courtier
INNER JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  , level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (14046)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
where          
      Trades.BACKOFFICE = 266   
order by 7
;

END COMPLIANCE_TRADES_PEND_REVIEW;

PROCEDURE COMPLIANCE_TRADES_PEND_TRADER
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* All trades pending trader review*/

select          
      Instrument.libelle                                  Instrument_Name,
      Instrument.reference                                Instrument_Reference,
      FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy,
      riskusers.name                                      Trader,
      Trades.refcon                                       Trade_Id,
      Trades.sicovam                                      Sicovam,
      trunc(Trades.DATENEG)                               d$TradeDate,
      trunc(Trades.DATEVAL)                               d$ValueDate,
      Counterparty.name                                   Counterparty,
      btg_get_instrument_type (Trades.sicovam)            Instrument_Type
from            histomvts Trades 
inner join      business_events
on              business_events.id = Trades.type
inner join      titres Instrument
on              Instrument.sicovam = Trades.sicovam 
left join       riskusers
on              riskusers.ident = trades.operateur
left join       Tiers Counterparty
on              Counterparty.ident = trades.contrepartie
left join       Tiers Broker
on              Broker.ident = trades.courtier
INNER JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  , level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (14046)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
where          
      Trades.BACKOFFICE = 264   
;

END COMPLIANCE_TRADES_PEND_TRADER;

PROCEDURE JPM_CFD_TRADES
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* JPM report detailing all allocations done on CFDs today*/

select
     Fund.NAME                                        Fund,
     Trades.refcon                                    Trade_ID,
     trunc(Trades.DATENEG)                            d$Trade_Date,
     trunc(Trades.DATEVAL)                            d$Value_Date,
     trades.quantite                                  n$Quantity,
     trades.cours                                     Net_Price,
     underlying.reference                             BBG_Ticker,
     ISIN.Value                                       ISIN,
     SEDOL.value                                      SEDOL,
     DEVISE_TO_STR(Trades.devisepay)                  Pay_CCY,
     DEVISE_TO_STR(underlying.devisectt)              Underlying_CCY,
     trades.tauxchange                                FX
from           
      histomvts Trades 
      inner join      titres Instrument
      on              Instrument.sicovam = Trades.sicovam 
      inner join      tiers Fund     
      on              Fund.IDENT = trades.entite
      left join       titres underlying
      on              Instrument.code_emet = underlying.sicovam
      left join       extrnl_references_instruments ISIN
      on              isin.sophis_ident = underlying.sicovam
      and             ISIN.ref_ident = 1
      left join       extrnl_references_instruments SEDOL
      on              SEDOL.sophis_ident = underlying.sicovam
      and             SEDOL.ref_ident = 2
      inner join      business_events
      on              business_events.id = trades.type
where           Trades.BACKOFFICE                             not in (11,13,17,26,27,192,220,248,252)   --cancelled trades
and             Instrument.TYPE                               = 'G'                                     --CFD
and             trades.dateneg                                >= btg_business_date(trunc(sysdate),-1)  	--todays trades
and             trades.depositaire                            in (10010668,10011275,10010556,10020116)           --JPM CFD depositaries
and             business_events.compta                        = 1                                       --position affecting trades only
order by        3 asc;

END JPM_CFD_TRADES;

PROCEDURE COMPLIANCE_TRADE_REASONS
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* Details of all compliance reviewed trades*/

select          Trades.refcon                                       Trade_Id,
                Instrument.libelle                                  Instrument_Name,
                Instrument.reference                                Instrument_Reference,
                FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy,
                riskusers.name                                      Trader,
                Trades.sicovam                                      Sicovam,
                trunc(Trades.DATENEG)                               d$TradeDate,
                trunc(Trades.DATEVAL)                               d$ValueDate,
                Counterparty.name                                   Counterparty,
                btg_get_instrument_type (Trades.sicovam)            Instrument_Type,
                explainer.name                                      Reason_Giver,
                btg_allctn_rl_cmmnt.stamp                           Time_stamp,
                max(comp.datemodif)                                 d$Compliance_accepted,
                btg_allctn_rl_PRDFND_RSN.reason                     Reason,
                btg_allctn_rl_cmmnt."COMMENT"                       Text
                
from            histomvts Trades 

inner join      business_events
on              business_events.id = Trades.type

inner join      titres Instrument
on              Instrument.sicovam = Trades.sicovam 

left join       riskusers
on              riskusers.ident = trades.operateur

left join       Tiers Counterparty
on              Counterparty.ident = trades.contrepartie

left join       Tiers Broker
on              Broker.ident = trades.courtier

inner join      btg_allctn_rl_cmmnt
on              btg_allctn_rl_cmmnt.refcon= trades.refcon

inner join      btg_allctn_rl_PRDFND_RSN
on              btg_allctn_rl_PRDFND_RSN.id = btg_allctn_rl_cmmnt.reason

left join       riskusers   explainer
on              explainer.ident = btg_allctn_rl_cmmnt.userid

left join       audit_mvt   comp
on              comp.refcon = Trades.refcon

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
                , FOLIO.ident AS STRATEGY_ID
                , FOLIO.name AS STRATEGY_NAME
                , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (14046)--Execution book
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
ON              FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM

where           Trades.BACKOFFICE = 268 
and				Trades.dateneg between trunc(sysdate)-12 and trunc(sysdate)-5
                
group by        Trades.refcon, 
                Instrument.libelle, 
                Instrument.reference, 
                FUND_BOOK_STRATEGY.BOOK_NAME, 
                riskusers.name, 
                Trades.sicovam, 
                trunc(Trades.DATENEG), 
                trunc(Trades.DATEVAL), 
                Counterparty.name, 
                btg_get_instrument_type (Trades.sicovam), 
                explainer.name, 
                btg_allctn_rl_cmmnt.stamp, 
                btg_allctn_rl_PRDFND_RSN.reason, 
                btg_allctn_rl_cmmnt."COMMENT"   
                
order by        Trades.refcon, 
                btg_allctn_rl_cmmnt.stamp
;

END COMPLIANCE_TRADE_REASONS;

PROCEDURE SWAPS_DUE_TO_START
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* Details of all swaps and xccy swaps that are about to hit the start date*/

SELECT      FUND_BOOK_STRATEGY.FUND_NAME            Fund
,           TITRES.emission                         d$Start_Date
,           FUND_BOOK_STRATEGY.BOOK_NAME            Top_Strategy
,           FUND_BOOK_STRATEGY.strategy_name        Bottom_Strategy
,           TITRES.reference                        Reference
,           TITRES.libelle                          Name
,           SUM(ROUND(HISTOMVTS.quantite,5))        n$Quantity
,           HISTOMVTS.sicovam                       Sicovam
  
FROM        HISTOMVTS
    
INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            ,level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
          ) FUND_BOOK_STRATEGY
ON          FUND_BOOK_STRATEGY.STRATEGY_ID =HISTOMVTS.OPCVM

INNER JOIN  TITRES 
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta      =1 --position affecting trades only

WHERE       TITRES.affectation        IN ('1000','3') --swaps and Non USD xccy swaps
AND         trunc(TITRES.emission)    <= btg_business_date(sysdate,5) --echange happens in next 5 days
AND         trunc(TITRES.DATEFINAL)   >= trunc(sysdate) --swap has not expired already
AND         HISTOMVTS.backoffice      NOT IN (192,11,13,17,26,27,220,248,252) --excludes cancelled trades
AND         TITRES.quotite            IN (2,3) --Initial and Both exchange of notional
HAVING      SUM(ROUND(HISTOMVTS.quantite,5))    !=0 --position exists currently
GROUP BY FUND_BOOK_STRATEGY.FUND_NAME, TITRES.emission, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.strategy_name, TITRES.reference, TITRES.libelle, HISTOMVTS.sicovam
ORDER BY    2,5;

END SWAPS_DUE_TO_START;

PROCEDURE COMPLIANCE_OUTSTANDING
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

/* Counts by strategy the number of trades outstanding for compliance to review*/

select          
      FUND_BOOK_STRATEGY.BOOK_NAME                        Strategy,
      count(Trades.refcon)                                Count
from            histomvts Trades 
inner join      business_events
on              business_events.id = Trades.type
inner join      titres Instrument
on              Instrument.sicovam = Trades.sicovam 
left join       riskusers
on              riskusers.ident = trades.operateur
left join       Tiers Counterparty
on              Counterparty.ident = trades.contrepartie
left join       Tiers Broker
on              Broker.ident = trades.courtier
INNER JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 2, 3) AS BOOK_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  , level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (14046)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
where          
      Trades.BACKOFFICE = 266 
group by FUND_BOOK_STRATEGY.BOOK_NAME   
;

END COMPLIANCE_OUTSTANDING;


-- *****************************************************************
-- Description:     PROCEDURE  EXPIRY_T7
-- Author:          Jeff Yu
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 Mar 2015          Davi Xavier         Created 
-- 17 APR 2018           Jeff Yu           Modified (PMOF-305) ---Add underlyer for Future and Options instrument
-- *****************************************************************

PROCEDURE EXPIRY_T7
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

SELECT                        
                  
                  CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        WHEN TITRES.type = 'G' THEN UNDERLYING1.exsoc
                        ELSE TRUNC(SYSDATE)-500
                  END                                                           d$Expiry
                , CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END                                                           Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME                                  Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME                                  Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME                              Folio_name
                , TITRES.REFERENCE												                      Reference
                , TITRES.libelle											                          Instrument_Name
                , Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end as Underly_Instrument
                , SUM(HISTOMVTS.quantite)                                       Quantity
                , HISTOMVTS.sicovam                                             Sicovam
                , FUND_BOOK_STRATEGY.STRATEGY_ID	                              Folio_ID
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      WHEN TITRES.type = 'G' AND UNDERLYING1.TAUX_VAR = 4 THEN 'Cash' --For CFD
                      WHEN TITRES.type = 'G' AND UNDERLYING1.TAUX_VAR = 1 THEN 'Physical' --For CFD                      
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type

LEFT JOIN   AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation

------UNDERLYING INSTRUMENT------
LEFT JOIN   titres UNDERLYING1
ON UNDERLYING1.sicovam = 
CASE WHEN TITRES.type in ('G','F') then TITRES.code_emet 
          WHEN TITRES.type = 'D' then TITRES.codesj
ELSE TITRES.sicovam 
END


WHERE       
          HISTOMVTS.backoffice not in (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
AND       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) >= trunc(sysdate) and trunc(TITRES.DATEFINAL) <= btg_business_date(trunc(sysdate),5)) --swaps
            OR
            (TITRES.type in  ('O','D') and TITRES.FINPER >= trunc(sysdate) and TITRES.FINPER <= btg_business_date(trunc(sysdate),5)) --Bonds/Options
            OR 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE >= trunc(sysdate) and TITRES.ECHEANCE <= btg_business_date(trunc(sysdate),5)) --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC >= trunc(sysdate) and TITRES.EXSOC <= btg_business_date(trunc(sysdate),5) and TITRES.affectation!=33) --Futures not FRA
            OR
            (TITRES.type = 'K' and HISTOMVTS.dateval >= trunc(sysdate) and HISTOMVTS.dateval <= btg_business_date(trunc(sysdate),5)) --NDF          
            OR
            (TITRES.type = 'G' and UNDERLYING1.exsoc >= trunc(sysdate) and UNDERLYING1.exsoc <= btg_business_date(trunc(sysdate),5)) --CFD          
          
          )
GROUP BY                   
                  CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        WHEN TITRES.type = 'G' THEN UNDERLYING1.exsoc
                        ELSE TRUNC(SYSDATE)-500
                  END, 
                  CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END, 
                  FUND_BOOK_STRATEGY.Fund_NAME, 
                  FUND_BOOK_STRATEGY.BOOK_NAME, 
                  FUND_BOOK_STRATEGY.STRATEGY_NAME, 
                  TITRES.REFERENCE, 
                  TITRES.libelle, 
                  Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end,
                  HISTOMVTS.sicovam, 
                  FUND_BOOK_STRATEGY.STRATEGY_ID, 
                  
                  CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      WHEN TITRES.type = 'G' AND UNDERLYING1.TAUX_VAR = 4 THEN 'Cash' --For CFD
                      WHEN TITRES.type = 'G' AND UNDERLYING1.TAUX_VAR = 1 THEN 'Physical' --For CFD
                      
                      ELSE ''
                  END                                 
HAVING SUM(HISTOMVTS.quantite) !=0
ORDER BY 1,5,3,8;

END EXPIRY_T7;


-- *****************************************************************
-- Description:     PROCEDURE  EXPIRY_T1
-- Author:          Jeff Yu
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 Mar 2015          Davi Xavier         Created 
-- 18 APR 2018         Jeff Yu       Modified (PMOF 305)  Re-order columns
-- *****************************************************************
PROCEDURE EXPIRY_T1
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

SELECT      
                  CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END                                                           d$Expiry
                , CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  end                                                           instrument_type
                , FUND_BOOK_STRATEGY.BOOK_NAME                                  Strategy_Name                
                , fund_book_strategy.fund_name                                  fund_name
                , histomvts.sicovam                                             sicovam
				, TITRES.reference                                              Reference
                , TITRES.libelle	                                            Instrument_Name                
                , sum(histomvts.quantite)                                       quantity
                , devise_to_str(titres.devisectt)                               Currency
                , btg_get_underlying_reference(histomvts.sicovam)               underlying
                , btg_option_style(histomvts.sicovam)                           BTG_Option_Call_Put
                , titres.quotite                                                Contract_size
                , titres.prixexer                                               strike
                , dep.name                                                      Depositary
                , FUND_BOOK_STRATEGY.STRATEGY_NAME                              Folio_name
                , FUND_BOOK_STRATEGY.STRATEGY_ID	                              Folio_ID
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                where level >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND,PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14414,90565,14045)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    fund_book_strategy
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
LEFT JOIN   AFFECTATION
on          affectation.ident = titres.affectation


left outer join titres underlying1 
ON UNDERLYING1.sicovam = TITRES.code_emet 
left outer join titres underlying2 
ON UNDERLYING2.sicovam = TITRES.codesj 
left outer join titres underlying3 
on underlying3.sicovam = titres.codesj2 

inner join  tiers dep 
on dep.ident = histomvts.depositaire

where     fund_book_strategy.fund_id NOT IN (PCKG_BTG.FOLIO_EXEC_BOOK) --(14046)
AND       HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
AND       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) >= trunc(sysdate) and trunc(TITRES.DATEFINAL) <= btg_business_date(trunc(sysdate),1)) --swaps
            OR
            (TITRES.type in  ('O','D') and TITRES.FINPER >= trunc(sysdate) and TITRES.FINPER <= btg_business_date(trunc(sysdate),1)) --Bonds/Options
            OR 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE >= trunc(sysdate) and TITRES.ECHEANCE <= btg_business_date(trunc(sysdate),1)) --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC >= trunc(sysdate) and TITRES.EXSOC <= btg_business_date(trunc(sysdate),1) and TITRES.affectation!=33) --Futures not FRA
            OR
            (TITRES.type = 'K' and histomvts.dateval >= trunc(sysdate) and histomvts.dateval <= btg_business_date(trunc(sysdate),1)) --NDF
          )
OR (fund_book_strategy.fund_id IN (PCKG_BTG.FOLIO_EXEC_BOOK) --(14046)
AND histomvts.backoffice in (260) 
and business_events.compta = 1 
AND       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) >= trunc(sysdate) and trunc(TITRES.DATEFINAL) <= btg_business_date(trunc(sysdate),1)) --swaps
            OR
            (TITRES.type in  ('O','D') and TITRES.FINPER >= trunc(sysdate) and TITRES.FINPER <= btg_business_date(trunc(sysdate),1)) --Bonds/Options
            or 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE >= trunc(sysdate) and TITRES.ECHEANCE <= btg_business_date(trunc(sysdate),1)) --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC >= trunc(sysdate) and TITRES.EXSOC <= btg_business_date(trunc(sysdate),1) and TITRES.affectation!=33) --Futures not FRA
            OR
            (titres.type = 'K' and histomvts.dateval >= trunc(sysdate) and histomvts.dateval <= btg_business_date(trunc(sysdate),1)) --NDF
          )) -- Unallocated trades into the Execution book  
GROUP BY CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END, CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        else affectation.libelle                  
                  end, fund_book_strategy.fund_id, fund_book_strategy.fund_name, fund_book_strategy.book_name,BTG_GET_UNDERLYING_REFERENCE(histomvts.sicovam),devise_to_str(titres.devisectt),BTG_OPTION_STYLE(histomvts.sicovam),titres.quotite,titres.prixexer,dep.name,FUND_BOOK_STRATEGY.STRATEGY_NAME, TITRES.reference,TITRES.libelle, HISTOMVTS.sicovam, FUND_BOOK_STRATEGY.STRATEGY_ID, CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  end                                 
having (fund_book_strategy.fund_id NOT IN (PCKG_BTG.FOLIO_EXEC_BOOK) -- (14046)
and sum(histomvts.quantite) !=0)
or fund_book_strategy.fund_id in (pckg_btg.folio_exec_book) -- (14046)
ORDER BY 1,15,4,10;

END EXPIRY_T1;


-- *****************************************************************
-- Description:     PROCEDURE  EXPIRY_MISSED
-- Author:          Jeff Yu
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 Mar 2015          Davi Xavier         Created 
-- 17 APR 2018          Jeff Yu          Modified (PMOF-305) Add underlying for Future and Options instruments.
-- *****************************************************************
PROCEDURE EXPIRY_MISSED
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

SELECT      
                  CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END                                                           d$Expiry
                , CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END                                                           Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME                                  Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME                                  Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME                              Folio_name
                , TITRES.reference                                              Reference
				, TITRES.libelle	                                            Instrument_Name
				, Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end as Underly_Instrument
                , SUM(HISTOMVTS.quantite)                                       Quantity
                , HISTOMVTS.sicovam                                             Sicovam
                , FUND_BOOK_STRATEGY.STRATEGY_ID	                              Folio_ID
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 2
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
LEFT JOIN   AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation
------UNDERLYING INSTRUMENT------
LEFT JOIN   titres UNDERLYING1
ON UNDERLYING1.sicovam = 
CASE WHEN TITRES.type = 'F' then TITRES.code_emet 
         WHEN TITRES.type = 'D' then TITRES.codesj
ELSE TITRES.sicovam 
END

WHERE       
          HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
AND       (
            (TITRES.type = 'S' AND TRUNC(TITRES.DATEFINAL) < TRUNC(sysdate)) --swaps
            OR
            (TITRES.type in  ('O','D') AND TITRES.FINPER < TRUNC(sysdate)) --Bonds/Options
            OR 
            (TITRES.type in ('M','F','N') AND TITRES.ECHEANCE < TRUNC(sysdate)) --OTC Stock derivatives
            OR
            (TITRES.type = 'K' AND HISTOMVTS.dateval < TRUNC(sysdate)) --NDF
          )
GROUP BY CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END, CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END, FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, TITRES.reference, TITRES.libelle
				  , Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end
				  , HISTOMVTS.sicovam, FUND_BOOK_STRATEGY.STRATEGY_ID, CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                 
HAVING abs(trunc(SUM(HISTOMVTS.quantite),3)) > 0.99
ORDER BY 1,5,3,8;

END EXPIRY_MISSED;


  -- *****************************************************************
  -- Description: PROCEDURE EXPIRY_PREC_METAL
	--
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 23 May 2013    Oliver South     Created.
  -- *****************************************************************
  PROCEDURE EXPIRY_PREC_METAL
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  -- *****************************************************************
  -- START OF: EXPIRY_PREC_METAL
  -- *****************************************************************  
		OPEN p_CURSOR FOR
      SELECT      
                  histomvts.dateval                 d$Expiry
                , FUND_BOOK_STRATEGY.Fund_NAME      Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME      Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME  Folio_name
                , case
                        when security.type = 'K' then 'NDF'
                        when security.type = 'E' then 'Forward FX'
                        else 'Unknown'
                  end                               Instrument_Type
                , security.reference                Instrument_Name
                , sum(histomvts.quantite)           Quantity
                , histomvts.sicovam                 Sicovam
FROM            histomvts
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN    titres security
ON            security.sicovam          = histomvts.sicovam
INNER JOIN    business_events
ON            business_events.id = histomvts.type
WHERE       
          histomvts.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       business_events.compta = 1          --position trades only
AND       (security.reference like '%XAU%' --GOLD! ALWAYS BELIEVE IN YOUR SOUL! You've got the power to know... You're indestructible... Always believe in, because you are Gold!
          OR
          security.reference like '%XAG%' --Silver
          OR
          security.reference like '%XPT%' --Platinum
          OR
          security.reference like '%XPD%' --Paladium
          )
AND       security.type in ('E','X','K') --Forward FX, FX pair, NDF
AND       histomvts.dateval >= trunc(sysdate)  --date not passed
AND       histomvts.dateval <= btg_business_date(trunc(sysdate),5) --Expires in next business week
GROUP BY  histomvts.dateval, 
          FUND_BOOK_STRATEGY.Fund_NAME, 
          FUND_BOOK_STRATEGY.BOOK_NAME, 
          FUND_BOOK_STRATEGY.STRATEGY_NAME, 
          case
              when security.type = 'K' then 'NDF'
              when security.type = 'E' then 'Forward FX'
              else 'Unknown'
          end, 
          security.reference, 
          histomvts.sicovam                                
HAVING    sum(histomvts.quantite) !=0 --Position still open
ORDER BY  1,6,3;
    
  -- *****************************************************************
  -- END OF: EXPIRY_PREC_METAL
  -- *****************************************************************   
	END EXPIRY_PREC_METAL;


PROCEDURE ORACLE_INVALID_OBJECT
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

SELECT 
      OBJECT_NAME 
      , STATUS
      , OBJECT_TYPE
FROM 
      USER_OBJECTS 
WHERE 
      STATUS != 'VALID'
;

END ORACLE_INVALID_OBJECT;

  -- *****************************************************************
  -- Description: PROCEDURE RV_LONG_SHORT_MEXICO
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- 27-MAY-2016  Gustavo Binnie	GAMCP-25
  -- *****************************************************************
  PROCEDURE RV_LONG_SHORT_MEXICO
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: RV_LONG_SHORT_MEXICO
  -- *****************************************************************  
		OPEN p_CURSOR FOR
  SELECT DISTINCT TITRES.reference, GEMM.QTY n$GEMM
  FROM TITRES
    LEFT JOIN     (  Select titres.reference, SUM(Trades2.quantite) QTY
                              from histomvts Trades2            
                              INNER JOIN  FOLIO
                              ON FOLIO.ident   = Trades2.opcvm
                              INNER JOIN TITRES
                              ON Trades2.SICOVAM = TITRES.SICOVAM
                              INNER JOIN business_events BE
                                ON         BE.id           = Trades2.type
                                AND        be.compta       = 1
                              WHERE        OPCVM           = 126153 --- RV_LONG_SHORTMEXICO GEMM
                              AND Trades2.backoffice NOT  IN (192,11,13,17,26,27,220,248,252)
                              GROUP BY titres.reference
                ) GEMM
                  ON TITRES.reference = GEMM.reference       
                  WHERE 
                  (GEMM.QTY <>0)
                  ORDER BY titres.reference;
  -- *****************************************************************
  -- END OF: RV_LONG_SHORT_MEXICO
  -- *****************************************************************   
	END RV_LONG_SHORT_MEXICO; 


  -- *****************************************************************
  -- Description: PROCEDURE RV_LONG_SHORT_CHILE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie    Created.
  -- 27-MAY-2016  Gustavo Binnie	GAMCP-25
  -- *****************************************************************
  PROCEDURE RV_LONG_SHORT_CHILE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: RV_LONG_SHORT_CHILE
  -- *****************************************************************  
		OPEN p_CURSOR FOR
 SELECT DISTINCT TITRES.reference, GEMM.QTY n$GEMM
 FROM TITRES
 LEFT JOIN     (  Select titres.reference, SUM(Trades2.quantite) QTY
                              from histomvts Trades2        
                              INNER JOIN  FOLIO
                              ON           FOLIO.ident      = Trades2.opcvm
                              INNER JOIN TITRES
                              ON           Trades2.SICOVAM  = TITRES.SICOVAM
                              INNER JOIN business_events BE
                                ON         BE.id            = Trades2.TYPE
                                AND        be.compta        = 1  
                              WHERE        Trades2.OPCVM    = 126152  --- RV_L_S_CHILE GEMM                            
                              AND Trades2.backoffice NOT  IN (192,11,13,17,26,27,220,248,252)
                              GROUP BY titres.reference
                ) GEMM
                ON TITRES.reference = GEMM.reference               
                  WHERE 
                  (GEMM.QTY <>0)
                  ORDER BY titres.reference;
  -- *****************************************************************
  -- END OF: RV_LONG_SHORT_CHILE
  -- *****************************************************************   
	END RV_LONG_SHORT_CHILE;        
  
    -- *****************************************************************
  -- Description: PROCEDURE NEW_DEPOSITARIES_T_3D
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author            Reason for Change
  -- ----------------------------------------------------------------
  --    2013          Gustavo Binnie     Created.
  -- 29 OCT 2014      Davi Xavier        Change the depositary filter
  -- *****************************************************************
  PROCEDURE NEW_DEPOSITARIES_T_3D
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: NEW_DEPOSITARIES_T_3D
  -- *****************************************************************  
		OPEN p_CURSOR FOR
  SELECT
                            tiers.name                           Name
                          , aud.datemodif                        d$Date_Created
                          , riskusers.name                       Created_By
      FROM                  audit_tiers_compo aud      
      INNER JOIN            tiers
      ON                    tiers.ident                          =  aud.code
      LEFT JOIN             riskusers
      ON                    riskusers.ident                      =  aud.id
      WHERE          
                            ESTDEPOSITAIRE(tiers.options)        = 1
          AND               aud.datemodif                        >  trunc(BTG_BUSINESS_DATE(sysdate, -3) )
		  AND                   aud.state                            =  1          
      ORDER BY              aud.datemodif                        ASC;
  -- *****************************************************************
  -- END OF: NEW_DEPOSITARIES_T_3D
  -- *****************************************************************   
	END NEW_DEPOSITARIES_T_3D;     
  
      -- *****************************************************************
  -- Description: PROCEDURE TRADES_BOOKED_LATE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
  PROCEDURE TRADES_BOOKED_LATE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: TRADES_BOOKED_LATE
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
    SELECT
                  Trades.sicovam                                   Sicovam                
								, Trades.refcon                                    Trade_ID
                , trader.name                                      Trader
								, Instrument.libelle                               Instrument_Name
                , Instrument.reference                             Ticker
								, trunc(Trades.DATENEG)                            d$Trade_Date
                , trunc(Trades.DATEVAL)                         	 d$Value_Date
                , Trades.quantite                                  n$Qty
                , decode(Trades.quantite, 0, Trades.cours,  ROUND(abs(Trades.Montant/Trades.quantite),8) ) Net_Price
                , bo_kernel_status.name                            Status
                , DEVISE_TO_STR(Trades.devisepay)                  Currency
                , btg_get_instrument_type (Trades.sicovam)         Instrument_Type
                , business_events.NAME                             Busines_Event
                , Broker.NAME                              	       Broker
                             
      FROM                    histomvts Trades       
      INNER JOIN              titres Instrument 
      ON                      Instrument.sicovam                  =  Trades.sicovam
      INNER JOIN              business_events
      ON                      business_events.id                  =  Trades.type
      INNER JOIN              tiers PrimeBroker     
      ON                      PrimeBroker.IDENT                   =  Trades.DEPOSITAIRE
      INNER JOIN              bo_kernel_status
      ON                      bo_kernel_status.id                 =  Trades.backoffice
      INNER JOIN              tiers Broker     
      ON                      Broker.IDENT                        =  Trades.courtier
      INNER JOIN ( 
                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                    , FOLIO.ident                                                           AS STRATEGY_ID
                                    , FOLIO.name                                                            AS STRATEGY_NAME
                                    , level
                              FROM FOLIO
                              WHERE 
                              LEVEL >= 3
                              START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_EXECUTION_BOOK)--Execution Book (14045)
                              CONNECT BY PRIOR FOLIO.ident       =  FOLIO.mgr  
                            ) FUND_BOOK_STRATEGY
      ON                    FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
      LEFT JOIN             riskusers trader
      ON                    trader.ident                         =  Trades.operateur
      WHERE          
          Trades.BACKOFFICE                                           NOT IN (11,13,17,26,27,192,220,248,252)   --cancelled trades
          AND trunc(trades.datecomptable) = trunc(sysdate)
          AND trunc(trades.dateneg) < trunc(sysdate)                      
          AND               business_events.compta               =  1 --trades affecting position
          AND               Instrument.type                     != 'L'
          AND               FUND_BOOK_STRATEGY.BOOK_NAME         in ('Equity London EXEC','Cross Asset NY EXEC','Equity US EXEC')
      ORDER BY        2 ASC;     
    
  -- *****************************************************************
  -- END OF: TRADES_BOOKED_LATE
  -- *****************************************************************   
	END TRADES_BOOKED_LATE;        

  -- *****************************************************************
  -- Description: PROCEDURE UST_NOT_COVERED_BY_REPO
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013       Gustavo Binnie     Created.
  -- 10-APR-2015   Gustavo Binnie	  Fix a bug to when there isn't any repo on that bond
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  PROCEDURE UST_NOT_COVERED_BY_REPO
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UST_NOT_COVERED_BY_REPO
  -- *****************************************************************  
		OPEN p_CURSOR FOR
		SELECT distinct
                      FUND_BOOK_STRATEGY_REPO.Fund_NAME								Fund, 
                      TIERS.NAME													PB, 
                      DECODE(TITRES.TYPE,'L',REPO_ULY.REFERENCE, TITRES.REFERENCE)  UST, --if a repo trade then show underlying bond reference otherwise bond reference
                      DECODE(TITRES.TYPE,'L',REPO_ULY.SICOVAM, TITRES.SICOVAM)      Sicovam, --if a repo trade then show underlying bond sicovam otherwise bond sicovam
                      HISTOMVTS.DATEVAL												d$Value_Date, 
                      (NVL(BondTrades.QTY, 0)+NVL(RepoTrades.QTY, 0))				n$Sum_Quantity
          FROM        HISTOMVTS
          INNER JOIN ( 
                      SELECT     CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)   AS FUND_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)    AS Fund_NAME
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)   AS BOOK_ID
                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)    AS BOOK_NAME
                                , FOLIO.ident                                                           AS STRATEGY_ID
                                , FOLIO.name                                                            AS STRATEGY_NAME
                                , level
                      FROM FOLIO
                      WHERE LEVEL     >= 4
                      START WITH FOLIO.ident            IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)
                      CONNECT BY PRIOR FOLIO.ident      = FOLIO.mgr  
                    ) FUND_BOOK_STRATEGY_REPO
      ON            FUND_BOOK_STRATEGY_REPO.STRATEGY_ID      = HISTOMVTS.OPCVM 
          INNER JOIN  BUSINESS_EVENTS
          ON          BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
          AND         BUSINESS_EVENTS.COMPTA = 1 --position affecting tickets only
          INNER JOIN  TIERS
          ON          TIERS.IDENT = HISTOMVTS.DEPOSITAIRE --bring back depositary name
          LEFT JOIN   TITRES
          ON          TITRES.SICOVAM = HISTOMVTS.SICOVAM
          AND         TITRES.TYPE IN ('O','L') --link trades with either bond or repo trades
          LEFT JOIN   TITRES REPO_ULY
          ON          REPO_ULY.SICOVAM = TITRES.CODE_EMET --link a bond with a repo where bond is underlying of a repo
          LEFT JOIN 
          (                       SELECT      BOND_UNDR.SICOVAM as UndSicovam, TRADESREPO.depositaire as PB, sum(TRADESREPO.QUANTITE) as Qty
                                  FROM        HISTOMVTS TRADESREPO
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.ID = TRADESREPO.TYPE
                                  AND         BUSINESS_EVENTS.COMPTA = 1 
                                  LEFT JOIN   TITRES
                                  ON          TITRES.SICOVAM = TRADESREPO.SICOVAM
                                  AND         TITRES.TYPE IN ('L') 
                                  INNER JOIN   TITRES BOND_UNDR
                                  ON          BOND_UNDR.SICOVAM = TITRES.CODE_EMET
                                  WHERE       TRADESREPO.DATEVAL = TRUNC(SYSDATE) --trades settline today
                                  AND        (  
                                              TITRES.REFERENCE LIKE 'US912%' 
                                  OR  TITRES.REFERENCE LIKE 'US313%'
                                  OR  BOND_UNDR.REFERENCE LIKE 'US912%'
                                  OR  BOND_UNDR.REFERENCE LIKE 'US313%'
                                               )
                                  AND         TRADESREPO.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252) --not deleted trades
                                  AND         BOND_UNDR.AFFECTATION NOT IN (35, 1252, 1253, 1353) --MBS - Agency, MBS - Non Agency, CMBS, MBS - European ALL EXCLUDED
                                  AND         TITRES.AFFECTATION NOT IN (35, 1252, 1253, 1353)  --MBS - Agency, MBS - Non Agency, CMBS, MBS - European ALL EXCLUDED
                                  group by BOND_UNDR.SICOVAM, TRADESREPO.depositaire 
          ) RepoTrades
          on DECODE(TITRES.TYPE,'L',REPO_ULY.SICOVAM, TITRES.SICOVAM) = RepoTrades.UndSicovam and  HISTOMVTS.depositaire = RepoTrades.PB
          left join
          (                       SELECT      TITRES.SICOVAM as BondSicovam, TRADES.depositaire as PB, SUM(TRADES.QUANTITE) as Qty
                                  FROM        HISTOMVTS TRADES
                                  INNER JOIN  BUSINESS_EVENTS
                                  ON          BUSINESS_EVENTS.ID = TRADES.TYPE
                                  AND         BUSINESS_EVENTS.COMPTA = 1 
                                  LEFT JOIN   TITRES
                                  ON          TITRES.SICOVAM = TRADES.SICOVAM
                                  AND         TITRES.TYPE IN ('O') 
                                  WHERE       TRADES.DATEVAL = TRUNC(SYSDATE) --trades settline today
                                  AND        (  
                                              TITRES.REFERENCE LIKE 'US912%' 
                                              OR  TITRES.REFERENCE LIKE 'US313%'
                                              ) 
                                  AND         TRADES.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252) --not deleted trades
                                  AND         TITRES.AFFECTATION NOT IN (35, 1252, 1253, 1353)  --MBS - Agency, MBS - Non Agency, CMBS, MBS - European ALL EXCLUDED
                                  group by TITRES.SICOVAM, TRADES.depositaire
            ) BondTrades
            on DECODE(TITRES.TYPE,'L',REPO_ULY.SICOVAM, TITRES.SICOVAM) = BondTrades.BondSicovam and HISTOMVTS.depositaire = BondTrades.PB
          WHERE       HISTOMVTS.DATEVAL = TRUNC(SYSDATE) --trades settline today
          AND         (  
                          REPO_ULY.REFERENCE LIKE 'US912%' --All identify instrument as UST
                      OR  REPO_ULY.REFERENCE LIKE 'US313%'
                      OR  TITRES.REFERENCE LIKE 'US912%'
                      OR  TITRES.REFERENCE LIKE 'US313%'
                      )
          AND         HISTOMVTS.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)  --not deleted trades
          AND         NVL(REPO_ULY.AFFECTATION,0) NOT IN (35, 1252, 1253, 1353) --MBS - Agency, MBS - Non Agency, CMBS, MBS - European ALL EXCLUDED
          AND         TITRES.AFFECTATION NOT IN (35, 1252, 1253, 1353)  --MBS - Agency, MBS - Non Agency, CMBS, MBS - European ALL EXCLUDED
          and      (NVL(BondTrades.QTY, 0)+NVL(RepoTrades.QTY, 0)) <> 0
          order by 1,4;


  -- *****************************************************************
  -- END OF: UST_NOT_COVERED_BY_REPO
  -- *****************************************************************   
	END UST_NOT_COVERED_BY_REPO;         
 
  -- *****************************************************************
  -- Description: PROCEDURE EQ_BOXED_POSITION
  --
  -- Revision History
  -- Date             Author         Reason for Change
  -- ----------------------------------------------------------------
  -- 18-Nov-2013      Oliver South   Created.
  -- 05-APR-2016	 Gustavo Binnie  PMOG-940 - Apply rounding to open/closed positions
  -- 15-APR-2016	 Gustavo Binnie  PMOG-946 - Remove flat positions
  -- *****************************************************************
  PROCEDURE EQ_BOXED_POSITION
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: EQ_BOXED_POSITION
  -- *****************************************************************  
		OPEN p_CURSOR FOR

SELECT 
            BOXED.Fund_NAME                     Fund_NAME
          , BOXED.BOOK_NAME                     BOOK_NAME
          , BOXED.sicovam                       sicovam
          , TITRES.libelle                      Instrument_name
          , TITRES.Reference                    Instrument_reference
          , TIERS2.name                         Depositary
          , AFFECTATION.libelle                 Instrument_Allotment
          , SUM(TRADES.quantite)                n$Quantity
          , CASE 
              WHEN SUM(TRADES.quantite) >0 
              THEN 'Long' 
              ELSE 'Short' 
          END                                   Long_Short
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
            SELECT
                    POSITION.Fund_NAME
                  , POSITION.BOOK_NAME
                  , POSITION.sicovam
                  , COUNT(POSITION.depositaire)
            FROM (
                          SELECT 
                                    FUND_BOOK_STRATEGY.Fund_NAME
                                  , FUND_BOOK_STRATEGY.BOOK_NAME
                                  , TIERS.name
                                  , HISTOMVTS.sicovam
                                  , HISTOMVTS.depositaire
                                  , SUM(HISTOMVTS.quantite)
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                             -- INNER JOIN BTG_MAPPING_CODE
                             -- on  fund_book_strategy.book_id = btg_mapping_code.input_code
                             -- AND BTG_MAPPING_CODE.TYPE_ID = 34--London EQ strategies only
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, TIERS.name, HISTOMVTS.sicovam, HISTOMVTS.depositaire 
						  HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000
                          )       POSITION --this creates a table of all positions and indicates if long or short
           GROUP BY POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            HAVING COUNT(POSITION.depositaire) >1 
            )     BOXED --this table shows the positions where there is a long and a short position
ON BOXED.Fund_NAME = FUND_BOOK_STRATEGY2.Fund_NAME
AND BOXED.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXED.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam
INNER JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation
AND AFFECTATION.ident IN (4,5,8,9,10,13,14,17,18,19,20,21,25,26,29,30,35,38,39,40,43,47,49,1020,1041,1060,1140,1160,1200,1251,1252,1253,1353,1450,1500,1501,1502,1503,1504,1505,1506,1600,1601,41,12,1701,1801)
WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
GROUP BY boxed.fund_name, boxed.book_name, boxed.sicovam, titres.libelle, titres.REFERENCE, tiers2.NAME, affectation.libelle
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000

UNION --ABOVE ARE THE BOXED POSITIONS WITHIN THE FUND (IN THE SAME STRATEGY) / BELOW ARE THE BOXED POSITIONS IN DIFFERENT FUNDS (IN THE SAME STRATEGY) 

SELECT 
            FUND_BOOK_STRATEGY2.Fund_NAME
          , BOXEDFUND.BOOK_NAME
          , BOXEDFUND.sicovam
          , titres.libelle                      Instrument_name
          , TITRES.Reference                    Instrument_reference
          , TIERS2.name                         Depositary
          , AFFECTATION.libelle                 Instrument_Allotment
          , SUM(TRADES.quantite)                n$Quantity
          , CASE 
              WHEN SUM(TRADES.quantite) >0 
              THEN 'Long' 
              ELSE 'Short' 
          END                                   Long_Short
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (

Select DIRECTION.BOOK_NAME,DIRECTION.sicovam,count(DIRECTION.direction) FROM (
                  SELECT DISTINCT   FUND_BOOK_STRATEGY.BOOK_NAME
                                  , HISTOMVTS.sicovam
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                             -- INNER JOIN BTG_MAPPING_CODE
                             -- on  fund_book_strategy.book_id = btg_mapping_code.input_code
                             -- AND BTG_MAPPING_CODE.TYPE_ID = 34--London EQ strategies only
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                         HAVING ROUND(SUM(HISTOMVTS.quantite),6) != 0.000000 )DIRECTION
                          GROUP BY DIRECTION.BOOK_NAME,DIRECTION.sicovam
                          HAVING count(DIRECTION.direction)>1)BOXEDFUND
                          
ON BOXEDFUND.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXEDFUND.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam
INNER JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation
AND AFFECTATION.ident IN (4,5,8,9,10,13,14,17,18,19,20,21,25,26,29,30,35,38,39,40,43,47,49,1020,1041,1060,1140,1160,1200,1251,1252,1253,1353,1450,1500,1501,1502,1503,1504,1505,1506,1600,1601,41,12,1701,1801)
WHERE     trades.backoffice not in (11,13,17,26,27,192,220,248,252)
GROUP BY FUND_BOOK_STRATEGY2.Fund_NAME, BOXEDFUND.book_name, BOXEDFUND.sicovam, titres.libelle, titres.REFERENCE, tiers2.NAME, affectation.libelle
HAVING ROUND(SUM(TRADES.quantite),6) != 0.000000
ORDER BY 3,1,2,6;

  -- *****************************************************************
  -- END OF: EQ_BOXED_POSITION
  -- *****************************************************************   
	END EQ_BOXED_POSITION;  

  -- *****************************************************************
  -- Description: PROCEDURE UST_AMEND_BDATE
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 19-Dec-2013      Oliver South      Created.
  -- *****************************************************************
  PROCEDURE UST_AMEND_BDATE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UST_AMEND_BDATE
  -- *****************************************************************  
		OPEN p_CURSOR FOR

    SELECT
                      FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
                    , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
                    , Trades.sicovam                Sicovam
                    , Trades.refcon                 Trade_Id
                    , trader.name                   Trader
                    , Instrument.libelle            Name
                    , Instrument.reference          Ticker
                    , trunc(Trades.DATENEG)         d$Trade_Date
                    , trunc(Trades.DATEVAL)         d$Value_Date
                    , trunc(abc.datemodif)          d$Date_Modified
                    , CASE
                        WHEN trunc(Trades.datecomptable) =  trunc(abc.datemodif)
                        THEN 'Late Booked Trade'
                        ELSE 'Amendment'
                    END                             Record_Type
    FROM            histomvts Trades 
    INNER JOIN      riskusers trader
    ON              trader.ident = Trades.operateur
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam    
    AND             Instrument.affectation in (25,1251) --Gov Bond and Agency Bond
    INNER JOIN      sector_instrument_association domicile
    ON              domicile.sicovam = instrument.sicovam
    AND             domicile.sector = 6290 --Domicile country = USD
    INNER JOIN      (
                        select 
                          max(audit_mvt.version) abdversion
                        , audit_mvt.refcon
                        , max(audit_mvt.datemodif) datemodif
                        , audit_mvt.OPCVM  
                        from audit_mvt 
                        GROUP BY audit_mvt.refcon, audit_mvt.OPCVM
                    ) abc
    ON              abc.refcon= trades.refcon  
    AND             trunc(abc.datemodif) > btg_business_date(trunc(sysdate),-2) --finds the latest version and checks it was modified in the last 2 business days
    AND             abc.OPCVM = TRADES.OPCVM
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    WHERE       Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252) 
    AND         trunc(Trades.dateneg) != trunc(abc.datemodif)
	ORDER BY 1,2;

  -- *****************************************************************
  -- END OF: UST_AMEND_BDATE
  -- *****************************************************************   
	END UST_AMEND_BDATE;  


-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_POS_ALL
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 18 Sep 2014    Oliver South   Created
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE INCONSISTENT_POS_ALL (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INCONSISTENT_POS_ALL
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
             distinct All_Positions1.Strategy_Name
           , All_Positions1.Fund_Name
           , All_Positions1.Sicovam
           , All_Positions1.Name
           , all_positions1.ticker
           , round((case
                  WHEN TITRES.type = 'G' THEN All_Positions1.Quantity/TITRES.nominal --CFDs don't have nominal, this messes up the calculation
                  else all_positions1.quantity 
            END),4)   Quantity
FROM
(SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , Trades.sicovam                Sicovam
          , Instrument.libelle            Name
          , Instrument.reference          Ticker
          , ROUND(SUM(Trades.QUANTITE * NVL(Instrument.nominal,1)),6) Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    INNER JOIN      business_events
    ON              business_events.id = Trades.type
    AND             business_events.compta = 1
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- 14414 -- --Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    WHERE           Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, Trades.sicovam, Instrument.libelle, Instrument.reference   
    HAVING SUM(Trades.QUANTITE) <> 0    
)All_Positions1
INNER JOIN
(SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , Trades.sicovam                Sicovam
          , Instrument.libelle            Name
          , Instrument.reference          Ticker
          , ROUND(SUM(Trades.QUANTITE * NVL(Instrument.nominal,1)),6) Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    INNER JOIN      business_events
    ON              business_events.id = Trades.type
    AND             business_events.compta = 1
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    WHERE           Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, Trades.sicovam, Instrument.libelle, Instrument.reference   
    HAVING SUM(Trades.QUANTITE) <> 0    
)All_Positions2
ON    All_Positions1.Strategy_Name = All_Positions2.Strategy_Name --same strategy
AND   All_Positions1.Fund_Name <> All_Positions2.Fund_Name --different fund
AND   All_Positions1.Sicovam = All_Positions2.Sicovam --same instrument
AND   (
        ( All_Positions1.Quantity > 0 AND All_Positions2.Quantity < 0)
        OR
        ( All_Positions1.Quantity < 0 AND All_Positions2.Quantity > 0)
       ) --different position direction
INNER JOIN TITRES
ON All_Positions2.sicovam = TITRES.sicovam
and titres.type not in ('E') --exclude spot fx
ORDER BY 1, 3;

		-- *****************************************************************
		-- END OF: INCONSISTENT_POS_ALL
		-- *****************************************************************
END  INCONSISTENT_POS_ALL;


-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_NOVATIONS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- 18 Jun 2015    Davi Xavier    Added trader id and rename title
-- *****************************************************************
PROCEDURE OTC_T_NOVATIONS (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: OTC_T_NOVATIONS
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
        AFFECTATION.libelle                           Allotment
      , FUND_BOOK_STRATEGY.BOOK_NAME                  Fund_Strategy
      , HISTOMVTS.sicovam                             Sicovam
      , HISTOMVTS.refcon                              Trade_ID
      , TITRES.reference                              Ticker
      , TRUNC(HISTOMVTS.DATENEG)                      d$Trade_Date
      , TRUNC(HISTOMVTS.DATEVAL)                      d$Value_Date
      , ROUND(HISTOMVTS.QUANTITE * TITRES.nominal,4)  n$Quantity
      , HISTOMVTS.Montant                             n$Net_Amount
      , DEVISE_TO_STR(HISTOMVTS.devisepay)            Currency
      , TIERS.NAME                                    Prime_Broker
      , ASSIGN.NAME                                   Step_In_Party
      , BUSINESS_EVENTS.NAME                          Busines_Event
      , trader.name                                   BTG_Trader

      
FROM  HISTOMVTS

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam

LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation

INNER JOIN BUSINESS_EVENTS 
ON BUSINESS_EVENTS.id = HISTOMVTS.type

INNER JOIN TIERS
ON TIERS.IDENT = HISTOMVTS.DEPOSITAIRE

INNER JOIN TIERS ASSIGN
ON ASSIGN.IDENT = HISTOMVTS.CONTREPARTIE2

INNER JOIN      riskusers trader 
ON              trader.ident = HISTOMVTS.operateur 

INNER JOIN (
              SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
              FROM FOLIO
              WHERE LEVEL >= 4 START
              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) --
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND   HISTOMVTS.contrepartie2 IS NOT NULL --novations
AND   HISTOMVTS.dateneg = TRUNC(sysdate) --Todays trades

ORDER BY 1,2,3 ASC;
             
		-- *****************************************************************
		-- END OF: OTC_T_NOVATIONS
		-- *****************************************************************
END  OTC_T_NOVATIONS;

-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_UNWINDS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- 18 Jun 2015    Davi Xavier    Added trader id and rename title
-- *****************************************************************
PROCEDURE OTC_T_UNWINDS (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: OTC_T_UNWINDS
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
        AFFECTATION.libelle                           Allotment
      , FUND_BOOK_STRATEGY.BOOK_NAME                  Fund_Strategy
      , HISTOMVTS.sicovam                             Sicovam
      , HISTOMVTS.refcon                              Trade_ID
      , TITRES.reference                              Ticker
      , TRUNC(HISTOMVTS.DATENEG)                      d$Trade_Date
      , TRUNC(HISTOMVTS.DATEVAL)                      d$Value_Date
      , ROUND(HISTOMVTS.QUANTITE * TITRES.nominal,4)  n$Quantity
      , HISTOMVTS.Montant                             n$Net_Amount
      , DEVISE_TO_STR(HISTOMVTS.devisepay)            Currency
      , TIERS.NAME                                    Prime_Broker
      , BUSINESS_EVENTS.NAME                          Busines_Event
      , trader.name                                   BTG_Trader
      
FROM  HISTOMVTS

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam

LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation

INNER JOIN BUSINESS_EVENTS 
ON BUSINESS_EVENTS.id = HISTOMVTS.type

INNER JOIN TIERS
ON TIERS.IDENT = HISTOMVTS.DEPOSITAIRE

INNER JOIN      riskusers trader 
ON              trader.ident = HISTOMVTS.operateur 

INNER JOIN (
              SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
              FROM FOLIO
              WHERE LEVEL >= 4 START
              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) --
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND   BUSINESS_EVENTS.NAME IN ('Full Unwind','Partial Unwind') --unwinds
AND   HISTOMVTS.dateneg = TRUNC(sysdate) --Todays trades

ORDER BY 1,2,3 ASC;
             
		-- *****************************************************************
		-- END OF: OTC_T_UNWINDS
		-- *****************************************************************
END  OTC_T_UNWINDS;

-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_1_NOVATIONS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- *****************************************************************

PROCEDURE OTC_T_1_NOVATIONS (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: OTC_T_1_NOVATIONS
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
        AFFECTATION.libelle                           Allotment
      , FUND_BOOK_STRATEGY.BOOK_NAME                  Fund_Strategy
      , HISTOMVTS.sicovam                             Sicovam
      , HISTOMVTS.refcon                              Trade_ID
      , TITRES.reference                              Ticker
      , TRUNC(HISTOMVTS.DATENEG)                      d$Trade_Date
      , TRUNC(HISTOMVTS.DATEVAL)                      d$Value_Date
      , ROUND(HISTOMVTS.QUANTITE * TITRES.nominal,4)  n$Quantity
      , HISTOMVTS.Montant                             n$Net_Amount
      , DEVISE_TO_STR(HISTOMVTS.devisepay)            Currency
      , TIERS.NAME                                    Prime_Broker
      , BUSINESS_EVENTS.NAME                          Busines_Event
      
FROM  HISTOMVTS

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam

LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation

INNER JOIN BUSINESS_EVENTS 
ON BUSINESS_EVENTS.id = HISTOMVTS.type

INNER JOIN TIERS
ON TIERS.IDENT = HISTOMVTS.DEPOSITAIRE

INNER JOIN (
              SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
              FROM FOLIO
              WHERE LEVEL >= 4 START
              WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) 
              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
AND   HISTOMVTS.contrepartie2 IS NOT NULL --novations
AND   HISTOMVTS.dateneg = TRUNC(BTG_BUSINESS_DATE(sysdate,-1)) --Yesterday's trades

ORDER BY 1,2,3,12 ASC;
             
		-- *****************************************************************
		-- END OF: OTC_T_1_NOVATIONS
		-- *****************************************************************
END  OTC_T_1_NOVATIONS;

-- *****************************************************************
-- Description:     PROCEDURE  BANK_LOAN_BOXED
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- *****************************************************************

PROCEDURE BANK_LOAN_BOXED (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BANK_LOAN_BOXED
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT          FUND_BOOK_STRATEGY1.BOOK_NAME       Strategy
						  , FUND_BOOK_STRATEGY1.FUND_NAME       Fund
						  , FUND_BOOK_STRATEGY1.STRATEGY_NAME   Folio_Name
						  , trader.name                         Trader
						  , PrimeBroker.NAME                    Depositary
						  , h1.sicovam                          SICOVAM
						  , Instrument.reference                REFERENCE
						  , sum(h1.quantite)                    Quantity
						  , FUND_BOOK_STRATEGY1.STRATEGY_ID     Folio_Ident
			FROM            histomvts h1 
			INNER JOIN      tiers PrimeBroker 
			ON              PrimeBroker.IDENT = h1.DEPOSITAIRE 
			INNER JOIN      titres Instrument 
			ON              Instrument.sicovam = h1.sicovam 
			INNER JOIN      riskusers trader 
			ON              trader.ident = h1.operateur 
			INNER JOIN
						  ( SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                     AS TOP_FUND_ID
									, CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
									, FOLIO.ident                                                            AS STRATEGY_ID
									, FOLIO.name                                                             AS STRATEGY_NAME
									, level
							FROM FOLIO
							WHERE LEVEL                    >= 4
							START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
							CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
						)   FUND_BOOK_STRATEGY1
			ON              FUND_BOOK_STRATEGY1.STRATEGY_ID = h1.OPCVM
			INNER JOIN      
						  (  SELECT         h2.sicovam,
                                FUND_BOOK_STRATEGY.FUND_ID
							 FROM     histomvts h2
							 JOIN         titres
							 ON           h2.sicovam = titres.sicovam
							 INNER JOIN
										(   SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
													, CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
													, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
													, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
													, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
													, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
													, FOLIO.ident                                                            AS STRATEGY_ID
													, FOLIO.name                                                             AS STRATEGY_NAME
													, level
											FROM FOLIO
											WHERE LEVEL                    >= 4
											START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
											CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
											) FUND_BOOK_STRATEGY
							 ON                FUND_BOOK_STRATEGY.STRATEGY_ID = h2.OPCVM
							 INNER JOIN        business_events BE
							 ON                BE.id                           =  H2.type
							 AND               be.compta                       =  1 --position affecting trade tickets only
							 WHERE
                    titres.type                         = 'S' --all swaps
							 AND  titres.default_event_leg1       = 0 --exclude CDS, cannot use affectation since not set for older instruments
							 AND  h2.depositaire  IN (SELECT BTG_MAPPING_CODE.INPUT_CODE
                                          FROM BTG_MAPPING_CODE
                                          WHERE BTG_MAPPING_CODE.SOURCE_ID = 9
                                          AND BTG_MAPPING_CODE.TYPE_ID = 54
                                          )--Bank Loan Depositaries
							 AND h2.backoffice NOT  IN (192,11,13,17,26,27,220,248,252)--Not cancelled trades
							 GROUP BY   h2.sicovam, FUND_BOOK_STRATEGY.FUND_ID
							 HAVING COUNT(DISTINCT(h2.depositaire)) > 1 --more than one depositary per position
						  )   BOXED_POSITION
			ON        BOXED_POSITION.sicovam = h1.sicovam
			WHERE     h1.backoffice NOT IN (192,11,13,17,26,27,220,248,252)--Not cancelled trades
			AND       FUND_BOOK_STRATEGY1.FUND_ID = BOXED_POSITION.FUND_ID
      GROUP BY FUND_BOOK_STRATEGY1.BOOK_NAME, FUND_BOOK_STRATEGY1.FUND_NAME, FUND_BOOK_STRATEGY1.STRATEGY_NAME, trader.name, PrimeBroker.NAME, h1.sicovam, Instrument.reference, FUND_BOOK_STRATEGY1.STRATEGY_ID
      having sum(h1.quantite) ! =0 
			ORDER BY 1,2,4;
      
             
		-- *****************************************************************
		-- END OF: BANK_LOAN_BOXED
		-- *****************************************************************
END  BANK_LOAN_BOXED;



-- *****************************************************************
-- Description:     PROCEDURE  GS_BLOCK_TRADE_CSA_IND
--                  
--
-- Author:          jun guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 28 Mar 2014    Jun Guan   Created
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************

PROCEDURE GS_BLOCK_TRADE_CSA_IND (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: GS_BLOCK_TRADE_CSA_IND
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 'BLOCK' AS FUND
	,DECODE(SIGN(histomvts.quantite), - 1, 'SELL', 'BUY') AS DIRECTION
	,to_char(histomvts.dateneg, 'DD-MON-YY') AS "TRADE DATE"
	,to_char(histomvts.dateVAL, 'DD-MON-YY') AS "VALUE DATE"
	,security.libelle AS "NAME"
	,security.reference AS "REFERENCE"
	,extrnl_references_instruments.VALUE AS "ISIN"
	,ABS(histomvts.QUANTITE) AS "QUANTITY"
	,ABS(histomvts.cours) AS "PRICE"
	,ABS(histomvts.montant) AS "NET AMOUNT"
	,devise_to_str(histomvts.devisepay) AS "CURRENCY"
	,'GOLDMAN SACHS' AS "BROKER"
	,dataset.primebroker AS "PRIME BROKER"
	,HISTOMVTS.REFCON AS "BTG TRADE ID"
	,decode(CPTY.IDENT, 10020866, 'Yes', 'No') AS "CSA"
	
FROM histomvts

INNER JOIN (
	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
		,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS strat_id
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS strat_NAME
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
		,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
		,FOLIO.ident AS STRATEGY_ID
		,FOLIO.NAME AS STRATEGY_NAME
		,LEVEL
	FROM FOLIO
	WHERE LEVEL >= 4 START
	WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK) --exeuction book
		CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
	) FUND_BOOK_STRATEGY
	ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.opcvm
	
INNER JOIN titres security
ON security.sicovam = histomvts.sicovam
AND security.type = 'A'

INNER JOIN business_events
ON business_events.id = histomvts.type
AND business_events.compta = 1

INNER JOIN tiers cpty
ON cpty.ident = histomvts.courtier
	
INNER JOIN btg_mapping_code
ON btg_mapping_code.input_code = cpty.ident
AND btg_mapping_code.source_id = 3
AND btg_mapping_code.type_id = 56
AND btg_mapping_code.output_code = 'GOLDMAN SACHS'
		
INNER JOIN tiers depo
ON depo.ident = histomvts.depositaire
	
LEFT JOIN extrnl_references_instruments
ON extrnl_references_instruments.SOPHIS_IDENT = SECURITY.SICOVAM
AND extrnl_references_instruments.REF_IDENT = 1
		
INNER JOIN 
   (
	SELECT DISTINCT depo.EXTERNREF primebroker
		,histomvts.refcon block_id
	FROM histomvts
	INNER JOIN ta_block_to_generated
		ON ta_block_to_generated.block_id = histomvts.refcon
	INNER JOIN histomvts allocation
		ON allocation.refcon = ta_block_to_generated.generated_id
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS strat_id
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS strat_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --primary funds
			CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = allocation.opcvm
	INNER JOIN (
		SELECT FOLIO.IDENT
		FROM FOLIO START WITH FOLIO.IDENT IN (
				SELECT input_code
				FROM btg_mapping_code
				WHERE source_id=3 and type_id=34
				) ---only for EQ strats
			CONNECT BY PRIOR FOLIO.IDENT = FOLIO.MGR
		) strategy
		ON strategy.IDENT = allocation.OPCVM
	INNER JOIN tiers depo
		ON depo.ident = allocation.depositaire
	) dataset
	ON dataset.block_id = histomvts.refcon

WHERE histomvts.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Deleted/cancelled
AND trunc(histomvts.dateneg) = trunc(sysdate);
      
             
		-- *****************************************************************
		-- END OF: GS_BLOCK_TRADE_CSA_IND
		-- *****************************************************************
END  GS_BLOCK_TRADE_CSA_IND;


-- *****************************************************************
-- Description:     PROCEDURE  CFD_LAST_PRICE
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 02 Sep 2014     Oliver South   Created
-- *****************************************************************
PROCEDURE CFD_LAST_PRICE (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: CFD_LAST_PRICE
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
                TITRES.sicovam Sicovam 
              , TITRES.libelle Instrument_Name 
              , TITRES.reference Instrument_Reference 
              , COUNT(HISTORIQUE.d) No_Last_Prices 
              , MAX(HISTORIQUE.jour) Last_Day_Of_Price 
FROM TITRES 
INNER JOIN HISTORIQUE 
ON HISTORIQUE.sicovam = TITRES.sicovam 
WHERE TITRES.type = 'G' 
GROUP BY TITRES.sicovam 
              , TITRES.libelle 
              , TITRES.reference 
HAVING COUNT(HISTORIQUE.d) >0 
ORDER BY 5 DESC;

		-- *****************************************************************
		-- END OF: CFD_LAST_PRICE
		-- *****************************************************************
END  CFD_LAST_PRICE;

-- *****************************************************************
-- Description:     PROCEDURE  MLP_CASH_TRADES
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- 23 APR 2018     Jeff Yu       Modified (PMOG-1220)
-- *****************************************************************
PROCEDURE MLP_CASH_TRADES (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MLP_CASH_TRADES
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT          FUND_BOOK_STRATEGY1.BOOK_NAME       Strategy
			  , FUND_BOOK_STRATEGY1.FUND_NAME       Fund
              , Instrument.reference                Instrument_Reference
              , Instrument.sicovam                  Sicovam
              , Trades.refcon                       Trade_Id
              , TRUNC(Trades.DATENEG)               d$Trade_Date
              , TRUNC(Trades.DATEVAL)               d$Value_Date
              , BE.name                             Business_Event
              , TRADES.QUANTITE                     n$Quantity
              , trader.name                         Trader
			  , PrimeBroker.NAME                    Depositary
      FROM            histomvts Trades 
	  INNER JOIN      tiers PrimeBroker 
	  ON              PrimeBroker.IDENT = Trades.DEPOSITAIRE 
      INNER JOIN      BUSINESS_EVENTS BE
	  ON              BE.ID = Trades.type
      AND             BE.COMPTA = 1 
	  INNER JOIN      titres Instrument 
	  ON              Instrument.sicovam = Trades.sicovam 
	  INNER JOIN      riskusers trader 
	  ON              trader.ident = Trades.operateur 
	  INNER JOIN
						  ( SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                     AS TOP_FUND_ID
									, CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
									, FOLIO.ident                                                            AS STRATEGY_ID
									, FOLIO.name                                                             AS STRATEGY_NAME
									, level
							FROM FOLIO
							WHERE LEVEL                    >= 4
							START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds/UCITS
							CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
						)   FUND_BOOK_STRATEGY1
			ON              FUND_BOOK_STRATEGY1.STRATEGY_ID = Trades.OPCVM			
			WHERE     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)--Not cancelled trades
	  AND INSTRUMENT.AFFECTATION IN (1601) -- Shares - MLP
      AND TRADES.MONTANT <> 0 --NOT Cash Free  
      AND TRUNC(TRADES.DATENEG) >= TRUNC(BTG_BUSINESS_DATE(SYSDATE,-10))
      ;

		-- *****************************************************************
		-- END OF: MLP_CASH_TRADES
		-- *****************************************************************
END  MLP_CASH_TRADES;

-- *****************************************************************
-- Description:     PROCEDURE  MLP_ARFS_IPO_TRADES
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- *****************************************************************
PROCEDURE MLP_ARFS_IPO_TRADES (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MLP_ARFS_IPO_TRADES
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT          FUND_BOOK_STRATEGY1.BOOK_NAME       Strategy
			  , FUND_BOOK_STRATEGY1.FUND_NAME       Fund
              , Instrument.reference                Instrument_Reference
              , Instrument.sicovam                  Sicovam
              , Trades.refcon                       Trade_Id
              , TRUNC(Trades.DATENEG)               d$Trade_Date
              , TRUNC(Trades.DATEVAL)               d$Value_Date
              , BE.name                             Business_Event
              , TRADES.QUANTITE                     n$Quantity
              , trader.name                         Trader
						  , PrimeBroker.NAME                    Depositary
			FROM            histomvts Trades 
			INNER JOIN      tiers PrimeBroker 
			ON              PrimeBroker.IDENT = Trades.DEPOSITAIRE 
			INNER JOIN      BUSINESS_EVENTS BE
			ON              BE.ID = Trades.type
			AND             BE.COMPTA = 1 
			INNER JOIN      titres Instrument 
			ON              Instrument.sicovam = Trades.sicovam 
			INNER JOIN      riskusers trader 
			ON              trader.ident = Trades.operateur 
			INNER JOIN
						  ( SELECT    CONNECT_BY_ROOT(FOLIO.ident)                                     AS TOP_FUND_ID
									, CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
									, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
									, FOLIO.ident                                                            AS STRATEGY_ID
									, FOLIO.name                                                             AS STRATEGY_NAME
									, level
							FROM FOLIO
							WHERE LEVEL                    >= 4
							START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds/UCITS
							CONNECT BY PRIOR FOLIO.ident   = FOLIO.mgr  
						)   FUND_BOOK_STRATEGY1
			ON              FUND_BOOK_STRATEGY1.STRATEGY_ID = Trades.OPCVM			
			WHERE     Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)--Not cancelled trades
			AND INSTRUMENT.AFFECTATION IN (1601) -- Shares - MLP
			AND TRADES.MONTANT <> 0 --NOT Cash Free  
			AND FUND_BOOK_STRATEGY1.FUND_ID IN (PCKG_BTG.FOLIO_ARF_MASTER_FUND, PCKG_BTG.FOLIO_ARF2_MASTER_FUND )
			AND TRADES.TYPE IN (294) -- IPO Trades
			AND TRUNC(TRADES.DATENEG) >= TRUNC(BTG_BUSINESS_DATE(SYSDATE,-10))
			;

		-- *****************************************************************
		-- END OF: MLP_ARFS_IPO_TRADES
		-- *****************************************************************
END  MLP_ARFS_IPO_TRADES;

-- *****************************************************************
-- Description:     PROCEDURE  MLP_CASH_POSITIONS
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- 16 MAY 2018    Jeff Yu     Modified (PMOG-1241)
-- *****************************************************************
PROCEDURE MLP_CASH_POSITIONS (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MLP_CASH_POSITIONS
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT       
      FUND_BOOK_STRATEGY.BOOK_NAME STRATEGY
    , FUND_BOOK_STRATEGY.Fund_NAME FUND
    , TITRES.REFERENCE INSTRUMENT_REFERENCE
    , TRADES.SICOVAM SICOVAM
    , SUM(TRADES.QUANTITE) QTY
    , OPEN_CASH_POSITIONS.HOLDING_PERIOD DAYS_HELD
    FROM            HISTOMVTS TRADES
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id = TRADES.type
    AND             BUSINESS_EVENTS.compta = 1  
    INNER JOIN      TITRES
    ON              TITRES.sicovam = TRADES.sicovam    
    INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds/UCITS
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
    ON             FUND_BOOK_STRATEGY.STRATEGY_ID =  TRADES.OPCVM
    INNER JOIN ( 
              SELECT       
              DISTINCT
              TRADES1.SICOVAM  SICOVAM,
              TRADES1.ENTITE  FUND,
              FUND_BOOK_STRATEGY.BOOK_ID BOOK_ID,
              OPEN_POSITIONS.HOLDING_PERIOD HOLDING_PERIOD
              FROM            HISTOMVTS TRADES1
              INNER JOIN      BUSINESS_EVENTS
              ON              BUSINESS_EVENTS.id = TRADES1.type
              AND             BUSINESS_EVENTS.compta = 1  
              INNER JOIN      TITRES
              ON              TITRES.sicovam = TRADES1.sicovam        
              INNER JOIN ( 
                        SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                              , FOLIO.ident                                                         AS STRATEGY_ID
                              , level
                        FROM FOLIO
                        WHERE LEVEL >= 4
                        START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds/UCITS
                        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
              ON             FUND_BOOK_STRATEGY.STRATEGY_ID = TRADES1.OPCVM
              INNER JOIN (          
                        SELECT
                          TRADES_POS1.SICOVAM SICOVAM
                        , TRADES_POS1.ENTITE FUND_ID
                        , FUND_BOOK_STRATEGY.BOOK_ID STRATEGY_ID
                        , BTG_HOLDING_PERIOD(TRADES_POS1.SICOVAM,TRADES_POS1.ENTITE,SYSDATE,FUND_BOOK_STRATEGY.BOOK_ID) HOLDING_PERIOD
                        FROM            HISTOMVTS TRADES_POS1
                        INNER JOIN      BUSINESS_EVENTS
                        ON              BUSINESS_EVENTS.id = TRADES_POS1.type
                        AND             BUSINESS_EVENTS.compta = 1  
                        INNER JOIN      TITRES
                        ON              TITRES.sicovam = TRADES_POS1.sicovam       
                        INNER JOIN ( 
                                SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                              , FOLIO.ident                                                         AS STRATEGY_ID
                              , level
                              FROM FOLIO
                              WHERE LEVEL >= 4
                              START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds/UCITS
                              CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                        )    FUND_BOOK_STRATEGY
                        ON             FUND_BOOK_STRATEGY.STRATEGY_ID = TRADES_POS1.OPCVM
                        WHERE          TRADES_POS1.backoffice NOT IN (192,11,13,17,26,27,220,248,252)--cancelled trades
                        AND            TITRES.AFFECTATION = 1601 -- Shares - MLP              
                        AND            TRADES_POS1.QUANTITE <> 0
                        AND            TRADES_POS1.MONTANT <> 0
                        AND            TRADES_POS1.TYPE <> 294
                        GROUP BY       TRADES_POS1.SICOVAM, TRADES_POS1.ENTITE, FUND_BOOK_STRATEGY.BOOK_ID
                        HAVING         BTG_HOLDING_PERIOD(TRADES_POS1.SICOVAM,TRADES_POS1.ENTITE,SYSDATE,FUND_BOOK_STRATEGY.BOOK_ID) > 5
              ) OPEN_POSITIONS
              ON  OPEN_POSITIONS.SICOVAM      =  TRADES1.SICOVAM
              AND OPEN_POSITIONS.FUND_ID      =  TRADES1.ENTITE
              AND OPEN_POSITIONS.STRATEGY_ID  =  FUND_BOOK_STRATEGY.BOOK_ID
              WHERE (TRUNC(SYSDATE)-TRUNC(TRADES1.DATENEG)) <= OPEN_POSITIONS.HOLDING_PERIOD
              AND   TRADES1.QUANTITE <> 0
              AND   TRADES1.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
              AND   TRADES1.MONTANT <> 0
              AND   TRADES1.TYPE <> 294
    ) OPEN_CASH_POSITIONS
    ON        OPEN_CASH_POSITIONS.SICOVAM = TRADES.SICOVAM
    AND       OPEN_CASH_POSITIONS.FUND  = TRADES.ENTITE
    AND       OPEN_CASH_POSITIONS.BOOK_ID = FUND_BOOK_STRATEGY.BOOK_ID
    WHERE     TRADES.backoffice NOT IN (192,11,13,17,26,27,220,248,252)--cancelled trades
    GROUP BY TITRES.REFERENCE, TRADES.SICOVAM, FUND_BOOK_STRATEGY.Fund_NAME, TRADES.ENTITE, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.BOOK_ID, OPEN_CASH_POSITIONS.HOLDING_PERIOD
    ORDER BY 1,2;    

		-- *****************************************************************
		-- END OF: MLP_CASH_POSITIONS
		-- *****************************************************************
END  MLP_CASH_POSITIONS;

-- *****************************************************************
-- Description:     PROCEDURE  EQ_US_IPO_OPEN_POS
--                  
--
-- Author:         Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 12 Dec 2014     Davi Xavier   Created
-- *****************************************************************
PROCEDURE EQ_US_IPO_OPEN_POS (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: EQ_US_IPO_OPEN_POS
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
        fund_book_strategy.fund_name
      , fund_book_strategy.book_name
      , trades.sicovam
      , TITRES.libelle                      Instrument_name
      , titres.reference                    instrument_reference
      , affectation.libelle                 instrument_allotment   
      , SUM(trades.quantite) as             Quantity
      , CASE 
          WHEN SUM(trades.quantite) >0 
          THEN 'Long' 
          else 'Short' 
          end as direction
from histomvts  trades
      INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                  , FOLIO.ident                                                             AS STRATEGY_ID
                  , FOLIO.name                                                              AS STRATEGY_NAME
                  , level
                                            FROM        FOLIO
                                            where       level >= 4
                                            START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) -- (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) fund_book_strategy
                  on fund_book_strategy.strategy_id =   trades.opcvm
                              
inner join business_events                            
on trades.type = business_events.id                              
and business_events.compta = 1  --position affecting trades only
inner join titres
on titres.sicovam = trades.sicovam
inner join affectation
ON AFFECTATION.ident = TITRES.affectation                         
where     trades.backoffice not in (11,13,17,26,27,192,220,248,252) --Not deleted trades
and fund_book_strategy.book_name in ('EQ US IPO') -- EQ US IPO strategy
group by fund_book_strategy.fund_name, fund_book_strategy.book_name, trades.sicovam,  TITRES.libelle, TITRES.Reference, affectation.libelle
HAVING SUM(trades.quantite) !=0;

		-- *****************************************************************
		-- END OF: EQ_US_IPO_OPEN_POS
		-- *****************************************************************
END  EQ_US_IPO_OPEN_POS;


-- *****************************************************************
-- Description:     PROCEDURE  EXPIRY_T0
--                  
--
-- Author:         Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 15 Dec 2014     Davi Xavier		Created
-- 24 SEP 2015	   Gustavo Binnie	Added column refere. Column Instrument Name changed from titres.reference to titres.libelle
-- 17 APR 2018   Jeff Yu  Modified (PMOF-305) --Add underlyer for Future and Option instruments
-- *****************************************************************

PROCEDURE EXPIRY_T0
	(
		p_CURSOR OUT T_CURSOR
	)
  AS
	BEGIN
		
		OPEN p_CURSOR FOR

SELECT      
                  case
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL 
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        when titres.type in ('M','F','N') then titres.echeance
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END                                                           d$Expiry
                , CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END                                                           Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME                                  Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME                                  Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME                              Folio_name
				, TITRES.reference												Reference
                , TITRES.libelle	                                            Instrument_Name
				, Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end as Underly_Instrument
                , SUM(HISTOMVTS.quantite)                                       Quantity
                , HISTOMVTS.sicovam                                             Sicovam
                , FUND_BOOK_STRATEGY.STRATEGY_ID	                              Folio_ID
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                where level >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND,PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14414,90565,14045)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    fund_book_strategy
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
LEFT JOIN   AFFECTATION
on          affectation.ident = titres.affectation
------UNDERLYING INSTRUMENT------
LEFT JOIN   titres UNDERLYING1
ON UNDERLYING1.sicovam = 
CASE WHEN TITRES.type = 'F'  then TITRES.code_emet 
          WHEN TITRES.type = 'D' then TITRES.codesj
ELSE TITRES.sicovam 
END

where     fund_book_strategy.fund_id NOT IN (PCKG_BTG.FOLIO_EXEC_BOOK) --(14046)
AND       HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
and       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) = trunc(sysdate))  --swaps
            or
            (TITRES.type in  ('O','D') and TITRES.FINPER = trunc(sysdate))  --Bonds/Options
            or 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE = trunc(sysdate))  --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC = trunc(sysdate) and TITRES.affectation!=33) --Futures not FRA
            or
            (TITRES.type = 'K' and histomvts.dateval = trunc(sysdate)) --NDF
          )
OR (fund_book_strategy.fund_id IN (PCKG_BTG.FOLIO_EXEC_BOOK) --(14046)
AND histomvts.backoffice in (260) 
and business_events.compta = 1 
AND       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) = trunc(sysdate)) --swaps
            OR
            (TITRES.type in  ('O','D') and TITRES.FINPER = trunc(sysdate)) --Bonds/Options
            or 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE = trunc(sysdate)) --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC = trunc(sysdate) and TITRES.affectation!=33) --Futures not FRA
            OR
            (titres.type = 'K' and histomvts.dateval = trunc(sysdate) ) --NDF
          )) -- Unallocated trades into the Execution book  
GROUP BY CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END, CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        else affectation.libelle                  
                  END, fund_book_strategy.fund_id, FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, TITRES.reference, TITRES.libelle
				  , Case when titres.type in  ('F','D')  then UNDERLYING1.reference  else null end
				  , HISTOMVTS.sicovam, FUND_BOOK_STRATEGY.STRATEGY_ID, CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  end                                 
having (fund_book_strategy.fund_id NOT IN (PCKG_BTG.FOLIO_EXEC_BOOK) -- (14046)
and sum(histomvts.quantite) !=0)
or fund_book_strategy.fund_id in (pckg_btg.folio_exec_book) -- (14046)
ORDER BY 1,5,3,8;

END EXPIRY_T0;


 PROCEDURE MS_BLOCK_TRADE_SOFT_DOL
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
 
 -- *****************************************************************
 -- START OF: MS_BLOCK_TRADE_SOFT_DOL
 -- ****************************************************************   
	OPEN p_CURSOR FOR 

SELECT 
    'BLOCK'                                                           Fund
	, DECODE(SIGN(HISTOMVTS.quantite), - 1, 'BTG SELL', 'BTG BUY')      Direction
    , RISKUSERS.name                                                    BTG_Trader
	, HISTOMVTS.dateneg                                                 Trade_Date
	, HISTOMVTS.dateVAL                                                 Value_Date
	, TITRES.libelle                                                    Instrument_Name
	, TITRES.reference                                                  Instrument_Ticker
	, EXTRNL_REFERENCES_INSTRUMENTS.VALUE                               ISIN
	, HISTOMVTS.QUANTITE                                                Quantity
	, HISTOMVTS.cours                                                   Price
    , HISTOMVTS.fraiscourtage                                           Broker_fees
	, HISTOMVTS.montant                                                 Net_amount
	, DEVISE_TO_STR(HISTOMVTS.devisepay)                                Currency
	, 'CSA-MS'                                                          Broker
	, 'MORGAN STANLEY UK'                                               Prime_Broker
	, HISTOMVTS.REFCON                                                  BTG_Trade_ID
	
FROM HISTOMVTS

INNER JOIN (
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
              ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 2, 3) AS strat_id
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 2, 3) AS strat_NAME
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
              ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
              ,FOLIO.ident AS STRATEGY_ID
              ,FOLIO.NAME AS STRATEGY_NAME
              ,LEVEL
            FROM FOLIO
            WHERE LEVEL >= 4 START
            WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXEC_BOOK) --exeuction book (14045) 
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
          ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm --verify the trade is booked in the execution book folders
	
INNER JOIN TITRES
ON TITRES.sicovam = HISTOMVTS.sicovam --instrument static

INNER JOIN RISKUSERS
ON RISKUSERS.ident = HISTOMVTS.operateur --trader name

INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.id = HISTOMVTS.type
AND BUSINESS_EVENTS.compta = 1 --position affecting tickets only

INNER JOIN TIERS
ON TIERS.ident = HISTOMVTS.courtier
AND TIERS.ident = 10023124 --CSA-MS
	
LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS
ON EXTRNL_REFERENCES_INSTRUMENTS.SOPHIS_IDENT = TITRES.SICOVAM
AND EXTRNL_REFERENCES_INSTRUMENTS.REF_IDENT = 1 --ISIN

INNER JOIN AUDIT_MVT
ON AUDIT_MVT.refcon = HISTOMVTS.refcon
AND AUDIT_MVT.version = 1 --first version of trade from audit trail
AND TRUNC(AUDIT_MVT.datemodif) = TRUNC(SYSDATE) --trades booked today only

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Deleted/cancelled
;

 -- *****************************************************************
 -- END OF: MS_BLOCK_TRADE_SOFT_DOL
 -- ****************************************************************    
  END MS_BLOCK_TRADE_SOFT_DOL; 

-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_POS_EQ_ENERGYOP
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author            Reason for Change
-- ----------------------------------------------------------------
-- 11 Mar 2015      Davi Xavier       Created - addapted from INCONSISTENT_POS_ALL
-- 18 Mar 2016     Gustavo Binnie	  PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE INCONSISTENT_POS_EQ_ENERGYOP (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: INCONSISTENT_POS_EQ_ENERGYOP
	-- *****************************************************************	
	OPEN p_CURSOR
	FOR

SELECT 
             distinct All_Positions1.Strategy_Name
           , All_Positions1.Fund_Name
           , All_Positions1.Sicovam
           , All_Positions1.Name
           , all_positions1.ticker
           , round((case
                  WHEN TITRES.type = 'G' THEN All_Positions1.Quantity/TITRES.nominal --CFDs don't have nominal, this messes up the calculation
                  else all_positions1.quantity 
            END),4)   Quantity
FROM
(SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , Trades.sicovam                Sicovam
          , Instrument.libelle            Name
          , Instrument.reference          Ticker
          , SUM(Trades.QUANTITE*NVL(Instrument.nominal,1)) Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    INNER JOIN      business_events
    ON              business_events.id = Trades.type
    AND             business_events.compta = 1
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- 14414 -- --Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    WHERE           Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, Trades.sicovam, Instrument.libelle, Instrument.reference   
    HAVING SUM(Trades.QUANTITE) <> 0    
)All_Positions1
INNER JOIN
(SELECT          
            FUND_BOOK_STRATEGY.BOOK_NAME  Strategy_Name
          , FUND_BOOK_STRATEGY.Fund_NAME  Fund_Name
          , Trades.sicovam                Sicovam
          , Instrument.libelle            Name
          , Instrument.reference          Ticker
          , SUM(Trades.QUANTITE*NVL(Instrument.nominal,1)) Quantity
    FROM            histomvts Trades 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam = Trades.sicovam 
    INNER JOIN      business_events
    ON              business_events.id = Trades.type
    AND             business_events.compta = 1
    INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident               IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
    WHERE           Trades.BACKOFFICE                             NOT IN (192,11,13,17,26,27,220,248,252) --not cancelled trades
    GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.Fund_NAME, Trades.sicovam, Instrument.libelle, Instrument.reference   
    HAVING SUM(Trades.QUANTITE) <> 0    
)All_Positions2
ON    All_Positions1.Strategy_Name = All_Positions2.Strategy_Name --same strategy
AND   All_Positions1.Fund_Name <> All_Positions2.Fund_Name --different fund
AND   All_Positions1.Sicovam = All_Positions2.Sicovam --same instrument
AND   (
        ( All_Positions1.Quantity > 0 AND All_Positions2.Quantity < 0)
        OR
        ( All_Positions1.Quantity < 0 AND All_Positions2.Quantity > 0)
       ) --different position direction
INNER JOIN TITRES
ON All_Positions2.sicovam = TITRES.sicovam
AND titres.TYPE NOT IN ('E') --exclude spot fx
AND All_Positions1.Strategy_Name IN ('EQ Energy Opportunities')
ORDER BY 1, 3;

		-- *****************************************************************
		-- END OF: INCONSISTENT_POS_EQ_ENERGYOP
		-- *****************************************************************
END  INCONSISTENT_POS_EQ_ENERGYOP;

-- *****************************************************************
-- Description:     PROCEDURE  EMLATAM_FXO_GEMM
-- Description:     PROCEDURE  EMLATAM_FXO_INTB
-- Description:     PROCEDURE  EMLATAM_FXO_ARF
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 Mar 2015          Davi Xavier         Created 
-- 05 JAN 2018           Jeff Yu           Modified (PMGMPMO-253) ---Add ARF Fund
-- *****************************************************************

PROCEDURE EMLATAM_FXO_GEMM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID 
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates'
and FUND_BOOK_STRATEGY.Fund_NAME = 'GEMM MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMLATAM_FXO_GEMM;


PROCEDURE EMLATAM_FXO_INTB
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

 select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates'
and FUND_BOOK_STRATEGY.Fund_NAME = 'BTG PACTUAL INTERNATIONAL B'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMLATAM_FXO_INTB;

PROCEDURE EMLATAM_FXO_ARF
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID 
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates 2018'
and FUND_BOOK_STRATEGY.Fund_NAME = 'ARF MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMLATAM_FXO_ARF;

-- *****************************************************************
-- Description:     PROCEDURE  EMLATAM_FXO_GEMM_EXP_NXT_3
-- Description:     PROCEDURE  EMLATAM_FXO_INTB_EXP_NXT_3
-- Description:     PROCEDURE  EMLATAM_FXO_ARF_EXP_NXT_3
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 Mar 2015          Davi Xavier         Created 
-- 05 JAN 2018           Jeff Yu           Modified (PMGMPMO-253) ---Add ARF Fund
-- *****************************************************************


PROCEDURE EMLATAM_FXO_GEMM_EXP_NXT_3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates'
and FUND_BOOK_STRATEGY.Fund_NAME = 'GEMM MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
ORDER BY 8,2 ASC;

END EMLATAM_FXO_GEMM_EXP_NXT_3;

PROCEDURE EMLATAM_FXO_INTB_EXP_NXT_3

	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

 select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) )
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates'
and FUND_BOOK_STRATEGY.Fund_NAME = 'BTG PACTUAL INTERNATIONAL B'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
order by 8,2 asc;

END EMLATAM_FXO_INTB_EXP_NXT_3;

PROCEDURE EMLATAM_FXO_ARF_EXP_NXT_3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        Tiers.name                                                                          Counterparty,
        Instrument.libelle                                                                  Ticker,
        devise_to_str(Instrument.devisectt)                                                 Currency,
        trunc(Trades.DATENEG)                                                               d$Trade_Date,
        trades.quantite                                                                     n$Quantity,
        round(BTG_FN_FXO_STRIKE_BARRIER(instrument.sicovam, instrument.prixexer),4)         Strike,
        BTG_FN_FXO_BARRIERS(instrument.sicovam)                                             barrier,
        case when instrument.type ='N' then instrument.echeance else instrument.finper end  d$Maturity_Date,
        FUND_BOOK_STRATEGY.Fund_NAME                                                        Fund,
        FUND_BOOK_STRATEGY.FOLDER_NAME                                                      Folio_name
        
from    histomvts Trades 
inner join      titres Instrument
on              Instrument.sicovam= Trades.sicovam 
inner join      tiers
on              tiers.ident = trades.contrepartie
left JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)   AS FOLDER_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)    AS FOLDER_NAME
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  ,level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
WHERE   Instrument.affectation = 23
and ((instrument.type ='N' and instrument.echeance > trunc(sysdate-1) ) or ( instrument.type <>'N' and instrument.finper>trunc(sysdate-1) ) ) 
and ((instrument.type ='N' and instrument.echeance < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) or ( instrument.type <>'N' and instrument.finper < trunc(BTG_BUSINESS_DATE(sysdate, 4) ) ) ) 
and FUND_BOOK_STRATEGY.BOOK_NAME = 'EM (Latam) Rates 2018'
and FUND_BOOK_STRATEGY.Fund_NAME = 'ARF MASTER Fund'
and Trades.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
ORDER BY 8,2 ASC;

END EMLATAM_FXO_ARF_EXP_NXT_3;

-- *****************************************************************
-- Description:     PROCEDURE  LAST_PRICE_AUDIT_REPORT
--
-- Author:          Oliver South
--
-- Revision History
-- Date                 Author               Reason for Change
-- ----------------------------------------------------------------
-- 19 Mar 2015         Oliver South         Created 
-- *****************************************************************
PROCEDURE LAST_PRICE_AUDIT_REPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
      , TITRES.REFERENCE                                 Instrument_reference
      , TITRES.LIBELLE                                   Instrument_name
      , BTG_DAILY_AUDIT_HISTORIQUE.USERname
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_DAY      d$Date_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_TIME     Time_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.ACTION                
      , round(BTG_DAILY_AUDIT_HISTORIQUE.D_ORIGINAL,6)  D_Price_Before
      , round(BTG_DAILY_AUDIT_HISTORIQUE.D_AFTER,6)     D_Price_After
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFIED_JOUR         d$Price_date
      , CASE
        WHEN BTG_DAILY_AUDIT_HISTORIQUE.USERname = 'svc_pasv' THEN 'EXCEL PRICE ADD-IN'
        ELSE ''
        END                                               Notes
FROM    BTG_DAILY_AUDIT_HISTORIQUE
INNER JOIN TITRES
ON TITRES.SICOVAM = BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
WHERE   (D_ORIGINAL IS NOT NULL and D_AFTER IS NOT NULL) --if they are null then it indicates it is a theoretical price change, and we don't log those
AND     TRUNC(MODIFICATION_DAY) = TRUNC(BTG_BUSINESS_DATE(SYSDATE,-1)) --can run Mon - Fri making Monday look at Fridays changes
AND     TRUNC(MODIFICATION_DAY) != TRUNC(MODIFIED_JOUR) --show modifications for any date not the same impact date as the modification date
ORDER BY 3,4 DESC
;
END LAST_PRICE_AUDIT_REPORT;

   	  -- *****************************************************************
  -- Description: PROCEDURE EQ_BOXED_POSITION_EQ_ENERYOP
  --
  -- Revision History
  -- Date            Author			 Reason for Change
  -- ----------------------------------------------------------------
  -- 18-Nov-2015     Davi Xavier     Created.
  -- 18 Mar 2016     Gustavo Binnie	 PMOG-930 - Changed Name and scope to EQ Energy Oportunities
  -- *****************************************************************
  PROCEDURE EQ_BOXED_POSITION_EQ_ENERYOP
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: EQ_BOXED_POSITION_EQ_ENERYOP
  -- *****************************************************************  
		OPEN p_CURSOR FOR

SELECT 
            BOXED.Fund_NAME
          , BOXED.BOOK_NAME
          , BOXED.sicovam
          , TITRES.libelle                      Instrument_name
          , TITRES.Reference                    Instrument_reference
          , TIERS2.name                         Depositary
          , AFFECTATION.libelle                 Instrument_Allotment
          , SUM(TRADES.quantite)                n$Quantity
          , CASE 
              WHEN SUM(TRADES.quantite) >0 
              THEN 'Long' 
              ELSE 'Short' 
          END                                   Long_Short
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (
            SELECT
                    POSITION.Fund_NAME
                  , POSITION.BOOK_NAME
                  , POSITION.sicovam
                  , COUNT(POSITION.depositaire)
            FROM (
                          SELECT 
                                    FUND_BOOK_STRATEGY.Fund_NAME
                                  , FUND_BOOK_STRATEGY.BOOK_NAME
                                  , TIERS.name
                                  , HISTOMVTS.sicovam
                                  , HISTOMVTS.depositaire
                                  , SUM(HISTOMVTS.quantite)
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, TIERS.name, HISTOMVTS.sicovam, HISTOMVTS.depositaire 
                          HAVING SUM(HISTOMVTS.quantite) !=0
                          )       POSITION --this creates a table of all positions and indicates if long or short
           GROUP BY POSITION.Fund_NAME, POSITION.BOOK_NAME, POSITION.sicovam
            HAVING COUNT(POSITION.depositaire) >1 
            )     BOXED --this table shows the positions where there is a long and a short position
ON BOXED.Fund_NAME = FUND_BOOK_STRATEGY2.Fund_NAME
AND BOXED.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXED.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam
INNER JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation
AND AFFECTATION.ident IN (4,5,8,9,10,13,14,17,18,19,20,21,25,26,29,30,35,38,39,40,43,47,49,1020,1041,1060,1140,1160,1200,1251,1252,1253,1353,1450,1500,1501,1502,1503,1504,1505,1506,1600,1601,41,12,1701,1801)
WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
and boxed.book_name in ('EQ Energy Opportunities')
GROUP BY boxed.fund_name, boxed.book_name, boxed.sicovam, titres.libelle, titres.reference, tiers2.name, affectation.libelle

UNION --ABOVE ARE THE BOXED POSITIONS WITHIN THE FUND (IN THE SAME STRATEGY) / BELOW ARE THE BOXED POSITIONS IN DIFFERENT FUNDS (IN THE SAME STRATEGY) 

SELECT 
            FUND_BOOK_STRATEGY2.Fund_NAME
          , BOXEDFUND.BOOK_NAME
          , BOXEDFUND.sicovam
          , titres.libelle                      Instrument_name
          , TITRES.Reference                    Instrument_reference
          , TIERS2.name                         Depositary
          , AFFECTATION.libelle                 Instrument_Allotment
          , SUM(TRADES.quantite)                n$Quantity
          , CASE 
              WHEN SUM(TRADES.quantite) >0 
              THEN 'Long' 
              ELSE 'Short' 
          END                                   Long_Short
FROM
HISTOMVTS TRADES
INNER JOIN ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                            , FOLIO.ident                                                             AS STRATEGY_ID
                            , FOLIO.name                                                              AS STRATEGY_NAME
                            , level
                        FROM        FOLIO
                        WHERE       LEVEL >= 4
                        START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                        CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                      ) FUND_BOOK_STRATEGY2
          ON            FUND_BOOK_STRATEGY2.STRATEGY_ID =   TRADES.OPCVM
INNER JOIN  (

Select DIRECTION.BOOK_NAME,DIRECTION.sicovam,count(DIRECTION.direction) FROM (
                  SELECT DISTINCT   FUND_BOOK_STRATEGY.BOOK_NAME
                                  , HISTOMVTS.sicovam
                                  , CASE 
                                      WHEN SUM(HISTOMVTS.quantite) >0 
                                      THEN 'Long' 
                                      ELSE 'Short' 
                                    END                           AS direction
                          FROM HISTOMVTS 
                              INNER JOIN ( 
                                          SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                                , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                                                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                                                , FOLIO.ident                                                             AS STRATEGY_ID
                                                , FOLIO.name                                                              AS STRATEGY_NAME
                                                , level
                                            FROM        FOLIO
                                            WHERE       LEVEL >= 4
                                            START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
                                            CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                          ) FUND_BOOK_STRATEGY
                              ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              INNER JOIN BUSINESS_EVENTS
                              ON HISTOMVTS.type = BUSINESS_EVENTS.id
                              AND BUSINESS_EVENTS.compta = 1  --position affecting trades only
                              INNER JOIN TIERS
                              ON TIERS.ident = HISTOMVTS.depositaire
                          WHERE     HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
                         GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam
                          HAVING SUM(HISTOMVTS.quantite)>=1 OR SUM(HISTOMVTS.quantite)<=-1)DIRECTION
                          GROUP BY DIRECTION.BOOK_NAME,DIRECTION.sicovam
                          HAVING count(DIRECTION.direction)>1)BOXEDFUND
                          
ON BOXEDFUND.BOOK_NAME = FUND_BOOK_STRATEGY2.BOOK_NAME
AND BOXEDFUND.sicovam = TRADES.sicovam 
INNER JOIN BUSINESS_EVENTS BUSINESS_EVENTS2
ON TRADES.type = BUSINESS_EVENTS2.id
AND BUSINESS_EVENTS2.compta = 1 --position affecting trades only
INNER JOIN TIERS TIERS2
ON TIERS2.ident = TRADES.depositaire
INNER JOIN TITRES
ON titres.sicovam = trades.sicovam
INNER JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation
AND AFFECTATION.ident IN (4,5,8,9,10,13,14,17,18,19,20,21,25,26,29,30,35,38,39,40,43,47,49,1020,1041,1060,1140,1160,1200,1251,1252,1253,1353,1450,1500,1501,1502,1503,1504,1505,1506,1600,1601,41,12,1701,1801)
WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252)
and BOXEDFUND.book_name in ('EQ Energy Opportunities')
GROUP BY FUND_BOOK_STRATEGY2.Fund_NAME, BOXEDFUND.book_name, BOXEDFUND.sicovam, titres.libelle, titres.REFERENCE, tiers2.NAME, affectation.libelle
HAVING SUM(TRADES.quantite)>=1 OR SUM(TRADES.quantite)<=-1
ORDER BY 3,1,2,6;

  -- *****************************************************************
  -- END OF: EQ_BOXED_POSITION_EQ_ENERYOP
  -- *****************************************************************   
	END EQ_BOXED_POSITION_EQ_ENERYOP;  
  

-- *****************************************************************
  -- Description: PROCEDURE FX_OTC_OPEN
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 07-APR-2015      Davi Xavier      Created.
  -- *****************************************************************
  PROCEDURE FX_OTC_OPEN
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: FX_OTC_OPEN
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select      
                FUND_BOOK_STRATEGY.Fund_NAME        Fund
              , FUND_BOOK_STRATEGY.STRATEGY_NAME    Folio
              , TIERS.name                          Depositary
              ,	HISTOMVTS.sicovam                   Sicovam
              , HISTOMVTS.dateval                   d$Expiry
              , TITRES.libelle                      Name
              , HISTOMVTS.quantite                  n$Quantity_CCY1
              , HISTOMVTS.montant                   n$Quantity_CCY2
  
FROM        HISTOMVTS
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
                  --START       WITH FOLIO.ident    IN (14414)--Primary funds
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN  TITRES
ON          TITRES.sicovam          = histomvts.sicovam

INNER JOIN  TIERS
ON HISTOMVTS.depositaire = TIERS.ident
AND TIERS.name LIKE '%OTC%' --OTC depositaries

WHERE TITRES.type IN ('K','E','X') --NDF, forwards, FX
AND HISTOMVTS.dateval >= trunc(SYSDATE) --Any trade that has not yet settled
AND HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
ORDER BY 5 ASC;

  -- *****************************************************************
  -- END OF: FX_OTC_OPEN
  -- *****************************************************************   
	END FX_OTC_OPEN; 

-- *****************************************************************
-- Description:     PROCEDURE  THEORETICAL_PRICE_AUDIT_REPORT
--
-- Author:				Davi Xavier
--
-- Revision History
-- Date                 Author               Reason for Change
-- ----------------------------------------------------------------
-- 29 MaY 2015         Davi Xavier           Created 
-- *****************************************************************
PROCEDURE THEORETICAL_PRICE_AUDIT_REPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
      , TITRES.REFERENCE                                 Instrument_reference
      , TITRES.LIBELLE                                   Instrument_name
      , BTG_DAILY_AUDIT_HISTORIQUE.USERname
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_DAY      d$Date_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_TIME     Time_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.ACTION                
      , round(BTG_DAILY_AUDIT_HISTORIQUE.T_ORIGINAL,6)   T_Price_Before
      , round(BTG_DAILY_AUDIT_HISTORIQUE.T_AFTER,6)      T_Price_After
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFIED_JOUR         d$Price_date
      , CASE
        WHEN BTG_DAILY_AUDIT_HISTORIQUE.USERname = 'svc_pasv' THEN 'EXCEL PRICE ADD-IN'
        ELSE ''
        END                                               Notes
FROM    BTG_DAILY_AUDIT_HISTORIQUE
INNER JOIN TITRES
ON TITRES.SICOVAM = BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
WHERE   (T_ORIGINAL IS NOT NULL and T_AFTER IS NOT NULL) 
AND     TRUNC(MODIFICATION_DAY) = TRUNC(BTG_BUSINESS_DATE(SYSDATE,-1)) --can run Mon - Fri making Monday look at Fridays changes
AND     TRUNC(MODIFICATION_DAY) != TRUNC(MODIFIED_JOUR) --show modifications for any date not the same impact date as the modification date
ORDER BY 3,4 DESC
;
END THEORETICAL_PRICE_AUDIT_REPORT;

  -- *****************************************************************
  -- Description: TRADES_FXO_PREM
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 11-JUN-2015      Oliver        Created.
  -- 11-JUN-2015      Davi          Asked release
  -- *****************************************************************
  
PROCEDURE TRADES_FXO_PREM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT 
              FUND_BOOK_STRATEGY.BOOK_NAME        Strategy
            , FUND_BOOK_STRATEGY.Fund_NAME        Fund
            , HISTOMVTS.refcon     		         	  TradeID
            , HISTOMVTS.sicovam                   Sicovam
            , HISTOMVTS.dateneg                   d$TradeDate
            , HISTOMVTS.dateval                   d$ValueDate
            , TITRES.reference                    Reference
            , RISKUSERS.name						          Trader    
            , DEVISE_TO_STR(TITRES.DEVISECTT)     Premium_CCY
            , DEVISE_TO_STR(HISTOMVTS.devisepay)  Payment_CCY
FROM        HISTOMVTS
INNER JOIN (
                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                  ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                  ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                  ,FOLIO.ident AS STRATEGY_ID
                  ,FOLIO.NAME AS STRATEGY_NAME
                  ,LEVEL
                FROM FOLIO
                WHERE LEVEL >= 4 START
                WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --Primary funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                ) FUND_BOOK_STRATEGY 
ON              FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm
INNER JOIN      TITRES
ON              TITRES.sicovam = HISTOMVTS.sicovam 
AND             TITRES.affectation = 23 -- FX option
INNER JOIN      RISKUSERS
ON              RISKUSERS.ident = HISTOMVTS.operateur
WHERE           TITRES.DEVISECTT != HISTOMVTS.devisepay --premium ccy <> settlement ccy
AND             HISTOMVTS.dateneg > TRUNC(SYSDATE-5) --last 5 business days
;
END TRADES_FXO_PREM;

  -- *****************************************************************
  -- Description: CDS_BOXED_POSITION
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 29-JUL-2015      Oliver			Created.
  -- 29-JUL-2015      Davi				Arranged the release with AS
  -- APPSUPP-2219	  Andre	Bresslau	Fixed cancelled trades typo
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE CDS_BOXED_POSITION
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT 
                  FUND_BOOK_STRATEGY.BOOK_NAME      Strategy_Name                
                , FUND_BOOK_STRATEGY.fund_name      Fund_name
                , HISTOMVTS.sicovam                 Sicovam
                , TITRES.reference                  Instrument_Name                
                , SUM(HISTOMVTS.quantite)           Quantity
                , TIERS.name                        Depositary
                , AFFECTATION.libelle                Allotment
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                where level >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    fund_book_strategy
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
AND         BUSINESS_EVENTS.compta = 1 --position trades only
INNER JOIN  AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation
AND         AFFECTATION IN (22, 1250) --CDS and CDS Options instruments
INNER JOIN  TIERS 
ON          TIERS.ident = HISTOMVTS.depositaire
INNER JOIN          (
          /* Collect the fund/strategy/sicovam combination for all flat positions within a strategy ignoring depositary*/
          SELECT
                  FUND_BOOK_STRATEGY.FUND_ID
                , FUND_BOOK_STRATEGY.BOOK_ID
                , HISTOMVTS.sicovam
          FROM  HISTOMVTS
                INNER JOIN ( 
                                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                                      , FOLIO.ident                                                         AS STRATEGY_ID
                                      , FOLIO.name                                                          AS STRATEGY_NAME
                                      , level
                                FROM FOLIO
                                where level >= 4
                                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                              )    fund_book_strategy
                ON             FUND_BOOK_STRATEGY.STRATEGY_ID =  HISTOMVTS.OPCVM
                INNER JOIN  TITRES
                ON          TITRES.sicovam = HISTOMVTS.sicovam
                INNER JOIN  BUSINESS_EVENTS
                ON          BUSINESS_EVENTS.id = HISTOMVTS.type
                AND       BUSINESS_EVENTS.compta = 1 --position trades only
                INNER JOIN   AFFECTATION
                ON          AFFECTATION.ident = TITRES.affectation
                AND         AFFECTATION IN (22, 1250) --CDS and CDS Options instruments
                INNER JOIN  TIERS 
                ON          TIERS.ident = histomvts.depositaire
                WHERE     HISTOMVTS.backoffice not in (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) GROUP BY FUND_BOOK_STRATEGY.FUND_ID
                                , FUND_BOOK_STRATEGY.BOOK_ID
                                , HISTOMVTS.sicovam
                HAVING SUM(HISTOMVTS.quantite) =0
                INTERSECT
                /* Collect the fund/strategy/sicovam combination for all non-flat positions within a strategy taking into account depositary*/
                SELECT            FUND_BOOK_STRATEGY.FUND_ID
                                , FUND_BOOK_STRATEGY.BOOK_ID
                                , HISTOMVTS.sicovam
                FROM            HISTOMVTS
                INNER JOIN ( 
                                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                                      , FOLIO.ident                                                         AS STRATEGY_ID
                                      , FOLIO.name                                                          AS STRATEGY_NAME
                                      , level
                                FROM FOLIO
                                where level >= 4
                                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                              )    fund_book_strategy
                ON          FUND_BOOK_STRATEGY.STRATEGY_ID =  HISTOMVTS.OPCVM
                INNER JOIN  TITRES
                ON          TITRES.sicovam = HISTOMVTS.sicovam
                INNER JOIN  BUSINESS_EVENTS
                ON          BUSINESS_EVENTS.id = HISTOMVTS.type
                AND       BUSINESS_EVENTS.compta = 1 --position trades only
                INNER JOIN   AFFECTATION
                ON          AFFECTATION.ident = TITRES.affectation
                AND         AFFECTATION IN (22, 1250) --CDS and CDS Options instruments
                INNER JOIN  tiers dep 
                ON          dep.ident = histomvts.depositaire
                WHERE     HISTOMVTS.backoffice not in (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) GROUP BY FUND_BOOK_STRATEGY.FUND_ID
                                , FUND_BOOK_STRATEGY.BOOK_ID
                                , HISTOMVTS.sicovam
                                , dep.ident
                HAVING SUM(histomvts.quantite) <>0
                ) BOXED_POSITIONS --the intersect of flat positions at a strategy level with those which are non-flat at a depositary/strategy level are the boxed identifirers
                ON BOXED_POSITIONS.FUND_ID = FUND_BOOK_STRATEGY.FUND_ID --link of the boxed positions back to the general query
                AND BOXED_POSITIONS.BOOK_ID = FUND_BOOK_STRATEGY.BOOK_ID --link of the boxed positions back to the general query
                AND BOXED_POSITIONS.sicovam = HISTOMVTS.sicovam --link of the boxed positions back to the general query
WHERE     HISTOMVTS.backoffice NOT IN (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) --cancelled trades
GROUP BY FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.fund_name, HISTOMVTS.sicovam, TITRES.reference, TIERS.name, AFFECTATION.libelle
HAVING SUM(histomvts.quantite) <>0
ORDER BY 3,1,2;

END CDS_BOXED_POSITION;

  -- *****************************************************************
  -- Description: UF_INSTRUMENTS
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 10-AUG-2015      Davi          Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE UF_INSTRUMENTS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT            TITRES.reference                                              Instrument_reference,
                  histomvts.sicovam                                             sicovam,
                  Tiers.name                                                    Counterparty,                 
                  sum(histomvts.quantite)                                       Notional, 
                  TITRES.datefinal                                              d$UF_Maturity 
                  
FROM            histomvts

inner join      tiers
on              tiers.ident = histomvts.contrepartie

INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM

INNER JOIN  titres 
ON          titres .sicovam          = histomvts.sicovam

INNER JOIN  business_events
ON          business_events.id = histomvts.type
AND         business_events.compta = 1          -- position trades only

LEFT JOIN affectation
ON        affectation.ident = titres .affectation

WHERE histomvts.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades

and affectation.ident = 50 -- 'Inflation Swaps'
and (TITRES.reference like 'UF%')

AND fund_book_strategy.fund_name = 'GEMM MASTER Fund'
GROUP BY  TITRES.reference , histomvts.sicovam,Tiers.name,TITRES.datefinal 
HAVING sum(histomvts.quantite) != 0
ORDER BY 2;

END UF_INSTRUMENTS;

  -- *****************************************************************
  -- Description: LATAM_FWD
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 10-AUG-2015      Davi          Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE LATAM_FWD
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT            TITRES.reference                                              Instrument_reference,
                  histomvts.sicovam                                             sicovam,
                  btg_get_underlying_reference(histomvts.sicovam)               Bond_Ref,
                  Tiers.name                                                    Counterparty,
                  MIN(histomvts.dateneg)                                        d$INITIAL_Trade_Date,                  
                  sum(histomvts.quantite)                                       Notional, 
                  titres.j1refcon1/100                                          Clean_price 
                  
FROM            histomvts

inner join      tiers
on              tiers.ident = histomvts.contrepartie

INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM

INNER JOIN  titres 
ON          titres .sicovam          = histomvts.sicovam

INNER JOIN  business_events
ON          business_events.id = histomvts.type
AND         business_events.compta = 1           -- position trades only

LEFT JOIN affectation
ON        affectation.ident = titres .affectation

WHERE histomvts.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades

and affectation.ident = 3 -- Swaps
and (TITRES.reference like 'TES%'
or TITRES.reference like 'BTP%'
or TITRES.reference like 'BTU%'
or TITRES.reference like 'UVR%'
or TITRES.reference like 'MBO%') 

AND fund_book_strategy.fund_name = 'GEMM MASTER Fund'

GROUP BY  TITRES.reference , histomvts.sicovam,btg_get_underlying_reference(histomvts.sicovam),Tiers.name,titres.j1refcon1 
HAVING sum(histomvts.quantite) != 0 
ORDER BY 2;

END LATAM_FWD;

  -- *****************************************************************
  -- Description: EXPIRY_FUT_DELIVERY
  --
  -- Revision History
  -- Date             Author			Reason for Change
  -- ----------------------------------------------------------------
  -- 07-SEP-2015      Oliver			Created.
  -- 07-SEP-2015      Davi				Arranged the release with AS
  -- 24-SEP-2015	  Gustavo Binnie	Added column instrument reference
  -- 17-Apr-2018    Jeff Yu     PMOF-305  Add underlying 
  -- *****************************************************************
  
PROCEDURE EXPIRY_FUT_DELIVERY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR
SELECT      
                  TITRES.EXSOC                                                  d$Payment_Date
                , TITRES.ECHEANCE                                               d$Maturiy
                , AFFECTATION.libelle                                           Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME                                  Fund_Name
                , FUND_BOOK_STRATEGY.BOOK_NAME                                  Strategy_Name
                , FUND_BOOK_STRATEGY.STRATEGY_NAME                              Folio_name
                , TITRES.reference                                              Reference
				, TITRES.libelle	                                            Instrument_Name
				, UNDERLYING1.reference                                   Underly_Instrument
                , SUM(HISTOMVTS.quantite)                                       Quantity
                , HISTOMVTS.sicovam                                             Sicovam
                , FUND_BOOK_STRATEGY.STRATEGY_ID	                              Folio_ID
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  CONNECT_BY_ROOT(FOLIO.ident)                                        AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                         AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)  AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)  AS BOOK_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , FOLIO.name                                                          AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 2
                START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
LEFT JOIN   AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation
LEFT JOIN   titres UNDERLYING1
ON UNDERLYING1.sicovam = TITRES.code_emet 

WHERE       
          HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
AND       TRUNC(sysdate) >= TITRES.EXSOC --Payment date has been passed
AND       TRUNC(sysdate) <= TITRES.ECHEANCE --Maturity date not reached yet
AND       TITRES.type = 'F' --Futures
AND       TITRES.affectation !=33 --Not FRA
AND       TRUNC(to_date(TITRES.EXSOC,'DD-MON-YY')) != TRUNC(to_date('01-JAN-04','DD-MON-YY')) --ignores when the payment date has not been entered
GROUP BY TITRES.EXSOC, TITRES.ECHEANCE, AFFECTATION.libelle, FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME
                  , TITRES.reference, TITRES.libelle, UNDERLYING1.reference,HISTOMVTS.sicovam, FUND_BOOK_STRATEGY.STRATEGY_ID, CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END
HAVING SUM(HISTOMVTS.quantite) != 0
ORDER BY 1,6,4,9;

END EXPIRY_FUT_DELIVERY;

  -- *****************************************************************
  -- Description: PROCEDURE MO_AMENDMENT_EXEC
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 20 SEP 2015     Davi Xavier     Created.
  -- *****************************************************************
  
PROCEDURE MO_AMENDMENT_EXEC(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MO_AMENDMENT_EXEC
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

Select * from --SELECT FOR THE UNION WITH THE MANAGER TABLE
(SELECT FUND_BOOK_STRATEGY.BOOK_NAME                             Strategy_name,       
        ECONOMIC_CHANGES.REFCON                                  Trade_ID,
        ECONOMIC_CHANGES.SICOVAM                                 SICOVAM, 
        Instrument.REFERENCE                                     Instrument_Reference,
        Instrument.LIBELLE                                       Instrument_NAME,
        histomvts.dateneg                                        d$Trade_Date,
        histomvts.dateval                                        d$Value_Date,
        CASE WHEN audit_mvt.DATEMODIF is null THEN To_char(sysdate,'DD-MON-YYYY HH:MM:SS') ELSE To_char(audit_mvt.DATEMODIF,'DD-MON-YYYY HH:MM:SS') END       Date_Modified,
        CASE WHEN trader.name is null THEN 'MO_ID not indentified in database, please check Sophis audit' ELSE trader.name END                                               USER_ID,
        business_events.NAME                                                                    Busines_Event,
        CASE WHEN risk_user_profiles.profile_ident=4572 THEN 'MO amendment' ELSE '' END         Details,
        ECONOMIC_CHANGES.cours                                                                  Price,
        ECONOMIC_CHANGES.quantite                                                               Qty,
        ECONOMIC_CHANGES.montant                                                                Net_Amount
--***--        
FROM (
-- STEP 2 >> BELOW WE ARE CREATING A NEW TABLE WHICH CONSIDERS ONLY ECONOMIC CHANGES, DISREGARDING THE STATUS CHANGES AND ANY OTHER TICKET CHANGE,
--           GROUPING THE INFORMATION BELOW PER TRADE_ID, PRICE, QUANTITE AND AMOUNT, AND FIGURING OUT THE FIRST REGISTER OF ECONOMIC CHANGE 
SELECT    MIN(NEW_AUDIT_LDN.version)-1                                           VERSION,
          NEW_AUDIT_LDN.refcon,
          NEW_AUDIT_LDN.sicovam,
          NEW_AUDIT_LDN.cours,
          NEW_AUDIT_LDN.quantite,
          NEW_AUDIT_LDN.montant
          from (
          
-- STEP 1 >> BELOW WE ARE CREATING A NEW TEMPORARY TABLE IN ORDER TO ADD THE CURRENT ECONOMIC VALUES (FROM THE HISTOMVTS TABLE), ONCE THE LAST ECONOMIC CHANGE MADE IN THE TRADE DOESN'T APPEAR IN THE AUDIT.MVT TABLE
      SELECT min(audit_mvt.version) version,audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant
      from audit_mvt         
      WHERE audit_mvt.version >1 --dESREGARD THE INSERTIONS
--STEP 1.1 >> THE FINTER BELOW FILTER ONLY 1-) THE TRADES WITH ECONIMIC CHANGES 2-) MADE BY AN MO 3-) IN A LDN STRATEGY 4-) TODAY
      AND audit_mvt.REFCON IN (--After the coditions have been created by the tables "ecochanges1" ans "TRADE_IDs_LIST", filter only the trades which were 1-)Amended by a M.O.\2-)Today\3-)In a LDN strategy
                                select distinct TRADE_IDs_LIST.REFCON from (
                                -- The "TRADE_IDs_LISTt" add the information of which operator amended the ticket 
                                select ecochanges1.*,risk_user_profiles.profile_ident,audit_mvt.opcvm
                                
                                -- The "ecochanges1" table selects all economic changes   
                                from(SELECT min(audit_mvt.version) version,min(audit_mvt.datemodif) datemodif,audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 
                                from audit_mvt  
                                where audit_mvt.version >1 
                                group by audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant)ecochanges1 
                                
                                inner join audit_mvt 
                                on ecochanges1.version = audit_mvt.version 
                                and ecochanges1.refcon = audit_mvt.refcon 
                                
                                inner JOIN risk_user_profiles  
                                on audit_mvt.USERID=risk_user_profiles.user_ident
                                
                                )TRADE_IDs_LIST 
                                INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                                ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADE_IDs_LIST.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' 
                                
                                where TRADE_IDs_LIST.profile_ident = 4572
                                and TRADE_IDs_LIST.datemodif > trunc(SYSDATE))

group by audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 

UNION
--STEP 2.2 -- ADDING THE INFORMATION FROM HISTOMVTS TABLE AS MENTIONED IN THE STEP 1
  select  1000001 VERSION,
          histomvts.refcon,
          histomvts.sicovam,
          histomvts.cours,
          histomvts.quantite,
          histomvts.montant    
          from histomvts
-- THE FILTER BELOW IS DIFFERENT FROM THE STEP 1.1.1 IN ORDER TO OPTIMIZE THE CODE
      WHERE histomvts.REFCON IN (--After all the coditions have been created by the tables "ecochanges1" ans "TRADE_IDs_LIST" filter only the trades which were 1)Amended by a M.O.\2)Today\In a LDN strategy
                                select distinct audit_mvt.REFCON from audit_mvt
                                
                                inner JOIN risk_user_profiles  
                                on audit_mvt.USERID=risk_user_profiles.user_ident
                                
                                INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                                ON FUND_BOOK_STRATEGY.STRATEGY_ID = audit_mvt.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' 
                                
                                where risk_user_profiles.profile_ident = 4572
                                and audit_mvt.datemodif > trunc(SYSDATE))

      )NEW_AUDIT_LDN
-- STEP 1 END
      GROUP BY NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant
--***--
-- STEP 2 END
      )ECONOMIC_CHANGES
      
      LEFT JOIN       audit_mvt
      ON              ECONOMIC_CHANGES.REFCON = audit_mvt.REFCON
      AND             ECONOMIC_CHANGES.VERSION = audit_mvt.version
      
      LEFT JOIN       riskusers trader
      ON              trader.ident = audit_mvt.USERID --FIND THE NAME OF THE USER WICH MADE THE AMENDMENT

      LEFT JOIN       risk_user_profiles 
      ON              audit_mvt.USERID=risk_user_profiles.user_ident
      
      INNER JOIN      histomvts
      ON              ECONOMIC_CHANGES.refcon= histomvts.refcon
  
      LEFT JOIN       Business_Events
      ON              Business_Events.Id =histomvts.type
  
    inner JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                        , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)     AS FOLDER_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)      AS FOLDER_NAME
                        , FOLIO.ident                                                             AS STRATEGY_ID
                        , FOLIO.name                                                              AS STRATEGY_NAME
                        , level
                    FROM        FOLIO
                    WHERE       LEVEL >= 4
                    START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) --(PCKG_BTG.FOLIO_EXECUTION_BOOK-)
                    CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
 ----------------------------------------------------------------------------------------- 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam= histomvts.sicovam    
-----------------------------------------------------------------------------------------     
      INNER JOIN 
      --IF ANY MAINTENANCE IS NECESSARY, THE CODE BELOW IS EXACTLY THE CODE BETWEEN THE SYMBOL --***-- ABOVE, EXCEPT FOR THE GROUP BY AND COUNTER IN THE SELECT
      (SELECT  DISTINCT ECONOMIC_CHANGES2.refcon,COUNT(ECONOMIC_CHANGES2.refcon) COUNTER FROM (SELECT MIN(NEW_AUDIT_LDN.version) VERSION,NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant from (SELECT min(audit_mvt.version) version,audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt WHERE audit_mvt.version >1 AND audit_mvt.REFCON IN (select distinct TRADE_IDs_LIST.REFCON from (select ecochanges1.*,risk_user_profiles.profile_ident,audit_mvt.opcvm from(SELECT min(audit_mvt.version) version,min(audit_mvt.datemodif) datemodif,audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt where audit_mvt.version >1 group by audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant)ecochanges1 inner join audit_mvt on ecochanges1.version = audit_mvt.version and ecochanges1.refcon = audit_mvt.refcon inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident)TRADE_IDs_LIST INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADE_IDs_LIST.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' where TRADE_IDs_LIST.profile_ident = 4572 and TRADE_IDs_LIST.datemodif > trunc(SYSDATE)) group by audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 
      UNION select 1000000 VERSION, histomvts.refcon, histomvts.sicovam,histomvts.cours,histomvts.quantite,histomvts.montant from histomvts WHERE histomvts.REFCON IN (select distinct audit_mvt.REFCON from audit_mvt inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = audit_mvt.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' where risk_user_profiles.profile_ident = 4572 and audit_mvt.datemodif > trunc(SYSDATE)))NEW_AUDIT_LDN GROUP BY NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant)ECONOMIC_CHANGES2 GROUP BY ECONOMIC_CHANGES2.refcon)
      REPLICA_OF_ECONOMIC_CHANGES
      ON ECONOMIC_CHANGES.refcon= REPLICA_OF_ECONOMIC_CHANGES.refcon

where REPLICA_OF_ECONOMIC_CHANGES.counter > 1)FINAL
where FINAL.USER_ID <> 'MANAGER'  -- Ben asked to to reports only the last economic change by the user "manager" in order to reduce the size of this report

union
----------------------Add last register for the user 'MANAGER'------------------------------------
SELECT  FUND_BOOK_STRATEGY.BOOK_NAME                             Strategy_name,  
        audit_mvt.REFCON                                         Trade_ID,
        audit_mvt.SICOVAM                                        SICOVAM,  
        Instrument.REFERENCE                                     Instrument_Reference,
        Instrument.LIBELLE                                       Instrument_Name,
        histomvts.dateneg                                        d$Trade_Date,
        histomvts.dateval                                        d$Value_Date,
        CASE WHEN audit_mvt.DATEMODIF is null THEN To_char(sysdate,'DD-MON-YYYY HH:MM:SS') ELSE To_char(audit_mvt.DATEMODIF,'DD-MON-YYYY HH:MM:SS') END       Date_Modified,
        CASE WHEN trader.name is null THEN 'MO_ID not indentified in database, please check Sophis audit' ELSE trader.name END                                               USER_ID,
        business_events.NAME                                                              Busines_Event,
        CASE WHEN risk_user_profiles.profile_ident=4572 THEN 'MO amendment' ELSE '' END   Details,
        audit_mvt.cours                                                                  Price,
        audit_mvt.quantite                                                               Qty,
        audit_mvt.montant                                                                Net_Amount
from
(SELECT audit_mvt.refcon, max(audit_mvt.version) version FROM audit_mvt
INNER JOIN riskusers trader
ON trader.ident = audit_mvt.USERID
AND trader.IDENT = 1 -- USER = MANAGER 
group by audit_mvt.refcon)manager
inner join audit_mvt
on audit_mvt.refcon = manager.refcon
and audit_mvt.version = manager.version
      
      LEFT JOIN       riskusers trader
      ON              trader.ident = audit_mvt.USERID --FIND THE NAME OF THE USER WICH MADE THE AMENDMENT

      LEFT JOIN       risk_user_profiles 
      ON              audit_mvt.USERID=risk_user_profiles.user_ident
      
      INNER JOIN      histomvts
      ON              manager.refcon= histomvts.refcon
  
      INNER JOIN      Business_Events
      ON              Business_Events.Id =histomvts.type
  
    inner JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                        , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 4, 5)     AS FOLDER_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 4, 5)      AS FOLDER_NAME
                        , FOLIO.ident                                                             AS STRATEGY_ID
                        , FOLIO.name                                                              AS STRATEGY_NAME
                        , level
                    FROM        FOLIO
                    WHERE       LEVEL >= 4
                    START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) --(PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14045-)
                    CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
 ----------------------------------------------------------------------------------------- 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam= histomvts.sicovam
      
-----------------------------------------------------------------------------------------     
      INNER JOIN 
      --IF ANY MAINTENANCE IS NECESSARY, THE CODE BELOW IS EXACTLY THE CODE BETWEEN THE SYMBOL --***-- ABOVE, EXCEPT FOR THE GROUP BY AND COUNTER IN THE SELECT
      (SELECT  DISTINCT ECONOMIC_CHANGES2.refcon,COUNT(ECONOMIC_CHANGES2.refcon) COUNTER FROM (SELECT MIN(NEW_AUDIT_LDN.version) VERSION,NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant from (SELECT min(audit_mvt.version) version,audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt WHERE audit_mvt.version >1 AND audit_mvt.REFCON IN (select distinct TRADE_IDs_LIST.REFCON from (select ecochanges1.*,risk_user_profiles.profile_ident,audit_mvt.opcvm from(SELECT min(audit_mvt.version) version,min(audit_mvt.datemodif) datemodif,audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt where audit_mvt.version >1 group by audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant)ecochanges1 inner join audit_mvt on ecochanges1.version = audit_mvt.version and ecochanges1.refcon = audit_mvt.refcon inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident)TRADE_IDs_LIST INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADE_IDs_LIST.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' where TRADE_IDs_LIST.profile_ident = 4572 and TRADE_IDs_LIST.datemodif > trunc(SYSDATE)) group by audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 
      UNION select 1000000 VERSION, histomvts.refcon, histomvts.sicovam,histomvts.cours,histomvts.quantite,histomvts.montant from histomvts WHERE histomvts.REFCON IN (select distinct audit_mvt.REFCON from audit_mvt inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = audit_mvt.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 70 and btg_mapping_code.output_code = 'LDN' where risk_user_profiles.profile_ident = 4572 and audit_mvt.datemodif > trunc(SYSDATE)))NEW_AUDIT_LDN GROUP BY NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant)ECONOMIC_CHANGES2 GROUP BY ECONOMIC_CHANGES2.refcon)
      REPLICA_OF_ECONOMIC_CHANGES
      ON audit_mvt.REFCON= REPLICA_OF_ECONOMIC_CHANGES.refcon
      where REPLICA_OF_ECONOMIC_CHANGES.counter > 1
      and audit_mvt.cours is not null
  
order by 2,8;

END

-- *****************************************************************
-- END OF: MO_AMENDMENT_EXEC
-- *****************************************************************

MO_AMENDMENT_EXEC;

  -- *****************************************************************
  -- Description: PROCEDURE MO_INSERTIONS_EXEC
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 20 SEP 2015     Davi Xavier     Created.
  -- *****************************************************************
  
PROCEDURE MO_INSERTIONS_EXEC(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MO_INSERTIONS_EXEC
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT  BOOK_NAME                             Strategy_name,
        insertion.refcon                      Trade_ID,
        Instrument.sicovam                    sicovam,
        Instrument.REFERENCE                  Instrument_Reference,
        Instrument.reference                  Instrument_Name,
        TRADES.dateneg                        d$Trade_Date,
        TRADES.dateval                        d$Value_Date,
        to_char(insertion.datemodif,'DD-MON-YYYY HH:MM:SS')                   Insertion_Date,
        trader.name                           USER_ID,
        business_events.NAME                  Busines_Event,
        'MO insertion'                        Details,
        TRADES.cours                          Current_Price,
        TRADES.quantite                       Current_QTY,
        TRADES.montant                        Current_Net_Amount

FROM (select audit_mvt.refcon,
audit_mvt.cours,
audit_mvt.quantite,
audit_mvt.montant,
audit_mvt.datemodif,
audit_mvt.USERID
from audit_mvt
INNER JOIN risk_user_profiles 
on audit_mvt.USERID=risk_user_profiles.user_ident 
and risk_user_profiles.profile_ident=4572 
where audit_mvt.version = 1 
AND TRUNC(audit_mvt.datemodif) = TRUNC(SYSDATE))insertion

-----------------------------------------------------------------------------------------
--  FILTER ONLY CHANGE FOR THE EXECUTION BOOK
-----------------------------------------------------------------------------------------
INNER JOIN HISTOMVTS TRADES
ON insertion.REFCON = TRADES.REFCON

INNER JOIN      riskusers trader
ON              trader.ident = insertion.USERID

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_EXECUTION_BOOK) -- (14045) -- 
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
-----------------------------------------------------------------------------------------   
--ONLY FOR LDN STRATEGIES
----------------------------------------------------------------------------------------- 
INNER JOIN btg_mapping_code
ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code
and btg_mapping_code.source_id = 3
and btg_mapping_code.type_id = 70
and btg_mapping_code.output_code = 'LDN'
----------------------------------------------------------------------------------------- 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam    
----------------------------------------------------------------------------------------- 
    INNER JOIN AFFECTATION
    ON AFFECTATION.ident = Instrument.affectation
    AND AFFECTATION.ident not IN (7)
-----------------------------------------------------------------------------------------  
    INNER JOIN     business_events
    ON             business_events.id = Trades.type
    
ORDER BY 1,9 DESC;

END

-- *****************************************************************
-- END OF: MO_INSERTIONS_EXEC
-- *****************************************************************

MO_INSERTIONS_EXEC;

  -- *****************************************************************
  -- Description: PROCEDURE MO_AMEND_DIV_PRIM
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 20 SEP 2015     Davi Xavier     Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE MO_AMEND_DIV_PRIM(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MO_AMEND_DIV_PRIM
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT  FUND_BOOK_STRATEGY.FUND_NAME                             FUND_name,
        FUND_BOOK_STRATEGY.BOOK_NAME                             Strategy_name,
        FUND_BOOK_STRATEGY.FOLDER_NAME                           FOLDER_name,
        ECONOMIC_CHANGES.REFCON                                  Trade_ID,
        ECONOMIC_CHANGES.SICOVAM                                 SICOVAM,  
        Instrument.REFERENCE                                     Instrument_Reference,
        Instrument.LIBELLE                                       Instrument_Name,
        histomvts.dateneg                                        d$Trade_Date,
        histomvts.dateval                                        d$Value_Date,
        CASE WHEN audit_mvt.DATEMODIF is null THEN To_char(sysdate,'DD-MON-YYYY HH:MM:SS') ELSE To_char(audit_mvt.DATEMODIF,'DD-MON-YYYY HH:MM:SS') END       Date_Modified,
        CASE WHEN trader.name is null THEN 'MO_ID not indentified in database, please check Sophis audit' ELSE trader.name END                                               USER_ID,
        CASE WHEN risk_user_profiles.profile_ident=4572 THEN 'MO amendment' ELSE '' END  Details,
        business_events.NAME                                     Busines_Event,
        ECONOMIC_CHANGES.cours                                   Price,
        ECONOMIC_CHANGES.quantite                                Qty,
        ECONOMIC_CHANGES.montant                                 Net_Amount
--***--        
FROM (
-- STEP 2 >> BELOW WE ARE CREATING A NEW TABLE WHICH CONSIDERS ONLY ECONOMIC CHANGES, DISREGARDING THE STATUS CHANGES AND ANY OTHER TICKET CHANGE,
--           GROUPING THE INFORMATION BELOW PER TRADE_ID, PRICE, QUANTITE AND AMOUNT, AND FIGURING OUT THE FIRST REGISTER OF ECONOMIC CHANGE 
SELECT    MIN(NEW_AUDIT_LDN.version)                                           VERSION,
          NEW_AUDIT_LDN.refcon,
          NEW_AUDIT_LDN.sicovam,
          NEW_AUDIT_LDN.cours,
          NEW_AUDIT_LDN.quantite,
          NEW_AUDIT_LDN.montant
          from (
          
-- STEP 1 >> BELOW WE ARE CREATING A NEW TEMPORARY TABLE IN ORDER TO ADD THE CURRENT ECONOMIC VALUES (FROM THE HISTOMVTS TABLE), ONCE THE LAST ECONOMIC CHANGE MADE IN THE TRADE DOESN'T APPEAR IN THE AUDIT.MVT TABLE
      SELECT min(audit_mvt.version) version,audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant
      from audit_mvt         
      WHERE audit_mvt.version >1 --dESREGARD THE INSERTIONS
--STEP 1.1 >> THE FINTER BELOW FILTER ONLY 1-) THE TRADES WITH ECONIMIC CHANGES 2-) MADE BY AN MO 3-) IN A LDN STRATEGY 4-) TODAY
      AND audit_mvt.REFCON IN (--After the coditions have been created by the tables "ecochanges1" ans "TRADE_IDs_LIST", filter only the trades which were 1-)Amended by a M.O.\2-)Today\3-)In a LDN strategy
                                select distinct TRADE_IDs_LIST.REFCON from (
                                -- The "TRADE_IDs_LISTt" add the information of which operator amended the ticket 
                                select ecochanges1.*,risk_user_profiles.profile_ident,audit_mvt.opcvm
                                
                                -- The "ecochanges1" table selects all economic changes   
                                from(SELECT min(audit_mvt.version) version,min(audit_mvt.datemodif) datemodif,audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 
                                from audit_mvt  
                                where audit_mvt.version >1 
                                group by audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant)ecochanges1 
                                
                                inner join audit_mvt 
                                on ecochanges1.version = audit_mvt.version 
                                and ecochanges1.refcon = audit_mvt.refcon 
                                
                                inner JOIN risk_user_profiles  
                                on audit_mvt.USERID=risk_user_profiles.user_ident
                                
                                Inner Join Business_Events
                                On  Business_Events.Id = audit_mvt.type
                                and audit_mvt.type IN (147,2,644) -- DIVIDEND,Coupon,Coupon Losses
                                
                                )TRADE_IDs_LIST 
                                INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO 
								WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                                ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADE_IDs_LIST.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 33 and btg_mapping_code.output_code = 'LDN' 
                                
                                where TRADE_IDs_LIST.profile_ident = 4572
                                and TRADE_IDs_LIST.datemodif > trunc(SYSDATE))

group by audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 

UNION
--STEP 2.2 -- ADDING THE INFORMATION FROM HISTOMVTS TABLE AS MENTIONED IN THE STEP 1
  select  1000000 VERSION,
          histomvts.refcon,
          histomvts.sicovam,
          histomvts.cours,
          histomvts.quantite,
          histomvts.montant    
          from histomvts
-- THE FILTER BELOW IS DIFFERENT FROM THE STEP 1.1.1 IN ORDER TO OPTIMIZE THE CODE
      WHERE histomvts.REFCON IN (--After all the coditions have been created by the tables "ecochanges1" ans "TRADE_IDs_LIST" filter only the trades which were 1)Amended by a M.O.\2)Today\In a LDN strategy
                                select distinct audit_mvt.REFCON from audit_mvt
                                
                                inner JOIN risk_user_profiles  
                                on audit_mvt.USERID=risk_user_profiles.user_ident
                                
                                INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY 
                                ON FUND_BOOK_STRATEGY.STRATEGY_ID = audit_mvt.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 33 and btg_mapping_code.output_code = 'LDN' 
                                
                                Inner Join Business_Events
                                On  Business_Events.Id =audit_mvt.type
                                and audit_mvt.type IN (147,2,644) -- DIVIDEND,Coupon,Coupon Losses
                                
                                where risk_user_profiles.profile_ident = 4572
                                and audit_mvt.datemodif > trunc(SYSDATE))

      )NEW_AUDIT_LDN
-- STEP 1 END
      GROUP BY NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant
--***--
-- STEP 2 END
      )ECONOMIC_CHANGES
      
      LEFT JOIN       audit_mvt
      ON              audit_mvt.REFCON = ECONOMIC_CHANGES.REFCON
      AND             audit_mvt.version = ECONOMIC_CHANGES.VERSION
      
      LEFT JOIN       riskusers trader
      ON              trader.ident = audit_mvt.USERID --FIND THE NAME OF THE USER WICH MADE THE AMENDMENT

      LEFT JOIN       risk_user_profiles 
      ON              audit_mvt.USERID=risk_user_profiles.user_ident
      
      Inner join   histomvts
      on ECONOMIC_CHANGES.refcon= histomvts.refcon
  
    inner JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                        , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 5, 6)     AS FOLDER_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 5, 6)      AS FOLDER_NAME
                        , FOLIO.ident                                                             AS STRATEGY_ID
                        , FOLIO.name                                                              AS STRATEGY_NAME
                        , level
                    FROM        FOLIO
                    WHERE       LEVEL >= 4
                    START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414,90565) 
                    CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
      ON            FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
 ----------------------------------------------------------------------------------------- 
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam= histomvts.sicovam    
-----------------------------------------------------------------------------------------     
      INNER JOIN 
      --IF ANY MAINTENANCE IS NECESSARY, THE CODE BELOW IS EXACTLY THE CODE BETWEEN THE SYMBOL --***-- ABOVE, EXCEPT FOR THE GROUP BY AND COUNTER IN THE SELECT
      (SELECT  DISTINCT ECONOMIC_CHANGES2.refcon,COUNT(ECONOMIC_CHANGES2.refcon) COUNTER FROM (SELECT MIN(NEW_AUDIT_LDN.version) VERSION, NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant from (SELECT min(audit_mvt.version) version,audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt WHERE audit_mvt.version >1 AND audit_mvt.REFCON IN (select distinct TRADE_IDs_LIST.REFCON from (select ecochanges1.*,risk_user_profiles.profile_ident,audit_mvt.opcvm from(SELECT min(audit_mvt.version) version,min(audit_mvt.datemodif) datemodif,audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant from audit_mvt where audit_mvt.version >1 group by audit_mvt.refcon, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant)ecochanges1 inner join audit_mvt on ecochanges1.version = audit_mvt.version and ecochanges1.refcon = audit_mvt.refcon inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident Inner Join Business_Events On  Business_Events.Id = audit_mvt.type and audit_mvt.type IN (147,2,644))TRADE_IDs_LIST INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADE_IDs_LIST.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 33 and btg_mapping_code.output_code = 'LDN' where TRADE_IDs_LIST.profile_ident = 4572 and TRADE_IDs_LIST.datemodif > trunc(SYSDATE)) group by audit_mvt.refcon,audit_mvt.SICOVAM, audit_mvt.cours, audit_mvt.quantite, audit_mvt.montant 
      UNION select  1000000 VERSION,histomvts.refcon, histomvts.sicovam,histomvts.cours,histomvts.quantite,histomvts.montant from histomvts WHERE histomvts.REFCON IN (select distinct audit_mvt.REFCON from audit_mvt inner JOIN risk_user_profiles on audit_mvt.USERID=risk_user_profiles.user_ident INNER JOIN (SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID, CONNECT_BY_ROOT(FOLIO.name)AS TOP_FUND_NAME, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID, FOLIO.ident AS STRATEGY_ID, level FROM FOLIO WHERE LEVEL >= 4 START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = audit_mvt.OPCVM INNER JOIN btg_mapping_code ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code and btg_mapping_code.source_id = 3 and btg_mapping_code.type_id = 33 and btg_mapping_code.output_code = 'LDN' Inner Join Business_Events On  Business_Events.Id =audit_mvt.type and audit_mvt.type IN (147,2,644) where risk_user_profiles.profile_ident = 4572 and audit_mvt.datemodif > trunc(SYSDATE)))NEW_AUDIT_LDN GROUP BY NEW_AUDIT_LDN.refcon,NEW_AUDIT_LDN.sicovam,NEW_AUDIT_LDN.cours,NEW_AUDIT_LDN.quantite,NEW_AUDIT_LDN.montant)ECONOMIC_CHANGES2 GROUP BY ECONOMIC_CHANGES2.refcon
      )REPLICA_OF_ECONOMIC_CHANGES
      ON ECONOMIC_CHANGES.refcon= REPLICA_OF_ECONOMIC_CHANGES.refcon
   
      INNER JOIN     business_events
      ON             business_events.id = histomvts.type
    
where REPLICA_OF_ECONOMIC_CHANGES.counter > 1
order by 4,10
;

END

-- *****************************************************************
-- END OF: MO_AMEND_DIV_PRIM
-- *****************************************************************

MO_AMEND_DIV_PRIM;

  -- *****************************************************************
  -- Description: PROCEDURE MO_INSERTIONS_PRIM
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 05 OCT 2015     Davi Xavier     Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE MO_INSERTIONS_PRIM(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: MO_INSERTIONS_PRIM
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT  FUND_NAME                             FUND_name,
        BOOK_NAME                             Strategy_name,
        FOLDER_NAME                           FOLDER_name,
        insertion.refcon                      Trade_ID,
        Instrument.sicovam                    sicovam,
        Instrument.REFERENCE                  Instrument_Reference,
        Instrument.reference                  Instrument_Name,
        TRADES.dateneg                        d$Trade_Date,
        TRADES.dateval                        d$Value_Date,
        to_char(insertion.datemodif,'DD-MON-YYYY HH:MM:SS')                   Insertion_Date,
        trader.name                           USER_ID,
        business_events.NAME                  Busines_Event,
        'MO insertion'                        Details,
        TRADES.cours                          Current_Price,
        TRADES.quantite                       Current_QTY,
        TRADES.montant                        Current_Net_Amount

FROM (select audit_mvt.refcon,
audit_mvt.cours,
audit_mvt.quantite,
audit_mvt.montant,
audit_mvt.datemodif,
audit_mvt.USERID
from audit_mvt
INNER JOIN risk_user_profiles 
on audit_mvt.USERID=risk_user_profiles.user_ident 
and risk_user_profiles.profile_ident=4572 
where audit_mvt.version = 1 
AND TRUNC(audit_mvt.datemodif) = TRUNC(SYSDATE))insertion

-----------------------------------------------------------------------------------------
--  FILTER ONLY CHANGE FOR THE EXECUTION BOOK
-----------------------------------------------------------------------------------------
INNER JOIN HISTOMVTS TRADES
ON insertion.REFCON = TRADES.REFCON

INNER JOIN      riskusers trader
ON              trader.ident = insertion.USERID

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 5, 6)     AS FOLDER_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 5, 6)      AS FOLDER_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565) -- 
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
-----------------------------------------------------------------------------------------   
--ONLY FOR LDN STRATEGIES
----------------------------------------------------------------------------------------- 
INNER JOIN btg_mapping_code
ON FUND_BOOK_STRATEGY.BOOK_ID = btg_mapping_code.input_code
and btg_mapping_code.source_id = 3
and btg_mapping_code.type_id = 33
and btg_mapping_code.output_code = 'LDN'
----------------------------------------------------------------------------------------- 
    INNER JOIN      titres Instrument
    ON              Instrument.sicovam= Trades.sicovam    
----------------------------------------------------------------------------------------- 
    INNER JOIN AFFECTATION
    ON AFFECTATION.ident = Instrument.affectation
    AND AFFECTATION.ident not IN (7)
-----------------------------------------------------------------------------------------  
    INNER JOIN     business_events
    ON             business_events.id = Trades.type
    and            Trades.type IN (147,2,644) -- DIVIDEND,Coupon,Coupon Losses
    
ORDER BY 1,9 DESC;

END

-- *****************************************************************
-- END OF: MO_INSERTIONS_PRIM
-- *****************************************************************

MO_INSERTIONS_PRIM;

  -- *****************************************************************
  -- Description: PROCEDURE BOXED_OPT_UND_EQ_ENERGYOP
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 05 OCT 2015     Davi Xavier			Created.
  -- 18 Mar 2016     Gustavo Binnie			PMOG-930 - Changed Name and scope to EQ Energy Oportunities
  -- *****************************************************************
  
PROCEDURE BOXED_OPT_UND_EQ_ENERGYOP(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: BOXED_OPT_UND_EQ_ENERGYOP
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

Select LISTED_OPTIONS_POSITION.Fund
      ,LISTED_OPTIONS_POSITION.Strategy
      ,LISTED_OPTIONS_POSITION.Instrument_sicovam
      ,LISTED_OPTIONS_POSITION.Instrument_reference
      ,LISTED_OPTIONS_POSITION.Underlying_Reference
      ,LISTED_OPTIONS_POSITION.Underlying_Sicovam
      ,LISTED_OPTIONS_POSITION.Instrument_Position
      ,LISTED_OPTIONS_POSITION.No_Options_to_be_exercised
      ,UNDERLYING_POS.Underlying_Position

from 
(SELECT 
  FUND_BOOK_STRATEGY.Fund_NAME                              Fund
, FUND_BOOK_STRATEGY.BOOK_NAME                              Strategy
, HISTOMVTS.sicovam                                         Instrument_sicovam
, TITRES.Reference                                          Instrument_reference
, btg_get_underlying_reference(histomvts.sicovam)           Underlying_Reference
, BTG_GET_UNDERLYING_SICOVAM(histomvts.sicovam)					    Underlying_Sicovam
, SUM(HISTOMVTS.quantite)                                   Instrument_Position
, SUM(HISTOMVTS.quantite)*TITRES.QUOTITE                    No_Options_to_be_exercised

FROM HISTOMVTS 
                              
INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              
INNER JOIN BUSINESS_EVENTS
ON HISTOMVTS.type = BUSINESS_EVENTS.id                            
AND BUSINESS_EVENTS.compta = 1  --position affecting trades only

INNER JOIN TIERS
ON TIERS.ident = HISTOMVTS.depositaire

INNER JOIN TITRES
ON titres.sicovam = HISTOMVTS.sicovam

INNER JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation
AND AFFECTATION.ident IN (10)

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
AND FUND_BOOK_STRATEGY.book_name in ('EQ Energy Opportunities')
GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam, TITRES.Reference, btg_get_underlying_reference(histomvts.sicovam),TITRES.QUOTITE
HAVING SUM(HISTOMVTS.quantite) !=0)LISTED_OPTIONS_POSITION

LEFT JOIN

(SELECT 
  FUND_BOOK_STRATEGY.Fund_NAME                              Fund
, FUND_BOOK_STRATEGY.BOOK_NAME                              Strategy
, HISTOMVTS.sicovam                                         sicovam
, SUM(HISTOMVTS.quantite)                                   Underlying_Position

FROM HISTOMVTS 
                              
INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident)                          AS TOP_FUND_ID
, CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
, REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
, FOLIO.ident                                                             AS STRATEGY_ID
, FOLIO.name                                                              AS STRATEGY_NAME
, level
FROM        FOLIO
WHERE       LEVEL >= 4
START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM
                              
INNER JOIN BUSINESS_EVENTS
ON HISTOMVTS.type = BUSINESS_EVENTS.id                            
AND BUSINESS_EVENTS.compta = 1  --position affecting trades only

INNER JOIN TIERS
ON TIERS.ident = HISTOMVTS.depositaire

INNER JOIN TITRES
ON titres.sicovam = HISTOMVTS.sicovam

WHERE HISTOMVTS.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
AND FUND_BOOK_STRATEGY.book_name in ('EQ Energy Opportunities')
GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, HISTOMVTS.sicovam)UNDERLYING_POS
ON LISTED_OPTIONS_POSITION.Underlying_Sicovam = UNDERLYING_POS.sicovam 
AND LISTED_OPTIONS_POSITION.Fund = UNDERLYING_POS.Fund
AND LISTED_OPTIONS_POSITION.Strategy = UNDERLYING_POS.Strategy

order by 1;

END

-- *****************************************************************
-- END OF: BOXED_OPT_UND_EQ_ENERGYOP
-- *****************************************************************

BOXED_OPT_UND_EQ_ENERGYOP;

  -- *****************************************************************
  -- Description: PROCEDURE AUDIT_TRAIL_NEW_USER
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 05 OCT 2015     Davi Xavier     Created.
  -- *****************************************************************
  
PROCEDURE AUDIT_TRAIL_NEW_USER(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: AUDIT_TRAIL_NEW_USER
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT RISKUSERS.NAME                                            User_Name,
       TO_CHAR(BTG_AUDIT_RISKUSERS.AUDIT_DATE,'DD-MM-YYYY')      Date_Created ,
       BTG_AUDIT_RISKUSERS.AUDIT_NETWORK_USER                    Created_By,
       PROFILE.NAME                                              Profile,
       USERINFOS.COUNTRY                                         BTG_Location
       
FROM BTG_AUDIT_RISKUSERS 

LEFT JOIN   RISKUSERS
ON          RISKUSERS.IDENT =  BTG_AUDIT_RISKUSERS.IDENT
                                
INNER JOIN  RISK_USER_PROFILES
ON          RISKUSERS.IDENT = RISK_USER_PROFILES.USER_IDENT

INNER JOIN   RISKUSERS PROFILE
ON           RISKUSERS.GIDENT = PROFILE.IDENT

INNER JOIN   USERINFOS
ON           USERINFOS.IDENT = RISKUSERS.IDENT
                                
WHERE   AUDIT_EVENT = 'INSERT'
AND     PROFILE.GIDENT IN (4572,4567); --'OPERATIONS_TD','FRONT-OFFICE'

END

-- *****************************************************************
-- END OF: AUDIT_TRAIL_NEW_USER
-- *****************************************************************

AUDIT_TRAIL_NEW_USER;

-- *****************************************************************
  -- Description: PROCEDURE LATE_BOOKINGS_NEOVEST
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 14 OCT 2015     Gustavo Binnie		    Created.
  -- 19 NOV 2015     Gustavo Binnie		    PMOG-870
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE LATE_BOOKINGS_NEOVEST(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: LATE_BOOKINGS_NEOVEST
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

	SELECT DISTINCT 		  histomvts.refcon 							Trade_ID
							, histomvts.dateneg 						Trade_Date
							, FUND_BOOK_STRATEGY.Fund_NAME 				Fund
							, FUND_BOOK_STRATEGY.BOOK_NAME 				Strategy
							, FUND_BOOK_STRATEGY.STRATEGY_NAME 			Folio
							, PB.NAME									Depositary
							, titres.reference      					Instrument_Reference
							, case when HISTOMVTS.BACKOFFICE IN (11,13,17,26,27,192,220,248,252) then NULL else HISTOMVTS.cours end Price
							, case when last_day.quantite is null then 'New Trade' else to_char(last_day.quantite) end 								   Previous_Quantity
							, case when HISTOMVTS.BACKOFFICE IN (11,13,17,26,27,192,220,248,252) then 'Cancelled' else to_char(histomvts.quantite) end Quantity

    FROM HISTOMVTS
    INNER JOIN
    (  
					SELECT            AUDIT_MVT.VERSION
									, AUDIT_MVT.DATEMODIF
									, AUDIT_MVT.REFCON
									, AUDIT_MVT.COURS
									, AUDIT_MVT.QUANTITE
									, AUDIT_MVT.MONTANT
									, AUDIT_MVT.BACKOFFICE
									, ROW_NUMBER() OVER (PARTITION BY AUDIT_MVT.REFCON ORDER BY AUDIT_MVT.VERSION) ORDER_N                                
					FROM AUDIT_MVT 
					INNER JOIN 				HISTOMVTS
					ON 						HISTOMVTS.REFCON 	= AUDIT_MVT.REFCON
					INNER JOIN 				TITRES
					ON 						HISTOMVTS.SICOVAM 	= TITRES.SICOVAM
					WHERE 					(AUDIT_MVT.DATEMODIF > (TRUNC(SYSDATE) +(5/24)) AND TITRES.TYPE <> 'F' ) 
											OR                                
											(AUDIT_MVT.DATEMODIF > (TRUNC(SYSDATE-(22/24)) + (22/24)) AND TITRES.TYPE = 'F') 
    )LAST_DAY
    ON LAST_DAY.REFCON = HISTOMVTS.REFCON
    AND LAST_DAY.ORDER_N =1 
	INNER JOIN 
	( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                        , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                        , FOLIO.ident                                                             AS STRATEGY_ID
                        , FOLIO.name                                                              AS STRATEGY_NAME
                        , level
                    FROM        FOLIO
                    WHERE       LEVEL >= 4
                    START       WITH FOLIO.ident IN (14414,90565) -- (PCKG_BTG.FOLIO_EXECUTION_BOOK) --EXECUTION BOOK 
                    CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
    ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
	INNER JOIN BUSINESS_EVENTS BE
	ON BE.ID = HISTOMVTS.TYPE
	AND BE.COMPTA = 1
	INNER JOIN TITRES
	ON TITRES.SICOVAM = HISTOMVTS.SICOVAM
	LEFT JOIN TIERS PB
	ON PB.IDENT		  = HISTOMVTS.DEPOSITAIRE
	WHERE 
	(
	( HISTOMVTS.DATENEG     < TRUNC(SYSDATE) AND TITRES.TYPE <> 'F')
	OR
	( HISTOMVTS.DATENEG     < TRUNC(SYSDATE-(22/24)+1) AND TITRES.TYPE = 'F')
	)
	AND EXISTS 
	(                                                                                                                                                    
                    SELECT 1 FROM FOLIO                               
                    WHERE IDENT  IN (    SELECT DISTINCT EXT_ENT.ENTRYPT FROM EXTRACTION
                                         LEFT JOIN EXTRACTION_ENTRYPTS EXT_ENT
                                         ON EXTRACTION.ID = EXT_ENT.CODE
                                         WHERE extraction.NAME like 'Neovest%' )                                                                                    
                    START WITH IDENT = histomvts.OPCVM                      
                    CONNECT BY PRIOR    MGR = IDENT                 
    )
	AND 
	(
		HISTOMVTS.QUANTITE <> LAST_DAY.QUANTITE
		OR
		(HISTOMVTS.BACKOFFICE IN (11,13,17,26,27,192,220,248,252) AND LAST_DAY.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252))
		OR
		LAST_DAY.QUANTITE IS NULL
	)
	ORDER BY 1;

END

-- *****************************************************************
-- END OF: LATE_BOOKINGS_NEOVEST
-- *****************************************************************

LATE_BOOKINGS_NEOVEST;

-- *****************************************************************
  -- Description: PROCEDURE EXPIRY_NDF_FIXING
  --
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 28 OCT 2015     Oliver South		    Created.
  -- 28 OCT 2015     Davi Xavier		    Arranged the release with AS
  -- *****************************************************************
  
PROCEDURE EXPIRY_NDF_FIXING(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: EXPIRY_NDF_FIXING
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT      
                FUND_BOOK_STRATEGY.Fund_NAME        Fund
              , FUND_BOOK_STRATEGY.BOOK_NAME        Strategy
              , FUND_BOOK_STRATEGY.STRATEGY_NAME    Folio
              ,	HISTOMVTS.sicovam                   Sicovam
              , HISTOMVTS.dateval                   d$Expiry
              , TITRES.libelle                      Name
              , SUM(HISTOMVTS.quantite)             n$NDF_Quantity
              , SUM(HISTOMVTS.montant)              n$Quantity
  
FROM          HISTOMVTS
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   HISTOMVTS.OPCVM

INNER JOIN     RISKUSERS 
ON             RISKUSERS.ident              = HISTOMVTS.operateur

INNER JOIN    TITRES
ON            TITRES.sicovam          = HISTOMVTS.sicovam

WHERE         TITRES.type = 'K' --NDFs
AND           HISTOMVTS.dateval = BTG_BUSINESS_DATE(TRUNC(SYSDATE),2) --2 business days from today
AND           HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --exclude cancelled trades
GROUP BY FUND_BOOK_STRATEGY.Fund_NAME, FUND_BOOK_STRATEGY.BOOK_NAME, FUND_BOOK_STRATEGY.STRATEGY_NAME, HISTOMVTS.sicovam, HISTOMVTS.dateval, TITRES.libelle
ORDER BY 4;

END

-- *****************************************************************
-- END OF: EXPIRY_NDF_FIXING
-- *****************************************************************

EXPIRY_NDF_FIXING;


-- *****************************************************************
  -- Description: PROCEDURE ACCRUED_DIVIDENDS_REC
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 4 NOV 2015		 Gustavo Binnie		    Created.
  -- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  -- *****************************************************************
  
PROCEDURE ACCRUED_DIVIDENDS_REC(p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- START OF: ACCRUED_DIVIDENDS_REC
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR
	SELECT histomvts.refcon				 || '-AD'															"TransactionReferenceNo"
			, CASE WHEN histomvts.quantite > 0 THEN 'B' WHEN histomvts.quantite < 0 THEN 'SS' ELSE '' END	"Buy/Sell"
			, 'NEW'																							"TradeStatus"
			, FUND_BOOK_STRATEGY.Fund_NAME 																	"FundName"
			, BO_TREASURY_ACCOUNT.ACCOUNT_NAME || '-AD'														"BankAccountID"
			, TO_CHAR(HISTOMVTS.dateval,'YYYY-MM-DD')    													"SettlementDate"
			, TO_CHAR(TRUNC(SYSDATE),'YYYY-MM-DD')															"PostDate"
			, HISTOMVTS.SICOVAM																				"SecurityID(Sicovam)"
			, sec.reference 																				"Reference"
			, cusip.value																					"Cusip"
			, sedol.value																					"Sedol"
			, ISIN.value																					"ISIN"      
			, CASE WHEN uf.Model='Ric' THEN RIC.SERVISEN when sec.type in ('A','F','O','I') then sec.reference WHEN SEC.TYPE = 'G' THEN UNDERLYING.REFERENCE ELSE '' END "Ticker" 
			, nvl(decode(undRef.Model,'Reference',underlying.REFERENCE,Und_ISIN.VALUE),' ')					"UnderlyingISIN"
			, SEC.libelle																					"SecurityDescription"
			, affectation.LIBELLE																			"SecurityType"
			, btg_get_instrument_type(histomvts.sicovam)													"SecurityTypeDescription"      
			, TO_CHAR(histomvts.dateneg,'YYYY-MM-DD')														"TradeDate"
			, round(nvl(histomvts.quantite * sec.nominal, 0),12)											"Nominal"
			, histomvts.quantite																			"Quantity"
			, histomvts.montant																				"NetAmountInBaseCCY"
			, '' "PriceInBaseCCY"
			, devise_to_str(histomvts.devisepay) "BaseCCY"
			, '' "NetAmountInLocalCCY"
			, round(histomvts.cours,12) "PriceInLocalCCY"
			, devise_to_str(sec.devisectt) "LocalCCY"
			, business_events.NAME "BusinessEvent"
			, histomvts.INFOSBACKOFFICE as "Comment"
			, CASE WHEN sec.type = 'A' THEN NULL ELSE sec.quotite END "ContractSize"
			, '' "Strike"
			, Trader.NAME as "Operator"
			, TO_CHAR(HISTOMVTS.dateval,'YYYY-MM-DD')    							"PaymentDate"
			, counterparty.NAME "Counterparty"
			, broker.NAME "Broker"
			, round(nvl((histomvts.quantite * histomvts.cours), 0),12)  "GrossAmountInSettlementCCY"
			, FUND_BOOK_STRATEGY.BOOK_NAME "TopStrategy"
			, histomvts.TAUXCHANGE "FXRate"
			, BlockTrade.block_id "ParentId"
		    , '' "FUT_Market"
			, '' "FUT_PutCall"
			, (histomvts.fraiscounterparty + histomvts.fraismarche + histomvts.fraiscourtage) "Fees"
			, BO_KERNEL_STATUS.NAME "BackOfficeStatus"
			, '' "Loanxid"
			, depositary.NAME "Depositary"
			, '' "Settlement Type"
			, CASE WHEN underlying.type = 'A' THEN NULL ELSE underlying.quotite END "Underlying Contract Size"
	
FROM histomvts
LEFT JOIN titres sec ON sec.sicovam = histomvts.sicovam
LEFT JOIN folio ON folio.ident = histomvts.opcvm
INNER JOIN business_events BE ON BE.id = HISTOMVTS.type

LEFT JOIN		tiers counterparty 
ON				counterparty.ident				= histomvts.contrepartie
LEFT JOIN		tiers broker 
ON				broker.ident					= histomvts.courtier
LEFT JOIN		tiers depositary 
ON				depositary.ident				= histomvts.depositaire
LEFT JOIN		affectation 
ON				affectation.ident				= sec.affectation
LEFT JOIN		BO_KERNEL_STATUS 
ON				BO_KERNEL_STATUS.id				= histomvts.backoffice
LEFT JOIN 		riskusers 						Trader 
ON 				Trader.ident 					=  histomvts.OPERATEUR
LEFT JOIN 		business_events 
ON 				business_events.id 				= histomvts.type
LEFT JOIN		titres Underlying
ON				Underlying.sicovam = (case when sec.type='A' then sec.base1 when sec.type='D' then sec.codesj when sec.type='S' then decode(sec.jambe1,1,sec.j2refcon2,decode(sec.j1refcon2,0,sec.j2refcon2,sec.j1refcon2)) else decode(sec.code_emet,0,decode(sec.codesj,0,sec.codesj2,sec.codesj),sec.code_emet) end)
left join		EXTRNL_REFERENCES_INSTRUMENTS 	Und_ISIN
ON 				Und_ISIN.SOPHIS_IDENT 			= Underlying.SICOVAM 
AND 			Und_ISIN.REF_IDENT				=	1
left join 		references undRef 
on 				undRef.allotment				= Underlying.affectation 
and 			undRef.reference				='ISIN'
LEFT JOIN 		ric 
ON 				ric.sicovam						= CASE WHEN SEC.TYPE = 'G' THEN Underlying.SICOVAM ELSE sec.sicovam END
left join 		references uf 
on 				uf.allotment = CASE WHEN SEC.TYPE = 'G' THEN sec.AFFECTATION ELSE sec.affectation END
and 			uf.reference='TICKER'
LEFT JOIN 		extrnl_references_instruments 	sedol
ON 				sedol.sophis_ident      = CASE WHEN SEC.TYPE = 'G' THEN Underlying.SICOVAM ELSE sec.sicovam END
and 			sedol.ref_ident 						= 2
LEFT JOIN 		extrnl_references_instruments 	CUSIP
ON 				CUSIP.sophis_ident      = CASE WHEN SEC.TYPE = 'G' THEN Underlying.SICOVAM ELSE sec.sicovam END
AND 			CUSIP.ref_ident 				= 3
LEFT JOIN 		extrnl_references_instruments 	ISIN
ON 				ISIN.sophis_ident       = CASE WHEN SEC.TYPE = 'G' THEN Underlying.SICOVAM ELSE sec.sicovam END
AND 			ISIN.ref_ident 					= 1
LEFT JOIN TA_BLOCK_TO_GENERATED BlockTrade
on        BlockTrade.generated_id				= histomvts.sicovam
LEFT JOIN BO_TREASURY_ACCOUNT
ON        BO_TREASURY_ACCOUNT.DEPOSITARY		= depositary.ident
AND       BO_TREASURY_ACCOUNT.CCY				= histomvts.devisepay
AND       BO_TREASURY_ACCOUNT.ENTITY			= histomvts.ENTITE
INNER JOIN (
    SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                        ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME                          
                        ,FOLIO.ident AS STRATEGY_ID
                        ,FOLIO.NAME AS STRATEGY_NAME
                        ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 4 START
            WITH FOLIO.ident IN (14414,90565) --Primary funds
                        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
WHERE histomvts.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
and histomvts.type = 147
and trunc(histomvts.DATENEG) < trunc(sysdate)
and trunc(HISTOMVTS.dateval) >= trunc(sysdate)
and depositary.name not like '%-2689-%'
;

END

-- *****************************************************************
-- END OF: ACCRUED_DIVIDENDS_REC
-- *****************************************************************

ACCRUED_DIVIDENDS_REC;


-- *****************************************************************
-- Description:     PROCEDURE  FWD_CASH_SETTL
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 20 dec 2015      Davi Xavier            Created
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- ***************************************************************** 
PROCEDURE FWD_CASH_SETTL (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: FWD_CASH_SETTL
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT      
						  FUND_BOOK_STRATEGY.BOOK_NAME          Strategy_name
						, FUND_BOOK_STRATEGY.Fund_NAME          Fund_name
						, HISTOMVTS.sicovam                        Sicovam
						, HISTOMVTS.refcon                         Trade_Id
						, RISKUSERS.name                           Trader
						, TITRES.libelle                    Instrument_Name
						, TITRES.reference                  Instrument_Ref
						, TRUNC(HISTOMVTS.DATEVAL)                 d$Value_Date
            , HISTOMVTS.montant                     Cash
            , DEVISE_TO_STR(HISTOMVTS.devisepay)      Currency
						, HISTOMVTS.QUANTITE                       n$Quantity
            , BUSINESS_EVENTS.name
     FROM       HISTOMVTS
     INNER JOIN ( 
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH          FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565)--Primary funds
                CONNECT BY PRIOR    FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =   HISTOMVTS.OPCVM
    INNER JOIN      TITRES
    ON              TITRES.sicovam          = HISTOMVTS.sicovam
    INNER JOIN      RISKUSERS
    ON              RISKUSERS.ident                = HISTOMVTS.operateur
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id          = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1 -- position affecting results
    AND             BUSINESS_EVENTS.name != 'Currency'
    WHERE           HISTOMVTS.backoffice     NOT IN (192,11,13,17,26,27,220,248,252)
    AND             HISTOMVTS.DATEVAL > TRUNC(SYSDATE+30)
    AND             HISTOMVTS.montant <>0
    ORDER BY        8 ASC;
		
END

FWD_CASH_SETTL;

-- *****************************************************************
-- END OF: FWD_CASH_SETTL
-- ***************************************************************** 


-- *****************************************************************
-- Description:     PROCEDURE  FXO_CLOSE_POS_EXP
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 20 dec 2015      Davi Xavier            Created
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- ***************************************************************** 
PROCEDURE FXO_CLOSE_POS_EXP (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: FXO_CLOSE_POS_EXP
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT        FUND_BOOK_STRATEGY.Fund_NAME             Fund_name
            , AFFECTATION.libelle                      Instrument_Allotment
						, HISTOMVTS.sicovam                        Sicovam
						, TITRES.libelle                           Instrument_Name
						, TITRES.reference                         Instrument_Ref
            , CASE WHEN TITRES.type ='N' then TITRES.echeance ELSE TITRES.finper end  d$Maturity_Date
            , BROKER.NAME                              Broker
            , DEPOSITARY.NAME                          Depositary
						, SUM(HISTOMVTS.QUANTITE)                  n$Position

     FROM       HISTOMVTS
     INNER JOIN ( 
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level
                FROM FOLIO
                WHERE LEVEL >= 4
                START WITH          FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) -- (14414)--Primary funds
                CONNECT BY PRIOR    FOLIO.ident   = FOLIO.mgr  
              ) FUND_BOOK_STRATEGY
    ON          FUND_BOOK_STRATEGY.STRATEGY_ID    =   HISTOMVTS.OPCVM
    
    INNER JOIN      TIERS DEPOSITARY 
    ON              DEPOSITARY.IDENT            = HISTOMVTS.DEPOSITAIRE
    INNER JOIN		  TIERS BROKER 
    ON				      broker.ident					      = HISTOMVTS.courtier
    INNER JOIN      TITRES
    ON              TITRES.sicovam              = HISTOMVTS.sicovam
    INNER JOIN      AFFECTATION
    ON              AFFECTATION.ident = TITRES.affectation
    AND             AFFECTATION.ident IN (23) --	FX Options
    INNER JOIN      RISKUSERS
    ON              RISKUSERS.ident             = HISTOMVTS.operateur
    INNER JOIN      BUSINESS_EVENTS
    ON              BUSINESS_EVENTS.id          = HISTOMVTS.type
    AND             BUSINESS_EVENTS.compta = 1 -- position affecting results
    
    WHERE           HISTOMVTS.backoffice     NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    
    GROUP BY        FUND_BOOK_STRATEGY.Fund_NAME, AFFECTATION.libelle, HISTOMVTS.sicovam, TITRES.libelle, TITRES.reference, CASE WHEN TITRES.type ='N' then TITRES.echeance ELSE TITRES.finper end, BROKER.NAME, DEPOSITARY.NAME
    HAVING          SUM(HISTOMVTS.QUANTITE) =0
    AND             TRUNC(sysdate) <= (CASE WHEN TITRES.type ='N' then TITRES.echeance ELSE TITRES.finper end) --Maturity date not reached yet
    ORDER BY        2,6;
		
END

FXO_CLOSE_POS_EXP;

-- *****************************************************************
-- END OF: AMEND_INS_AFT_CKECKMO
-- ***************************************************************** 

-- *****************************************************************
-- Description:     PROCEDURE  AMEND_INS_AFT_CKECKMO
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 18 FEB 2015      Davi Xavier            Created
-- ***************************************************************** 
PROCEDURE AMEND_INS_AFT_CKECKMO (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: AMEND_INS_AFT_CKECKMO
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT * FROM
(SELECT CHECKED_MO_DATA.REFCON, CHECKED_MO_DATA.SICOVAM, INTRUMENT_AMEND.REFERENCE,CHECKED_MO_DATA.CHECKED_MO_DATE, INTRUMENT_AMEND.INST_MODIF_DATE,           CASE 
WHEN (CHECKED_MO_DATA.CHECKED_MO_DATE < INTRUMENT_AMEND.INST_MODIF_DATE) THEN 'CHECK' ELSE 'IGNORE'
END CHECKING

FROM

(SELECT HISTOMVTS.REFCON, HISTOMVTS.SICOVAM, MAX(AUDIT_MVT.DATEMODIF) CHECKED_MO_DATE

FROM HISTOMVTS

INNER JOIN AUDIT_MVT
ON AUDIT_MVT.REFCON = HISTOMVTS.REFCON

INNER JOIN TITRES
on HISTOMVTS.SICOVAM = TITRES.SICOVAM

WHERE  titres.type in ('S','W','F','D')
AND    titres.affectation in (3,24,31,48,33,1000)
AND     HISTOMVTS.dateneg > trunc(sysdate-1)
AND     HISTOMVTS.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252) -- exclude cancelled trades
AND     HISTOMVTS.BACKOFFICE not in (260,262,266,186,19,264,8,250,190)	--Unallocated,Allocated OK,In Breach,TA Accepted / Pending MO,Modified FM / Pending MO,Review Required,Checked FM,TA Checked MO / Modified,TA Modified / Pending MO

GROUP BY HISTOMVTS.REFCON, HISTOMVTS.SICOVAM
)CHECKED_MO_DATA

------------------------------------------------------------------------------
LEFT JOIN
-------------------------------------------------------------------------------

(select  titres.sicovam,
        titres.libelle      reference,
        num_to_date(trunc(infos_histo_KEYS.modifydate))  INST_MODIF_DATE

from titres 

INNER JOIN (
  SELECT infos_histo.sicovam AS sicovam
  , MAX(infos_histo.date_validite) AS modifydate
  , infos_histo.type_table as typetable
  FROM infos_histo
  where infos_histo.modif !=1 and infos_histo.type_table=3
  group by infos_histo.sicovam,infos_histo.type_table
) infos_histo_KEYS
ON infos_histo_KEYS.sicovam = titres.sicovam

INNER JOIN 
histomvts Trades
on Trades.sicovam=titres.sicovam

where  titres.type in ('S','W','F','D')
and    titres.affectation in (3,
24,
31,
48,
33,
1000)

Group by titres.sicovam,titres.libelle,num_to_date(trunc(infos_histo_KEYS.modifydate))
)INTRUMENT_AMEND
ON CHECKED_MO_DATA.SICOVAM = INTRUMENT_AMEND.SICOVAM)CLEAN

WHERE CLEAN.CHECKING = 'CHECK';
		
END

AMEND_INS_AFT_CKECKMO;

-- *****************************************************************
-- END OF: AMEND_INS_AFT_CKECKMO
-- ***************************************************************** 


-- *****************************************************************
-- Description: PROCEDURE FX_OPTION_NUM_OF_EXPIRIES
--
-- Author:     Jeff  Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 19/12/2016   Jeff Yu			Created.
-- 22/03/2017   Jeff Yu        Modified (PMGMPMO-217)
-- *****************************************************************
PROCEDURE FX_OPTION_NUM_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR


--FX Options - number of expiries in next year
SELECT 	t.finper                  "Expiry Date"
        ,count(distinct t.sicovam)            "Number of expiries"
        ,count(distinct tiers.NAME)       "Number of counterparties"
        
FROM titres t
inner join histomvts h
on t.SICOVAM=h.SICOVAM
left join tiers 
on tiers.ident=h.contrepartie
LEFT JOIN BO_KERNEL_STATUS_COMPONENT
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=h.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
WHERE t.affectation = 23 --FX Options
AND t.FINPER > sysdate --expire after today
AND t.FINPER <= (sysdate + 365) --expire before a year from now 
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null    
AND t.sicovam in (
                    select sicovam
                    from histomvts h
                    INNER JOIN (
                                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (
                                                      14414   --PCKG_BTG.FOLIO_PRIMARY_FUNDS
                                                      ,90565  --PCKG_BTG.FOLIO_UCITS_FUND
                                                    )
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                ) FUND_BOOK_STRATEGY
                      ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.opcvm --used to filter out parent trades
                      LEFT JOIN BO_KERNEL_STATUS_COMPONENT
                    ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=h.backoffice
                    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
                    INNER JOIN BUSINESS_EVENTS
                    ON BUSINESS_EVENTS.id = h.type
                    AND BUSINESS_EVENTS.compta = 1      
                     where BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades from open positions
                    GROUP BY sicovam
                    having sum(h.quantite) <> 0 --instrument with open positions
                  )
GROUP BY t.FINPER
ORDER BY t.FINPER;

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END   FX_OPTION_NUM_OF_EXPIRIES;
-- *****************************************************************
-- END OF: FX_OPTION_NUM_OF_EXPIRIES
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE FX_OPTION_LIST_OF_EXPIRIES
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 19/12/2016   Jeff Yu			Created.
-- 22/03/2017   Jeff Yu        Modified (PMGMPMO-217)
-- *****************************************************************
PROCEDURE FX_OPTION_LIST_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR


--FX Options - list of expiries in next year
SELECT 	DISTINCT t.FINPER                 "Expiry Date"
        ,t.sicovam                     "Sicovam"
        ,t.libelle                    "Instrument Name"
        ,t.reference                  "Instrument Reference"
        ,devise_to_str(t.devisectt)   "Currency"
        ,tiers.NAME       "Counterparty Name"

FROM titres t
inner join histomvts h
on t.SICOVAM=h.SICOVAM
left join tiers 
on tiers.ident=h.contrepartie
LEFT JOIN BO_KERNEL_STATUS_COMPONENT
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=h.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
WHERE t.affectation = 23 --FX Options
AND t.FINPER > sysdate --expire after today
AND t.FINPER <= (sysdate + 365) --expire before a year from now 
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  
AND t.sicovam in (
                    select sicovam
                    from histomvts h
                    INNER JOIN (
                                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (
                                                      14414   --PCKG_BTG.FOLIO_PRIMARY_FUNDS
                                                      ,90565  --PCKG_BTG.FOLIO_UCITS_FUND
                                                    )
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                ) FUND_BOOK_STRATEGY
                      ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.opcvm --used to filter out parent trades
                    LEFT JOIN BO_KERNEL_STATUS_COMPONENT
                    ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=h.backoffice
                    AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
                    INNER JOIN BUSINESS_EVENTS
                    ON BUSINESS_EVENTS.id = h.type
                    AND BUSINESS_EVENTS.compta = 1                  
                    where BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades from open positions
                    GROUP BY sicovam
                    having sum(h.quantite) <> 0 --instrument with open positions
                  )

ORDER BY t.FINPER, t.sicovam, tiers.NAME;

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	END    FX_OPTION_LIST_OF_EXPIRIES;
-- *****************************************************************
-- END OF: FX_OPTION_LIST_OF_EXPIRIES
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE ESPEED_BROKERTEC_ETRADES
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 20/04/2017   Jeff Yu			Created. (PMOG-1112)
-- *****************************************************************
PROCEDURE ESPEED_BROKERTEC_ETRADES
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

SELECT
                          trades.refcon                    tradeID
                         ,fund.name                        Fund
                         ,fund_strategy.name               Fund_Strategy
                         ,strategy.name                    Strategy
                         ,PrimeBroker.name                 Depositary
                         ,trader.name                      Trader
                         ,Trades.sicovam				   Sicovam
                         ,Instrument.reference             REPO_Reference
                         ,trunc(Trades.DATENEG)            TradeDate
                         ,trunc(Trades.DATEVAL)            ValueDate

      FROM            histomvts Trades       
      INNER JOIN      business_events
      ON              business_events.id                            = Trades.type      
      INNER JOIN      devisev2 Currency
      ON              Currency.code                                 = Trades.devisepay      
      INNER JOIN      titres Instrument
      ON              Instrument.sicovam                            = Trades.sicovam       
      INNER JOIN      tiers PrimeBroker     
      ON              PrimeBroker.IDENT                             = Trades.DEPOSITAIRE      
      INNER JOIN  (
                      SELECT       folio.ident
                                  ,folio.name
                                  ,nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident)    parent_ident
                      FROM        folio
                      WHERE       level       > 2
                      START WITH  ident  in (12506,12642,62880,67092,93654) -- All Primary Funds except GEMM
        CONNECT BY  mgr         = prior ident
      ) strategy
      ON          strategy.ident            = Trades.opcvm
      INNER JOIN      folio fund_strategy
      ON              fund_strategy.ident   = strategy.parent_ident    
      INNER JOIN      tiers fund
      ON              fund.ident            = Trades.entite
      INNER JOIN      riskusers trader
      ON              trader.ident          = Trades.operateur      
      WHERE           trades.creation       = 2
	  AND           trunc(Trades.DATENEG) = BTG_BUSINESS_DATE(trunc(sysdate),-1)   ---Report trades booked on previous business day
      AND            ( 
                          trades.contrepartie IN (10004042,10004782) 
                          OR trades.courtier  IN (10004042,10004782)
                     )    
	  AND            TRADES.backoffice not in (11,13,17,26,27,192,220,248,252) ;

  EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    ESPEED_BROKERTEC_ETRADES;
-- *****************************************************************
-- END OF: ESPEED_BROKERTEC_ETRADES
-- *****************************************************************



-- *****************************************************************
-- Description: PROCEDURE CPTY_LEI
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 26/12/2017   Jeff Yu			Created. (PMOG-1178)
-- *****************************************************************
PROCEDURE CPTY_LEI
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select  distinct tiers.ident
,tiers.name  as counterparty_name
,tiers.reference 
,tiers.externref  as external_reference
,REGEXP_REPLACE
        (
        REGEXP_REPLACE( (
		case when (ESTCONTREPARTIE(tiers.options) != 1 and ESTCOURTIER(tiers.options) != 1) then 'Cpty or Broker Checkbox' ELSE NULL END || ',' ||
		case when (
         (FEE.MARKET_FEE='London' or FEE.FUTURE_FEE='London')
      and (tiers.lei is null or length(tiers.lei) != 20)  ----LEI is blank or length is incorrect
         ) then 'LEI' ELSE NULL END 
  ) 
          ,',+(,|$)','\1'),
          '^,'     )
     "MISSING_DATA"     
  
from tiers
left JOIN (
select tiers.ident,
case when market_fee.cnt > 0 then 'London' else 'Others' end as market_fee,
case when future_fee.cnt > 0 then 'London' else 'Others' end as future_fee
from tiers
left join (
select ident, count(*) as cnt from FRAISTIERS 
where ENTITY in (10012566,-1) -----London or All execution
group by ident
) market_fee
on market_fee.ident=tiers.ident
left join (
select ident, count(*) as cnt from MO_FRAIS 
where ENTITY in (10012566,-1) ----London or All Execution
group by ident
) future_fee
on future_fee.ident=tiers.ident

)  Fee
ON FEE.IDENT=TIERS.IDENT

where TIERS.MGR = 10007662  ------Counterparty Group
AND  (
         (ESTCONTREPARTIE(tiers.options) != 1 and ESTCOURTIER(tiers.options) != 1) -----Neither of Cpty nor Broker box are checked
   OR (
         (FEE.MARKET_FEE='London' or FEE.FUTURE_FEE='London')
      and (tiers.lei is null or length(tiers.lei) != 20)  ----LEI is blank or length is incorrect
         )
) ;        

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    CPTY_LEI;
-- *****************************************************************
-- END OF: CPTY_LEI
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE TRADE_NON_FO
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 29/12/2017   Jeff Yu			Created. (PMCMIFID2-49)
-- 20 JUN 2018  Jeff Yu    Modified (PMGMRISK-228)
-- 03 AUG 2018	Gustavo Binnie  Exclude Internal Transfers (PMOG-1254)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE TRADE_NON_FO
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select   trades.refcon as trade_id
, Fund_NAME
, BOOK_NAME
, titres.sicovam
, titres.reference
, trades.dateneg as d$trade_date
, BUSINESS_EVENTS.name  as  business_event
, RISKUSERS.name as trader

from HISTOMVTS trades
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 START
                                WITH FOLIO.ident IN (14414,90565)
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=trades.OPCVM
inner join titres
on titres.sicovam=trades.sicovam
INNER JOIN    BUSINESS_EVENTS
ON            BUSINESS_EVENTS.id  = trades.type
AND           BUSINESS_EVENTS.compta = 1 --position affecting tickets only
left join RISKUSERS
on RISKUSERS.ident=trades.OPERATEUR
inner join USERINFOS
on USERINFOS.ident=trades.OPERATEUR
and USERINFOS.country='UK'
WHERE trades.backoffice not in (192,11,13,17,26,27,220,248,252)
AND trades.type in (1,4,6,17,25,140,160,161,190,221,242,243,247,250,274,294,344,444,796,1196,1394,1444,1494)
AND RISKUSERS.gident != 4567 ------front office group
AND trades.COURTIER NOT IN (10010875,10010876) -- EXCLUDE INTERNAL TRANSFER (STRAT) / INTERNAL TRANSFER (INT)
AND trunc(trades.dateneg) >= trunc(sysdate) - 7
;

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    TRADE_NON_FO;
-- *****************************************************************
-- END OF: TRADE_NON_FO
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE UK_STRAT_MISS_DECISION_MAKER
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 29/12/2017   Jeff Yu			Created. (PMCMIFID2-50)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE UK_STRAT_MISS_DECISION_MAKER
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select distinct UK_Strat.input_code as folio_id
,Fund_NAME
,BOOK_NAME
from btg_mapping_code UK_Strat
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (14414,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.BOOK_ID=UK_Strat.input_code
where UK_Strat.source_id = 3
and UK_Strat.type_id = 33 
and UK_Strat.output_code = 'LDN'
and UK_Strat.input_code NOT IN (
select input_code
from btg_mapping_code where type_id = 79 and source_id=6)
;

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    UK_STRAT_MISS_DECISION_MAKER;
-- *****************************************************************
-- END OF: UK_STRAT_MISS_DECISION_MAKER
-- *****************************************************************

-- *****************************************************************
-- Description: PROCEDURE BASKET_INDEX_NO_COMP
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 08/01/2018   Jeff Yu			Created. (PMCMIFID2-55)
-- *****************************************************************
PROCEDURE BASKET_INDEX_NO_COMP
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select titres.sicovam, titres.reference
from titres
LEFT JOIN panier UNDERLYING_BASKET
ON UNDERLYING_BASKET.sicovam = titres.SICOVAM
WHERE titres.type = 'I'
AND titres.nbtitres = 131072 ----basket index
AND UNDERLYING_BASKET.SICOVAM IS NULL;

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    BASKET_INDEX_NO_COMP;
-- *****************************************************************
-- END OF: BASKET_INDEX_NO_COMP
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE CDS_MISS_ISIN
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 10/01/2018   Jeff Yu			Created. (PMCMIFID2-52)
-- 11/01/2018   Jeff Yu        Modified (PMCMIFID2-65)
-- 08/21/2018   Jeff Yu        modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE CDS_MISS_ISIN
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select titres.sicovam
, titres.reference
, titres.datefinal as d$maturity
from titres

INNER JOIN (
SELECT TITRES.SICOVAM, SUM(HISTOMVTS.QUANTITE) FROM TITRES 
INNER JOIN HISTOMVTS
ON TITRES.SICOVAM=HISTOMVTS.SICOVAM
INNER JOIN (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (14414,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=HISTOMVTS.OPCVM
INNER JOIN btg_mapping_code UK_Strat
ON STRATEGY.BOOK_ID=UK_Strat.input_code
and UK_Strat.source_id = 3
and UK_Strat.type_id = 33 
and UK_Strat.output_code = 'LDN'
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
AND BUSINESS_EVENTS.COMPTA = 1
WHERE HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND HISTOMVTS.dateneg <= TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM 
HAVING SUM(HISTOMVTS.QUANTITE) !=0 
) open_position
ON TITRES.SICOVAM=open_position.SICOVAM

LEFT JOIN TITRES UND_RATE1
ON UND_RATE1.TYPE = 'I'
AND UND_RATE1.SICOVAM = titres.j1refcon2

LEFT JOIN TITRES UND_RATE2
ON UND_RATE2.TYPE = 'I'
AND UND_RATE2.SICOVAM = titres.j2refcon2

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ES
ON ES.REF_IDENT=1 ----ISIN
AND ES.sophis_ident=TITRES.SICOVAM

where titres.type = 'S'
and titres.affectation=22 ------CDS
AND trunc(titres.datefinal) >= trunc(sysdate)  -----non-matured
AND DEVISE_TO_STR(titres.DEVISECTT) = 'EUR'
AND (UND_RATE1.TYPE = 'I' or UND_RATE2.TYPE = 'I')
AND round(MONTHS_BETWEEN(titres.datefinal, titres.emission)) = 63
AND ES.VALUE IS NULL;

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    CDS_MISS_ISIN;
-- *****************************************************************
-- END OF: CDS_MISS_ISIN
-- *****************************************************************


-- *****************************************************************
-- Description: PROCEDURE IRS_MISS_ISIN
--
-- Author:      Jeff Yu
--
-- Revision History
-- Date         Author				Reason for Change
-- ----------------------------------------------------------------
-- 10/01/2018   Jeff Yu			Created. (PMCMIFID2-52)
-- 11/01/2018   Jeff Yu        Modified (PMCMIFID2-65)
-- 08/21/2018   Jeff Yu        Modified (PMOGUCITS-60)
-- *****************************************************************
PROCEDURE IRS_MISS_ISIN
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
	BEGIN
  
    OPEN p_CURSOR FOR

select titres.sicovam
, titres.reference
, titres.datefinal as d$maturity
from titres

INNER JOIN (
SELECT TITRES.SICOVAM, SUM(HISTOMVTS.QUANTITE) FROM TITRES 
INNER JOIN HISTOMVTS
ON TITRES.SICOVAM=HISTOMVTS.SICOVAM
INNER JOIN (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (14414,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=HISTOMVTS.OPCVM
INNER JOIN btg_mapping_code UK_Strat
ON STRATEGY.BOOK_ID=UK_Strat.input_code
and UK_Strat.source_id = 3
and UK_Strat.type_id = 33 
and UK_Strat.output_code = 'LDN'
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
AND BUSINESS_EVENTS.COMPTA = 1
WHERE HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND HISTOMVTS.dateneg <= TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM 
HAVING SUM(HISTOMVTS.QUANTITE) !=0 
) open_position
ON TITRES.SICOVAM=open_position.SICOVAM

LEFT JOIN TITRES UND_RATE1
ON UND_RATE1.TYPE IN ('R') 
AND UND_RATE1.SICOVAM = titres.base1

LEFT JOIN TITRES UND_RATE2
ON UND_RATE2.TYPE IN ('R') 
AND UND_RATE2.SICOVAM = titres.base2

LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS ES
ON ES.REF_IDENT=1 ----ISIN
AND ES.sophis_ident=TITRES.SICOVAM

where titres.type = 'S'
and titres.affectation=24 ------IRS
AND trunc(titres.datefinal) >= trunc(sysdate)  -----non-matured
AND DEVISE_TO_STR(titres.DEVISECTT) in  ('EUR','USD')
and (UND_RATE1.sicovam IS NULL or UND_RATE2.sicovam IS NULL) -----floating vs fixed
and (titres.duree1 in (3,4) and titres.duree2 in (3,4)) ----coupon frequency is semi annual or annual
and  (decode(titres.unit1,0,titres.base1,titres.unit1) in (1,4,5,10,11,17) and decode(titres.unit2,0,titres.base2,titres.unit2) in (1,4,5,10,11,17)) -----coupon basis 
AND (
(DEVISE_TO_STR(titres.DEVISECTT) = 'EUR' AND ((
              (
              (
              BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  = '3MNTH' 
              )
              OR
              (
              BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  = '3MNTH' 
              )
              ) ----underlying rate tenor is 3M
      and  round(MONTHS_BETWEEN( titres.datefinal, titres.emission )) in (24,36,48,60,72,120,180,240,360) -----months between end date and start date
      )  ----underlying rate tenor is 3M
      OR ((
              (
              BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  = '6MNTH' 
              )
              OR
              (
              BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  = '6MNTH' 
              )
              ) ----underlying rate tenor is 6M
      and  round(MONTHS_BETWEEN( titres.datefinal, titres.emission )) in (24,36,48,60,72,84,96,108,120,144,180,240,360) -----months between end date and start date
      ) )
)    -----CCY IS EUR
  OR (DEVISE_TO_STR(titres.DEVISECTT) = 'USD' and  (
              (
              BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE1.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  in ('3MNTH','6MNTH') 
              )
              OR
              (
              BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 65535) 
              || CASE BITAND((UND_RATE2.ECHEANCE - DATE'1904-01-01'), 196608) WHEN 65536 THEN 'DAYS' WHEN 131072 THEN 'MNTH' WHEN 196608 THEN 'YEAR' END  in ('3MNTH','6MNTH') 
              )
              ) ----underlying rate tenor is 3M or 6M
      and  round(MONTHS_BETWEEN( titres.datefinal, titres.emission )) in (24,36,48,60,72,84,120,144,180,240,360) -----months between end date and start date
) )
AND ES.VALUE IS NULL;

EXCEPTION
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	

	END    IRS_MISS_ISIN;
-- *****************************************************************
-- END OF: IRS_MISS_ISIN
-- *****************************************************************

-- *****************************************************************
-- Description:     PROCEDURE  SWAP_USING_XXX_QUOTATION_UNIT
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 03 APR 2018      Gustavo Binnie      Created - MCMIFID2-79
-- ***************************************************************** 
PROCEDURE SWAP_USING_XXX_QUOTATION_UNIT (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: SWAP_USING_XXX_QUOTATION_UNIT
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

SELECT				SICOVAM, 
					LIBELLE AS INSTRUMENT_NAME, 
					REFERENCE,  
					(SELECT COUNT(*) FROM AMRECON_VACATIONS AV 
										  LEFT JOIN HISTOMVTS H ON H.REFCON = AV.REFCON 
										  INNER JOIN USERINFOS ON H.OPERATEUR = USERINFOS.IDENT
										  LEFT JOIN TITRES SEC ON H.SICOVAM = SEC.SICOVAM
										  INNER JOIN TIERS CPTY ON CPTY.IDENT = H.CONTREPARTIE
										  INNER JOIN TIERS BROKER ON BROKER.IDENT = H.COURTIER  
										  WHERE AV.ESID = 4334 AND H.SICOVAM = TITRES.SICOVAM
										  AND UPPER(USERINFOS.COUNTRY) = 'UK'
										  AND (BROKER.NAME NOT LIKE ('INTERNAL%') AND BROKER.NAME NOT LIKE ('PB TRANSFER%') AND BROKER.IDENT NOT IN (10012815,10010875,10010876,10010878,10003642))
										  AND (CPTY.NAME NOT LIKE ('INTERNAL%') AND CPTY.NAME NOT LIKE ('PB TRANSFER%')AND CPTY.IDENT NOT IN (10012815,10010875,10010876,10010878,10003642))
										  AND H.DATENEG > '02-JAN-2018'  --MIFIR STARTS POST THIS DATE 
					) ALLOCATIONS_TRADES_MIFIR_FILE 
   FROM TITRES 
   WHERE TYPE = 'S' 
   AND QUOTATION_TYPE=6 
   AND DATEFINAL > SYSDATE;
		
END

SWAP_USING_XXX_QUOTATION_UNIT;

-- *****************************************************************
-- END OF: SWAP_USING_XXX_QUOTATION_UNIT
-- ***************************************************************** 


-- *****************************************************************
-- Description:     PROCEDURE  UKTRADE_MISS_DECMAKER
--
-- Author:      Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 MAY 2018       Jeff Yu       Created (PMCMIFID2-87)
-- 21 AUG 2018       Jeff Yu       Modified (PMOGUCITS-60)
-- ***************************************************************** 
PROCEDURE UKTRADE_MISS_DECMAKER (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: UKTRADE_MISS_DECMAKER
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR

select tr.refcon as trade_id
, RISKUSERS.name as trader
, tr.opcvm as folio_id
, STRATEGY_NAME as folio_name
, Fund_NAME
, BOOK_NAME
, bmc.OUTPUT_CODE

  from HISTOMVTS tr
  inner join amrecon_vacations 
  on tr.refcon=amrecon_vacations.refcon
  left join userinfos
  on tr.operateur=userinfos.ident
  left join RISKUSERS
  on RISKUSERS.ident=tr.operateur
  
  left join
  (  select CONNECT_BY_ROOT(FOLIO.ident) root
          , folio.ident
          , level
          , ROW_NUMBER() OVER (PARTITION BY folio.ident ORDER BY level ASC) AS rn
  from folio
  start with ident in (select input_code from btg_mapping_code where source_id = 6 and type_id = 79)
  connect by PRIOR FOLIO.ident = FOLIO.mgr
  order by level
  ) folio
  on folio.ident = tr.opcvm
  and folio.rn = 1
  left join btg_mapping_code bmc
  on bmc.source_id = 6 and bmc.type_id = 79 and root = bmc.INPUT_CODE
  
  inner join (	SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (14414,90565) 
    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = tr.OPCVM
  
where amrecon_vacations.esid=4334
  and userinfos.country='UK'
  and CONTREPARTIE not in (10012815,10010875,10010876,10010878,10003642,10007902,10014565,10014065,10014066,10014067,10010898,10010899,10010900,10010901,10019066) ---transfer
  and COURTIER not in (10012815,10010875,10010876,10010878,10003642,10007902,10014565,10014065,10014066,10014067,10010898,10010899,10010900,10010901,10019066) ---transfer
  and tr.dateneg >= trunc(sysdate) - 7-----7 days period
  and (bmc.OUTPUT_CODE = 'INVALID' or bmc.output_code is null)  
  ;

END

UKTRADE_MISS_DECMAKER;

-- *****************************************************************
-- END OF: UKTRADE_MISS_DECMAKER
-- ***************************************************************** 


-- *****************************************************************
-- Description:     PROCEDURE  UCITS_GMF_TRADES_NO_SSIs
--
-- Author:          Helen Zheng
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 JUL 2018      Helen Zheng      Created - PMOGUCITS-46
-- ***************************************************************** 
-- ***************************************************************** 
PROCEDURE UCITS_GMF_TRADES_NO_SSIs (p_CURSOR OUT T_CURSOR) AS

BEGIN
	-- *****************************************************************
	-- BEGIN OF: UCITS_GMF_TRADES_NO_SSIs
	-- *****************************************************************   
	OPEN p_CURSOR
	FOR


-- SHARES ONLY
select 
FUND_BOOK_STRATEGY.fund_name,
FUND_BOOK_STRATEGY.strategy_name,
trade.refcon as TradeID,

instr.libelle as InstrumentName,
instr.sicovam InstrumentID,
trade.dateneg as TradeDate,
trade.dateval as ValueDate,
case when trade.depositaire=10027030 Then 'JPM-EUROCLEAR-GMF'
 when trade.depositaire=10027031 Then 'JPM-DTCC-GMF'
 when trade.depositaire=10027032 Then 'JPM-DOMESTIC-GMF'
else ''
end as Depositary,
tiers.name as Broker,
allot.libelle as Allotment,
cntry.code as CntryOnInstr,
ssi.countrycode as SSICntryOnSSI
from join_position_histomvts trade
left join titres instr
on trade.sicovam=instr.sicovam
left join SECTOR_INSTRUMENT_ASSOCIATION t
on instr.sicovam=t.sicovam
left join sectors s
on t.type=s.id
left join sectors cntry
on t.sector=cntry.id
left join tiers 
on trade.courtier=tiers.ident
left join affectation allot
on instr.affectation=allot.ident
left join tierssettlement ssi
on cntry.code=ssi.countrycode and trade.courtier=ssi.code  and trade.depositaire=ssi.depositary
left join tiers depo
on ssi.depositary=depo.ident
INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (90565)--UCITs funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = trade.OPCVM

where 
 t.type=5347 
 --and instr.affectation in (4,1140,1500,1501,1502,1503,1504,1505,1506,1601,1701,1600) 
 and trade.depositaire in (10027031,10027032) --JPM-DTCC-DEPOSITARY and JPM-Domestic-DEPOSITARY only
and trade.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
and (tiers.ident !=10010875 and tiers.ident !=10010876)
AND trade.dateneg <= TRUNC(sysdate) 
AND trade.dateneg > TRUNC(sysdate-6)
and (ssi.countrycode is null)

union

-- FIXED INCOME ONLY
select 
FUND_BOOK_STRATEGY.fund_name,
FUND_BOOK_STRATEGY.strategy_name,
trade.refcon as TradeID,
instr.libelle as InstrumentName,
instr.sicovam InstrumentID,
trade.dateneg as TradeDate,
trade.dateval as ValueDate,
case when trade.depositaire=10027030 Then 'JPM-EUROCLEAR-GMF'
 when trade.depositaire=10027031 Then 'JPM-DTCC-GMF'
 when trade.depositaire=10027032 Then 'JPM-DOMESTIC-GMF'
else ''
end as Depositary,
tiers.name as Broker,
allot.libelle as Allotment,
cntry.code as CntryOnInstr,
ssi.countrycode as SSICntryOnSSI

from join_position_histomvts trade
left join titres instr
on trade.sicovam=instr.sicovam
left join SECTOR_INSTRUMENT_ASSOCIATION t
on instr.sicovam=t.sicovam
left join sectors s
on t.type=s.id
left join sectors cntry
on t.sector=cntry.id
left join tiers 
on trade.courtier=tiers.ident
left join affectation allot
on instr.affectation=allot.ident
left join tierssettlement ssi
on cntry.code=ssi.countrycode and trade.courtier=ssi.code and instr.affectation=ssi.allotment and trade.depositaire=ssi.depositary
left join tiers depo
on ssi.depositary=depo.ident
INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (90565)--UCITs funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = trade.OPCVM

where 
 t.type=5347 and trade.depositaire in (10027031,10027032) --JPM-DTCC-DEPOSITARY and JPM-Domestic-DEPOSITARY only
and instr.affectation in (25,26) -- have to specify the fixed income allotments Will need to add to this if in the future more allotments are included
 and trade.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
 and (tiers.ident !=10010875 and tiers.ident !=10010876)
AND trade.dateneg <= TRUNC(sysdate) 
AND trade.dateneg > TRUNC(sysdate-6)
and (ssi.countrycode is null)

UNION

-- Euroclear cleared ones ONLY
select 
FUND_BOOK_STRATEGY.fund_name,
FUND_BOOK_STRATEGY.strategy_name,
trade.refcon as TradeID,
instr.libelle as InstrumentName,
instr.sicovam InstrumentID,
trade.dateneg as TradeDate,
trade.dateval as ValueDate,
case when trade.depositaire=10027030 Then 'JPM-EUROCLEAR-GMF'
else ''
end as Depositary,
tiers.name as Broker,
allot.libelle as Allotment,
cntry.code as CntryOnInstr,
ssi.countrycode as SSICntryOnSSI

from join_position_histomvts trade
left join titres instr
on trade.sicovam=instr.sicovam
left join SECTOR_INSTRUMENT_ASSOCIATION t
on instr.sicovam=t.sicovam
left join sectors s
on t.type=s.id
left join sectors cntry
on t.sector=cntry.id
left join tiers 
on trade.courtier=tiers.ident and tiers.mgr=10007662
left join affectation allot
on instr.affectation=allot.ident
left join tierssettlement ssi
on trade.courtier=ssi.code  and trade.depositaire=ssi.depositary 
left join tiers depo
on ssi.depositary=depo.ident
INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 4
                            START WITH FOLIO.ident           IN (90565)--UCITs funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = trade.OPCVM

where 
 t.type=5347  and trade.depositaire in (10027030) --JPM-EUROCLEAR-DEPOSITARY only
and trade.BACKOFFICE NOT IN (11,13,17,26,27,192,220,248,252) --Not deleted trades
and (tiers.ident !=10010875 and tiers.ident !=10010876)
AND trade.dateneg <= TRUNC(sysdate) 
AND trade.dateneg > TRUNC(sysdate-6)
and (ssi.countrycode is null)
;

END

UCITS_GMF_TRADES_NO_SSIs;

-- *****************************************************************
-- END OF: UCITS_GMF_TRADES_NO_SSIs
-- ***************************************************************** 

END PCKG_BTG_EMAILER_OPSREPORTS;