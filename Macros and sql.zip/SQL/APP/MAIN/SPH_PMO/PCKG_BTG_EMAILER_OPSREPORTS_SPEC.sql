create or replace
PACKAGE            "PCKG_BTG_EMAILER_OPSREPORTS" 
AS

  TYPE T_CURSOR IS REF CURSOR;



PROCEDURE VOL_VAR_NUM_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE VOL_VAR_LIST_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  );

  
  PROCEDURE NY_MO_BLOTTER2
  (
    p_CURSOR OUT T_CURSOR
  );
  

PROCEDURE LONDON_UST_SETT_TODAY
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE INSTRUMENT_CHANGE_MTM
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE NEW_2LEVEL_EQ_STRAT
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE TURKEY_BOND_TRADES
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE JPM_GDS_STATIC_CHANGE
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE UNALLOCATED_TRADE_T_1
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE UNALLOCATED_TRADE_T_1_NY
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE UNALLOCATED_TRADE_T_NY
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE UNSETTLED_BOND_GLEM
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE BTG_STRAT_REGION_GLOBAL
  (
    p_CURSOR OUT T_CURSOR
  );

-----********************--------------------
--11-DEC-2017      CREATED BY Jeff Yu      PMGMRISK-147
PROCEDURE GDO_NEW_FOLIO
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE BTG_STRAT_REGION_SUMMARY
  (
    p_CURSOR OUT T_CURSOR
  );
  
PROCEDURE EMFX_FXO_INTB
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE EMFX_FXO_INTB_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );  

PROCEDURE EMFX_FXO_GEMM
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE EMFX_FXO_GEMM_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE EMFX_FXO_ARF
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE EMFX_FXO_ARF_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE LDN_NON_ALLOC_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);
  
 PROCEDURE NY_NON_ALLOC_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE COMPLIANCE_TRADES_PEND_REVIEW
	(
		p_CURSOR OUT T_CURSOR
	);
  
PROCEDURE COMPLIANCE_TRADES_PEND_TRADER
	(
		p_CURSOR OUT T_CURSOR
	);
  
PROCEDURE JPM_CFD_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);
  
PROCEDURE COMPLIANCE_TRADE_REASONS
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE SWAPS_DUE_TO_START
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE COMPLIANCE_OUTSTANDING
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE EXPIRY_T7
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE EXPIRY_T1
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE EXPIRY_MISSED
	(
		p_CURSOR OUT T_CURSOR
	);



  -- *****************************************************************
  -- Description: PROCEDURE EXPIRY_PREC_METAL
	--
  -- Author:          Oliver South
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    23-May-2013   Oliver South     Created.
  -- *****************************************************************
PROCEDURE EXPIRY_PREC_METAL
	(
		p_CURSOR OUT T_CURSOR
	);

PROCEDURE ORACLE_INVALID_OBJECT
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE RV_LONG_SHORT_MEXICO
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
PROCEDURE RV_LONG_SHORT_MEXICO
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE RV_LONG_SHORT_CHILE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
PROCEDURE RV_LONG_SHORT_CHILE
	(
		p_CURSOR OUT T_CURSOR
	);
  
  -- *****************************************************************
  -- Description: PROCEDURE NEW_DEPOSITARIES_T_3D
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
PROCEDURE NEW_DEPOSITARIES_T_3D
	(
		p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE TRADES_BOOKED_LATE
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
  PROCEDURE TRADES_BOOKED_LATE
	(
     p_CURSOR OUT T_CURSOR
	);  
  
  -- *****************************************************************
  -- Description: PROCEDURE UST_NOT_COVERED_BY_REPO
	--
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- *****************************************************************
  PROCEDURE UST_NOT_COVERED_BY_REPO
	(
     p_CURSOR OUT T_CURSOR
	);

  -- *****************************************************************
  -- Description: PROCEDURE EQ_BOXED_POSITION
	--
  -- Author:          
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 18-Nov-2013    Oliver South     Created.
  -- *****************************************************************
  PROCEDURE EQ_BOXED_POSITION
	(
     p_CURSOR OUT T_CURSOR
	);
  -- *****************************************************************
  -- Description: PROCEDURE UST_AMEND_BDATE
	--
  -- Author:          
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 19-Dec-2013    Oliver South     Created.
  -- *****************************************************************
  PROCEDURE UST_AMEND_BDATE
	(
     p_CURSOR OUT T_CURSOR
	);

	
-- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_POS_ALL
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 18 Sep 2014    Oliver South   Created
-- *****************************************************************
  PROCEDURE INCONSISTENT_POS_ALL
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_NOVATIONS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- *****************************************************************


  PROCEDURE OTC_T_NOVATIONS
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_UNWINDS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- *****************************************************************
  PROCEDURE OTC_T_UNWINDS
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  OTC_T_1_NOVATIONS
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 10 Mar 2014    Oliver South   Created
-- *****************************************************************
  PROCEDURE OTC_T_1_NOVATIONS
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  BANK_LOAN_BOXED
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 20 Mar 2014    Oliver South   Created
-- *****************************************************************
  PROCEDURE BANK_LOAN_BOXED
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  GS_BLOCK_TRADE_CSA_IND
--                  
--
-- Author:          JUN GUAN
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 28 Mar 2014    JUN GUAN   Created
-- *****************************************************************
  PROCEDURE GS_BLOCK_TRADE_CSA_IND
	(
		p_CURSOR OUT T_CURSOR
	);


-- *****************************************************************
-- Description:     PROCEDURE  CFD_LAST_PRICE
--                  
--
-- Author:          Oliver South
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 02 Sep 2014     Oliver South   Created
-- *****************************************************************
  PROCEDURE CFD_LAST_PRICE
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MLP_CASH_TRADES
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- 23 APR 2018     Jeff Yu       Modified (PMOG-1220)
-- *****************************************************************
  PROCEDURE MLP_CASH_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MLP_ARFS_IPO_TRADES
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- *****************************************************************
PROCEDURE MLP_ARFS_IPO_TRADES
	(
		p_CURSOR OUT T_CURSOR
	);

-- *****************************************************************
-- Description:     PROCEDURE  MLP_CASH_POSITIONS
--                  
--
-- Author:         Gustavo Binnie
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 13 Nov 2014     Gustavo Binnie   Created
-- *****************************************************************
PROCEDURE MLP_CASH_POSITIONS
	(
		p_CURSOR OUT T_CURSOR
	);

	-- *****************************************************************
-- Description:     PROCEDURE  EQ_US_IPO_OPEN_POS
--                  
--
-- Author:         Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 12 Dec 2014      Davi Xavier      Created
-- *****************************************************************
PROCEDURE EQ_US_IPO_OPEN_POS
	(
		p_CURSOR OUT T_CURSOR
	);

	-- *****************************************************************
-- Description:     PROCEDURE  EXPIRY_T0
--                  
--
-- Author:         Davi Xavier
--
-- Revision History
-- Date             Author			 Reason for Change
-- ----------------------------------------------------------------
-- 15 Dec 2014      Davi Xavier      Created
-- *****************************************************************
PROCEDURE EXPIRY_T0
	(
		p_cursor out t_cursor
	);



  -- *****************************************************************
-- Description:     PROCEDURE  MS_BLOCK_TRADE_SOFT_DOL
--                  
--
-- Author: Davi Xavier         
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 19 Feb 2015     Davi Xavier   Created
-- *****************************************************************
   PROCEDURE MS_BLOCK_TRADE_SOFT_DOL
  (
    p_CURSOR OUT T_CURSOR
  );
  
    -- *****************************************************************
-- Description:     PROCEDURE  INCONSISTENT_POS_EQ_ENERGYOP
--                  
--
-- Author: Davi Xavier         
--
-- Revision History
-- Date               Author          Reason for Change
-- ----------------------------------------------------------------
-- 11 Mar 2015     Davi Xavier		  Created
-- 18 Mar 2016     Gustavo Binnie	  PMOG-930 - Changed Name and scope to EQ Energy Oportunities
-- *****************************************************************
   PROCEDURE INCONSISTENT_POS_EQ_ENERGYOP
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
-- Description:     PROCEDURE  EMLATAM_FXO_GEMM
-- Description:     PROCEDURE  EMLATAM_FXO_INTB
-- Description:     PROCEDURE  EMLATAM_FXO_ARF
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 12 Mar 2015          Davi Xavier         Created 
-- *****************************************************************
   PROCEDURE EMLATAM_FXO_GEMM
  (
    p_CURSOR OUT T_CURSOR
  );
  
     PROCEDURE EMLATAM_FXO_INTB
  (
    p_CURSOR OUT T_CURSOR
  );
  
  PROCEDURE EMLATAM_FXO_ARF
  (
    p_CURSOR OUT T_CURSOR
  );
-- *****************************************************************
-- Description:     PROCEDURE  EMLATAM_FXO_GEMM_EXP_NXT_3
-- Description:     PROCEDURE  EMLATAM_FXO_INTB_EXP_NXT_3
-- Description:     PROCEDURE  EMLATAM_FXO_ARF_EXP_NXT_3
--                  
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 Mar 2015          Davi Xavier         Created 
-- *****************************************************************

   PROCEDURE EMLATAM_FXO_GEMM_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );
  
     PROCEDURE EMLATAM_FXO_INTB_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );
  
  PROCEDURE EMLATAM_FXO_ARF_EXP_NXT_3
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  LAST_PRICE_AUDIT_REPORT
--
-- Author:          Oliver South
--
-- Revision History
-- Date                 Author               Reason for Change
-- ----------------------------------------------------------------
-- 19 Mar 2015         Oliver South         Created 
-- *****************************************************************

   PROCEDURE LAST_PRICE_AUDIT_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );

-- *****************************************************************
-- Description:     PROCEDURE  EQ_BOXED_POSITION_EQ_ENERYOP
--
-- Author:          Davi Xavier
--
-- Revision History
-- Date                 Author              Reason for Change
-- ----------------------------------------------------------------
-- 25 Mar 2015         Davi Xavier          Created
-- 18 Mar 2016		   Gustavo Binnie		PMOG-930 - Changed Name and scope to EQ Energy Oportunities 
-- *****************************************************************

   PROCEDURE EQ_BOXED_POSITION_EQ_ENERYOP
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
  -- Description: PROCEDURE FX_OTC_OPEN
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 07-APR-2015      Davi Xavier      Created.
  -- *****************************************************************

   PROCEDURE FX_OTC_OPEN
  (
    p_CURSOR OUT T_CURSOR
  );

  -- *****************************************************************
  -- Description: THEORETICAL_PRICE_AUDIT_REPORT
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 28-MAY-2015      Davi Xavier      Created.
  -- *****************************************************************

   PROCEDURE THEORETICAL_PRICE_AUDIT_REPORT
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: TRADES_FXO_PREM
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 11-JUN-2015      Oliver        Created.
  -- 11-JUN-2015      Davi          Asked release
  -- *****************************************************************

   PROCEDURE TRADES_FXO_PREM
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: CDS_BOXED_POSITION
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 29-JUL-2015      Oliver        Created.
  -- 29-JUL-2015      Davi          Arranged the release with AS
  -- *****************************************************************

   PROCEDURE CDS_BOXED_POSITION
  (
    p_CURSOR OUT T_CURSOR
  );
  
    -- *****************************************************************
  -- Description: UF_INSTRUMENTS
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 29-AUG-2015      Davi          Created.
  -- *****************************************************************

   PROCEDURE UF_INSTRUMENTS
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: LATAM_FWD
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 29-AUG-2015      Davi          Created.
  -- *****************************************************************

   PROCEDURE LATAM_FWD
  (
    p_CURSOR OUT T_CURSOR
  );

  -- *****************************************************************
  -- Description: EXPIRY_FUT_DELIVERY
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 07-SEP-2015      Oliver        Created.
  -- 07-SEP-2015      Davi          Arranged the release with AS
  -- *****************************************************************

   PROCEDURE EXPIRY_FUT_DELIVERY
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: MO_AMENDMENT_EXEC
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 20-SEP-2015      Davi          Created.
  -- *****************************************************************

   PROCEDURE MO_AMENDMENT_EXEC
  (
    p_CURSOR OUT T_CURSOR
  );

  -- *****************************************************************
  -- Description: MO_INSERTIONS_EXEC
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 20-SEP-2015      Davi          Created.
  -- *****************************************************************

   PROCEDURE MO_INSERTIONS_EXEC
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: MO_AMEND_DIV_PRIM
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  -- 20-SEP-2015      Davi          Created.
  -- *****************************************************************

   PROCEDURE MO_AMEND_DIV_PRIM
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: PROCEDURE MO_INSERTIONS_PRIM
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 05 OCT 2015     Davi Xavier     Created.
  -- *****************************************************************

   PROCEDURE MO_INSERTIONS_PRIM
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: PROCEDURE BOXED_OPT_UND_EQ_ENERGYOP
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 06 OCT 2015     Davi Xavier			Created.
  -- 18 Mar 2016     Gustavo Binnie			PMOG-930 - Changed Name and scope to EQ Energy Oportunities
  -- *****************************************************************

   PROCEDURE BOXED_OPT_UND_EQ_ENERGYOP
  (
    p_CURSOR OUT T_CURSOR
  );
  
  -- *****************************************************************
  -- Description: PROCEDURE AUDIT_TRAIL_NEW_USER
  --
  -- Author:          Davi Xavier
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 12 OCT 2015      Davi Xavier     Created.
  -- *****************************************************************

   PROCEDURE AUDIT_TRAIL_NEW_USER
  (
    p_CURSOR OUT T_CURSOR
  );

  -- *****************************************************************
  -- Description: PROCEDURE LATE_BOOKINGS_NEOVEST
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 14 OCT 2015     Gustavo Binnie		    Created.
  -- *****************************************************************

   PROCEDURE LATE_BOOKINGS_NEOVEST
  (
    p_CURSOR OUT T_CURSOR
  );
  
  
  -- *****************************************************************
  -- Description: EXPIRY_NDF_FIXING
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 28 OCT 2015     Oliver South		    Created.
  -- 28 OCT 2015     Davi Xavier		    Arranged the release with AS
  -- *****************************************************************

   PROCEDURE EXPIRY_NDF_FIXING
  (
    p_CURSOR OUT T_CURSOR
  );
  

-- *****************************************************************
  -- Description: PROCEDURE ACCRUED_DIVIDENDS_REC
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author			    Reason for Change
  -- ----------------------------------------------------------------
  -- 4 NOV 2015		 Gustavo Binnie		    Created.
  -- *****************************************************************
  
   PROCEDURE ACCRUED_DIVIDENDS_REC
  (
    p_CURSOR OUT T_CURSOR
  );


	-- *****************************************************************
-- Description:     PROCEDURE  FWD_CASH_SETTL
--
-- Author:          Davi Xavier
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 22 DEC 2015      Davi Xavier            Created
-- ***************************************************************** 

  PROCEDURE FWD_CASH_SETTL

	(
		p_CURSOR OUT T_CURSOR
	);

	-- *****************************************************************
-- Description:     PROCEDURE  FXO_CLOSE_POS_EXP
--
-- Author:          Davi Xavier
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 22 DEC 2015      Davi Xavier            Created
-- ***************************************************************** 

  PROCEDURE FXO_CLOSE_POS_EXP

	(
		p_CURSOR OUT T_CURSOR
	);

		-- *****************************************************************
-- Description:     PROCEDURE  AMEND_INS_AFT_CKECKMO
--
-- Author:          Davi Xavier
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 18 FEB 2015      Davi Xavier            Created
-- ***************************************************************** 

  PROCEDURE AMEND_INS_AFT_CKECKMO

	(
		p_CURSOR OUT T_CURSOR
	);

	-- *****************************************************************
-- Description:     PROCEDURE  FX_OPTION_NUM_OF_EXPIRIES
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 DEC 2016      Jeff Yu            Created
-- ***************************************************************** 
	PROCEDURE FX_OPTION_NUM_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  );

  	-- *****************************************************************
-- Description:     PROCEDURE  FX_OPTION_LIST_OF_EXPIRIES
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 19 DEC 2016      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE FX_OPTION_LIST_OF_EXPIRIES
  (
    p_CURSOR OUT T_CURSOR
  );

    	-- *****************************************************************
-- Description:     PROCEDURE  ESPEED_BROKERTEC_ETRADES
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 20 APR 2017      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE ESPEED_BROKERTEC_ETRADES
  (
    p_CURSOR OUT T_CURSOR
  );

     	-- *****************************************************************
-- Description:     PROCEDURE  CPTY_LEI
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 26 DEC 2017      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE CPTY_LEI
  (
    p_CURSOR OUT T_CURSOR
  );


    	-- *****************************************************************
-- Description:     PROCEDURE  TRADE_NON_FO
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE TRADE_NON_FO
  (
    p_CURSOR OUT T_CURSOR
  );


   	-- *****************************************************************
-- Description:     PROCEDURE  UK_STRAT_MISS_DECISION_MAKER
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 29 DEC 2017      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE UK_STRAT_MISS_DECISION_MAKER
  (
    p_CURSOR OUT T_CURSOR
  );


   	-- *****************************************************************
-- Description:     PROCEDURE  BASKET_INDEX_NO_COMP
--
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 08 JAN 2018      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE BASKET_INDEX_NO_COMP
  (
    p_CURSOR OUT T_CURSOR
  );


 	-- *****************************************************************
-- Description:     PROCEDURE  CDS_MISS_ISIN
-- Description:     PROCEDURE  IRS_MISS_ISIN
-- Author:          Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 10 JAN 2018      Jeff Yu            Created
-- ***************************************************************** 
PROCEDURE CDS_MISS_ISIN
  (
    p_CURSOR OUT T_CURSOR
  );

PROCEDURE IRS_MISS_ISIN
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  SWAP_USING_XXX_QUOTATION_UNIT
--
-- Author:          Gustavo Binnie
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 03 APR 2018      Gustavo Binnie      Created - MCMIFID2-79
-- ***************************************************************** 
PROCEDURE SWAP_USING_XXX_QUOTATION_UNIT
  (
    p_CURSOR OUT T_CURSOR
  );


-- *****************************************************************
-- Description:     PROCEDURE  UKTRADE_MISS_DECMAKER
--
-- Author:         Jeff Yu
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 MAY 2018       Jeff Yu       Created (PMCMIFID2-87)
-- ***************************************************************** 
PROCEDURE UKTRADE_MISS_DECMAKER
  (
    p_CURSOR OUT T_CURSOR
  );


  
-- *****************************************************************
-- Description:     PROCEDURE  UCITS_GMF_TRADES_NO_SSIs
--
-- Author:          Helen Zheng
--
-- Revision History
-------------------
-- Date             Author              Reason for Change
-- ----------------------------------------------------------------
-- 17 JUL 2018      Helen Zheng      Created - PMOGUCITS-46
-- ***************************************************************** 
PROCEDURE UCITS_GMF_TRADES_NO_SSIs
  (
    p_CURSOR OUT T_CURSOR
  );


END PCKG_BTG_EMAILER_OPSREPORTS;