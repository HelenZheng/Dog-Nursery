create or replace
PACKAGE BODY PCKG_BTG_EMAILER_RISK_REPORTS AS

  PROCEDURE EM_CREDIT_PSTN_CHNG
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
    
    OPEN p_CURSOR FOR
      SELECT CLIENTS.libelle AS FUND
      , FOLIOS.FOLIO_NAME AS STRATEGY
      , TITRES.libelle AS INSTRUMENT
      , POSITIONS.YESTERDAY AS n$YESTERDAYS_POSITION
      , POSITIONS.TODAY AS n$TODAYS_POSITION
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'SHORT' 
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
          ELSE 'UNKNOWN'
        END AS YESTERDAYS_STATE
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
          ELSE 'UNKNOWN'
        END AS TODAYS_STATE
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'NEW POSITION'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'NEW POSITION'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'FULL LONG UNWIND'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'FULL LONG UNWIND CROSSING ZERO'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'FULL SHORT UNWIND'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'FULL SHORT UNWIND CROSSING ZERO'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
          ELSE 'UNKNOWN'
        END AS ACTION_TAKEN
      , FOLIOS.FOLIO_FULL_NAME AS STRATEGY_FULL_NAME
      FROM (
        SELECT HISTOMVTS.entite FUND_ID
        , HISTOMVTS.opcvm AS FOLIO_ID
        , HISTOMVTS.sicovam AS INSTRUMENT_ID
        , SUM(HISTOMVTS.quantite) AS TODAY
        , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) THEN HISTOMVTS.quantite ELSE 0 END) AS YESTERDAY  
        FROM HISTOMVTS
        INNER JOIN BO_KERNEL_STATUS_COMPONENT
        ON BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
        AND BO_KERNEL_STATUS_COMPONENT.kernel_status_id = HISTOMVTS.backoffice
        INNER JOIN BUSINESS_EVENTS 
        ON BUSINESS_EVENTS.Id = HISTOMVTS.Type
        AND BUSINESS_EVENTS.COMPTA = 1
        WHERE HISTOMVTS.dateneg <= trunc(sysdate)
        AND HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
        GROUP BY HISTOMVTS.entite
        , HISTOMVTS.opcvm
        , HISTOMVTS.sicovam
      ) POSITIONS
      INNER JOIN (
        SELECT FOLIO.ident AS FOLIO_ID
        , FOLIO.name AS FOLIO_NAME
        , SYS_CONNECT_BY_PATH(FOLIO.name, '\') AS FOLIO_FULL_NAME        
        FROM FOLIO  
        START WITH FOLIO.ident IN (13264, 26166, 14081, 24010)
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ) FOLIOS
      ON FOLIOS.FOLIO_ID = POSITIONS.FOLIO_ID
      INNER JOIN TITRES 
      ON TITRES.sicovam = POSITIONS.INSTRUMENT_ID
      AND TITRES.type != 'L' --EXCLUDE REPOS
      INNER JOIN CLIENTS
      ON CLIENTS.ident = POSITIONS.fund_id
      WHERE POSITIONS.TODAY != POSITIONS.YESTERDAY
      ORDER BY CLIENTS.libelle
      , FOLIOS.FOLIO_NAME
      , TITRES.libelle;
                
  END EM_CREDIT_PSTN_CHNG;
  

  
  PROCEDURE GLOBAL_CREDIT_PSTN_CHNG
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

    OPEN p_CURSOR FOR
      SELECT CLIENTS.libelle AS FUND
      , FOLIOS.FOLIO_NAME AS STRATEGY
      , TITRES.libelle AS INSTRUMENT
      , POSITIONS.YESTERDAY AS n$YESTERDAYS_POSITION
      , POSITIONS.TODAY AS n$TODAYS_POSITION
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'SHORT' 
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
          ELSE 'UNKNOWN'
        END AS YESTERDAYS_STATE
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'SHORT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'FLAT'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'LONG'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'SHORT'
          ELSE 'UNKNOWN'
        END AS TODAYS_STATE
      , CASE 
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) > 0) THEN 'NEW POSITION'
          WHEN (POSITIONS.YESTERDAY = 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY) < 0) THEN 'NEW POSITION'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'INCREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'INCREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY = 0) THEN 'FULL LONG UNWIND'
          WHEN (POSITIONS.YESTERDAY > 0 AND POSITIONS.TODAY < 0) THEN 'FULL LONG UNWIND CROSSING ZERO'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY = 0) THEN 'FULL SHORT UNWIND'
          WHEN (POSITIONS.YESTERDAY < 0 AND POSITIONS.TODAY > 0) THEN 'FULL SHORT UNWIND CROSSING ZERO'
          WHEN (POSITIONS.YESTERDAY > 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  < 0) THEN 'DECREASE IN POSITION'
          WHEN (POSITIONS.YESTERDAY < 0 AND (POSITIONS.TODAY - POSITIONS.YESTERDAY)  > 0) THEN 'DECREASE IN POSITION'
          ELSE 'UNKNOWN'
        END AS ACTION_TAKEN
      , FOLIOS.FOLIO_FULL_NAME AS STRATEGY_FULL_NAME
      FROM (
        SELECT HISTOMVTS.entite FUND_ID
        , HISTOMVTS.opcvm AS FOLIO_ID
        , HISTOMVTS.sicovam AS INSTRUMENT_ID
        , SUM(HISTOMVTS.quantite) AS TODAY
        , SUM(CASE WHEN HISTOMVTS.dateneg < trunc(sysdate) THEN HISTOMVTS.quantite ELSE 0 END) AS YESTERDAY  
        FROM HISTOMVTS
        INNER JOIN BO_KERNEL_STATUS_COMPONENT
        ON BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
        AND BO_KERNEL_STATUS_COMPONENT.kernel_status_id = HISTOMVTS.backoffice
        INNER JOIN BUSINESS_EVENTS 
        ON BUSINESS_EVENTS.Id = HISTOMVTS.Type
        AND BUSINESS_EVENTS.COMPTA = 1
        WHERE HISTOMVTS.dateneg <= trunc(sysdate)
        AND HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
        GROUP BY HISTOMVTS.entite
        , HISTOMVTS.opcvm
        , HISTOMVTS.sicovam
      ) POSITIONS
      INNER JOIN (
        SELECT FOLIO.ident AS FOLIO_ID
        , FOLIO.name AS FOLIO_NAME
        , SYS_CONNECT_BY_PATH(FOLIO.name, '\') AS FOLIO_FULL_NAME        
        FROM FOLIO  
        START WITH FOLIO.ident IN (59370, 59371)
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
      ) FOLIOS
      ON FOLIOS.FOLIO_ID = POSITIONS.FOLIO_ID
      INNER JOIN TITRES 
      ON TITRES.sicovam = POSITIONS.INSTRUMENT_ID
      AND TITRES.type != 'L' --EXCLUDE REPOS
      INNER JOIN CLIENTS
      ON CLIENTS.ident = POSITIONS.fund_id
      WHERE POSITIONS.TODAY != POSITIONS.YESTERDAY
      ORDER BY CLIENTS.libelle
      , FOLIOS.FOLIO_NAME
      , TITRES.libelle;

  END GLOBAL_CREDIT_PSTN_CHNG;
  


  PROCEDURE EM_GLOBAL_CREDIT_BNDS_FLT_VAR
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

    OPEN p_CURSOR FOR
      SELECT TITRES.sicovam AS SICOVAM
      , TITRES.libelle AS NAME
      , TITRES.reference AS REFERENCE
      FROM TITRES
      INNER JOIN (
        SELECT DISTINCT OPEN_POSITIONS.sicovam
        FROM (
          SELECT HISTOMVTS.opcvm
          , TITRES.sicovam
          FROM HISTOMVTS
          INNER JOIN TITRES 
          ON TITRES.sicovam = HISTOMVTS.sicovam
          INNER JOIN (
            SELECT FOLIO.ident AS IDENT
            FROM FOLIO
            START WITH FOLIO.ident IN (13264, 14081, 24010, 26166, 68487, 59370, 59371)
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
          ) FOLIOS
          ON FOLIOS.ident = HISTOMVTS.opcvm  
          WHERE HISTOMVTS.backoffice NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252) 
          AND HISTOMVTS.type in (1,140)
          AND TITRES.type = 'O'
          AND TITRES.fixedspread = 2
          AND TITRES.default_event in (41, 42, 43, 44)
          GROUP BY HISTOMVTS.opcvm
          , TITRES.sicovam
          HAVING SUM(HISTOMVTS.quantite) != 0
        ) OPEN_POSITIONS
      ) OPEN_INSTRUMENTS
      ON OPEN_INSTRUMENTS.sicovam = TITRES.sicovam
      ORDER BY REFERENCE;

  END EM_GLOBAL_CREDIT_BNDS_FLT_VAR;


PROCEDURE USCREDIT_6M
(
    p_CURSOR OUT T_CURSOR
)
AS
BEGIN
  
     OPEN p_CURSOR FOR
		select      case security.type when 'S' THEN 'LOAN' ELSE 'BOND' END AS "INSTRUMENT_TYPE"
		,           fund.name               Fund
		,           max(histomvts.dateneg)       d$LastTrade
		,           strategy.name           Strategy
		,           security.libelle        Name
		,           security.reference      ISIN
		,           sum(histomvts.QUANTITE*security.nominal) n$Position
  
		from        histomvts

		inner join  tiers fund
		on          fund.ident                = histomvts.entite
  
		inner join  (
					  select      folio.ident
					  ,           folio.name
					  ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
					  from        folio
					  where       level       > 1
					  start with  ident       in (70093)
					  connect by  mgr         = prior ident					  
					) strategy
		on          strategy.ident            = histomvts.opcvm

		inner join  folio fund_strategy
		on          fund_strategy.ident       = strategy.parent_ident

		inner join  titres security
		on          security.sicovam          = histomvts.sicovam

		where		(security.type             = 'O' OR (security.type = 'S' AND (security.jambe1 in (3,5) OR security.jambe2 in (3,5))))
		and histomvts.backoffice not in (192,11,13,17,26,27,220,248,252)
		and histomvts.type not in (2,46,7)
		group by security.type, fund.name, strategy.name, security.libelle, security.reference
		having sum(histomvts.QUANTITE*security.nominal) !=0
		and max(histomvts.dateneg) <= sysdate -180
		order by 1, 3, 2, 4, 5;

END USCREDIT_6M;

  
  PROCEDURE USCREDIT_1M
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
	
	OPEN p_CURSOR FOR
		select      case security.type when 'S' THEN 'LOAN' ELSE 'BOND' END AS "INSTRUMENT_TYPE"
		,           fund.name               Fund
		,           max(histomvts.dateneg)       d$LastTrade
		,           strategy.name           Strategy
		,           security.libelle        Name
		,           security.reference      ISIN
		,           sum(histomvts.QUANTITE*security.nominal) n$Position
  
		from        histomvts

		inner join  tiers fund
		on          fund.ident                = histomvts.entite
  
		inner join  (
					  select      folio.ident
					  ,           folio.name
					  ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
					  from        folio
					  where       level       > 1
					  start with  ident       in (70093)
					  connect by  mgr         = prior ident					  
					) strategy
		on          strategy.ident            = histomvts.opcvm

		inner join  folio fund_strategy
		on          fund_strategy.ident       = strategy.parent_ident

		inner join  titres security
		on          security.sicovam          = histomvts.sicovam

		where		(security.type             = 'O' OR (security.type = 'S' AND (security.jambe1 in (3,5) OR security.jambe2 in (3,5))))
		and histomvts.backoffice not in (192,11,13,17,26,27,220,248,252)
		and histomvts.type not in (2,46,7)
		group by security.type, fund.name, strategy.name, security.libelle, security.reference
		having sum(histomvts.QUANTITE*security.nominal) !=0
		and max(histomvts.dateneg) > sysdate -180
		and max(histomvts.dateneg) <= sysdate -90
		order by 1, 3, 2, 4, 5;

  END USCREDIT_1M;


  PROCEDURE USCREDIT_1W
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
	
	OPEN p_CURSOR FOR
		select      case security.type when 'S' THEN 'LOAN' ELSE 'BOND' END AS "INSTRUMENT_TYPE"
		,           fund.name               Fund
		,           max(histomvts.dateneg)       d$LastTrade
		,           strategy.name           Strategy
		,           security.libelle        Name
		,           security.reference      ISIN
		,           sum(histomvts.QUANTITE*security.nominal) n$Position
  
		from        histomvts

		inner join  tiers fund
		on          fund.ident                = histomvts.entite
  
		inner join  (
					  select      folio.ident
					  ,           folio.name
					  ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
					  from        folio
					  where       level       > 1
					  start with  ident       in (70093)
					  connect by  mgr         = prior ident					  
					) strategy
		on          strategy.ident            = histomvts.opcvm

		inner join  folio fund_strategy
		on          fund_strategy.ident       = strategy.parent_ident

		inner join  titres security
		on          security.sicovam          = histomvts.sicovam

		where		(security.type             = 'O' OR (security.type = 'S' AND (security.jambe1 in (3,5) OR security.jambe2 in (3,5))))
		and histomvts.backoffice not in (192,11,13,17,26,27,220,248,252)
		and histomvts.type not in (2,46,7)
		group by security.type, fund.name, strategy.name, security.libelle, security.reference
		having sum(histomvts.QUANTITE*security.nominal) !=0
		and max(histomvts.dateneg) > sysdate -90
		and max(histomvts.dateneg) <= sysdate -30
		order by 1, 3, 2, 4, 5;

  END USCREDIT_1W;
  

  PROCEDURE USCREDIT_NOW
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN
	
	OPEN p_CURSOR FOR
		select      case security.type when 'S' THEN 'LOAN' ELSE 'BOND' END AS "INSTRUMENT_TYPE"
		,           fund.name               Fund
		,           max(histomvts.dateneg)       d$LastTrade
		,           strategy.name           Strategy
		,           security.libelle        Name
		,           security.reference      ISIN
		,           sum(histomvts.QUANTITE*security.nominal) n$Position
  
		from        histomvts

		inner join  tiers fund
		on          fund.ident                = histomvts.entite
  
		inner join  (
					  select      folio.ident
					  ,           folio.name
					  ,           nvl(btg_parse_string(SYS_CONNECT_BY_PATH(ident, '/'),3,4), ident) parent_ident
					  from        folio
					  where       level       > 1
					  start with  ident       in (70093)
					  connect by  mgr         = prior ident					  
					) strategy
		on          strategy.ident            = histomvts.opcvm

		inner join  folio fund_strategy
		on          fund_strategy.ident       = strategy.parent_ident

		inner join  titres security
		on          security.sicovam          = histomvts.sicovam

		where		(security.type             = 'O' OR (security.type = 'S' AND (security.jambe1 in (3,5) OR security.jambe2 in (3,5))))
		and histomvts.backoffice not in (192,11,13,17,26,27,220,248,252)
		and histomvts.type not in (2,46,7)
		group by security.type, fund.name, strategy.name, security.libelle, security.reference
		having sum(histomvts.QUANTITE*security.nominal) !=0
		and max(histomvts.dateneg) > sysdate -30
		and max(histomvts.dateneg) <= sysdate -7
		order by 1, 3, 2, 4, 5;

  END USCREDIT_NOW;


PROCEDURE EQ_US_IPO_TRADES_TODAY
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

    OPEN p_CURSOR FOR
      SELECT HISTOMVTS.refcon AS TRADE_ID   
      , BO_KERNEL_STATUS.name AS STATUS   
      , BUSINESS_EVENTS.name AS BUSINESS_EVENT
      , CLIENTS.libelle AS FUND
      , FOLIOS.FOLIO_NAME AS FOLIO_NAME   
      , FOLIOS.FOLIO_PATH AS FOLIO_PATH
      , AFFECTATION.libelle AS ALLOTMENT
      , BTG_GET_INSTRUMENT_TYPE(HISTOMVTS.sicovam) AS INSTRUMENT_TYPE
      , HISTOMVTS.sicovam AS INSTRUMENT_ID   
      , TITRES.libelle AS INSTRUMENT_NAME   
      , TITRES.reference AS INSTRUMENT_REFERENCE   
      , DEVISE_TO_STR(TITRES.devisectt) AS INSTRUMENT_CCY   
      , CONTREPARTIES.libelle AS COUNTERPARTY
      , HISTOMVTS.dateneg AS TRADE_DATE   
      , HISTOMVTS.quantite AS QUANTITY   
      , HISTOMVTS.cours AS TRADE_PRICE
      , DEVISE_TO_STR(HISTOMVTS.devisepay) AS TRADE_CURRENCY   
      , HISTOMVTS.montant AS NET_CASH   
      FROM HISTOMVTS   
      INNER JOIN (    
        SELECT FOLIO.ident AS FOLIO_ID   
        , FOLIO.name AS FOLIO_NAME   
        , SYS_CONNECT_BY_PATH(FOLIO.name, '\') AS FOLIO_PATH
        FROM FOLIO   
        START WITH FOLIO.ident IN (71209, 71210, 134813)
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr     
      ) FOLIOS   
      ON FOLIOS.folio_id = HISTOMVTS.opcvm   
      INNER JOIN BUSINESS_EVENTS    
      ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE       
      AND BUSINESS_EVENTS.COMPTA = 1
      LEFT OUTER JOIN BO_KERNEL_STATUS   
      ON BO_KERNEL_STATUS.id = HISTOMVTS.backoffice   
      LEFT OUTER JOIN CLIENTS   
      ON CLIENTS.ident = HISTOMVTS.entite   
      LEFT OUTER JOIN TITRES   
      ON TITRES.sicovam = HISTOMVTS.sicovam   
      LEFT OUTER JOIN CONTREPARTIES   
      ON CONTREPARTIES.ident = HISTOMVTS.contrepartie   
      LEFT OUTER JOIN AFFECTATION   
      ON TITRES.affectation = AFFECTATION.ident   
      WHERE HISTOMVTS.BACKOFFICE NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
      AND TITRES.type != 'L'
      AND HISTOMVTS.DATENEG = TRUNC(SYSDATE-1);
      
  END EQ_US_IPO_TRADES_TODAY;
  
------------------------------------------------------------------------------------------------------------------------------
  --10 NOV 2017     Jeff Yu      Created (PMGMRISK-138)
------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE OTC_STRUCTURED_MODEL
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

    OPEN p_CURSOR FOR

select titres.sicovam
, libelle as instrument_name
, reference
, FINPER  as maturity
, modele
from titres
Inner join (
SELECT   trades.sicovam                     
              , SUM(trades.quantite)    AS QUANTITY  
FROM HISTOMVTS trades
inner join titres
on titres.sicovam=trades.sicovam
INNER JOIN (
                                SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 4 START
                                WITH FOLIO.ident IN (12514)   ---whole BTG funds
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                ) FUND_BOOK_STRATEGY
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.opcvm 
INNER JOIN       BUSINESS_EVENTS 
ON    BUSINESS_EVENTS.id        =     trades.type      
AND  BUSINESS_EVENTS.compta     =  1
WHERE            trades.backoffice      NOT IN (11, 13, 17, 26, 27, 192, 220, 248, 252)
GROUP BY          trades.sicovam
HAVING            SUM(trades.quantite) <> 0
)  open
on open.sicovam=titres.sicovam
where affectation=2
and modele = 'New Multi Underlying'
;

END OTC_STRUCTURED_MODEL;


------------------------------------------------------------------------------------------------------------------------------
  --20 JUN 2018     Jeff Yu      Created (PMGMRISK-229)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE INSTR_MISS_LIQSECTOR
  (
    p_CURSOR OUT T_CURSOR
  )
  AS
  BEGIN

    OPEN p_CURSOR FOR

select sec.sicovam
, sec.reference
, sec.libelle as instrument_name
, affectation.libelle as allotment

from titres sec
left join titres underly1
on underly1.sicovam =
case when sec.type='D' then sec.codesj
when sec.type='S' then DECODE(SEC.jambe1, 1, 0, 0, SEC.BASE1, SEC.j1refcon2) 
else decode(sec.code_emet,0,decode(sec.codesj,0,sec.codesj2,sec.codesj),sec.code_emet) end
left join titres underly2
on underly2.sicovam = CASE WHEN SEC.TYPE = 'S' THEN DECODE(SEC.jambe2, 1, 0, 0, SEC.BASE2, SEC.j2refcon2) END
INNER JOIN (
	SELECT t.sicovam 
		,sum(trades.quantite)
	FROM titres t
	INNER JOIN HISTOMVTS trades
  ON trades.sicovam = t.sicovam
	INNER JOIN (
		SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
			,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
			,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
			,FOLIO.ident AS STRATEGY_ID
			,FOLIO.NAME AS STRATEGY_NAME
			,LEVEL
		FROM FOLIO
		WHERE LEVEL >= 4 START
		WITH FOLIO.ident IN (14414,90565) 
    CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
		) FUND_BOOK_STRATEGY
		ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.OPCVM
	INNER JOIN business_events
  ON business_events.id = trades.type
  AND business_events.compta = 1

	WHERE trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252)
  group by t.sicovam 
	HAVING sum(trades.quantite) != 0
	) open_position
ON open_position.sicovam = sec.sicovam
left join affectation
ON AFFECTATION.IDENT=sec.AFFECTATION
where (
 (sec.type not in ('D','G','S','N') and sec.sicovam not in (select sicovam from sector_instrument_association where type=1823)) ---check instrument itself
 or 
 (sec.type in ('D','G','S','N') and 
 sec.sicovam not in (select sicovam from sector_instrument_association where type=1823)
and
(underly1.sicovam not in (select sicovam from sector_instrument_association where type=1823)
or underly2.sicovam not in (select sicovam from sector_instrument_association where type=1823)
)
) ---check both instrument itself and underlying
)
and sec.type != 'L'    and sec.affectation !=7
order by sec.type
;      

END INSTR_MISS_LIQSECTOR;


END PCKG_BTG_EMAILER_RISK_REPORTS;