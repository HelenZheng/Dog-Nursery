create or replace
PACKAGE PCKG_BTG_EMAILER_RISK_REPORTS 
AS

  TYPE T_CURSOR IS REF CURSOR;
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- ***************************************************************** 
  PROCEDURE EM_CREDIT_PSTN_CHNG
  (
    p_CURSOR OUT T_CURSOR
  );
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE GLOBAL_CREDIT_PSTN_CHNG
  (
    p_CURSOR OUT T_CURSOR
  );
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE EM_GLOBAL_CREDIT_BNDS_FLT_VAR
  (
    p_CURSOR OUT T_CURSOR
  );
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE USCREDIT_6M
  (
    p_CURSOR OUT T_CURSOR
  ); 
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE USCREDIT_1M
  (
    p_CURSOR OUT T_CURSOR
  ); 
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************
  PROCEDURE USCREDIT_1W
  (
    p_CURSOR OUT T_CURSOR
  ); 
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--
-- Revision History
-- Date             Author        Reason for Change
-- ----------------------------------------------------------------
-- 01 DEC 2012    Jun Guan      Created.
-- *****************************************************************  
  PROCEDURE USCREDIT_NOW
  (
    p_CURSOR OUT T_CURSOR
  );
  
-- *****************************************************************
-- Description:     PROCEDURE  EQ_COMM7D
--                  
--
-- Author:          Jun Guan
--

  PROCEDURE EQ_US_IPO_TRADES_TODAY
  (
    p_CURSOR OUT T_CURSOR
  ); 
  
  -- *****************************************************************
-- Description:     PROCEDURE  OTC_STRUCTURED_MODEL
--                  
--
-- Author:          Jeff Yu
--

  PROCEDURE OTC_STRUCTURED_MODEL
  (
    p_CURSOR OUT T_CURSOR
  ); 

END PCKG_BTG_EMAILER_RISK_REPORTS;
 