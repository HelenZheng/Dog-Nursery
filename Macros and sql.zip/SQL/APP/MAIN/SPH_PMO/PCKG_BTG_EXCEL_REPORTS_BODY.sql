create or replace PACKAGE BODY            "PCKG_BTG_EXCEL_REPORTS" AS
  
    PROCEDURE COMPLIANCE_FAIRPRICE
  (
    IN_DATE_FROM  IN    DATE
  , IN_DATE_TO    IN    DATE
  , IN_REGION     IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  ) AS
  BEGIN
  
      OPEN OUT_CURSOR FOR      
        select  
        Trades.sicovam Sicovam,  
        DECODE (Instrument.TYPE,'F','Future','O','Bond','A','Equity','D','Option','Other') InstType, 
        Trades.refcon TradeID,  
        tiers.name Fund,  
        DECODE (Instrument.TYPE,'O',CONCAT(Instrument.reference,' ISIN'),'D',ric.servisen ,Instrument.reference) Ticker,  
        trunc(Trades.DATENEG) TradeDate,  
        trunc(Trades.DATEVAL) ValueDate,  
        trades.cours Price,  
        decode(SIGN(Trades.quantite), 1, 'BUY', -1, 'SELL', 'OTHER') Direction,
        DEVISE_TO_STR(Trades.devisepay) Currency,
        
		/*
		eri_risk.value Risk,
        eri_domicile.value Domicile,
		*/

		country_of_risk.code Risk,
        country_of_domicile.code Domicile,

        instrument.dateregl BondIssueDate,  
        riskusers.name Trader  
from  
        histomvts Trades  
left JOIN ( 
        SELECT  REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID
        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_NAME
        , FOLIO.ident AS STRATEGY_ID
        , FOLIO.name AS STRATEGY_NAME
        ,level
        FROM FOLIO
        WHERE LEVEL >= 4
        START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565)--Primary funds
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
        ) FUND_BOOK_STRATEGY
ON 	FUND_BOOK_STRATEGY.STRATEGY_ID = Trades.opcvm
inner join 	titres Instrument  
on 		Instrument.sicovam = Trades.sicovam  
inner join 	riskusers  
on 		riskusers.ident = trades.operateur  
inner join 	tiers  
on 		tiers.ident = trades.entite  
left join  	ric
on 		ric.sicovam = trades.sicovam

/*
left join 	extrnl_references_instruments eri_risk 
on    		  Instrument.sicovam = eri_risk.sophis_ident 
and  (eri_risk.ref_ident = 18 or  eri_risk.ref_ident is null ) -- country_of_risk
left join 	extrnl_references_instruments eri_domicile 
on    		  Instrument.sicovam = eri_domicile.sophis_ident
and  (eri_domicile.ref_ident = 19 or eri_domicile.ref_ident is null) -- country_of_domicile
*/

left join sector_instrument_association sia_risk
  on Instrument.sicovam = sia_risk.sicovam
    and sia_risk.type = 5350
left join sectors country_of_risk
  on sia_risk.sector = country_of_risk.id

left join sector_instrument_association sia_dom
  on Instrument.sicovam = sia_dom.sicovam
    and sia_dom.type = 5347
left join sectors country_of_domicile
  on sia_dom.sector = country_of_domicile.id

where  
        Trades.type in (1,140,1444,1494)  --purchase/sale, short sale, purchase/sale-forward risk, secondary offering
        and Trades.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
        and 	(
		Instrument.TYPE IN ('F','A','O') --futures/shares/bonds
		OR 
		(Instrument.TYPE = 'D' AND Instrument.affectation in (9,10)) --Options/convertibles
		)  
        and trades.dateneg BETWEEN IN_DATE_FROM AND IN_DATE_TO --date range from Excel
        and FUND_BOOK_STRATEGY.BOOK_ID in 	(
						select 
							BTG_MAPPING_CODE.INPUT_CODE 
						from 
							BTG_MAPPING_CODE 
						where 
							BTG_MAPPING_CODE.OUTPUT_CODE  = IN_REGION and 
              BTG_MAPPING_CODE.TYPE_ID  = 33 and 
              BTG_MAPPING_CODE.SOURCE_ID  = 3
						) --region taken from Excel
        order by 6,4, 10 asc;
    END COMPLIANCE_FAIRPRICE;
  





PROCEDURE PRICE_REC

(
IN_DATE_REC IN DATE
, IN_REGION IN VARCHAR2
, OUT_CURSOR OUT T_CURSOR
) AS

BEGIN
	OPEN OUT_CURSOR
	FOR


with openPositions as (
                        --open positions
                        SELECT  
                                HISTOMVTS.sicovam
                                ,HISTOMVTS.opcvm
                                ,sum(HISTOMVTS.quantite) quantity_sum
                                
                        FROM HISTOMVTS
                        
                        INNER JOIN (
                                    SELECT FOLIO.ident
                                    FROM FOLIO 
                                    START WITH FOLIO.ident IN (
                                                                SELECT BTG_MAPPING_CODE.INPUT_CODE
                                                                FROM BTG_MAPPING_CODE
                                                                WHERE BTG_MAPPING_CODE.OUTPUT_CODE = CASE WHEN IN_REGION='ALL' THEN BTG_MAPPING_CODE.OUTPUT_CODE ELSE IN_REGION END  
                                                                --WHERE BTG_MAPPING_CODE.OUTPUT_CODE = 'LDN'
                                                                  AND BTG_MAPPING_CODE.TYPE_ID  = 33 
                                                                    AND BTG_MAPPING_CODE.SOURCE_ID  = 3
                                                              ) CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
                                    ) FOLIOS 
                          ON FOLIOS.ident = HISTOMVTS.opcvm
                        
                        INNER JOIN BO_KERNEL_STATUS_COMPONENT 
                          ON BO_KERNEL_STATUS_COMPONENT.kernel_status_id = HISTOMVTS.backoffice
                            AND BO_KERNEL_STATUS_COMPONENT.kernel_status_group_id = 27882
                        
                        INNER JOIN BUSINESS_EVENTS
                          ON BUSINESS_EVENTS.Id = HISTOMVTS.Type
                            AND BUSINESS_EVENTS.COMPTA = 1
                        
                        WHERE HISTOMVTS.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --exclude cancelled trades
                        AND HISTOMVTS.dateneg <= IN_DATE_REC
                        --AND HISTOMVTS.dateneg <= '01-MAR-2016'
                        
                        group by sicovam, opcvm
                        
                        HAVING SUM(HISTOMVTS.quantite) <> 0
),
Strategies as (
                SELECT        
                        CONNECT_BY_ROOT(FOLIO.ident)                                               AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                                AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2)        AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)         AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4)        AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)         AS BOOK_NAME
                      , FOLIO.ident                                                                AS STRATEGY_ID
                      , FOLIO.name                                                                 AS STRATEGY_NAME
                      , level

                FROM FOLIO

                WHERE LEVEL >= 4
                START WITH          FOLIO.ident   IN (14414,90565)--Primary funds
                CONNECT BY  PRIOR    FOLIO.ident   = FOLIO.mgr
              )
SELECT op.sicovam SICOVAM
      ,titres.code_emet UNDERLYING_SICOVAM
      ,RIC.SERVISEN AS SERVISEN
      ,TITRES.REFERENCE AS TICKER_CFD
      ,H2.t AS T
      ,HISTORIQUE.d AS D
	  ,H3.d as D_1BD
      ,BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam) AS INSTRUMENT_TYPE
      ,FIDLIST.SPOT_SAVE
      ,FIDLIST.NAME
      ,regexp_replace(RTRIM(XMLAGG(XMLELEMENT(E,BOOK_NAME,',').EXTRACT('//text()') ORDER BY BOOK_NAME).GetClobVal(),','),'([^,]+)(,\1)+', '\1') STRATEGY
      ,sum(op.quantity_sum) QUANTITY
	  ,A.LIBELLE AS ALLOTMENT
	  ,TITRES.LIBELLE AS INST_NAME
      
FROM openPositions op

LEFT JOIN titres
  on op.sicovam = titres.sicovam
  
INNER JOIN Strategies s
  ON op.opcvm = s.STRATEGY_ID
  
LEFT JOIN affectation a
  ON titres.affectation = a.ident

INNER JOIN RIC 
  ON RIC.sicovam = DECODE(TITRES.type, 'G', TITRES.code_emet, TITRES.sicovam)
    AND RIC.fid != 0

LEFT JOIN HISTORIQUE 
  ON HISTORIQUE.sicovam = DECODE(TITRES.type, 'G', TITRES.code_emet, TITRES.sicovam)
    AND HISTORIQUE.jour = IN_DATE_REC
    --AND HISTORIQUE.jour = '01-MAR-2016'

LEFT JOIN HISTORIQUE H2 
  ON H2.sicovam = DECODE(TITRES.type, 'G', TITRES.sicovam, TITRES.code_emet)
    AND H2.jour = IN_DATE_REC
    --AND H2.jour = '01-MAR-2016'

LEFT JOIN HISTORIQUE H3 
  ON H3.sicovam = DECODE(TITRES.type, 'G', TITRES.code_emet, TITRES.sicovam)
    AND H3.jour = BTG_BUSINESS_DATE(IN_DATE_REC,-1)

INNER JOIN FIDLIST
  ON RIC.FID = FIDLIST.ITEM

WHERE RIC.prefixe = 'Global'

AND NOT (
          BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam) = 'Shares' 
          AND titres.affectation not in (4, 1601)
        )

--Filter out mortgages
AND NOT (
          titres.affectation in (
                            35, --MBS - Agency
                            1252, --MBS - Non Agency
                            1253, --CMBS
                            1353, --MBS - European
                            1450 --ABS - Student Loan
                            )
        )

--Filter out UST
AND titres.sicovam not in	(
                            SELECT titres.sicovam 
                            FROM titres
                            LEFT JOIN sector_instrument_association
                              ON titres.sicovam = sector_instrument_association.sicovam
                                AND sector_instrument_association.type = 5347 --Country of Domicile
                            WHERE affectation in (25,1251) --Gov bonds, Agency Bond
                            AND sector = 6290 --UNITED STATES
                          )
                          
group by op.sicovam, titres.code_emet, RIC.SERVISEN, TITRES.REFERENCE, H2.t, H3.d,
HISTORIQUE.d, BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam), FIDLIST.SPOT_SAVE, FIDLIST.NAME, A.LIBELLE, TITRES.LIBELLE
                          
                     
UNION ALL


--include indexes
select titres.sicovam
      ,titres.code_emet UNDERLYING_SICOVAM
      ,RIC.SERVISEN AS SERVISEN
      ,TITRES.REFERENCE AS TICKER_CFD
      ,H2.t AS T
      ,HISTORIQUE.d AS D
	  ,H3.d as D_1BD
      ,BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam) AS INSTRUMENT_TYPE
      ,FIDLIST.SPOT_SAVE
      ,FIDLIST.NAME
      ,null STRATEGY --no strat for indexes
      ,null QUANTITY --no quantity for indexes
	  ,A.LIBELLE AS ALLOTMENT
	  ,TITRES.LIBELLE AS INST_NAME
      
from titres

inner join ric
  on titres.sicovam = ric.sicovam
    and ric.prefixe = 'Global'

LEFT JOIN affectation a
  ON titres.affectation = a.ident
    
LEFT JOIN HISTORIQUE 
  ON HISTORIQUE.sicovam = DECODE(TITRES.type, 'G', TITRES.code_emet, TITRES.sicovam)
    AND HISTORIQUE.jour = IN_DATE_REC
    --AND HISTORIQUE.jour = '01-MAR-2016'

LEFT JOIN HISTORIQUE H2 
  ON H2.sicovam = DECODE(TITRES.type, 'G', TITRES.sicovam, TITRES.code_emet)
    AND H2.jour = IN_DATE_REC
    --AND H2.jour = '01-MAR-2016'

LEFT JOIN HISTORIQUE H3 
  ON H3.sicovam = DECODE(TITRES.type, 'G', TITRES.code_emet, TITRES.sicovam)
    AND H3.jour = BTG_BUSINESS_DATE(IN_DATE_REC,-1)

INNER JOIN FIDLIST
  ON RIC.FID = FIDLIST.ITEM

where type = 'I'

AND NOT (
          BTG_GET_INSTRUMENT_TYPE(TITRES.sicovam) = 'Shares' 
          AND titres.affectation not in (4, 1601)
        )

--Filter out mortgages
AND NOT (
          titres.affectation in (
                            35, --MBS - Agency
                            1252, --MBS - Non Agency
                            1253, --CMBS
                            1353, --MBS - European
                            1450 --ABS - Student Loan
                            )
        )

--Filter out UST
AND titres.sicovam not in	(
                            SELECT titres.sicovam 
                            FROM titres
                            LEFT JOIN sector_instrument_association
                              ON titres.sicovam = sector_instrument_association.sicovam
                                AND sector_instrument_association.type = 5347 --Country of Domicile
                            WHERE affectation in (25,1251) --Gov bonds, Agency Bond
                            AND sector = 6290 --UNITED STATES
                          )


ORDER BY INSTRUMENT_TYPE,SERVISEN;

	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END PRICE_REC;







  PROCEDURE CURVE_PRICE_REC
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
select  d.libelle  CCY,
        t.libelle CurveFamily,
        c.libelle CurveName,
        h.dategraphe CurveDate,
        case
          when i.type = '1' then to_date('01/01/1904', 'dd/mm/yyyy')+i.x
          when i.type = '2' then h.dategraphe+i.x
          when i.type = '3' then add_months(h.dategraphe,i.x)
          when i.type = '4' then add_months(h.dategraphe,i.x*12)
          when i.type = '5' then null --rolling maturity months
          when i.type = '6' then null --rolling maturity quarters
          when i.type = '12' then to_date('01/01/1904', 'dd/mm/yyyy')+i.x
        end as maturity,  
        case
          when i.type = '1' then null
          when i.type = '5' then null
          when i.type = '6' then null
          when i.type = '12' then null
          else i.x
        end as term,
        case
          when i.type = '1' then null
          when i.type = '2' then 'day'
          when i.type = '3' then 'month'
          when i.type = '4' then 'year' 
          when i.type = '5' then null
          when i.type = '6' then null
        end as term2,
        r.sicovam SICOVAM,
        r.servisen    Identifier,
        decode(f.factor,null,i.y,i.y/f.factor)    Price         
from  devisev2 d,
      typecourbetaux t,
      courbetaux c,
      histotaux h,
      gr_infoscourbe g,
      gr_points i,
      ric r,
      identrictaux2 e,
      fidlist f
where t.codedev = d.code
and   c.codetypecourbetaux = t.code
and   h.codedev = c.code
and   h.dategraphe = trunc(btg_business_date(sysdate,-1))
and   h.graphe = g.graphe
and   i.courbe = g.ident
and   r.sicovam = e.ident
and   e.courbetaux = h.codedev
and   e.maturity = i.x
and   e.type = i.type
and   f.item = r.fid
order by 1,2,3,4,5;
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END CURVE_PRICE_REC; 
  
        PROCEDURE FX_REC
  (
    IN_DATE_FROM  IN    DATE
  , OUT_CURSOR    OUT   T_CURSOR
  ) AS
  BEGIN
  
      OPEN OUT_CURSOR FOR     

select 
	devisev2.libelle Name,
	RIC.SERVISEN AS SERVISEN, 
	prices.d AS D,
	prices.JOUR,
	devise_to_str(devisev2.code) CCY,
	devisev2.code Sicovam
from 
	RIC 
left join (select * from historique where HISTORIQUE.JOUR = trunc(IN_DATE_FROM)) prices
on prices.sicovam = RIC.sicovam 
inner join devisev2
on devisev2.code = ric.sicovam
ORDER BY  SERVISEN;

 EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
  
  END FX_REC;
    
    PROCEDURE COUPON_DIVIDEND_CHECK
  (
  
    IN_DATE_FROM  IN    DATE
  , IN_DATE_TO    IN    DATE
  , IN_REGION     IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  ) AS
  BEGIN
  
      OPEN OUT_CURSOR FOR      
select  
        Trades1.sicovam                                                                               Sicovam,  
        DECODE (Instrument.TYPE,'O','Bond','A','Equity','D','Convertible','G','CFD','Other')          InstType, 
        Trades1.refcon                                                                                TradeID,  
        tiers.NAME                                                                                    Fund,
        FUND_BOOK_STRATEGY.BOOK_NAME                                                                  Strategy,
        FUND_BOOK_STRATEGY.FOLIO_NAME                                                                 Folio,
        DECODE (Instrument.TYPE,
                'O',CONCAT(Instrument.reference,' ISIN'),
                'D',CONCAT(Instrument.reference,' ISIN'),
                'G',underlying.reference,
                Instrument.reference)                                                                 Ticker,  
        Instrument.libelle                                                                            Name,
        trunc(Trades1.DATENEG)                                                                        TradeDate,  
        trunc(Trades1.DATEVAL)                                                                        ValueDate,
        Trades1.quantite                                                                              Quantity,
        DECODE (Instrument.TYPE,
                'O',nvl(ROUND(Trades1.QUANTITE*Instrument.nominal, 8),0)  ,
                'D',nvl(ROUND(Trades1.QUANTITE*Instrument.nominal, 8),0)  ,
                null)                                                                                 Nominal,
        Trades1.montant                                                                               NetAmount,  
        DEVISE_TO_STR(Trades1.devisepay)                                                              Currency,  
        'NOT POSTED'                                                                                  Status  
from  
        mvt_auto Trades1  
left JOIN ( 
                            SELECT  
                            CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                          , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2) AS Fund_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 4, 5) AS FOLIO_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 4, 5) AS FOLIO_NAME 
                          , FOLIO.ident AS STRATEGY_ID 
                          , FOLIO.name AS STRATEGY_NAME 
                          , level 
        FROM FOLIO
        WHERE LEVEL >= 4
        START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,9056) 
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
        ) FUND_BOOK_STRATEGY
        ON FUND_BOOK_STRATEGY.STRATEGY_ID = Trades1.opcvm
inner join  titres Instrument  
on          Instrument.sicovam = Trades1.sicovam  
left join   titres underlying
on          Instrument.code_emet = underlying.sicovam
left join	riskusers  
on          riskusers.ident = Trades1.operateur  
inner join  tiers  
on          tiers.ident = Trades1.entite  
left join   ric
on          ric.sicovam = Trades1.sicovam

INNER JOIN AFFECTATION 
ON AFFECTATION.ident = Instrument.affectation
LEFT JOIN  SECTOR_INSTRUMENT_ASSOCIATION sea 
ON Instrument.sicovam = sea.sicovam
AND sea.TYPE=5348
LEFT JOIN sectors
ON sea.sector = sectors.ID 

where  
            Trades1.type in (2,147)  --coupon/dividend

AND         (
            Instrument.TYPE = 'O' and ((Instrument.affectation != 25 AND sectors.code != 'US') or Instrument.affectation not in (35,1252,1253,1353))  --bonds
	    OR
            (Instrument.TYPE = 'D' AND Instrument.affectation = 9) --convertible bonds
            )  
            
and         (
            (Trades1.dateneg BETWEEN IN_DATE_FROM AND IN_DATE_TO) --date range from Excel
            OR
            (Trades1.dateval BETWEEN IN_DATE_FROM AND IN_DATE_TO) --date range from Excel
            )
 

and         FUND_BOOK_STRATEGY.BOOK_ID in ( select 
                                                    BTG_MAPPING_CODE.INPUT_CODE
                                            FROM    BTG_MAPPING_CODE 
                                            WHERE   BTG_MAPPING_CODE.OUTPUT_CODE = IN_REGION AND
                                                    BTG_MAPPING_CODE.TYPE_ID  = 33 and 
                                                    BTG_MAPPING_CODE.SOURCE_ID  = 3) --region taken from Excel
UNION
  select  
        Trades.sicovam                                                                                Sicovam,  
        DECODE (Instrument1.TYPE,'O','Bond','A','Equity','D','Convertible','G','CFD','Other')         InstType, 
        Trades.refcon                                                                                 TradeID,  
        tiers1.NAME                                                                                   Fund,  
        FUND_BOOK_STRATEGY1.BOOK_NAME                                                                 Strategy,
        FUND_BOOK_STRATEGY1.FOLIO_NAME                                                                Folio,                           
        DECODE (Instrument1.TYPE,
                'O',CONCAT(Instrument1.reference,' ISIN'),
                'D',CONCAT(Instrument1.reference,' ISIN'),
                'G',underlying1.reference,
                Instrument1.reference)                                                                Ticker,  
        Instrument1.libelle                                                                           Name,
        trunc(Trades.DATENEG)                                                                         TradeDate,  
        trunc(Trades.DATEVAL)                                                                         ValueDate,
        trades.quantite                                                                               Quantity,
        DECODE (Instrument1.TYPE,
                'O',nvl(ROUND(Trades.QUANTITE*Instrument1.nominal, 8),0)  ,
                'D',nvl(ROUND(Trades.QUANTITE*Instrument1.nominal, 8),0)  ,
                null)                                                                                  Nominal,
        trades.montant                                                                                 NetAmount,  
        DEVISE_TO_STR(Trades.devisepay)                                                                Currency,  
        'POSTED'                                                                                       Status  
from  
        histomvts Trades  
left JOIN ( 
                            SELECT  
                            CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                          , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2) AS Fund_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 4, 5) AS FOLIO_ID 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 4, 5) AS FOLIO_NAME 
                          , FOLIO.ident AS STRATEGY_ID 
                          , FOLIO.name AS STRATEGY_NAME 
                          , level 
        FROM FOLIO
        WHERE LEVEL >= 4
        START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565)--Primary funds
        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
        ) FUND_BOOK_STRATEGY1
        ON FUND_BOOK_STRATEGY1.STRATEGY_ID = Trades.opcvm
inner join  titres Instrument1  
on          Instrument1.sicovam = Trades.sicovam  
left join   titres underlying1
on          Instrument1.code_emet = underlying1.sicovam
inner join  riskusers riskusers1
on          riskusers1.ident = trades.operateur  
inner join  tiers tiers1 
on          tiers1.ident = Trades.entite  
left join   ric ric1
ON          ric1.sicovam = trades.sicovam

INNER JOIN AFFECTATION AFFECTATION1
ON AFFECTATION1.ident = Instrument1.affectation
LEFT JOIN  SECTOR_INSTRUMENT_ASSOCIATION sea1 
ON Instrument1.sicovam = sea1.sicovam
AND sea1.TYPE=5348
LEFT JOIN sectors sectors1
ON sea1.sector = sectors1.ID 

where  
            Trades.type in (2,147)  --coupon/dividend
and         Trades.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND         (
            Instrument1.TYPE = 'O' and ((Instrument1.affectation != 25 AND sectors1.code != 'US') or Instrument1.affectation not in (35,1252,1253,1353))  --bonds
	    OR
            (Instrument1.TYPE = 'D' AND Instrument1.affectation = 9) --convertible bonds
            )  
            
and        (
            (Trades.dateneg BETWEEN IN_DATE_FROM AND IN_DATE_TO) --date range from Excel
            OR
            (Trades.dateval BETWEEN IN_DATE_FROM AND IN_DATE_TO) --date range from Excel
            )

and         FUND_BOOK_STRATEGY1.BOOK_ID in ( select 
                                                    BTG_MAPPING_CODE.INPUT_CODE 
                                            FROM    BTG_MAPPING_CODE 
                                            WHERE   BTG_MAPPING_CODE.OUTPUT_CODE = IN_REGION AND
                                                    BTG_MAPPING_CODE.TYPE_ID  = 33 and 
                                                    BTG_MAPPING_CODE.SOURCE_ID  = 3) --region taken from Excel

order by 8,7 asc;
    END COUPON_DIVIDEND_CHECK;
    
    PROCEDURE EQUITY_INST_REC
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
       select 
              titres.sicovam                          Sicovam,
              titres.libelle                          Equity_Name,
              titres.reference                        Equity_Reference,
              ISIN.value                              ISIN,
              SEDOL.value                             SEDOL,
              ticker.servisen                         TICKER,
              TICKER.prefixe                          Global,
              fidlist.name                            FID,
              Issuer.libelle                          Issuer,
              Issuer.reference                        Issuer_Ref,
              TITRES.beta                             Beta,
              marche.libelle                          Market,
              devise_to_str(titres.devisectt)         Currency,
              titres.quotite                          Min_lot
from          titres
left join     extrnl_references_instruments ISIN
on            titres.sicovam = ISIN.sophis_ident and ISIN.ref_ident = 1
left join     extrnl_references_instruments SEDOL
on            titres.sicovam = SEDOL.sophis_ident and SEDOL.ref_ident = 2
left join     ric TICKER
on            titres.sicovam = ticker.sicovam
left join     fidlist
on            TICKER.fid = fidlist.item
left join     titres Issuer
on            Issuer.sicovam = titres.base1
left join     marche
on            marche.mnemomarche = titres.marche and marche.codedevise = titres.devisectt
where
              titres.type = 'A'
and           titres.affectation not in ('46','1140', '45') --External Fund Series/Fake Share/External Funds
order by 4
;
    
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END EQUITY_INST_REC; 
  
      
  
        PROCEDURE MBS_INST_REC
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
    OPEN p_CURSOR FOR
      SELECT 
     Security.SICOVAM
		,Security.reference AS ISIN
		,Security.libelle AS BBG_NAME
		,to_char(Security.dateregl, 'mm-dd-yyyy') AS ISSUE_DATE
		,to_char(Security.finper, 'mm-dd-yyyy') AS MATURITY_DATE
    ,CASE
        WHEN rates.libelle is not null
        THEN
            DECODE (Security.Duree1,
                    1, 'Monthly',
                    2, 'Quarterly',
                    3, 'Semi Annual',
                    4, 'Annual',
                    5, 'Final',
                    6, 'Weekly',
                    6, 'Daily',
                    7, '2 Weeks',
                    8, '3 Weeks',
                    9, '4 Weeks',
                    10, 'IMM',
                    11, '2 Months',
                    12, '5 Months',
                    13, '7 Months',
                    14, '4 Months',
                    15, '8 Months',
                    16, '9 Months',
                    17, '10 Months',
                    18, '11 Months',
                    'No idea sunsine')
        ELSE   
            DECODE (Security.freq_coupon,
                    1,'Monthly',
                    2,'Quarterly',
                    3,'Semi Annual',
                    4,'Annual',
                    'No idea sunshine')                         
    END AS                                                      
                                                                Freq
,CASE
        WHEN rates.libelle is not null
        THEN
            DECODE (Security.Unit1,
                    1, 'ACT/360',
                    2, 'ACT/365 FIXED',
                    3, 'ACT/ACT (ISDA)',
                    4, '30U/360',
                    5, '30E/360 ISDA00',
                    6, 'Actual/365.25',
                    7, 'ACT/ACT (ISMA)ISDA00',
                    8, 'NL/365',
                    9, 'ACT/ACT (AFB)',
                    10, '30/360 ISDA06',
                    11, '30E/360 ISDA06',
                    12, 'ACT/ACT (ISMA)ISDA06',
                    13, 'Open/252',
                    14, 'Open/Open',
                    15, 'ACT/365(JGB)',
                    'No idea sunshine')                  
        ELSE   
            DECODE (Security.BASIS_AC,
                    1,'ACT/360',
                    2,'ACT/365 FIXED',
                    3,'ACT/ACT(ISDA)',
                    4,'30U/360',
                    5,'30E/360 ISDA00',
                    6,'Actual/365.25',
                    7,'ACT/ACT (ISMA) ISDA00',
                    8,'NL/365',9,'ACT/ACT (AFB)',
                    10,'30/360 ISDA06',
                    11,'30E/360 ISDA06',
                    12,'ACT/ACT (ISMA) ISDA06',
                    13,'Open/252',
                    14,'Open/Open',
                    15,'ACT/365 (JGB)',
                    'No idea sunshine')                       
    END AS                                                      
                                                                Basis
		,Security.croidiv AS FIXEDRATE
    ,Security.fixe1 AS SPREAD
    ,rates.libelle AS IR_INDEX
    ,to_char(Security.firstsettlementdate, 'mm-dd-yyyy') AS FIRSTSETTLEMENTDATE
    ,to_char(Security.datecoupon2, 'mm-dd-yyyy') AS FIRSTCOUPONDATE_FIXED
		,to_char(Security.datecalcul, 'mm-dd-yyyy') AS LASTBUTONECOUPONDATE_FIXED
		,Security.nbpts AS SETTLEMENTLAG
		,Security.pay_shift AS OWNERSHIP_SHIFT
		,Security.settle_shift AS SETTLEMENT_SHIFT
    ,DEVISE_TO_STR(Security.devisectt)                          CCY
    --,CNTRY_OF_RISK.value                                        CNTRY_OF_RISK
	,country_of_risk.code										CNTRY_OF_RISK


	,Security.modele AS CALCMODEL
    ,DECODE (nvl(Security.affectation,1),
                  1,'None Defined',
                  7,'Repos',
                  9,'Convertible',
                  13,'Debt Instruments',
                  20,'Cash',
                  25,'Gov Bonds',
                  26,'Corp Bonds',
                  34,'TBA',
                  35,'MBS - Agency',
                  38,'ABS',
                  1102,'Fully Funded TRS',
                  1180,'Bond - Dummy',
                  1200,'Bond - Time Deposit',
                  1252,'MBS -  Non Agency',
                  1253,'CMBS',
                  1353,'MBS - European',
                  1450,'ABS - Student Loan')    AS                                   
                                                                Allotment
    ,t2.libelle                                                 IssuerName
    ,t2.reference                                               IssuerReference

	FROM TITRES Security
  LEFT JOIN clause 
    ON Security.Sicovam = Clause.Sicovam
Left JOIN titres t2
    ON Security.Code_Emet = t2.Sicovam
Left JOIN titres rates
    ON Security.base1 = rates.Sicovam

/*
left join extrnl_references_instruments CNTRY_OF_RISK
on Security.SICOVAM = CNTRY_OF_RISK.sophis_ident and CNTRY_OF_RISK.ref_ident = 18
*/

left join sector_instrument_association sia_risk
  on Security.sicovam = sia_risk.sicovam
    and sia_risk.type = 5350
left join sectors country_of_risk
  on sia_risk.sector = country_of_risk.id

	WHERE Security.TYPE = 'O'
		AND Security.AFFECTATION in (35,38,1252,1253,1450,1353)
	ORDER BY 
    Security.REFERENCE DESC;
    
	EXCEPTION
	
		WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm);	
	
	END MBS_INST_REC;
    
    
------------------------------------------------------------------------------
-- Name: ITALIAN_WHT
------------------------------------------------------------------------------
-- Author: Matt Kelly		Date: 18th Dec 2013


-- Updated: 25th July 2014 by Matt Kelly
-- Updated: 2nd Oct 2015 by Matt Kelly
------------------------------------------------------------------------------

	PROCEDURE ITALIAN_WHT
(
		IN_FROM_DATE IN DATE
		,IN_TO_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
) AS

BEGIN
	OPEN OUT_CURSOR
	FOR


SELECT    FUND_BOOK_STRATEGY.BOOK_NAME             STRATEGY_NAME
          ,FUND_BOOK_STRATEGY.Fund_NAME            FUND_NAME 
          ,Trades.sicovam                          SICOVAM
          ,Trades.refcon                           TRADE_ID
          ,trader.name                             TRADER
          
          ,CASE
            WHEN Instrument.type = 'O' THEN 'Bond'
            WHEN Instrument.affectation = 9 THEN 'Convertible'
            WHEN Instrument.type = 'L' THEN 'Repo'
          END as                                   TYPE
          
          ,Instrument.libelle                      NAME
          
          ,CASE 
            WHEN Instrument.type = 'O' THEN concat(Instrument.reference, ' Corp')
            WHEN Instrument.affectation = 9 THEN concat(Instrument.reference, ' Corp')
            WHEN Instrument.type = 'L' THEN concat(t2.reference, ' Corp')
          END as                                   REFERENCE
          
          ,trunc(Trades.DATENEG)                   d$TRADE_DATE
          ,devise_to_str(Instrument.devisectt)     CURRENCY
          
          ,CASE
            WHEN Instrument.type = 'O' THEN Trades.quantite*Instrument.nominal
            WHEN instrument.affectation = 9 THEN Trades.quantite*Instrument.nominal
            WHEN Instrument.type = 'L' THEN Trades.quantite*t2.nominal
          END as                                   NOMINAL
          
          ,Trades.dateneg                          TRADE_DATE
          ,Trades.dateval                          VALUE_DATE
          
          ,CASE
            WHEN Instrument.type = 'O' THEN Instrument.dateregl
            WHEN instrument.affectation = 9 THEN Instrument.dateregl
            WHEN Instrument.type = 'L' THEN t2.dateregl
          END as                                   ISSUE_DATE
          
          ,CASE
            WHEN Instrument.type = 'O' THEN Instrument.finper
            WHEN Instrument.affectation = 9 THEN Instrument.finper
            WHEN Instrument.type = 'L' THEN t2.finper
          END as                                   MATURITY_DATE

          ,Trades.opcvm                            FOLIO_ID
          ,CASE
            WHEN (instrument.affectation = 9) THEN --If instrument is a convertible
              CASE
                WHEN (Instrument.BASIS_YTM = 1) THEN 'ACT/360'
                WHEN (Instrument.BASIS_YTM = 2) THEN 'ACT/365 FIXED'
                WHEN (Instrument.BASIS_YTM = 3) THEN 'ACT/ACT (ISDA)'
                WHEN (Instrument.BASIS_YTM = 4) THEN '30U/360'
                WHEN (Instrument.BASIS_YTM = 5) THEN '30E/360 ISDA00'
                WHEN (Instrument.BASIS_YTM = 6) THEN 'Actual/365.25'
                WHEN (Instrument.BASIS_YTM = 7) THEN 'ACT/ACT (ISMA) ISDA00'
                WHEN (Instrument.BASIS_YTM = 8) THEN 'NL/365'
                WHEN (Instrument.BASIS_YTM = 9) THEN 'ACT/ACT (AFB)'
                WHEN (Instrument.BASIS_YTM = 10) THEN '30/360 ISDA06'
                WHEN (Instrument.BASIS_YTM = 11) THEN '30E/360 ISDA06'
                WHEN (Instrument.BASIS_YTM = 12) THEN 'ACT/ACT (ISMA) ISDA06'
                WHEN (Instrument.BASIS_YTM = 13) THEN 'Open/252'
                WHEN (Instrument.BASIS_YTM = 14) THEN 'Open/Open'
                WHEN (Instrument.BASIS_YTM = 15) THEN 'ACT/365(JGB)'
                ELSE 'UNKNOWN'
              END
            WHEN (Instrument.unit1 <> 0) THEN --If unit1 field is not zero, use it to populate the Accrued_Day_Count_Basis column
              CASE
                WHEN (Instrument.unit1 = 1) THEN 'ACT/360'
                WHEN (Instrument.unit1 = 2) THEN 'ACT/365 FIXED'
                WHEN (Instrument.unit1 = 3) THEN 'ACT/ACT (ISDA)'
                WHEN (Instrument.unit1 = 4) THEN '30U/360'
                WHEN (Instrument.unit1 = 5) THEN '30E/360 ISDA00'
                WHEN (Instrument.unit1 = 6) THEN 'Actual/365.25'
                WHEN (Instrument.unit1 = 7) THEN 'ACT/ACT (ISMA) ISDA00'
                WHEN (Instrument.unit1 = 8) THEN 'NL/365'
                WHEN (Instrument.unit1 = 9) THEN 'ACT/ACT (AFB)'
                WHEN (Instrument.unit1 = 10) THEN '30/360 ISDA06'
                WHEN (Instrument.unit1 = 11) THEN '30E/360 ISDA06'
                WHEN (Instrument.unit1 = 12) THEN 'ACT/ACT (ISMA) ISDA06'
                WHEN (Instrument.unit1 = 13) THEN 'Open/252'
                WHEN (Instrument.unit1 = 14) THEN 'Open/Open'
                WHEN (Instrument.unit1 = 15) THEN 'ACT/365(JGB)'
                ELSE 'UNKNOWN'
              END
            ELSE --Else, unit1 field is zero, so use the BASIS_AC field to populate the Accrued_Day_Count_Basis column instead
              CASE
                WHEN (Instrument.BASIS_AC = 1) THEN 'ACT/360'
                WHEN (Instrument.BASIS_AC = 2) THEN 'ACT/365 FIXED'
                WHEN (Instrument.BASIS_AC = 3) THEN 'ACT/ACT (ISDA)'
                WHEN (Instrument.BASIS_AC = 4) THEN '30U/360'
                WHEN (Instrument.BASIS_AC = 5) THEN '30E/360 ISDA00'
                WHEN (Instrument.BASIS_AC = 6) THEN 'Actual/365.25'
                WHEN (Instrument.BASIS_AC = 7) THEN 'ACT/ACT (ISMA) ISDA00'
                WHEN (Instrument.BASIS_AC = 8) THEN 'NL/365'
                WHEN (Instrument.BASIS_AC = 9) THEN 'ACT/ACT (AFB)'
                WHEN (Instrument.BASIS_AC = 10) THEN '30/360 ISDA06'
                WHEN (Instrument.BASIS_AC = 11) THEN '30E/360 ISDA06'
                WHEN (Instrument.BASIS_AC = 12) THEN 'ACT/ACT (ISMA) ISDA06'
                WHEN (Instrument.BASIS_AC = 13) THEN 'Open/252'
                WHEN (Instrument.BASIS_AC = 14) THEN 'Open/Open'
                WHEN (Instrument.BASIS_AC = 15) THEN 'ACT/365(JGB)'
                ELSE 'UNKNOWN'
              END
          END ACCRUED_DAY_COUNT_BASIS
          ,DEPOSITARY.name                   DEPOSITARY
                    
    FROM            histomvts Trades 
    
    LEFT JOIN       riskusers trader
      ON              trader.ident = Trades.operateur

    LEFT JOIN       devisev2 Currency
      ON              Currency.code= Trades.devisepay
    
    INNER JOIN      titres Instrument
      ON              Instrument.sicovam= Trades.sicovam
      
    LEFT JOIN       titres t2
      ON              Instrument.code_emet = t2.sicovam
    
    LEFT JOIN       Ric
      ON              Instrument.Sicovam = Ric.Sicovam
      
    LEFT JOIN       Ric Ric2
      ON              t2.Sicovam = Ric2.Sicovam
    
    LEFT JOIN extrnl_references_instruments isin
      ON trades.sicovam = isin.sophis_ident
        AND ref_ident = 1
      
    --country of risk
    LEFT JOIN sector_instrument_association sia
      ON Instrument.sicovam = sia.sicovam
        AND sia.type = 5350
    
    LEFT JOIN sectors country_of_risk
      ON sia.sector = country_of_risk.id
    -----------------
    
    --underlying country of risk
    LEFT JOIN sector_instrument_association sia2
      ON t2.sicovam = sia2.sicovam
        AND sia2.type = 5350
    
    LEFT JOIN sectors country_of_risk2
      ON sia2.sector = country_of_risk2.id
    -----------------
    
    INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN  (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414, 90565) --Primary Funds, UCITS Fund --
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID =   Trades.OPCVM
    
    INNER JOIN BUSINESS_EVENTS ON BUSINESS_EVENTS.Id = Trades.Type
      AND BUSINESS_EVENTS.COMPTA = 1 --trades, i.e. excludes coupons, etc.
      
    LEFT JOIN tiers Broker
      ON Trades.courtier = Broker.IDENT
      
    LEFT JOIN tiers Depositary
      ON DEPOSITARY.ident = trades.DEPOSITAIRE
      
    
    WHERE   (
              (Instrument.type = 'O' AND country_of_risk.id = 6359) --Bonds with Country of Risk = ITALY
      OR
              (Instrument.affectation = 9 AND country_of_risk.id = 6359) --Bonds with Country of Risk = ITALY
      OR
              (Instrument.type = 'L' AND country_of_risk2.id = 6359 AND (t2.affectation is null or t2.affectation <> 1353)) --repos with COR = ITALY and underlying allotment is not "MBS - European"
            )

    AND         Trades.dateval >=  IN_FROM_DATE
    AND         Trades.dateval <=  IN_TO_DATE
    
    AND Trades.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --cancelled trades
    
    AND Broker.name != 'INTERNAL TRADES'
	
  ORDER BY 1,2;



	EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END ITALIAN_WHT;

-- END ITALIAN_WHT -----------------------------------------------

------------------------------------------------------------------------------
-- Name: SHARES_REIT
------------------------------------------------------------------------------
-- Author: Davi Xavier		          Date: 25th Mar 2015
------------------------------------------------------------------------------

	PROCEDURE SHARES_REIT
(
		IN_FROM_DATE IN DATE
		,IN_TO_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
) AS

BEGIN
	OPEN OUT_CURSOR
	FOR


SELECT  TITRES.REFERENCE            REFERENCE 
      , sectors.code                Country
      , SUM(HISTOMVTS.quantite)     Quantity  

FROM HISTOMVTS 
     
INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 1, 2) AS FUND_ID 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2) AS Fund_NAME 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_ID 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_NAME 
            , FOLIO.ident AS STRATEGY_ID 
            , FOLIO.name AS STRATEGY_NAME 
            ,level 
            FROM FOLIO 
            WHERE LEVEL >= 4 
            START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND) --(14414,90565) --
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
          ) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID =HISTOMVTS.OPCVM 

INNER JOIN TITRES 
ON TITRES.sicovam = HISTOMVTS.sicovam 

INNER JOIN BUSINESS_EVENTS 
ON BUSINESS_EVENTS.id = HISTOMVTS.type 
AND BUSINESS_EVENTS.compta =1 --position affecting trades only 

LEFT JOIN AFFECTATION 
ON AFFECTATION.ident = TITRES.affectation 

LEFT JOIN  SECTOR_INSTRUMENT_ASSOCIATION sea 
ON TITRES.sicovam = sea.sicovam
AND sea.TYPE=5348

left JOIN sectors 
ON sea.sector = sectors.ID 

WHERE TITRES.affectation = 1701 -- Shares - REIT 
AND HISTOMVTS.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --excludes cancelled trades 
HAVING SUM(HISTOMVTS.quantite) !=0 --position exists currently 
GROUP BY  TITRES.REFERENCE,sectors.code;

EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);

END SHARES_REIT;


-- END SHARES_REIT -----------------------------------------------

------------------------------------------------------------------------------
-- Name: RULE_105_CHECK
------------------------------------------------------------------------------
-- Author: Gustavo Binnie	Date: 4th May 2015
-- ----------------------------------------------------------------
-- Date             JIRA
-- ----------------------------------------------------------------
-- 09 DEC 2015      PUSOPUP-226
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
------------------------------------------------------------------------------  
    PROCEDURE RULE_105_CHECK
  (
    TICKER        IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  ) AS
  BEGIN
  
      OPEN OUT_CURSOR FOR      
   SELECT 
  SEC.SICOVAM                         SICOVAM, 
  TRADES.REFCON                       TRADE_ID, 
  SEC.REFERENCE                       INSTRUMENT_REFERENCE, 
  AFFECTATION.LIBELLE                 ALLOTMENT, 
  FUND_BOOK_STRATEGY.Fund_NAME        FUND, 
  FUND_BOOK_STRATEGY.BOOK_NAME        STRATEGY,
  FUND_BOOK_STRATEGY.STRATEGY_ID      FOLIO_ID,
  PB.NAME                             DEPOSITARY,
  trader.name                         TRADER, 
  TRADES.QUANTITE                     QUANTITY, 
  TO_CHAR(TRUNC(TRADES.DATENEG),'YYYY-MM-DD')                      TRADE_DATE, 
  SEC.TYPE                            INST_TYPE, 
  SEC.TYPEPRO                         INST_TYPE_OPTION 
  FROM JOIN_POSITION_HISTOMVTS TRADES 
  INNER JOIN ( 
                            SELECT                             
                            REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 1, 2) AS Fund_NAME 
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, 'Â¬'), '[^Â¬]+', 3, 4) AS BOOK_NAME 
                          , FOLIO.ident AS STRATEGY_ID 
                          , level 
                  FROM FOLIO 
                  WHERE LEVEL >= 4 
                  START WITH FOLIO.ident IN (14414,90565)                
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
                ) FUND_BOOK_STRATEGY 
  ON FUND_BOOK_STRATEGY.STRATEGY_ID = TRADES.OPCVM 
  INNER JOIN TITRES SEC 
  ON TRADES.SICOVAM = SEC.SICOVAM
  INNER JOIN TIERS PB
  ON TRADES.DEPOSITAIRE = PB.IDENT 
  INNER JOIN BUSINESS_EVENTS BE 
  ON TRADES.TYPE = BE.ID 
  AND BE.COMPTA=1   
  LEFT JOIN AFFECTATION 
  ON AFFECTATION.IDENT = SEC.AFFECTATION 
  LEFT JOIN  riskusers trader 
  ON trader.ident = Trades.operateur   
  WHERE 
  TRADES.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
  AND TRADES.SICOVAM IN 
  (
  SELECT SEC.SICOVAM SICOVAM 
  FROM TITRES SEC
  LEFT JOIN   titres Underlying1 
  ON Underlying1.sicovam = case when Sec.type='A' then Sec.base1 when Sec.type='D' then Sec.codesj when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end  
  LEFT JOIN   titres Underlying2 
  ON Underlying2.sicovam = case when Underlying1.type in ('A','I') then 0 when Underlying1.type='D' then Underlying1.codesj when Underlying1.type='S' then decode(Underlying1.jambe1,1,Underlying1.j2refcon2,decode(Underlying1.j1refcon2,0,Underlying1.j2refcon2,Underlying1.j1refcon2)) else decode(Underlying1.code_emet,0,decode(Underlying1.codesj,0,Underlying1.codesj2,Underlying1.codesj),Underlying1.code_emet) end  
  and Underlying1.type <> 'H'
  WHERE (UPPER(SEC.REFERENCE) = UPPER(TICKER) OR UPPER(Underlying1.REFERENCE) = UPPER(TICKER) OR UPPER(Underlying2.REFERENCE) = UPPER(TICKER)) 
  );
  
  EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);
  
  END RULE_105_CHECK;
  
-- END RULE_105_CHECK -----------------------------------------------


------------------------------------------------------------------------------
-- Name: RULE_105_HOLIDAYS
------------------------------------------------------------------------------
-- Author: Gustavo Binnie	Date: 4th May 2015
------------------------------------------------------------------------------  
  PROCEDURE RULE_105_HOLIDAYS
  (
     TICKER        IN    VARCHAR2
		,PRICE_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
) AS

BEGIN
	OPEN OUT_CURSOR
	FOR

  SELECT FERIES.DATEFER HOLIDAY from titres 
	LEFT JOIN marche
		ON titres.marche = marche.mnemomarche
		AND titres.devisectt = marche.codedevise
	LEFT JOIN place
		ON marche.placedecotationv2 = place.code
  LEFT JOIN FERIES
  ON FERIES.CODEDEV = CASE WHEN place.code IS NULL THEN titres.devisectt ELSE place.CODE END
  WHERE upper(titres.reference) = upper(TICKER)
  AND FERIES.DATEFER <= PRICE_DATE
  AND FERIES.DATEFER+15 >= PRICE_DATE;
  
  EXCEPTION WHEN OTHERS THEN raise_application_error(- 20011, sqlerrm);  
  
  END RULE_105_HOLIDAYS;

       
END PCKG_BTG_EXCEL_REPORTS;