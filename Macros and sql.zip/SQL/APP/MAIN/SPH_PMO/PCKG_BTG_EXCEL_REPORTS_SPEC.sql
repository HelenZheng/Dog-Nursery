create or replace PACKAGE            "PCKG_BTG_EXCEL_REPORTS" 
AS

  TYPE T_CURSOR IS REF CURSOR;

  PROCEDURE COMPLIANCE_FAIRPRICE
  (
    IN_DATE_FROM  IN    DATE
  , IN_DATE_TO    IN    DATE
  , IN_REGION     IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  );




    PROCEDURE PRICE_REC
  (
    IN_DATE_REC  IN    DATE
  , IN_REGION     IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  );




  
PROCEDURE CURVE_PRICE_REC
	(
		p_CURSOR OUT T_CURSOR
	);
  
  PROCEDURE FX_REC
  (
    IN_DATE_FROM  IN    DATE
  , OUT_CURSOR    OUT   T_CURSOR
  );
  
   PROCEDURE COUPON_DIVIDEND_CHECK
  (
    IN_DATE_FROM  IN    DATE
   , IN_DATE_TO   IN    DATE
  , IN_REGION     IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  );
  
  	PROCEDURE EQUITY_INST_REC
	(
		p_CURSOR OUT T_CURSOR
	);
  
    PROCEDURE MBS_INST_REC
	(
		p_CURSOR OUT T_CURSOR
	);
  
------------------------------------------------------------------------------
-- Name: ITALIAN_WHT
------------------------------------------------------------------------------
-- Author: Matt Kelly		Date: 18th Dec 2013
------------------------------------------------------------------------------
  
    PROCEDURE ITALIAN_WHT
  (
		IN_FROM_DATE IN DATE
		,IN_TO_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
  );
  
-- END ITALIAN_WHT -----------------------------------------------------------

------------------------------------------------------------------------------
-- Name: SHARES_REIT
------------------------------------------------------------------------------
-- Author: Davi Xavier	Date: 25th Mar 2015
------------------------------------------------------------------------------
  
    PROCEDURE SHARES_REIT
  (
		IN_FROM_DATE IN DATE
		,IN_TO_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
  );
  
-- END SHARES_REIT -----------------------------------------------------------

------------------------------------------------------------------------------
-- Name: RULE_105_CHECK
------------------------------------------------------------------------------
-- Author: Gustavo Binnie	Date: 4th May 2015
------------------------------------------------------------------------------  
    PROCEDURE RULE_105_CHECK
  (
    TICKER        IN    VARCHAR2
  , OUT_CURSOR    OUT   T_CURSOR
  );
-- END RULE_105_CHECK ---------------------------------------------------------- 

------------------------------------------------------------------------------
-- Name: RULE_105_HOLIDAYS
------------------------------------------------------------------------------
-- Author: Gustavo Binnie	Date: 4th May 2015
------------------------------------------------------------------------------  
  PROCEDURE RULE_105_HOLIDAYS
  (
     TICKER        IN    VARCHAR2
		,PRICE_DATE IN DATE
		,OUT_CURSOR OUT T_CURSOR
) ;
-- END RULE_105_HOLIDAYS ----------------------------------------------------------
  
END PCKG_BTG_EXCEL_REPORTS;