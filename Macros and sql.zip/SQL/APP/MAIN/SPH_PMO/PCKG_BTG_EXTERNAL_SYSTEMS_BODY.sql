create or replace
PACKAGE BODY         "PCKG_BTG_EXTERNAL_SYSTEMS" AS
  
  PROCEDURE MISSING_CITI_ALLOC_FI
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
    
       OPEN p_CURSOR FOR
      
SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  1704 -- CITI Cash Transaction
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITI_ALLOC_FI;
  
  PROCEDURE MISSING_CITI_ALLOC_REPO
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
    
       OPEN p_CURSOR FOR
      
SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  1781 -- CITI REPO Transaction
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITI_ALLOC_REPO;
  
  
  PROCEDURE MISSING_CS_ALLOC_FI
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
     
      
      
       OPEN p_CURSOR FOR
      
SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  981 -- CS Fixed Income Transaction 
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CS_ALLOC_FI;
  
  PROCEDURE MISSING_CS_ALLOC_REPO
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
     
      
      
       OPEN p_CURSOR FOR
      
SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  1773	--CS REPO Transaction 
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CS_ALLOC_REPO;

  PROCEDURE MISSING_CITCO_TRADE_DUBLIN
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
       OPEN p_CURSOR FOR
          
SELECT          
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               Fund.libelle                                      TradeEntity
,               RISKUSERS.name                                    Operator      
,               Instrument.libelle                                Name
,               Instrument.reference                              Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts
    
FROM            HISTOMVTS                                         Trades 
      
INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            , level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (14414,61950)--Primary/Brazil Funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            )   Fund_BOOK_STRATEGY
ON              Fund_BOOK_STRATEGY.strategy_id                = Trades.opcvm

      
INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id                            = Trades.type
      
INNER JOIN      AMRECON_DEALS_FILTER
ON              AMRECON_DEALS_FILTER.businessevent            = Trades.type
      
INNER JOIN      AMRECON_EXTERNAL_SYSTEMS 
ON              AMRECON_EXTERNAL_SYSTEMS.deals_format_id      = AMRECON_DEALS_FILTER.id
AND             AMRECON_EXTERNAL_SYSTEMS.ID                   = 1481 -- Citco Trade Loader Dublin Funds 
      
INNER JOIN      AMRECON_EXTSYS_ACCOUNTS
ON              AMRECON_EXTSYS_ACCOUNTS.esid                  = AMRECON_EXTERNAL_SYSTEMS.id
AND             AMRECON_EXTSYS_ACCOUNTS.include               = 1
      
INNER JOIN      TITRES   Fund
ON              Fund.sicovam                                  = AMRECON_EXTSYS_ACCOUNTS.fund
AND             Fund.code_emet                                = Trades.entite
      
INNER JOIN      TITRES Instrument
ON              Instrument.sicovam                            = Trades.sicovam 
      
INNER JOIN      AFFECTATION Allotment
ON              Allotment.ident                               = Instrument.affectation
      
LEFT JOIN       TIERS PrimeBroker     
ON              PrimeBroker.ident                             = Trades.depositaire
      
LEFT JOIN       RISKUSERS
ON              RISKUSERS.ident                               = Trades.operateur
             
WHERE           Trades.backoffice                            IN (12,16,244)   -- checked mo 
AND             Trades.dateneg                               >=  sysdate-5
AND             instrument.affectation                       NOT IN (select allotment 
                                                                     from amrecon_extsys_accounts  
                                                                     where include=0 
                                                                     and pb=-1 
                                                                     and esid=amrecon_external_systems.id
                                                                     )
AND             Trades.depositaire                           NOT IN (select PB 
                                                                     from amrecon_extsys_accounts  
                                                                     where include=0 
                                                                     and Fund=-1 
                                                                     and allotment=-1 
                                                                     and esid=amrecon_external_systems.id
                                                                     )
AND             NOT EXISTS                                          (select 1 
                                                                     from amrecon_vacations 
                                                                     where refcon = Trades.refcon 
                                                                     and esid=amrecon_external_systems.id
                                                                     )     
       
ORDER BY        Instrument.libelle; 
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITCO_TRADE_DUBLIN;

--21 JUN-2018    Jeff Yu     Modified (PMGMCITCO-120)
  
  PROCEDURE MISSING_CITCO_FX_DUBLIN
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
       OPEN p_CURSOR FOR
      
SELECT          
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               Fund_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               Fund.libelle                                      TradeEntity
,               RISKUSERS.name                                    Operator      
,               Instrument.libelle                                Name
,               Instrument.reference                              Ticker
,               Allotment.libelle                                 Allotment
,               Fund_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               Fund_BOOK_STRATEGY.strategy_name                  Strategy
,               trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts
    
FROM            histomvts Trades 
      
INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            , level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (14414,61950)--Primary/Brazil Funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            )   Fund_BOOK_STRATEGY
ON              Fund_BOOK_STRATEGY.STRATEGY_ID                = Trades.opcvm
     
INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id                            = Trades.type
      
INNER JOIN      AMRECON_DEALS_FILTER
ON              AMRECON_DEALS_FILTER.businessevent            = Trades.type
      
INNER JOIN      AMRECON_EXTERNAL_SYSTEMS 
ON              AMRECON_EXTERNAL_SYSTEMS.deals_format_id      = AMRECON_DEALS_FILTER.id
AND             AMRECON_EXTERNAL_SYSTEMS.id                   in  (4534,4535) -- Citco FX New Dublin and Cork Funds 
      
INNER JOIN      AMRECON_EXTSYS_ACCOUNTS Includefilter
ON              Includefilter.esid                            = AMRECON_EXTERNAL_SYSTEMS.id
AND             Includefilter.include                         = 1

INNER JOIN      TITRES   Fund
ON              Fund.sicovam                                  = Includefilter.fund
AND             Fund.code_emet                                = Trades.entite
    
INNER JOIN      TITRES Instrument
ON              Instrument.sicovam                            = Trades.sicovam 
AND             F_INSTRALLOTMENT(Instrument.sicovam)          = Includefilter.allotment
      
INNER JOIN      AFFECTATION Allotment
ON              Allotment.IDENT                               = F_INSTRALLOTMENT(Instrument.sicovam)
      
LEFT JOIN       TIERS PrimeBroker     
ON              PrimeBroker.IDENT                             = Trades.depositaire
      
LEFT JOIN       RISKUSERS
ON              RISKUSERS.ident                               = Trades.operateur
             
WHERE           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo 
AND             Trades.dateneg                                >=  sysdate-5
AND             F_INSTRALLOTMENT(Instrument.sicovam)          NOT IN (select allotment
                                                                      from amrecon_extsys_accounts  
                                                                      where include=0 
                                                                      and pb=-1 
                                                                      and esid=amrecon_external_systems.id
                                                                      )
AND             Trades.depositaire                            NOT IN (select PB 
                                                                      from amrecon_extsys_accounts  
                                                                      where include=0 
                                                                      and Fund=-1 
                                                                      and allotment=-1 
                                                                      and esid=amrecon_external_systems.id
                                                                      )
AND             NOT EXISTS                                           (select 1 
                                                                      from amrecon_vacations 
                                                                      where refcon = Trades.refcon 
                                                                      and esid=amrecon_external_systems.id)      
ORDER BY        Instrument.libelle; 
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITCO_FX_DUBLIN;
  
  PROCEDURE MISSING_CITCO_REPO_DUBLIN
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
       OPEN p_CURSOR FOR
      
SELECT          
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               Fund_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               Fund.libelle                                      TradeEntity
,               RISKUSERS.name                                    Operator      
,               Instrument.libelle                                Name
,               Instrument.reference                              Ticker
,               Allotment.libelle                                 Allotment
,               Fund_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               Fund_BOOK_STRATEGY.strategy_name                  Strategy
,               trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts
    
FROM            HISTOMVTS                                         Trades 
      
INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            , level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (14414,61950)--Primary/Brazil Funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            )   Fund_BOOK_STRATEGY
ON              Fund_BOOK_STRATEGY.strategy_id                = Trades.opcvm
     
INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id                            = Trades.type
      
INNER JOIN      AMRECON_DEALS_FILTER
ON              AMRECON_DEALS_FILTER.businessevent            = Trades.type
      
INNER JOIN      AMRECON_EXTERNAL_SYSTEMS 
ON              AMRECON_EXTERNAL_SYSTEMS.deals_format_id      = AMRECON_DEALS_FILTER.id
AND             AMRECON_EXTERNAL_SYSTEMS.ID                   = 1483 -- Citco REPO Loader Dublin Funds 
      
INNER JOIN      AMRECON_EXTSYS_ACCOUNTS Includefilter
ON              Includefilter.esid                            = AMRECON_EXTERNAL_SYSTEMS.id
AND             Includefilter.include                         = 1

INNER JOIN      TITRES   Fund
ON              Fund.sicovam                                  = Includefilter.fund
AND             Fund.code_emet                                = Trades.entite
    
INNER JOIN      TITRES Instrument
ON              Instrument.sicovam                            = Trades.sicovam 
AND             F_INSTRALLOTMENT(Instrument.sicovam)          = Includefilter.allotment
      
INNER JOIN      AFFECTATION Allotment
ON              Allotment.ident                               = Instrument.affectation
      
LEFT JOIN       TIERS PrimeBroker     
ON              PrimeBroker.ident                             = Trades.depositaire
      
LEFT JOIN       RISKUSERS
ON              RISKUSERS.ident                               = Trades.operateur
             
WHERE           Trades.BACKOFFICE                             IN (12, 16,244)   -- checked mo 
AND             Trades.dateneg                                >=  sysdate-5
AND             Instrument.affectation                        NOT IN (select allotment 
                                                                      from amrecon_extsys_accounts  
                                                                      where include=0 
                                                                      and pb=-1 
                                                                      and esid=amrecon_external_systems.id
                                                                      )
AND             Trades.depositaire                            NOT IN (select PB 
                                                                      from amrecon_extsys_accounts  
                                                                      where include=0 
                                                                      and Fund=-1 
                                                                      and allotment=-1 
                                                                      and esid=amrecon_external_systems.id
                                                                      )
AND             NOT EXISTS                                           (select 1 
                                                                      from amrecon_vacations 
                                                                      where refcon = Trades.refcon 
                                                                      and esid=amrecon_external_systems.id
                                                                      )     
ORDER BY        Instrument.libelle; 
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITCO_REPO_DUBLIN;
  
  PROCEDURE MISSING_CITCO_TRADE_CORK
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
       OPEN p_CURSOR FOR
      
SELECT          

                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               Fund_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               Fund.libelle                                      TradeEntity
,               RISKUSERS.name                                    Operator      
,               Instrument.libelle                                Name
,               Instrument.reference                              Ticker
,               Allotment.libelle                                 Allotment
,               Fund_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               Fund_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts
    
FROM            HISTOMVTS                                         Trades 
      
INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            , level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (14414,61950)--Primary/Brazil Funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            )   Fund_BOOK_STRATEGY
ON              Fund_BOOK_STRATEGY.strategy_id                = Trades.opcvm

      
INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id                            = Trades.type
      
INNER JOIN      AMRECON_DEALS_FILTER
ON              AMRECON_DEALS_FILTER.businessevent            = Trades.type
      
INNER JOIN      AMRECON_EXTERNAL_SYSTEMS 
ON              AMRECON_EXTERNAL_SYSTEMS.deals_format_id      = AMRECON_DEALS_FILTER.id
AND             AMRECON_EXTERNAL_SYSTEMS.id                   = 1484 -- Citco Trade Loader Cork Funds 
      
INNER JOIN      AMRECON_EXTSYS_ACCOUNTS
ON              AMRECON_EXTSYS_ACCOUNTS.esid                  = AMRECON_EXTERNAL_SYSTEMS.id
AND             AMRECON_EXTSYS_ACCOUNTS.include               = 1
      
INNER JOIN      TITRES   Fund
ON              Fund.sicovam                                  = AMRECON_EXTSYS_ACCOUNTS.Fund
AND             Fund.code_emet                                = Trades.entite
      
INNER JOIN      TITRES Instrument
ON              Instrument.sicovam                            = Trades.sicovam 
      
INNER JOIN      AFFECTATION Allotment
ON              Allotment.ident                               = Instrument.affectation
      
LEFT JOIN       TIERS PrimeBroker     
ON              PrimeBroker.ident                             = Trades.depositaire
      
LEFT JOIN       RISKUSERS
ON              RISKUSERS.ident                               = Trades.operateur
             
WHERE           Trades.backoffice                            IN (12, 16,244)   -- checked mo 
AND             Trades.dateneg                               >=  sysdate-5
AND             Instrument.affectation                       NOT IN (select allotment 
                                                                     from amrecon_extsys_accounts  
                                                                     where include=0 
                                                                     and pb=-1 
                                                                     and esid=amrecon_external_systems.id
                                                                     )
AND             Trades.depositaire                           NOT IN (select pb 
                                                                     from amrecon_extsys_accounts  
                                                                     where include=0 
                                                                     and Fund=-1 
                                                                     and allotment=-1 
                                                                     and esid=amrecon_external_systems.id
                                                                     )
AND             NOT EXISTS                                          (select 1 
                                                                     from amrecon_vacations 
                                                                     where refcon = Trades.refcon 
                                                                     and   esid=amrecon_external_systems.id
                                                                     )     
ORDER BY        Instrument.libelle; 
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_CITCO_TRADE_CORK;
 
  PROCEDURE TRADES_IN_ERROR
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
      
  
SELECT  
                      AMRECON_VACATIONS.refcon                                  TradeID
,                     DECODE(AMRECON_VACATIONS.generation_type,
                            1,'New',
                            2,'Amend',
                            3,'Cancel',
                            'Unknow')                                           TransactionTypeInFile
,                     amrecon_vacations.insertion_date D$InsertionDate
,                     AMRECON_EXTERNAL_SYSTEMS.id                               FileTypeID
,                     AMRECON_EXTERNAL_SYSTEMS.name                             FileType
,                     histomvts.dateneg                                         d$TradeDate
,                     histomvts.dateval                                         d$ValueDate
,                     TIERS.name                                                TradeEntityFund
,                     Fund_BOOK_STRATEGY.Fund_NAME                              FolioFund



FROM                  AMRECON_VACATIONS

INNER JOIN            AMRECON_EXTERNAL_SYSTEMS
ON                    AMRECON_EXTERNAL_SYSTEMS.id = AMRECON_VACATIONS.esid

LEFT JOIN             HISTOMVTS
ON                    HISTOMVTS.refcon            = AMRECON_VACATIONS.refcon

LEFT JOIN             TITRES
ON                    TITRES.sicovam              = HISTOMVTS.sicovam

LEFT JOIN             TIERS
ON                    TIERS.ident                 = HISTOMVTS.entite

LEFT JOIN             ( 
                       SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                       , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                       , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                       , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                       , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                       , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                       , FOLIO.ident AS STRATEGY_ID
                       , FOLIO.name AS STRATEGY_NAME
                       , level
                       FROM FOLIO
                       WHERE LEVEL >= 4
                       START WITH FOLIO.ident IN (14414,61950,14405,90565)--Primary/Brazil/Secondary Funds
                       CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      ) Fund_BOOK_STRATEGY
ON                    Fund_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.opcvm

WHERE                   AMRECON_VACATIONS.sent                                  = 4
AND                     UPPER(AMRECON_EXTERNAL_SYSTEMS.name)                    NOT LIKE '%TEST%'

ORDER BY                AMRECON_VACATIONS.refcon
;

      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END TRADES_IN_ERROR; 
  
  PROCEDURE DUB_DEPO_IN_CORK_FILE_SUFFIX
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
 
SELECT 
                                     ThirdParty.ident                           DepositaryID
,                                    ThirdParty.name                            Depositary
,                                    AMRECON_EXTERNAL_SYSTEMS.name              ExternalSystem

FROM                                 TIERS ThirdParty

INNER JOIN                           TIERS Depo
ON                                   Depo.ident                               = ThirdParty.mgr

INNER JOIN                           AMRECON_FORMAT_AEXEO_FILTER
ON                                   AMRECON_FORMAT_AEXEO_FILTER.primebroker  = ThirdParty.ident

INNER JOIN                           AMRECON_EXTERNAL_SYSTEMS
ON                                   AMRECON_EXTERNAL_SYSTEMS.deals_format_id = AMRECON_FORMAT_AEXEO_FILTER.id

WHERE                                ESTDEPOSITAIRE(ThirdParty.options) = 1 
AND                                  Depo.ident                               IN (10010626,10007442,10006862,10006703,10007102,10010269,10010571,10010388,10025790)--- Dublin Depositaries
AND                                  AMRECON_EXTERNAL_SYSTEMS.id              = 1484 -- Citco Trade Loader Cork Funds
;
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END DUB_DEPO_IN_CORK_FILE_SUFFIX; 
  
  PROCEDURE CORK_DEPO_IN_DUB_FILE_SUFFIX
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR


SELECT 
                                     ThirdParty.ident                           DepositaryID
,                                    ThirdParty.name                            Depositary
,                                    AMRECON_EXTERNAL_SYSTEMS.name              ExternalSystem

FROM                                 TIERS ThirdParty

INNER JOIN                           TIERS Depo
ON                                   Depo.ident                               = ThirdParty.mgr

INNER JOIN                           AMRECON_FORMAT_AEXEO_FILTER
ON                                   AMRECON_FORMAT_AEXEO_FILTER.primebroker  = ThirdParty.ident

INNER JOIN                           AMRECON_EXTERNAL_SYSTEMS
ON                                   AMRECON_EXTERNAL_SYSTEMS.deals_format_id = AMRECON_FORMAT_AEXEO_FILTER.id

WHERE                                ESTDEPOSITAIRE(ThirdParty.options) = 1
AND                                  Depo.ident                               IN (10010062,10009483)--- CORK Depositaries
AND                                  UPPER(AMRECON_EXTERNAL_SYSTEMS.name)     like '%DUBLIN%'-- Citco Dublin Funds
;
      
      EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END CORK_DEPO_IN_DUB_FILE_SUFFIX; 
  
  PROCEDURE DUPE_AEXEO_SUFFIX
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
SELECT 
                          TIERS.name                                            Depositary
,                         AMRECON_FORMAT_AEXEO_FILTER.primebroker               DepositaryID
,                         affectation.libelle                                   Allotment
,                         AMRECON_FORMAT_AEXEO_FILTER.suffix                    Suffix
,                         AMRECON_EXTERNAL_SYSTEMS.name                         ExternalSystem
,                         AMRECON_EXTERNAL_SYSTEMS.comments                     ExternalSystemComments

FROM                      AMRECON_FORMAT_AEXEO_FILTER 

INNER JOIN                (select count(1),
                           amrecon_format_aexeo_filter.allotment,
                           amrecon_format_aexeo_filter.primebroker
                           from amrecon_format_aexeo_filter 
                           where primebroker !=-1 
                           group by amrecon_format_aexeo_filter.allotment,
                                    amrecon_format_aexeo_filter.primebroker,
                                    amrecon_format_aexeo_filter.id
                           having count(1)>1
                           )DATASET
ON                          AMRECON_FORMAT_AEXEO_FILTER.allotment             = DATASET.allotment 
AND                         AMRECON_FORMAT_AEXEO_FILTER.primebroker           = DATASET.primebroker

LEFT JOIN                   AMRECON_EXTERNAL_SYSTEMS 
ON                          AMRECON_EXTERNAL_SYSTEMS.deals_format_id          = AMRECON_FORMAT_AEXEO_FILTER.id

LEFT JOIN                   TIERS
ON                          TIERS.ident                                       = DATASET.primebroker

LEFT JOIN                   AFFECTATION 
ON                          AFFECTATION.ident                                 = AMRECON_FORMAT_AEXEO_FILTER.allotment

ORDER BY                    AMRECON_FORMAT_AEXEO_FILTER.primebroker,
                            AMRECON_FORMAT_AEXEO_FILTER.allotment
;
      
  EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END DUPE_AEXEO_SUFFIX; 
  
  
  PROCEDURE CANCELLED_MISSING_CANCELLATION
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
      
SELECT   
       Fileinterface.name                                                       External_System
      ,Fileinterface.id                                                         External_System_ID
      ,Trades.REFCON                                                            Trade_ID
      ,Trades.dateneg                                                           Trade_Date
      ,Fund.name                                                                Fund
      ,Counterparty.name                                                        Counterparty
      ,Allotment.LIBELLE                                                        Allotment
      ,Instrument.libelle                                                       Instrument_Name
      ,Instrument.reference                                                     Instrument_Reference
      ,trader.name                                                              Trader_Name
      ,users.name                                                               User_Name

FROM            audit_mvt                                                       Trades 
      
INNER JOIN       ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                  , FOLIO.ident AS STRATEGY_ID
                  , FOLIO.name AS STRATEGY_NAME
                  , level
                  FROM FOLIO
                  WHERE LEVEL >= 4
                  START WITH FOLIO.ident IN (14414,14405,90565)   --Primary and Secondary Funds
                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                 )                                                              Fund_BOOK_STRATEGY
ON Fund_BOOK_STRATEGY.STRATEGY_ID =Trades.OPCVM
    
INNER JOIN      TITRES                                                          Instrument
ON              Instrument.sicovam = Trades.sicovam 
      
LEFT JOIN       TIERS                                                           Counterparty
ON              Counterparty.ident = Trades.contrepartie 

LEFT JOIN       TIERS                                                           Fund
ON              Fund.ident = Trades.entite 

LEFT JOIN       AFFECTATION                                                     Allotment
ON              Allotment.IDENT = Instrument.affectation
      
INNER JOIN      amrecon_vacations
ON              amrecon_vacations.refcon = Trades.refcon
      
INNER JOIN      AMRECON_EXTERNAL_SYSTEMS                                        Fileinterface
ON              Fileinterface.ID = amrecon_vacations.esid
AND             upper(Fileinterface.Name) not like '%TEST%'
AND             esid not in (1261,261,1486) -- excluding the files that do not send cancellation
AND             Fileinterface.export_deals=1
    
LEFT JOIN       RISKUSERS                                                       Trader
ON              trader.ident=Trades.operateur
      
LEFT JOIN       RISKUSERS                                                       Users
ON              users.ident=Trades.userid

WHERE           Trades.state = 3
AND             trunc(Trades.DATEMODIF) = trunc(sysdate-1)
AND             amrecon_vacations.generation_type=1 
AND             amrecon_vacations.sent=1
AND             NOT EXISTS (select 1 from amrecon_vacations inner_amrecon_vacations 
                            where inner_amrecon_vacations.refcon = Trades.refcon 
                            and inner_amrecon_vacations.generation_type=3 
                            and inner_amrecon_vacations.esid = amrecon_vacations.esid
                            )
;
      
  EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END CANCELLED_MISSING_CANCELLATION; 
  
---Modified by Jeff Yu on Sep 29th, 2017--
---Add new fund GDO in scope; PMGMPMO-234-----
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
  PROCEDURE MISSING_STAARS
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
SELECT
      Trades.refcon                                       Trade_Id,
      Trades.sicovam                                      Sicovam,
      trunc(Trades.DATENEG)                               d$TradeDate,
      trunc(Trades.DATEVAL)                               d$ValueDate,
      Instrument.libelle                                  Instrument_Name,
      Fund_BOOK_STRATEGY.top_Fund_name                    Fund,
      Instrument.reference                                Instrument_Reference,
      RISKUSERS.name                                      Trader,
      Counterparty.name                                   Counterparty,
      affectation.libelle                                 Allotment,
      BUSINESS_EVENTS.name                                Business_Event
      
FROM            histomvts Trades 

INNER JOIN ( 
            SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
            , FOLIO.ident AS STRATEGY_ID
            , FOLIO.name AS STRATEGY_NAME
            , level
            FROM FOLIO
            WHERE LEVEL >= 4
            START WITH FOLIO.ident IN (14405,14414,90565)--Primary/secondary Funds/UCITS
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
            )   Fund_BOOK_STRATEGY
ON              Fund_BOOK_STRATEGY.STRATEGY_ID =  Trades.OPCVM
AND             Fund_BOOK_STRATEGY.Fund_ID     in (12506,12642,62880,12505,132408,130434,68998) --inc. ARF/ARF2/RATES/GEMM/GDO/GMF


INNER JOIN      BUSINESS_EVENTS
ON              BUSINESS_EVENTS.id = Trades.type

INNER JOIN      TITRES Instrument
ON              Instrument.sicovam = Trades.sicovam 

LEFT JOIN       affectation
ON              affectation.ident=instrument.affectation

LEFT JOIN       RISKUSERS
ON              RISKUSERS.ident = trades.operateur

LEFT JOIN       TIERS Counterparty
ON              Counterparty.ident = trades.contrepartie

LEFT JOIN       TIERS Broker
ON              Broker.ident = trades.courtier

WHERE   Trades.backoffice not in (192,11,13,17,26,27,220,248,252)
AND     trades.dateneg >= sysdate-10
AND     not exists (select 1  from       amrecon_vacations

                              inner join AMRECON_EXTERNAL_SYSTEMS 
                              on         AMRECON_EXTERNAL_SYSTEMS.id=amrecon_vacations.esid
    
                              where      AMRECON_EXTERNAL_SYSTEMS.name like '%Staars%' 
                              and        AMRECON_EXTERNAL_SYSTEMS.id !=1261-- exclude staars security file
                              and        amrecon_vacations.refcon=trades.refcon
                    )
;
      
  EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_STAARS; 
  
  PROCEDURE MISSING_UBS_ALLOC_BOND
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  961 -- UBS PB Bond Standalone Transaction 
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      
  EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_UBS_ALLOC_BOND; 
  
  PROCEDURE MISSING_UBS_ALLOC_CFD
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR

SELECT 
                AMRECON_EXTERNAL_SYSTEMS.name                     External_System
,               Trades.refcon                                     TradeID
,               FUND_BOOK_STRATEGY.fund_name                      PortfolioFundName
,               FullFilter.Entity_ID                              TradeEntity
,               RISKUSERS.name                                    Operator      
,               FullFilter.INST_NAME                              Name
,               FullFilter.INST_REF                               Ticker
,               Allotment.libelle                                 Allotment
,               FUND_BOOK_STRATEGY.book_name                      TOPLEVELStrategy
,               FUND_BOOK_STRATEGY.strategy_name                  Strategy
,               Trunc(Trades.dateneg)                             TradeDate  
,               Trades.quantite                                   Quantity
,               Trades.cours                                      Price
,               PrimeBroker.name                                  PrimeBroker
,               BUSINESS_EVENTS.name                              BusinesEvent
,               ISPBDEFINED(Trades.depositaire, Trades.opcvm)     NoOfPrimeBrokerAccounts

FROM                 HISTOMVTS                                    Trades

INNER JOIN           ( 
                      SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_Fund_ID
                      , CONNECT_BY_ROOT(FOLIO.name) AS TOP_Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS Fund_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                      , FOLIO.ident AS STRATEGY_ID
                      , FOLIO.name AS STRATEGY_NAME
                      , level
                      FROM FOLIO
                      WHERE LEVEL >= 4
                      START WITH FOLIO.ident IN (14414,90565)--Primary Funds
                      CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
                      )     Fund_BOOK_STRATEGY
ON                          Fund_BOOK_STRATEGY.strategy_id                    = Trades.opcvm 

INNER JOIN            (  
                       SELECT                TITRES.sicovam                     AS SICOVAM
                        ,                    TITRES.libelle                     AS INST_NAME
                        ,                    TITRES.reference                   AS INST_REF
                        ,                    devise_to_str(TITRES.devisectt)    AS CCY
                        ,                    Fund.code_emet                     AS Entity_ID  
                        ,                    AMRECON_EXTSYS_ACCOUNTS.pb         AS DEPOSITARY
                        ,                    AMRECON_EXTSYS_ACCOUNTS.ccy        AS CCY_ODE
                        ,                    AMRECON_EXTSYS_ACCOUNTS.allotment  AS ALLOTMENT
                        ,                    AMRECON_EXTSYS_ACCOUNTS.esid       AS ESID  
                        
                        FROM                 TITRES
                        
                        INNER JOIN           AMRECON_EXTSYS_ACCOUNTS
                        ON                   (TITRES.devisectt                = AMRECON_EXTSYS_ACCOUNTS.ccy
                                              OR    0                         = AMRECON_EXTSYS_ACCOUNTS.ccy)
                        AND                  (TITRES.affectation              = AMRECON_EXTSYS_ACCOUNTS.allotment
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.allotment)
                        
                        INNER JOIN           TITRES                             Fund
                        ON                   (Fund.sicovam                    = AMRECON_EXTSYS_ACCOUNTS.fund
                                              OR    -1                        = AMRECON_EXTSYS_ACCOUNTS.fund)
                        
                        WHERE                AMRECON_EXTSYS_ACCOUNTS.include  = 1
                       )   FullFilter
                       
                       ON  FullFilter.Entity_ID                               = Trades.entite
                       AND FullFilter.sicovam                                 = Trades.sicovam
                       AND FullFilter.DEPOSITARY                              = Trades.depositaire
                       
INNER JOIN                 BUSINESS_EVENTS
ON                         BUSINESS_EVENTS.id                                 = Trades.type

INNER JOIN                 AMRECON_EXTERNAL_SYSTEMS 
ON                         AMRECON_EXTERNAL_SYSTEMS.id                        = FullFilter.esid


INNER JOIN                 TITRES Instrument
ON                         Instrument.sicovam                                 = FullFilter.sicovam 
      
INNER JOIN                 AFFECTATION Allotment
ON                         Allotment.ident                                    = FullFilter.ALLOTMENT
      
INNER JOIN                 TIERS PrimeBroker     
ON                         PrimeBroker.ident                                  = Trades.depositaire

INNER JOIN                 AMRECON_DEALS_FILTER
ON                         AMRECON_DEALS_FILTER.id                            = AMRECON_EXTERNAL_SYSTEMS.deals_format_id
AND                        AMRECON_DEALS_FILTER.businessevent                 = Trades.type

LEFT JOIN                  RISKUSERS
ON                         RISKUSERS.ident                                    = Trades.operateur
                        
WHERE                      Trades.backoffice                                  IN (12,16,244)   -- checked mo 
AND                        Trades.dateneg                                     >= sysdate-5
AND                        AMRECON_EXTERNAL_SYSTEMS.ID                        =  1506 -- UBS PB CFD Standalone Transaction
AND                        NOT EXISTS                                            (select 1 
                                                                                  from amrecon_vacations 
                                                                                  where refcon = Trades.refcon 
                                                                                  and esid=amrecon_external_systems.id
                                                                                  )   
;
      
  EXCEPTION
 
  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END MISSING_UBS_ALLOC_CFD; 
  
  ------Modified by Jeff Yu on Sep 29th, 2017-----
  ------Add new fund GDO; PMGMPMO-234-------------
  PROCEDURE MISSING_STRAT_AEXEO_CODE
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
SELECT * /*This report checks the strategies have an Aexeo code for the Sophis built files*/
FROM (
	(
		SELECT folio.NAME TopLevelStrategy
			,folio.ident StrategyID
			,funds.NAME FundName
			,(
				SELECT NAME
				FROM amrecon_external_systems
				WHERE id = 1481
				) AS "Not mapped in External System"
		FROM folio
		INNER JOIN folio strategies ON strategies.ident = folio.mgr
		INNER JOIN folio funds ON funds.ident = strategies.mgr
		LEFT JOIN (
			SELECT amrecon_format_bob_stratfilter.folio
				,amrecon_format_bob_stratfilter.strategy code
				,amrecon_external_systems.id esid
				,amrecon_external_systems.NAME ESName
			FROM amrecon_format_bob_stratfilter
			INNER JOIN amrecon_external_systems ON amrecon_external_systems.deals_format_id = - (amrecon_format_bob_stratfilter.id)
			WHERE amrecon_external_systems.id = 1481
			) citco_strat_mapping ON citco_strat_mapping.folio = folio.ident
		WHERE strategies.NAME = 'Strategies'
			AND funds.ident IN (
				67092
				,12505
				,12506
				,12642
				,28964
				,62880
				,63809
				,132408
				) --ARF,ARF2,GEMM,Focus,Global,DMF,GDO
			AND citco_strat_mapping.code IS NULL
		) --Citco Dublin FA ALL Trade
	
	UNION
	
	(
		SELECT folio.NAME TopLevelStrategy
			,folio.ident StrategyID
			,funds.NAME FundName
			,(
				SELECT NAME
				FROM amrecon_external_systems
				WHERE id = 1482
				) AS "Not mapped in External System"
		FROM folio
		INNER JOIN folio strategies ON strategies.ident = folio.mgr
		INNER JOIN folio funds ON funds.ident = strategies.mgr
		LEFT JOIN (
			SELECT amrecon_format_bob_stratfilter.folio
				,amrecon_format_bob_stratfilter.strategy code
				,amrecon_external_systems.id esid
				,amrecon_external_systems.NAME ESName
			FROM amrecon_format_bob_stratfilter
			INNER JOIN amrecon_external_systems ON amrecon_external_systems.deals_format_id = - (amrecon_format_bob_stratfilter.id)
			WHERE amrecon_external_systems.id = 1482
			) citco_strat_mapping ON citco_strat_mapping.folio = folio.ident
		WHERE strategies.NAME = 'Strategies'
			AND funds.ident IN (
				67092
				,12505
				,12506
				,12642
				,28964
				,62880
				,63809
				,132408
				) --ARF,ARF2,GEMM,Focus,Global,DMF,GDO
			AND citco_strat_mapping.code IS NULL
		) --Citco Dublin FA FX Trade
	
	UNION
	
	(
		SELECT folio.NAME TopLevelStrategy
			,folio.ident StrategyID
			,funds.NAME FundName
			,(
				SELECT NAME
				FROM amrecon_external_systems
				WHERE id = 1483
				) AS "Not mapped in External System"
		FROM folio
		INNER JOIN folio strategies ON strategies.ident = folio.mgr
		INNER JOIN folio funds ON funds.ident = strategies.mgr
		LEFT JOIN (
			SELECT amrecon_format_bob_stratfilter.folio
				,amrecon_format_bob_stratfilter.strategy code
				,amrecon_external_systems.id esid
				,amrecon_external_systems.NAME ESName
			FROM amrecon_format_bob_stratfilter
			INNER JOIN amrecon_external_systems ON amrecon_external_systems.deals_format_id = - (amrecon_format_bob_stratfilter.id)
			WHERE amrecon_external_systems.id = 1483
			) citco_strat_mapping ON citco_strat_mapping.folio = folio.ident
		WHERE strategies.NAME = 'Strategies'
			AND funds.ident IN (
				67092
				,12505
				,12506
				,12642
				,28964
				,62880
				,63809
				) --ARF,ARF2,GEMM,Focus,Global,DMF
			AND citco_strat_mapping.code IS NULL
		) --Citco Dublin FA REPO Trade
	
	UNION
	
	(
		SELECT folio.NAME TopLevelStrategy
			,folio.ident StrategyID
			,funds.NAME FundName
			,(
				SELECT NAME
				FROM amrecon_external_systems
				WHERE id = 1484
				) AS "Not mapped in External System"
		FROM folio
		INNER JOIN folio strategies ON strategies.ident = folio.mgr
		INNER JOIN folio funds ON funds.ident = strategies.mgr
		LEFT JOIN (
			SELECT amrecon_format_bob_stratfilter.folio
				,amrecon_format_bob_stratfilter.strategy code
				,amrecon_external_systems.id esid
				,amrecon_external_systems.NAME ESName
			FROM amrecon_format_bob_stratfilter
			INNER JOIN amrecon_external_systems ON amrecon_external_systems.deals_format_id = - (amrecon_format_bob_stratfilter.id)
			WHERE amrecon_external_systems.id = 1484
			) citco_strat_mapping ON citco_strat_mapping.folio = folio.ident
		WHERE strategies.NAME = 'Strategies'
			AND funds.ident IN (
				58901
				,61951
				) -- GEO,Absoluto,Equity Fund
			AND citco_strat_mapping.code IS NULL
		) --Citco Cork FA ALL Trade
	) ALLCITCOFILES
WHERE ALLCITCOFILES.TopLevelStrategy != 'X-Closed Strats';
    
  END MISSING_STRAT_AEXEO_CODE; 
  
  ------Modified by Jeff Yu on Sep 29th, 2017-----------
  -------Add new fund GDO; PMGMPMO-234-------
  PROCEDURE MISSING_STRAT_AEXEO_CODE_MAP
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
 SELECT /*This checks the new Citco files created by BTG*/
            FOLIO.NAME TopLevelStrategy
          , FOLIO.ident StrategyID
          , funds.NAME FundName
      FROM FOLIO
      INNER JOIN FOLIO STRATEGIES 
      ON STRATEGIES.ident = FOLIO.mgr --get the parent of each folio
      AND STRATEGIES.name = 'Strategies' --parent must be called Strategies
      INNER JOIN FOLIO FUNDS
      ON FUNDS.ident = STRATEGIES.mgr --get the parent of each Strategies folio
      AND FUNDS.ident IN (12505,12506,12642,28964,62880,63809,67092,58901,61951,132408) --The funds checked are ARF,ARF2,GEMM,Focus,Global,DMF,GEO,Absoluto,Brazil Equity Fund,GDO
      LEFT JOIN BTG_MAPPING_CODE  --all the strategy to Aexeo mappings are held in this table
      ON BTG_MAPPING_CODE.input_code = FOLIO.ident
      AND BTG_MAPPING_CODE.type_id = 26
      AND BTG_MAPPING_CODE.source_id = 2
      WHERE BTG_MAPPING_CODE.output_code IS NULL
      AND FOLIO.NAME != 'X-Closed Strats' --Old strategies are put here and no longer need to be checked
      ;
    
  END MISSING_STRAT_AEXEO_CODE_MAP; 



  -------APPSUPP-4277-------

  PROCEDURE TRADES_DELETED
  (
    p_CURSOR OUT T_CURSOR
  ) AS
  BEGIN
      
      OPEN p_CURSOR FOR
      
  
select AE.name,AV.INSERTION_DATE,AV.refcon from AMRECON_VACATIONS  AV, AMRECON_EXTERNAL_SYSTEMS AE
where AV.REFCON NOT IN (select refcon from HISTOMVTS)
AND AV.SENT=0
AND AV.GENERATION_TYPE=3
AND AV.ESID IN (select ID from AMRECON_EXTERNAL_SYSTEMS where name  NOT LIKE '%TEST%')
AND AV.ESID = AE.ID
order by AE.name,AV.INSERTION_DATE desc;

      EXCEPTION

  WHEN OTHERS THEN
      raise_application_error(-20011, sqlerrm); 
    
  END TRADES_DELETED;

  
END PCKG_BTG_EXTERNAL_SYSTEMS;