create or replace
PACKAGE BODY            "PCKG_BTG_PMO_REPORTS_COMP" 
AS
  
-- *****************************************************************
-- Description: PROCEDURE REGION_MARKET_ABUSE 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 22 JUN 2016      COM-277
-- 09 AUG 2016      COM-285
-- 05 OCT 2017     COM-301 (modified by Jeff Yu remove filter "only check GEMM"
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE REGION_MARKET_ABUSE
	(
		REGION	IN	VARCHAR2
	 , p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: REGION_MARKET_ABUSE
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
SELECT  DISTINCT
        FUND_BOOK_STRATEGY.Fund_NAME 					"FundName" 
      , btg_get_instrument_type(histomvts.sicovam) "Instrument Type"
      , CASE WHEN uf.Model='Ric' THEN RIC.SERVISEN when sec.type in ('A','F','O','I') then sec.reference WHEN SEC.TYPE = 'G' THEN UNDERLYING.REFERENCE ELSE '' END "Ticker"
      , histomvts.refcon "Trade ID"
			, CASE WHEN histomvts.quantite > 0 THEN 'B' WHEN histomvts.quantite < 0 THEN 'S' ELSE '' END "Buy/Sell"
      , SEC.libelle "Security"
      , DECODE(Underlying.TYPE,'H',Underlying.LIBELLE,'') "Issuer"
      , CNTRY_OF_ISSUE.code "Country of Issue"
      , CNTRY_OF_INC.code "Country of Incorporation"      
      , DECODE(SEC.TYPE,'G',devise_to_str(Underlying.devisectt),devise_to_str(sec.devisectt)) "Currency"
      , round(histomvts.cours,12) "Trade price (local)"
      , histomvts.quantite "Quantity"
      , round(nvl(histomvts.quantite * sec.nominal, 0),12) "Nominal"
      , histomvts.MONTANT "Net Amount (Sett CCY)"
      , histomvts.dateneg "Trade Date"
      , TO_CHAR(TRUNC(histomvts.HEURENEG/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(histomvts.HEURENEG,3600)/60),'FM00') || ':' || TO_CHAR(MOD(histomvts.HEURENEG,60),'FM00') "Trade execution time"      
			, HISTOMVTS.dateval    							"SettlementDate"
      , Trader.NAME                       "Trader"
      , FUND_BOOK_STRATEGY.BOOK_NAME "Strategy"
      , broker.NAME "Broker"      
      , counterparty.NAME "Counterparty"
      , histomvts.fraiscourtage "Broker fees"      
      , histomvts.fraiscounterparty "Counterparty Fees"    
      , histomvts.fraismarche "Market Fees"    
      , CASE
								WHEN sec.type = 'S' THEN TRUNC(sec.datefinal) --IRS, OIS, Inflation Swaps, vol swap, var swap, eq swap, CDS, Correlation Swaps
								WHEN sec.type IN ('B','G','O') THEN TRUNC(sec.finper) --Caps and Floors, CFD, Bonds
								WHEN sec.affectation IN (2,10,31,1250,1301,1060,1041,23 ) THEN TRUNC(sec.finper) --OTC Stock Derivatives, Listed Options, Swaptions, CDS Options, Variance Options, Dividend Option, Volatility Options, FX Option
								WHEN (sec.type = 'F' OR sec.affectation = 14) THEN TRUNC(sec.echeance) --Dividend Future or Package
								WHEN sec.type = 'K' THEN HISTOMVTS.dateval   --NDF
								WHEN sec.type IN ('L','N') THEN TRUNC(sec.dateregl) --Repo
								ELSE null
			  END                                                                           "Maturity Date"
      

FROM histomvts
LEFT JOIN titres sec ON sec.sicovam = histomvts.sicovam

INNER JOIN business_events BE ON BE.id = HISTOMVTS.type
and be.compta = 1

LEFT JOIN tiers counterparty 
ON counterparty.ident = histomvts.contrepartie

LEFT JOIN tiers broker 
ON broker.ident = histomvts.courtier

LEFT JOIN tiers depositary 
ON depositary.ident = histomvts.depositaire

LEFT JOIN affectation 
ON affectation.ident = sec.affectation

LEFT JOIN 		riskusers 						Trader 
ON 				Trader.ident 				=  histomvts.OPERATEUR
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR

LEFT JOIN 		business_events 
ON 				business_events.id 				= histomvts.type

LEFT JOIN   titres Underlying
ON          Underlying.sicovam = (case when sec.type='A' then sec.base1 when sec.type='D' then sec.codesj when sec.type='S' then decode(sec.jambe1,1,sec.j2refcon2,decode(sec.j1refcon2,0,sec.j2refcon2,sec.j1refcon2)) else decode(sec.code_emet,0,decode(sec.codesj,0,sec.codesj2,sec.codesj),sec.code_emet) end)

left join 		references uf 
on 				uf.allotment = CASE WHEN SEC.TYPE = 'G' THEN sec.AFFECTATION ELSE sec.affectation END
and 			uf.reference='TICKER'

LEFT JOIN 		ric 
ON 				ric.sicovam						= CASE WHEN SEC.TYPE = 'G' THEN Underlying.SICOVAM ELSE sec.sicovam END

LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SEA_ISSUE
ON        SEA_ISSUE.SICOVAM = SEC.SICOVAM
AND       SEA_ISSUE.TYPE=5349

LEFT JOIN SECTORS CNTRY_OF_ISSUE
ON        SEA_ISSUE.SECTOR = CNTRY_OF_ISSUE.ID

LEFT JOIN SECTOR_INSTRUMENT_ASSOCIATION SEA_INC
ON        SEA_INC.SICOVAM = SEC.SICOVAM
AND       SEA_INC.TYPE=5348

LEFT JOIN SECTORS CNTRY_OF_INC
ON        SEA_INC.SECTOR = CNTRY_OF_INC.ID


LEFT JOIN TA_BLOCK_TO_GENERATED BlockTrade
on        BlockTrade.generated_id = histomvts.sicovam

INNER JOIN (
    SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                        ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME                          
                        ,FOLIO.ident AS STRATEGY_ID
                        ,FOLIO.NAME AS STRATEGY_NAME
                        ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 4 START
            WITH FOLIO.ident IN (14414,90565) --Primary funds
                        CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY ON FUND_BOOK_STRATEGY.STRATEGY_ID = histomvts.OPCVM
WHERE histomvts.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
and userinfos.country=REGION
and decode(counterparty.name,'NDF FIXING',1,0) = 0 
and histomvts.type not in (3,8,9,100,30,31,360,380,274,121,1094,744,846)
and trunc(histomvts.DATENEG) <= trunc(last_day(add_months(sysdate,-1)))
and trunc(HISTOMVTS.DATENEG) >= TRUNC(ADD_MONTHS(SYSDATE, -1), 'MM') 
ORDER BY 15;  
    
  -- *****************************************************************
  -- END OF: REGION_MARKET_ABUSE
  -- *****************************************************************   
	END REGION_MARKET_ABUSE;  



-- *****************************************************************
-- Description: PROCEDURE CROSS_PRINCIPAL_TRADE_T1 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 07 AUG 2017      COM-303
-- 04 OCT 2017      COM-304 (Modify to add filter "same broker")
-- 05 OCT 2017      APPSUPP-3298 (Modified by Jeff Yu to re-format trade_date and settle_date)
-- 11 OCT 2017      COM-306 (Add field "Time")
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE CROSS_PRINCIPAL_TRADE_T1
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: CROSS_PRINCIPAL_TRADE_T1
  -- *****************************************************************  
		OPEN p_CURSOR FOR
	
SELECT 
CT.fund_name as "Fund Name"
,BOOK_NAME as Strategy
,CT.DATENEG as  d$Trade_Date
,to_char(to_date(histomvts.heureneg,'sssss'),'hh24:mi:ss') as Time
,HISTOMVTS.DATEVAL as d$Settlement_Date
,CT.SICOVAM as "Security ID"
,TITRES.LIBELLE as "Security Name"
,CT.parent as "Block ID"
,CT.tradeid as "Trade ID"
,CT.QUANTITE as Quantity
,histomvts.MONTANT as "Net Amount"
,HISTOMVTS.COURS AS PRICE
,affectation.libelle as allotment
,BE.name as "Business Event"
,BROKER.NAME AS BROKER
,CPTY.NAME AS COUNTERPARTY
,RISKUSERS.NAME AS trader
,enteredby.NAME as Operater
,histomvts.infos as "FO Remarks"
,histomvts.infosbackoffice as "BO Remarks"
FROM
(
-----****Two Funds Scenario***-----
(
----*******Part-1 Allocated trades*******-----
select fund_name,BOOK_NAME,DATENEG,SICOVAM,parent,tradeid,QUANTITE
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.parent,A.tradeid,A.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
where  A.QUANTITE + B.QUANTITE = 0 --same quantity different direction

UNION ----Connect Fund B allocated trades---

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.parent,B.tradeid,B.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 

) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
where  A.QUANTITE + B.QUANTITE = 0  --same quantity different direction
)
--***Part 2 Connect trades booked directly in funds***---

UNION 

select fund_name,BOOK_NAME,DATENEG,SICOVAM,null as parent,refcon,quantite
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.refcon,A.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
and  A.QUANTITE + B.QUANTITE = 0 --same quantity different direction

UNION

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
and  A.QUANTITE + B.QUANTITE = 0  --same quantity different direction
) 
where refcon not in (
select generated_id from histomvts
inner join TA_BLOCK_TO_GENERATED
on TA_BLOCK_TO_GENERATED.generated_id=histomvts.refcon) --Trades allocated from block level--
) 
-----***Three Funds Scenario***----
UNION

(
----Allocated trades-----
select fund_name,BOOK_NAME,DATENEG,SICOVAM,parent,tradeid,QUANTITE
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.parent,A.tradeid,A.QUANTITE
from 
--Fund A--
(SELECT tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
left join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
inner join
--Fund C--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION ----Union Fund B allocated trade ---

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.parent,B.tradeid,B.QUANTITE
from 
--Fund A--
(SELECT tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
left join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
inner join
--Fund C--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION ----Union Fund C allocated trade ---

select  C.fund_name,C.BOOK_NAME,C.DATENEG,C.SICOVAM,C.parent,C.tradeid,C.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--Fund C--
inner join
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE  A.QUANTITE+B.QUANTITE+C.QUANTITE=0
)
------*********Below union connects to trades booked directly in funds********

UNION ---Connect trades booked directly in funds---

select fund_name,BOOK_NAME,DATENEG,SICOVAM,null as parent,refcon,quantite
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.refcon,A.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION --connect to Fund B--

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION --connect to Fund C--

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

) GRAND
where refcon not in (
select generated_id from histomvts
inner join TA_BLOCK_TO_GENERATED
on TA_BLOCK_TO_GENERATED.generated_id=histomvts.refcon)
)
)CT
INNER JOIN TITRES
ON TITRES.SICOVAM=CT.SICOVAM
INNER JOIN HISTOMVTS
ON CT.tradeid=HISTOMVTS.REFCON
LEFT JOIN TIERS CPTY
ON HISTOMVTS.CONTREPARTIE=CPTY.IDENT
LEFT JOIN TIERS BROKER
ON HISTOMVTS.COURTIER=BROKER.IDENT
INNER JOIN AFFECTATION
ON AFFECTATION.IDENT=TITRES.AFFECTATION
LEFT JOIN  BUSINESS_EVENTS BE
ON  BE.id = histomvts.type
LEFT JOIN RISKUSERS
ON RISKUSERS.IDENT=HISTOMVTS.OPERATEUR
LEFT JOIN audit_mvt 
ON audit_mvt.refcon = histomvts.refcon
AND audit_mvt.version = 1
LEFT JOIN riskusers enteredby 
ON enteredby.ident = audit_mvt.userid
ORDER BY CT.DATENEG desc,CT.SICOVAM,CT.parent,CT.tradeid;

  
  -- *****************************************************************
  -- END OF: CROSS_PRINCIPAL_TRADE_T1
  -- *****************************************************************   
	END CROSS_PRINCIPAL_TRADE_T1;  



-- *****************************************************************
-- Description: PROCEDURE CROSS_PRINCIPAL_TRADE_INTRADAY
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 11 OCT 2017      COM-306 
-- 04 DEC 2017      APPSUPP-3729   Update intraday report to only include US Strategies.
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE CROSS_PRINCIPAL_TRADE_INTRADAY
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: CROSS_PRINCIPAL_TRADE_INTRADAY
  -- *****************************************************************  
		OPEN p_CURSOR FOR
	

SELECT 
CT.fund_name as "Fund Name"
,BOOK_NAME as Strategy
,CT.DATENEG as  d$Trade_Date
, to_char(to_date(histomvts.heureneg,'sssss'),'hh24:mi:ss') as Time
,HISTOMVTS.DATEVAL as d$Settlement_Date
,CT.SICOVAM as "Security ID"
,TITRES.LIBELLE as "Security Name"
,CT.parent as "Block ID"
,CT.tradeid as "Trade ID"
,CT.QUANTITE as Quantity
,histomvts.MONTANT as "Net Amount"
,HISTOMVTS.COURS AS PRICE
,affectation.libelle as allotment
,BE.name as "Business Event"
,BROKER.NAME AS BROKER
,CPTY.NAME AS COUNTERPARTY
,RISKUSERS.NAME AS trader
,enteredby.NAME as Operater
,histomvts.infos as "FO Remarks"
,histomvts.infosbackoffice as "BO Remarks"
FROM
(
-----****Two Funds Scenario***-----
(
----*******Part-1 Allocated trades*******-----
select fund_name,BOOK_NAME,DATENEG,SICOVAM,parent,tradeid,QUANTITE
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.parent,A.tradeid,A.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
where  A.QUANTITE + B.QUANTITE = 0 --same quantity different direction

UNION ----Connect Fund B allocated trades---

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.parent,B.tradeid,B.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 

) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
where  A.QUANTITE + B.QUANTITE = 0  --same quantity different direction
)
--***Part 2 Connect trades booked directly in funds***---

UNION 

select fund_name,BOOK_NAME,DATENEG,SICOVAM,null as parent,refcon,quantite
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.refcon,A.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
and  A.QUANTITE + B.QUANTITE = 0 --same quantity different direction

UNION

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
and  A.QUANTITE + B.QUANTITE = 0  --same quantity different direction
) 
where refcon not in (
select generated_id from histomvts
inner join TA_BLOCK_TO_GENERATED
on TA_BLOCK_TO_GENERATED.generated_id=histomvts.refcon) --Trades allocated from block level--
) 
-----***Three Funds Scenario***----
UNION

(
----Allocated trades-----
select fund_name,BOOK_NAME,DATENEG,SICOVAM,parent,tradeid,QUANTITE
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.parent,A.tradeid,A.QUANTITE
from 
--Fund A--
(SELECT tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
left join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
inner join
--Fund C--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION ----Union Fund B allocated trade ---

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.parent,B.tradeid,B.QUANTITE
from 
--Fund A--
(SELECT tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
left join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
inner join
--Fund C--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'  
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION ----Union Fund C allocated trade ---

select  C.fund_name,C.BOOK_NAME,C.DATENEG,C.SICOVAM,C.parent,C.tradeid,C.QUANTITE
from 
--Fund A--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree.block_id as parent,tree.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree
on histomvts.refcon=tree.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree1.block_id as parent,tree1.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree1
on histomvts.refcon=tree1.tradeid
inner join tiers
on histomvts.entite=tiers.ident
 INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%'
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--Fund C--
inner join
(SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,histomvts.SICOVAM,tree2.block_id as parent,tree2.tradeid,QUANTITE,COURTIER
FROM HISTOMVTS 
inner join (
select block_id,generated_id as tradeid,quantity from
(select block_id,generated_id,quantity,
count(distinct(quantity)) over (PARTITION BY block_id) as cnt,
count(generated_id) over (PARTITION BY block_id) as child
from TA_BLOCK_TO_GENERATED
) where (child=1) or (cnt !=1 and child > 1)
) tree2
on histomvts.refcon=tree2.tradeid
left join tiers
on histomvts.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where QUANTITE <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE  A.QUANTITE+B.QUANTITE+C.QUANTITE=0
)
------*********Below union connects to trades booked directly in funds********

UNION ---Connect trades booked directly in funds---

select fund_name,BOOK_NAME,DATENEG,SICOVAM,null as parent,refcon,quantite
from (
select  A.fund_name,A.BOOK_NAME,A.DATENEG,A.SICOVAM,A.refcon,A.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION --connect to Fund B--

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

UNION --connect to Fund C--

select  B.fund_name,B.BOOK_NAME,B.DATENEG,B.SICOVAM,B.refcon,B.quantite
from 
--Fund A--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) A
inner join 
--Fund B--
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
--order by dateneg desc
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
 ) B
 ON    A.Fund_Name <> B.Fund_Name --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND A.COURTIER = B.COURTIER --same broker
--and A.QUANTITE + B.QUANTITE = 0
inner join
(
SELECT  tiers.name as fund_name,FUND_BOOK_STRATEGY.BOOK_NAME,DATENEG,SICOVAM,refcon,quantite,COURTIER
FROM HISTOMVTS 
inner join tiers
on HISTOMVTS.entite=tiers.ident
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  HISTOMVTS.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=HISTOMVTS.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = HISTOMVTS.type
AND             business_events.compta = 1
where quantite <> 0    
and  tiers.name not like '%Execution%' 
and BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) --Internal transfer(strat), internal transfer(INT), PB Transfer--
) C
ON    (C.Fund_Name <> B.Fund_Name and C.Fund_Name <> A.Fund_Name)--different fund
AND   C.Sicovam = B.Sicovam --same instrument
and  C.DATENEG = B.DATENEG --same date
AND C.COURTIER = B.COURTIER --same broker
WHERE A.QUANTITE+B.QUANTITE+C.QUANTITE=0

) GRAND
where refcon not in (
select generated_id from histomvts
inner join TA_BLOCK_TO_GENERATED
on TA_BLOCK_TO_GENERATED.generated_id=histomvts.refcon)
)
)CT
INNER JOIN TITRES
ON TITRES.SICOVAM=CT.SICOVAM
INNER JOIN HISTOMVTS
ON CT.tradeid=HISTOMVTS.REFCON
LEFT JOIN TIERS CPTY
ON HISTOMVTS.CONTREPARTIE=CPTY.IDENT
LEFT JOIN TIERS BROKER
ON HISTOMVTS.COURTIER=BROKER.IDENT
INNER JOIN AFFECTATION
ON AFFECTATION.IDENT=TITRES.AFFECTATION
LEFT JOIN  BUSINESS_EVENTS BE
ON  BE.id = histomvts.type
LEFT JOIN RISKUSERS
ON RISKUSERS.IDENT=HISTOMVTS.OPERATEUR
LEFT JOIN USERINFOS
ON USERINFOS.IDENT = HISTOMVTS.OPERATEUR
LEFT JOIN audit_mvt 
ON audit_mvt.refcon = histomvts.refcon
AND audit_mvt.version = 1
LEFT JOIN riskusers enteredby 
ON enteredby.ident = audit_mvt.userid
WHERE USERINFOS.COUNTRY = 'US'
ORDER BY CT.DATENEG desc,CT.SICOVAM,CT.parent,CT.tradeid;

  
  -- *****************************************************************
  -- END OF: CROSS_PRINCIPAL_TRADE_INTRADAY
  -- *****************************************************************   
	END CROSS_PRINCIPAL_TRADE_INTRADAY;  



-- *****************************************************************
-- Description: PROCEDURE CROSS_PRINCIPAL_TRADE_EOD 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 07 AUG 2017      COM-303
-- 05 OCT 2017      APPSUPP-3298 (Re-format trade date and settle date)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE CROSS_PRINCIPAL_TRADE_EOD
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: CROSS_PRINCIPAL_TRADE_EOD
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select 
Fund_NAME
,DATENEG as d$Trade_Date
,CT.SICOVAM as "Security ID"
, TITRES.LIBELLE as "Security Name"
,total as "Total Quantity"
,affectation.libelle as Allotment
from
(
select A.Fund_NAME,A.DATENEG,A.SICOVAM, sumA as total
from 
(
SELECT  Fund_NAME,DATENEG,histomvts.SICOVAM,sum(quantite) as sumA
FROM HISTOMVTS 
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where 
--tiers.name not like '%Execution%' 
BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
GROUP BY Fund_NAME,DATENEG,histomvts.SICOVAM
HAVING sum(quantite) <> 0
) A
inner join
(
SELECT  Fund_NAME,DATENEG,histomvts.SICOVAM,sum(quantite) as sumB
FROM HISTOMVTS 
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where 
--tiers.name not like '%Execution%' 
BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
GROUP BY Fund_NAME,DATENEG,histomvts.SICOVAM
HAVING sum(quantite) <> 0
) B
ON    A.Fund_NAME <> B.Fund_NAME --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND sumA + sumB = 0

UNION

select B.Fund_NAME,B.DATENEG,B.SICOVAM, sumB as total
from 
(
SELECT Fund_NAME,DATENEG,histomvts.SICOVAM,sum(quantite) as sumA
FROM HISTOMVTS 
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where 
--tiers.name not like '%Execution%' 
BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
GROUP BY Fund_NAME,DATENEG,histomvts.SICOVAM
HAVING sum(quantite) <> 0
) A
inner join
(
SELECT  Fund_NAME,DATENEG,histomvts.SICOVAM,sum(quantite) as sumB
FROM HISTOMVTS 
INNER JOIN ( 
                  SELECT   CONNECT_BY_ROOT(FOLIO.ident)                                                  AS TOP_FUND_ID
                          , CONNECT_BY_ROOT(FOLIO.name)                                                  AS TOP_FUND_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2)          AS FUND_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2)           AS Fund_NAME
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4)          AS BOOK_ID
                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4)           AS BOOK_NAME
                          , FOLIO.ident                                                                  AS STRATEGY_ID
                          , FOLIO.name                                                                   AS STRATEGY_NAME
                          , level
                  FROM FOLIO
                  where level >= 2
                  START WITH FOLIO.ident               IN (14414,90565) -- (14414) ----Primary funds
                  CONNECT BY PRIOR FOLIO.ident         =  FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID       =  histomvts.OPCVM
LEFT JOIN BO_KERNEL_STATUS_COMPONENT 
ON BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID=histomvts.backoffice
AND BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_GROUP_ID=68415
LEFT JOIN      business_events
ON              business_events.id = histomvts.type
AND             business_events.compta = 1
where 
--tiers.name not like '%Execution%' 
BO_KERNEL_STATUS_COMPONENT.KERNEL_STATUS_ID is null  --Exclude cancelled trades
and trunc(dateneg) = TRUNC(SYSDATE-1)
and business_events.id in (1,444,161,140,1444,1494) --Purchase/Sale, Purchase/Sale off market, Transfer, Short Sale
and CONTREPARTIE not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
and COURTIER not in (10010875,10010876,10014565,1001406510014066,10014067,10010898,10010899,10010900,10010901,10019066) 
GROUP BY Fund_NAME,DATENEG,histomvts.SICOVAM
HAVING sum(quantite) <> 0
) B
ON    A.Fund_NAME <> B.Fund_NAME --different fund
AND   A.Sicovam = B.Sicovam --same instrument
and  A.DATENEG = B.DATENEG --same date
AND sumA + sumB = 0
) CT
INNER JOIN TITRES
ON TITRES.SICOVAM=CT.SICOVAM
INNER JOIN AFFECTATION
ON AFFECTATION.IDENT=TITRES.AFFECTATION

ORDER BY DATENEG DESC,CT.SICOVAM;

  -- *****************************************************************
  -- END OF: CROSS_PRINCIPAL_TRADE_EOD
  -- *****************************************************************   
	END CROSS_PRINCIPAL_TRADE_EOD;  


-- *****************************************************************
-- Description: PROCEDURE NONDISCRE_ACCOUNT_TRADE
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 03 OCT 2017      Created by Jeff Yu. (COM-305)
-- 01 NOV 2017      Modified by Jeff Yu (COM-308)
-- *****************************************************************
  PROCEDURE NONDISCRE_ACCOUNT_TRADE
	(
		p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: NONDISCRE_ACCOUNT_TRADE
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select trades.refcon as trade_id
,titres.libelle as security
,titres.reference
,trades.dateneg as trade_date
, to_char(to_date(heureneg,'sssss'),'hh24:mi:ss') as time
,ext.value as ISIN
,case when quantite < 0 then 'Sell' else 'Buy' end as "Buy/Sell"
,quantite
, trades.MONTANT AS TRANSACTION_AMOUNT
,DEVISE_TO_STR(DEVISEPAY) AS PAYMENT_CURRENCY
, BE.Name as "Business Event"
,STRATEGY.Fund_NAME as "Account Number"
,STRATEGY.Fund_NAME as "Client Name"
,RISKUSERS.NAME AS trader
from JOIN_POSITION_HISTOMVTS trades
inner join titres
on titres.sicovam=trades.sicovam
inner join 
(
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 1, 2) AS Fund_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.NAME, '�'), '[^�]+', 3, 4) AS BOOK_NAME
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,FOLIO.NAME AS STRATEGY_NAME
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 START
                                WITH FOLIO.ident IN (130481)
                                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=trades.OPCVM
LEFT JOIN BUSINESS_EVENTS BE
ON BE.ID=trades.type
left join EXTRNL_REFERENCES_INSTRUMENTS ext
on ext.sophis_ident=titres.sicovam
and ext.REF_IDENT=1
LEFT JOIN RISKUSERS
ON RISKUSERS.IDENT=trades.OPERATEUR
WHERE trunc(dateneg) >= TRUNC(SYSDATE-30);


  -- *****************************************************************
  -- END OF: NONDISCRE_ACCOUNT_TRADE
  -- *****************************************************************   
	END NONDISCRE_ACCOUNT_TRADE;  


-- *****************************************************************
-- Description: PROCEDURE  ORDER_FLAGGED_EXCEPTION
--
-- Revision History
-- Date       User      JIRA
-- ----------------------------------------------------------------
-- 27 DEC 2017     Jeff Yu      Created (COM-309)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE ORDER_FLAGGED_EXCEPTION
	(
	   STRATEGY	  IN	VARCHAR2
	 , p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: ORDER_FLAGGED_EXCEPTION
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select   distinct  Child.allotment
, "Instrument Type"
, exe.refcon    as  "Order ID"
, "Buy/Sell"
, Child.security  as "Security Name"
, Child.reference    as  "Security Reference"
, PAYMENT_CURRENCY
, Child.price
, exe.quantite  
, exe.MONTANT   as gross_amount
, d$trade_date
, TO_CHAR(TRUNC(exe.HEURENEG/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(exe.HEURENEG,3600)/60),'FM00') || ':' || TO_CHAR(MOD(exe.HEURENEG,60),'FM00') "Trade Execution Time"      
, Child.trader
, Child.broker
, Child.counterparty
, 'Y'  as flag
, exe.BTG_EXCEPTION_COMMENTS     as "Exception Comments"      
FROM  (
SELECT  DISTINCT
        affectation.libelle   as allotment
      , btg_get_instrument_type(trades.sicovam) "Instrument Type"
      , trades.refcon    as  trade_id
			, CASE WHEN trades.quantite > 0 THEN 'B' WHEN trades.quantite < 0 THEN 'S' ELSE '' END "Buy/Sell"
      , SEC.libelle  as security
      , sec.reference  
      , DEVISE_TO_STR(DEVISEPAY) AS PAYMENT_CURRENCY
      , round(trades.cours,12)   as price
      , trades.dateneg   as  d$trade_date
      , Trader.NAME            as trader
      , broker.NAME   as broker
      , counterparty.NAME   as counterparty
      
FROM HISTOMVTS trades
INNER JOIN (
           SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                        ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID
                        , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME                          
                        ,FOLIO.ident AS STRATEGY_ID
                        ,FOLIO.NAME AS STRATEGY_NAME
                        ,LEVEL
            FROM FOLIO
            WHERE   LEVEL >= 4 START
            WITH FOLIO.ident IN (14414,90565) --Primary funds
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
            ) FUND_BOOK_STRATEGY 
ON FUND_BOOK_STRATEGY.STRATEGY_ID = trades.OPCVM
INNER JOIN titres sec 
ON sec.sicovam = trades.sicovam
LEFT JOIN tiers counterparty 
ON counterparty.ident = trades.CONTREPARTIE
LEFT JOIN tiers broker 
ON broker.ident = trades.courtier
LEFT JOIN affectation 
ON affectation.ident = sec.affectation
LEFT JOIN 		riskusers 						Trader 
ON 	Trader.ident 				=  trades.OPERATEUR

WHERE trades.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
and FUND_BOOK_STRATEGY.BOOK_NAME = STRATEGY  ---pass parameter here
)    Child
left join TA_BLOCK_TO_GENERATED PARENT
ON PARENT.GENERATED_ID = child.trade_id
inner join HISTOMVTS exe
on exe.refcon = PARENT.BLOCK_ID
where  trunc(exe.DATENEG) = trunc(sysdate) - 1
and exe.btg_exception_flag = 1;

 -- *****************************************************************
  -- END OF: ORDER_FLAGGED_EXCEPTION
  -- *****************************************************************   
	END ORDER_FLAGGED_EXCEPTION;  


END PCKG_BTG_PMO_REPORTS_COMP;