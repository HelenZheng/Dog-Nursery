create or replace
PACKAGE BODY            "PCKG_BTG_PMO_REPORTS_OPS" 
AS
  
  -- *****************************************************************
  -- Description: PROCEDURE TRADES_BOOKED_LATE
  --
  -- Author:          Gustavo Binnie
  --
  -- Revision History
  -- Date             Author        Reason for Change
  -- ----------------------------------------------------------------
  --    2013      Gustavo Binnie     Created.
  -- ----------------------------------------------------------------
  -- Date             JIRA
  -- ----------------------------------------------------------------
  -- 02 MAY 2016      GAMACN-17
  -- 13 FEB 2018     Jeff Yu   PMOG-1205
  -- *****************************************************************
  PROCEDURE TRADES_BOOKED_LATE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: TRADES_BOOKED_LATE
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
SELECT
                  Trades.refcon                                    Trade_ID
                , trader.name                                      Trader
				, booked.NAME									   Booked_By
				, FUND_BOOK_STRATEGY.BOOK_NAME					   Strategy
				, Trades.sicovam                                   Sicovam
				, Instrument.libelle                               Instrument_Name
                , Instrument.reference                             Ticker				
				, trunc(Trades.DATENEG)                            d$Trade_Date
                , trunc(Trades.DATEVAL)                            d$Value_Date
				, trunc(audit_mvt.datemodif)					   d$Insertion_Date
				, BTG_BUSINESS_DAYS(trunc(Trades.DATENEG), trunc(audit_mvt.datemodif))-1  n$Nb_Bus_Days_Late 
                , Trades.quantite                                  n$Qty
                , decode(Trades.quantite, 0, Trades.cours,  ROUND(abs(Trades.Montant/Trades.quantite),8) ) Net_Price
                , bo_kernel_status.name                            Status
                , DEVISE_TO_STR(Trades.devisepay)                  Currency
                , btg_get_instrument_type (Trades.sicovam)         Instrument_Type
                , business_events.NAME                             Busines_Event
                , Broker.NAME                              	       Broker
                             
      FROM                    histomvts Trades       
      INNER JOIN              titres Instrument 
      ON                      Instrument.sicovam                  =  Trades.sicovam
      INNER JOIN              business_events
      ON                      business_events.id                  =  Trades.type
      INNER JOIN              tiers PrimeBroker     
      ON                      PrimeBroker.IDENT                   =  Trades.DEPOSITAIRE
      INNER JOIN              bo_kernel_status
      ON                      bo_kernel_status.id                 =  Trades.backoffice
      INNER JOIN              tiers Broker     
      ON                      Broker.IDENT                        =  Trades.courtier      
      INNER JOIN 			  audit_mvt
      on 					  audit_mvt.refcon 					  =  TRADES.REFCON
      and 					  audit_mvt.version 				  =  1             
      LEFT JOIN               riskusers booked
      ON                      booked.ident 						  =  audit_mvt.USERID

      INNER JOIN ( 
                              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                           AS TOP_FUND_ID
                                    , CONNECT_BY_ROOT(FOLIO.name)                                           AS TOP_FUND_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)   AS FUND_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)    AS Fund_NAME
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)   AS BOOK_ID
                                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)    AS BOOK_NAME
                                    , FOLIO.ident                                                           AS STRATEGY_ID
                                    , FOLIO.name                                                            AS STRATEGY_NAME
                                    , level
                              FROM FOLIO
                              WHERE 
                              LEVEL >= 3
                              START WITH FOLIO.ident            IN (14045)
                              CONNECT BY PRIOR FOLIO.ident       =  FOLIO.mgr  
                            ) FUND_BOOK_STRATEGY
      ON                    FUND_BOOK_STRATEGY.STRATEGY_ID       =  Trades.OPCVM
      LEFT JOIN             riskusers trader
      ON                    trader.ident                         =  Trades.operateur
      WHERE          
							Trades.BACKOFFICE                                           NOT IN (11,13,17,26,27,192,220,248,252)   -- not cancelled trades
          AND 				trunc(audit_mvt.datemodif) 	>= trunc (sysdate) - 7  ---Trades inserted in last week
          AND 				trunc(trades.dateneg) 				<= BTG_BUSINESS_DATE(trunc(audit_mvt.datemodif),-2)
          AND               business_events.compta               =  1 --trades affecting position
          AND               Instrument.type                     != 'L'          
      ORDER BY        2 ASC;     
    
    
  -- *****************************************************************
  -- END OF: TRADES_BOOKED_LATE
  -- *****************************************************************   
	END TRADES_BOOKED_LATE;  
	
-- *****************************************************************
-- Description: PROCEDURE UNAVISTA_ALLOTMENT_LIST
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 JUN 2016      GAMACN-60
-- *****************************************************************
  PROCEDURE UNAVISTA_ALLOTMENT_LIST
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UNAVISTA_ALLOTMENT_LIST
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
select					  affectation.libelle Allotment
						, affectation.ident AllotmentID
						, CASE WHEN amrecon_extsys_accounts.allotment is null THEN 'Y' ELSE 'N' END Included_UnaVista_Trade_File 
from affectation
LEFT JOIN amrecon_extsys_accounts 
ON amrecon_extsys_accounts.allotment=affectation.ident 
and amrecon_extsys_accounts.include=0 
and amrecon_extsys_accounts.esid=2531 --Unavista External System ID
ORDER BY 1;     
    
  -- *****************************************************************
  -- END OF: UNAVISTA_ALLOTMENT_LIST
  -- *****************************************************************   
	END UNAVISTA_ALLOTMENT_LIST;        	      

-- *****************************************************************
-- Description: PROCEDURE UNAVISTA_BROKER_MIFID_LIST
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 JUN 2016      GAMACN-60
-- *****************************************************************
  PROCEDURE UNAVISTA_BROKER_MIFID_LIST
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UNAVISTA_BROKER_MIFID_LIST
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select					 tiers.name				Broker_Name
						,tiers.reference		Broker_Reference
						,tiers.ident			Broker_ID
						,folder.name			Folder
						,tiersproperties.value  MiFID 
						,TIERSGENERAL.SWIFT		BIC_Code
						,FRN.VALUE				FRN_Code
						,tiers.EXTERNREF		CGE
from tiers 

left join TIERSGENERAL
on TIERSGENERAL.CODE = tiers.IDENT

left join tiersproperties 
on tiersproperties.code=tiers.ident 
and tiersproperties.name='MiFID (Y/N)'

left join tiersproperties FRN
on FRN.code=tiers.ident 
and FRN.name='FRN CODE'

left join tiers folder
on folder.ident = tiers.MGR

where (ESTCONTREPARTIE(tiers.OPTIONS) = 1
or ESTCOURTIER(tiers.OPTIONS) = 1)
and tiers.MGR not in (10016915,10016967,10016965,10016966)
order by 1;
    
  -- *****************************************************************
  -- END OF: UNAVISTA_BROKER_MIFID_LIST
  -- *****************************************************************   
	END UNAVISTA_BROKER_MIFID_LIST;

-- *****************************************************************
-- Description: PROCEDURE UNAVISTA_USER_REGION_LIST
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 JUN 2016      GAMACN-60
-- *****************************************************************
  PROCEDURE UNAVISTA_USER_REGION_LIST
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UNAVISTA_USER_REGION_LIST
  -- *****************************************************************  
		OPEN p_CURSOR FOR
 
select						  riskusers.ident		UserID
							, riskusers.name		SophisUserName 
							, groupname.name		UserGroup
							, CASE WHEN userinfos.country='UK' THEN 'Y' ELSE 'N' END UK_Based

from riskusers 

left join riskusers groupname 
on groupname.ident=riskusers.gident 

INNER JOIN userinfos 
ON userinfos.ident=riskusers.ident

ORDER BY 2
;
    
  -- *****************************************************************
  -- END OF: UNAVISTA_USER_REGION_LIST
  -- *****************************************************************   
	END UNAVISTA_USER_REGION_LIST;

-- *****************************************************************
-- Description: PROCEDURE UNAVISTA_BUSINESS_EVENT_LIST 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 JUN 2016      GAMACN-60
-- *****************************************************************
  PROCEDURE UNAVISTA_BUSINESS_EVENT_LIST
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UNAVISTA_BUSINESS_EVENT_LIST
  -- *****************************************************************  
		OPEN p_CURSOR FOR
 
select									  BUSINESS_EVENTS.ID	"ID"
										, BUSINESS_EVENTS.NAME	Business_Event
										, CASE WHEN BE_FILTER.BUSINESSEVENT IS NULL THEN 'N' ELSE 'Y' END Included_UnaVista_Trade_File
from BUSINESS_EVENTS

left join AMRECON_DEALS_FILTER BE_FILTER
ON BE_FILTER.BUSINESSEVENT = BUSINESS_EVENTS.ID
AND BE_FILTER.ID = 2061

ORDER BY 2
;
    
  -- *****************************************************************
  -- END OF: UNAVISTA_BUSINESS_EVENT_LIST
  -- *****************************************************************   
	END UNAVISTA_BUSINESS_EVENT_LIST;

-- *****************************************************************
-- Description: PROCEDURE UNAVISTA_MARKET_LIST 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 JUN 2016      GAMACN-60
-- *****************************************************************
  PROCEDURE UNAVISTA_MARKET_LIST
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: UNAVISTA_MARKET_LIST
  -- *****************************************************************  
		OPEN p_CURSOR FOR
 
select * from 
( 
( 
select 

devise_to_str(marche.codedevise) Currency 
,place.libelle Place 
,marche.libelle Market
,ESMA_Flag.value ESMA_Flag
,MIC_CODE.value MIC_Code
     
from marche 

left join extrnl_ref_market_value ESMA_Flag
on ESMA_Flag.market=marche.mnemomarche 
and ESMA_Flag.currency = marche.CODEDEVISE
and ESMA_Flag.ref_ident=8 

left join extrnl_ref_market_value MIC_CODE
on MIC_CODE.market=marche.mnemomarche 
and MIC_CODE.currency = marche.CODEDEVISE
and MIC_CODE.ref_ident=7

LEFT JOIN place 
ON marche.placedecotationv2 = place.code 

     
) 
UNION ALL 
( 

select 'Future'
,'Future'
, Nom Market
, ESMA_Map.output_code ESMA_Flag
, MIC_Map.output_code MIC_Code

from marcheorganise 

left join btg_mapping_code ESMA_Map
on ESMA_Map.input_code=marcheorganise.ident 
and ESMA_Map.source_id=3 
and ESMA_Map.type_id=25 

left join btg_mapping_code MIC_Map
on MIC_Map.input_code=marcheorganise.ident 
and MIC_Map.source_id=3 
and MIC_Map.type_id=23
) 
) ;
    
  -- *****************************************************************
  -- END OF: UNAVISTA_MARKET_LIST
  -- *****************************************************************   
	END UNAVISTA_MARKET_LIST;

-- *****************************************************************
-- Description: PROCEDURE NY_OPS_TRADEDATE_CONFIRMATION 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 07 JUN 2016      PMOG-996
-- 18 AUG 2016		PMOG-1038
--04 NOV 2016      PMOG-1060
-- 30 NOV 2017     PMOG-1141
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- 17 SEP 2018		Gustavo Binnie (PMOG-1269)
-- *****************************************************************
  PROCEDURE NY_OPS_TRADEDATE_CONFIRMATION
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: NY_OPS_TRADEDATE_CONFIRMATION
  -- *****************************************************************  
		OPEN p_CURSOR FOR
 
select 
  FUND_BOOK_STRATEGY.Fund_NAME Fund,
  FUND_BOOK_STRATEGY.BOOK_NAME Strategy,
  refcon Tradeid ,
  histomvts.dateneg Trade_Date,
  histomvts.dateval Value_Date,
  abs(histomvts.QUANTITE)* abs(security.nominal) Nominal,                
  case when histomvts.quantite < 0 then 'SELL' when histomvts.quantite > 0 then 'BUY' ELSE '0' END BTGDirec,
  histomvts.cours Gross_Price, 
  abs(histomvts.montant) Net_Amount,
  security.reference ISIN,
  security.libelle   Name,
  CASE WHEN DP.NAME LIKE '%CANTOR%' THEN  CANTOR_FI_CODE.VALUE ELSE UBS_FI_CODE.value END CP

from histomvts
inner join titres security on security.sicovam = histomvts.sicovam  
inner join tiers fund2 on fund2.ident = histomvts.depositaire
LEFT join tiersproperties UBS_FI_CODE on UBS_FI_CODE.code = histomvts.courtier and UBS_FI_CODE.name = 'UBS FI CODE' 
LEFT join tiersproperties CANTOR_FI_CODE on CANTOR_FI_CODE.code = histomvts.courtier and CANTOR_FI_CODE.name = 'CANTOR FI CODE' 
LEFT JOIN TIERS DP ON HISTOMVTS.DEPOSITAIRE = DP.IDENT
inner join business_events on business_events.id = histomvts.type
INNER JOIN ( 
  SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
  , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME  
  , FOLIO.ident AS STRATEGY_ID
  , FOLIO.name AS STRATEGY_NAME
  , level
  FROM FOLIO
  WHERE LEVEL >= 4
  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
) FUND_BOOK_STRATEGY
    ON FUND_BOOK_STRATEGY.STRATEGY_ID =histomvts.OPCVM
where trunc(dateneg) >= trunc(sysdate) 
and histomvts.depositaire in (10005743,10006707,10025795,10005742,10026092, 10027631,10027632,10027633,10027634)
and FUND_BOOK_STRATEGY.BOOK_NAME in ('US Rates','Treasury Offshore', 'Securitized Products','Global Rates')
and security.type = 'O'
and business_events.compta = 1 and id not in ('9', '380')
and backoffice not in (11, 13, 27, 192, 220, 246, 248, 252)
order by CP, ISIN, Value_Date, BTGDirec, Fund;
    
  -- *****************************************************************
  -- END OF: NY_OPS_TRADEDATE_CONFIRMATION
  -- *****************************************************************   
	END NY_OPS_TRADEDATE_CONFIRMATION;

-- *****************************************************************
-- Description:     PROCEDURE  LAST_PRICE_AUDIT_REPORT
--
-- Author:          Oliver South
--
-- Revision History
-- Date                 Author               Reason for Change
-- ----------------------------------------------------------------
-- 19 Mar 2015         Oliver South         Created
-- ----------------------------------------------------------------
-- Date             JIRA
-- ----------------------------------------------------------------
-- 07 JUL 2016      PMOG-761
-- *****************************************************************
PROCEDURE LAST_PRICE_AUDIT_REPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
      , TITRES.REFERENCE                                 Instrument_reference
      , TITRES.LIBELLE                                   Instrument_name
      , BTG_DAILY_AUDIT_HISTORIQUE.USERname
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_DAY      d$Date_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_TIME     Time_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.ACTION                
      , round(BTG_DAILY_AUDIT_HISTORIQUE.D_ORIGINAL,6)  D_Price_Before
      , round(BTG_DAILY_AUDIT_HISTORIQUE.D_AFTER,6)     D_Price_After
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFIED_JOUR         d$Price_date
      , CASE
        WHEN BTG_DAILY_AUDIT_HISTORIQUE.USERname = 'svc_pasv' THEN 'EXCEL PRICE ADD-IN'
        ELSE ''
        END                                               Notes
FROM    BTG_DAILY_AUDIT_HISTORIQUE
INNER JOIN TITRES
ON TITRES.SICOVAM = BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
WHERE   (D_ORIGINAL IS NOT NULL and D_AFTER IS NOT NULL) --if they are null then it indicates it is a theoretical price change, and we don't log those
AND     TRUNC(MODIFICATION_DAY) = TRUNC(BTG_BUSINESS_DATE(SYSDATE,-1)) --can run Mon - Fri making Monday look at Fridays changes
AND     TRUNC(MODIFICATION_DAY) != TRUNC(MODIFIED_JOUR) --show modifications for any date not the same impact date as the modification date
ORDER BY 3,4 DESC
;
END LAST_PRICE_AUDIT_REPORT;

-- *****************************************************************
-- Description:     PROCEDURE  THEORETICAL_PRICE_AUDIT_REPORT
--
-- Author:				Davi Xavier
--
-- Revision History
-- Date                 Author               Reason for Change
-- ----------------------------------------------------------------
-- 29 MaY 2015         Davi Xavier           Created
-- ----------------------------------------------------------------
-- Date             JIRA
-- ----------------------------------------------------------------
-- 07 JUL 2016      PMOG-761 
-- *****************************************************************
PROCEDURE THEORETICAL_PRICE_AUDIT_REPORT
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

select
        BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
      , TITRES.REFERENCE                                 Instrument_reference
      , TITRES.LIBELLE                                   Instrument_name
      , BTG_DAILY_AUDIT_HISTORIQUE.USERname
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_DAY      d$Date_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFICATION_TIME     Time_modified
      , BTG_DAILY_AUDIT_HISTORIQUE.ACTION                
      , round(BTG_DAILY_AUDIT_HISTORIQUE.T_ORIGINAL,6)   T_Price_Before
      , round(BTG_DAILY_AUDIT_HISTORIQUE.T_AFTER,6)      T_Price_After
      , BTG_DAILY_AUDIT_HISTORIQUE.MODIFIED_JOUR         d$Price_date
      , CASE
        WHEN BTG_DAILY_AUDIT_HISTORIQUE.USERname = 'svc_pasv' THEN 'EXCEL PRICE ADD-IN'
        ELSE ''
        END                                               Notes
FROM    BTG_DAILY_AUDIT_HISTORIQUE
INNER JOIN TITRES
ON TITRES.SICOVAM = BTG_DAILY_AUDIT_HISTORIQUE.SICOVAM
WHERE   (T_ORIGINAL IS NOT NULL and T_AFTER IS NOT NULL) 
AND     TRUNC(MODIFICATION_DAY) = TRUNC(BTG_BUSINESS_DATE(SYSDATE,-1)) --can run Mon - Fri making Monday look at Fridays changes
AND     TRUNC(MODIFICATION_DAY) != TRUNC(MODIFIED_JOUR) --show modifications for any date not the same impact date as the modification date
ORDER BY 3,4 DESC
;
END THEORETICAL_PRICE_AUDIT_REPORT;

-- *****************************************************************
-- Description: SOPHIS_DEPOSITARY_ACCOUNTS 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 20 JUL 2016      PMOG-1025
-- 03 MAY 2017     PUSOPUP-313--Part 1: Change logic to report cash account
-- 03 AUG 2017     PMOG-1126  Change column name
-- 09 AUG 2017     PMOG-1126  Add new column "Thid Party Fund Reference"
-- *****************************************************************
PROCEDURE SOPHIS_DEPOSITARY_ACCOUNTS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT 
   TITRES.reference as "Fund Reference"  
  ,PARENT.NAME as "Third Party Fund Reference"
  ,TIERS.ident
	,TIERS.reference
	,TIERS.NAME
	,TIERS.EXTERNREF
	,BO_TREASURY_ACCOUNT.account_name as "Cash Account Name"
  ,DEVISE_TO_STR(CCY) as "Cash Account CCY"  --Add currency column
FROM TIERS 
INNER JOIN TIERS PARENT
ON PARENT.IDENT=TIERS.MGR
INNER JOIN BO_TREASURY_ACCOUNT 
ON BO_TREASURY_ACCOUNT.DEPOSITARY = TIERS.ident
inner JOIN AM_ACCOUNT_FILTER --Report cash account instead of instrument account
ON AM_ACCOUNT_FILTER.ACCOUNTID = BO_TREASURY_ACCOUNT.ID
LEFT JOIN TITRES 
ON TITRES.sicovam = AM_ACCOUNT_FILTER.fund
WHERE ESTDEPOSITAIRE(tiers.options) = 1 --only Depositary
--AND BO_TREASURY_ACCOUNT.ACCOUNT_TYPE=3
ORDER BY TIERS.reference
;

END SOPHIS_DEPOSITARY_ACCOUNTS;

-- *****************************************************************
-- Description: DASH_REPORTS_LISTED_OPT_MOD_T1 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 08 AUG 2016      PMOG-1029
-- 05 JUN 2017      PMOG-1117
-- *****************************************************************
PROCEDURE DASH_REPORTS_LISTED_OPT_MOD_T1
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT t.sicovam                        "Sicovam",
       ULY.reference                    "Underlying Reference",       
           CASE 
         WHEN t.typesj = 2 THEN 'Physical Delivery' 
         WHEN t.typesj = 1 THEN 'New Share' 
         WHEN t.typesj = 8 THEN 'Market Delivery' 
         WHEN t.typesj = 3 THEN 'Cash' 
         WHEN t.typesj = 9 THEN 'Cash and Application' 
         WHEN t.typesj = 5 THEN 'Currency' 
         WHEN t.typesj = 7 THEN 'Future' 
         ELSE 'UNKNOWN'
       END                              "Payment Delivery",
       Devise_to_str (t.devisectt)      "Payment Currency",
       extrnl_ref_market_value.value    "MIC Code",
       t.reference                      "Option Reference",
       t.libelle                        "Option Name",
       t.modele                         "Data Model",
       CASE 
         WHEN t.typepro = 1 THEN 'CALL' 
         WHEN t.typepro = 2 THEN 'PUT' 
         ELSE 'UNKNOWN'
       END                              "Product Type",
       t.finper                         "Expiration Date",
       CASE
         WHEN t.debutper = '01-Jan-1904' THEN 'American'
         ELSE 'European'
       END                              "Exercise Style",
       t.prixexer                       "Strike",
       t.quotite                        "Contract Size",
       affectation.libelle              "Allotment Sophis",
       clause.valeur                    "Over or Fixed Volatility",
       t.modele                         "Data Model",
       fidlist.name                     "FID",
       ric.servisen                     "User Reference",
       EPC.value                        "Exchange Product Code",
       CUSIP.value                      "CUSIP",
       BBG_COMP.value                   "ID BB Company",
       BBG_UNI.value                    "ID BB Unique ID",
       'FALSE'                          "New Position",
       ULY.externref                    "Underlying ISIN"

FROM   titres t

left join titres ULY 
  ON t.codesj = ULY.sicovam
left join affectation 
  ON affectation.ident = t.affectation 
left join ric 
  ON ric.sicovam = t.sicovam 
left join fidlist 
   ON fidlist.item = ric.fid 
left join extrnl_references_instruments EPC 
  ON EPC.sophis_ident = t.sicovam 
     AND EPC.ref_ident = 25 
left join extrnl_references_instruments BBG_COMP 
  ON BBG_COMP.sophis_ident = t.sicovam 
     AND BBG_COMP.ref_ident = 673 
left join extrnl_references_instruments BBG_UNI 
  ON BBG_UNI.sophis_ident = t.sicovam 
     AND BBG_UNI.ref_ident = 674 
left join extrnl_ref_market_value 
  ON extrnl_ref_market_value.currency = t.devisectt 
     AND extrnl_ref_market_value.market = t.marche 
      AND extrnl_ref_market_value.ref_ident = 7 
left join clause 
  ON clause.sicovam = t.sicovam
left join extrnl_references_instruments CUSIP 
  ON CUSIP.sophis_ident = t.sicovam 
    AND CUSIP.ref_ident = 3 
                         
WHERE  t.affectation = 10 --Listed Options 
and ID_TO_CCYSYMBOL(t.devisectt) <> 'BRL'
AND t.sicovam in (

                  (
                  --List of sicovams modified in last day
                  SELECT DISTINCT a.sicovam
                  FROM   btg_titres_audit a
                  left join btg_titres_audit prev
                  ON a.sicovam = prev.sicovam 
                    AND a.audit_version = prev.audit_version + 1 
                  WHERE (
                        a.typesj != prev.typesj Or (a.typesj IS NULL AND prev.typesj IS NOT NULL) OR  (a.typesj IS NOT NULL AND prev.typesj IS NULL)
                        OR a.devisectt != prev.devisectt Or (a.devisectt IS NULL AND prev.devisectt IS NOT NULL) OR  (a.devisectt IS NOT NULL AND prev.devisectt IS NULL) 
                        OR a.reference != prev.reference Or (a.reference IS NULL AND prev.reference IS NOT NULL) OR  (a.reference IS NOT NULL AND prev.reference IS NULL)
                        OR a.libelle != prev.libelle Or (a.libelle IS NULL AND prev.libelle IS NOT NULL) OR  (a.libelle IS NOT NULL AND prev.libelle IS NULL)
                        OR a.modele != prev.modele Or (a.modele IS NULL AND prev.modele IS NOT NULL) OR  (a.modele IS NOT NULL AND prev.modele IS NULL)
                        OR a.typepro != prev.typepro Or (a.typepro IS NULL AND prev.typepro IS NOT NULL) OR  (a.typepro IS NOT NULL AND prev.typepro IS NULL)
                        OR a.finper != prev.finper Or (a.finper IS NULL AND prev.finper IS NOT NULL) OR  (a.finper IS NOT NULL AND prev.finper IS NULL)
                        OR a.debutper != prev.debutper Or (a.debutper IS NULL AND prev.debutper IS NOT NULL) OR  (a.debutper IS NOT NULL AND prev.debutper IS NULL)
                        OR a.prixexer != prev.prixexer Or (a.prixexer IS NULL AND prev.prixexer IS NOT NULL) OR  (a.prixexer IS NOT NULL AND prev.prixexer IS NULL)
                        OR a.quotite != prev.quotite Or (a.quotite IS NULL AND prev.quotite IS NOT NULL) OR  (a.quotite IS NOT NULL AND prev.quotite IS NULL)
                        OR a.affectation != prev.affectation Or (a.affectation IS NULL AND prev.affectation IS NOT NULL) OR  (a.affectation IS NOT NULL AND prev.affectation IS NULL)
                        OR a.modele != prev.modele Or (a.modele IS NULL AND prev.modele IS NOT NULL) OR  (a.modele IS NOT NULL AND prev.modele IS NULL)
                  )
                  AND Trunc(a.audit_date) = Trunc(SYSDATE - 1)
                  --Changes in Ctrl + J (Infos)  
                  UNION
                  SELECT a.sicovam 
                  FROM   btg_audit_ric a 
                  WHERE  ( Nvl(a.new_servisen, '(null)') != Nvl(a.old_servisen, '(null)') ) 
                  AND Trunc(a.modification_day) = Trunc(SYSDATE - 1) 
                  -- Changes in External References 
                  UNION 
                  SELECT DISTINCT ( sophis_ident ) 
                  FROM   btg_extrnl_ref_instr_audit 
                  WHERE  Trunc(audit_date) = Trunc(SYSDATE - 1) 
                  AND ref_ident IN ( 25, 673, 674 )
                  )
                  
                  
                  MINUS
                    
                  (
                  --Instruments with positions opened in last day
                      SELECT h.sicovam
                      FROM histomvts h
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate - 1) --yesterday
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.sicovam
                      HAVING SUM(h.quantite) = 0 --no position
                    
                    INTERSECT

                      SELECT h.sicovam
                      FROM histomvts h                          
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate) --today
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.SICOVAM
                      HAVING SUM(h.quantite) <> 0 --open position
                  )           
)

UNION ALL

SELECT t.sicovam                        "Sicovam",
       ULY.reference                    "Underlying Reference",        
       CASE 
         WHEN t.typesj = 2 THEN 'Physical Delivery' 
         WHEN t.typesj = 1 THEN 'New Share' 
         WHEN t.typesj = 8 THEN 'Market Delivery' 
         WHEN t.typesj = 3 THEN 'Cash' 
         WHEN t.typesj = 9 THEN 'Cash and Application' 
         WHEN t.typesj = 5 THEN 'Currency' 
         WHEN t.typesj = 7 THEN 'Future' 
         ELSE 'UNKNOWN'
       END                              "Payment Delivery",
       Devise_to_str (t.devisectt)      "Payment Currency",
       extrnl_ref_market_value.value    "MIC Code",
       t.reference                      "Option Reference",
       t.libelle                        "Option Name",
       t.modele                         "Data Model",
       CASE 
         WHEN t.typepro = 1 THEN 'CALL' 
         WHEN t.typepro = 2 THEN 'PUT' 
         ELSE 'UNKNOWN'
       END                              "Product Type",
       t.finper                         "Expiration Date",
       CASE
         WHEN t.debutper = '01-Jan-1904' THEN 'American'
         ELSE 'European'
       END                              "Exercise Style",
       t.prixexer                       "Strike",
       t.quotite                        "Contract Size",
       affectation.libelle              "Allotment Sophis",
       clause.valeur                    "Over or Fixed Volatility",
       t.modele                         "Data Model",
       fidlist.name                     "FID",
       ric.servisen                     "User Reference",
       EPC.value                        "Exchange Product Code",
       CUSIP.value                      "CUSIP",
       BBG_COMP.value                   "ID BB Company",
       BBG_UNI.value                    "ID BB Unique ID",
       'TRUE'                           "New Position",
       ULY.externref                    "Underlying ISIN"


FROM   titres t

left join titres ULY 
  ON t.codesj = ULY.sicovam
left join affectation 
  ON affectation.ident = t.affectation 
left join ric 
  ON ric.sicovam = t.sicovam 
left join fidlist 
   ON fidlist.item = ric.fid 
left join extrnl_references_instruments EPC 
  ON EPC.sophis_ident = t.sicovam 
     AND EPC.ref_ident = 25 
left join extrnl_references_instruments BBG_COMP 
  ON BBG_COMP.sophis_ident = t.sicovam 
     AND BBG_COMP.ref_ident = 673 
left join extrnl_references_instruments BBG_UNI 
  ON BBG_UNI.sophis_ident = t.sicovam 
     AND BBG_UNI.ref_ident = 674 
left join extrnl_ref_market_value 
  ON extrnl_ref_market_value.currency = t.devisectt 
     AND extrnl_ref_market_value.market = t.marche 
      AND extrnl_ref_market_value.ref_ident = 7 
left join clause 
  ON clause.sicovam = t.sicovam
left join extrnl_references_instruments CUSIP 
  ON CUSIP.sophis_ident = t.sicovam 
    AND CUSIP.ref_ident = 3 
                         
WHERE  t.affectation = 10 --Listed Options 
and ID_TO_CCYSYMBOL(t.devisectt) <> 'BRL'
AND t.sicovam in (
                  --Instruments with positions opened in last day
                      SELECT h.sicovam
                      FROM histomvts h
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate - 1) --yesterday
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.sicovam
                      HAVING SUM(h.quantite) = 0 --no position
                    
                    INTERSECT

                      SELECT h.sicovam
                      FROM histomvts h                          
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate) --today
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.SICOVAM
                      HAVING SUM(h.quantite) <> 0 --open position
)
ORDER BY "Underlying Reference", "Option Reference";

END DASH_REPORTS_LISTED_OPT_MOD_T1;

-- *****************************************************************
-- Description: DASH_REPORTS_LISTED_OPT_MOD_T3 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 08 AUG 2016      PMOG-1029
-- 05 JUN 2017      PMOG-1117
-- *****************************************************************
PROCEDURE DASH_REPORTS_LISTED_OPT_MOD_T3
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
  
     OPEN p_CURSOR FOR

SELECT t.sicovam                        "Sicovam",
       ULY.reference                    "Underlying Reference",
       CASE 
         WHEN t.typesj = 2 THEN 'Physical Delivery' 
         WHEN t.typesj = 1 THEN 'New Share' 
         WHEN t.typesj = 8 THEN 'Market Delivery' 
         WHEN t.typesj = 3 THEN 'Cash' 
         WHEN t.typesj = 9 THEN 'Cash and Application' 
         WHEN t.typesj = 5 THEN 'Currency' 
         WHEN t.typesj = 7 THEN 'Future' 
         ELSE 'UNKNOWN'
       END                              "Payment Delivery",
       Devise_to_str (t.devisectt)      "Payment Currency",
       extrnl_ref_market_value.value    "MIC Code",
       t.reference                      "Option Reference",
       t.libelle                        "Option Name",
       t.modele                         "Data Model",
       CASE 
         WHEN t.typepro = 1 THEN 'CALL' 
         WHEN t.typepro = 2 THEN 'PUT' 
         ELSE 'UNKNOWN'
       END                              "Product Type",
       t.finper                         "Expiration Date",
       CASE
         WHEN t.debutper = '01-Jan-1904' THEN 'American'
         ELSE 'European'
       END                              "Exercise Style",
       t.prixexer                       "Strike",
       t.quotite                        "Contract Size",
       affectation.libelle              "Allotment Sophis",
       clause.valeur                    "Over or Fixed Volatility",
       t.modele                         "Data Model",
       fidlist.name                     "FID",
       ric.servisen                     "User Reference",
       EPC.value                        "Exchange Product Code",
       CUSIP.value                      "CUSIP",
       BBG_COMP.value                   "ID BB Company",
       BBG_UNI.value                    "ID BB Unique ID",
       'FALSE'                          "New Position",
       ULY.externref                    "Underlying ISIN"


FROM   titres t

left join titres ULY 
  ON t.codesj = ULY.sicovam
left join affectation 
  ON affectation.ident = t.affectation 
left join ric 
  ON ric.sicovam = t.sicovam 
left join fidlist 
   ON fidlist.item = ric.fid 
left join extrnl_references_instruments EPC 
  ON EPC.sophis_ident = t.sicovam 
     AND EPC.ref_ident = 25 
left join extrnl_references_instruments BBG_COMP 
  ON BBG_COMP.sophis_ident = t.sicovam 
     AND BBG_COMP.ref_ident = 673 
left join extrnl_references_instruments BBG_UNI 
  ON BBG_UNI.sophis_ident = t.sicovam 
     AND BBG_UNI.ref_ident = 674 
left join extrnl_ref_market_value 
  ON extrnl_ref_market_value.currency = t.devisectt 
     AND extrnl_ref_market_value.market = t.marche 
      AND extrnl_ref_market_value.ref_ident = 7 
left join clause 
  ON clause.sicovam = t.sicovam
left join extrnl_references_instruments CUSIP 
  ON CUSIP.sophis_ident = t.sicovam 
    AND CUSIP.ref_ident = 3 
                         
WHERE  t.affectation = 10 --Listed Options 
and ID_TO_CCYSYMBOL(t.devisectt) <> 'BRL'
AND t.sicovam in (

                  (
                  --List of sicovams modified in last 3 days
                  SELECT DISTINCT a.sicovam
                  FROM   btg_titres_audit a
                  left join btg_titres_audit prev
                  ON a.sicovam = prev.sicovam 
                    AND a.audit_version = prev.audit_version + 1 
                  WHERE (
                        a.typesj != prev.typesj Or (a.typesj IS NULL AND prev.typesj IS NOT NULL) OR  (a.typesj IS NOT NULL AND prev.typesj IS NULL)
                        OR a.devisectt != prev.devisectt Or (a.devisectt IS NULL AND prev.devisectt IS NOT NULL) OR  (a.devisectt IS NOT NULL AND prev.devisectt IS NULL) 
                        OR a.reference != prev.reference Or (a.reference IS NULL AND prev.reference IS NOT NULL) OR  (a.reference IS NOT NULL AND prev.reference IS NULL)
                        OR a.libelle != prev.libelle Or (a.libelle IS NULL AND prev.libelle IS NOT NULL) OR  (a.libelle IS NOT NULL AND prev.libelle IS NULL)
                        OR a.modele != prev.modele Or (a.modele IS NULL AND prev.modele IS NOT NULL) OR  (a.modele IS NOT NULL AND prev.modele IS NULL)
                        OR a.typepro != prev.typepro Or (a.typepro IS NULL AND prev.typepro IS NOT NULL) OR  (a.typepro IS NOT NULL AND prev.typepro IS NULL)
                        OR a.finper != prev.finper Or (a.finper IS NULL AND prev.finper IS NOT NULL) OR  (a.finper IS NOT NULL AND prev.finper IS NULL)
                        OR a.debutper != prev.debutper Or (a.debutper IS NULL AND prev.debutper IS NOT NULL) OR  (a.debutper IS NOT NULL AND prev.debutper IS NULL)
                        OR a.prixexer != prev.prixexer Or (a.prixexer IS NULL AND prev.prixexer IS NOT NULL) OR  (a.prixexer IS NOT NULL AND prev.prixexer IS NULL)
                        OR a.quotite != prev.quotite Or (a.quotite IS NULL AND prev.quotite IS NOT NULL) OR  (a.quotite IS NOT NULL AND prev.quotite IS NULL)
                        OR a.affectation != prev.affectation Or (a.affectation IS NULL AND prev.affectation IS NOT NULL) OR  (a.affectation IS NOT NULL AND prev.affectation IS NULL)
                        OR a.modele != prev.modele Or (a.modele IS NULL AND prev.modele IS NOT NULL) OR  (a.modele IS NOT NULL AND prev.modele IS NULL)
                  )
                  AND Trunc(a.audit_date) = Trunc(SYSDATE - 3) --3 days ago
                  --Changes in Ctrl + J (Infos)  
                  UNION
                  SELECT a.sicovam 
                  FROM   btg_audit_ric a 
                  WHERE  ( Nvl(a.new_servisen, '(null)') != Nvl(a.old_servisen, '(null)') ) 
                  AND Trunc(a.modification_day) = Trunc(SYSDATE - 3) --3 days ago
                  -- Changes in External References 
                  UNION 
                  SELECT DISTINCT ( sophis_ident ) 
                  FROM   btg_extrnl_ref_instr_audit 
                  WHERE  Trunc(audit_date) = Trunc(SYSDATE - 3) --3 days ago
                  AND ref_ident IN ( 25, 673, 674 )
                  )
                  
                  
                  MINUS
                    
                  (
                  --Instruments with positions opened in last 3 days
                      SELECT h.sicovam
                      FROM histomvts h
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate - 3) --3 days ago
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.sicovam
                      HAVING SUM(h.quantite) = 0 --no position
                    
                    INTERSECT

                      SELECT h.sicovam
                      FROM histomvts h                          
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate) --today
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.SICOVAM
                      HAVING SUM(h.quantite) <> 0 --open position
                  )           
)

UNION ALL

SELECT t.sicovam                        "Sicovam",
       ULY.reference                    "Underlying Reference",
       CASE 
         WHEN t.typesj = 2 THEN 'Physical Delivery' 
         WHEN t.typesj = 1 THEN 'New Share' 
         WHEN t.typesj = 8 THEN 'Market Delivery' 
         WHEN t.typesj = 3 THEN 'Cash' 
         WHEN t.typesj = 9 THEN 'Cash and Application' 
         WHEN t.typesj = 5 THEN 'Currency' 
         WHEN t.typesj = 7 THEN 'Future' 
         ELSE 'UNKNOWN'
       END                              "Payment Delivery",
       Devise_to_str (t.devisectt)      "Payment Currency",
       extrnl_ref_market_value.value    "MIC Code",
       t.reference                      "Option Reference",
       t.libelle                        "Option Name",
       t.modele                         "Data Model",
       CASE 
         WHEN t.typepro = 1 THEN 'CALL' 
         WHEN t.typepro = 2 THEN 'PUT' 
         ELSE 'UNKNOWN'
       END                              "Product Type",
       t.finper                         "Expiration Date",
       CASE
         WHEN t.debutper = '01-Jan-1904' THEN 'American'
         ELSE 'European'
       END                              "Exercise Style",
       t.prixexer                       "Strike",
       t.quotite                        "Contract Size",
       affectation.libelle              "Allotment Sophis",
       clause.valeur                    "Over or Fixed Volatility",
       t.modele                         "Data Model",
       fidlist.name                     "FID",
       ric.servisen                     "User Reference",
       EPC.value                        "Exchange Product Code",
       CUSIP.value                      "CUSIP",
       BBG_COMP.value                   "ID BB Company",
       BBG_UNI.value                    "ID BB Unique ID",
       'TRUE'                           "New Position",
       ULY.externref                    "Underlying ISIN"

FROM   titres t

left join titres ULY 
  ON t.codesj = ULY.sicovam
left join affectation 
  ON affectation.ident = t.affectation 
left join ric 
  ON ric.sicovam = t.sicovam 
left join fidlist 
   ON fidlist.item = ric.fid 
left join extrnl_references_instruments EPC 
  ON EPC.sophis_ident = t.sicovam 
     AND EPC.ref_ident = 25 
left join extrnl_references_instruments BBG_COMP 
  ON BBG_COMP.sophis_ident = t.sicovam 
     AND BBG_COMP.ref_ident = 673 
left join extrnl_references_instruments BBG_UNI 
  ON BBG_UNI.sophis_ident = t.sicovam 
     AND BBG_UNI.ref_ident = 674 
left join extrnl_ref_market_value 
  ON extrnl_ref_market_value.currency = t.devisectt 
     AND extrnl_ref_market_value.market = t.marche 
      AND extrnl_ref_market_value.ref_ident = 7 
left join clause 
  ON clause.sicovam = t.sicovam
left join extrnl_references_instruments CUSIP 
  ON CUSIP.sophis_ident = t.sicovam 
    AND CUSIP.ref_ident = 3 
                         
WHERE  t.affectation = 10 --Listed Options 
and ID_TO_CCYSYMBOL(t.devisectt) <> 'BRL'
AND t.sicovam in (
                  --Instruments with positions opened in last 3 days
                      SELECT h.sicovam
                      FROM histomvts h
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate - 3) --3 days ago
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.sicovam
                      HAVING SUM(h.quantite) = 0 --no position
                    
                    INTERSECT

                      SELECT h.sicovam
                      FROM histomvts h                          
                      INNER JOIN BUSINESS_EVENTS
                        ON BUSINESS_EVENTS.id = h.type
                          AND BUSINESS_EVENTS.compta = 1
                      INNER JOIN ( 
                                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                                          , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                                          , FOLIO.ident                                                             AS STRATEGY_ID
                                          , FOLIO.name                                                              AS STRATEGY_NAME
                                          , level
                                      FROM        FOLIO
                                      WHERE       LEVEL >= 4
                                      START       WITH FOLIO.ident    IN (14414,90565)
                                      CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                                  ) FUND_BOOK_STRATEGY
                        ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
                      WHERE h.dateneg <= trunc(sysdate) --today
                      AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --Exclude cancelled trades
                      GROUP BY h.SICOVAM
                      HAVING SUM(h.quantite) <> 0 --open position
)
ORDER BY "Underlying Reference", "Option Reference";


END DASH_REPORTS_LISTED_OPT_MOD_T3;

-- *****************************************************************
-- Description: PROCEDURE DASH_REPORTS_DIVIDEND 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 09 AUG 2016      PMOG-1030
-- *****************************************************************
  PROCEDURE DASH_REPORTS_DIVIDEND
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: DASH_REPORTS_DIVIDEND
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
select 				 t.reference 				REFERENCE
					,h.sicovam 					INTERNAL_ID
					,a.libelle 					ALLOTMENT
					,DEVISE_TO_STR(t.DEVISECTT) INSTRUMENT_CURRENCY
					,devise_to_str(d.currency) 	DIVIDEND_CURRENCY
					,CASE d.dateexdiv  
						WHEN TO_DATE('01-JAN-1904') THEN d.datediv
						ELSE d.dateexdiv
					END 						EX_DIV_DATE
					,d.infos AS 				"COMMENT"
					,d.DATEPAYE 				PAYABLE_DATE
					,d.VALEUR 					DIVIDEND_AMOUNT
					,d.AVOIR_FISCAL 			DIVIDEND_TYPE_CODE
					,CASE d.avoir_fiscal
						WHEN 1 THEN 'Dividend or coupon'
						WHEN 2 THEN 'Tax credit'
						WHEN 3 THEN 'Optional dividend'
						WHEN 11 THEN 'Exceptional dividend'
						WHEN 12 THEN 'Exceptional tax credit'
						WHEN 13 THEN 'Exceptional optional'
						WHEN 21 THEN 'Cyclical dividend or coupon'
						WHEN 22 THEN 'Cyclical tax credit'
						WHEN 23 THEN 'Cyclical optional dividend'
						ELSE 'Unknown'
					END 						DIVIDEND_TYPE_DESCRIPTION
      
from histomvts h

left join titres t
  on h.sicovam = t.sicovam
  
left join affectation a
  on t.affectation = a.IDENT
  
INNER JOIN BUSINESS_EVENTS
  ON BUSINESS_EVENTS.id = h.type
    AND BUSINESS_EVENTS.compta = 1 --position affecting trades only
  
INNER JOIN ( 
              SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                    , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                    , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                    , FOLIO.ident                                                             AS STRATEGY_ID
                    , FOLIO.name                                                              AS STRATEGY_NAME
                    , level
                FROM        FOLIO
                WHERE       LEVEL >= 4
                START       WITH FOLIO.ident    IN (14414,90565)
                CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
            ) FUND_BOOK_STRATEGY
  ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM

left join DIVIDENDE d
  on h.sicovam = d.sicovam
    
WHERE h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --exclude cancelled trades
and  (
        (t.type in ('G', 'D', 'F') AND t.code_emet in (select t1.sicovam from titres t1 where t1.type = 'A'))
        OR 
        (t.codesj in (select t2.sicovam from titres t2 where type = 'A'))
        OR 
        (t.type = 'A') --Share
      )

and d.dateexdiv >= sysdate --today or later
and d.dateexdiv <= sysdate + 30 --5 days from now

group by t.reference
      ,h.sicovam
      ,a.libelle
      ,DEVISE_TO_STR(t.DEVISECTT)
      ,devise_to_str(d.currency)
      ,CASE d.dateexdiv
        WHEN TO_DATE('01-JAN-1904') THEN d.datediv
        ELSE d.dateexdiv
      END
      ,d.infos
      ,d.DATEPAYE
      ,d.VALEUR
      ,d.AVOIR_FISCAL
      ,CASE d.avoir_fiscal
        WHEN 1 THEN 'Dividend or coupon'
        WHEN 2 THEN 'Tax credit'
        WHEN 3 THEN 'Optional dividend'
        WHEN 11 THEN 'Exceptional dividend'
        WHEN 12 THEN 'Exceptional tax credit'
        WHEN 13 THEN 'Exceptional optional'
        WHEN 21 THEN 'Cyclical dividend or coupon'
        WHEN 22 THEN 'Cyclical tax credit'
        WHEN 23 THEN 'Cyclical optional dividend'
        ELSE 'Unknown'
      END

having sum(h.quantite) <> 0

order by reference, ex_div_date asc;  
    
  -- *****************************************************************
  -- END OF: DASH_REPORTS_DIVIDEND
  -- *****************************************************************   
	END DASH_REPORTS_DIVIDEND; 

-- *****************************************************************
-- Description: PROCEDURE WM_EXPIRY 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 09 SEP 2016      PMOG-1041
-- 08 FEB 2017		PMOG-1093
-- *****************************************************************
  PROCEDURE WM_EXPIRY
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: WM_EXPIRY
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
SELECT      
                  CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END                                                           d$Expiry
                  , CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END                                                           Instrument_Type
                , FUND_BOOK_STRATEGY.Fund_NAME                                  Client
                , PB.NAME                                 Account
                , TITRES.REFERENCE												Reference
                , TITRES.libelle											    Instrument_Name
                , SUM(HISTOMVTS.quantite)                                       Quantity
				, ROUND(SUM(HISTOMVTS.QUANTITE * NVL(TITRES.nominal,1)),6)		Notional
                , HISTOMVTS.sicovam                                             Sicovam
                , CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                                           Delivery_type
FROM            HISTOMVTS
INNER JOIN ( 
                SELECT  
                        REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)  AS Fund_NAME
                      , FOLIO.ident                                                         AS STRATEGY_ID
                      , level
                FROM FOLIO
                WHERE LEVEL >= 1
                START WITH FOLIO.ident IN (130481) --WM FOLIO
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr  
              )    FUND_BOOK_STRATEGY
ON             FUND_BOOK_STRATEGY.STRATEGY_ID     =  histomvts.OPCVM
INNER JOIN  TITRES
ON          TITRES.sicovam          = HISTOMVTS.sicovam
INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.id = HISTOMVTS.type
LEFT JOIN   AFFECTATION
ON          AFFECTATION.ident = TITRES.affectation
LEFT JOIN   TIERS PB
ON          PB.IDENT = HISTOMVTS.DEPOSITAIRE
WHERE       
          HISTOMVTS.backoffice not in (192,11,13,17,26,27,220,248,252) --cancelled trades
AND       BUSINESS_EVENTS.compta = 1 --position trades only
AND       (
            (TITRES.type = 'S' and trunc(TITRES.DATEFINAL) >= trunc(sysdate) and trunc(TITRES.DATEFINAL) <= btg_business_date(trunc(sysdate),5)) --swaps
            OR
            (TITRES.type in  ('O','D') and TITRES.FINPER >= trunc(sysdate) and TITRES.FINPER <= btg_business_date(trunc(sysdate),5)) --Bonds/Options
            OR 
            (TITRES.type in ('M','F','N') and TITRES.ECHEANCE >= trunc(sysdate) and TITRES.ECHEANCE <= btg_business_date(trunc(sysdate),5)) --OTC Stock derivatives
            OR
            (TITRES.type = 'F' and TITRES.EXSOC >= trunc(sysdate) and TITRES.EXSOC <= btg_business_date(trunc(sysdate),5) and TITRES.affectation!=63) --Futures not FRA
            OR
            (TITRES.type = 'K' and HISTOMVTS.dateval >= trunc(sysdate) and HISTOMVTS.dateval <= btg_business_date(trunc(sysdate),5)) --NDF
          )
GROUP BY CASE
                        WHEN TITRES.type = 'S' THEN TITRES.DATEFINAL
                        WHEN TITRES.type IN  ('O','D','L') THEN TITRES.FINPER
                        WHEN TITRES.type IN ('M','F','N') THEN TITRES.ECHEANCE
                        WHEN TITRES.type = 'K' THEN histomvts.dateval
                        ELSE TRUNC(SYSDATE)-500
                  END, CASE
                        WHEN TITRES.type = 'K' THEN 'NDF'
                        ELSE AFFECTATION.libelle                  
                  END, FUND_BOOK_STRATEGY.Fund_NAME, TITRES.REFERENCE, TITRES.libelle, HISTOMVTS.sicovam, PB.NAME, CASE
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 4 THEN 'Cash' --For futures
                      WHEN TITRES.type = 'F' AND TITRES.TAUX_VAR = 1 THEN 'Physical' --For futures
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 0 THEN 'Physical' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 1 THEN 'New Share' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 2 THEN 'Market Delivery' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 3 THEN 'Cash' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 4 THEN 'Cash and Application' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 5 THEN 'Currency' --For options
                      WHEN TITRES.type = 'D' AND TITRES.typesj = 6 THEN 'Future' --For options
                      ELSE ''
                  END                                 
HAVING SUM(HISTOMVTS.quantite) !=0
ORDER BY 1,6,3;
  -- *****************************************************************
  -- END OF: WM_EXPIRY
  -- *****************************************************************   
	END WM_EXPIRY; 

-- *****************************************************************
-- Description: PROCEDURE ALL_FUTURE_INSTRUMENTS 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 27 SEP 2016      PMOF-240
-- *****************************************************************
  PROCEDURE ALL_FUTURE_INSTRUMENTS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: ALL_FUTURE_INSTRUMENTS
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
SELECT 
DISTINCT
					  SEC.SICOVAM                                             SICOVAM
					, SEC.REFERENCE                                           REFERENCE
					, SEC.LIBELLE	                                          INSTRUMENT_NAME                
					, SEC.ECHEANCE                                            EXPIRY
					, DEVISE_TO_STR(SEC.DEVISECTT)                            CURRENCY
					, BTG_GET_UNDERLYING_REFERENCE(SEC.SICOVAM)               UNDERLYING
					, SEC.QUOTITE                                             CONTRACT_SIZE
					, CASE
					      WHEN SEC.TAUX_VAR = 4 THEN 'Cash'
					      WHEN SEC.TAUX_VAR = 1 THEN 'Physical'
					      ELSE ''
					   END                                                    DELIVERY_TYPE
					, CASE 
					      WHEN OPEN_POSITION.SICOVAM IS NOT NULL THEN 'Open'
					      ELSE 'Closed'
					  END                                                     OPEN_POSITION
from TITRES SEC
LEFT JOIN
(
					SELECT
					HISTOMVTS.ENTITE ENTITE,
					FUND_BOOK_STRATEGY.BOOK_ID BOOK_ID,
					HISTOMVTS.SICOVAM SICOVAM
					 
					FROM HISTOMVTS 
					 
					INNER JOIN (
					                            SELECT 
					                            CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
					                          , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
					                          , FOLIO.ident AS STRATEGY_ID
					                          , FOLIO.name AS STRATEGY_NAME
					                          , level
					                  FROM FOLIO
					                  WHERE LEVEL >= 4
					                  --START WITH FOLIO.ident IN (14414)--Primary funds
					                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
					                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
					                ) FUND_BOOK_STRATEGY
					ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
					
					INNER JOIN BUSINESS_EVENTS
					ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
					AND BUSINESS_EVENTS.COMPTA = 1
					 
					INNER JOIN TITRES SEC
					ON SEC.SICOVAM = HISTOMVTS.SICOVAM
					 
					WHERE
					HISTOMVTS.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
					GROUP BY 
					HISTOMVTS.ENTITE ,
					FUND_BOOK_STRATEGY.BOOK_ID,
					HISTOMVTS.SICOVAM ,
					SEC.TYPE
					HAVING 
					ROUND(sum(HISTOMVTS.QUANTITE),6) <> 0 AND SEC.TYPE = 'F'
) OPEN_POSITION
ON SEC.SICOVAM = OPEN_POSITION.SICOVAM
WHERE 
SEC.TYPE = 'F'
ORDER BY 2;
  -- *****************************************************************
  -- END OF: ALL_FUTURE_INSTRUMENTS
  -- *****************************************************************   
	END ALL_FUTURE_INSTRUMENTS; 

-- *****************************************************************
-- Description: PROCEDURE ACTIVE_FUTURES 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 27 SEP 2016      PMOF-240
-- *****************************************************************
  PROCEDURE ACTIVE_FUTURES
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: ACTIVE_FUTURES
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
SELECT 
DISTINCT
					  SEC.SICOVAM                                             SICOVAM
					, SEC.REFERENCE                                           REFERENCE
					, SEC.LIBELLE	                                          INSTRUMENT_NAME                
					, SEC.ECHEANCE                                            EXPIRY
					, DEVISE_TO_STR(SEC.DEVISECTT)                            CURRENCY
					, BTG_GET_UNDERLYING_REFERENCE(SEC.SICOVAM)               UNDERLYING
					, SEC.QUOTITE                                             CONTRACT_SIZE
					, CASE
					      WHEN SEC.TAUX_VAR = 4 THEN 'Cash'
					      WHEN SEC.TAUX_VAR = 1 THEN 'Physical'
					      ELSE ''
					   END                                                    DELIVERY_TYPE
					, CASE 
					      WHEN open_position.SICOVAM IS NOT NULL THEN 'Open'
					      ELSE 'Closed'
					  END                                                     OPEN_POSITION
FROM TITRES SEC
LEFT JOIN   titres Underlying1
      ON Underlying1.sicovam = 
      case when Sec.type='A' then Sec.base1 
      when Sec.type='D' then Sec.codesj      
      when Sec.type='B' then Sec.taux_var   
      when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
LEFT JOIN HISTOMVTS TRADES
ON TRADES.SICOVAM = SEC.SICOVAM
AND TRADES.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
AND TRUNC(TRADES.DATENEG) >= TRUNC(SYSDATE-30)
LEFT JOIN
(
					SELECT
					HISTOMVTS.ENTITE ENTITE,
					FUND_BOOK_STRATEGY.BOOK_ID BOOK_ID,
					HISTOMVTS.SICOVAM SICOVAM
					 
					from HISTOMVTS 
					 
					INNER JOIN (
					                            SELECT 
					                            CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
					                          , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2) AS Fund_NAME
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4) AS BOOK_ID
					                          , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4) AS BOOK_NAME
					                          , FOLIO.ident AS STRATEGY_ID
					                          , FOLIO.name AS STRATEGY_NAME
					                          , level
					                  FROM FOLIO
					                  WHERE LEVEL >= 4
					                  --START WITH FOLIO.ident IN (14414)--Primary funds
					                  START WITH FOLIO.ident IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_UCITS_FUND)--Primary funds
					                  CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
					                ) FUND_BOOK_STRATEGY
					ON FUND_BOOK_STRATEGY.STRATEGY_ID = HISTOMVTS.OPCVM
					
					INNER JOIN BUSINESS_EVENTS
					ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
					AND BUSINESS_EVENTS.COMPTA = 1
					 
					INNER JOIN TITRES SEC
					ON SEC.SICOVAM = HISTOMVTS.SICOVAM
					 
					LEFT JOIN   titres Underlying1
					      ON Underlying1.sicovam = 
					      case when Sec.type='A' then Sec.base1 
					      when Sec.type='D' then Sec.codesj      
					      when Sec.type='B' then Sec.taux_var   
					      when Sec.type='S' then decode(Sec.jambe1,1,Sec.j2refcon2,decode(Sec.j1refcon2,0,Sec.j2refcon2,Sec.j1refcon2)) else decode(Sec.code_emet,0,decode(Sec.codesj,0,Sec.codesj2,Sec.codesj),Sec.code_emet) end 
					 
					where
					HISTOMVTS.BACKOFFICE NOT IN (192,11,13,17,26,27,220,248,252)
					GROUP BY 
					HISTOMVTS.ENTITE ,
					FUND_BOOK_STRATEGY.BOOK_ID,
					HISTOMVTS.SICOVAM ,
					SEC.TYPE,
					UNDERLYING1.TYPE
					HAVING 
					ROUND(SUM(HISTOMVTS.QUANTITE),6) <> 0 AND (SEC.TYPE = 'F' OR UNDERLYING1.TYPE = 'F')
) OPEN_POSITION
ON SEC.SICOVAM = OPEN_POSITION.SICOVAM
WHERE 
(SEC.TYPE = 'F' OR UNDERLYING1.TYPE = 'F')
AND
(OPEN_POSITION.SICOVAM IS NOT NULL OR TRADES.SICOVAM IS NOT NULL)
ORDER BY 2;
  -- *****************************************************************
  -- END OF: ACTIVE_FUTURES
  -- *****************************************************************   
	END ACTIVE_FUTURES;

-- *****************************************************************
-- Description: PROCEDURE EMLATAMRATES_MXN_AUTOTICKETS 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 14 DEC 2016      PMOG-1067
-- 05 JAN 2018       PMGMPMO-253
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE EMLATAMRATES_MXN_AUTOTICKETS
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: EMLATAMRATES_MXN_AUTOTICKETS
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
           
            
SELECT      FUND_BOOK_STRATEGY.Fund_NAME                                             Fund
          , FUND_BOOK_STRATEGY.BOOK_NAME                                             Strategy
          , MVT_AUTO.dateneg                                                         Trade_Date
          , MVT_AUTO.dateval                                                         Value_Date
          , TITRES.Sicovam                                                           Sicovam
          , TITRES.libelle                                                           Name
          , TITRES.reference                                                         Reference 
          , MVT_AUTO.montant                                                         Net_Amount
          , BUSINESS_EVENTS.NAME                                                     Business_Event
          , devise_to_str(MVT_AUTO.devisepay)                                        Currency
          , TIERS.name                                                               Counterparty

FROM        MVT_AUTO

INNER JOIN  TIERS
ON          TIERS.ident                        = MVT_AUTO.contrepartie

INNER JOIN  TITRES
ON          TITRES.sicovam                          = MVT_AUTO.sicovam

INNER JOIN  BUSINESS_EVENTS
ON          BUSINESS_EVENTS.ID                        = MVT_AUTO.TYPE

INNER JOIN ( 
                SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                      , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                      , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                      , FOLIO.ident                                                             AS STRATEGY_ID
                      , FOLIO.name                                                              AS STRATEGY_NAME
                      , level
                  FROM        FOLIO
                  WHERE       LEVEL >= 4
                  START       WITH FOLIO.ident    IN (PCKG_BTG.FOLIO_PRIMARY_FUNDS, PCKG_BTG.FOLIO_SECUNDARY_FUNDS,PCKG_BTG.FOLIO_UCITS_FUND) --(14414,14405,90565) 
                  CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                ) FUND_BOOK_STRATEGY
ON            FUND_BOOK_STRATEGY.STRATEGY_ID          = MVT_AUTO.OPCVM

WHERE FUND_BOOK_STRATEGY.BOOK_NAME LIKE '%EM (Latam) Rates%'
AND MVT_AUTO.devisepay  = 55400526 --MXN Currency
order by  MVT_AUTO.dateval,  TITRES.Sicovam ,  FUND_BOOK_STRATEGY.Fund_NAME    
; 
  -- *****************************************************************
  -- END OF: EMLATAMRATES_MXN_AUTOTICKETS
  -- *****************************************************************   
	END EMLATAMRATES_MXN_AUTOTICKETS; 


-- *****************************************************************
-- Description: PROCEDURE CPTY_REGION_TRADE_VOL 
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 06 SEP 2017      PMOG-1135   Created by Jeff Yu
--20 JUN 2018     PMGMRISK-228   Modified by Jeff Yu (Add new business event)
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE CPTY_REGION_TRADE_VOL
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: CPTY_REGION_TRADE_VOL
  -- *****************************************************************  
		OPEN p_CURSOR FOR
    
select distinct tiers.ident as "Internal Code"
,tiers.name as "Counterparty Name"
,tiers.reference
,tiers.externref as "GCE Code"
,UK_LIST.CNT as "UK Listed"
,UK_OTC.CNT as "UK OTC"
,US_LIST.CNT as "US Listed"
,US_OTC.CNT as "US OTC"
,BR_LIST.CNT as "BR Listed"
,BR_OTC.CNT as "BR OTC"
from tiers
---UK OTC---
left join (
select cpty.ident,cpty.name,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
left join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
left join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name like '%OTC%' 
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'UK'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident,cpty.name
) UK_OTC
on UK_OTC.ident=TIERS.IDENT
----UK List---
left join (
select cpty.ident,cpty.name,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
inner join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
inner join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name not like '%OTC%'
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'UK'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident,cpty.name
) UK_List
on UK_List.ident=TIERS.IDENT
---US OTC----
LEFT join (
select cpty.ident,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
inner join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
inner join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name like '%OTC%' 
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'US'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident
) US_OTC
on US_OTC.ident=TIERS.IDENT
--US List---
LEFT join (
select cpty.ident,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
inner join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
inner join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name not like '%OTC%'
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'US'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident
) US_List
on US_List.ident=TIERS.IDENT
---Brazil OTC----
LEFT join (
select cpty.ident,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
inner join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
inner join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name like '%OTC%' 
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'BRAZIL'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident
) BR_OTC
on BR_OTC.ident=TIERS.IDENT
--BRAZIL List---
LEFT join (
select cpty.ident,count(refcon) as cnt
from histomvts
inner join (
SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID
                                      ,CONNECT_BY_ROOT(FOLIO.NAME) AS TOP_FUND_NAME
                                      ,REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2) AS FUND_ID
                                      ,FOLIO.ident AS STRATEGY_ID
                                      ,LEVEL
                                FROM FOLIO
                                WHERE LEVEL >= 2 
                                START WITH FOLIO.ident IN (14414,14405,90565)
                                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr
) STRATEGY
ON STRATEGY.STRATEGY_ID=histomvts.OPCVM
inner join tiers cpty
on histomvts.CONTREPARTIE=cpty.ident
left join tiers cp_mgr
on cpty.mgr=cp_mgr.ident
inner join tiers depo
on histomvts.DEPOSITAIRE=depo.ident
left join tiers mgr
on depo.mgr=mgr.ident
LEFT JOIN     userinfos
ON        userinfos.ident    =  histomvts.OPERATEUR
where cp_mgr.ident=10007662
and depo.name not like '%OTC%'
and mgr.ident != 10025790 --exclude GEMM Inactive depos
and USERINFOS.COUNTRY = 'BRAZIL'
and histomvts.type in (250,6,190,241,243,25,17,247,240,796,242,1094,1,444,140,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
and trunc(dateneg) >=add_months(trunc(sysdate),-3) --past 3 months--
group by cpty.ident
) BR_List
on BR_List.ident=TIERS.IDENT
where tiers.ident is not null
and not (UK_LIST.CNT is null and UK_OTC.CNT is null and US_LIST.CNT is null and US_OTC.CNT is null and BR_LIST.CNT is null and BR_OTC.CNT is null)
order by tiers.name;           
 
  -- *****************************************************************
  -- END OF: CPTY_REGION_TRADE_VOL
  -- *****************************************************************   
	END CPTY_REGION_TRADE_VOL; 



-- *****************************************************************
-- Description: PROCEDURE TRADE_VOL_ELECTRA
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 10 NOV 2017      PMOG-1162   Created by Jeff Yu
--20 JUN 2018     PMGMRISK-228   Modified by Jeff Yu (Add new business event)
-- *****************************************************************
  PROCEDURE TRADE_VOL_ELECTRA
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: TRADE_VOL_ELECTRA
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select distinct histomvts.DATENEG   as  d$Trade_Date
,GEMM.cnt as GEMM
,ARF.cnt AS ARF
,ARF2.cnt AS ARF2
,GDO.cnt AS GDO
,RATES.cnt AS RATES
,INTB.cnt AS INTB
from histomvts
left join
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10003512
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GEMM
on histomvts.dateneg=GEMM.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10003506
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF
on histomvts.dateneg=ARF.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10003503
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF2
on histomvts.dateneg=ARF2.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10026005
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GDO
on histomvts.dateneg=GDO.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10010267
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) RATES
on histomvts.dateneg=RATES.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
where histomvts.entite = 10010750
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) INTB
on histomvts.dateneg=INTB.dateneg
where histomvts.DATENEG >= add_months(trunc(sysdate),-3)
and histomvts.DATENEG <= trunc(sysdate)
order by histomvts.dateneg desc;
 
  -- *****************************************************************
  -- END OF: TRADE_VOL_ELECTRA
  -- *****************************************************************   
	END TRADE_VOL_ELECTRA; 


-- *****************************************************************
-- Description: PROCEDURE TRADE_VOL_TRIRESOLVE
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 10 NOV 2017      PMOG-1162   Created by Jeff Yu
--20 JUN 2018     PMGMRISK-228   Modified by Jeff Yu (Add new business event)
-- *****************************************************************
  PROCEDURE TRADE_VOL_TRIRESOLVE
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: TRADE_VOL_TRIRESOLVE
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select distinct histomvts.DATENEG    as   d$Trade_Date
,GEMM.cnt as GEMM
,ARF.cnt AS ARF
,ARF2.cnt AS ARF2
,GDO.cnt AS GDO
,RATES.cnt AS RATES
,INTB.cnt AS INTB
from histomvts
left join
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003512
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GEMM
on histomvts.dateneg=GEMM.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003506
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF
on histomvts.dateneg=ARF.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003503
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF2
on histomvts.dateneg=ARF2.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10026005
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GDO
on histomvts.dateneg=GDO.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10010267
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) RATES
on histomvts.dateneg=RATES.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10010750
and affectation in (22,1250,1101,27,50,24,2,14,3,31,16,1080)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) INTB
on histomvts.dateneg=INTB.dateneg
where histomvts.DATENEG >= add_months(trunc(sysdate),-6)
and histomvts.DATENEG <= trunc(sysdate)
order by histomvts.dateneg desc;

 -- *****************************************************************
  -- END OF: TRADE_VOL_TRIRESOLVE
  -- *****************************************************************   
	END TRADE_VOL_TRIRESOLVE; 


-- *****************************************************************
-- Description: PROCEDURE TRADE_VOL_MTM
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 10 NOV 2017      PMOG-1162   Created by Jeff Yu
--20 JUN 2018     PMGMRISK-228   Modified by Jeff Yu (Add new business event)
-- *****************************************************************
  PROCEDURE TRADE_VOL_MTM
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: TRADE_VOL_MTM
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select distinct histomvts.DATENEG   as  d$Trade_Date
,GEMM.cnt as GEMM
,ARF.cnt AS ARF
,ARF2.cnt AS ARF2
,GDO.cnt AS GDO
,RATES.cnt AS RATES
,INTB.cnt AS INTB
from histomvts
left join
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003512
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GEMM
on histomvts.dateneg=GEMM.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003506
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF
on histomvts.dateneg=ARF.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10003503
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) ARF2
on histomvts.dateneg=ARF2.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10026005
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) GDO
on histomvts.dateneg=GDO.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10010267
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) RATES
on histomvts.dateneg=RATES.dateneg
LEFT JOIN
(
select DATENEG, count(distinct refcon) as cnt
from histomvts
inner join titres
on histomvts.sicovam=titres.sicovam
where histomvts.entite = 10010750
and affectation in (1101,24,31,16)
and histomvts.type in (1,6,17,25,99,160,190,24,241,242,243,247,250,294,344,444,794,796,1094,1394,1444,1494)
and backoffice not in (192,11,13,17,26,27,220,248,252)
group by DATENEG
) INTB
on histomvts.dateneg=INTB.dateneg
where histomvts.DATENEG >= add_months(trunc(sysdate),-6)
and histomvts.DATENEG <= trunc(sysdate)
order by histomvts.dateneg desc;

-- *****************************************************************
  -- END OF: TRADE_VOL_MTM
  -- *****************************************************************   
	END TRADE_VOL_MTM; 


-- *****************************************************************
-- Description: PROCEDURE US_IPO_CHECK
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 1 DEC 2017      PMOG-1173   Created by Jeff Yu
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE US_IPO_CHECK
	(
     p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: US_IPO_CHECK
  -- *****************************************************************  
		OPEN p_CURSOR FOR

SELECT  DISTINCT    
              trades.refcon                       Trade_ID
            , FUND_BOOK_STRATEGY.Fund_NAME            Fund
            , FUND_BOOK_STRATEGY.BOOK_NAME            Strategy
            , trades.dateneg            Trade_Date
            , trades.dateval                Value_Date
            , CASE WHEN QUANTITE < 0 THEN 'S'
            else 'B' END AS "Buy/Sell"
            , TITRES.reference          as  security_reference                  
            , TITRES.libelle                as   security_name
            , EX.VALUE    as cusip
            , QUANTITE as quantity
            , cours as price
            , fraiscourtage  as broker_fee
            , DEVISE_TO_STR(DEVISEPAY) AS PAYMENT_CURRENCY
            , TIERS.NAME  as broker
            , BUSINESS_EVENTS.name                    Business_Event
            , BO.NAME    as  status
            , trader.name   as trader

    FROM      HISTOMVTS  trades
    INNER JOIN ( 
                    SELECT CONNECT_BY_ROOT(FOLIO.ident)                                              AS TOP_FUND_ID
                            , CONNECT_BY_ROOT(FOLIO.name)                                            AS TOP_FUND_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)    AS FUND_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)     AS Fund_NAME
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)    AS BOOK_ID
                            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)     AS BOOK_NAME
                            , FOLIO.ident                                                            AS STRATEGY_ID
                            , FOLIO.name                                                             AS STRATEGY_NAME
                            , level
                            FROM FOLIO
                            WHERE LEVEL >= 2
                            START WITH FOLIO.ident           IN (14414,90565)--Primary funds
                            CONNECT BY PRIOR     FOLIO.ident = FOLIO.mgr  
                  ) FUND_BOOK_STRATEGY
    ON            FUND_BOOK_STRATEGY.STRATEGY_ID = trades.OPCVM
    INNER JOIN    TITRES
    ON            TITRES.sicovam  = trades.sicovam
    INNER JOIN    BUSINESS_EVENTS
    ON            BUSINESS_EVENTS.id  = trades.type
    AND           BUSINESS_EVENTS.compta = 1 --position affecting tickets only
    LEFT JOIN TIERS
    ON TIERS.IDENT = trades.COURTIER
    LEFT JOIN BO_KERNEL_STATUS BO
    ON BO.id = trades.backoffice
    LEFT JOIN EXTRNL_REFERENCES_INSTRUMENTS EX
    ON EX.sophis_ident = titres.sicovam
    AND EX.REF_IDENT = 3   -----Cusip
    LEFT JOIN    RISKUSERS  trader  
    ON   trader.ident = trades.operateur
    
    WHERE        (titres.reference like '%US Equity%'
                     or titres.reference like '%UN Equity%'
                     or titres.reference like '%UQ Equity%'
                     or titres.reference like '%UW Equity%')                             
    AND           trunc(trades.dateneg) >= trunc(sysdate) - 30
 ORDER BY trades.dateneg desc, TITRES.reference;

-- *****************************************************************
  -- END OF: US_IPO_CHECK
  -- *****************************************************************   
	END US_IPO_CHECK; 


-- *****************************************************************
-- Description: PROCEDURE BOOKED_ALLOC_BY_OPS
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 22 JUN 2018      PMOG-1172    Created by Jeff Yu
-- *****************************************************************
  PROCEDURE BOOKED_ALLOC_BY_OPS
	(
     REGION1 	IN	 VARCHAR2 default NULL
   , REGION2 	IN	 VARCHAR2 default NULL
   , p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: BOOKED_ALLOC_BY_OPS
  -- *****************************************************************  
		OPEN p_CURSOR FOR

 select execution_book
 , "Strategy/Trader Book"
 , sicovam
 , parent_id
 , reference
 , allotment
 , trade_date
 , value_date
 , business_event
 , counterparty
 , trader
 , operator
 , creation_type
 , listagg(pool.type, ';') within group (order by pool.type desc) as exception_type
 
 from (
 SELECT  DISTINCT    

           entity.name  as  execution_book
           ,mgr.name  as  "Strategy/Trader Book"
            ,trades.sicovam                       Sicovam
            , trades.refcon                       parent_id
            , TITRES.reference                        
            , nvl(AFFECTATION.LIBELLE, BTG_GET_INSTRUMENT_TYPE(titres.SICOVAM))   as allotment
            , TRUNC(trades.dateneg)                Trade_Date
            , TRUNC(trades.dateval)                Value_Date
            , BUSINESS_EVENTS.name                    Business_Event
            , ctpy.NAME    as  counterparty
            , operator.name  as   trader
            , entryby.name      as  operator
            , case when trades.creation = 0 then 'Manual'
                      when trades.creation = 1 then 'Automatic'
                      when trades.creation = 2 then 'Electronic'
              else 'Others'  end as creation_type                           
            , 'Booked by Ops'  as type
            
    FROM      HISTOMVTS  trades
    INNER JOIN   AUDIT_MVT
    ON trades.REFCON=AUDIT_MVT.refcon
    AND AUDIT_MVT.state=1 ----create
    INNER JOIN    BUSINESS_EVENTS
    ON            BUSINESS_EVENTS.id  = trades.type
    AND           BUSINESS_EVENTS.compta = 1 
    INNER JOIN    RISKUSERS  entryby   ----------Trades entered by Ops
    ON            entryby.ident = AUDIT_MVT.userid
    AND          entryby.gident = 4572 --Trader name in OPERATIONS_TD group
    AND          AUDIT_MVT.userid  NOT IN (2707, 1889, 2928, 12816) --Joe Ilardi, Bill Rose (wrose), Marcos Flaks, Rafael Rocha
    INNER JOIN    USERINFOS
    ON            USERINFOS.ident = AUDIT_MVT.userid
    INNER JOIN    TITRES
    ON            TITRES.sicovam  = trades.sicovam
    LEFT JOIN  TIERS ctpy
    ON   ctpy.ident=trades.CONTREPARTIE
     LEFT JOIN  TIERS entity
    ON   entity.ident=trades.entite
    LEFT JOIN   AFFECTATION
    ON   AFFECTATION.IDENT=TITRES.AFFECTATION
    LEFT JOIN  RISKUSERS  operator   --------operator name shown in ticket
    ON    operator.ident = AUDIT_MVT.operateur
    INNER JOIN TA_BLOCK_TO_GENERATED TA
    ON  TA.BLOCK_ID = trades.refcon
    LEFT JOIN FOLIO
    ON FOLIO.IDENT=trades.opcvm
   LEFT JOIN FOLIO mgr
    ON mgr.IDENT=FOLIO.mgr

    WHERE     trades.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND           trades.type IN (1,294,247,250,1444,1494) 
    AND          USERINFOS.country in (REGION1,REGION2)
    AND           trunc(trades.dateneg) >= add_months(trunc(sysdate),-1)
  
    UNION
    
    SELECT        distinct
              entity.name as execution_book
            ,mgr.name  as "Strategy/Trader Book"
            , titres.Sicovam
            , histomvts.refcon   as  parent_id
            , titres.reference
            , nvl(AFFECTATION.LIBELLE, BTG_GET_INSTRUMENT_TYPE(titres.SICOVAM))   as allotment
            , TRUNC(HISTOMVTS.dateneg)                Trade_Date
            , TRUNC(HISTOMVTS.dateval)                Value_Date
            , BUSINESS_EVENTS.name                    Business_Event
            , ctpy.NAME    as  counterparty
            , trader.name     trader
            , RISKUSERS.name             operator
            , case when HISTOMVTS.creation = 0 then 'Manual'
                      when HISTOMVTS.creation = 1 then 'Automatic'
                      when HISTOMVTS.creation = 2 then 'Electronic'
              else 'Others'  end as creation_type     
            , 'Allocated by Ops'      as type
               
    FROM      AUDIT_MVT 
    INNER JOIN   HISTOMVTS
    ON HISTOMVTS.REFCON=AUDIT_MVT.refcon
    INNER JOIN    BUSINESS_EVENTS
    ON            BUSINESS_EVENTS.id  = HISTOMVTS.type
    AND          BUSINESS_EVENTS.compta = 1 
    INNER JOIN    RISKUSERS   
    ON            RISKUSERS.ident = AUDIT_MVT.userid
    AND          RISKUSERS.gident = 4572 --allocator name in OPERATIONS_TD group
    AND          AUDIT_MVT.userid NOT IN (2707, 1889, 2928, 12816) --Joe Ilardi, Bill Rose (wrose), Marcos Flaks, Rafael Rocha
    INNER JOIN    USERINFOS 
    ON            USERINFOS.ident = AUDIT_MVT.userid
    INNER JOIN    TITRES
    ON            TITRES.sicovam  = HISTOMVTS.sicovam
    LEFT JOIN   TIERS ctpy
    ON            ctpy.ident = AUDIT_MVT.CONTREPARTIE
    LEFT JOIN AFFECTATION
    ON            AFFECTATION.IDENT = TITRES.AFFECTATION
    LEFT JOIN  RISKUSERS trader
    ON            trader.ident = HISTOMVTS.operateur
    INNER JOIN TA_BLOCK_TO_GENERATED TA
    ON TA.BLOCK_ID = HISTOMVTS.refcon
     LEFT JOIN FOLIO
    ON FOLIO.IDENT=HISTOMVTS.opcvm
    LEFT JOIN FOLIO mgr
    ON mgr.IDENT=FOLIO.mgr
      LEFT JOIN  TIERS entity
    ON   entity.ident=histomvts.entite
    
    WHERE     histomvts.backoffice NOT IN (11,13,17,26,27,192,220,248,252) --cancelled trades
    AND            HISTOMVTS.type IN (1,294,247,250,1444,1494) 
    AND           USERINFOS.country in (REGION1,REGION2)
    AND           AUDIT_MVT.backoffice = 180 -----BO status is Allocated
    AND           trunc(HISTOMVTS.dateneg) >= add_months(trunc(sysdate),-1)
) pool

group by execution_book
 , "Strategy/Trader Book"
 , sicovam
 , parent_id
 , reference
 , allotment
 , trade_date
 , value_date
 , business_event
 , counterparty
 , trader
 , operator
 , creation_type
;

-- *****************************************************************
  -- END OF: BOOKED_ALLOC_BY_OPS
  -- *****************************************************************   
	END BOOKED_ALLOC_BY_OPS; 


-- *****************************************************************
-- Description: PROCEDURE LAST_PRICE_OVER_CHANGE_LISTED
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 22 JUN 2018      PMOGEI-10    Created by Jeff Yu
-- 16 AUG 2018    Jeff Yu    Modified (PMOGUCITS-60)
-- *****************************************************************
  PROCEDURE LAST_PRICE_OVER_CHANGE_LISTED
	(
      p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: LAST_PRICE_OVER_CHANGE_LISTED
  -- *****************************************************************  
		OPEN p_CURSOR FOR

SELECT distinct pool.SICOVAM
, pool.REFERENCE
,pool.LIBELLE  as instrument_name
,pool.ALLOTMENT
, pool.pricing_date
, pool.D
, pool.D1  as "D-1"
,ap.username
from
(
SELECT SICOVAM, REFERENCE,LIBELLE,ALLOTMENT, pricing_date, D, D1 FROM (
SELECT TITRES.sicovam
, TITRES.REFERENCE
,TITRES.LIBELLE
, AFFECTATION.LIBELLE  AS ALLOTMENT
,HISTORIQUE.jour as pricing_date
,HISTORIQUE.D, 
LEAD (HISTORIQUE.D,1) OVER (PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) AS D1,
HISTORIQUE.D - LEAD (HISTORIQUE.D,1) OVER (PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) AS difference,
DENSE_RANK() OVER(PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) Top

FROM HISTORIQUE
INNER JOIN TITRES
ON HISTORIQUE.SICOVAM=TITRES.SICOVAM
INNER JOIN (
SELECT TITRES.SICOVAM, SUM(HISTOMVTS.QUANTITE) FROM TITRES 
INNER JOIN HISTOMVTS
ON TITRES.SICOVAM=HISTOMVTS.SICOVAM
INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                  , FOLIO.ident                                                             AS STRATEGY_ID
                  , FOLIO.name                                                              AS STRATEGY_NAME
                  , level
                 FROM        FOLIO
                where       level >= 4
                START       WITH FOLIO.ident    IN (14414,90565) 
                CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) fund_book_strategy
on fund_book_strategy.strategy_id =   HISTOMVTS.opcvm
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
AND BUSINESS_EVENTS.COMPTA = 1
WHERE HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND   HISTOMVTS.dateneg < TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM 
HAVING SUM(HISTOMVTS.QUANTITE) !=0
) OPEN_P
on OPEN_P.sicovam=TITRES.SICOVAM
LEFT JOIN AFFECTATION
ON AFFECTATION.IDENT=TITRES.AFFECTATION
WHERE  
HISTORIQUE.D IS NOT NULL
and (titres.type in ('A','O','G') or titres.affectation in (1020,1060,5,10,1041,34)) ---Listed products
)
WHERE TOP=1 
and trunc(pricing_date) = trunc(sysdate) 
AND (
(D1=0 and ABS(D) >= 0.1) OR
(D1 <> 0 AND ABS(difference/D1) >= 0.1)
)
) pool
INNER JOIN BTG_DAILY_AUDIT_HISTORIQUE ap
on ap.sicovam=pool.sicovam
and ap.modified_jour=pool.pricing_date
and ap.d_after=pool.d
where ap.username != 'svc_sophis_adm'  -----Exclude sophis system update
order by pool.ALLOTMENT, pool.sicovam
;

-- *****************************************************************
  -- END OF: LAST_PRICE_OVER_CHANGE_LISTED
  -- *****************************************************************   
	END LAST_PRICE_OVER_CHANGE_LISTED; 


-- *****************************************************************
-- Description: PROCEDURE LAST_PRICE_OVER_CHANGE_OTC
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 22 JUN 2018      PMOGEI-10    Created by Jeff Yu
-- *****************************************************************
  PROCEDURE LAST_PRICE_OVER_CHANGE_OTC
	(
        p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: LAST_PRICE_OVER_CHANGE_OTC
  -- *****************************************************************  
		OPEN p_CURSOR FOR

SELECT distinct pool.SICOVAM
, pool.REFERENCE
,pool.LIBELLE   as instrument_name
,pool.ALLOTMENT
, pool.pricing_date
, pool.D
, pool.D1   as  "D-1"
,ap.username
from
(
SELECT SICOVAM, REFERENCE,LIBELLE,ALLOTMENT, pricing_date, D, D1 FROM (
SELECT TITRES.sicovam
, TITRES.REFERENCE
,TITRES.LIBELLE
, AFFECTATION.LIBELLE  AS ALLOTMENT
,HISTORIQUE.jour as pricing_date
,HISTORIQUE.D, 
LEAD (HISTORIQUE.D,1) OVER (PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) AS D1,
HISTORIQUE.D - LEAD (HISTORIQUE.D,1) OVER (PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) AS difference,
DENSE_RANK() OVER(PARTITION BY TITRES.sicovam ORDER BY HISTORIQUE.jour DESC) Top

FROM HISTORIQUE
INNER JOIN TITRES
ON HISTORIQUE.SICOVAM=TITRES.SICOVAM
INNER JOIN (
SELECT TITRES.SICOVAM, SUM(HISTOMVTS.QUANTITE) FROM TITRES 
INNER JOIN HISTOMVTS
ON TITRES.SICOVAM=HISTOMVTS.SICOVAM
INNER JOIN ( 
                  SELECT CONNECT_BY_ROOT(FOLIO.ident)                                             AS TOP_FUND_ID
                  , CONNECT_BY_ROOT(FOLIO.name)                                             AS TOP_FUND_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 1, 2)     AS FUND_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 1, 2)      AS Fund_NAME
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '¬'), '[^¬]+', 3, 4)     AS BOOK_ID
                  , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '¬'), '[^¬]+', 3, 4)      AS BOOK_NAME
                  , FOLIO.ident                                                             AS STRATEGY_ID
                  , FOLIO.name                                                              AS STRATEGY_NAME
                  , level
                 FROM        FOLIO
                where       level >= 4
                START       WITH FOLIO.ident    IN (14414,90565) 
                CONNECT BY PRIOR FOLIO.ident    =   FOLIO.mgr  
                  ) fund_book_strategy
on fund_book_strategy.strategy_id =   HISTOMVTS.opcvm
INNER JOIN BUSINESS_EVENTS
ON BUSINESS_EVENTS.ID = HISTOMVTS.TYPE
AND BUSINESS_EVENTS.COMPTA = 1
WHERE HISTOMVTS.BACKOFFICE not in (192,11,13,17,26,27,220,248,252)
AND   HISTOMVTS.dateneg < TRUNC(SYSDATE)
GROUP BY TITRES.SICOVAM 
HAVING SUM(HISTOMVTS.QUANTITE) !=0
) OPEN_P
on OPEN_P.sicovam=TITRES.SICOVAM
LEFT JOIN AFFECTATION
ON AFFECTATION.IDENT=TITRES.AFFECTATION
WHERE  
HISTORIQUE.D IS NOT NULL
and (titres.type not in ('A','O','G') and titres.affectation not in (1020,1060,5,10,1041,34))  -----OTC Products
)
WHERE TOP=1 
and trunc(pricing_date) = trunc(sysdate) 
AND (
(D1=0 and ABS(D) >= 0.1) OR
(D1 <> 0 AND ABS(difference/D1) >= 0.1)
)
) pool
INNER JOIN BTG_DAILY_AUDIT_HISTORIQUE ap
on ap.sicovam=pool.sicovam
and ap.modified_jour=pool.pricing_date
and ap.d_after=pool.d
where ap.username != 'svc_sophis_adm'  -----Exclude sophis system update
order by pool.ALLOTMENT, pool.sicovam
;

-- *****************************************************************
  -- END OF: LAST_PRICE_OVER_CHANGE_OTC
  -- *****************************************************************   
	END LAST_PRICE_OVER_CHANGE_OTC; 


-- *****************************************************************
-- Description: PROCEDURE SD_STAARS_FEED
--
-- Revision History
-- Date             JIRA
-- ----------------------------------------------------------------
-- 21 AUG 2018      PMOG-1123    Created by Jeff Yu
-- *****************************************************************
  PROCEDURE SD_STAARS_FEED
	(
        p_CURSOR OUT T_CURSOR
	)
	AS
	BEGIN
   -- *****************************************************************
  -- START OF: SD_STAARS_FEED
  -- *****************************************************************  
		OPEN p_CURSOR FOR

select sd.code as TransactionReferenceNo
, '' as "Buy/Sell"
, '' as TradeStatus 
, fund.libelle as FundName
, '' as BankAccountID
, to_char(SD.PAY_DATE,'YYYY-MM-DD') as SettlementDate 
, '' as PostDate
, '' as "SecurityID(Sicovam)"
, '' as Reference
, '' as Cusip
,'' as Sedol
, '' as ISIN
, '' as Ticker
,'' as UnderlyingISIN
,'' as SecurityDescription
,'' as SecurityType
, '' as SecurityTypeDescription
, to_char(sd.nego_date,'YYYY-MM-DD') as TradeDate 
, SD.NUMBER_SHARES as Nominal 
,SD.NUMBER_SHARES as Quantity
,sd.amount as NetAmountInBaseCCY
,'' as PriceInBaseCCY
,'' as BaseCCY
,sd.amount as NetAmountInLocalCCY
,'' as PriceInLocalCCY
,'' as LocalCCY
,'' as BusinessEvent
,'' as "Comment"
,'' as ContractSize
,'' as Strike
,'' as "Operator" 
, to_char(SD.PAY_DATE,'YYYY-MM-DD') as PaymentDate 
,'' as Counterparty
,'' as Broker
,'' as GrossAmountInSettlementCCY
,'' as TopStrategy
,'' as FXRate
,'' as ParentId
,'' as FUT_Market
,'' as FUT_PutCall
,'' as Fees
, BO_KERNEL_STATUS.NAME as BackOfficeStatus
,'' as Loanxid
, tiers.name as Depositary
,'' as "Settlement Type"
,'' as "Underlying Contract Size"
,'' as "Fixed Rate"
,'' as "Start Date"
,'' as "Maturity Date"
, '' as Strategy
, '' as RED
, null
,'' as  Seniority
, '' as "Restructuring type"
, '' as "ISDA Protocal"
, '' as "CDS Type"
, fund.libelle as Fund
, '' as "Market Fees"
, '' as "Execution Fees"
, '' as "Creation Type"

from FUND_PURCHASE sd
left join titres fund
on sd.FUND=fund.sicovam
left join BO_KERNEL_STATUS
on BO_KERNEL_STATUS.id=sd.backoffice
left join tiers
on tiers.ident=sd.broker
where sd.code in (
select distinct f.code
from AUDIT_FUND_PURCHASE a
inner join FUND_PURCHASE f
on a.code=f.code
where trunc(AUDIT_DATE) >= trunc(BTG_BUSINESS_DATE(sysdate,-1))
)
;

-- *****************************************************************
  -- END OF: SD_STAARS_FEED
  -- *****************************************************************   
	END SD_STAARS_FEED; 

END PCKG_BTG_PMO_REPORTS_OPS;