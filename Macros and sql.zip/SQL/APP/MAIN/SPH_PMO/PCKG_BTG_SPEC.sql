CREATE OR REPLACE PACKAGE PCKG_BTG
AS 

  -- ***************************************************************************
	-- Constant variables
	-- ***************************************************************************
  
  EOT                               CONSTANT TIMESTAMP    := TO_DATE( '31-Dec-9999 23:59:59', 'DD-MON-YYYY HH24:MI:SS' );
  --Date used on PACKAGE BODY "PCKG_BTG_BR_INTERFACE as cut off date for getting trades, only trades with dateTrade bigger than this date will be interfaced
  DT_BR_INTERFACE_CUT_OFF              CONSTANT TIMESTAMP    := TO_DATE('2011/06/01:12:00:00AM', 'yyyy/mm/dd:hh:mi:ssam');
  
  
  -- ***************************************************************************
	-- Folios Codes
	-- ***************************************************************************
    FOLIO_PRIMARY_FUNDS                               CONSTANT  FOLIO.IDENT%TYPE     := 14414 ;
    FOLIO_SECUNDARY_FUNDS                             CONSTANT  FOLIO.IDENT%TYPE     := 14405 ;
    FOLIO_EXECUTION_BOOK                              CONSTANT  FOLIO.IDENT%TYPE     := 14045 ;
    FOLIO_GEMM_MASTER_FUND                            CONSTANT  FOLIO.IDENT%TYPE     := 12505 ;
    FOLIO_ARF2_MASTER_FUND                            CONSTANT  FOLIO.IDENT%TYPE     := 12642 ;
    FOLIO_ARF_MASTER_FUND                             CONSTANT  FOLIO.IDENT%TYPE     := 12506;   
    FOLIO_FOCUS_FUND_RATE                             CONSTANT  FOLIO.IDENT%TYPE     := 62880 ;
    FOLIO_GEO_MASTER_FUND                             CONSTANT  FOLIO.IDENT%TYPE     := 67092 ;
    FOLIO_PACTUAL_GLOBAL_FUND                         CONSTANT  FOLIO.IDENT%TYPE     := 63809 ;
    FOLIO_EMBL_FUND                                   CONSTANT  FOLIO.IDENT%TYPE     := 66762 ;
    FOLIO_DMF_FUND                                    CONSTANT  FOLIO.IDENT%TYPE     := 28964 ;
    FOLIO_STF_MASTER_FUND                             CONSTANT  FOLIO.IDENT%TYPE     := 64846 ; 
    FOLIO_BTG_FUND                                    CONSTANT  FOLIO.IDENT%TYPE     := 12514 ; 
    FOLIO_EXEC_BOOK                                   CONSTANT  FOLIO.IDENT%TYPE     := 14046 ; 
	FOLIO_UCITS_FUND                                  CONSTANT  FOLIO.IDENT%TYPE     := 90565 ; 
	FOLIO_QSF_MASTER_FUND                             CONSTANT  FOLIO.IDENT%TYPE     := 93654 ; 
	FOLIO_BTG_WEALTH_MANAGEMENT                       CONSTANT  FOLIO.IDENT%TYPE     := 86931 ; 
	FOLIO_GDO_MASTER_FUND                             CONSTANT  FOLIO.IDENT%TYPE     := 132408;
    
END PCKG_BTG;
 
/



