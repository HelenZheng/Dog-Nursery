create or replace
TRIGGER "SPH_OWNER"."BTG_TR_DEPO_COUNTERPART" 

BEFORE INSERT OR UPDATE OF "DEPOSITARY_OF_THE_COUNTERPART" ON "HISTOMVTS" FOR EACH ROW

                          begin

	if inserting then
  
  
  
  DECLARE
  v_found NUMBER := 0;
   CURSOR check_cursor
       IS
   SELECT 1
    FROM titres
   WHERE sicovam = :NEW."SICOVAM"  ;
  BEGIN
  OPEN  check_cursor;
  FETCH check_cursor INTO v_found;
  CLOSE check_cursor;
  
   IF v_found = 1
   THEN
   :NEW."DEPOSITARY_OF_THE_COUNTERPART" := null;
   END IF;  
 END;
 
 elsif updating then
 DECLARE
  v_found NUMBER := 0;
   CURSOR check_cursor
       IS
   SELECT 1
    FROM titres
   WHERE sicovam = :NEW."SICOVAM"  ;
  BEGIN
  OPEN  check_cursor;
  FETCH check_cursor INTO v_found;
  CLOSE check_cursor;
  
   IF v_found = 1
   THEN
   :NEW."DEPOSITARY_OF_THE_COUNTERPART" := null;
   END IF;  
 END;
end if;
END;
