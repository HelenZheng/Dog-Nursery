﻿$local_dir = "D:\FileInterface\PersonalExtraction\MacroQuant\FX\QUERYDOWNLOADER"
Set-Location -Path $local_dir

$config_file = "Btg.AssetManagement.QueryDownloader.exe.config"
$night_file ="Btg.AssetManagement.QueryDownloader.exe.config.night"
$morning_file = "Btg.AssetManagement.QueryDownloader.exe.config.morning"


$a = Get-Date
"The Hour is: " + $a.Hour

if ($a.Hour -eq 6) 
   {
     "It's Morning Time"
	 Remove-Item $config_file
     if (Test-Path "$local_dir\$morning_file") 
        {
          "Morning File $morning_file FOUND"
          "Copying File $morning_file to $config_file"
          Copy-Item $morning_file  $config_file
        }
   }
elseif ($a.Hour -eq 22) 
   {
     "It's Night Time"
	 Remove-Item $config_file
     if (Test-Path "$local_dir\$night_file") 
        {
          "Night File $night_file FOUND"
          "Copying File $night_file to $config_file"
          Copy-Item $night_file  $config_file
         }

   }
else 
   {
      "Doing Nothing, job is running out of sequence, keeping current config file"   
 }


