#ifndef _SphDotNetLink_H_
#define _SphDotNetLink_H_

#include "SphInc/SphMacros.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma managed(push, on)
#endif


#include <vcclr.h>	// gcroot

SPH_PROLOG
#pragma managed
namespace sophis
{
	/**
	 *	ISRDotNetLink
	 *	Interface used to retrieve managed object embedded into an unmanaged class.
	 *	It is used to retrieve .NET-defined user data in C++.
	 *	@version 6.0
	 */
	class SOPHIS_CORE ISRDotNetLink
	{
	public:
		/**
		 *	Trivial destructor.
		 *	@version 6.0
		 */
		virtual ~ISRDotNetLink();

		/**
		 *	Method returning the managed object.
		 *	@return the managed object or nullptr if none.
		 *	@version 6.0
		 */
		virtual gcroot< System::Object ^ >	GetManaged() const	= 0;
		
		template< class _MngR_, class _UnMngP_ >
		static _MngR_ ^	GetManaged( const _UnMngP_ * cppP )
		{
			const ISRDotNetLink * dotNetLink	= dynamic_cast< const ISRDotNetLink * >( cppP );
			if( 0 != dotNetLink )
			{
				System::Object ^ mngObj	= dotNetLink->GetManaged();
				return dynamic_cast< _MngR_ ^ >( mngObj );
			}
			else
				return nullptr;
		}
	};
}

SPH_EPILOG

#if (defined(WIN32)||defined(_WIN64))
#	pragma managed(pop)
#endif

#endif

