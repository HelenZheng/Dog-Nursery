#ifndef __SPHAccountingForecast_H_
#define __SPHAccountingForecast_H_
#pragma once

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(list)
#include "SphAccountingPosting.h"

SPH_PROLOG
namespace sophis
{
	namespace accounting
	{
		class SOPHIS_ACCOUNTING CSRAccountForecast
		{	
		public:
			CSRAccountForecast();
			virtual ~CSRAccountForecast();

			void execute(_STL::list<long> entities);
			virtual long push_back(SSFinalPosting *posting);					
			virtual long push_back(SSFinalPostingExtraction *posting);
		};
	}
}
SPH_EPILOG

#endif