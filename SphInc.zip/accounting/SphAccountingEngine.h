#ifndef SPH_ACCOUNTING_ENGINE_H
#define SPH_ACCOUNTING_ENGINE_H

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(algorithm)
#include __STL_INCLUDE_PATH(set)
#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_kernel/SphKernelEngine.h"
#include "SphTools/sphvector.h"
#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis
{
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace accounting
	{
		class CSREngineQueries;
		class SSFinalPosting;
		class CSRAccountingEntity;

		class SOPHIS_ACCOUNTING CSRAccountingMvt
		{
		public:
			CSRAccountingMvt(CSREngineQueries *engQueries);
			virtual ~CSRAccountingMvt();
			void init(); 
			CSREngineQueries* GetEngineQueries() const;
			int GetTotalCountOfPosting() const ;
			void IncreaseTotalCountOfPostings() ;
			const SSFinalPosting* GetErrorPosting() const ;
			sophisTools::csrvector /*CSRAccountingEntity* */ GetAccEntityArray() const ;

			long	GetAllotmentID()		const ;
			long	GetAccountingBookID()	const ;
			long	GetBaseCurrencyCode()	const ;
	
			// mvt information
			virtual portfolio::TransactionIdent GetMvtCode() const = 0;

			virtual long GetMvtVersion() const;
			virtual long GetInstrumentCode() const;
			virtual portfolio::PositionIdent GetPositionID() const;
			virtual long GetFolioCode() const = 0;
			virtual void ShootAgain() = 0;

			virtual eTradeType GetTradeType() const = 0;
			
			virtual eRuleType GetRuleType() const = 0;

			virtual bool DeletePostingsBeforeReverse( bool onlyShootAgain = false) const = 0;
			virtual bool GetPostingsToReverse( /* out */ _STL::vector<SSFinalPosting>& posts) const = 0;


		protected:
			// Initialize the accounting entity array
			// Return :
			//	- true if there are some accounting Entity defined for the trade
			bool InitializeAccountingEntityArray() ;

			// To get all the EntityID of a certain type : exlude or not exclude
			// Parameter :
			//	[OUT]	- LVLong array = array of EntityID corresponding to the type specified
			//	[IN]	- eExcludeType excludeType =  etExcluded, etNotExcluded
			// Return :
			//	- bool = true if success
			bool DetermineAccEntityIDArray(_STL::vector<long> & array, eExcludeType excludeType ) ;


			virtual CSRAccountingEntity* createAccountingEntity(CSREngineQueries *engQueries) const;

			virtual long GetEntity() const = 0;
			virtual long GetSettlementCurrency() const = 0;
			virtual long GetCounterparty() const = 0;
			
			// Initialize the allotment bookID associated with current trade
			// return :
			//	- false if no allotment 
			virtual bool InitializeAllotmentID();

			// Initialize the base currency code associated with current trade
			// return :
			//	- false if not found 
			virtual bool InitializeCurrencyCode() = 0;

			virtual	bool InitializeAccountBookID() = 0; 

		protected:
			CSRAccountingMvt();
			void Initialize(CSREngineQueries *engQueries);

			// To create ErrorPosting corresponding to specified errorType
			// Parameter :
			//	- eAccountingTradeError errorType = 	ateNoAccountingEntity,
			//											ateNoBaseCurrency,
			//											ateNoAllotment,
			//											ateNoAccountBook
			//
			void CreateErrorPosting( eAccountingTradeError errorType ) ;

			int fTotalCountOfPostings ;
			long fBaseCurrencyCode;
			long fAccountingBookID;
			long fAllotmentID;
			CSRAccountingEntity** fAccountingEntityArray ;
			int		fSizeAccEntityArr ;

			SSFinalPosting		  *fErrorPosting ;
			CSREngineQueries	  *fEngineQueries;

			static const char * __CLASS__;
		};

		class SOPHIS_ACCOUNTING CSRAccountingTrade : public virtual CSRAccountingMvt
		{
		public :

			// Constructor/Destructor
			CSRAccountingTrade(const portfolio::CSRTransaction* trade, long version, CSREngineQueries *engQueries, bool deleteTrade=false);

			virtual ~CSRAccountingTrade() ;

			virtual CSRAccountingEntity* createAccountingEntity(CSREngineQueries *engQueries) const;

			// Member fields access

			const portfolio::CSRTransaction*	GetTrade()	const ;

			// trade information
			virtual portfolio::TransactionIdent GetMvtCode() const;

			virtual long GetMvtVersion() const;
			virtual long GetInstrumentCode() const;
			virtual portfolio::PositionIdent GetPositionID() const;
			virtual long GetFolioCode() const;

			eTradeType GetTradeType() const { return ttTrade; }
			eRuleType GetRuleType() const {return rtTrade;}

			virtual bool DeletePostingsBeforeReverse( bool onlyShootAgain = false) const;
			virtual bool GetPostingsToReverse( /* out */ _STL::vector<SSFinalPosting>& posts) const;
			virtual void ShootAgain();

		protected :

			CSRAccountingTrade();
			void Initialize(const portfolio::CSRTransaction* trade, long version, CSREngineQueries *engQueries, bool deleteTrade=false);

			// Processing methods

			// Initialize the account bookID associated with current trade
			//
			// return :
			//	- false if no accountBook 
			//
			bool InitializeAccountBookID() ;

			// Initialize the base currency code associated with current trade
			//
			// return :
			//	- false if not found 
			//
			bool InitializeCurrencyCode() ;

			long GetEntity() const;
			long GetSettlementCurrency() const;
			long GetCounterparty() const;

			// Fields

		//	const CSRInstruction* fInstr;
			const portfolio::CSRTransaction*	fTrade;
			long								fTradeVersion;
			mutable _STL::set<long>				fToShootAgain;


			private:
				bool fDeleteTrade;
			static const char * __CLASS__;

		} ;

namespace PostingStatus
{
	enum eStatus
	{
		psNotAStatus,
		psPending, 
		psReady,
		psHold,
		psSent,
		psReadyReversed,
		psSentReversed,
		psReadyAL,
		psSentAL,
		psPendingReversal,
		psReadyReversal,
		psHoldReversal,
		psSentReversal,
		psSentALReversed,
		psHoldAL,
		psSentFromAL,
		psSentALReversal,
		psLast
	} ;

	eStatus	SOPHIS_ACCOUNTING	Hold(eStatus status);	
	eStatus	SOPHIS_ACCOUNTING	Ready(eStatus status);	
	eStatus	SOPHIS_ACCOUNTING	Reversed(eStatus status);
	bool	SOPHIS_ACCOUNTING	ToDelete(eStatus status);
	int		SOPHIS_ACCOUNTING	SqlPostingIn(char * query, bool (*Include)(eStatus status));
}

class SOPHIS_ACCOUNTING CSRAccountingEngine
{
public:

	static void generateForAction(	CSRAccountingMvt* mvt,
									backoffice_kernel::eGenerationType generationType,
									tools::CSREventVector * mess,
									_STL::set<long> *postingDate = 0);

	static bool GetAllPostings(CSRAccountingMvt* mvt,
							   SSFinalPosting**					finalPostingArray,
							   int*								sizeFinalPostingArray,
							   backoffice_kernel::eGenerationType generationType) ;

	static bool ProcessPostings(const CSRAccountingMvt* mvt,
							    SSFinalPosting** finalPostingArray,
								int* sizeFinalPostingArray,
								backoffice_kernel::eGenerationType generationType);

private:
	static bool ReSizePostingArray(SSFinalPosting** finalPostingArray,
								   int* currentSize,int increaseBy);
};

	}
}

SPH_EPILOG

#endif // SPH_ACCOUNTING_ENGINE_H
