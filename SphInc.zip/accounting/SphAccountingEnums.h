#ifndef SPH_ACCOUNTING_ENUMS_H
#define SPH_ACCOUNTING_ENUMS_H


#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif

SPH_PROLOG

///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
namespace sophis
{
	namespace accounting
	{

///////////////////////////////////////////////////////////////////////////

enum eAccountType
{
	atAsset=1,
	atLiability,
	atExpenses,
	atRevenue,
	atOffBalanceSheet,
	atThirdAccount,
	atRevenueExpenses,
	atOffBalanceSheetCredit,
	atOffBalanceSheetDebit,
	atTechnical
} ;

///////////////////////////////////////////////////////////////////////////

enum eTypePosting
{
	tpAsset=1,
	tpLiability,
	tpForex,
	tpAccruedFirstLeg,
	tpAccruedSecondLeg,

	tpSimplePosting,
	tpIncomeFirstLeg,
	tpIncomeSecondLeg,
	tpPostingError,
	tpPostingWarning,

	tpRevaluation,
	tpRevaluation2,
	tpPrepaidExpenses,
	tpDifferedExpenses,
	tpPrepaidRevenues,

	tpDifferedRevenues,
	tpAccrual,
	tpReconciliation,

	tpAmortized
} ;	

///////////////////////////////////////////////////////////////////////////

enum eRuleType
{
	rtTrade=1
	,rtPosition
	,rtBalance
	,rtAuxiliaryLedger
	,rtSettlement
	,rtPayment	
	,rtAmortizing
	,rtEOY
	,rtAll
	,rtEngineTypeCount = rtPayment
};

///////////////////////////////////////////////////////////////////////////

enum eTradeType
{
	ttTrade = 0,
	ttVirtualForValue = 1
};

///////////////////////////////////////////////////////////////////////////

enum eAccountingRuleError
{
	areNoPostingRule
} ;

///////////////////////////////////////////////////////////////////////////

enum ePostingRuleError
{
	preAmoutNotAvailable,
	preNoPostingAmountModel,
	preTypeCurrencyUnknown,
	preToDoIfUnknown,
	preTypeCurrencyToDoUnknown,
	preNoForexRuleModel,
	preTypeCreditDebitUnknown,
	preAddInstrumentCodeUnknown,
	preAddThirdPartyCodeUnknown,
	preNoModelDate,
	preNoAccountNumberFound,
	preNoModelQuantity,
	preNoUnderlyingAllotment,
	preCurrencyAndInstrument,
	preAmoutCurrencyNotAvailable,
	preDefaultAccountingAccountNameID,
	preNoNostroAccount,
} ;

///////////////////////////////////////////////////////////////////////////

enum eAccountingTradeError
{
	ateNoAccountingEntity,
	ateNoBaseCurrency,
	ateNoAllotment,
	ateNoAccountBook
} ;

///////////////////////////////////////////////////////////////////////////

enum eAccountingPositionError
{
	apeNoBaseCurrency,
	apeNoAllotment
} ;

///////////////////////////////////////////////////////////////////////////

enum eAccountingEntityError
{
	aeeNoRulesID
} ;

///////////////////////////////////////////////////////////////////////////

enum eAggregationError
{
	aeAux1NameDifferent,
	aeAux2NameDifferent,
	aeAux3NameDifferent,
	aeAux1NumberDifferent,
	aeAux2NumberDifferent,
	aeAux3NumberDifferent,
	aePostingTypeDifferent,
	aeSignDifferent
} ;

///////////////////////////////////////////////////////////////////////////

enum eExcludeType
{
	etExcluded = 1,
	etNotExcluded
} ;

///////////////////////////////////////////////////////////////////////////

enum eStopSearchingRule
{
	ssrYes = 1,
	ssrNo
} ;

///////////////////////////////////////////////////////////////////////////

enum eTradeCurrencyType
{
	tctAmountCurrency=1,
	tctBaseCurrency,
	tctAccountancyCurrency,
	tctTradeCurrency,
	tctFixedCurrency
} ;

///////////////////////////////////////////////////////////////////////////

enum ePNLCurrencyType
{
	pctAmountCurrency=1,
	pctBaseCurrency,
	pctAccountancyCurrency,
	pctFixedCurrency
} ;

///////////////////////////////////////////////////////////////////////////

enum eTradeCurrencyToDoType
{
	tcttdAmountCurrency=1,
	tcttdBaseCurrency,
	tcttdAccountancyCurrency,
	tcttdTradeCurrency,
	tcttdNoChoice,
	tcttdFixedCurrency
} ;

///////////////////////////////////////////////////////////////////////////
	
enum eTypeCreditDebit
{
	tcdDebitAlways=1,
	tcdCreditAlways,
	tcdDebitIfAmountPositive,
	tcdCreditIfAmountPositive
} ;

///////////////////////////////////////////////////////////////////////////

enum eAddInstrument
{
	aiNoThird=1,
	aiCounterpart,
	aiBroker,
	aiDepositary
} ;

///////////////////////////////////////////////////////////////////////////

enum eTypeReversal
{
	trOther			= 1,
	trIncremental,
	trReversal,
	trAccrual,
	trUnrealized,
	trUnrealizedEq,
	trUnrealizedEqFx
} ;

///////////////////////////////////////////////////////////////////////////

enum eAccLength // naming convention -> P_XXXXX_LEN stands for POSTING_XXXXXXX_LENGTH
{
	P_ACCOUNT_LEN			= 40
	,P_ACC_NUMBER_LEN		= 80
	,P_AUX_ACC_LEN			= 80
	,P_COMMENTS_LEN			= 100
	,P_JOURNAL_ENTRY_LEN	= 40
	,P_NAME_LEN				= 40
	,TO_DO_IF_LEN			= 256
	,ENTITY_RULES_CONDITION_LEN = 100
};

///////////////////////////////////////////////////////////////////////////

typedef enum 
{
	esBeforePnL = 1,
	esAfterPnL
} eExecutionSchedule;

///////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG

#endif // #ifndef SPH_ACCOUNTING_ENUMS_H
