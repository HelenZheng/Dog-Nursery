#ifndef _SPH_ACCOUNTING_POSTING_H_
#define _SPH_ACCOUNTING_POSTING_H_

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
#include "SphInc/SphMacros.h"
#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis
{
	namespace accounting
	{
		struct TPostingInfo;
		struct TPostingRulesTrade;
		struct TPostingRulesPnL;

//#define POSTING_ACCOUNT_LENGTH			40
//#define POSTING_COMMENTS_LENGTH			100
//#define POSTING_JOURNAL_ENTRY_LENGTH	40
//#define POSTING_NAME_LENGTH				40
//#define TO_DO_IF_LENGTH					256	

		enum efpFinalPosting
		{
			efpID, 
			efpAccountEntityID,
			efpPostingRuleID,
			efpTradeID,
			efpVersionID,
			efpPostingType,
			efpGenerationDate,
			efpPostingDate,
			efpAccountNumber,
			efpAccountCurrency,
			efpAmount,
			efpCreditDebit,
			efpThirdPartyID,
			efpInstrumentID,
			efpCurrency,
			efpQuantity,
			efpSign,
			efpAuxiliary1Account,
			efpAuxiliary2Account,
			efpComments,
			efpJournalEntry,
			efpStatus,
			efpAuxiliaryDate,
			efpAccountNameID,
			efpAuxiliary1AccountID,
			efpAuxiliary2AccountID,
			efpLinkeID,
			efpRuleType,
			efpAuxiliary3Account,
			efpAuxiliary3AccountID,
			efpPositionID,
			efpAuxiliaryID,
			efpAccountingBookID,
			efpAmortizingRuleID,
			efpInstructionID,
			efpPaymentID,
			efpNostroID,
			efpAmountCurrency,
			efpTradeType, 
			efpOriginalPostingDate
		};

		class SSPostingExtractionLevel;

		class SOPHIS_ACCOUNTING SSFinalPosting
		{
		public:
			long	fID ;
			long	fAccountEntityID ;
			int		fAccountType ;
			long	fPostingRuleID ;
			portfolio::TransactionIdent	fTradeID ;
			long	fVersionID ;
			long	fPostingType ;
			long	fGenerationDate ;
			long	fPostingDate ;
			char	fAccountNumber[ P_ACC_NUMBER_LEN] ;
			long	fAccountCurrency ;
			double	fAmount ;
			char	fCreditOrDebit[2];	// 2 for Oracle
			char	fCreditOrDebitUnused;
			long	fThirdPartyID ;
			long	fInstrumentID ;
			long	fCurrency ;
			double	fQuantity ;
			char	fSign[2];	// 2 for Oracle
			char	fSignUnused;// 2 for Oracle
			char	fAux1Account[ P_AUX_ACC_LEN] ;
			char	fAux2Account[ P_AUX_ACC_LEN] ;
			char	fAux3Account[ P_AUX_ACC_LEN] ;
			char	fComments[ P_COMMENTS_LEN] ;
			char	fJournalEntry[ P_JOURNAL_ENTRY_LEN] ;
			long	fStatus ;
			long	fAuxiliaryDate ;
			long	fAccountNameID ;
			long	fAux1AccountID ;
			long	fAux2AccountID ;
			long	fAux3AccountID ;
			long	fLinkID ;
			int		fRuleType ;
			double	fAmountYesterday ;
			double	fQuantityYesterday ;
			char	fName[ P_NAME_LEN];
			long	fAllotment ;
			portfolio::PositionIdent	fPositionID;
			long	fAccountingBookID;
			long	fAmortizingRuleID;
			double	fAmountOriginalCurrency ;
			long	fAccountLag;
			long	fInxID;
			long	fPaymentID;
			long	fNostroAccountID;
			int		fTradeType;
			long	fOriginalPostingDate;
			double	fAmountOriginalCurrencyYesterday;
			long	fHedgeRelationshipId;

			int		fDateLock;

			SSFinalPosting(){ Initialize();};
			SSFinalPosting( const SSFinalPosting & posting );

			virtual void Initialize();
			void	operator = ( const SSFinalPosting & posting );
			SSFinalPosting & operator = (const TPostingInfo & p_info);
			SSFinalPosting & operator = (const TPostingRulesTrade & p_rule_trade);
			SSFinalPosting & operator = (const TPostingRulesPnL & p_info);
		} ;

		struct SSFinalPostingAuxID : public SSFinalPosting
		{
			long	fAuxiliaryID;
			long	fTradeDateNeg;	// from HISTOMVTS (if set); be careful when dealing with aggregated postings
			long	fTradeHeureNeg;	// from HISTOMVTS (if set); be careful when dealing with aggregated postings
			void	operator = ( const SSFinalPostingAuxID & posting );
		};

		class SOPHIS_ACCOUNTING SSPostingExtractionLevel
		{		
		public:
			long fIdent, fMgr, fCode;
			int fLevel;
			SSPostingExtractionLevel* fParent;
			_STL::string fName, fCriteriumName;

			SSPostingExtractionLevel();
			virtual ~SSPostingExtractionLevel();

			void AddChild(SSPostingExtractionLevel *l);
			_STL::vector<SSPostingExtractionLevel*> fChildren;
			SSPostingExtractionLevel* GetChild(long ident);
		};

		class SOPHIS_ACCOUNTING SSFinalPostingExtraction : public SSFinalPosting
		{
		public:
			SSPostingExtractionLevel *fLevel;

			SSFinalPostingExtraction(const SSFinalPosting &posting, SSPostingExtractionLevel *level);
			SSFinalPostingExtraction(const SSFinalPostingExtraction &posting);
			virtual ~SSFinalPostingExtraction(){}
		};

		/**
		* Array of postings.
		*/
		typedef _STL::vector< SSFinalPosting *> VP_SSFinalPosting;
		typedef VP_SSFinalPosting::iterator		IVP_SSFinalPosting;

		typedef _STL::vector<SSFinalPosting> V_SSFinalPosting;
		typedef V_SSFinalPosting::iterator	 IV_SSFinalPosting;

		typedef _STL::vector<SSFinalPostingAuxID> PostingAuxList;
	}
}

SPH_EPILOG

#endif
