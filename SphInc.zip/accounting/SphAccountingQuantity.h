#ifndef SPH_ACCOUNTING_QUANTITY_H
#define SPH_ACCOUNTING_QUANTITY_H


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_ACCOUNTING_QUANTITY(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAccountingQuantity)
#define CONSTRUCTOR_ACCOUNTING_QUANTITY(derivedClass)
#define WITHOUT_CONSTRUCTOR_ACCOUNTING_QUANTITY(derivedClass)
#define	INITIALISE_ACCOUNTING_QUANTITY(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRPosition;
		class CSRTransaction;
	}

	namespace accounting
	{

		/** Interface to populate quantity in accounting engines.
		This is used by the p&l, balance and trade accounting engine, to know what figures
		to populate in Quantity, Instrument and Position field in account_posting table.
		@since 4.2.1
		*/
		class SOPHIS_ACCOUNTING CSRAccountingQuantity
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSRAccountingQuantity() {}

			/** Enumeration to define what to populate.
			Used as return by the main method of the interface.
			*/
			enum  ID_to_Populate
			{
				/** Error case. */
				NotDefined,

				/** No population of instrument nor position.*/
				NoInstrumentID,

				/** Population of instrument not position.*/
				InstrumentID,

				/** Population of instrument and position.*/
				PositionID
			};

			/** Sign of the posting amount.
			@since 4.5.0
			*/
			enum eFlow
			{
				fCredit,
				fDebit
			};

			/** Get the quantity for the trade engine.
			@param trade is the transaction.
			@param flow is the amount sign.
			@param quantity is the output parameter quantity.
			@return what to populate.
			By default call the old interface for maintenance reason which return NotDefined.
			@version 4.5.0 add e new parameter for the sens.
			*/
			virtual ID_to_Populate get_quantity( const portfolio::CSRTransaction& trade, eFlow flow, double* quantity ) const ;

			/** Get the quantity for the P&L engine.
			@param position is the position.
			@param flow is the amount sign.
			@param quantity is the output parameter quantity.
			@return what to populate.
			By default call the old interface for maintenance reason which return NotDefined.
			@version 4.5.0 add e new parameter for the sens.
			*/
			virtual ID_to_Populate get_quantity( const portfolio::CSRPosition& position, eFlow flow, double* quantity ) const ;

			/** Get the quantity for the balance engine.
			@param instrument_id is the instrument id obtained with the group query in positing amount.
			@return what to populate.
			The quantity to populate comes from the group query.
			@since 4.5.0
			*/
			virtual ID_to_Populate populate_in_balance_engine( long instrument_id ) const ;

			/** Get the singleton for one quantity.
			This is equivalent to CSRAccountingQuantity::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the quantity name is not found.
			@param quantityName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRAccountingQuantity* getInstance( const char* quantityName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_ACCOUNTING_QUANTITY.
			@see tools::CSRPrototype
			*/
			virtual CSRAccountingQuantity* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRAccountingQuantity, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_ACCOUNTING_QUANTITY.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

		private:

			/** Returns the quantity to be inserted in the posting.
			@deprecated 4.5.0
			Use one with an equivalent in the public section.
			*/
			virtual ID_to_Populate get_quantity( const portfolio::CSRTransaction& trade, double* quantity ) const ;

			/** Returns the quantity to be inserted in the posting.
			@deprecated 4.5.0
			Use one with an equivalent in the public section.
			*/
			virtual ID_to_Populate get_quantity( const portfolio::CSRPosition& position, double* quantity ) const ;
		} ;


	}
}

SPH_EPILOG

#endif // SPH_ACCOUNTING_QUANTITY_H
