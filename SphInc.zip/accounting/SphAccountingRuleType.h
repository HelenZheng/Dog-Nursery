#ifndef SPH_ACCOUNTING_RULE_TYPE_H
#define SPH_ACCOUNTING_RULE_TYPE_H

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

#define DECLARATION_ACC_RULE_TYPE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAccountingRuleType)
#define CONSTRUCTOR_ACC_RULE_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_ACC_RULE_TYPE(derivedClass)
#define	INITIALISE_ACC_RULE_TYPE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)


SPH_PROLOG

class CSUMenu;
namespace sophis
{
	namespace gui
	{
		struct SSRgbColor;
	}
	namespace accounting
	{
		class CSRAccountingMvt;

		/*	Class to handle an accounting rule type (like trade rules, pnl rules...)
		*/
		class SOPHIS_ACCOUNTING CSRAccountingRuleType
		{
		protected:
			eRuleType fRuleType;
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRAccountingRuleType() {}

			virtual eRuleType GetRuleType() const = 0;

			// by default return 0
			virtual CSRAccountingMvt* 
			CreateAccountingMvt(portfolio::TransactionIdent tradeId, 
			                    short versionId) const;

# ifndef GCC_XML
			/// @deprecated 7.1.3
			DEPRECATED_TRANSACTION_IDENT			
			virtual CSRAccountingMvt* CreateAccountingMvt(long tradeId, 
			                                              short versionId) const
			{
				throw sophisTools::base::NotImplemented("CreateAccountingMvt");
			}

# endif GCC_XML

			virtual bool PostingRecreationIsPossible() const {return false;}
			virtual bool IsLinkedToAnEntity() const {return true;}
			virtual void GetRGBColor(gui::SSRgbColor *color) const ;

			virtual double GetLast(long instrumentId, 
			                       portfolio::TransactionIdent mvtId, 
			                       long date) const;
# ifndef GCC_XML
			/// @deprecated 7.1.3
			DEPRECATED_TRANSACTION_IDENT
			virtual double GetLast(long instrumentId, 
			                       long mvtId, 
			                       long date) const			
			{
				throw sophisTools::base::NotImplemented("CreateAccountingMvt");
			}
# endif GCC_XML

			virtual const char* GetName() const = 0;
			virtual const char* GetRulesTableName() const = 0;
			virtual const char* GetPostingRulesTableName() const = 0;
			virtual CSUMenu* new_rulesConditionMenu() const = 0;

			static CSRAccountingRuleType* GetInstance( eRuleType ruleType ) ;
			virtual CSRAccountingRuleType* Clone() const = 0;

			_STL::vector<_STL::string> GetMenuValues();

//			typedef sophis::tools::CSRPrototype<CSRAccountingRuleType, eRuleType> prototype;
			typedef sophis::tools::CSRPrototype<CSRAccountingRuleType, 
													const char *, 
													sophis::tools::less_char_star> prototype;
			static prototype& GetPrototype();
		} ;
	}
}

SPH_EPILOG

#endif // SPH_ACCOUNTING_RULE_TYPE_H

