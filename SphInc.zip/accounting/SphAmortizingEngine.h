#ifndef __SPHAmortizingFinalDate_H_
#define __SPHAmortizingFinalDate_H_
#pragma once


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_AMORTIZING_FINAL_DATE(derivedClass)	DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAmortizingFinalDate)
#define CONSTRUCTOR_AMORTIZING_FINAL_DATE(derivedClass)
#define WITHOUT_CONSTRUCTOR_AMORTIZING_FINAL_DATE(derivedClass)
#define	INITIALISE_AMORTIZING_FINAL_DATE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

#define DECLARATION_AMORTIZING_START_DATE(derivedClass)	DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAmortizingStartDate)
#define CONSTRUCTOR_AMORTIZING_START_DATE(derivedClass)
#define WITHOUT_CONSTRUCTOR_AMORTIZING_START_DATE(derivedClass)
#define	INITIALISE_AMORTIZING_START_DATE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

#define DECLARATION_AMORTIZING_AMOUNT(derivedClass)	DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAmortizingAmount)
#define CONSTRUCTOR_AMORTIZING_AMOUNT(derivedClass)
#define WITHOUT_CONSTRUCTOR_AMORTIZING_AMOUNT(derivedClass)
#define	INITIALISE_AMORTIZING_AMOUNT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {	
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRTransaction;
	}

	namespace static_data
	{
		class CSRDayCountBasis;
	}

	namespace accounting
	{	
		
		class SOPHIS_ACCOUNTING CSRAmortizingFinalDate
		{
		public:			
			virtual ~CSRAmortizingFinalDate() {}			
			
			virtual long GetFinalDate(const instrument::CSRInstrument &instrument) = 0;
			
			virtual CSRAmortizingFinalDate* Clone() const = 0;

			static CSRAmortizingFinalDate* getInstance( const char* modelName );
			
			typedef sophis::tools::CSRPrototype<CSRAmortizingFinalDate, 
												const char *, 
												sophis::tools::less_char_star> prototype;
			
			static prototype& GetPrototype();
		};

		class SOPHIS_ACCOUNTING CSRAmortizingStartDate
		{
		public:			
			virtual ~CSRAmortizingStartDate() {}			

			virtual long GetStartDate(long posting_date, const instrument::CSRInstrument &instrument) = 0;

			virtual CSRAmortizingStartDate* Clone() const = 0;

			static CSRAmortizingStartDate* getInstance( const char* modelName );

			typedef sophis::tools::CSRPrototype<CSRAmortizingStartDate, 
				const char *, 
				sophis::tools::less_char_star> prototype;

			static prototype& GetPrototype();
		};

		class SOPHIS_ACCOUNTING CSRAmortizingAmount
		{
		public:			
			virtual ~CSRAmortizingAmount() {}						

			virtual CSRAmortizingAmount* Clone() const = 0;

			virtual double GetAmount(const sophis::static_data::CSRDayCountBasis * basis, 
									 const sophis::portfolio::CSRTransaction* transaction,
										long start_date, 
										long current_date,
										long final_date, 
										double	quantity,
										double amount) = 0;

			static CSRAmortizingAmount* getInstance( const char* modelName );

			typedef sophis::tools::CSRPrototype<CSRAmortizingAmount, 
				const char *, 
				sophis::tools::less_char_star> prototype;

			static prototype& GetPrototype();
		};
	}
}

SPH_EPILOG

#endif
