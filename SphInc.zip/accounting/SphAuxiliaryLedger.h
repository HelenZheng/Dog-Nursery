#ifndef _SPH_AUXILIARY_LEDGER_H_
#define _SPH_AUXILIARY_LEDGER_H_


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/accounting/SphAccountingPosting.h"
#include "SphSDBCInc/SphForwardDeclaration.h"

#include __STL_INCLUDE_PATH(set)
// Boost library is not managed by gcc_xml
#ifndef GCC_XML
	BOOST_INCLUDE_BEGIN
	#include BOOST_INCLUDE_PATH(unordered_set.hpp)
	BOOST_INCLUDE_END
#else
	#include __STL_INCLUDE_PATH(unordered_set)
#endif

#define DECLARATION_AUX_LEDGER_RULES_GROUP(derivedClass)	DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAuxiliaryLedgerGroup)
#define DECLARATION_AUX_LEDGER_RULES_SORT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAuxiliaryLedgerSort)
#define DECLARATION_AUX_LEDGER_WORK_PER(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAuxiliaryLedgerWorkPer)
//#define DECLARATION_AUX_LEDGER_METHOD(derviedClass)         DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRAuxiliaryLedgerMethod) 

#define	INITIALISE_AUX_LEDGER_RULES_GROUP(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)
#define	INITIALISE_AUX_LEDGER_RULES_SORT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)
#define	INITIALISE_AUX_LEDGER_METHOD(derivedClass, name)	    INITIALISE_PROTOTYPE(derivedClass,  name)
#define	INITIALISE_AUX_LEDGER_WORK_PER(derivedClass, name)	    INITIALISE_PROTOTYPE(derivedClass,  name)


SPH_PROLOG

namespace sophis
{

	namespace portfolio
	{
		class CSRAveragePrice;
	}
	namespace accounting
	{
//////////////////////////////////////////////////////////////////////////
/**
 * Interface for aggregating (grouping) postings.
 */
//////////////////////////////////////////////////////////////////////////

		/** Data contained in the definition of the auxiliary ledger rule.
		@since 5.3.6
		*/
		struct	AuxiliaryData	{
			long	fPostingTypeBuy;
			// Note the five posting type should start by capitalGain
			// and be continuous. This is due to CSRExtractAccountPostingAL::Extract
			// which needs a long *. Not nice, I agree.
			long    fCapitalGainPostingType;
			long    fCapitalLossPostingType;
			long    fAssetLongPostingType;
			long    fAssetShortPostingType;
			long    fSplitPostingType;
			long	fNominalReductionPostingType;
			long	fRepoPostingType;


			long	fAmortizingRuleID;
			long	fEquityFxCapitaGain;
			long	fEquityFxCapitaLoss;
			long	fRealisedAmortRuleID;
		};

class SOPHIS_ACCOUNTING CSRAuxiliaryLedgerGroup
{
public:
	virtual bool IsLower(const SSFinalPostingAuxID &f1 , const SSFinalPostingAuxID &f2) const = 0;

	virtual long hash_key(const SSFinalPostingAuxID &f) const = 0;
    
    // return -1 if a<b, 0 if a=b, 1 if a>b
	virtual int defaultGroupByCheck(const SSFinalPostingAuxID &f1, const SSFinalPostingAuxID &f2) const;

    /** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_AUX_LEDGER_RULES_GROUP
	@see tools::CSRPrototype
	*/
    virtual CSRAuxiliaryLedgerGroup* Clone() const = 0;

	/** Get a singleton for a specific grouping type.
	  * @param methodName is the name of the sorting method sought.
	  * @return a pointer to the singleton, which must not be deleted but can be null.
	  */
	static CSRAuxiliaryLedgerGroup *getInstance(const char* methodName);

	/** Typedef for the prototype (the key is a string).
	  */
	typedef sophis::tools::CSRPrototype<CSRAuxiliaryLedgerGroup
										,const char*
										,sophis::tools::less_char_star> prototype;
	
	/** Access to the prototype singleton.
	  *	use INITIALISE_AUX_LEDGER_RULES_SORTING to add a new sorting method.
	  *	@see tools::CSRPrototype
	  */
	static prototype& GetPrototype();

	long fSplitPostingType;
};

//////////////////////////////////////////////////////////////////////////
/**
 * Structure for storing aggregation results. It stores the result (aggregated) posting.
 */
struct SSAggregatedPostingAux : SSFinalPostingAuxID, _STL::vector<const SSFinalPostingAuxID *>
{
	/**
      * Constructor.
      */
	SSAggregatedPostingAux(const SSFinalPostingAuxID &posting);

	struct hash_compare
	{
		static const size_t bucket_size = 4;
		static const size_t min_buckets = 8;
	
		_STL::size_t operator()(const SSFinalPostingAuxID &a) const
		{
			return fGroup->hash_key(a);
		}

		bool operator () (const SSFinalPostingAuxID &a, const SSFinalPostingAuxID &b) const
		{
			return !fGroup->IsLower(a,b) && !fGroup->IsLower(b,a);
		}

		CSRAuxiliaryLedgerGroup * fGroup;
	};


	/**
	 *
	 */
	void operator += (const SSFinalPostingAuxID &posting);

	long fMinId;
	bool fMoreThanOne;
  
};

/////////////////////////////////////////////////////////////////////////
/**
  * Structure for a list of aggregated postings.
  */
typedef GCC_UNORDORED_NS::unordered_set<SSAggregatedPostingAux,  
                        SSAggregatedPostingAux::hash_compare,
						SSAggregatedPostingAux::hash_compare> AggregatedPostingAuxList;

//////////////////////////////////////////////////////////////////////////
/**
  * Interface for sorting the postings.
  */
//////////////////////////////////////////////////////////////////////////

class SOPHIS_ACCOUNTING CSRAuxiliaryLedgerSort
{
public:
    virtual bool DefaultIsLower(const SSFinalPostingAuxID &f1, const SSFinalPostingAuxID &f2) const;

	virtual bool IsLower(const SSFinalPostingAuxID &f1 , const SSFinalPostingAuxID &f2) const = 0;

	struct KeyComp
	{
		bool operator () ( AggregatedPostingAuxList::const_iterator a,  
			               AggregatedPostingAuxList::const_iterator b) const
		{
	        return fSort->IsLower(*a, *b);
		}

		CSRAuxiliaryLedgerSort * fSort;

	};

	virtual void Preprocess(const AggregatedPostingAuxList &list) { };

    /** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_AUX_LEDGER_RULES_SORT
	@see tools::CSRPrototype
	*/
    virtual CSRAuxiliaryLedgerSort* Clone() const = 0;

	/** Get a singleton for a specific AL method.
	  * @param methodName is the name of the AL method sought.
	  * @return a pointer to the singleton, which must not be deleted but can be null.
	  */
	static CSRAuxiliaryLedgerSort *getInstance(const char* methodName);

	/** Typedef for the prototype (the key is a string).
	 */
	typedef sophis::tools::CSRPrototype<CSRAuxiliaryLedgerSort,
										const char*,
										sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	  *  use INITIALISE_AUX_LEDGER_RULES_SORTING to add a new sorting method.
	  * @see tools::CSRPrototype
	  */
	static prototype& GetPrototype();

    long fSplitPostingType;
};

struct TALKeyPT;

/** Interface to split the deals in the AL by certain Type.
@since 6.1
*/
class SOPHIS_ACCOUNTING CSRAuxiliaryLedgerWorkPer
{
public:	
	/** Size of buffer to save the key of the work per.
	*/
	enum	{
		eBufferSizeKey	= 40
	};

	virtual CSRAuxiliaryLedgerWorkPer* Clone() const = 0;

	static CSRAuxiliaryLedgerWorkPer *getInstance(const char* methodName);

	/** Fill the key in a buffer
	@param posting is the posting to extract the key.
	@param buffer is if a buffer of size eBufferSizeKey
	*/
	virtual void FillKey(const SSFinalPostingAuxID &posting, const void *buffer) const = 0;

	/** Compare two keys previously filled by FillKey
	@param buffer1 is if a buffer of size eBufferSizeKey
	@param buffer2 is if a buffer of size eBufferSizeKey
	@return < 0 if buffer1 < buffer2, 0 if buffer1 == buffer2, > 0 if buffer1 > buffer2
	*/
	virtual int Compare(const void *buffer1, const void *buffer2) const = 0;


	/** Fill a query of ACCOUNT POSTING table with a where.
	@param query is a query where we need to add "AND clauses"
	@param buffer is an unititilized buffer where we put the key value
	You must use CSRInRef and not CSRIn.
	@see CSRQueryBuffered
	@see CSRInRef
	*/
	virtual void SQLWhere(sql::CSRQueryBuffered<SSFinalPostingAuxID> &query, const void *buffer) const = 0;

	typedef sophis::tools::CSRPrototype<CSRAuxiliaryLedgerWorkPer,
		const char*,
		sophis::tools::less_char_star> prototype;

	static prototype& GetPrototype();
};

//////////////////////////////////////////////////////////////////////////
/**
  * Structure for sorting list of aggregated postings. It is defined as multiset 
  * since sorting is not unique, i.e. elements can be equal.
  */
typedef _STL::multiset<AggregatedPostingAuxList::const_iterator, 
					   CSRAuxiliaryLedgerSort::KeyComp> AggregatedPostingAuxSorted;

//////////////////////////////////////////////////////////////////////////
/**
  * List of Auxiliary Ids that must be updated after the Aux engine has run
	* @version 5.3.4.6 add a bool to update Auxiliaryledger_id
  */
//////////////////////////////////////////////////////////////////////////
struct AuxiliaryUpdate
{
	long	id;
	long	auxiliary_id;
	long	amortizing_id;
};

typedef _STL::vector<AuxiliaryUpdate > AuxiliayIdToUpdateList;

//////////////////////////////////////////////////////////////////////////
/**
  * Interface for different Auxiliary ledger processing methods
  */
//////////////////////////////////////////////////////////////////////////

class SOPHIS_ACCOUNTING CSRAuxiliaryLedgerMethod
{
public:
    /** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_AUX_LEDGER_METHOD
	@see tools::CSRPrototype
	*/

	virtual void Process( TALKeyPT &key,
						  const AuxiliaryData &alData,
						  CSRAuxiliaryLedgerGroup *group,
						  CSRAuxiliaryLedgerSort *sort,
						  PostingAuxList &auxList,
						  AuxiliayIdToUpdateList &idList,
						  PostingAuxList &auxList2,
						  long date,
						  AggregatedPostingAuxList *auxList3,
						  PostingAuxList *auxList4) = 0;

    void CreateMapId( const AggregatedPostingAuxSorted &p1, AuxiliayIdToUpdateList &p2, long amortizingId);

    void Sort(const AggregatedPostingAuxList &p1, AggregatedPostingAuxSorted &p2);

    void Aggregate(const PostingAuxList &p1, AggregatedPostingAuxList &p2);

    void GeneratePostingAuxIds(PostingAuxList &p);

    long GenerateAggrPostingAuxId(AggregatedPostingAuxSorted &p);

    long NewAuxiliaryId(void);	

    virtual CSRAuxiliaryLedgerMethod* Clone() const = 0;

	/** Get a singleton for a specific AL type.
	  * @param methodName is the name of the AL method sought.
	  * @return a pointer to the singleton, which must not be deleted but can be null.
	  */
	static CSRAuxiliaryLedgerMethod *getInstance(const char* methodName);

	/** Typedef for the prototype (the key is a string).
	  */
	typedef sophis::tools::CSRPrototype<CSRAuxiliaryLedgerMethod
										,const char*
										,sophis::tools::less_char_star> prototype;
	
	/** Access to the prototype singleton.
	  *	use INITIALISE_AUX_LEDGER_METHOD to add a new AL method
	  *	@see tools::CSRPrototype
	  */
	static prototype& GetPrototype();
};


	} // namespace accounting
} // namespace sophis


SPH_EPILOG

#endif
