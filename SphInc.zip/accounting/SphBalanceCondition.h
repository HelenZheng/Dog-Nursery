#ifndef _SPH_BALANCE_CONDITION_H_
#define _SPH_BALANCE_CONDITION_H_


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"


SPH_PROLOG
namespace sophis {
	namespace accounting {

//class CSRDefinitionFlow;
//class CSRInstruction;

/** Defines a condition to apply an Accounting Balance Rule.
When the Accounting Balance engine is run, the appropriate balance rule is selected among the Account Entities rules.
In order to decide whether to select the balance rule, a Balance Condition is verified. If the balance condition is
respected, the balance rule is selected (from the Account Equities table).
For any balance rule in the Account Entities table, a condition can be specified on any of the columns Condition 1, Condition 2
and Condition 3.
*/
class SOPHIS_ACCOUNTING CSRBalanceCondition
{
public:
	/** Checks if this condition is satisfied in order for the Balance Engine to select a balance rule.
	@param date
	the date specified as the position date in the Price Dates configuration.
	@param entity
	the identifier of the account entity on which the Balance Rule in question is tested.
	Each balance rule among the rules to select is configured on one (or more) account entity(s).
	@return
	True, if this condition is satisfied, and therefore the balance rule is selected (as long as the other
	conditions are satisfied). False otherwise.
	By default, the condition is always statisfied regardless (returns True).
	*/
	virtual bool IsCorrect( const long date, const long entityId) {return true;}
	
//	Prototype stuff
	// Internal.
	virtual CSRBalanceCondition* Clone() const { throw 1; }

	// Internal.
	typedef sophis::tools::CSRPrototype<CSRBalanceCondition, const char *, sophis::tools::less_char_star> prototype;

	// Internal.
	static prototype& GetPrototype();
};

/** Macro to use when introducing a new Balance Condition.
The class which implements the new Balance Condition must derive from {@link accounting::CSRBalanceCondition}.
@param derivedClass
name of the class which implements the new balance condition.
@param name
the name of the new condition as it occurs on the Condition column in the Account Entities table.
*/
#define	INITIALISE_BALANCE_CONDITION(derivedClass, name) \
		PROTOTYPE_INSTALL(CSRBalanceCondition, derivedClass, name)

	}
}

SPH_EPILOG

#endif //_SPH_BALANCE_CONDITION_H_