/*
 	File:		SphChartOfAccount.h

 	Contains:	Class for the handling of account number.

 	Copyright:	 2003 Sophis.

*/
#pragma once
#ifndef _SphChartOfAccount_h_
#define _SphChartOfAccount_h_

#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(memory)

#include "SphInc/SphMacros.h"


//#define ACCOUNT_LENGTH			40
#define ADD_INSTRUMENT_LENGTH		40
#define ACCOUNT_NUMBER_LENGTH		80

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class CSRElement;
	}
	namespace portfolio
	{
		class CSRPosition;
		class CSRTransaction;
	}
	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
	namespace accounting
	{

		/** Data of the table ACCOUNT_NUMBER for one account ID.
		No constructor or destructor is available in this structure, nor in its derivatives.
		@since 4.5
		*/
		struct SSAcntMap //Used For input
		{
			long  accountingEntityID;
			long  accountID;
			long  allotmentID;
			long  bookID;
			long  currency;
			long  counterpartID;
			long  counterpartSite;
			long  credOrDeb;
			long  nostro_id;
		};

		/** Data returned to populate the account number for a posting.
		User has to derive it and add his own parameters, linked to
		the CSRElement to be described.
		*/
		struct SSResInitAcntNum
		{
			char	fAccountNumber[ ACCOUNT_NUMBER_LENGTH ] ;
			char	fAddInstrument[ ADD_INSTRUMENT_LENGTH ] ;
			int		fAddThirdParty ;
			int		fAccountType ;
		};

		typedef _STL::list<sophis::gui::CSRElement*> ListOfElements;

		/** @class CSRChartOfAccount
		You can overload this class and re-define the creation pointer.
		This class describes the SSResInitAcntNum. You can overload the structure and describe the new elements.
		You must also add the new fields in the table ACCOUNT_NUMBER.
		*/

		class SOPHIS_BO_KERNEL CSRChartOfAccount : public ListOfElements
		{
         public:

            static const char* __CLASS__;

			typedef ListOfElements::const_iterator cIterator;
			typedef ListOfElements::iterator Iterator;

			/** Create an instance of CSRChartOfAccount or a derived.
			@return a new instance which will be deleted using delete.
			By default, points on {@link CSRChartOfAccount::CreateBasicInstance}
			You can redirect the pointer, in order to create your own derivated class.
			It is called at the launch of each engine.
			*/
			static CSRChartOfAccount * (*GetInstance)();

            /**
            Return the number of fields.
             * This must be implemented in derived classes to return
			 * the number of new fields.
			 */
			virtual int GetExtraFieldCount() const;

			/** Method called by the trading engine to get an account.
			@param transaction holds the data of the trade being processed.
			@param input describes the input parameters.
			@param input describes the output parameters returned by {@link CSRChartOfAccount::GetAccountList}.
			@param underlying_id is the id of the instrument given by the trade amount, 0 for the balance amount.
			@return true if the account is found.
			@version 5.2.3 add a new parameter underlying_id.
			*/
			bool GetAccountForTradingEngine(const portfolio::CSRTransaction& transaction,
											const SSAcntMap &input,
											SSResInitAcntNum& output,
											long underlying_id );

			/** Method called by the p&l engine to get an account.
			@param position holds the data of the position being processed.
			@param input describes the input parameters.
			@param input describes the output parameters returned by {@link CSRChartOfAccount::GetAccountList}.
			@param underlying_id is the id of the instrument given by the amount.
			@return true if the account is found.
			@version 5.2.3 add a new parameter underlying_id.
			*/
			bool GetAccountForPnLEngine(const portfolio::CSRPosition& position,
										const SSAcntMap &input,
										SSResInitAcntNum& output,
										long underlying_id);


            /**
			 * Populates the internal map of new CSRElements, which is
			 * used in various private methods.
			 *
			 * @returns true if CSRElements we found, otherwise false.
			 */
			bool initElements();

            /**
			 * If we want to build a CSRElement list and use it outside
			 * this class then set OrphanCSRElements() to true, otherwise the
			 * class keeps ownership of the list and deletes it in its dtor().
			 */
			static void OrphanCSRElements(bool status = true);

			/**
             * Get the size of a CSRElement field, if index is ebd() then the
			 * combined size of all elements is returned, otherwise only the
			 * indexed elements size is returned. First element is at position
			 * 0.
			 *
			 * @index the element we are interested in or all.
			 * @return the size.
			 * @throws InvalidRangeException if range is not valid.
			 */
            long getExtraFieldSize(cIterator index/* = end()*/);

			const sophis::gui::CSRElement* operator[](int i) const;

			/** Destructor.
			*/
			virtual ~CSRChartOfAccount();				
		protected:
			virtual sophis::gui::CSRElement* new_FieldElement(int i) const;


			/** Get the list of accounts matching the transaction.
			@param input describes the input parameters as selected in the database
			and matching Sophis default criteria, including the user's new fields.
			@param count is the size of the input array.
			@param output is the buffer to return the output data. Must be completed by the
			user.
			@param underlying_id is the id of the instrument given by the amount of trade or balance.
			@return true if data was found, otherwise false.
			By default, call the deprecated method whose output is to populate the first line of the input array.
			@version 5.2.3 add a new parameter underlying_id.
			*/
			virtual bool GetAccountList(const portfolio::CSRTransaction& transaction,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output,
										long underlying_id) const ;

			/** Get the list of accounts matching the position.
			@param input describes the input parameters as selected in the database,
			matching Sophis default criteria, including the user's new fields.
			@param count is the size of the input array.
			@param output is the buffer to return the output data. Must be filled by the
			user.
			@param underlying_id is the id of the instrument given by the amount of p&l.
			@return true if data was found, otherwise false.
			By default, call the deprecated method whose output is to populate the first line of the input array.
			@version 5.2.3 add a new parameter underlying_id.
			*/
			virtual bool GetAccountList(const portfolio::CSRPosition& position,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output,
										long underlying_id) const ;

			/** Get the list of accounts matching the transaction.
			@param input describes the input parameters as selected in the database
			and matching Sophis default criteria, including the user's new fields.
			@param count is the size of the input array.
			@param output is the buffer to return the output data. Must be completed by the
			user.
			@param underlying_id is the id of the instrument given by the amount of trade or balance.
			@return true if data was found, otherwise false.
			By default, call the deprecated method whose output is to populate the first line of the input array.
			@version 5.2.3 add a new parameter underlying_id.
			@version 6.3.7 add a new parameter const SSAcntMap &acntMap,
			*/
			virtual bool GetAccountList(const portfolio::CSRTransaction& transaction,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output,
										long underlying_id,
										const SSAcntMap &acntMap) const ;

			/** Get the list of accounts matching the position.
			@param input describes the input parameters as selected in the database,
			matching Sophis default criteria, including the user's new fields.
			@param count is the size of the input array.
			@param output is the buffer to return the output data. Must be filled by the
			user.
			@param underlying_id is the id of the instrument given by the amount of p&l.
			@return true if data was found, otherwise false.
			By default, call the deprecated method whose output is to populate the first line of the input array.
			@version 5.2.3 add a new parameter underlying_id.
			@version 6.3.7 add a new parameter const SSAcntMap &acntMap,
			*/
			virtual bool GetAccountList(const portfolio::CSRPosition& position,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output,
										long underlying_id,
										const SSAcntMap &acntMap) const ;


			/// Only derived classes can instanciate this
			CSRChartOfAccount();

		private:

            /**
			 * Build a string of comma seperated column names to be used internally
			 * in a query. The prefix if specified is used as "prefix.column" to
			 * allwo the use of multiple tables.
			 *
			 * @retval columString the comma-seperated column list
			 * @params the optional column name prefix.
			 */
			 void buildExtraColumnNames(_STL::string& columString, const _STL::string& prefix = "");
			/**
			 * Get the default SELECT query string include  additional columns.
			 */
			 void getDefaultQuery(_STL::string&resultQuery, const _STL::string&ExtraColumns) const;

			bool initializeQuery();

			bool executeQuery(const SSAcntMap& param, SSResInitAcntNum *&results, int &count);

            void setupDefaultInputParams(sql::CSRStructureDescriptor*& descPar);

			/**
			 * Invoked by the dtor() to cleanup any allocated data.
			 */
			void destroy();

			/** Add cursors for the query in GetAccountList. */
			sql::CSRSqlQuery	*fQueryTradingEngine;

			/** Create an instance of CSRChartOfAccount.
			@return a new instance which will be deleted using delete.
			*/
			static CSRChartOfAccount* CreateBasicInstance();
			
			static bool fOrphanCSRElements;

			bool fInitialized;

			/** 
			@deprecated 5.2.3 use the new one.
			*/
			virtual bool GetAccountList(const portfolio::CSRTransaction& transaction,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output) const ;
			/** 
			@deprecated 5.2.3 use the new one.
			*/
			virtual bool GetAccountList(const portfolio::CSRPosition& position,
										const SSResInitAcntNum* input, int count,
										SSResInitAcntNum& output) const ;
		};
}
}

SPH_EPILOG

#endif




