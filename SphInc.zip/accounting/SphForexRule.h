#ifndef SPH_FOREX_RULE_H
#define SPH_FOREX_RULE_H


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_FOREX_RULE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRForexRule)
#define CONSTRUCTOR_FOREX_RULE(derivedClass)
#define WITHOUT_CONSTRUCTOR_FOREX_RULE(derivedClass)
#define	INITIALISE_FOREX_RULE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRPosition;
		class CSRTransaction;
	}

	namespace accounting
	{

		/** Interface to convert an accounting amount in one currency to another one.
		This is used by the p&l, balance and trade accounting engine, to know what figures
		to populate in amount field in account_posting table.
		@since 4.2.1
		*/
		class SOPHIS_ACCOUNTING CSRForexRule
		{
		public:

			/** Trivial constructor.
			*/
			CSRForexRule();

			/** Trivial destructor.
			*/
			virtual ~CSRForexRule() {}

			/** Method called by the trade and balance engine to convert an amount.
			@param amount is the original amount given by {@link CSRPostingAmountForTrade::get_posting_amount} for the trade engine
			or the balance of the account for the balance engine.
			@param currency_amount is the currency of the original amount given by {@link CSRPostingAmountForTrade::get_posting_amount} for the trade engine
			or the currency of the account for the balance engine.
			@param new_currency is the currency to convert the original amount.
			@param trade is the original trade; for the balance engine, a pseudo trade is created with the data which has been possible to capture
			from the accounts to balance.
			@param notYetFixed is an output parameter to specify that the fixing is not done yet and the trade has to be shooted again.
			@param date gives the date choosed in the transaction rule. May be null.
			Note that you must not put the flag to false if the fixing is done, only put it to true when the fixing is not done. 
			Indeed, the flag comes with previous values.
			@return the amount in the new currency. By default, use the fx of the FO position.
			@version 6.2 Add a parameter date.
			@version 5.3.6 Add a parameter notYetFixed.
			@version 4.5.0 field useTrade is deprecated.
			*/
			virtual double get_amount(	double	amount,
										long	currency_amount,
										long	new_currency,
										const	portfolio::CSRTransaction& trade,
										bool	&notYetFixed,
										long	date) const = 0;


			/** Method called by the p&l engine to convert an amount.
			@param amount is the original amount given by by the return of{@link CSRPostingAmountForPNL::get_posting_amount}.
			@param currency_amount is the currency of the original amount given by output parameter currency of {@link CSRPostingAmountForTrade::get_posting_amount}.
			@param new_currency is the currency to convert the original amount.
			@param position is the position in the portfolio.
			*/
			virtual double get_amount(	double	amount,
										long	currency_amount,
										long	new_currency,
										const	portfolio::CSRPosition& position	) const = 0 ;

			/** Get the singleton for one forex rule.
			This is equivalent to CSRForexRule::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the amount name is not found.
			@param amountName is a C string for the forex rule.
			@param forexPlace is a place id for the forex to choose.
			@return a pointer which must not be deleted but can be null.
			@version 5.3.6 new parameter forex place
			*/
			static CSRForexRule* getInstance( const char* modelName, long forexPlace ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_FOREX_RULE.
			@see tools::CSRPrototype
			*/
			virtual CSRForexRule* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRForexRule, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a forex rule to this singleton, use INITIALISE_FOREX_RULE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** call this method when you want to invalidate the cache.
			This is generally called when starting p&l engine or instruction to oblige to find 
			the forex in the database.
			@since 5.3.6
			*/
			static void InvalidCache();

		protected:
			/** Forex place to use. 
			By default 0 and it is initialized by {@link getInstance}/
			@since 5.3.6
			*/
			long	fForexPlace;

			/** Global cache count.
			This is incremented by InvalidCache and may be used to be compare to a counter of your cache.
			@since 5.3.6
			*/
			static long	gCachCount;

			#ifdef SOPHIS_DEPRECATED
			/** 
			@deprecated 5.3.6 Overload the new method.
			*/
			virtual double get_amount(	double	amount,
				long	currency_amount,
				long	new_currency,
						const	portfolio::CSRTransaction& trade,
						bool	useTrade ) const;
			#endif
		} ;
	}
}

SPH_EPILOG

#endif // SPH_FOREX_RULE_H
