#ifndef SPH_POSTING_AMOUNT_FOR_PNL_H
#define SPH_POSTING_AMOUNT_FOR_PNL_H


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphPostingAmountInfo.h"

#define DECLARATION_POSTING_AMOUNT_FOR_PNL(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRPostingAmountForPNL)
#define CONSTRUCTOR_POSTING_AMOUNT_FOR_PNL(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_AMOUNT_FOR_PNL(derivedClass)
#define	INITIALISE_POSTING_AMOUNT_FOR_PNL(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

#define DECLARATION_POSTING_AMOUNT_FOR_EOY(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRPostingAmountForEOY)
#define CONSTRUCTOR_POSTING_AMOUNT_FOR_EOY(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_AMOUNT_FOR_EOY(derivedClass)
#define	INITIALISE_POSTING_AMOUNT_FOR_EOY(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRPosition;
		class CSRTransaction;
	}

	namespace accounting
	{

		/** Interface to create a posting amount from a position.
		It is used as a amount for a p&l rule.
		You can implement this interface to add an amount on the list.
		@since 4.2.1
		*/
		class SOPHIS_ACCOUNTING CSRPostingAmountForPNL
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingAmountForPNL() {}

			/** Lock the amount to start or end date
			Method called by the p&l engine to determine of the posting should be locked at a start or end date
			during forecasting
			@returns 0, 1, or 2. 0 = No date locking, 1 = lock at start date, 2 = lock and end date
			*/
			virtual int get_amount_date_lock();

			/** Get the amount to post.
			Method called by the p&l engine to calculate the amount to post before conversion in the currency.
			@param position is the position in the portfolio to get the amount.
			@param currency is code of currency of amount for posting; the amount posted can be converted
			according the currency wanted in the accounting rule.
			@param instrument is code of instrument for this posting; it is used to find the account in the chart.
			@returns amount for this posting.
			@see CSRForexRule
			*/
			virtual double get_posting_amount(	const portfolio::CSRPosition& position,
												long* currency,
												long* instrument ) const = 0 ;

			/** Vector version of 'double get_posting_amount(...)' function
			*/
			virtual void get_posting_amount(const portfolio::CSRPosition& position
											,sophis::backoffice_kernel::VTAccAmountInfo& amountInfo);

			/** Get the singleton for one amount.
			This is equivalent to CSRPostingAmountForPNL::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the amount name is not found.
			@param amountName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingAmountForPNL* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_AMOUNT_FOR_PNL.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingAmountForPNL* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingAmountForPNL, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_AMOUNT_FOR_PNL.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;


		/** Interface to create a posting amount from a position.
		It is used as a amount for a EOY.
		You can implement this interface to add an amount on the list.
		@since 7.1
		*/		
		struct SOPHIS_ACCOUNTING InputData
		{
			long	fAccountNameID;			
			long	fAccountingBookID;
			long	fAccountCurrency;			
			long	fCurrency;
			long	fThirdParty;
			double	fAmount;
			double	fAmountOriginal;			
			long	fEntityID;
			long	fAuxiliaryID;

			InputData();
		};
		struct SOPHIS_ACCOUNTING TBalanceAmountEOY
		{
			double Amount;
			double AmountOriginal;
		};
		class SOPHIS_ACCOUNTING CSRPostingAmountForEOY
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSRPostingAmountForEOY() {}

			/** Get the amount to post.
			Method called by the EoY engine to calculate the amount.
			@param inputData is the InputData get the amount in account postings.
			@out param balanceAmount is amount for EOY;
			@returns true if balance amount is calculated properly.
			*/
			virtual bool get_posting_amount(const InputData& inputData, TBalanceAmountEOY& balanceAmount) = 0 ;

			/** Get the singleton for one amount.
			This is equivalent to CSRPostingAmountForEOY::GetPrototype().GetData(modelName).
			except that exception is caught to return 0 if the amount name is not found.
			@param modelName is a C string for the Instance.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingAmountForEOY* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_AMOUNT_FOR_EOY.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingAmountForEOY* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingAmountForEOY, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_AMOUNT_FOR_EOY.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}

SPH_EPILOG

#endif // SPH_POSTING_AMOUNT_FOR_PNL_H
