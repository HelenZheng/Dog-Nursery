#pragma once

#ifndef _SPH_POSTINGDATESETTLEMENT_H_
#define _SPH_POSTINGDATESETTLEMENT_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_POSTING_DATE_SETTLEMENT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRPostingDateSettlement)
#define CONSTRUCTOR_POSTING_DATE_SETTLEMENT(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_DATE_SETTLEMENT(derivedClass)
#define	INITIALISE_POSTING_DATE_SETTLEMENT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)


SPH_PROLOG

namespace sophis
{
	namespace backoffice_cash
	{
		class CSRInstruction;
	}
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace accounting
	{

		/** Interface to create a date amount from an instruction.
		It is used as a date for a settlement rule.
		You can implement this interface to add a date on the list.
		@see CSRPostingAmountForSettlement
		@see CSRRulesThirdPartyType
		@see CSRPostingToDoIf
		@since 4.5.0
		*/
		class SOPHIS_ACCOUNTING CSRPostingDateSettlement
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingDateSettlement() {}

			/** Get the date to post.
			Method called by the settlement engine in the BOWS server to calculate the date to post.
			@param instruction is the instruction of settlement treated by the BOWS.
			@param trade is the original transaction corresponding to the instruction.
			@returns the date in number of days from 1/1/1904 for this posting.
			*/
			virtual long get_posting_date(	const backoffice_cash::CSRInstruction &instruction,
											const portfolio::CSRTransaction& trade ) const = 0;


			/** Get the singleton for one settlement date.
			This is equivalent to CSRPostingDateSettlement::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the date name is not found.
			@param modelName is a C string for the date.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingDateSettlement* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_DATE_SETTLEMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingDateSettlement* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingDateSettlement
					,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_DATE_SETTLEMENT.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}

SPH_EPILOG

#endif // _SPH_POSTINGDATESETTLEMENT_H_
