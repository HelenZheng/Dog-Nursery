#pragma once

#ifndef _SPH_RULESCONDITION_H_
#define _SPH_RULESCONDITION_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_RULES_CONDITION_TRANSACTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRRulesConditionTransaction)
#define CONSTRUCTOR_RULES_CONDITION_TRANSACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_RULES_CONDITION_TRANSACTION(derivedClass)
#define	INITIALISE_RULES_CONDITION_TRANSACTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

#define DECLARATION_RULES_CONDITION_POSITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::accounting::CSRRulesConditionPosition)
#define CONSTRUCTOR_RULES_CONDITION_POSITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_RULES_CONDITION_POSITION(derivedClass)
#define	INITIALISE_RULES_CONDITION_POSITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG

namespace sophis
{
	namespace portfolio
	{
		class CSRPosition;
		class CSRTransaction;
	}

	namespace accounting
	{

		/** Interface to create a condition for the accounting trade engine.
		It is used as a condition to know if a transaction rule has to be applied.
		You can implement this interface to add a condition on the list.
		@since 4.2.1
		@see CSRPostingToDoIf
		*/
		class SOPHIS_ACCOUNTING CSRRulesConditionTransaction
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSRRulesConditionTransaction() {}

			/** Tell if the rule applied according the condition.
			This is called by the accounting trade engine to know if a trade rules has to
			be applied after all the other criteria matches.
			@param trade is the transaction to generate posting.
			@return true if the rule has to be applied.
			*/
			virtual bool get_condition( const portfolio::CSRTransaction& trade ) const = 0;

			/** Get the singleton for one settlement date.
			This is equivalent to CSRRulesConditionTransaction::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the condition name is not found.
			@param modelName is a C string for the condition.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRRulesConditionTransaction* getInstance( const char* modelName );

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_RULES_CONDITION_TRANSACTION.
			@see tools::CSRPrototype
			*/
			virtual CSRRulesConditionTransaction* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRRulesConditionTransaction
												,const char*
												,sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_RULES_CONDITION_TRANSACTION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;



		/** Interface to create a condition for the accounting p&l engine.
		It is used as a condition to know if a p&l rule has to be applied.
		You can implement this interface to add a condition on the list.
		@since 4.2.1
		@see CSRPostingToDoIfPosition
		*/
		class SOPHIS_ACCOUNTING CSRRulesConditionPosition
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRRulesConditionPosition() {}

			/** Tell if the rule applied according the condition.
			This is called by the accounting p&l engine to know if a p&l rules has to
			be applied once all the other criteria matches.
			@param position is the position to generate posting.
			@return true if the rule has to be applied.
			*/
			virtual bool get_condition( const portfolio::CSRPosition& position ) const = 0;

			/** Get the singleton for one settlement date.
			This is equivalent to CSRRulesConditionPosition::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the condition name is not found.
			@param modelName is a C string for the condition.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRRulesConditionPosition* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_RULES_CONDITION_POSITION.
			@see tools::CSRPrototype
			*/
			virtual CSRRulesConditionPosition* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRRulesConditionPosition
												,const char*
												,sophis::tools::less_char_star> prototype;
			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_RULES_CONDITION_POSITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;


	}
}

SPH_EPILOG

#endif // _SPH_POSTINGDATESETTLEMENT_H_
