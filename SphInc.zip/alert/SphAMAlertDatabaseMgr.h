#pragma once

#ifndef _SPH_AM_DB_ALERT_H_
#define _SPH_AM_DB_ALERT_H_

#include "SphInc/alert/SphAlertWindowExports.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)

namespace sophis 
{
	namespace alert 
	{

		enum EAlertLevel
		{
			asLow,
			asMedium,
			asHigh,
			asBlocking
		};

		struct SOPHIS_ALERT_WINDOW AlertCount
		{
			long nbLow;
			long nbMedium;
			long nbHigh;
			long nbBlocking;

			AlertCount();
			AlertCount operator +=(const AlertCount& ac);
		};

		// internal
		struct aCount
		{
			long count;
			long level;
			char sourceName[40];
		};

		enum EActionType
		{
			atNoAction,
			atTransaction,
			atInstrument,
			atFolio
		};

		struct DbAlertLine
		{
			long alertID;
			char source[40];
			long fundID;
			char container[40];
			long eventDate;
			long eventID;
			EAlertLevel level;
			EActionType actionType;
			char message[256];

			bool operator < (const DbAlertLine& dba) const{return alertID<dba.alertID;}
		};

		typedef _STL::map<_STL::string, AlertCount> AlertCountMap;

		// This is only intended to compute the nb of alert stored in for each source in the AM_ALERT database
		// the instance is refreshed for each AMAlertUpdate event.
		class SOPHIS_ALERT_WINDOW CSRDBAlertCounter
		{
		public:

			CSRDBAlertCounter();

			/* Singleton specifics */
			static CSRDBAlertCounter*	GetInstance();

			void updateMap();

			AlertCount GetSourceCount(const char * sourceName);

		protected:
			AlertCountMap fAlertCounts;
			static CSRDBAlertCounter* fInstance;
		};


		/** Class to collect multiple alerts in the database.
		* this class is also intended to add/delete alerts in the database
		* and insure the coherence of the base.
		*/

		typedef _STL::map<long, DbAlertLine> DbAlertMap;
		class SOPHIS_ALERT_WINDOW CSAMAlertDatabaseMrg
		{
		public:
			// Load all alerts stored in the database
			CSAMAlertDatabaseMrg(long beginDate=-1, long endDate=-1);

			// Load all alerts stored in the database that respect the specified filter
			// date = -1 mean no limit
			CSAMAlertDatabaseMrg(_STL::string source,long beginDate=-1, long endDate=-1);

			// Add an alert
			// if ok sent an 
			static void AddAlert(_STL::string source, long fundID, _STL::string container, long eventDate, long eventID, EAlertLevel level, EActionType actiontype, _STL::string message);

			// Delete an alert
			static void DeleteAlert(long AlertID);

			// Update the instance to take into account a database modification
			// Can be use on event reception
			void UpdateAlert(long AlertID)const;

			// This method clear all data, update the parameters and load new alert set
			void UpdateParameters(_STL::string source ,long beginDate=-1, long endDate=-1);

			// Main loading methods
			void Load();
			void Clear();

		public:
			DbAlertMap fData;

		private:
			_STL::string fFilterSource;
			long fBeginDate;
			long fEndDate;
		};
	}
}

#endif
