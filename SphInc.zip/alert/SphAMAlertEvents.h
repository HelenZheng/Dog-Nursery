/********************************************************************
*	@date		:	20.12.2007
*
*	@file		: 	SphAMAlertEvents.h
*	
*	@purpose	:	Events for alert window
*	
*/

#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPHAM_Alert_Events_H_
#define _SPHAM_Alert_Events_H_


namespace sophis	
{
	namespace alert	
	{
		enum eAlertEvent 
		{
		   aeAlertUpdate			= 'aevt'	// Alert added or removed
		   ,aeAlertSourceProp		= 'aspr'	// Alert sources properties modified
		};
	}
}
#endif
