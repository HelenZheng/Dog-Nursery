#pragma once

#ifndef _SPH_AM_ALERT_H_
#define _SPH_AM_ALERT_H_

#include <SphTools/SphPrototype.h>
#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"
#include "SphTools/sphvector.h"
#include "SphInc/alert/SphAMAlertDatabaseMgr.h"
#include "SphInc/alert/SphAlertWindowExports.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(memory)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(set)

#include "SphInc/tools/SphAlgorithm.h"

#define DECLARE_AM_ALERT_SOURCE(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::alert::CSAMAlertSource)
#define CONSTRUCTOR_AM_ALERT_SOURCE(derivedClass)
#define WITHOUT_CONSTRUCTOR_AM_ALERT_SOURCE(derivedClass)
#define	INITIALISE_AM_ALERT_SOURCE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

# ifndef GCC_XML
BOOST_INCLUDE_BEGIN
#  include BOOST_INCLUDE_PATH(variant.hpp)
#  include BOOST_INCLUDE_PATH(unordered_map.hpp)
BOOST_INCLUDE_END
# else
#  include __STL_INCLUDE_PATH(unordered_map)
# endif GCC_XML


namespace sophis {
	namespace event {
		class ISEvent;
	}

	namespace alert {

		/** Actions to be requested of the AM alert book window on reception
		* of a coherency event. */
		enum AlertEventAction
		{
			NoAction,
			RebuildReport
		};


		/** Alert Event Id for  */
		class SOPHIS_ALERT_WINDOW AlertEventID
		{
		public:
			/////////////
			// Typedef //
			/////////////

		# ifndef GCC_XML 
			// Not supported by GCC_XML
			
			typedef boost::variant<long, 
									portfolio::TransactionIdent> ObjectId;
		# endif GCC_XML

		    //////////////////
			// Constructors //
			//////////////////

			/// Default constructor 
			AlertEventID();

			/// Constructors with specific types used by the vairant
			/// They are used for DotNetToolkit
			AlertEventID(const long& ident);
			AlertEventID(const portfolio::TransactionIdent& ident);

		# ifndef GCC_XML
			//// Constructor with the variant, not supported by DotNetToolkit
			AlertEventID(const ObjectId& ident);
		# endif GCC_XML

			////////////////
			// Accesssors //
			////////////////

			/// Specific type accessors for DotNetToolkit
			long GetLong() const;
			portfolio::TransactionIdent GetTransactionIdent() const;

		# ifndef GCC_XML

			/// Accessor not supported by the DotNetToolkit
			const ObjectId& Get() const;

			///////////////
			// Operators //
			///////////////


			template <typename Visitor>
			typename Visitor::result_type apply_visitor(const Visitor& visitor) const
			{
				return fObjectId.apply_visitor(visitor);
			}

			template <typename Visitor>
			typename Visitor::result_type apply_visitor(const Visitor& visitor)
			{
				return fObjectId.apply_visitor(visitor);
			}

			template <typename Type>
			Type get() const
			{
				return boost::get<Type>(fObjectId);
			}


		# endif GCC_XML

			/// Comparisons
			bool operator==(const AlertEventID& object_id) const;
			bool operator<(const AlertEventID& object_id) const;


		private:

	# ifndef GCC_XML 
			ObjectId fObjectId;
	# endif GCC_XML 
		};

# ifndef GCC_XML 

	} // namespace alert
} // namespace sophis


// Helper function, not needed for gcc_xml
namespace boost {
	template <typename Type>
	Type get(const sophis::alert::AlertEventID& object)
	{
		return object.get<Type>();
	}
}

namespace sophis {
namespace alert {

# endif GCC_XML

		struct AlertValue
		{
			long alertID;
			long eventDate;
			AlertEventID eventID;
			EActionType actionType;
			EAlertLevel level;
			_STL::string message;
		};

		enum eCriticityLevel
		{
			clAlways,
			clLow,
			clMedium,
			clHigh,
			clBlocking,
			clNever
		};

		enum eSourceAvailibility
		{
			saAvailable, // source available in status bar and alert window
			saNotInStatusBar, // source displayed in the alert window, not in the status bar
			saNotAvailable // source ignored
		};

		typedef _STL::vector<AlertValue> AlertValues;
		typedef _STL::shared_ptr<AlertValues> AlertValuesHandle;
		typedef _STL::shared_ptr<const AlertValues> AlertValuesConstHandle;

		// An alert source container will handle alerts for the alert book, in addition to the source itself
		class SOPHIS_ALERT_WINDOW CSRAlertContainer
		{
		public:

			CSRAlertContainer(_STL::string name);

			void AddAlert(long eventDate, 
			              AlertEventID eventID, 
			              EAlertLevel severity, 
			              const char* message, 
			              EActionType 
			              actionType=atNoAction, 
			              long alertID=0);

			// Getters
			_STL::string GetAlertContainerName() const {return fName;}
			AlertValuesConstHandle GetAlertValues() const {return fData;}
			AlertValuesHandle GetAlertValues() {return fData;}

		protected:
			_STL::string fName;
			AlertValuesHandle fData;
		};

		typedef _STL::vector<CSRAlertContainer> AlertContainers;

		/**
		*	An alert source can add its own alert to the AM Alert book 
		*   theses alerts can be define for a specific extraction portfolio if needed.
		*	
		*/
		class SOPHIS_ALERT_WINDOW CSAMAlertSource
		{

		public:
			CSAMAlertSource();

			// Get the alerts for a portfolio
			virtual void GetAlerts(const _STL::set<long> &portfolioIds, AlertContainers &alerts);

			// Called on window exit
			// useful to clean objects created during the alert generation
			virtual void Clean(){}

			virtual AlertEventAction HandleEvent(const sophis::event::ISEvent& event, const _STL::set<long>& fund_codes) const;

			// Should return the quantity of each status alert
			// This have to be very fast as it's called by the status bar, no long process can be done there
			// If long process are compulsory, then the update frequency can be change so the source won't
			// slow down the whole client
			virtual AlertCount GetAlertCount() const;

			// Getters
			long GetStatusBarUpdateFrequency() const {return fRefreshPeriod;}
			eSourceAvailibility GetAvailability() const {return fAvailable;}
			eCriticityLevel GetCriticityLevel() const {return fCriticityLevel;}

			// Setters
			void SetStatusBarUpdateFrequency(long frequency) {fRefreshPeriod = frequency;}
			void SetAvailable(eSourceAvailibility avail) {fAvailable = avail;}
			void SetCriticityLevel(eCriticityLevel level) {fCriticityLevel = level;}

			typedef sophis::tools::CSRPrototype<CSAMAlertSource, const char*, sophis::tools::less_char_star> prototype;
			static prototype& GetPrototype();

		protected:
			// Status bar (which call GetAlertCount()) update frequency in seconds , can't be less than 5 seconds
			long				fRefreshPeriod; 

			// Source availabitity : determine if the source is taken into account by the alert window and the status bar
			eSourceAvailibility	fAvailable;

			// Criticity level of the source
			// If an alert level > criticity level, it will trigger a visible alert
			eCriticityLevel		fCriticityLevel;
		};
	}
}

#endif
