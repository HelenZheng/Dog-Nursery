#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPH_AM_ALERT_SOURCE_GUI_H_
#define _SPH_AM_ALERT_SOURCE_GUI_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/alert/SphAlertWindowGUIExports.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(string)

#include  "SphInc/tools/SphAlgorithm.h"

#define DECLARE_AM_ALERT_SOURCE_GUI(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::alert::CSAMAlertSourceGUI)
#define CONSTRUCTOR_AM_ALERT_SOURCE_GUI(derivedClass)
#define WITHOUT_CONSTRUCTOR_AM_ALERT_SOURCE_GUI(derivedClass)
#define	INITIALISE_AM_ALERT_SOURCE_GUI(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

namespace sophis
{
	namespace alert
	{
		struct AlertValue;

		/*	Class to handle the GUI behaviour of an alert source
		*/
		class SOPHIS_ALERT_WINDOW_GUI CSAMAlertSourceGUI
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSAMAlertSourceGUI() {}

			// Display an alert
			// user have to double click on a particular line to display the alert
			// @param sourceName is the name of the source
			// @param sourceType is the container of the alert (this is supply by the source itself)
			// @param alert is the values of the alert, the most important value is the event id that should allow
			// the source to identifie the data to display (refcon for a mvt or sicovam for an instrument for instance)
			// return true if everything went ok
			virtual bool DisplayAlert(_STL::string sourceName, _STL::string sourceType, const AlertValue& alert)= 0;

			static CSAMAlertSourceGUI* GetInstance(_STL::string sourceName);
			virtual CSAMAlertSourceGUI* Clone() const = 0;

			typedef sophis::tools::CSRPrototype<CSAMAlertSourceGUI, const char*, sophis::tools::less_char_star> prototype;
			static prototype& GetPrototype();
		} ;
	}
}

#endif // _SPH_AM_ALERT_SOURCE_GUI_H_