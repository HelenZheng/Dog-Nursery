#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SphAlertWindowExports_H_
#define _SphAlertWindowExports_H_

#ifdef _WIN32
#	ifdef SOPHIS_ALERT_WINDOW_EXPORTS
#		define SOPHIS_ALERT_WINDOW __declspec(dllexport)
#	else
#		define SOPHIS_ALERT_WINDOW __declspec(dllimport)
#	endif
#else
#	define SOPHIS_ALERT_WINDOW
#endif

#endif