#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SphAlertWindowGUIExports_H_
#define _SphAlertWindowGUIExports_H_

#ifdef _WIN32
#	ifdef SOPHIS_ALERT_WINDOW_GUI_EXPORTS
#		define SOPHIS_ALERT_WINDOW_GUI __declspec(dllexport)
#	else
#		define SOPHIS_ALERT_WINDOW_GUI __declspec(dllimport)
#	endif
#else
#	define SOPHIS_ALERT_WINDOW_GUI
#endif

#endif