#ifndef SPH_BO_ACTION_DIALOG
#define SPH_BO_ACTION_DIALOG


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/SphMacros.h"

#include "SphInc/gui/SphDialog.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		class SOPHIS_BO_CASH CSRBOActionDialog : public sophis::gui::CSRFitDialog
		{
		public:
			CSRBOActionDialog();
			~CSRBOActionDialog() = 0;

			virtual void Initialise(const sophis::backoffice_cash::CSRInstruction& instruction);
			virtual	void Open() = 0;
			virtual	Boolean	Close();

			static const char* GetDefaultDialogName();
			static const char* GetExternalEventDefaultDialogName();

		//	Prototype stuff
			virtual sophis::gui::CSRFitDialog* Clone() const { throw 1; }
			typedef sophis::tools::CSRPrototype<sophis::gui::CSRFitDialog, _STL::string> prototype;
			static prototype& GetPrototype();
			const sophis::backoffice_cash::CSRInstruction& GetInstruction();

		protected:
			sophis::backoffice_cash::CSRInstruction	fInstruction;

		};
	}
}
SPH_EPILOG
#endif // SPH_BO_ACTION_DIALOG
