#ifndef SPH_BO_ACTION_DUAL_DIALOG
#define SPH_BO_ACTION_DUAL_DIALOG


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialog.h"
#include "SphInc/backoffice_cash/SphInstruction.h"

#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		class SOPHIS_BO_CASH CSRBOActionDualDialog : public sophis::gui::CSRFitDialog
		{
		public:
			CSRBOActionDualDialog();
			~CSRBOActionDualDialog() = 0;

			virtual void Initialise(sophis::backoffice_cash::CSRInstruction& instruction1,
									sophis::backoffice_cash::CSRInstruction& instruction2);
			virtual	void Open() = 0;

			static const char* GetDefaultDialogName();

		//	Prototype stuff
			virtual sophis::gui::CSRFitDialog* Clone() const { throw 1; }
			typedef sophis::tools::CSRPrototype<sophis::gui::CSRFitDialog, _STL::string> prototype;
			static prototype& GetPrototype();

		protected:
			sophis::backoffice_cash::CSRInstruction fInstruction1;
			sophis::backoffice_cash::CSRInstruction fInstruction2;

		};
	}
}

SPH_EPILOG

#endif // SPH_BO_ACTION_DUAL_DIALOG