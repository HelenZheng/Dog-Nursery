/*
File:		SphBOCashColumn.h

Contains:	Class for the handling of Instruction columns

Copyright:	� 2006 Sophis.
*/
#pragma once

#ifndef _SphBOCashColumn_H_
#define _SphBOCashColumn_H_

#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

struct SSCellStyle;
union SSCellValue;


#define DECLARATION_BOCASH_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_cash::CSRBOCashColumn)
#define	INITIALISE_BOCASH_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name) 


namespace sophis	{
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_otc {
		class CSTransactionCacheMgr;
		class CSRMessage;
	}

	namespace backoffice_cash {
		class CSRInstruction;

		/** Used to pass extra data into the columns if needed. */
		class SOPHIS_BO_CASH CSBOCashRow
		{
		public:
			CSBOCashRow(_STL::string id, CSRInstruction::eInternalStatus initStatus);
			void SetUniqueID(_STL::string id);
			_STL::string GetUniqueID() const;
			bool GetInvalid() const;
			void SetInvalid(bool invalid);
			long GetSDepSelection() const;
			void SetSDepSelection(long dep);
			long GetRDepSelection() const;
			void SetRDepSelection(long dep);
			bool GetCancelToSendAgain();
			void SetCancelToSendAgain(bool val);
			// These functions will return the trade amount, trade quantity and trade nominal of the netted lines.
			// The summation must be done in the blotter.
			double GetTradeAmount();
			void SetTradeAmount(double amount);
			void AddToTradeAmount(double amount);
			double GetTradeQuantity();
			void SetTradeQuantity(double quantity);
			void AddToTradeQuantity(double quantity);
			CSRInstruction::eInternalStatus GetInitialStatus();
		private:
			bool fInvalid;
			_STL::string uniqueID; // Unique string identifying the instruction blotter.
			long sDepSelection;
			long rDepSelection;
			bool fCancelToSendAgain;
			double trade_amount;
			double trade_quantity;
			CSRInstruction::eInternalStatus initialStatus;
		};

		/** Base class CSBOCashData */
		class SOPHIS_BO_CASH CSBOCashData
		{
		public:
			CSBOCashData(const backoffice_otc::CSTransactionCacheMgr& transactionMgr);
			CSBOCashData(const backoffice_otc::CSTransactionCacheMgr& transactionMgr, CSBOCashRow& row);
			const backoffice_otc::CSTransactionCacheMgr& GetTransactionMgr() const;
			CSBOCashRow* GetBOCashRow() const;
			virtual ~CSBOCashData();
		protected:
			CSBOCashData();
			void Initialize(const backoffice_otc::CSTransactionCacheMgr& transactionMgr);
			void Initialize(const backoffice_otc::CSTransactionCacheMgr& transactionMgr, CSBOCashRow& row);
			const backoffice_otc::CSTransactionCacheMgr* fTransactionMgr;
			CSBOCashRow* fBOCashRow;
		};

		/** message specific data */
		class SOPHIS_BO_CASH CSMessageData : public virtual CSBOCashData
		{
		public:
			CSMessageData(const sophis::backoffice_otc::CSRMessage& msg,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr);

			CSMessageData(const sophis::backoffice_otc::CSRMessage& msg,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr,
				CSBOCashRow& row);
			const sophis::backoffice_otc::CSRMessage & GetMsg() const;
		protected:
			CSMessageData();
			void Initialize(const sophis::backoffice_otc::CSRMessage& msg,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr);

			void Initialize(const sophis::backoffice_otc::CSRMessage& msg,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr,
				CSBOCashRow& row);

			const sophis::backoffice_otc::CSRMessage* fMsg;
		};

		/** instruction specific data */
		class SOPHIS_BO_CASH CSInstrData : public virtual CSBOCashData
		{
		public:
			CSInstrData(const sophis::backoffice_cash::CSRInstruction& instr,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr);

			CSInstrData(const sophis::backoffice_cash::CSRInstruction& instr,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr,
				CSBOCashRow& row);
			const sophis::backoffice_cash::CSRInstruction & GetInstr() const;
		protected:
			CSInstrData();
			void Initialize(const sophis::backoffice_cash::CSRInstruction& instr,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr);
			void Initialize(const sophis::backoffice_cash::CSRInstruction& instr,
				const backoffice_otc::CSTransactionCacheMgr& transactionMgr,
				CSBOCashRow& row);
			const sophis::backoffice_cash::CSRInstruction* fInstr;
		};

		/** Interface to handle columns in Instruction blotters.
		To add a column, derive this class, using the macro DECLARATION_BOCASH_COLUMN in your header
		and INITIALISE_BOCASH_COLUMN in UNIVERSAL_MAIN.
		The main methods providing the values to display must have no MFC code.
		For example, you cannot show a dialog using CSRFitDialog::Message.
		This can produce error MFC messages or alter the window itself.
		Also note that use of the class {@link CSRSqlQuery} method to write certain
		queries. In the verbose mode, errors generate a dialog. It is better to disable
		the verbose mode using {@link CSRSqlQuery::SetVerbose} and to deal with the
		error code yourself.
		@see CSRPortfolioColumn
		@since 5.2.1
		*/
		class SOPHIS_BO_CASH CSRBOCashColumn
		{
		public:
			/** Main method to display the content of OTC message.
			@param data is the CSMessageData structure to be displayed.
			@param value is an output parameter, used to return the value to be displayed.
			@param style is an output parameter, used to describe the style and the data type.
			*/
			virtual	void	GetMsgCell(
				const CSMessageData		& data,
				SSCellValue				* value,
				SSCellStyle				* style) const = 0;

			/** Main method to display the content on netted line.
			@param data is the CSInstrData structure to be displayed.
			@param value is an output parameter, used to return the value to be displayed.
			@param style is an output parameter, used to describe the style and the data type.
			*/
			virtual	void	GetInstrCell(
				const CSInstrData		& data,
				SSCellValue				* value,
				SSCellStyle				* style) const = 0;

			/** Define the default size in pixels.
			*/
			virtual short	GetDefaultWidth() const;


			/** Icon id to display when grouping by that column.
			@return a short id corresponding to a resource bmp sith a shift of 1000.
			*/
			virtual short GetGroupIcon() const;


			/** Get the id .
			The value is created at the end of the initialise because it must
			be unique according to the table COLUMN_NAME.
			*/
			int GetId() const;

			/** Set the id.
			Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id);

			/** Check if a column is a popup column.
			 * @return true if it is a popup col, false otherwise. Default is false.
			*/
			virtual bool IsPopupCol() const;

			/** Used to get the popup menu
			 * @param menuItems: The list of items in the menu.
			 * @param data: The data to be displayed.
			 */
			virtual void GetPopupMenu(_STL::vector<_STL::string>& menuItems,  CSBOCashData& data);

			/** Called when the popup menu changes.
			 * @param data: The data to be displayed.
			 */
			virtual bool OnPopupMenuChange(CSBOCashData& data, int selection);
			
			/** Used to get the popup selection
			 * @param data: The data to be displayed.
			 * @return: the id of the selected item. 
			 */
			virtual long GetPopupSelection(CSBOCashData& data);

			/** Typedef for the prototype : the key is a const char *.
			*/
			typedef tools::CSRPrototypeWithId<CSRBOCashColumn, const char *, tools::less_char_star> prototype;
			/** Access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_INSTRUMENT_FACTORY
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

		protected:
			long	fId;
		};
	}
}

SPH_EPILOG

#endif
