#ifndef _SphBOSCPEnums_H_
#define _SphBOSCPEnums_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {

		const int HEADERLINE = 0;

		enum eSCPRowType 
		{
			sOrderedByClearerHeaderRow,
			sOrderedByInstrumentHeaderRow,
			sOrderedByUniversalHeaderRow,
			sClearerRow,
			sAccountRow,
			sCurrencyRow,
			sInstrumentRow,
			sUniversalRefRow,
			sFromTheClearerRow,
			sCurrentStockRow,
			sRemainingSettlementRow
		};
	}
}
SPH_EPILOG
#endif
