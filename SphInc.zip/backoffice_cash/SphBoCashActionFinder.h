#ifndef __CSRBOCashActionFinder__
#define __CSRBOCashActionFinder__
#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphBoCashWorkflowTypes.h"
#include "SphInc/backoffice_cash/SphBoCashException.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(map)



SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {

		class CSRInstruction;
		class CSRBOCashPerformActionException;
		class CSRBOCashInstrBuilderException;
		class CSRBOCashInstrCheckIRLException;
		class CSRBoCashExtraModifiedItemsManager;

	}
}

namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace tools
	{
		class CSREventVector;
	}
}

namespace CSRBOCashActionFinderHelper
{
	//public:
	static long MakeMask( long input, char mask_char );
	static long StripWildCard( long from );
	static char BOWS_WILD_CHAR = '*';
};

typedef _STL::map<long, _STL::string> MStatusNames;

class SOPHIS_BO_CASH CSRBOCashActionFinder
{
public:
	CSRBOCashActionFinder( const boWorkflowDefVector& possiblities, const boCashInstructEventVector& events );

	/*
	 * This method is the main one containing the logic. Other methods taking one or two instructions as parameters are derivating from this one.
	 * @param _bActionNeedsToUpdate is set to NULL in the particular case of the dual blotter.
	 * @param _bUseFinalStatus2 is set to true only in the particular case of the dual blotter.
	*/
	void performAction( 
		long Event, 
		sophis::backoffice_cash::CSRInstructionList& listInstruction, 
		sophis::tools::CSREventVector* _eventVector,
		bool* _bActionNeedsToUpdate,
		sophis::backoffice_cash::CSRBoCashExtraModifiedItemsManager* _extraModifiedItemsManager,
		bool _bUseFinalStatus2 = false )
		throw (sophis::backoffice_cash::CSRBOCashPerformActionException, sophis::backoffice_cash::CSRBOCashInstrBuilderException, sophis::backoffice_cash::CSRBOCashInstrCheckIRLException);

	const sophis::backoffice_cash::CSRDefinitionFlow& getActionById( long id ) const
		throw (sophis::backoffice_cash::CSRBOCashPerformActionException);

	/*
	* Finds an appropriate workflow rule in the workflow definition m_boWorkflow
	*
	* NOTE: Returns the rule for which the checkConditionsMatch() returns true.
	*		If cannot find such a rule, returns -1
	*/

	struct SKey {
		long event;
		long initialStatus1;
		long initialStatus2;
		long deliveryType;
		bool isSTP;
		SKey() 
			: event(-1)
			, initialStatus1(-1)
			, initialStatus2(-1)
			, deliveryType(-1)
			, isSTP(false) 
		{}
		SKey(long e, long i1, long i2, long dt, bool s) 
			: event(e)
			, initialStatus1(i1)
			, initialStatus2(i2)
			, deliveryType(dt)
			, isSTP(s) 
		{}
	};

	int findWorkflowRule(
		const SKey& _key, 
		const sophis::backoffice_cash::CSRInstructionList _instrList) const;

	//int findWorkflowRule(
	//	const SKey _key, 
	//	const sophis::backoffice_cash::CSRInstructionList _instrList,
	//	bool isSTP) const;

protected:
	int		findLine( long fromLine, const SKey& key ) const;

	void	LoadStatuses(void);
	bool	matches( int index, const SKey& key ) const;
	bool	CompareStatuses(long ruleStatus, const char *ruleEditStatus, long initialStatus) const;
	bool	checkConditionsMatch(
		const sophis::backoffice_cash::CSRDefinitionFlow& workFlow, 
		sophis::backoffice_cash::CSRInstructionList listInstruction) const;

	/*
	 * checkIRL is called by PerformAction, it calls CSRInstructionCheckIRL::prototype::IsOK() 
	 * @param checkName is the name of the CheckIRL prototype to use
	 * @param listInst is the list of instructions to check
	 * throws a CSRBOCashInstrCheckIRLException in case of failure to pass the check...
	 */
	void   checkIRL(const char* checkName,
					const sophis::backoffice_cash::CSRInstructionList _listInstruction)
					throw (sophis::backoffice_cash::CSRBOCashInstrCheckIRLException);

	boWorkflowDefVector	m_boWorkflow;
	boCashInstructEventVector m_boCashEvents;

	static MStatusNames	m_Statuses;
	static bool			m_StatusesLoaded;

protected:
	static const char* __CLASS__;
};


SPH_EPILOG



#endif __CSRBOCashActionFinder__