#pragma once

#include "SphInc/tools/SphValidation.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/backoffice_cash/SphBoCashException.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		typedef _STL::vector<CSRInstruction> CSRINSTRUCTION_COLLECTION;
		typedef CSRINSTRUCTION_COLLECTION::iterator    CSRINSTRUCTION_COLLECTION_ITER;

		class SOPHIS_BO_CASH CSRBoCashBatchMultipleAbstractEvent: public virtual sophis::tools::CSRAbstractEvent
		{
		public:
			CSRBoCashBatchMultipleAbstractEvent(){}
			~CSRBoCashBatchMultipleAbstractEvent(){}
			void initSourceEventVector(sophis::tools::CSREventVector* _v)
			{
				m_sourceEventVector = _v;
			}

			void addInstruction(const CSRInstruction& m) 
			{ 
				m_csrInstructionCollection.push_back(m); 
			}

			virtual void Send()
				throw (sophisTools::base::ExceptionBase);

			virtual void runSingle(const CSRInstruction* _m, 
								   sophis::tools::CSREventVector* _v)
								   throw (CSRBOCashException) = 0;

		private:
			void runBatch();
			CSRINSTRUCTION_COLLECTION m_csrInstructionCollection;
			
			//We might have to happen other events during the execution of our event...
			//So we keep a ref to the CSREventVector this event was part of:
			sophis::tools::CSREventVector *m_sourceEventVector;

			static const char* __CLASS__;

		};
	}
}

SPH_EPILOG