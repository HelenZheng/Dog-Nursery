#ifndef BO_CASH_EXCEPTION_H
#define BO_CASH_EXCEPTION_H

#pragma once
#include "SphInc/SphMacros.h"

#include "SphBOCashWorkflowTypes.h"
#include "SphTools/SphExceptions.h"
#include __STL_INCLUDE_PATH(string)

#include "SphSDBCInc/exceptions/SphOracleException.h"

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{

		class CSR_IM_Exception;

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashException
		{
		public:
			CSRBOCashException(const char* errMsgHeader, const CSRBOCashException& source);
			CSRBOCashException(const char* errMsgHeader, const CSR_IM_Exception& source);
			CSRBOCashException(const char* errMsgHeader, const sophisTools::base::ExceptionBase& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber,
				const long instrId, const long instrVersion, const sophis::portfolio::TransactionIdent tradeId, const long tradeVersion, const long messageId, const long workflowId, const long delieveryType);
			CSRBOCashException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			virtual ~CSRBOCashException();

			void AddErrorMessageHeader(const char* errMsgHeader);

			virtual const char* GetErrorMessage() const;
			virtual const _STL::string& GetErrorMessageString() const;
			virtual const char* GetClass() const;
			virtual const _STL::string& GetClassString() const;
			virtual const char* GetMethod() const;
			virtual const _STL::string& GetMethodString() const;
			virtual const char* GetFile() const;
			virtual const _STL::string& GetFileString() const;
			virtual const char* GetSource() const;
			virtual const _STL::string& GetSourceString() const;
			virtual long GetLine() const;
			virtual const _STL::string GetString() const;

		protected:
			virtual const _STL::string GetEnvironmentString() const;
			virtual const char* GetExceptionClassName() const;

			_STL::string m_ErrMsg;
			_STL::string m_ClassName;
			_STL::string m_MethodName;
			_STL::string m_FileName;
			_STL::string m_SourceName;
			long m_LineNumber;

			// Instruction info
			long m_InstrId;
			long m_InstrVersion;
			portfolio::TransactionIdent m_TradeId;
			long m_TradeVersion;
			long m_MessageId;
			long m_WorkflowId;
			long m_DelieveryType;
		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashUnknownException : public CSRBOCashException
		{
		public:
			CSRBOCashUnknownException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashUnknownException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoInstructionException : public CSRBOCashException
		{
		public:
			CSRBOCashNoInstructionException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashNoInstructionException(const char* errMsgHeader, const sophisTools::base::ExceptionBase& source, const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashNoInstructionException(const char* errMsgHeader, const CSR_IM_Exception& source);
			~CSRBOCashNoInstructionException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashQueryFailedException : public CSRBOCashException
		{
		public:
			CSRBOCashQueryFailedException(const char* errMsgHeader, const sophis::sql::CSROracleException& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashQueryFailedException(const char* errMsgHeader, const sophisTools::base::DatabaseException& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashQueryFailedException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber, long errorCode);
			~CSRBOCashQueryFailedException();

			long GetErrorCode() const;
		protected:
			long m_ErrorCode;
			virtual const char* GetExceptionClassName() const;
			virtual const _STL::string GetEnvironmentString() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashPerformActionException : public CSRBOCashException
		{
		public:
			CSRBOCashPerformActionException(const char* errMsgHeader, const sophisTools::base::ExceptionBase& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber, long eventID);
			CSRBOCashPerformActionException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber, long eventID);
			~CSRBOCashPerformActionException();

			long GetEventID() const;
		protected:
			virtual const char* GetExceptionClassName() const;
			virtual const _STL::string GetEnvironmentString() const;
			long m_EventID;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNewDealExistsException : public CSRBOCashException
		{
		public:
			CSRBOCashNewDealExistsException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashNewDealExistsException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoTransactionException : public CSRBOCashException
		{
		public:
			CSRBOCashNoTransactionException(const char* errMsgHeader, const sophisTools::base::ExceptionBase& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber, sophis::portfolio::TransactionIdent tradeID, long tradeVersion);
			CSRBOCashNoTransactionException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber, sophis::portfolio::TransactionIdent tradeID, long tradeVersion);
			~CSRBOCashNoTransactionException();

			portfolio::TransactionIdent GetTradeID() const;
			long GetTradeVersion() const;

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashCantMatchException : public CSRBOCashException
		{
		public:
			CSRBOCashCantMatchException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashCantMatchException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoTradeDetailsException : public CSRBOCashException
		{
		public:
			CSRBOCashNoTradeDetailsException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashNoTradeDetailsException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoWorkflowException : public CSRBOCashException
		{
		public:
			CSRBOCashNoWorkflowException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber, long workflowId, long deliveryType);
			~CSRBOCashNoWorkflowException();

			long GetWorkflowID() const;
			long GetDelieveryType() const;

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoEventIDException : public CSRBOCashException
		{
		public:
			CSRBOCashNoEventIDException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber, long eventID);
			~CSRBOCashNoEventIDException();

			long GetEventID() const;

		protected:
			virtual const char* GetExceptionClassName() const;
			long m_EventID;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoEventIDForLinksException : public CSRBOCashException
		{
		public:
			CSRBOCashNoEventIDForLinksException(const char* errMsgHeader, const CSRBOCashException& source);
			CSRBOCashNoEventIDForLinksException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashNoEventIDForLinksException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashGenerateTemplateException : public CSRBOCashException
		{
		public:
			CSRBOCashGenerateTemplateException(const char* errMsgHeader, const CSR_IM_Exception& source);
			CSRBOCashGenerateTemplateException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashGenerateTemplateException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber,
				const long instrId, const long instrVersion, const sophis::portfolio::TransactionIdent tradeId, const long tradeVersion, const long messageId, const long workflowId, const long deliveryType);
			~CSRBOCashGenerateTemplateException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashNoInstructionOrTradeIdException : public CSRBOCashException
		{
		public:
			CSRBOCashNoInstructionOrTradeIdException(const char* errMsgHeader, const CSR_IM_Exception& source);
			CSRBOCashNoInstructionOrTradeIdException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashNoInstructionOrTradeIdException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};
		//////////////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBOCashInstrBuilderException : public CSRBOCashException
		{
		public:
			CSRBOCashInstrBuilderException(const char* errMsgHeader, const CSRBOCashException& source);
			CSRBOCashInstrBuilderException(const char* errMsgHeader, const sophisTools::base::ExceptionBase& source,
				const char* className, const char* methodName, const char* fileName, long lineNumber);
			CSRBOCashInstrBuilderException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashInstrBuilderException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};

		class SOPHIS_BO_CASH CSRBOCashInstrCheckIRLException : public CSRBOCashException
		{
		public:
			CSRBOCashInstrCheckIRLException(const char* errMsg, const char* className, const char* methodName, const char* fileName, long lineNumber);
			~CSRBOCashInstrCheckIRLException();

		protected:
			virtual const char* GetExceptionClassName() const;

		private:
			static const char* __CLASS__;
		};

		//////////////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG

#endif //BO_CASH_EXCEPTION_H
