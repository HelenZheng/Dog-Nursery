#pragma once

#include "SphInc/backoffice_cash/SphBoCashBatchMultipleAbstractEvent.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		class SOPHIS_BO_CASH CSRBoCashGenerateTemplateEvent: public virtual CSRBoCashBatchMultipleAbstractEvent
		{
		public:
			CSRBoCashGenerateTemplateEvent(){}
			~CSRBoCashGenerateTemplateEvent(){}

			virtual void runSingle(const CSRInstruction* _instruction, 
								   sophis::tools::CSREventVector* _eventVector)
								   throw (CSRBOCashException);

		private:
			static const char* __CLASS__;

		};
	}
}
SPH_EPILOG