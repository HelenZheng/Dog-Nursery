#ifndef __CS_BOWS_INSTRUCTION_PROCESSOR_H__
#define __CS_BOWS_INSTRUCTION_PROCESSOR_H__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/portfolio/SphTransaction.h"
#include "SphInc/backoffice_cash/SphInstruction.h"

#include "SphInc/backoffice_cash/SphInstructionManager.h"
#include "SphInc/backoffice_cash/SphBoCashException.h"

#include __STL_INCLUDE_PATH(list)

#ifdef GCC_XML
#define	assert(a) 
#define ASSERT(a) 
#endif

SPH_PROLOG
class CSRBOCashWorkflowManager;

namespace sophis 
{
	namespace backoffice_cash 
	{

class CSRInstruction;
class CSRBOCashException;
class CSR_IM_DataBaseException;
class CSRBoCashExtraModifiedItemsManager;

class SOPHIS_BO_CASH CSRBoCashInstructionProcessor
{
// Construction / destruction
public:
	virtual ~CSRBoCashInstructionProcessor();
	static CSRBoCashInstructionProcessor* getInstance();
	static bool IsLoaded();

// Interface
public:
	void processInstruction(
		CSRInstructionList& _instructionList, 
		long _eventID, 
		long _status, 
		sophis::tools::CSREventVector* _eventVector,
		CSRBoCashExtraModifiedItemsManager* _extraModifiedItemsManager = NULL,
		bool inSTP = false) const;

	void processInstruction(
		CSRInstructionList& _instructionList, 
		long _eventID, 
		long _status, 
		sophis::tools::CSREventVector* _eventVector,
		CSRBoCashExtraModifiedItemsManager* _extraModifiedItemsManager ,
		bool _ignoreNostroLostro,
		bool inSTP = false) const
	throw (CSRBOCashPerformActionException, CSRBOCashNoEventIDException, CSR_IM_DataBaseException, CSRBOCashException);
	
// Accessors
public:
	void SetNeedWorkflowReload();
	inline CSRBOCashWorkflowManager* getWorkflowManager()
	{ ASSERT(m_WorkflowManager != NULL); return m_WorkflowManager; }
	
// Data
protected:
	CSRBoCashInstructionProcessor();
	CSRBOCashWorkflowManager* m_WorkflowManager;
	mutable bool m_needWorkflowReload;

	static CSRBoCashInstructionProcessor* m_instance; 
	static const char* __CLASS__; // Logger stuff
};

	}
}

SPH_EPILOG

#endif //#define __CS_BOWS_INSTRUCTION_PROCESSOR_H__
