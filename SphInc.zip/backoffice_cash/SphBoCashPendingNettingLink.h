#pragma once

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		enum ePendingNettingLinkOutputType
		{
			ePendingNettingLinkOutputTypeNA,
			ePendingNettingLinkOutputTypeMessage,
			ePendingNettingLinkOutputTypeInstruction
		};

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBoCashPendingNettingLink
		{
		public:
			CSRBoCashPendingNettingLink(long _linkId, long _tradeId, long m_outputType, long m_outputId);
			CSRBoCashPendingNettingLink();
			~CSRBoCashPendingNettingLink();

			long getLinkId();
			void setLinkId(long _linkId);

			portfolio::TransactionIdent getTradeId();
			void setTradeId(portfolio::TransactionIdent _tradeId);

			long getOutputId();
			void setOutputId(long _outputId);

			long getOutputType();
			void setOutputType(long _outputType);

		protected:
			long m_linkId;
			portfolio::TransactionIdent m_tradeId;
			long m_outputId;
			long m_outputType;

		private:
		    static const char* __CLASS__; 
		};
	}
}

SPH_EPILOG