#pragma once

#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_cash/SphBoCashPendingNettingLink.h"
#include "SphInc/backoffice_cash/SphBOCashException.h"
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis
{
	namespace sql
	{
		class CSRStructureDescriptor;
		class CSRSqlQuery;
	}

	namespace backoffice_cash
	{

		//////////////////////////////////////////////////////////////////////////////////
		class SOPHIS_BO_CASH CSRBoCashPendingNettingLinkManager
		{
		public:
			~CSRBoCashPendingNettingLinkManager();
			static CSRBoCashPendingNettingLinkManager* getInstance();
			void lockResources() throw (CSRBOCashQueryFailedException);
			void cleanPendingNettingTableForLinkId(long _linkId) throw (CSRBOCashQueryFailedException);
			void refreshPendingNettingTable() throw (CSRBOCashQueryFailedException);
			void refreshOutputIds() throw (CSRBOCashQueryFailedException);
			_STL::list<_STL::list<CSRBoCashPendingNettingLink> > getAllReadyForNettingLinks() 
				throw (CSRBOCashQueryFailedException);

		protected:
			CSRBoCashPendingNettingLinkManager();
			static CSRBoCashPendingNettingLinkManager* m_instance;
			sophis::sql::CSRStructureDescriptor*	m_getAllReadyForNettingLinksResultDesc;

			sophis::sql::CSRSqlQuery*				m_getAllReadyForNettingLinksQuery;

		private:
		    static const char* __CLASS__; 
		};
	}
}

SPH_EPILOG