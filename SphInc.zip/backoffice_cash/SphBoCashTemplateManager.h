#ifndef SPH_BO_CASH_TEMPLATE_MANAGER_H
#define SPH_BO_CASH_TEMPLATE_MANAGER_H

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphValidation.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/backoffice_cash/SphInstructionManager.h"
#include "SphInc/backoffice_cash/SphBOCashException.h"
#include "SphInc/backoffice_cash/SphBOCashActionFinder.h"

SPH_PROLOG
class SOPHIS_BO_CASH CSRBoCashTemplateManager {
public:
	~CSRBoCashTemplateManager();
	static CSRBoCashTemplateManager* getInstance();
	bool isGenerateTemplateRequired(	const CSRBOCashActionFinder& _finder, 
										sophis::backoffice_cash::CSRInstruction& _instruction, 
										bool _ignoreNostroLostro = false);
	bool requestTemplateIfRequired( const CSRBOCashActionFinder& _finder, 
		sophis::backoffice_cash::CSRInstruction& _instruction,
		sophis::tools::CSREventVector* _eventVector,
		bool _ignoreNostroLostro = false)
		throw (sophis::backoffice_cash::CSRBOCashNoWorkflowException, sophis::backoffice_cash::CSR_IM_DataBaseException);
	bool generateTemplate( const sophis::backoffice_cash::CSRInstruction& instruction)
		throw (sophis::backoffice_cash::CSRBOCashGenerateTemplateException);
	void requestTemplateGeneration(const sophis::backoffice_cash::CSRInstruction& _instruction, sophis::tools::CSREventVector* _eventVector);
protected:
	static CSRBoCashTemplateManager* m_Instance;

	bool checkForNOSTROLOSTRO( sophis::backoffice_cash::CSRInstruction& instruction );
private:
	static const char* __CLASS__; 
};
SPH_EPILOG
#endif


