#pragma once
#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphBOCashException.h"

SPH_PROLOG

#define DECLARATION_BOCASH_THREAD_OBJECT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass, CSRBOCashThreadObject)
#define	INITIALISE_BOCASH_THREAD_OBJECT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

namespace sophis {
	namespace backoffice_cash {

		class SOPHIS_BO_CASH CSRBOCashThreadObject
		{
		public:
			/**
			* 
			* This is function that is to be used by HostThread.
			* It must return 'void' and must accept no parameters.
			* In this class it retries messages that have not yet been matched
			*
			**/
			virtual void runMethod() throw(CSRBOCashException);

			//	Prototype stuff
			virtual CSRBOCashThreadObject* Clone() const { throw 1; }
			typedef sophis::tools::CSRPrototype<CSRBOCashThreadObject, const char *, sophis::tools::less_char_star> prototype;
			static prototype & GetPrototype();
		private:
			static const char* __CLASS__;
		};

	}
}

SPH_EPILOG