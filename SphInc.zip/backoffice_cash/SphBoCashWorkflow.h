#ifndef __CSRBOCashWorkflow__
#define __CSRBOCashWorkflow__
#include "SphInc/SphMacros.h"

#include "SphBOCashWorkflowTypes.h"
#include "SphBOCashException.h"

SPH_PROLOG

// used to specify we want first match when calling CSRBOCashWorkflow::GetNextMatch
const int GM_GET_FIRST = -1;

class SOPHIS_BO_CASH CSRBOCashWorkflow
{
public:
	// constructor
	CSRBOCashWorkflow();
	// copy constructor
	CSRBOCashWorkflow( const boWorkflowDefVector& wfdVector );
	~CSRBOCashWorkflow();

	// assignment operators
	void operator= ( const CSRBOCashWorkflow& rhs );
	void operator= ( const boWorkflowDefVector& rhs );

	// Returns a boWorkflowDefVector with all matching possiblities ordered by priotity
	int GetAllMatches( boWorkflowDefVector& wfdVector, long Event, long InitialStatus1, long InitialStatus2 = -1 ) 
		throw (sophis::backoffice_cash::CSRBOCashNoInstructionException);

	// Returns the next matching boWorkflowDefItem starting from priority = position ( GM_GET_FIRST indicates get first match)
	int GetNextMatch( sophis::backoffice_cash::CSRDefinitionFlow& item, long Event, int& position, long InitialStatus1, long InitialStatus2 = -1 ) 
		throw (sophis::backoffice_cash::CSRBOCashNoInstructionException);

protected:
	static const char* __CLASS__;

private:
	void				Reset();

	long						m_workflowId;	// the workflow ID
	long						m_deliveryType;	// the delivery type WF_FOP or WF_DVP or WF_ALL

	boWorkflowDefVector m_boWorkflow;	// the workflow
};

SPH_EPILOG

#endif // __CSRBOCashWorkflow__

