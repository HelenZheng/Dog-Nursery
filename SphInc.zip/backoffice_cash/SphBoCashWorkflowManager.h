#ifndef __CSRBOCashWorkflowManager__
#define __CSRBOCashWorkflowManager__
#include "SphInc/SphMacros.h"


#include __STL_INCLUDE_PATH(map)

#include "SphBOCashWorkflowTypes.h"
#include "SphInc/backoffice_cash/SphBoCashException.h"
#include "SphInc/backoffice_cash/SphInstruction.h"


SPH_PROLOG

namespace sophis
{
	namespace backoffice_cash
	{
		class CSRBOCashNoWorkflowException;
		class CSRBOCashQueryFailedException;
	}
}

// comparison function for workflow map
inline bool operator< (boWorkflowMapKey lhs, boWorkflowMapKey rhs)
{
	if(lhs.id < rhs.id)
	{
		return true;
	}

	if(lhs.id == rhs.id && lhs.type < rhs.type)
	{
		return true;
	}

	if(lhs.id == rhs.id && lhs.type == rhs.type && lhs.eventId < rhs.eventId)
	{
		return true;
	}

	return false;
}

typedef _STL::map< boWorkflowMapKey, boWorkflowDefVector > boWorkflowMap;

// Simple container class for workflows. Only load/reload/get functionality.
class SOPHIS_BO_CASH CSRBOCashWorkflowManager
{
public:
	CSRBOCashWorkflowManager(); // loads workflows
	~CSRBOCashWorkflowManager();

	//Keep this for BackWard compatibility...
	// const boWorkflowDefVector& GetWorkflow(	long workflow_id, long deliveryType);

	const sophis::backoffice_cash::CSRDefinitionFlow* FindWorkflowRuleByInstruction(sophis::backoffice_cash::CSRInstruction *instruction);
	bool FindWorkflowRuleByInstruction(sophis::backoffice_cash::CSRInstruction *instruction, sophis::backoffice_cash::CSRDefinitionFlow &rule);

	const boWorkflowDefVector& GetWorkflow(	long workflow_id, long deliveryType, long eventId)
		throw (sophis::backoffice_cash::CSRBOCashNoWorkflowException);
	// returns the workflow def list for requested 
	// workflow_id/type pair
	void SetCacheEnabled( bool enabled ) {}//Keep this for BackWard compatibility...
	bool GetCacheEnabled( ) { return true; }//Keep this for BackWard compatibility...

#ifdef _DEBUG
	// *** IT - don't need this in release build
	void Dump();

#endif

	int LoadWorkflows();// loads or reloads workflows from database. 
	int LoadEvents();

	const CSRInstructEvent* GetEvent(long eventID);
	boCashInstructEventVector& GetEvents();

protected:	
	boWorkflowMap m_workflows;
	boWorkflowMap m_workflowsWithoutEvent;
	boCashInstructEventVector m_boCashInstructionEvents;

	static const char* __CLASS__;

	bool m_Loaded;
	bool m_LoadedEvents;
private:

};


SPH_EPILOG

#endif // __CSRBOCashWorkflowManager__
