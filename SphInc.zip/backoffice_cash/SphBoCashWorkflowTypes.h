#ifndef __BOCASHWORKFLOWTYPES__
#define __BOCASHWORKFLOWTYPES__

#include "SphInc/backoffice_cash/SphDefinitionFlow.h"
#include "SphInc/backoffice_kernel/SphKernelEvent.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
enum BowsTransactionAction
{
	BOWS_TA_NONE=-1,
	BOWS_TA_NEW_DEAL=1,
	BOWS_TA_MODIFY_DEAL=2,
	BOWS_TA_CANCEL_DEAL=3
};

typedef enum
{
	IE01 = 1		// Neither of the two Sophis ref in the XML
	,IE02			// No corresponding Trade / Instruction ref
	,IE03			// No corresponding Instruction for this trade ref
	,IE04			// Unknown Event
	,IE05			// Check your correspondence table
	,IE06			// No corresponding line, check the workflow definition
	,IE07			// Inconsistent Instruction builder for this rule
	,IE08			// Inconsistent Final statuses for this rule
	,IE09			// Exception coming from Check IRL interface
	,IE10			
	,IE11			// No reference, waiting for further matching
	,IE12			// Unknown reference, waiting for further matching
	,IELast = IE12	// last error code
//***ATTENTION*** IF YOU ADD A NEW EXCEPTION STATUS: You must update the GROUPED_INSTRUCTION DB view to ignore the new exception status
}bowsInstrumentStatusErrorCode;

inline char* GetInstrumentStatusErrorCodeAsString(const long _errorStatus)
{
	switch (_errorStatus)
	{
	case IE01:
		return "IE01";
	case IE02:
		return "IE02";
	case IE03:
		return "IE03";
	case IE04:
		return "IE04";
	case IE05:
		return "IE05";
	case IE06:
		return "IE06";
	case IE07:
		return "IE07";
	case IE08:
		return "IE08";
	case IE09:
		return "IE09";
	case IE10:
		return "IE10";
	case IE11:
		return "IE11";
	case IE12:
		return "IE12";
	default:
		return "<unknown instrument status error code>";
	}
}

typedef enum {	
	BOWS_AUTO_SEND_YES = 1
	, BOWS_AUTO_SEND_NO
	, BOWS_AUTO_SEND_NOT_APPLICABLE
}bowsAutoSend;
	}
}

// key for accessing items in the map
typedef struct _boWorkflowMapKey
{
	long						id;		// WORKFLOW_ID
	long						type;	// DELIVERY_TYPE
	long						eventId;	// EVENT_ID
}boWorkflowMapKey;

//type for storing a bo cash events
class CSRInstructEvent
{
public:
	long id;
	char name[256];
	sophis::backoffice_kernel::eBOEventSTP stp;
};

// vector of entries in BO_CASH_WORKFLOW_DEF by workflow_id/delivery_type sorted by priority
typedef _STL::vector< sophis::backoffice_cash::CSRDefinitionFlow > boWorkflowDefVector ;
typedef _STL::vector< CSRInstructEvent > boCashInstructEventVector;

SPH_EPILOG

#endif // __BOCASHWORKFLOWTYPES__

