#pragma once
#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)


SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		/** Constants to indicate the presence of CSRIncomingInstruction fields in incoming XML file
		    and differientiate an empty value from a missing value.
			See below {@link CSRIncomingInstruction::fFieldMask}
		*/
		const unsigned long long FM_EVENT_ID					= 0x0000000001ULL;
		const unsigned long long FM_EVENT_ID_LINKS				= 0x0000000002ULL;
		const unsigned long long FM_MESSAGE_DATE				= 0x0000000004ULL;
		const unsigned long long FM_EFFECTIVE_DATE				= 0x0000000008ULL;
		const unsigned long long FM_QUANTITY_SETTLED			= 0x0000000010ULL;
		const unsigned long long FM_AMOUNT_SETTLED				= 0x0000000020ULL;
		const unsigned long long FM_CCY_PAID					= 0x0000000040ULL;
		const unsigned long long FM_INSTRUCTION_ID				= 0x0000000080ULL;
		const unsigned long long FM_INSTRUCTION_VERSION			= 0x0000000100ULL;
		const unsigned long long FM_TRADE_ID					= 0x0000000200ULL;
		const unsigned long long FM_TRADE_VERSION				= 0x0000000400ULL;
		const unsigned long long FM_INSTRUMENT_REFERENCE		= 0x0000000800ULL;
		const unsigned long long FM_INSTRUMENT_REFERENCE_TYPE	= 0x0000001000ULL;
		const unsigned long long FM_QUANTITY					= 0x0000002000ULL;
		const unsigned long long FM_PRICE						= 0x0000004000ULL;
		const unsigned long long FM_COUNTERPARTY_ID				= 0x0000008000ULL;
		const unsigned long long FM_REASON_CODE					= 0x0000010000ULL;
		const unsigned long long FM_COMMENT						= 0x0000020000ULL;
		const unsigned long long FM_NOSTRO1						= 0x0000040000ULL;
		const unsigned long long FM_NOSTRO2						= 0x0000080000ULL;
		const unsigned long long FM_NOSTRO3						= 0x0000100000ULL;
		const unsigned long long FM_NOSTRO_ACCOUNT1				= 0x0000200000ULL;
		const unsigned long long FM_NOSTRO_ACCOUNT2				= 0x0000400000ULL;
		const unsigned long long FM_LOSTRO1						= 0x0000800000ULL;
		const unsigned long long FM_LOSTRO2						= 0x0001000000ULL;
		const unsigned long long FM_LOSTRO3						= 0x0002000000ULL;
		const unsigned long long FM_LOSTRO_ACCOUNT1				= 0x0004000000ULL;
		const unsigned long long FM_LOSTRO_ACCOUNT2				= 0x0008000000ULL;
		const unsigned long long FM_COUNTERPARTY_REFERENCE		= 0x0010000000ULL;
		const unsigned long long FM_CLEARER_REFERENCE			= 0x0020000000ULL;
		const unsigned long long FM_WORKFLOW_ID					= 0x0040000000ULL;
		const unsigned long long FM_DELIVERY_TYPE				= 0x0080000000ULL;
		const unsigned long long FM_FEES						= 0x0100000000ULL;
		const unsigned long long FM_FEES_TYPE					= 0x0200000000ULL;
		const unsigned long long FM_ACCRUED_AMOUNT				= 0x0400000000ULL;
		const unsigned long long FM_EXCEPTION_INSTRUCTION_ID	= 0x0800000000ULL;
		const unsigned long long FM_AMOUNT						= 0x1000000000ULL;
		const unsigned long long FM_CCY_TRADE					= 0x2000000000ULL;
		const unsigned long long FM_VALUE_DATE					= 0x4000000000ULL;

		/** This class is used in order to pass the incoming XML message 
			information to the auto matching algorithm {@link CSRInsAutoMatchingAlgo::Match}
		*/	
		class SOPHIS_BO_CASH CSRIncomingInstruction
		{
		public:
			CSRIncomingInstruction();
			CSRIncomingInstruction(const CSRIncomingInstruction& _init);
			CSRIncomingInstruction(unsigned long long _FieldMask, long _EventId, _STL::list<_STL::string> _EventIdLinks, long _MessageDate, long _EffectiveDate, double _QuantitySettled,
				double _AmountSettled, _STL::string _CcyPaid, long _InstructionId, long _InstructionVersion, portfolio::TransactionIdent _TradeId, long _TradeVersion, _STL::string _InstrumentReference,
				_STL::string _InstrumentReferenceType, double _Quantity, double _Price, long _CounterpartyId, _STL::string _ReasonCode, _STL::string _Comment, _STL::string _NOSTRO1, 
				_STL::string _NOSTRO2, _STL::string _NOSTRO3, _STL::string _NOSTROAccount1, _STL::string _NOSTROAccount2, _STL::string _LOSTRO1, _STL::string _LOSTRO2, _STL::string _LOSTRO3,
				_STL::string _LOSTROAccount1, _STL::string _LOSTROAccount2, _STL::string _CounterpartyReference, _STL::string _ClearerReference, long _WorkflowId, long _DeliveryType,
				double _Fees, long _FeesType, double _AccruedAmount, long _ExceptionInstructionId, double _Amount, _STL::string _CcyTrade, long _ValueDate/* long _UserId*/):
				fFieldMask(_FieldMask), fEventId(_EventId),fEventIdLinks(_EventIdLinks),fMessageDate(_MessageDate),fEffectiveDate(_EffectiveDate),fQuantitySettled(_QuantitySettled),
				fAmountSettled(_AmountSettled),fCcyPaid(_CcyPaid),fInstructionId(_InstructionId),fInstructionVersion(_InstructionVersion),fTradeId(_TradeId),fTradeVersion(_TradeVersion),fInstrumentReference(_InstrumentReference),
				fInstrumentReferenceType(_InstrumentReferenceType),fQuantity(_Quantity),fPrice(_Price),fCounterpartyId(_CounterpartyId),fReasonCode(_ReasonCode),fComment(_Comment),fNOSTRO1(_NOSTRO1),fNOSTRO2(_NOSTRO2),fNOSTRO3(_NOSTRO3),
				fNOSTROAccount1(_NOSTROAccount1),fNOSTROAccount2(_NOSTROAccount2),fLOSTRO1(_LOSTRO1),fLOSTRO2(_LOSTRO2),fLOSTRO3(_LOSTRO3),fLOSTROAccount1(_LOSTROAccount1),fLOSTROAccount2(_LOSTROAccount2),fCounterpartyReference(_CounterpartyReference),
				fClearerReference(_ClearerReference),fWorkflowId(_WorkflowId),fDeliveryType(_DeliveryType),fFees(_Fees),fFeesType(_FeesType),fAccruedAmount(_AccruedAmount),fExceptionInstructionId(_ExceptionInstructionId),fAmount(_Amount),fCcyTrade(_CcyTrade),
				fValueDate(_ValueDate)/* fUserId(_UserId*/{};

			~CSRIncomingInstruction();
			const CSRIncomingInstruction& operator=(class CSRIncomingInstruction const &);
			void init();

			/** Indicates the presence of fields in incoming XML file.
				It allows to differentiate a blank value from an missing (no XML tag) value
				The value is a combination of bits based on the constants above named FM_...
				For example, if a message contains and event id, a message date, a quantity settled, etc... 
				then fFieldMask = FM_EVENT_ID|FM_MESSAGE_DATE|FM_QUANTITY_SETTLED|...
			*/	
			unsigned long long fFieldMask;

			/** Contains the value read in the <MESSAGE_TYPE><EVENT_ID value=xxx/><MESSAGE_TYPE/> tag
				It is the Securities WF event to run on the instruction.
				Usually, either an event id is provided in fEventId OR a list of link values are provided in fEventIdLinks
			*/	
			long fEventId;


			/** Contains the values read in the <MESSAGE_TYPE><EVENT_LINK VALUE=xxx /><EVENT_LINK VALUE=yyy /><MESSAGE_TYPE/> tags
				It is a list of value which will be used to find the Securities WF event to run on the instruction.
				The event ID is found using the BO_CASH_EVENT_LINK table
				Usually, either an event id is provided in fEventId OR a list of link values are provided in fEventIdLinks
			*/	
			_STL::list<_STL::string> fEventIdLinks;

			/** Contains the value read in the <MESSAGE_DATE> tag
				It is the date of the message creation in the form of a long (number of days since 01/01/1904)
			*/	
			long fMessageDate;

			/** Contains the value read in the <EFFECTIVE_DATE> tag
				It is the effective date of the operation in the form of a long (number of days since 01/01/1904)
			*/	
			long fEffectiveDate;

			/** Contains the value read in the <QUANTITY_SETTLED> tag
				It is the quantity settled in this operation
			*/	
			double fQuantitySettled;

			/** Contains the value read in the <AMOUNT_SETTLED> tag
				It is the amount settled in this operation
			*/	
			double fAmountSettled;

			/** Contains the value read in the <CCY_PAID> tag
				It is the the currency used for the settlement amount
			*/	
			_STL::string fCcyPaid;

			/** Contains the value read in the <INSTRUCTION_TRADE><INSTRUCTION ID VALUE=xxx/><INSTRUCTION_TRADE/> tag
				It is the id of the instruction the message is related to.
				If provided, the matching is straight forward.
				Usually, either an instruction id and version OR trade id and version are provided.
				In some cases, none of the two are provided.
			*/	
			long fInstructionId;
			long fInstructionVersion;

			/** Contains the value read in the <INSTRUCTION_TRADE><TRADE ID VALUE=xxx/><INSTRUCTION_TRADE/> tag
				It is the id of the deal related to the instruction to which the message is related to.
				If provided, the matching is straight forward.
				Usually, either an instruction id and version OR trade id and version are provided.
				In some cases, none of the two are provided.
			*/	
			portfolio::TransactionIdent fTradeId;
			long fTradeVersion;

			/** Contains the value read in the <INSTRUMENT_REFERENCE> tag
				It must be the reference of the instrument related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			_STL::string fInstrumentReference;

			/** Contains the value read in the <INSTRUMENT_TYPE> tag
				It must be the type of the instrument related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			_STL::string fInstrumentReferenceType;

			/** Contains the value read in the <QUANTITY> tag
				It must the quantity of the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			double fQuantity;

			/** Contains the value read in the <PRICE> tag
				It must the price on the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			double fPrice;

			/** Contains the value read in the <COUNTERPARTY_ID> tag
				It must the counterparty on the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			long fCounterpartyId;

			/** Contains the value read in the <REASON_CODE> tag
				A reason code for the message
			*/	
			_STL::string fReasonCode;

			/** Contains the value read in the <COMMENT> tag
				A comment field about the message
			*/	
			_STL::string fComment;

			/** Contains the value read in the <NOSTRO1> tag
				The first NOSTRO reference related to the entity
			*/	
			_STL::string fNOSTRO1;

			/** Contains the value read in the <NOSTRO2> tag
				The second NOSTRO reference related to the entity
			*/	
			_STL::string fNOSTRO2;

			/** Contains the value read in the <NOSTRO3> tag
				The third NOSTRO reference related to the entity
			*/	
			_STL::string fNOSTRO3;

			/** Contains the value read in the <NOSTRO1> tag
				The first NOSTRO account related to the entity
			*/	
			_STL::string fNOSTROAccount1;

			/** Contains the value read in the <NOSTRO2> tag
				The second NOSTRO account related to the entity
			*/	
			_STL::string fNOSTROAccount2;

			/** Contains the value read in the <LOSTRO1> tag
				The first LOSTRO reference related to the counterparty
			*/	
			_STL::string fLOSTRO1;

			/** Contains the value read in the <LOSTRO2> tag
				The second LOSTRO reference related to the counterparty
			*/	
			_STL::string fLOSTRO2;

			/** Contains the value read in the <LOSTRO3> tag
				The third LOSTRO reference related to the counterparty
			*/	
			_STL::string fLOSTRO3;

			/** Contains the value read in the <LOSTRO_ACCOUNT1> tag
				The first LOSTRO account related to the entity
			*/	
			_STL::string fLOSTROAccount1;

			/** Contains the value read in the <LOSTRO_ACCOUNT2> tag
				The second LOSTRO account related to the entity
			*/	
			_STL::string fLOSTROAccount2;

			/** Contains the value read in the <COUNTERPARTY_REFERENCE> tag
				It must be the reference of the counterparty related to the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			_STL::string fCounterpartyReference;

			/** Contains the value read in the <CLEARER_REFERENCE> tag
				It must be the reference of the clearer related to the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			_STL::string fClearerReference;

			/** Contains the value read in the <WORKFLOW ID="xxx" DELIVERY_TYPE=""/> tag
				It must be the ID of the workflow (Table BO_CASH_WORKFLOW) of the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			long fWorkflowId;

			/** Contains the value read in the <WORKFLOW ID="" DELIVERY_TYPE="xxx"/> tag
				It must be the type of delivery ('DVP' or 'FOP' or 'STAR') of the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			long fDeliveryType;

			/** Contains the value read in the <FEES> tag
				Fee amount for the message
			*/	
			double fFees;

			/** Contains the value read in the <FEES_TYPE> tag
				Fee type for the message
			*/	
			long fFeesType;

			/** Contains the value read in the <ACCRUED_AMOUNT_SETTLED_VALUE> tag
				Accrued amount related to the settlement amoung
			*/	
			double fAccruedAmount;

			/** Contains the id of the exception instruction created in case of a failing match
				This field is therefore not used during the matching of the message to an instruction.
				It is filled later in the process when the exception instruction is created.
			*/	
			long fExceptionInstructionId;

			/** Contains the value read in the <AMOUNT> tag
				It must be the amount on the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			double fAmount;

			/** Contains the value read in the <CCY_TRADE> tag
				It must be the currency on the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			_STL::string fCcyTrade;

			/** Contains the value read in the <VALUE_DATE> tag
				It must be the value date on the deal related to the instruction.
				It is used for checks or for matching the instruction to the message
			*/	
			long fValueDate;

			//long fUserId;

		};
	}
}
SPH_EPILOG