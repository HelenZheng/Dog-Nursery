#ifndef __SPHDefinitionFlow__
#define __SPHDefinitionFlow__

#include "SphInc/SphMacros.h"

#define NUM_CONDITIONS		3

SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {

		class CSRDefinitionFlow
		{
		public:
		//	type	name					   Column name

			long	ident;					// ID
			long	workflowIdent;			// WORKFLOW_ID
			long	priority;				// PRIORITY
			long	deliveryType;			// DELIVERY_TYPE

			long	eventIdent;				// EVENT_ID
			long	initialStatus1;			// INITIAL_STATUS1
			long	initialStatus2;			// INITIAL_STATUS2

			char	editInitialStatus1[5];	// EDIT_INITIAL_STATUS1
			char	editInitialStatus2[5];	// EDIT_INITIAL_STATUS2
			
			char	condition1[50];			// CONDITION1
			char	condition2[50];			// CONDITION2
			char	condition3[50];			// CONDITION3

			long	finalStatus1;			// FINAL_STATUS1
			long	finalStatus2;			// FINAL_STATUS2

			long	templateIdent;			// TEMPLATE_ID
			long	autoSend;				// AUTO_SENT

			char	intructionBuilder[50];	// INSTR_MODELE
			char	instrCheckIRL[50];		// CONDITION_LENGTH
			char	comments[110];			// COMMENTS

			char	dialogModel[50];		// DLG_MODELE

			char	finalStatusRule1[50];	// RULE FOR FINAL STATUS 1
			char	finalStatusRule2[50];	// RULE FOR FINAL STATUS 2    

			bool	stpStop;				// STOP
		};


		enum eInitialStatusMenuExtraItems
		{
			ismeiNotApplicable		= 0,
			ismeiEditableStatus		= -1,
			ismeiNoStatus			= -2
		};


	}
}
SPH_EPILOG
#endif // __SPHDefinitionFlow__
