#ifndef __CS_INS_AUTO_MATCHING_ALGO_H__
#define __CS_INS_AUTO_MATCHING_ALGO_H__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphBowsIncomingInstruction.h"

#define DECLARATION_INSAUTOMATCHINGALGO(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRInsAutoMatchingAlgo)
#define CONSTRUCTOR_INSAUTOMATCHINGALGO(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSAUTOMATCHINGALGO(derivedClass)
#define	INITIALISE_INSAUTOMATCHINGALGO(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis 
{
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace backoffice_cash 
	{

	/** This class must be overridden in order to provide a custom 
		matching algorithm. 
		The idea is that based on the incoming XML message information 
		passed as a parameter, this algorithm will try to find the 
		instruction related to that message. If it fails to find a 
		matching instruction, the message information will be stored
		in the BO_UNMATCHED_INCOMING_MSG table, and further attempts to 
		match the message will happen regularly.

		The setup of this feature is in the BOWS.ini file:
		[AutoMatching]
		Algorithm = Default AutoMatching
		ThreadSleepTime = 2000

		Algorithm: contains the name under which the matching algorithm to use 
					was registred.
		ThreadSleepTime: contains the time (in millisecond) between each attempt
						to match the unmatched messages.

		@see CSRIncomingInstruction
		@version 5.2.6 included in toolkit
	*/					
		class SOPHIS_BO_CASH CSRInsAutoMatchingAlgo
		{
		public:
		/** This method must be overridden in order to provide a custom 
			matching algorithm. 

			@param _incomingInstruction
			All the information available from the incoming instruction XML message
			{@link CSRIncomingInstruction}

			@param _instructionsFound
			Points to an integer, which must be updated with the number of instructions 
			found as matching by the algorithm. Only a value of 1 means the message
			can be matched to the instruction. 0, 2 or more will fail.

			@see CSRIncomingInstruction
			@version 5.2.6 included in toolkit
			*/
			virtual void Match(const CSRIncomingInstruction _incomingInstruction, long* _instructionsFound) = 0;
	
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSAUTOMATCHINGALGO.
			@see tools::CSRPrototype
			*/
			virtual CSRInsAutoMatchingAlgo* Clone() const { throw 1; }
			
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef tools::CSRPrototype<CSRInsAutoMatchingAlgo, const char *, tools::less_char_star> prototype;
			
			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_INSAUTOMATCHINGALGO.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();	
		};

	}
}
SPH_EPILOG
#endif //#define __CS_INS_AUTO_MATCHING_ALGO_H__
