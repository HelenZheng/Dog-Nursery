#ifndef SPH_INSTRUCTION
#define SPH_INSTRUCTION



#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(list)
#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/backoffice_cash/SphBoCashException.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace SML{
class SMLKeyManager;
}

// These constants must be consistent with BO_CASH_INSTRUCTION table
#define	CSRINSTRUCTION_SIZE_SETTLE	40
#define	CSRINSTRUCTION_SIZE_COMMENT	512

namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace tools
	{
		namespace dataModel
		{
			class Data;
			class DataSet;
			class DataModelException;
		}
	}

	namespace backoffice_cash
	{

////////////////////////////////////////////////////////////////////////////////
//	CSR_InstrException
class SOPHIS_BO_CASH CSR_InstrException : public sophisTools::base::GeneralException
{
public:
	CSR_InstrException(const sophisTools::base::GeneralException& e,
		char* fileName, long lineNumber, char* function);
	CSR_InstrException(char* description, 
		char* fileName, long lineNumber, char* function);

	const _STL::string GetDescription() const;
	const _STL::string GetFileName() const;
	const long GetLineNumber() const;
	const _STL::string GetFunction() const;

private:
	_STL::string fDescription;
	_STL::string fFileName;
	long fLineNumber;
	_STL::string fFunction;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//	CSRInstruction
class SOPHIS_BO_CASH CSRInstruction
{
public:
	CSRInstruction();
	CSRInstruction(const CSRInstruction& instruction);
	virtual ~CSRInstruction();

	void Initialize();
	void Initialize(const CSRInstruction& instruction);

	inline void Copy(const CSRInstruction& instruction) {Initialize(instruction);}	// for backward comaptibility

	long GetTransactionLatestVersion();

	portfolio::CSRTransaction* getTransaction()	throw (CSR_InstrException);

	bool IsValidParentOfNetting();

	long Id;
	long version;
	long generationDate;
	long generationTime;
	long instructionDate;				//5
	long effectiveDate;	
	long status;
	portfolio::TransactionIdent tradeId; 
	long tradeVersion;
	long workflowId;	//10
	long deliveryType;					
	long clearerId;
	long counterpartId;  
	char nostro1[CSRINSTRUCTION_SIZE_SETTLE];
	char nostro2[CSRINSTRUCTION_SIZE_SETTLE]; //15
	char nostro3[CSRINSTRUCTION_SIZE_SETTLE];
	char nostro_account1[CSRINSTRUCTION_SIZE_SETTLE];
	char nostro_account2[CSRINSTRUCTION_SIZE_SETTLE];
	char lostro1[CSRINSTRUCTION_SIZE_SETTLE];
	char lostro2[CSRINSTRUCTION_SIZE_SETTLE];		//20
	char lostro3[CSRINSTRUCTION_SIZE_SETTLE];
	char lostro_account1[CSRINSTRUCTION_SIZE_SETTLE];
	char lostro_account2[CSRINSTRUCTION_SIZE_SETTLE];   
	double quantity;
	double amount;		//25
	double accruedAmount;				
	long currency;
	double adjustment;
	long adjustmentType;				
	char comment[CSRINSTRUCTION_SIZE_COMMENT];
	long messageId;						/*30*/    // document ID 
	long internalStatus;
	long workflowDefinitionId;
	char counterpartyReference[CSRINSTRUCTION_SIZE_SETTLE];		
	char clearerReference[CSRINSTRUCTION_SIZE_SETTLE];
	long templateId;					//35
	char reason_code[CSRINSTRUCTION_SIZE_SETTLE];
	long nettingType;//value of eNettingType
	long nettingId;//The ID of the instruction or the payment to which this instruction is netted.
	long nostroPhysicalId; // 7.0 Nostro physical (securities, maybe cash also) account id (SSI path).
	long nostroCashId; // 7.0 Nostro cash account id (SSI path).
	long lostroPhysicalId; // 7.0 Lostro physical (securities, maybe cash also) account id (SSI path).
	long lostroCashId; // 7.0 Lostro cash account id (SSI path).
	long psetId;

	// these fields are not in BO_CASH_INSTRUCTION
	// but are in BOC_BEVENT_ENTITY_FILTER
	long type;
	long entity;
	long instrumentId;					
	double trade_amount;				//40
	double trade_quantity;
	long   value_date;
	long   trade_date;
	long delivery_date;

	double	totalQuantity;//Only loaded for personal blotters...
	double	totalAmount;//Only loaded for personal blotters...

	int instructionEventID; //The ID of the last instruction event applied to the instruction
	int instructionRuleID; //The ID of the last instruction instruction applied to the instruction

	enum eInternalStatus
	{	// this enum is used throughout the Instruction Blotter code,
		// and it is used in the BOWS as well
		iiReady			= 1,
		iiNoMeaning,
		iiSent,
		iiHold,
		iiReceived,
		iiToSendAgain,
		iiEnded,		// new in 5.0.0
		iiLastStatus	= iiEnded
	};

	enum eInstructionNettingType
	{	// this enum is used throughout the Instruction Blotter code,
		// and it is used in the BOWS as well
		eInstructionNettingTypeNoNetting = 0,
		eInstructionNettingTypeNettedToInstruction,
		eInstructionNettingTypeNettedToPayment
	};

	/**
	* Serializes message description into a Data
	* Fills directly the data with the message description
	* @since 5.3.2
	*/
	void Describe(tools::dataModel::Data & data) const;

	/**
	* Serializes message description into a DataSet
	* Creates a sub element "instruction" to the DataSet and fills it with the description
	* Cf. grammar "www.sophis.net/instruction" in instruction.xsd for this type
	*/
	void Describe(tools::dataModel::DataSet& dataSet) const;
	
	/**
	* Returns the notional of the instrument associated with the trade.
	*/
	double getInstrumentNotional() const;

protected:
	portfolio::CSRTransaction* mTransaction; // transaction, related to this instruction

};
////////////////////////////////////////////////////////////////////////////////
typedef SOPHIS_BO_CASH CSRInstruction::eInternalStatus InstrIntStatus;
typedef _STL::list<CSRInstruction*> CSRInstructionList;

	} // namespace backoffice_cash
}

SOPHIS_BO_CASH SML::SMLKeyManager& operator << (SML::SMLKeyManager& keymgr, const sophis::backoffice_cash::CSRInstruction& inst)
throw (sophis::backoffice_cash::CSR_InstrException);



SPH_EPILOG

#endif //  SPH_INSTRUCTION

