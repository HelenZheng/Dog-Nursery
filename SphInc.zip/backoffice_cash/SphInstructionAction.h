#ifndef _InstructionAction_H_
#define _InstructionAction_H_

#ifndef _SphPrototype_H_
	#include "SphTools/SphPrototype.h"
#endif
#ifndef _SphAlgorthm_H_
	#include "SphInc/tools/SphAlgorithm.h"
#endif

#ifndef _SphValidation_H_
	#include "SphInc/tools/SphValidation.h"
#endif

#ifndef SPH_INSTRUCTION
	#include "SphInstruction.h"
#endif

#define CONSTRUCTOR_INSTRUCTION_ACTION(derivedClass)			
#define WITHOUT_INSTRUCTION_ACTION(derivedClass)	
#define DECLARATION_INSTRUCTION_ACTION(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRInstructionAction)
#define	INITIALISE_INSTRUCTION_ACTION(derivedClass, order,  name)\
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

/*#define CONSTRUCTOR_MESSAGE_EVENT(derivedClass)			
#define WITHOUT_CONSTRUCTOR_MESSAGE_EVENT(derivedClass)
#define DECLARATION_MESSAGE_EVENT(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRMessageEvent)
#define	INITIALISE_MESSAGE_EVENT(derivedClass, order,  name)\
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)*/

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
		class CSRInstruction;

		/** Interface to trigger some actions when saving instructions.
		You can overload this class and insert your own triggers.
		*/
		class SOPHIS_BO_CASH CSRInstructionAction
		{
		public:

			/** Specify the order of the triggers.
			*/
			enum	eOrder	{
				/** Before saving the data
				*/
				oBefore,
				
				/** Used internally : the code for saving is actually a trigger ordered by this enum
				*/
				oSave,

				/** After saving the data
				*/
				oAfter
			};


			/** Trivial constructor
			*/
			CSRInstructionAction();
		
			/** Trivial destructor
			*/
			virtual ~CSRInstructionAction();

			/** Ask what to notify when modifying.
			When saving, after that all the triggers have accepted the modification, they are called again 
			in the order eOrder + lexicographical order via
			NotifyModified to check if they have something to save in the database or send to other servers.
			@param original is the original instruction before any modification. It is a const object so that you cannot
			modify it.
			@param instruction is the instruction to save. It is a const object so that you cannot
			modify it.
			@param events is an event vector to put your events to send after the data are commited.
			Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
			event is in concordance with the database which will be the case after commiting. Moreover, if there
			is an exception in another trigger, the event must not be sent.
			@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
			some trouble, as in case of multi saving it will assume that no data or event is done. Do not commit, nor Rollback either,
			it is done elsewhere.
			*/
            virtual void NotifyModified(const sophis::backoffice_cash::CSRInstructionList &originalList, const sophis::backoffice_cash::CSRInstructionList &instructionList, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

            /** This version of NotifyModified is deprecated in favour of three parameter version of this function
            */
			virtual void NotifyModified(const sophis::backoffice_cash::CSRInstructionList &instructionList, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

			/** key for the prototype is eOrder + lexicographical 
			*/
			typedef tools::ordered_name<eOrder> ordered_name;
			
			/** typedef for the prototype
			*/
			typedef tools::CSRPrototype<CSRInstructionAction, ordered_name> prototype;

			/** access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_INSTRUCTION_ACTION
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Clone method needed by the prototype
			Usually, it is done automatically by the macro DECLARATION_INSTRUCTION_ACTION
			@see tools::CSRPrototype
			*/
			virtual CSRInstructionAction* Clone() const = 0;

		};
	} // namespace backoffice_otc
} // namespace sophis
SPH_EPILOG
#endif