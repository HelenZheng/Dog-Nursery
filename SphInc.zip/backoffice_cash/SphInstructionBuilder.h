#ifndef __SPHInstructionBuilder__
#define __SPHInstructionBuilder__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/backoffice_cash/SphBOCashException.h"
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis {
	namespace portfolio 
	{
		class CSRTransaction;
	}
	namespace tools
	{
		class CSREventVector;
	}
	namespace backoffice_cash 
	{
		class CSRDefinitionFlow;
		class CSRBoCashExtraModifiedItemsManager;

//////////////////////////////////////////////////////////////////////////////////
class SOPHIS_BO_CASH CSRInstructionBuilder
{
public:
	/**
	* Called to update (build) an instruction, taking a list of instructions as  parameter. 
	* Must be overridden.
	*
	* @param	flow: The flow executed
	* @param	instrList: A list of instructions
	* @param	_eventVector: A list of events to execute later
	* @param	_extraModifiedItemsManager: pointer to the class, which manages the extra modified instructions
	**/
	virtual void generate( const CSRDefinitionFlow& flow, 
							CSRInstructionList& instrList,
							sophis::tools::CSREventVector* _eventVector,
							CSRBoCashExtraModifiedItemsManager* _extraModifiedItemsManager) 
							throw (CSRBOCashInstrBuilderException) = 0;

//	Prototype stuff
	virtual CSRInstructionBuilder* Clone() const { throw 1; }
	typedef tools::CSRPrototype<CSRInstructionBuilder, const char *, tools::less_char_star> prototype;
	static prototype& GetPrototype();
};

	}
}

SPH_EPILOG
#endif
