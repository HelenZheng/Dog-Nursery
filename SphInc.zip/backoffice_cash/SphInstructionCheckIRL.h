
#pragma once

#ifndef _SPHINTRUCTIONCHECKIRL_H_
#define _SPHINTRUCTIONCHECKIRL_H_


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/backoffice_cash/SphBOCashException.h"
#include "SphInc/portfolio/SphTransaction.h"
#include __STL_INCLUDE_PATH(list)

#define DECLARATION_INSTRUCTION_CHECK_IRL(derivedClass)		DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_cash::CSRInstructionCheckIRL)
#define CONSTRUCTOR_INSTRUCTION_CHECK_IRL(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSTRUCTION_CHECK_IRL(derivedClass)
#define	INITIALISE_INSTRUCTION_CHECK_IRL(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {

		class SOPHIS_BO_CASH CSRInstructionCheckIRL
		{
		public:

			/**
			* Typically used to check IRL on a single instruction.
			* Must be overridden.
			*
			* @param	_listInstruction: the list of instructions to check
			* throws a CSRBOCashInstrCheckIRLException in case of failure to pass the check...
			**/
			virtual void IsOK(const CSRInstructionList _listInstruction) throw (CSRBOCashInstrCheckIRLException){;};

			/** Prototype stuff
			*/
			virtual CSRInstructionCheckIRL* Clone() const {throw 1;};
			/** the Condition key is a C string
			*/
			typedef sophis::tools::CSRPrototype<CSRInstructionCheckIRL, const char*, sophis::tools::less_char_star> prototype;
			/** Get the prototype singleton
			@return		the prototype singleton
			@see		CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	} // namespace
} //namespace
SPH_EPILOG
#endif
