#ifndef __SPHInstructionCondition__
#define __SPHInstructionCondition__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_cash/SphInstruction.h"

#define DECLARATION_INSTRUCTION_CONDITION(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_cash::CSRInstructionCondition)
#define CONSTRUCTOR_NSTRUCTION_CONDITION(derivedClass)
#define	INITIALISE_INSTRUCTION_CONDITION(derivedClass, name) INITIALISE_PROTOTYPE(derivedClass,  name)

#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_cash
	{
		class CSRDefinitionFlow;
		class CSRInstruction;

		class SOPHIS_BO_CASH CSRInstructionCondition
		{
		public:
			/**
			* Called to check that a list of instructions respect a condition associated to a SWF transition.
			* If the whole list respects that condition, than the transition can be selected by CSRBOCashWorkflow
			* Must be overridden.
			*
			* @param	flow: The flow executed
			* @param	instList: A list of instructions
			* @return   True if the condition is respected by all instructions in the list. False otherwise.
			* @version 5.2
			**/
			virtual bool IsOK(const CSRDefinitionFlow& flow, CSRInstructionList instrList) { return true; }

			/** "virtual copy constructor"
			* @return CSRInstructionCondition* a copy of the object
			*/
			virtual CSRInstructionCondition* Clone() const { throw 1; }

			/** The key for the prototype is a const char *
			* @see sophis::tools::CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRInstructionCondition, const char *, sophis::tools::less_char_star> prototype;
			
			/** Access to the prototype singleton.
			* @see sophis::tools::CSRPrototype
			**/
			static prototype & GetPrototype();
		};
	}
}

SPH_EPILOG

#endif //__SPHInstructionCondition__
