#ifndef _SphInstructionCtxMenu_H_
#define _SphInstructionCtxMenu_H_
#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"


#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphInc/backoffice_otc/SphMessage.h"

#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_INSTRUCTION_CTX_MENU(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRInstructionBlotterCtxMenu)
#define CONSTRUCTOR_INSTRUCTION_CTX_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSTRUCTION_CTX_MENU(derivedClass)
#define	INITIALISE_INSTRUCTION_CTX_MENU(derivedClass,name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_cash
	{
	
		/** Interface for creating specific menu for instructions/messages on the instruction blotter.
		This class can be overloaded to insert user's own actions on instructions/messages 
		using contextual menu from the instruction blotters.
		*/
		class SOPHIS_BO_CASH CSRInstructionBlotterCtxMenu
		{
		public:

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CREDIT_RISK_CALC_MODEL.
			@see tools::CSRPrototype
			*/
			virtual CSRInstructionBlotterCtxMenu* Clone() const { throw sophisTools::base::NotImplemented("CSRInstructionBlotterCtxMenu::Clone()"); }

			/** Trivial Constructor.
			*/
			CSRInstructionBlotterCtxMenu();

			/** Trivial Destructor.
			*/
			virtual ~CSRInstructionBlotterCtxMenu();

			/** Typedef for the prototype.
			*/
			typedef sophis::tools::CSRPrototype<CSRInstructionBlotterCtxMenu, const char *, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_INSTRUCTION_CTX_MENU.
			@see tools::CSRPrototype				  
			*/
			static prototype & GetPrototype();

			/** 
			Return true if this menu must be displayed with this selection of instructions.
			Else return false.
			This method is called first, so cache initialization can be done here.
			It is possible from the instruction blotter to select instructions and messages.
			@param instructionVector is the vector of instructions selected before right click.
			@param messageVector is the vector of messages selected before the right click.
			@return true if the menu must be displayed with this list of instructions.
			*/
			virtual bool IsAuthorized(const _STL::vector<CSRInstruction>& instructionVector, const _STL::vector<sophis::backoffice_otc::CSRMessage>& messageVector) const
			{
				return true;
			}

			/**
			Perform the action associated to the menu on the lists of instructions and messages.
			@param instructionVector is the vector of copies of instructions selected.
			@param messageVector is the vector of copies of messages selected.
			*/
			virtual void Action(const _STL::vector<CSRInstruction>& instructionVector, const _STL::vector<sophis::backoffice_otc::CSRMessage>& messageVector) const = 0;
		};
	} // namespace backoffice_cash
} // namespace sophis

SPH_EPILOG

#endif