#pragma once
#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"
#include "SphTools/SphExceptions.h"
#include "SphInstruction.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace sql {
		class CSRStructureDescriptor;
	} 
	namespace backoffice_cash {

class CSRInstruction;
class CBowsIncomingInstruction;
class CSRInstructionSummed;

enum eInstructionLoaderType{
	eInstructionLoader,
	eInstructionLoaderSummed
};

class SOPHIS_BO_CASH CSR_IM_Exception : public sophisTools::base::GeneralException
{
public:
	CSR_IM_Exception(char* description, char* fileName,
					 long lineNumber, char* function);

	const _STL::string GetDescription() const;
	const _STL::string GetFileName() const;
	const long GetLineNumber() const;
	const _STL::string GetFunction() const;
	virtual const _STL::string GetString() const;

protected:
	virtual const char* GetExceptionClassName() const;
	virtual const _STL::string GetEnvironmentString() const;
	_STL::string fDescription;
	_STL::string fFileName;
	long fLineNumber;
	_STL::string fFunction;
private:
	static const char* __CLASS__;
};

class SOPHIS_BO_CASH CSR_IM_NoInstructionsFoundException : public CSR_IM_Exception
{
public:
	CSR_IM_NoInstructionsFoundException(char* description, char* fileName,
								 long lineNumber, char* function);

protected:
	virtual const char* GetExceptionClassName() const;
private:
	static const char* __CLASS__;
};

class SOPHIS_BO_CASH CSR_IM_IndexOutOfBoundsException : public CSR_IM_Exception
{
public:
	CSR_IM_IndexOutOfBoundsException(char* description, char* fileName,
								 long lineNumber, char* function);

protected:
	virtual const char* GetExceptionClassName() const;
private:
	static const char* __CLASS__;
};

/** Class in charge of loading instructions. It uses the SPH_LOAD_INSTRUCTIONS Oracle stored procedure
in order to optimise the performances of the loading.
It is a singleton and must be accessed via the getInstance method.
It manages 2 types of instances: eInstructionLoader, eInstructionLoaderSummed.
eInstructionLoaderSummed contains the latest version of the instruction plus 2 extra columns: 
-Total settled quantity (CSRInstructionSummed::totalQuantity)
-Total settled amount (CSRInstructionSummed::totalAmount)
Also, the eInstructionLoaderSummed instance returns arrays of type CSRInstructionSummed instead of CSRInstruction
@version 5.2.5.N12,5.3.5.2,6.0.Z
 */
class SOPHIS_BO_CASH CSRInstructionLoader
{
public:
	/** Destructor
	*/
	~CSRInstructionLoader();

	/** The access point which must be used to get an instance of this class
	*/
	static CSRInstructionLoader* getInstance();

    enum Direction { PREV, NEXT } ;

	/** Loads all the instructions with all their versions for a specific deal id and version
	*/
	virtual void loadInstructionsForTrade( portfolio::TransactionIdent TradeId, long TradeVersion );

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual void loadInstructionsForTrade(long TradeId, 
	                                      long TradeVersion)

	{
		throw sophisTools::base::NotImplemented("loadInstructionsForTrade");
	}
# endif GCC_XML

	/** Loads all the instructions with all their versions for a the latest version of a specific deal id
	*/
	virtual void loadInstructionsForTradeWithHighestVersion( portfolio::TransactionIdent TradeId);// DB: Fixed bug IBOS-6B2DWG(Instructions not updated on modifying a deal in the FO)

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual void loadInstructionsForTradeWithHighestVersion(long TradeId)
	{
		throw sophisTools::base::NotImplemented("loadInstructionsForTradeWithHighestVersion");
	}
# endif GCC_XML

	/** Loads all the instructions with a given status
	*/
	virtual void loadInstructionsWithStatus( long Status );

	/** Loads all the instructions with a given internal status
	*/
	virtual void loadInstructionsWithInternalStatus( long Status );

	/** Loads all the instructions specified in the list of IDs and versions passed as parameter
	*/
	virtual void loadInstructionsList(long instructionsIdents[], 
	                                  long instructionsVersions[], 
	                                  int instructionsIdentsSize );

	/** Loads all the instructions specified in the list of IDs and versions passed as parameter, and load trade data based on param
	*/
	virtual void loadInstructionsList(long instructionsIdents[], 
	                                  long instructionsVersions[], 
	                                  int instructionsIdentsSize, 
	                                  bool loadTradeData );

	/** Loads all the latest versions of the instructions specified in the list of IDs passed as parameter
	*/
	virtual void loadInstructionsWithLatestVersionList(long instructionsIdents[], 
	                                                   int instructionsIdentsSize );

	/** Used to navigate in the loaded instructions
	Still used. Exple: WFFormerStatusRule
	*/
	virtual const CSRInstruction& locateLatestInstruction();

	/** Used to navigate in the loaded instructions
	Still used. Exple: WFFormerStatusRule
	*/
	virtual const CSRInstruction& getInstruction(	const Direction dir = NEXT, const CSRInstruction* current = 0);

	/** Returns the instruction in position "index" from the loaded instructions
	*/
	virtual const CSRInstruction& getInstruction(int index);

	/** Returns an array containing the references to all the loaded instructions
	*/
	virtual const _STL::vector<sophis::backoffice_cash::CSRInstruction>& getInstructionArrayRefs() const;

	/** Returns the instruction for the specified id and version
	*/
	virtual CSRInstruction loadSingleInstruction( long InstructionId, long InstructionVersion );

	/** Returns the instruction with the latest version for the specified id
	*/
	virtual CSRInstruction loadSingleLatestInstruction( long _instructionId);

	/** Returns the instruction with the latest id and the latest version for the specified trade id and version
	*/
	virtual CSRInstruction loadSingleLatestInstructionForTrade(portfolio::TransactionIdent TradeId, 
	                                                           long TradeVersion);

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual CSRInstruction loadSingleLatestInstructionForTrade(long TradeId, 
	                                                           long TradeVersion)
	{
		throw sophisTools::base::NotImplemented("loadSingleLatestInstructionForTrade");
	}
# endif GCC_XML

	/** Returns the instruction with the latest id and the latest version from the latest version of the specified trade id
	*/
	virtual CSRInstruction loadSingleLatestInstructionForTradeWithHighestVersion(portfolio::TransactionIdent _tradeId);

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual CSRInstruction loadSingleLatestInstructionForTradeWithHighestVersion(long _tradeId)	
	{
		throw sophisTools::base::NotImplemented("loadSingleLatestInstructionForTradeWithHighestVersion");
	}
# endif GCC_XML

	/** Loads instructions and their related trade information into a CSRInstruction[]
	The information loaded is later accessible via the getInstructionCount() and getInstructionPtr(int _index) methods

	@param _whereClause
	The SQL where clause to use to retrieve the instructions (must not contain the keyword WHERE at the beginning)

	@param _table
	Should be BO_CASH_INSTRUCTION. It allows to define an alias for the table like "BO_CASH_INSTRUCTION I"

	@param _includeTradeInfo
	If true, the deal information related to the instruction will be loaded.

	@param _includeNettedInstr
	If true, the instructions netted to the loaded instructions will be added to the list.

	@param _param1
	This allows to pass one dynamic parameter to Oracle as part of the query. It must be referenced in the where clause above (like :var1 for example).

	@param _param2
	This allows to pass a second dynamic parameter to Oracle as part of the query. It must be referenced in the where clause above (like :var2 for example).

	@param _useMaxLinePref
	If true, the riskpref MaxLinesInSecBlotters is used for the maximum number of lines to load. If more lines are specified in the where clause, only the first x are returned and a warning is displayed.

	@param _orderBy
	The SQL order by clause to use when loading.
	*/
	virtual int load(eInstructionLoaderType _type, 
	                 _STL::string _whereClause, 
	                 _STL::string _table, 
	                 bool _includeTradeInfo=true, 
	                 bool _includeNettedInstr=true, 
	                 portfolio::TransactionIdent _param1=-1, 
	                 portfolio::TransactionIdent _param2=-1, 
	                 bool _useMaxLinePref=false, 
	                 _STL::string _orderBy="");

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual int load(eInstructionLoaderType _type, 
	                 _STL::string _whereClause, 
	                 _STL::string _table, 
	                 bool _includeTradeInfo, 
	                 bool _includeNettedInstr, 
	                 long _param1, 
	                 long _param2, 
	                 bool _useMaxLinePref, 
	                 _STL::string _orderBy)
	{
		throw sophisTools::base::NotImplemented("load");
	}
# endif GCC_XML

	/** Returns the count of loaded instructions
	*/
	virtual int getInstructionCount() const;

	/** Returns the instruction at position _index from the loaded instructions
	*/
	virtual CSRInstruction* getInstructionPtr(int _index);

	/** Returns a copy of the instruction at position _index from the loaded instructions
	*/
	virtual CSRInstruction* getInstructionCopyPtr(int _index);

protected:
	CSRInstructionLoader();
	void ClearList();
	_STL::string parseStringForProcParam(_STL::string _param);

	
	eInstructionLoaderType m_Type;
	_STL::vector<CSRInstruction> m_InstructionList;

	static CSRInstructionLoader* m_Instance;
	static CSRInstructionLoader* m_InstanceSummed;

private:
	static const char* __CLASS__;
};

	}
}

SPH_EPILOG