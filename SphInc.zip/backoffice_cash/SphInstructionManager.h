#pragma once


#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/backoffice_cash/SphInstructionLoader.h"



SPH_PROLOG
namespace sophis {
	namespace sql {
		class CSRStructureDescriptor;
		class CSRSqlQuery;
	}
}

namespace sophisTools
{
	class csrstring;
}

namespace sophis {
	namespace backoffice_cash {

class CSRInstruction;
class CBowsIncomingInstruction;

class SOPHIS_BO_CASH CSR_IM_DataBaseException : public CSR_IM_Exception
{
public:
	CSR_IM_DataBaseException(char* description, char* fileName,
							 long lineNumber, char* function,
							 long instrutionId, long instructionVersion, long sqlErrorCode);

	long GetInstructionId() const;
	long GetInstructionVersion() const;
	long GetSQLErrorCode() const;

protected:
	virtual const char* GetExceptionClassName() const;
	virtual const _STL::string GetEnvironmentString() const;
	long fInstructionId;
	long fInstructionVersion;
	long fSQLErrorCode;
private:
	static const char* __CLASS__;
};

class SOPHIS_BO_CASH CSR_IM_UpdateException : public CSR_IM_DataBaseException
{
public:
	CSR_IM_UpdateException(char* description, char* fileName,
							 long lineNumber, char* function,
							 long instrutionId, long instructionVersion, long sqlRetCode);

protected:
	virtual const char* GetExceptionClassName() const;
private:
	static const char* __CLASS__;
};

class SOPHIS_BO_CASH CSR_IM_InsertException : public CSR_IM_DataBaseException
{
public:
	CSR_IM_InsertException(char* description, char* fileName,
							 long lineNumber, char* function,
							 long instrutionId, long instructionVersion, long sqlRetCode);

protected:
	virtual const char* GetExceptionClassName() const;
private:
	static const char* __CLASS__;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//CSRInstructionManager
/////
//
//  From 6.0: All methods related to the loading of instructions have been removed.
//            They were "deprecated" since 535.2, as CSRInstructionLoader must now be used for that purpose
class SOPHIS_BO_CASH CSRInstructionManager
{
public:
	CSRInstructionManager( );
	~CSRInstructionManager( );

	/////////////////////////////////////////////////////////////////////////////////////
	//These methods insert/update instructions
	///////
	static CSRInstructionManager* getInstance();
	virtual const bool updateInstructionNettingInfo( const CSRInstruction& instruction);
	static const bool addInstruction( CSRInstruction& instruction );
	virtual const bool addInstructionM( CSRInstruction& instruction );
	static const bool updateInstruction(const CSRInstruction& instruction);
	virtual const bool updateInstructionM(const CSRInstruction& instruction);
	static const long UpdateInternalStatusChange(CSRInstruction& instruction, bool reSending = false);

	/////////////////////////////////////////////////////////////////////////////////////
	//Other stuff
	///////
	static const long GetUserIDOfLastModifier(long instructionID);
	
protected:
	/////////////////////////////////////////////////////////////////////////////////////
	//protected variables
	sql::CSRStructureDescriptor*	fUpdateNettingInfoParamDesc;	
	sql::CSRSqlQuery*				fUpdateNettingInfoQuery;

	static CSRInstructionManager* m_Instance;
	
private:
	static const char* __CLASS__;

};
////////////////////////////////////////////////////////////////////////////////


	}
}

SPH_EPILOG



