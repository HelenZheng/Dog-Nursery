#ifndef __SphInstructionSelectorCondition__
#define __SphInstructionSelectorCondition__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_cash {

#define DECLARATION_INSTRUCTION_SELECTOR_CONDITION(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_cash::CSRInstructionSelectorCondition)
#define CONSTRUCTOR_INSTRUCTION_SELECTOR_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSTRUCTION_SELECTOR_CONDITION(derivedClass)
#define	INITIALISE_INSTRUCTION_SELECTOR_CONDITION(derivedClass, name)\
	INITIALISE_PROTOTYPE(derivedClass,  name)

		/** New condition for instructions.
		@version 5.2.7 this class is now included in Sophis.dll
		@since 5.2.6
		*/
		class SOPHIS_FIT CSRInstructionSelectorCondition
		{
		public:
			/** Static method to be called externally to get the condition state of the line of 
			* Securities Workflow Selector blotter.
			* @param tr - is the reference to the corresponding transaction.
			* @param vcond - is the vector of string values of condition columns of the line to be checked. 
			* @return - true if all conditions from @vcond param are met, false - otherwise.
			* @version 5.2.6
			**/
			static bool IsConditionMet(const sophis::portfolio::CSRTransaction& tr, 
										const _STL::vector<_STL::string> &vcond);
			/** Method which is called internally by static method sIsConditionMet() to check 
			* a single condition from @vcond vector (see sIsConditionMet() static method above).
			* @return - true if this single condition is met, false - otherwise. 
			* @version 5.2.6
			**/
			virtual bool GetCondition(const sophis::portfolio::CSRTransaction& tr) const = 0;
			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSAUTOMATCHINGALGO.
			@see tools::CSRPrototype
			*/
			virtual CSRInstructionSelectorCondition* Clone() const = 0;
			
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRInstructionSelectorCondition, 
												const char*, 
												sophis::tools::less_char_star> prototype;
			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_INSAUTOMATCHINGALGO.
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();
		};

	}
}
SPH_EPILOG
#endif //__SphInstructionSelectorCondition__
