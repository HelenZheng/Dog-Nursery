#ifndef __CSRINSTRUCTIONUTILS_H__
#define __CSRINSTRUCTIONUTILS_H__
#include "SphInc/backoffice_cash/SphInstruction.h"
#include "SphTools/SphExceptions.h"

namespace sophis
{
	namespace backoffice_cash
	{
		class SOPHIS_BO_CASH sNettingRow
		{
		public:
			long row;
			long cptyID;

			sNettingRow();
			bool operator==(const sNettingRow &row);
			bool operator!=(const sNettingRow &row);
		};

		class SOPHIS_BO_CASH InstructionMod
		{
		public:
			long id;
			int mod;
		};

		class SOPHIS_BO_CASH CSRInstructionUtils
		{
		public:
			static bool GetNettingConfig(const sophis::backoffice_cash::CSRInstruction *instruction, sNettingRow &row);
			static bool IsNettingEvent(int sel);
			static bool CheckNettingConditions(const sophis::backoffice_cash::CSRInstructionList &instructionList);
			static bool CSRInstructionUtils::ExecuteEvent(long eventID, sophis::backoffice_cash::CSRInstructionList& instructionList, _STL::vector<InstructionMod> &instructionMod);
		};

		class SOPHIS_BO_CASH CSRInstructionNettingException : public sophisTools::base::ExceptionBase
		{
		public:
			CSRInstructionNettingException(const char* message);
		};
	}
}
#endif