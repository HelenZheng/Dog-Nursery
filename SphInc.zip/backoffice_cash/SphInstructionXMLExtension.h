#ifndef __CS_INSTRUCTION_XML_EXTENSION_H__
#define __CS_INSTRUCTION_XML_EXTENSION_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_INSTRUCTIONXMLEXTENSION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRInstructionXMLExtension)
#define CONSTRUCTOR_INSTRUCTIONXMLEXTENSION(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSTRUCTIONXMLEXTENSION(derivedClass)
#define	INITIALISE_INSTRUCTIONXMLEXTENSION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis 
{
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}

	namespace backoffice_cash
	{

		class CSRInstruction;

		class SOPHIS_BO_CASH CSRInstructionXMLExtension
		{
		public:
			/** This method must be overridden in order to provide a name
			for the dataset/extra XML node.
			*/
			virtual _STL::string getExtraXMLDatasetName() const = 0;

			/** Overridden in order to provide custom XML extensions to instructions, by adding 
			extra information in a DataSet.

			@param currentTransaction
			A (const) reference to the transaction relating to this instruction.

			@param dataSetToFill
			A DataSet that the implementer may fill as it chooses.
			*/
			virtual void IncludeExtraDataWithDataset(const portfolio::CSRTransaction* currentTransaction, 
				const sophis::backoffice_cash::CSRInstruction* instruction,
				sophis::tools::dataModel::DataSet& dataSetToFill) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSTRUCTIONXMLEXTENSION.
			@see tools::CSRPrototype
			*/
			virtual CSRInstructionXMLExtension* Clone() const { throw 1; }

			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef tools::CSRPrototype<CSRInstructionXMLExtension, const char *, tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();	
		};

	}
}
SPH_EPILOG
#endif //#define __CS_INSTRUCTION_XML_EXTENSION_H__
