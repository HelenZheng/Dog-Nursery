#pragma once

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_NETTING_RULES_CONDITION(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRNettingRulesCondition)
#define	INITIALISE_NETTING_RULES_CONDITION(derivedClass, name) INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG

namespace sophis
{	
	namespace backoffice_otc 
	{
		class CSRMessage;
	}

	namespace backoffice_cash
	{
		/** 
		* Abstract base class for toolkitted condition criteria in netting tab of third parties.
		* Overload this class with your own conditioning code to add extra rules or overload current netting rules		
		*/
		class SOPHIS_FIT CSRNettingRulesCondition
		{
		public:
			/** 
			* Called to apply new/extra rule conditions before creating a netting line or adding a new message to an existing netting line.
			* Overload this function to write your own new/extra rules conditions.
			* @param	current: The current message being created
			* @param   existing: The existing message being checked against to create a new netting line with, or the netting line that the current message
		    *					 would be added to. Use SourceId to determine if it's a message or a netting line
			* @return   true if all the new rule conditions are met for the given message pair. Otherwise false.
			*/
			virtual bool checkCondition(backoffice_otc::CSRMessage* current, backoffice_otc::CSRMessage* existing) const = 0; 

			static bool checkCondition(const char* conditionname, backoffice_otc::CSRMessage* current, backoffice_otc::CSRMessage* existing); 
								
			//	Prototype stuff
			virtual CSRNettingRulesCondition* Clone() const { throw 1; }
			typedef sophis::tools::CSRPrototype<CSRNettingRulesCondition, const char *, sophis::tools::less_char_star> prototype;
			static prototype & GetPrototype();
		} ;
	}
}

SPH_EPILOG