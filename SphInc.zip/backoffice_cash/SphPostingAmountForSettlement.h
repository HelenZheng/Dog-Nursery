#pragma once

#ifndef SPH_POSTING_AMOUNT_FOR_SETTELMENT_H
#define SPH_POSTING_AMOUNT_FOR_SETTELMENT_H

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_POSTING_AMOUNT_FOR_SETTLEMENT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRPostingAmountForSettlement)
#define CONSTRUCTOR_POSTING_AMOUNT_FOR_SETTLEMENT(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_AMOUNT_FOR_SETTLEMENT(derivedClass)
#define	INITIALISE_POSTING_AMOUNT_FOR_SETTLEMENT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_cash
	{

		class CSRInstruction;

		/** Interface to create a posting amount from an instruction.
		It is used as a amount for a settlement rule.
		You can implement this interface to add an amount on the list.
		@see CSRPostingDateSettlement
		@since 4.5.0
		*/
		class SOPHIS_BO_CASH CSRPostingAmountForSettlement
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSRPostingAmountForSettlement() {}

			/** Get the amount to post.
			Method called by the settlement engine in the BOWS server to calculate the amount to post before conversion in the currency.
			@param instruction is the instruction of settlement treated by the BOWS.
			@param trade is the original transaction corresponding to the instrument.
			@param currency is an output parameter defining the amount currency; the amount posted can be converted
			according the currency wanted in the accounting rule.
			@param instrument is code of instrument for this posting; it is used to find the account in the chart.
			@returns amount for this posting.
			@see CSRForexRule
			*/
			virtual double get_posting_amount(
						const backoffice_cash::CSRInstruction &instruction,
						const portfolio::CSRTransaction& trade,
						long* currency,
						long* instrument) const = 0;

			/** Get the singleton for one settlement amount.
			This is equivalent to CSRPostingAmountForSettlement::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the amount name is not found.
			@param amountName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingAmountForSettlement* getInstance( const char* amountName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_AMOUNT_FOR_SETTLEMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingAmountForSettlement* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef tools::CSRPrototype<CSRPostingAmountForSettlement
							,const char*, tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_AMOUNT_FOR_SETTLEMENT.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}

SPH_EPILOG

#endif // SPH_POSTING_AMOUNT_FOR_SETTELMENT_H

