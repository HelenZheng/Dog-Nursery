#pragma once

#ifndef _SphRulesConditionInstruction_H_
#define _SphRulesConditionInstruction_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_RULES_CONDITION_INSTRUCTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRRulesConditionInstruction)
#define CONSTRUCTOR_RULES_CONDITION_INSTRUCTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_RULES_CONDITION_INSTRUCTION(derivedClass)
#define	INITIALISE_RULES_CONDITION_INSTRUCTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace backoffice_cash
	{
		class CSRInstruction;

		/** Interface to create a condition for the settlement engine.
		It is used as a condition to know if a instruction rule has to be applied.
		You can implement this interface to add a condition on the list.
		@since 4.5.0
		*/
		class SOPHIS_BO_CASH CSRRulesConditionInstruction
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRRulesConditionInstruction() {}

			/** Tell if the rule applied according the condition.
			This is called by the settlement engine in the BOWS to know if settlement instruction has to
			be applied after all the other criteria matches.
			@param instruction is the instruction of settlement treated by the BOWS.
			@param trade is the original transaction corresponding to the instrument.
			@return true if the rule has to be applied.
			*/
			virtual bool get_condition( const backoffice_cash::CSRInstruction& instr
									   ,const portfolio::CSRTransaction& trade ) const = 0;

			/** Get the singleton for one condition instruction.
			This is equivalent to CSRRulesConditionInstruction::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the rule condition is not found.
			@param modelName is a C string for the rule condition.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRRulesConditionInstruction* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_RULES_CONDITION_INSTRUCTION.
			@see tools::CSRPrototype
			*/
			virtual CSRRulesConditionInstruction* Clone() const = 0;


			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRRulesConditionInstruction
												,const char*
												,sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a condition rule to this singleton, use INITIALISE_RULES_CONDITION_INSTRUCTION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}
SPH_EPILOG
#endif // _SphRulesConditionInstruction_H_

 
