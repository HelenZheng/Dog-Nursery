#pragma once

#ifndef _SPH_RULESTHIRDPARTYTYPE_H_
#define _SPH_RULESTHIRDPARTYTYPE_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_RULES_THIRD_PARTY_TYPE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRRulesThirdPartyType)
#define CONSTRUCTOR_RULES_THIRD_PARTY_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_RULES_THIRD_PARTY_TYPE(derivedClass)
#define	INITIALISE_RULES_THIRD_PARTY_TYPE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace backoffice_cash
	{
		class CSRInstruction;

		/** Interface to find the third party from an instruction.
		It is used to fill the third party field.
		You can implement this interface to add a new type of third party on the list.
		@see CSRPostingAmountForSettlement
		@see CSRPostingDateSettlement
		*/
		class SOPHIS_BO_CASH CSRRulesThirdPartyType
		{
		public:
			/** Get the third party to post.
			Method called by the settlement engine in the BOWS server to calculate the thrid party to post.
			It is also used to find the account.
			@param instruction is the instruction of settlement treated by the BOWS.
			@param trade is the original transaction corresponding to the instruction.
			@returns a thrid party id.
			*/
			virtual long get_third_party(
						const backoffice_cash::CSRInstruction &instruction,
						const portfolio::CSRTransaction& trade ) const = 0;

			/** Get the singleton for one third party.
			This is equivalent to CSRRulesThirdPartyType::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the date name is not found.
			@param modelName is a C string for the third party type.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRRulesThirdPartyType* getInstance( const char* modelName ) ;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_DATE_SETTLEMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRRulesThirdPartyType* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRRulesThirdPartyType
					,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_RULES_THIRD_PARTY_TYPE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}

SPH_EPILOG

#endif //_SPH_POSTINGDATESETTLEMENT_H_
