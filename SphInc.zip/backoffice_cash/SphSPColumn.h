#ifndef _SphSCPColumn_H_
#define _SphSCPColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphEnums.h"
#include "SphInc/SphMacros.h"
//#include "SphInc/collateral/SphSecuritiesReportCommon.h"


SPH_PROLOG

struct SSCellStyle;
union SSCellValue;

namespace sophis {
	namespace backoffice_cash {

		class CSRSPReportResultHier;
/**
 * Macros for handling SCP column prototype implementation.
 */
#define DECLARATION_SP_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_cash::CSRSPColumn)
//#define CONSTRUCTOR_SCP_COLUMN(derivedClass)
//#define WITHOUT_CONSTRUCTOR_SCP_COLUMN(derivedClass)

#define	INITIALISE_SP_COLUMN(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * SCP column and prototype.
 * 
 * To add a column, derive this class, using the macro DECLARATION_SCP_COLUMN in your header
 * and INITIALISE_SCP_COLUMN in UNIVERSAL_MAIN.
 *
 */
class SOPHIS_BO_CASH CSRSPColumn
{
public:
	/** Constructor. */
	CSRSPColumn() : fId(0) {}

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param SCP line to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCell(const CSRSPReportResultHier &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/**
	 * Clone method required by the prototype.
	 * Use DECLARATION_SCP_COLUMN macro in the implementation of the derived class.
	 */
	virtual CSRSPColumn* Clone() const = 0;

	/** 
	 * Returns the default cell size in pixels.
	 */
	virtual short GetDefaultWidth() const;

	/**
	 * Returns icon that is displayed in tree view when grouped by this column
	 */
	virtual short GetIconId() const;

	/**
	 * Returns the id.
	 * The value is created at the end of the initialise because it must
	 * be unique according to the table COLUMN_NAME.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * Used when building the columns by {@link CSUReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototypeWithId<CSRSPColumn, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to prototype singleton.
	 */
	static prototype& GetPrototype(long type = 0);

protected:
	long	fId;
};

	} // namespace backoffice_cash
} // namespace sophis

SPH_EPILOG

#endif
