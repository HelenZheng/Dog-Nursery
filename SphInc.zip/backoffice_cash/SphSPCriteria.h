#ifndef _SphSPReportCriteria_H_
#define _SphSPReportCriteria_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphReportCriteria.h"
#include "SphInc/tools/SphReportCriteriaKeyBuilder.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

#define DEFAULT_SP_VIEW "Flat"

SPH_PROLOG
namespace sophis
{
	namespace tools
	{
		class CSRReportResultHier;
		class CSRReportCriteriaKey;
	}
}

namespace sophis {
	namespace backoffice_cash {
		class CSRSPReportResultHier;

#define DECLARATION_SP_CRITERIA(derivedClass)\
	public: virtual  sophis::tools::CSRReportCriteria* Clone() const { derivedClass* c = new derivedClass(); c->Initialise(*this); return c; }
#define CONSTRUCTOR_SP_CRITERIA(derivedClass)
#define WITHOUT_CONSTRUCTOR_SP_CRITERIA(derivedClass)
#define	INITIALISE_SP_CRITERIA(derivedClass,name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::backoffice_cash::CSRSPCriteria*>(sophis::backoffice_cash::CSRSPCriteria::GetPrototype().GetData(name))->SetName(name);

/**
 * Criteria for Securities Projection.
 * @version 5.3.6
 */
class SOPHIS_BO_CASH CSRSPCriteria : public virtual sophis::tools::CSRReportCriteria
{
public:
	/**
	 * Bridge. Calls GetSpCode(). 
	 */
	virtual long GetCode(const sophis::tools::CSRReportResultHier& result) const;

	/**
	 * To be implemented in derives classes.
	 * Must return the criteria code corresponding to a given securities projection result.
	 */
	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const = 0;

	/** 
	 * Typedef for the prototype : the key is a const char*. 
	 */
	typedef tools::CSRPrototype<CSRSPCriteria, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleto, use INITIALISE_SP_CRITERIA.
	 * @see tools::CSRPrototype
	 */
	static prototype& GetPrototype();

	/** Get the nth criteria of the prototype.
	 * @param index Starts from zero.
	 * @return Criteria object or 0 if out of bounds. */
	static const CSRSPCriteria* GetCriteria(int index);

	/** Get the criteria from the prototype by name.
	 * @param name Criteria name.
	 * @return Criteria object or 0 if out of bounds. */
	static const CSRSPCriteria* GetCriteria(_STL::string& name);

	/** Get the index of given criteria in the prototype by name.
	 * @param name Criteria name.
	 * @return Index in the prototype or -1 if does not exist. */
	static int GetCriteriaIndex(_STL::string& name);

	/** Get the nth criteria name from the prototype.
	 * @param index Starts from zero.
	 * @return Criteria name or empty string if does not exist. */
	static _STL::string GetCriteriaName(int index);

	/** Gets the list of indices of the criteria that are of date type. This is needed
	 * as it should only be possible to select one date at a time.
	 * @param indices a vector which will be cleared and will have the indices of the 
	 * date criteria inserted. Date critieria are those which extend the class CSRSPCriterionDateForward.
	 * */
	static void GetDateCriteriaIndices(_STL::vector<int>& indices, int& indexDefault);
};

/**
 * The SP report expects that the last criteria will always be a date, e.g.
	
	--counterparty
		--entity
			--date

   The reason for this is because there is a special type of aggregation on the date nodes that doesnt make
   sense for any of the other nodes. 

   e.g. if the 2/11/2009 has an instruction for 1000, and the 4/11/2009 has one for 500, the values displayed would
   be as follows:
   2/11/2009  1000
   3/11/2009  1000
   4/11/2009  1500

   As this is the case, we must always make sure that the last criteria added using the builder is a type of date.
   How do we determine this? We make sure that at some point one of the criteria classes is derived from the 
   CSRSPCriterionDateForward class. If this is not the case, an error message will be given. If you would like to
   have your own special type of date (for example having a particular icon or date format string) then you must 
   inherit from the CSRSPCriterionDateForward class.

   To use the builder to create the above structure, simply do the following:
   	
	builder.AddCriteria("Counterparty");
	builder.AddCriteria("Entity");
	builder.AddCriteria("Date-Forward");
	
	Then call GetCriteriaKey() to get the key. When making several keys, it is important to call clear() in between.
   
 */
class SOPHIS_BO_CASH CSRSPReportCriteriaKeyBuilder : public sophis::tools::CSRReportCriteriaKeyBuilder
{
public:
	CSRSPReportCriteriaKeyBuilder() : CSRReportCriteriaKeyBuilder(), fDateAdded(false), fDateIndex(-1) {}
	virtual ~CSRSPReportCriteriaKeyBuilder(){}
	virtual void AddCriteria(const char* criteriaName);
	virtual const sophis::tools::CSRReportCriteriaKey& GetCriteriaKey() const;
	virtual void Clear();
	virtual bool DateAdded();
	virtual void AddDate(); // This can be called at the end to add the basic date. 
	virtual int GetIndexDate();
private:
	bool fDateAdded;
	int fDateIndex;
};

	}
}

SPH_EPILOG

#endif