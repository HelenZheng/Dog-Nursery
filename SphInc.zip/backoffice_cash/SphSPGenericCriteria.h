#ifndef _SphSPGenericCriteria_H_
#define _SphSPGenericCriteria_H_

#include "SphInc/backoffice_cash/SphSPCriteria.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {
/**
	When using the builder with the criteria protype, use the strings specified in the classes to get the
	desired critieria.
 */


class SOPHIS_BO_CASH CSRSPCriterionInstrument : public virtual CSRSPCriteria
{
	// prototype string "Instrument"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionInstrument)

	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

class SOPHIS_BO_CASH CSRSPCriterionCounterparty : public virtual CSRSPCriteria
{
	// prototype string "Counterparty"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionCounterparty)

	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

class SOPHIS_BO_CASH CSRSPCriterionEntity : public virtual CSRSPCriteria
{
	// prototype string "Entity"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionEntity)

	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

class SOPHIS_BO_CASH CSRSPCriterionAccountNo : public virtual CSRSPCriteria
{
	// prototype string "AccountNo"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionAccountNo)
	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;

protected:
#ifndef GCC_XML
	static sophis::tools::CSRIDStorage accountNoCache;
#endif

	static void ClearCache();
};

/** The date on the report will be in descending order e.g
    2/11/2009
	3/11/2009
	4/11/2009
  */
class SOPHIS_BO_CASH CSRSPCriterionDateForward : public virtual CSRSPCriteria
{
	// prototype string "Date-Forward"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionDateForward)

	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

/** The date on the report will be in descending order e.g
    4/11/2009
	3/11/2009
	2/11/2009
  */
class SOPHIS_BO_CASH CSRSPCriterionDateBackward : public virtual CSRSPCriterionDateForward
{
	// prototype string "Date-Backward"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionDateBackward)

	virtual bool less(long code1, long code2) const;
};

class SOPHIS_BO_CASH CSRSPCriterionClearer : public virtual CSRSPCriteria
{
	// prototype string "Clearer"
public:
	DECLARATION_SP_CRITERIA(CSRSPCriterionClearer)

	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

class SOPHIS_BO_CASH CSRSPCustodian : public virtual CSRSPCriteria
{
	// prototype string "Custodian"
public:
	DECLARATION_SP_CRITERIA(CSRSPCustodian)
	virtual long GetSPCode(const CSRSPReportResultHier& spResult) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual short GetIcone() const;
	virtual bool less(long code1, long code2) const;

protected:
#ifndef GCC_XML
	static sophis::tools::CSRIDStorage custodianCache;
#endif
	static void ClearCache();
};

	}
}

SPH_EPILOG
#endif