#ifndef _SphSPReportFactory_H_
#define _SphSPReportFactory_H_
#include "SphInc/tools/SphReportFactoryBase.h"

SPH_PROLOG
namespace sophis{
	namespace tools{
		class CSRReportData;
		class CSRReportResultHier;
		class CSRReportCriteriaKey;
		class CSRReportCriteria;
		struct SSReportDataBase;
	}
}

namespace sophis{
	namespace backoffice_cash{

/**
 * Securities Projection factory.
 * @version 5.3.6
 */
class SOPHIS_BO_CASH CSRSPReportFactoryImpl : public virtual sophis::tools::CSRReportFactory
{
private:
	CSRSPReportFactoryImpl() {}

public:

	/**
	 * Access to the Securities Projection factory instance.
	 */
	static const CSRSPReportFactoryImpl& GetInstance();

	virtual sophis::tools::CSRReportData* new_ReportData(const sophis::tools::SSReportDataBase& data) const;
	/** Returns one of the results for the list. */
	virtual sophis::tools::CSRReportResultHier* new_ReportResult(sophis::tools::CSRReportData * data = 0) const;
	/** Returns one of the results for the tree. */
	virtual sophis::tools::CSRReportResultHier * new_ReportResultHier(sophis::tools::CSRReportResultHier * parent = 0, const sophis::tools::CSRReportCriteriaKey * criteriaKey = 0, const sophis::tools::CSRReportCriteria * criteria = 0, long code = 0) const;

	/** Returns one of the results for the list. */
	sophis::tools::CSRReportResultHier* new_ReportResultEmptyQty(long date, const sophis::tools::CSRReportData * data = 0) const;

};
	}
}

SPH_EPILOG

#endif
