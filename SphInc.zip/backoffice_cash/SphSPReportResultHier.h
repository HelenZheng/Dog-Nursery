#ifndef _SphSPResultHier_H_
#define _SphSPResultHier_H_

#include "SphInc/tools/SphReportResultBase.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace backoffice_cash {

class SOPHIS_BO_CASH CSRSPReportResultHier : public sophis::tools::CSRReportResultHier
{
public:
	CSRSPReportResultHier(bool isTreeNode);

	CSRSPReportResultHier(sophis::tools::CSRReportData * data, bool isTreeNode);

	/** Copy Constructor. */
	CSRSPReportResultHier(const CSRSPReportResultHier& copy);	
	/** Constructor using criteria when building hierarchical view.
	 * @param parent Parent result.
	 * @param criteriaKey Complete criteria key used to build hierarchical view.
	 * @param criteria Criteria specific to the node being built.
	 * @param code Criteria code specific to the node being built.
	 */	
	CSRSPReportResultHier(CSRReportResultHier * parent, sophis::tools::CSRReportData *data, const sophis::tools::CSRReportCriteria * criteria, long code, bool isTreeNode);	
	/** Destructor. */
	virtual ~CSRSPReportResultHier();
	
	/** Performs aggregation of the values. */
	virtual void Aggregate(bool force = false) const;

	/** Check if node is second last internal node. This should mean that it is the one above the date
	    The date node should always be the last one in the SP report.*/
	virtual bool CheckNodeLastInternal() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the counterparty*/
	virtual long GetCounterparty() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the entity*/
	virtual long GetEntity() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the date of the instruction*/
	virtual long GetDate() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the clearer id*/
	virtual long GetClearer() const;

	/** If it is an internal node it will return "", if it has an fData, it will return the account no*/
	virtual _STL::string GetAccountNo() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the sicovam*/
	virtual long GetInstrumentCode() const;

	/** If it is an internal node it will return "", if it has an fData, it will return the instrument type*/
	virtual _STL::string GetInstrumentType() const;

	/** If it is an internal node it will return "", if it has an fData, it will return the instrument ref*/
	virtual _STL::string GetInstrumentRef() const;

	/** If it is an internal node it will return "", if it has an fData, it will return the instrument model*/
	virtual _STL::string GetInstrumentModel() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the theoretical quantity*/
	virtual double GetQuantityTheoretical() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the total stock quantity*/
	virtual double GetQuantityTotalStock() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the clearer quantity*/
	virtual double GetQuantityClearer() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the remaining quantity*/
	virtual double GetQtyRemaining() const;

	/** If it is an internal node it will return 0, if it has an fData, it will return the difference between the 
	 *  total stock quantity and the clearer quantity.
	 */
	virtual double GetBridge() const;

	/** If it is an internal node it will return "", if it has an fData, it will return the custodian reference*/
	virtual _STL::string GetCustodian() const;

	/** Removes given result from the list. */
	// Not implemented yet
	virtual void RemoveResult(const CSRReportResultHier& result);

	virtual CSRReportResultHier* Clone() const;
protected:
	virtual void AddDataValues(const sophis::tools::CSRReportData & data) const;

	/** In the SP report the date nodes are handled differently. This function will sum all the nodes in the the fList
	    @return true if it has aggregated forward, false if backward */
	virtual bool AggregateList() const;

	/** This function will sum all the nodes in the the fList in a forward direction. Called from AggregateList.*/
	virtual void AggregateListForward() const;

	/** This function will sum all the nodes in the the fList in a backward direction. Called from AggregateList.*/
	virtual void AggregateListBackward() const;

	/** Adds 2 data values together. To be used when aggregating the list of nodes */
	virtual void AddDataValues(const sophis::tools::CSRReportData* data1, sophis::tools::CSRReportData* data2) const;
};
	}
}
SPH_EPILOG
#endif