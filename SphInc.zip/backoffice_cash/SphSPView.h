#ifndef _SphSPView_H_
#define _SphSPView_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphReportCriteriaKey.h"

#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis{
	namespace tools{
class CSRReportCriteriaKey;
	}
}
namespace sophis
{
	namespace backoffice_cash
	{
/**
 * Collection of views (criteria keys) for the SP report.
 * This collection of views is dynamic and is not the same as a typical prototype class.
 * Views will be added to this prototype as they are created by the user during execution.
 */
class SOPHIS_BO_CASH CSRSPView : public tools::CSRPrototype<sophis::tools::CSRReportCriteriaKey, _STL::string/*, tools::less_char_star*/>
{
protected:
	CSRSPView() {}
public:
	//typedef typename _STL::map<const char*, sophis::tools::CSRReportCriteriaKey*, lower, _A>::iterator iterator;
	typedef CSRSPView::iterator iterator;
	/** Access to the prototype singleton. */
	//typedef tools::CSRPrototype<CSRSPView, const char*, tools::less_char_star> prototype;
	static CSRSPView& GetPrototype();

	/** Adds given criteria key to the prototype. */
	virtual void InitialisePrototype(const _STL::string& name, const sophis::tools::CSRReportCriteriaKey& criteriaKey);

	/** Adds given criteria key to the prototype. */
	virtual void InitialisePrototype(const sophis::tools::CSRReportCriteriaKey& criteriaKey, const char* name);

	/** Delete one of the prototypes during execution 
		Note: This class is not intended as a typical prototype class.
		The Prototypes may be deleted during execution, So care needs to be taken.
	*/
	virtual void RemoveItem(const _STL::string& name);

	/** This function is used to replace the criteria key that is mapped to by the
        name string.
	*/
	virtual void ReplaceItem(const _STL::string& name, const sophis::tools::CSRReportCriteriaKey& criteriaKey);
};

	}
}

SPH_EPILOG

#endif