#ifndef SPH_SETTLEMENT_ENGINE_H
#define SPH_SETTLEMENT_ENGINE_H

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace accounting
	{
      class CSREngineQueriesSett;
      class SSFinalPosting;
	  class CSREngineQueriesIncomingMessage;
	  class CSREngineQueriesInsrtPosts;

	}

	namespace backoffice_cash
	{
		class CSRInstruction;

class SOPHIS_BO_CASH CSRSettlementEngine
{
public:
	static bool GetAllPostings(	const portfolio::CSRTransaction&	trade,
								long								version,
								const CSRInstruction&				instruction,
								accounting::SSFinalPosting**		finalPostingArray,
								int*								sizeFinalPostingArray,
								accounting::CSREngineQueriesSett*	engQueries) ;


	static void InsertAllPostingInDB(accounting::SSFinalPosting* finalPostingArray,
								     int sizeFinalPostingArray,
									 accounting::CSREngineQueriesInsrtPosts *queries);
};

}
}

SPH_EPILOG

#endif // SPH_SETTLEMENT_ENGINE_H
