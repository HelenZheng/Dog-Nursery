#pragma once

#ifndef _SPH_SETTLEMENT_RULE_CONDITION_H_
#define _SPH_SETTLEMENT_RULE_CONDITION_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_SETTLEMENT_RULES_CONDITION(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_cash::CSRSettlementRulesCondition)
#define	INITIALISE_SETTLEMENT_RULES_CONDITION(derivedClass, name) INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG

namespace sophis
{
	namespace backoffice_kernel
	{
		class ISRSsiLinksTkCriteria;
	}
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace instrument
	{
		class CSRInstrument;
	}
	namespace backoffice_cash
	{
		/** 
		* Abstract base class for toolkitted condition criteria in settlement instruction tab of third parties.
		* Overload this class with your own conditioning code to add extra rules or overload current rules of the 
		* settlement instructions.
		*
		* @version 5.2.7 Change of place : in Sophis.dll now.
		* @since 5.2.6
		*/
		class SOPHIS_FIT CSRSettlementRulesCondition
		{
		public:
			/** 
			* Called to apply new/extra rule conditions to given position during settlement instruction line determination.
			* Overload this function to write your own new/extra rules conditions.
			* @param	trans: The transaction to check your new/extra rules against
			* @return   true if all the new rule conditions are met for the given position. Otherwise false.
			*/
			virtual bool checkCondition(const portfolio::CSRTransaction* trans
				, const instrument::CSRInstrument* instr
				, long linePriority = -1, long lineID = -1, long thirdPartyID = -1) const = 0; 

			/**
			* Called to apply new/extra rule conditions to given position during settlement instruction line determination.
			* Overload this function to write your own new/extra rules conditions.
			* @param	tkCrit: The TK criteria to check your new/extra rules against
			* @return   true if all the new rule conditions are met for the given position. Otherwise false.
			* @version 6.2.0
			*/
			virtual bool checkCondition(const backoffice_kernel::ISRSsiLinksTkCriteria* tkCrit
				, long linePriority = -1, long lineID = -1, long thirdPartyID = -1) const; 

			/**
			* Called during Nostro reporting to check the condition inside fetch query.
			* Overload this function to provide custom SQL condition clause. The SQL should perform the same check
			* as checkCondition method. This sql condition clause is wrapped inside 'case when' SQL clause. 
			* The condition clause may check fields from histomvts table.
			* The default implementation returns "1=1".
			* If invalid SQL clause is provided then condition avaluates to false. Effectively every invalid SQL clause is changed to "1<>1".
			* @param histomvtsAlias is the alias that must be used to reference fields in histomvts table inside the condition clause.
			* @return string.
			* @version 5.3.5
			*/
			virtual _STL::string getSQLCondition(const char * histomvtsAlias) const;

			/** The static method calls the previous one.
			* @param	name is the condition name to test; if empty, then return true.
			* @param	trans: The transaction to check your new/extra rules against
			* @return   true if all the new rule conditions are met for the given position. Otherwise false.
			@throws ExceptionNotFound if the name is not empty and is not a condition. 
			@since 5.2.7
			*/
			static bool checkCondition(const char * name, const sophis::portfolio::CSRTransaction* trans
				, const instrument::CSRInstrument* instr
				, long linePriority = -1, long lineID = -1, long thirdPartyID = -1);

			/** The static method calls the previous one.
			* @param	name is the condition name to test; if empty, then return true.
			* @param	tkCrit: The transaction to check your new/extra rules against
			* @return   true if all the new rule conditions are met for the given position. Otherwise false.
			@throws ExceptionNotFound if the name is not empty and is not a condition. 
			@since 5.2.7
			*/
			static bool checkCondition(const char * name, const backoffice_kernel::ISRSsiLinksTkCriteria* tkCrit
				, long linePriority = -1, long lineID = -1, long thirdPartyID = -1);

			//	Prototype stuff
			virtual CSRSettlementRulesCondition* Clone() const { throw 1; }
			typedef sophis::tools::CSRPrototype<CSRSettlementRulesCondition, const char *, sophis::tools::less_char_star> prototype;
			static prototype & GetPrototype();
		} ;
	}
}

SPH_EPILOG

#endif // _SPH_SETTLEMENT_RULE_CONDITION_H_
