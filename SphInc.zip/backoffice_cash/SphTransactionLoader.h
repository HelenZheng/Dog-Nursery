#ifndef SPH_TRANSACTION_LOADER
#define SPH_TRANSACTION_LOADER

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"

SPH_PROLOG
namespace sophis 
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_cash 
	{

class CSRInstruction;
class CSRBOCashNoTransactionException;

////////////////////////////////////////////////////////////////////////////////
// CSRTransactionLoader
class SOPHIS_BO_CASH CSRTransactionLoader
{
// Construction/destruction
protected:
	CSRTransactionLoader( );
public:
	virtual ~CSRTransactionLoader( );

// Interface
public:
	static CSRTransactionLoader* getInstance();

	/////////////////////////////////////////////////////////////////////////////////////
	// returns the transaction, specified by instruction
	virtual portfolio::CSRTransaction* loadTransaction( const CSRInstruction& _instr) const
		throw (sophisTools::base::GeneralException);

// Data
protected:
	static CSRTransactionLoader* mInstance;

private:
	static const char* __CLASS__;
};
////////////////////////////////////////////////////////////////////////////////
	}
}

SPH_EPILOG

#endif // SPH_TRANSACTION_LOADER
