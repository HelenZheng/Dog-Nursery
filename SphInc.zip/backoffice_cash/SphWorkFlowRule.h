#ifndef __SPH_WORKFLOW_RULE__
#define __SPH_WORKFLOW_RULE__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis {
	namespace portfolio 
	{
		class CSRTransaction;
	}

	namespace backoffice_cash {

		class CSRDefinitionFlow;
		class CSRInstruction;

const long WORKFLOW_RULE		= -1;

class SOPHIS_BO_CASH CSRWorkFlowRule
{
 public:
	 virtual bool processRule(const CSRDefinitionFlow& flow, CSRInstruction& instr) {return true;}
	 virtual bool needsUpdate(const CSRDefinitionFlow& flow, CSRInstruction& instr) {return true;}

//	Prototype stuff
	virtual CSRWorkFlowRule* Clone() const { throw 1; }
	typedef sophis::tools::CSRPrototype<CSRWorkFlowRule, const char *, sophis::tools::less_char_star> prototype;
	static prototype & GetPrototype();
};

}
}

SPH_EPILOG

#endif
