/*
 	File:		SphAllotment.h

 	Contains:	Class for the handling of accountancy rules.

 	Copyright:	� 1995-2003 Sophis.

*/

/*! \file SphAllotment.h
	\brief Class for allotments - Back Office Kernel Module.
*/


#pragma once

#ifndef _SphAllotment_H_
#define _SphAllotment_H_

#include "SphInc/SphMacros.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG

/** Internal structure for allotment
*/
struct TIndent_Affectation;

namespace sophisTools	{
	class csrvector;
}

namespace sophis
{
	namespace tools
	{
		namespace dataModel	
		{
			class DataSet;
		}
	}
}

class CSUMenu;

namespace sophis	{
	namespace backoffice_kernel	{

		/** Allotment class.
		Only available with Back Office Kernel Module.
		@version 4.4.2.1 is now in namespace back_office and the deprecated method has desappeared.
		@since 4.1.1
		*/
		struct SOPHIS_BO_KERNEL SSAllotment
		{
			SSAllotment::SSAllotment(){}

			/** Constructor with internal structure.
			*/
			SSAllotment(const TIndent_Affectation &aff);

			/** Get ID.
			*/
			long	GetID() const;

			/** Get name.
			@return a C string pointer which must not be deleted.
			*/
			const char	*GetName() const;

			/** Get position creation policy
			@return a C string pointer which must not be deleted.
			*/
			const char	*GetPositionCreationPolicy() const;

			/** Get the OTC type
			@return true if the allotment has its OTC field defined to 'yes', false otherwise.
			*/
			bool IsOTC() const;

			/** Get whether this allotment indicates a contract position or not.
			@return true if the allotment has its 'Contract Position' field defined to 'yes', false otherwise.
			*/
			bool IsContractPosition() const;

			/** Get whether this allotment falls into regulatory reporting or not.
			@return true if the allotment has its regulatory reporting field defined to 'yes', false otherwise.
			*/
			bool IsRegulatoryReporting() const;

			/** Create an allotment with an ID.
			@param id is an allotment ID.
			@return a new allotment which must be deleted; return 0 if id does not exist.
			The algorithm is in O(n) where n is the allotment count.
			*/
			static SSAllotment * new_Allotment(long id);

			/** Get the name of an allotment with an ID.
			@param id is an allotment ID.
			@return a C string pointer which must not be deleted; return "" if the allotment does not exist.
			The algorithm is in O(n) where n is the allotment count.
			*/
			static char	*GetName(long id);

			/** Get the ID of an allotment with its name.
			@param id is an allotment name.
			@return an allotment id or -1 if no allotment could be found with that name
			The algorithm is in O(n) where n is the allotment count.
			@version 4.5.2.2 The method now makes comparaison without cases, space, or '_' '-'.
			*/
			static long GetByName(const char *name);

			/** Get the OTC type of an allotment with an ID.
			@param id is an allotment ID.
			@return true if the allotment has its OTC field defined to 'yes', false otherwise.
			The algorithm is in O(n) where n is the allotment count.
			*/
			static bool SSAllotment::IsOTC(long id);

			/** Add an allotment in the static table .
			@param id of the created allotment
			@param name			
			@param positionCreation			
			@param isOtc
			*/
			static bool AddAllotment(long id, const char *name, const char *positionCreation, bool isOtc);
			
			/** Add an allotment in the static table from a dataset
			@param iData_set
			*/
			static bool CreateAllotmentFromDescription(const sophis::tools::dataModel::DataSet& iData_set) ;

		private:
			long	fId;
			char	fName[40];
			char	fPositionCreation[40];
			bool	fIsOTC;
			bool	fIsContractPosition;
			bool	fIsRegulatoryReporting;

			friend struct SSAllotmentList;
		};

		/** List of all allotments.
		Build a list of all allotments.
		@version 4.2.1.1 is now a vector
		@since 4.1.1
		*/
		SPH_BEGIN_NOWARN_EXPORT
		struct SOPHIS_BO_KERNEL SSAllotmentList : public _STL::vector<SSAllotment>
		{
			SSAllotmentList();


			/** Create a universal menu (internal usage).
			@return a CSUMenu which must be disposed using DisposeMenu.
			@since 4.4.1.2
			*/
			CSUMenu * CreateMenu();

			/** Find the position in the array fAllotmentArray.
			@return id is the allotment ID to find.
			@return the position; -1 if not found.
			*/
			int	find(long id) const;
			/** Get allotment id from the menu ident
			@param id is the menu ident
			@return the corresponding allotment id;
			*/
			int GetAllotmentIdFromMenuIdent(long id) const;

		};
		SPH_END_NOWARN_EXPORT
	}
}

SPH_EPILOG


#endif


