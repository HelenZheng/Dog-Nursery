/*
 	File:		SphAllotmentCondition.h

 	Contains:	Base class for Allotment conditions.

 	Copyright:	� 2001-2006 Sophis.
*/

/*! \file SphAllotmentCondition.h
	\brief Base class for Allotment conditions.
*/

#pragma once

#ifndef _SPHALLOTMENTCONDITION_H_
#define _SPHALLOTMENTCONDITION_H_
#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

/** Macro defines Clone function for instantiating of derivedClass posting.
	@param derivedClass is the type of posting derived from CSRAllotmentCondition.
*/
#define DECLARATION_ALLOTMENT_CONDTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRAllotmentCondition)

/** macro used for installing the posting in Risk
	@param derivedClass is the type of posting derived from CSRAllotmentCondition
	@param name is the name of this posting which will be used to store it in 
	database and for building menu of all postings. The name must not exceed the length
	defined in SphInc/backoffice_otc/SphBOEnums.h {@link eBO_LENGHT::ALLOTMENT_CONDITION_LENGTH}
*/
#define	INITIALISE_ALLOTMENT_CONDTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace instrument {
		class CSRInstrument;
	}

	namespace backoffice_kernel
	{

		/** Interface to create an allotment condition in allotment criterias.
		You can implement this interface to add an allotment condition on the list.
		The method is_matched is called to determine an allotment for an instrument.
		@version 5.3
		*/
		class SOPHIS_BO_KERNEL CSRAllotmentCondition
		{
		public:


			/** Trivial destructor.
			*/
			virtual ~CSRAllotmentCondition() {}

			/** Filter to decide if instrument matches conditions for this allotment.
			@param instrument is the instrument to check. {@link sophis::instrument::CSRInstrument}.
			@returns true if is met, otherwise - false.
			@version 5.3
			*/
			virtual bool is_matched(const instrument::CSRInstrument &instrument) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_ALLOTMENT_CONDTION.
			@see tools::CSRPrototype
			@version 5.3
			*/
			virtual CSRAllotmentCondition* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRAllotmentCondition
				,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_ALLOTMENT_CONDTION.
			@see tools::CSRPrototype
			@version 5.3
			*/
			static prototype& GetPrototype();
		} ;
	}
}
SPH_EPILOG
#endif // _SPH_POSTINGDATESETTLEMENT_H_

