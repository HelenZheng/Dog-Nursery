#pragma once

#include "SphKernelEvent.h"
#include "SphInc/portfolio/SphTransaction.h"
#include "SphInc/backoffice_otc/SphBOEnums.h"
#include "SphKernelCondition.h"

namespace sophis
{
	namespace backoffice_kernel
	{
		struct SOPHIS_BO_KERNEL KernEvent
		{
			long	id;
			char	name[KERNEL_STATUS_LENGTH+AUDIT_DATE_TIME];
			long	type;
			eBOEventTier    tier_ev;
			eBOEventSTP		stp;
			char	comments[COMMENTS_LENGTH];

			KernEvent();
			KernEvent(long i, char *n, long ty, eBOEventTier ti, eBOEventSTP stp, char *c);
			KernEvent( const KernEvent& e);
			~KernEvent(){};
		};

		struct SOPHIS_FIT KernWFRule
		{
			long eventID;
			long initialStatus;
			long finalStatus;
			long asyncStatus;
			long asyncErrStatus;

			long actionToDo;
			char rightToHave1[USERRIGHT_LENGTH];
			char rightToHave2[USERRIGHT_LENGTH];
			char fieldsModifiable1[FIELDMODIF_LENGTH];
			char fieldsModifiable2[FIELDMODIF_LENGTH];
			char condition1[CONDITION_LENGTH];
			char condition2[CONDITION_LENGTH];
			char condition3[CONDITION_LENGTH];
			char comments[COMMENTS_LENGTH];
			char checkDeal[CHECK_DEAL_LENGTH];	//(vvf, 14/11/03) --check deal
			short stop;

			KernWFRule();
			KernWFRule(long e, long i, long f, long a, char *r1, char *r2
				,char *f1, char *f2, char *c1, char *c2, char *c3, char *cmt
				,char *checkDeal, short stop, long asyncStatus, long asyncErrStatus);
			KernWFRule( const KernWFRule &r);

			bool operator==(const KernWFRule &rule) const;
		};

		struct SOPHIS_FIT KernWFRuleID: public KernWFRule
		{
			long ruleID;

			KernWFRuleID();
			KernWFRuleID( long rid, KernWFRule& r);
			KernWFRuleID( const KernWFRuleID &ri);

			bool IsConditionMet(const ISKernCondArg& oi, const SSKernelInstrumentSelector &sel);	
		};

		class SOPHIS_BO_KERNEL CSRBOKernelEnvironmentWrapper
		{
		public:
			bool    GetKernEvent( long id, KernEvent& e);

			/** Find the rule for a transaction.
			@param t is the final (resp. initial) for a deal created or modified (resp. canceled).
			@param isid is the initial status of the deal.
			@param eid is the event id to apply to the tranaction
			@param r is the output for the data of the rule.
			@return true if rule found.
			*/
			virtual bool    FindRuleByInitialStatusAndEvent(const portfolio::CSRTransaction& t								
								,long isid 
                                ,long eid 
                                ,KernWFRuleID& r);

			/** Determine if a transition can be automatically applied to a transaction
			@param t is the final (resp. initial) for a deal created or modified (resp.canceled).
			@param rule_id is the output for the rule id that is to be applied to the transaction
			*/
			virtual bool CanPerformSTPTransition(const sophis::portfolio::CSRTransaction &trans, KernWFRuleID &r);

			virtual long GetKernTicketEvent(long businessEvent, bool creation);

			virtual bool IsBEInGroup(long beID, long groupID);

			virtual bool IsAllotInGroup(long allotmentID, long groupID);

			virtual _STL::string GetAllotmentName(long allotmentID);

			virtual _STL::string GetBEName(long beID);
		};
	}
}