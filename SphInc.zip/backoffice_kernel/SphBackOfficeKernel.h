#pragma once
#ifndef _SphBackOfficeKernel_H_
#define _SphBackOfficeKernel_H_

#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_otc/SphBOEnums.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel {

class ISROtcInput;
struct SSKernelInstrumentSelector;

/// Internal
struct KernWFRule;
struct KernWFRuleID;
struct KernWFDefContent;
struct KernEvent;

/**
 * Interface for performing basic back office static data lookup and actions.
 * @version 6.3
 */
class ISRBOKernelEnvironment
{
public:
	/** Trivial Constructor. */
	ISRBOKernelEnvironment() {}
	/** Trivial Destructor. */
	virtual ~ISRBOKernelEnvironment() {}

	/** Back Office Kernel Group information. */
	struct KernGroups
	{
		char	name[GROUP_NAME_LENGTH+AUDIT_DATE_TIME];
		char	comments[COMMENTS_LENGTH];
	};

	typedef KernGroups	KernStatGroups;
	typedef KernGroups	KernAllotGroups;
	typedef KernGroups	KernBEGroups;
	typedef KernGroups  KernNettGroups;

	/** Back Office Kernel Group id and information. */
	struct KernGroupsID : public KernGroups
	{
		long	id;
	};

	typedef KernGroupsID	KernStatGroupsID;
	typedef KernGroupsID	KernAllotGroupsID;
	typedef KernGroupsID	KernBEGroupsID;
	typedef KernGroupsID	KernNettGroupsID;

	/** Vector of ids. */
	typedef _STL::vector<long> VContent;
	typedef VContent::iterator IVContent;

	/** Back Office Kernel Group contents. */
	struct KernGroupContent
	{
		char	     name[GROUP_NAME_LENGTH+AUDIT_DATE_TIME];
		char	     comments[COMMENTS_LENGTH];
		VContent     contentID;
	};

	typedef KernGroupContent	KernStatGroupContent;
	typedef KernGroupContent	KernAllotGroupContent;
	typedef KernGroupContent	KernBEGroupContent;
	typedef KernGroupContent	KernNetttGroupContent;

	typedef _STL::map<long, KernGroupContent> KGroups;

	typedef KGroups KStatGroups;
	typedef KStatGroups::iterator IKStatGroups;
	typedef KGroups KAllotGroups;
	typedef KAllotGroups::iterator IKAllotGroups;
	typedef KGroups KBEGroups;
	typedef KBEGroups::iterator IKBEGroups;
	typedef KGroups KNettGroups;
	typedef KNettGroups::iterator IKNettGroups;

	/** Exception handling helper. */
	virtual _STL::string GenerateExceptionString(const char* message, const portfolio::CSRTransaction &transaction,
		long isid, long id, bool isEventID = true) { return _STL::string(""); }

	/** Checks if given kernel status is a valid one. */
	virtual bool IsStatusAvailable(long statusID) { return false; }
	/** Returns kernel status name given internal code. */
	virtual char* GetKernStatName(long statusID) { return 0; }
	/** Returns the kernel event internal code given a name. */
	virtual long GetKernEventIdByName(_STL::string eventName) { return 0; }
	/** Returns the kernel event name given internal code. */
	virtual char* GetKernEventName(long eventID) { return 0; }
	/** Returns allotment name given internal code. */
	virtual char* GetKernAllotName(long allotmentID) { return 0; }
	/** Returns business event name given internal code. */
	virtual char* GetKernBEName(long beID) { return 0; }
	/** Returns all kernel status groups. */
	virtual KStatGroups	GetAllKernStatGroups() { return KStatGroups(); }
	/** Populates kernel status group contents for given group code. */
	virtual bool GetKernStatGroup( long gid, KernStatGroupContent& gc) { return false;}
	/** Returns kernel status group name given internal code. */
	virtual char* GetKernStatGroupName(long gid) { return 0; }
	/** Returns all allotment groups. */
	virtual KAllotGroups GetAllKernAllotmentGroups() { return KAllotGroups(); }
	/** Populates allotment group contents for given group code. */
	virtual bool GetKernAllotmentGroup(long gid, KernAllotGroupContent& gc) { return false; }
	/** Returns allotment group name given internal code. */
	virtual char* GetKernAllotmentGroupName(long gid) { return 0; }
	/** Populates list of allotment groups for given allotment code. */
	virtual void GetAllKernAllotmentGroupsWithAllotment(long allotmentID, VContent &groups) {}
	/** Returns all business event groups. */
	virtual KBEGroups GetAllKernBusinessEventsGroups() { return KBEGroups(); }
	/** Populates business event group contents for given group code. */
	virtual bool GetKernBusinessEventsGroup(long gid, KernBEGroupContent& gc) { return false; }
	/** Returns business event group name given internal code. */
	virtual char* GetKernBusinessEventsGroupName(long gid) { return 0; }
	/** Checks if given kernel status belongs to the given group. */
	virtual bool IsStatusInGroup(long statusID, long groupID) { return false; }
	/** Checks if given allotment belongs to the given group. */
	virtual bool IsAllotmentInGroup(long allotmentID, long groupID) { return false; }
	/** Checks if given business event belongs to the given group. */
	virtual bool IsBusinessEventInGroup(long beID, long groupID) { return false; }
	/** */
	virtual _STL::string GetSQLBOFilter(long groupID) { return _STL::string(""); }
	/** */
	virtual long	GetAccountBookFromFolio(long folioID) { return 0; }
	/** */
	virtual bool	GetAccountBookName(long bookID, _STL::string &name) { return false; }

#ifndef GCC_XML
	/// INTERNAL.
	virtual bool FindRuleByTransaction(const portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByTransactionAndEvent(const portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		long event_id, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByOtcInputAndEvent(const ISROtcInput& oi, const SSKernelInstrumentSelector& sel,
		long event_id, KernWFRuleID &r) { return false; }
	/// INTERNAL.
	virtual bool CanPerformSTPTransition(const portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		KernWFRuleID &r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByInitialStatusAndEvent(const portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		long isid, long eid, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByInitialStatusAndEvent(const ISROtcInput& oi, const SSKernelInstrumentSelector& sel,
		long isid, long eid, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByInitialAndFinalStatus(const portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		long isid, long fsid, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByInitialAndFinalStatus(const ISROtcInput& oi, const SSKernelInstrumentSelector& sel,
		long isid, long fsid, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool FindRuleByWorkflowIDAndEvent(long workflowID, long isid, long eid, KernWFRuleID& r) { return false; }
	/// INTERNAL.
	virtual bool GetWorkflowData(long wfid, KernWFDefContent& dc) { return false; }
	/// INTERNAL.
	virtual bool FindWorkflowByTransaction(const sophis::portfolio::CSRTransaction& t, const SSKernelInstrumentSelector& sel,
		KernWFDefContent& dc) { return false; }
	/// INTERNAL.
	virtual bool FindWorkflowByOtcInput(const ISROtcInput& oi, const SSKernelInstrumentSelector& sel,
		KernWFDefContent& dc) { return false; }
	/// INTERNAL.
	virtual bool GetKernEvent(long id, KernEvent& e) { return false; }
	/// INTERNAL.
	long GetWorkflowRule(long id, KernWFRule &workflow) { return 0; }

#endif // GCC_XML
};

/**
 * Global handler (implementation, singleton) of back office static data lookup and actions.
 * @version 6.3
 */
extern SOPHIS_FIT ISRBOKernelEnvironment *gBOKernelEnvironment;

	} // namespace backoffice_kernel
} // namespace sophis

SPH_EPILOG

#endif // _SphBackOfficeKernel_H_
