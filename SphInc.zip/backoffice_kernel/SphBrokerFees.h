/*
 	File:		SphBrokerFees.h
 
 	Contains:	Base class to derive from it new broker fees calculator.
 
 	Copyright:	� 2001-2005 Sophis.
*/

#pragma once

#ifndef _SphBrokerFees_H_
#define _SphBrokerFees_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"


/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_BROKER_FEES(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRBrokerFees)
#define CONSTRUCTOR_BROKER_FEES(derivedClass)
#define WITHOUT_BROKER_FEES(derivedClass)
/** macro used for installing the broker fees in Risk
@param derivedClass is the type of posting derived from CSRBrokerFees
@param name is the name of this right which will be used to store it in 
database and for building menu of all broker fees installed
*/
#define	INITIALISE_BROKER_FEES(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

/*  =============================================================================
 *  For Broker Fees Conditions
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_BROKERFEES_RULES_CONDITION_TRANSACTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRBrokerFeesConditionTransaction)
#define CONSTRUCTOR_BROKERFEES_RULES_CONDITION_TRANSACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_BROKERFEES_RULES_CONDITION_TRANSACTION(derivedClass)
/*  For Broker Fees Conditions
 *	Macro to be placed in the clients <main>.cpp to register derived client classes
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Kernel Workflow Definition window.
 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
 */
#define	INITIALISE_BROKERFEES_RULES_CONDITION_TRANSACTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

/*  =============================================================================
 *  For Market Fees Conditions
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_MARKETFEES_RULES_CONDITION_TRANSACTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRMarketFeesConditionTransaction)
#define CONSTRUCTOR_MARKETFEES_RULES_CONDITION_TRANSACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_MARKETFEES_RULES_CONDITION_TRANSACTION(derivedClass)
/*  For Market Fees Conditions
 *	Macro to be placed in the clients <main>.cpp to register derived client classes
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Kernel Workflow Definition window.
 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
 */
#define	INITIALISE_MARKETFEES_RULES_CONDITION_TRANSACTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)



SPH_PROLOG
namespace sophis
{
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel
	{


	struct SSBrokerFeesData
	{
		/** 
			it is a string representation of broker fees value that will be used 
			as initial coefficient to calculate broker fees
		*/
		_STL::string str_value; 
		/**
			deal quantity
		*/
		double quantity; 
		/**
			security price
		*/
		double price;
		/**
			deal gross amount
		*/
		double gross_amount;
		/**
			deal basic amount
		*/
		double basic_amount;
		/**
			security last price
		*/
		double last;
		/**
			security spot price
		*/
		double spot;
		/**
			security quotity
		*/
		double quotity;

		SSBrokerFeesData();
		SSBrokerFeesData( _STL::string i_str_value, double i_quantity, double i_price,
						double i_gross_amount, double i_basic_amount, double i_last,
						double i_spot, double i_quotity);
		SSBrokerFeesData(const SSBrokerFeesData & bfData);
		~SSBrokerFeesData(){}
	};

	/** Interface to define broker fees calculator.
		This is used to calculate broker fees for new deal.
        Deriving from this broker fees interface we create Prototypes of broker fees calculators,
		that will be used for example in deal input dialog
		@since 5.1.0
	*/
	class SOPHIS_BO_KERNEL CSRBrokerFees
	{
	public:

	/** method to calculate broker fees
		@param bfData - object containing all nessessary info to calculate Broker Fees
		@returns calculated broker fees
	*/
		virtual double get_broker_fees(const SSBrokerFeesData& bfData) const = 0;

	/** Clone method needed by the prototype.
		Usually, it is done automatically by the macro DECLARATION_KERNEL_RIGHTS.
		@see tools::CSRPrototype
	*/
		virtual CSRBrokerFees* Clone() const = 0;

	/** Typedef for the prototype (the key is a string).
	*/
	typedef sophis::tools::CSRPrototype<CSRBrokerFees
		,const char*, sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
		To add an new broker fees calculator to this singleton, use INITIALISE_BROKER_FEES.
		@see tools::CSRPrototype
	*/
		static prototype& GetPrototype();
	};
	//==========================================================================
	//		Interface to create a condition for Broker Fees
	class SOPHIS_BO_KERNEL CSRBrokerFeesConditionTransaction
	{
	public:
		/** Test if Broker Fees has to be applied.
		*/
		virtual bool get_condition( const portfolio::CSRTransaction& trade ) const = 0;

		/** Get the singleton for one condition.
		This is equivalent to CSRBrokerFeesConditionTransaction::GetPrototype().GetData(modelName).
		except that exception is catched to return 0 if the amount name is not found.
		@param modelName is a C string for the condition.
		@return a pointer which must not be deleted but can be null.
		*/
		static CSRBrokerFeesConditionTransaction* getInstance( const char* modelName );

		/** Clone method needed by the prototype.
		Usually, it is done automatically by the macro DECLARATION_BROKERFEES_RULES_CONDITION_TRANSACTION.
		@see tools::CSRPrototype
		*/
		virtual CSRBrokerFeesConditionTransaction* Clone() const = 0;


		/** Typedef for the prototype (the key is a string).
		*/
		typedef sophis::tools::CSRPrototype<CSRBrokerFeesConditionTransaction
			,const char*
			,sophis::tools::less_char_star> prototype;

		/** Access to the prototype singleton.
		To add an amount to this singleton, use INITIALISE_BROKERFEES_RULES_CONDITION_TRANSACTION.
		@see tools::CSRPrototype
		*/
		static prototype& GetPrototype();
	} ;

	//==========================================================================
	//		Interface to create a condition for Market Fees
	class SOPHIS_BO_KERNEL CSRMarketFeesConditionTransaction
	{
	public:
		/** Test if Market Fees has to be applied.
		*/
		virtual bool get_condition( const portfolio::CSRTransaction& trade ) const = 0;

		/** Get the singleton for one condition.
		This is equivalent to CSRMarketFeesConditionTransaction::GetPrototype().GetData(modelName).
		except that exception is catched to return 0 if the amount name is not found.
		@param modelName is a C string for the condition.
		@return a pointer which must not be deleted but can be null.
		*/
		static CSRMarketFeesConditionTransaction* getInstance( const char* modelName );

		/** Clone method needed by the prototype.
		Usually, it is done automatically by the macro DECLARATION_MARKETFEES_RULES_CONDITION_TRANSACTION.
		@see tools::CSRPrototype
		*/
		virtual CSRMarketFeesConditionTransaction* Clone() const = 0;


		/** Typedef for the prototype (the key is a string).
		*/
		typedef sophis::tools::CSRPrototype<CSRMarketFeesConditionTransaction
			,const char*
			,sophis::tools::less_char_star> prototype;

		/** Access to the prototype singleton.
		To add an amount to this singleton, use INITIALISE_MARKETFEES_RULES_CONDITION_TRANSACTION.
		@see tools::CSRPrototype
		*/
		static prototype& GetPrototype();
	} ;



}
}
SPH_EPILOG
#endif // _SphBrokerFees_H_

