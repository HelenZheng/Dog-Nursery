#ifndef _SphBusinessEvent_H_
#define _SphBusinessEvent_H_

/*
 	File:		SphBusinessEvent.h

 	Contains:	Class for the handling of business events.

 	Copyright:	� 1995-2000 Sophis.

*/

/*! \file SphBusinessEvent.h
	\brief Handling business events.
*/

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphTransactionEnums.h"

#include "SphInc/misc/SphEvents.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

# ifndef GCC_XML
BOOST_INCLUDE_BEGIN
# include BOOST_INCLUDE_PATH(unordered_map.hpp)
BOOST_INCLUDE_END
# endif GCC_XML

SPH_PROLOG

namespace sophis
{
	namespace event
	{
		class ISEvent;
	}
}

namespace sophis	{
	namespace backoffice_kernel	{

		/** Describes the business event property.
		To function correctly, this class needs the Back Office kerner module.
		The data is read in the table BUSINESS_EVENTS.
		@see eTransactionType
		@since 4.1.0
		*/
		class SOPHIS_FIT CSRBusinessEvent {
		public:

			/** Describes how the reporting takes a deal with that business event into account.
			See Back Office User Guide for more explanation about each type.
			*/
			enum typeMethodEvent
			{
				meUndefined = 0,
				meNone,
				meAveragePrice,
				meIncome,
				meTaxCredit,
				meTreasury,	// 5
				meFinancing,
				meCommission,
				meMarginCall,
				meRealized,
				meCouponToReceive,	// 10
				meInBalance,
				meOnlyInBalance,
				mePureIncome
			};

			/** Describes the calculation of the fees in a transaction, with that business event.
			*/
			enum typeMethodFees
			{
				mfNone = 0,
				mfBroker,
				mfMarket,
				mfAll,
				mfCounterparty
			};

# ifndef GCC_XML
			/** Default constructors for containers */
			CSRBusinessEvent();
			CSRBusinessEvent(const CSRBusinessEvent&);           
			~CSRBusinessEvent();
# endif GCC_XML

			/** Specify if a method has to be included in the <B>Balance</B> column in the reporting.
			@param method is actually a typeMethodEvent.
			@return true if the method type is real cash.
			*/
			static bool InBalance(short method);

			/** Gives the total number of business events.
			*/
			static int GetNbBusinessEvents();

			/** Factory method to get the business event by index.
			@param i is the index from 0 until GetNbBusinessEvents()-1.
			@return a business event class.
			Note that you must not delete this object.
			*/
			static const CSRBusinessEvent* GetBusinessEventByIndex(int i);

			/** Factory method to get the business event by ID.
			@param ID is a transaction type.
			@return a business event class; The return must not be deleted;If it cannot find it, it returns 0.
			Note that you must not delete this object.
			*/
			static const CSRBusinessEvent* GetBusinessEventById(sophis::portfolio::eTransactionType id);
			static const CSRBusinessEvent* GetBusinessEventById(long id);

			/** Factory method to get the business event by its name.
			@param eventName is the name of the business event.
			@return a business event class; The return must not be deleted;If it cannot find it, it returns 0.
			Note that you must not delete this object.
			@version 5.2.2
			*/
			static const CSRBusinessEvent* GetBusinessEventByName(const char* eventName);

			/** Get the position of the index in the list fList.
			@param eventName is the name of the business event.
			@return a business event internal code. If it cannot be found, it returns the value 0.
			@version 5.2.2
			*/
			static sophis::portfolio::eTransactionType GetIdByName(const char* eventName);

			/** Get the position of the index in the list fList.
			@param id is a transaction type.
			@return a business event class. The return must not be deleted. If it cannot be found, it returns the value 0.
			*/
			static short GetIndexById(sophis::portfolio::eTransactionType id);
			static short GetIndexById(int id);

			/** Access to the ID (the transaction type) of the business event.
			@return its position. If it cannot be found, it returns 0.
			*/
			sophis::portfolio::eTransactionType GetIdent() const;

			/** Access to the name of the business event.
			The name is in French or English, according to the user preference.
			*/
			const char* GetName() const;

			/** Specify if reporting must update the number of securities.
			@return true for instance for business event like tPuchaseSale, tSplit or false.
			for instance tCoupon.
			*/
			bool ModifyNumberOfSecurities() const;

			/** Specify if reporting must update the Income column.
			*/
			bool IsInIncome() const;

			/** Specify if reporting must update the Tax Credit column.
			*/
			bool IsTaxCredit() const;

			/** Specify if reporting must update the Commission column.
			*/
			bool IsCommission() const;

			/** Specify if BE is aggregatable to use it for portfolio column .
			*/
			bool IsAggregatable() const;

			/** Specify if BE is dedicated for provision.
			*/
			bool IsProvision() const;


			/** Access to the method type.
			*/
			typeMethodEvent GetMethod() const;

			/** Specify if reporting must update the Balance column.
			*/
			bool	InBalance() const;


			/** Specify if the transaction has a second counterpart.
			For instance, this is the case in assignments.
			*/
			bool GetSecondThirdParty() const;

			/** Specify if a transaction has to calculate the market or broker fees, by default.
			*/
			typeMethodFees GetFeesMethod() const;


			/** Internal constant used in Sophis code.
			*/
			enum	eInternal{
				BE_USER		=	100 , // id >= 100 : user business event
				ALL_BE		=	-1
			};

			/** Load or reload the Business Event table.
			Normally used internally, but if you modify the business event
			you must call that method to update the cache.
			*/
			static void Load();

			/** Return a string "Type not in (...) " for all business events that do not modify the number of securities.
			Useful for SQL queries where you want to filter on transactions that modify the number of securities.
			For instance, "select sum(Quantite) from histomvts "
				"where " << CSRBusinessEvent::GetListModifyingNumberOfSecurities()"
				" group by mvtident"
			will give you the position.
			@return an internal static pointer. So you must not delete it.
			*/
			static const char *GetListModifyingNumberOfSecurities();


			/** Return a string "not exists (select 1 from ... where .. = type_field)". 
				The goal is the same as the previous query but it is often more efficient to use this one.
				@param type_field is the fully qualified name of the field in the table you want to check this list against.
				@return a dynamically created string. No deletion required.
			 */
			static _STL::string 
				GetListModifyingNumberOfSecurities(_STL::string type_field);
			

			/** Return a string "Type not in (...) " for all business events that is of type margin call.
			Useful for SQL queries where you want to filter on transactions with a filter on margin call..
			For instance, "select sum(Quantite) from histomvts "
				"where " << CSRBusinessEvent::GetListModifyingNumberOfSecurities()"
				" group by mvtident"
			will give you the position.
			@return an internal static pointer. So you must not delete it.
			@since 5.1.3.3
			*/
			static const char *GetListMarginCall();

			/** Return a string to filter according to the back_office preference of the user.
			For the status of the deal. @see eBackOfficeType
			@return an internal static pointer. So you must not delete it.
			*/
			static const char *GetBOFilter();

			/** Specify if reporting must take into account this deal according to the status.
			@param ID is actually a eBackOfficeType.
			@see eBackOfficeType
			*/
			static bool BOTakeIntoAccount(sophis::portfolio::eTransactionType id);
			static bool BOTakeIntoAccount(int id);



			/** Specify if reporting must update the number of securities.
			@id is actually a business event type, eTransactionType.
			@return true, for business events like tPuchaseSale, tSplit or false
			for events like tCoupon.
			*/
			static bool ModifyNumberOfSecurities(sophis::portfolio::eTransactionType id);
			static bool ModifyNumberOfSecurities(int id);


			/** Specify if reporting must update the commission column.
			@id is actually a business event type, eTransactionType.
			@return true, for business events like tCommission.
			@since 5.1
			@see IsCommission()
			*/
			static bool IsACommission(sophis::portfolio::eTransactionType id);
			static bool IsACommission(int id);


			/** Specify if reporting must update the deposit column.
			@id is actually a business event type, eTransactionType.
			@return true, for business events like tMarginCall.
			@since 5.1
			*/
			static bool IsAMarginCall(sophis::portfolio::eTransactionType id);
			static bool IsAMarginCall(int id);

			/** Specify if given business event is aggregatable
			 @param id	- id of event to check
			 @return	- true if given BE is aggregatable,
						  false otherwise
			 @since 5.2
			 */
			static bool IsAnAggregatableBE(sophis::portfolio::eTransactionType id);
			static bool IsAnAggregatableBE(int id);


			static bool IsAProvisionBE(sophis::portfolio::eTransactionType id);
			static bool IsAProvisionBE(int id);

			/** Returns the name of the column in the table BUSINESS_EVENTS according to the user preference language.
			*/
			static const char* GetNameCol();

			/** Clearing fBusinessEvents, fTypeMap, fNameMap and reloads the BusinessEvent table from database
			*/
            static void ReloadBECache(const sophis::event::ISEvent & event);


		private:

			typedef sophis::portfolio::eTransactionType eTransactionType;

			eTransactionType fIdent;
			char fName[256];
			short fCompta;
			short fMethod;
			short fSecondThirdParty;
			short fFees;
			bool  fAggregatable;
			short fProvisionType;

# ifndef GCC_XML
			typedef _STL::vector<CSRBusinessEvent> EventVector;
			typedef boost::unordered_map<eTransactionType, EventVector::iterator> TypeMap;
			typedef boost::unordered_map<_STL::string, EventVector::iterator> NameMap;

			static int fCount;
			static EventVector fBusinessEvents;
			static TypeMap fTypeMap;
			static NameMap fNameMap;
# endif GCC_XML
		};
	}
}
SPH_EPILOG


#endif


