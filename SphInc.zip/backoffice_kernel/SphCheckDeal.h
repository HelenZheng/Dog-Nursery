/*
 	File:	SphCheckDeal.h

 	Contains:	Abstract base class which can be used to extend popup menu of Check Deal column of 
				Workflow Definition window to add client specific funcionality.

 	Copyright:	� 1995-2006 Sophis.

*/

/*! \file SphCheckDeal.h
	\brief Abstract base class which can be used to extend popup menu of Check Deal column of 
		   Workflow Definition window to add client specific funcionality.
*/

#ifndef _SPH_CHECK_DEAL_H_
#define _SPH_CHECK_DEAL_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphValidation.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_CHECK_DEAL(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRCheckDeal)
#define CONSTRUCTOR_CHECK_DEAL(derivedClass)
#define WITHOUT_CONSTRUCTOR_CHECK_DEAL(derivedClass)
#define	INITIALISE_CHECK_DEAL(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace tools	{
		struct VoteException;
	}
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace backoffice_kernel
	{

		/** Class to check if a deal can be transferred from one status to another one.
		With the back office kernel module, for each event in the workflow definition a checked deal condition
		may be added. This checked deal condition is a derived class from CSRCheckDeal and it is executed in
		an internal Transaction Action.
		@since 4.5.2
		@see CSRTransactionAction
		*/
		class SOPHIS_BO_KERNEL CSRCheckDeal
		{
		public:
							
			/** Trivial destructor.
			*/
			virtual ~CSRCheckDeal() {}
				
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRCheckDeal, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_CHECKED_DEAL.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CHECKED_DEAL.
			@see tools::CSRPrototype
			*/
			virtual CSRCheckDeal* Clone() const = 0;
			
			/** Ask for a creation of a transaction.
			When creating, once the the workflow selector and the event have been found,
			and if a checked deal condition has been added, this method is executed.
			@param transaction is the transaction to create. It is a non-const object so you can
			modify it.
			@param event_id is the kent event used for creation.
			@throws VoteException if you reject that creation.
			For compatibility, call by defaut the deprecated method with one less parameter.
			@version 5.3 add the parameter event_id.
			*/
			virtual void VoteForCreation(portfolio::CSRTransaction& transaction,
									long event_id) const
				throw (tools::VoteException);

			/** Ask for a modification of a transaction.
			When modifying, once the the workflow selector and the event have been found,
			and if a checked deal condition has been added, this method is executed.
			@param original is the original transaction before any modification.
			@param transaction is the modified transaction. It is a non-const object so you can
			modify it.
			@param event_id is the kent event used for modification.
			@throws VoteException if you reject that modification.
			For compatibility, call by defaut the deprecated method with one less parameter.
			@version 5.3 add the parameter event_id.
			*/
			virtual void VoteForModification(const portfolio::CSRTransaction& original, 
											 portfolio::CSRTransaction& transaction,
											 long event_id) const
											 throw (tools::VoteException);

			/** Ask for a deletion of a transaction.
			When deleting, once the the workflow selector and the event have been found,
			and if a checked deal condition has been added, this method is executed.
			@param transaction is the original transaction before any modification.
			@param event_id is the kent event used for deletion.
			@throws VoteException if you reject that deletion.
			For compatibility, call by defaut the deprecated method with one less parameter.
			@version 5.3 add the parameter event_id.
			*/
			virtual void VoteForDeletion(const portfolio::CSRTransaction& transaction,
										long event_id) const
				throw (tools::VoteException);

		private:
			/**
			@deprecated 5.3 use the one with one more parameter. 
			*/
			virtual void VoteForCreation(portfolio::CSRTransaction& transaction) const
				throw (tools::VoteException)  {}

			/**
			@deprecated 5.3 use the one with one more parameter. 
			*/
			virtual void VoteForModification(const portfolio::CSRTransaction& original, 
											 portfolio::CSRTransaction& transaction) const
											 throw (tools::VoteException)  {}

			/**
			@deprecated 5.3 use the one with one more parameter. 
			*/
			virtual void VoteForDeletion(const portfolio::CSRTransaction& transaction) const
				throw (tools::VoteException) {}
		};

	} 
} 
SPH_EPILOG
#endif //_SPH_CHECK_DEAL_H_