/*
 	File:	SphCheckDealType.h

 	Contains:	Abstract base class which can be used to extend popup menu's of Trade Checking Rules 
	window to add client specific funcionality.
*/


#ifndef _SPH_CHECK_DEAL_TYPE_H_
#define _SPH_CHECK_DEAL_TYPE_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphValidation.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_CHECK_DEAL_TYPE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRCheckDealType)
#define CONSTRUCTOR_CHECK_DEAL_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_CHECK_DEAL_TYPE(derivedClass)
#define	INITIALISE_CHECK_DEAL_TYPE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

#define DECLARATION_CHECK_DEAL_OPERATOR(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRCheckDealOperator)
#define CONSTRUCTOR_CHECK_DEAL_OPERATOR(derivedClass)
#define WITHOUT_CONSTRUCTOR_CHECK_DEAL_OPERATOR(derivedClass)
#define	INITIALISE_CHECK_DEAL_OPERATOR(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace tools	{
		struct VoteException;
	}
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace backoffice_kernel
	{
		/** Enum is used for supported field types (see CSRCheckDealType::GetType)
		@since 7.1.2
		*/
		enum eCheckDealFieldType
		{
			eString,
			eInt,
			eLong,
			eDouble,
			eDateTime,
			eNullable,
			eStringMenu,
			eIdStringMenu,
			eRelative
		};

		/** Class for creating a pair of ID and String's for return menu's
		This class is used below in CSRCheckDealType::GetIdStringMenu in the return type
		@since 7.1.2
		*/
		class SOPHIS_BO_KERNEL CSRIdStringPair
		{
		public:
			long ID;
			_STL::string String;

			CSRIdStringPair(long id, _STL::string s);
		};

		/** Class to check if a deal's field matches a certain value.
		With the back office kernel module, for each event in the workflow definition a checked deal condition
		may be added. This checked deal condition is a derived class from CSRCheckDeal and it is executed in
		an internal Transaction Action. This class is used to make up rules for dynamically created Check Deal conditions
		@since 7.1.2
		@see CSRCheckDeal
		*/
		class SOPHIS_BO_KERNEL CSRCheckDealType
		{
		public:
							
			/** Trivial destructor.
			*/
			virtual ~CSRCheckDealType() {}
				
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRCheckDealType, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_CHECKED_DEAL.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CHECKED_DEAL_TYPE.
			@see tools::CSRPrototype
			*/
			virtual CSRCheckDealType* Clone() const = 0;
			
			/**
			Determines which field type the class belongs to.
			Defaults are: Transaction, Instrument, Depositary, Counterparty, Entity, Broker.
			The value here will be used to populate the Field Type menu
			@returns a string naming the field type
			@version 7.1.2
			*/
			virtual _STL::string GetFieldType();

			/** 
			Determines the name of the field. The value will be used to populate the Field Name menu
			@returns string naming the field
			@version 7.1.2
			*/
			virtual _STL::string GetFieldName(); 

			/**
			Determines the type of the field. 
			This value will determine what value types can be entered for this type, and how the values are compared
			@return the type of field
			@version 7.1.2
			*/
			virtual eCheckDealFieldType GetFieldDataType();

			/**
			Gets the value of the field to compare.
			When checking the check deal rule, the transaction being checked is passed here.
			The return value will be cast to the appropriate type (see GetFieldType) and compared to what has been 
			entered in the Value field of the rule
			@param transaction is the deal being checked
			@return the string value to compare
			@version 7.1.2
			*/
			virtual _STL::string GetFieldValue(const sophis::portfolio::CSRTransaction &transaction);

			/**
			Gets all the field details (see above methods)
			@param transaction is the deal to be checked (See GetFieldValue)
			@param fieldType will hold the type of the field (See GetFieldType)
			@param fieldName will hold the name of the field (See GetFieldName)
			@param fieldType will hold the type of the field (See GetFieldDataType)
			@param value will hold the to be checked (See GetFieldValue)
			
			@version 7.1.2
			*/
			virtual void GetField(const sophis::portfolio::CSRTransaction &transaction, _STL::string &fieldType, _STL::string &fieldName, eCheckDealFieldType &type, _STL::string &value);

			/**
			Get the string menu items.
			This will be called automatically if the eStringMenu type is returned from GetType
			@param rebuildMenu will tell the check deal type if it should rebuild it's menu. This will allow menu's to be cached inside the class
			@return a list of strings
			@version 7.1.3
			*/
			virtual _STL::vector<_STL::string> GetStringMenu(bool rebuildMenu);

			/**
			Get the id and string menu items.
			This will be called automatically if the eIdStringMenu type is returned from GetType
			@param rebuildMenu will tell the check deal type if it should rebuild it's menu. This will allow menu's to be cached inside the class
			@return a list of unique ID and string values
			@version 7.1.3
			*/
			virtual _STL::vector<CSRIdStringPair> GetIdStringMenu(bool rebuildMenu);

		};

		/** Class to to perform operational validation between the transaction and the check deal type
		@since 7.1.3
		@see CSRCheckDealType
		*/
		class SOPHIS_BO_KERNEL CSRCheckDealOperator
		{
		public:
							
			/** Trivial destructor.
			*/
			virtual ~CSRCheckDealOperator() {}
				
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRCheckDealOperator, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_CHECKED_DEAL_OPERATOR.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CHECKED_DEAL_OPERATOR.
			@see tools::CSRPrototype
			*/
			virtual CSRCheckDealOperator* Clone() const = 0;
			
			/** Determine if this operator is valid for the field type
			Not all operators are valid for all types of eCheckDealFieldType. It is up to each operator to tell 
			the system which types it is valid for
			@param type is the type being checked against
			@return true if the operator is valid, and false if not
			@version 7.1.3
			*/
			virtual bool ValidForFieldType(eCheckDealFieldType type);

			/** Validate the transaction against the check
			The operator is responsible for determining if the Transaction matches the check deal type. This must be done inside this method
			@param transaction is the transaction being checked
			@param check is the check deal to check the transaction against
			@param ruleValue is the value field of the checking rule
			@return true if it is valid, and false if not
			@version 7.1.3
			*/
			virtual bool Validate(const sophis::portfolio::CSRTransaction &transaction, const CSRCheckDealType &check, _STL::string ruleValue );

			/** Checks if this operator needs a value to compare with
			@returns true if a value is needed, and falst if no
			@version 7.1.3
			*/
			virtual bool NeedsValue();
		};
	} 
} 
SPH_EPILOG
#endif //_