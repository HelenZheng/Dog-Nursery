#ifndef _SPH_CLEARINGELIGIBILITY_H_
#define _SPH_CLEARINGELIGIBILITY_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_CONDITION_CLEARING(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRClearingCondition)
#define CONSTRUCTOR_CONDITION_CLEARING(derivedClass)
#define WITHOUT_CONSTRUCTOR_CONDITION_CLEARING(derivedClass)
#define	INITIALISE_CONDITION_CLEARING(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)


namespace sophis {
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace instrument	{
		class CSRInstrument;
	}
	namespace backoffice_kernel
	{
		enum ClearingModel
		{
			cmPrincipal = 1,
			cmAgency
		};

		class SOPHIS_BO_KERNEL CSRClearingEligibility
		{
		public:
			static _STL::vector<long> GetEligibleClearingHouses(const sophis::portfolio::CSRTransaction& transaction, const sophis::instrument::CSRInstrument* instrument);
			static _STL::vector<long> GetEligibleClearingMembers(const sophis::portfolio::CSRTransaction& transaction, const sophis::instrument::CSRInstrument* instrument);
			static _STL::vector<long> GetEligibleClearingModels(const sophis::portfolio::CSRTransaction& transaction, const sophis::instrument::CSRInstrument* instrument);
		};

		class SOPHIS_BO_KERNEL CSRClearingCondition
		{
		public:
							
			/** Trivial destructor.
			*/
			virtual ~CSRClearingCondition() {}
				
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRClearingCondition, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_CONDITION_CLEARING.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CONDITION_CLEARING.
			@see tools::CSRPrototype
			*/
			virtual CSRClearingCondition* Clone() const = 0;

			/** Ask for the eligibility of a transaction.
			@param transaction is the transaction to check.
			*/
			virtual bool IsEligible(const sophis::portfolio::CSRTransaction& transaction, const sophis::instrument::CSRInstrument* instrument) const = 0;
		};
	}
}

#endif // _SPH_CLEARINGELIGIBILITY_H_