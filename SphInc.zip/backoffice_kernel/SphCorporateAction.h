/*
 	File:		SphCorporateAction.h

 	Contains:	Class for handling business event for corporate action.

 	Copyright:	� 2000-2006 Sophis.
*/

/*! \file SphCorporateAction.h
	\brief Handling business events for corporate action.
*/

#ifndef _SphCorporateAction_H_
#define _SphCorporateAction_H_

#include "SphInc/SphMacros.h"
#include "SphInc/market_data/SphCorporateActionHandler.h"

//unix gcc forward declaration of enums are not allowed, if files Sphxxx.h are interdependent il has been necessary to create a file SphxxxEnums.h (obviously enums must be removed from Sphxxx.h)
#if (defined(WIN32)||defined(_WIN64))
namespace sophis {
	namespace portfolio {
		enum eTransactionType;
	}
}
#else
	#include "SphInc/portfolio/SphTransactionEnums.h"
#endif

SPH_PROLOG
namespace sophis	{
	namespace backoffice_kernel	{

		/** Describes the business event chosen for corporate action.
		To work correctly, this class needs the Back Office kerner module.
		The data is read in the table CORPORATE_ACTION_PREF.
		Note the inversion in the fields of this table.
		@since 4.1.1
		*/
		class SOPHIS_BO_KERNEL CSRCADefaultBusinessEvent
		{
		public :
			/** Constructor.
			Reads the table CORPORATE_ACTION_PREF.
			*/
			CSRCADefaultBusinessEvent() ;


			/** Destructor.
			Deallocate the array.
			*/
			~CSRCADefaultBusinessEvent() ;

			/** Enumeration of the item requested in corporate action.
			To see where the enumeration is used, see the Back Office
			User Guide.
			*/
			enum type
			{
				item_stock_loan_dividend_rebate = 1,
				item_stock_loan_comission ,
				item_stock_loan_collateral_remuneration ,
				item_stock_loan_expiry ,
				item_swap_payment_rate_leg ,				//5
				item_swap_payment_equity_leg ,
				item_swap_payment_equity_dividend_rebate_leg ,
				item_swap_expiry ,
				item_cap_floor_payment ,
				item_cap_floor_expiry ,						//10
				item_option_cancelled ,
				item_option_cash_payment ,
				item_option_deal_option,
				item_option_deal_equity ,
				item_option_cash_payment_bis ,				//15
				item_option_market_application ,
				item_future_closing_listed ,
				item_future_closing_otc ,
				item_swap_increasing_nominal ,
				item_crossing ,								//20
				item_equity_collateral ,
				item_stock_loan_lnb_initiation ,
				item_stock_loan_cash_margin_call ,
				item_stock_loan_securities_margin_call ,
				item_stock_loan_partial_return_lnb , 		//25
				item_stock_loan_triparty_transaction ,
				item_stock_loan_principal_stock_modification ,
				item_stock_loan_maturity_modification ,
				item_stock_loan_total_collateral_return , // at the maturity of the repo
				item_stock_loan_partial_collateral_return ,	//30
				item_swap_initialisation,
				item_swap_redemption,
				item_stock_loan_roll_expiry , // used to be roll_closing but has changed
				item_stock_loan_roll_opening ,
				item_stock_loan_sec_vs_cash_contract_cash_margin_call ,
				item_stock_loan_cash_pool_remuneration ,
				item_stock_loan_cash_collateral_return ,
				item_stock_loan_partial_commission_return ,
				item_stock_loan_partial_interest_return ,
				item_stock_loan_repricing_commission_return ,
				item_stock_loan_repricing_interest_return ,
				item_cash_from_abs_repayment ,
				item_package_expiry,
				item_treasury_movement_adjustement,
				item_treasury_movement_retail,
				item_treasury_movement_level,
				item_treasury_movement_account_remuneration,
				item_treasury_movement_account_cost,
				item_swap_basket_adjustment,
				item_swap_spread_fees,
				item_swap_ca_adjustment,
				item_cfd_credit_debit_margin_call,
				item_cfd_transfer_margin_call,
				item_swap_ca_rounding_coupon,
				item_bank_loans_prepayment,
				item_bank_loans_booking_through_facility,
				item_bank_loans_unsettled_accrued,
				item_bank_loans_commitment_fees,
				item_bank_loans_borrowing,
				item_bank_loans_lending,
				item_option_deal_option_short,
				item_stock_loan_initial_margin_modification,
				item_swap_payment_rate_leg_borrowing,
				item_treasury_movement_security,
				item_notional_exchange,
				item_swap_early_termination,
				_NUMBER_OF_TYPE_CORPORATE_ACTION_  =  item_swap_early_termination
			} ;

			/** Get the overloaded business event for the corporate action.
			@param IdCa is the item of the corporate action
			@return the ID of the business event, in the case of overloading. It returns 0
			if it has not been overloaded.
			*/
			long GetValue( type IdCa ) ;

			/** Get the business event for the corporate action.
			@param IdCa is the item of the corporate action.
			@return the ID of the business event. If it has not been overloaded, it uses the
			default values.
			*/
			portfolio::eTransactionType GetValueElseDefault( type IdCa ) ;

			/** Get the default business event for the corporate action.
			@param IdCa is the item of the corporate action.
			@return the default ID of the business event. This is used
			without the back office kernel module.
			*/
			static portfolio::eTransactionType	GetDefault(type IdCa ) ;

			/** Save the new corporate action list in the database.
			@param ArrayIdBe is an array of business event IDs of size _NUMBER_OF_TYPE_CORPORATE_ACTION_
			It then compares the new and old list and if they are different, the new list is saved.
			@version 5.2.2 Commit now and send a CorporateActionUpdate 
			*/
			void WriteChange( long* ArrayIdBe ) ;

			/** Get the number of corporate actions.
			@return the total number, that is _NUMBER_OF_TYPE_CORPORATE_ACTION_
			*/
			static int GetMaxCorporateAction() ;


			/** Read the overloaded business event for one corporate action.
			@param IdCa is the corporate action you want to read in the database.
			@param IdBe is the output return. Value is 0, if it is not overloaded.
			@return always true.
			@version 5.2.2 This method uses now a cache.
			*/
			static bool SReadValue( type IdCa , long& IdBe ) ;

			/** Read one business event for one corporate action.
			@param IdCa is the corporate action you want to read in the database.
			@return the associated business event. It it has not been overloaded, return the default
			business event (the Front Office business event).
			@version 5.2.2 This method uses now a cache.
			*/
			static portfolio::eTransactionType SReadValueElseDefault( type IdCa) ;

		private :
			/** Save in the database one corporate action.
			@param IdCa is the corporate action to save.
			@param IdBe is the business event id to save.
			@return false in case of Oracle error.
			@version 5.2.2 becomes private due to the cache.
			*/
			static bool WriteValue( type IdCa , long IdBe ) ;

			void AllocAndFillArray() ;
			struct SCorporateAction;

			SCorporateAction* fArrayIdBe ;
		};

	 }
}
SPH_EPILOG
#endif
