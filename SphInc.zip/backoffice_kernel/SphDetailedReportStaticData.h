/*
 	File:		SphDetailedReportStaticData.h

 	Contains:	Base Class for different static data

 	Copyright:	� 2001-2013 Sophis.

*/

/*! \file SphDetailedReportStaticData.h
	\brief Base Class for different static data
*/

#pragma once

#ifndef _SPH_DETAILEDREPORTSTATICDATA_H_
#define _SPH_DETAILEDREPORTSTATICDATA_H_


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_DETAILEDREPORTSTATICDATA(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRDetailedReportStaticData)
#define CONSTRUCTOR_DETAILEDREPORTSTATICDATA(derivedClass)
#define WITHOUT_CONSTRUCTOR_DETAILEDREPORTSTATICDATA(derivedClass)
#define	INITIALISE_DETAILEDREPORTSTATICDATA(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{	
	namespace backoffice_kernel
	{		
		struct SOPHIS_BO_KERNEL CSRStatusReportInput
		{
			long fFilterType;
			long fFilterId;
		};

		struct SOPHIS_BO_KERNEL CSRStaticDataInfo
		{
			_STL::string fDescription;		
			_STL::string fValue;

			_STL::vector< CSRStaticDataInfo > fValues;

			void				Add( const CSRStaticDataInfo& dataValue);
			unsigned int		Size() const;
			CSRStaticDataInfo	GetNth(unsigned int index);
			void				Clear();
		};

		class SOPHIS_BO_KERNEL CSRDetailedReportStaticData
		{
		public:
			/** Trivial destructor.
			*/
			virtual ~CSRDetailedReportStaticData() {}

			virtual void getData(const CSRStatusReportInput& input, CSRStaticDataInfo& data) const = 0 ;
			
			/** Get the singleton for one data.
			This is equivalent to CSRDetailedReportStaticData::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the data name is not found.
			@param modelName is a C string for the data type.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRDetailedReportStaticData* getInstance( const char* modelName ) ;
			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_DETAILEDREPORTSTATICDATA.
			@see tools::CSRPrototype
			*/
			virtual CSRDetailedReportStaticData* Clone() const = 0;
			
			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRDetailedReportStaticData, const char*, sophis::tools::less_char_star> prototype;
			
			/** Access to the prototype singleton.
			To add an data to this singleton, use INITIALISE_DETAILEDREPORTSTATICDATA.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};
	}
}
SPH_EPILOG
#endif
