#ifndef __SophisDialogCounterparty_H__
#define __SophisDialogCounterparty_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphThirdPartyDlg.h"
#include "SphInc/gui/SphDatabaseAuditDialog.h"
#include "exception"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(memory)

#define DECLARATION_COUNTERPARTY_TAB(derivedClass)	DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derivedClass,sophis::backoffice_kernel::CSRCounterpartyTab)
#define	INITIALISE_COUNTERPARTY_TAB(derivedClass, name)	    INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{	
	namespace backoffice_kernel
	{
		class SOPHIS_BO_KERNEL DialogOpenChecker
		{
		public:
			DialogOpenChecker();

			bool IsAlreadOpen() const;

			void SetToOpen(bool option);

		private:
			bool fIsOpen;	 
		};	

		class SOPHIS_BO_KERNEL CSRCounterpartyTab :  public sophis::gui::CSRDatabaseAuditDialog
		{
		public:
			CSRCounterpartyTab(	const char *table_name, const char *column_name, bool doAudit, bool FEVersion = false);

			virtual long CreateIdentifier();
			bool CreateNextAuditCode( long* nextCode,char * compo_table,eSavingMode *mode );
			void Open(void);

			virtual CSRCounterpartyTab* Clone() const=0;			

			static CSRCounterpartyTab *getInstance(const char* methodName);			

			typedef sophis::tools::CSRPrototype<CSRCounterpartyTab,
				const char*,
				sophis::tools::less_char_star> prototype;

			void InternelInitialize(const sophis::gui::CSRFitDialog * parent, long ident);
			virtual void Initialize(const sophis::gui::CSRFitDialog * parent, long ident)=0;
			sophis::gui::CSRFitDialog* GetParent() const { return fParent; }
			void SetAuditMode(bool AuditMode);

			static prototype& GetPrototype();

		protected:
			long fIdent;	
			sophis::gui::CSRFitDialog* fParent;
			sophis::backoffice_kernel::DialogOpenChecker fDlgOpenChk;
		};		

		class SOPHIS_BO_KERNEL CSDialogCounterparty : public sophis::gui::CSRDatabaseAuditDialog
		{
		public:
			CSDialogCounterparty();
			CSDialogCounterparty(const sophis::gui::CSRFitDialog * parent,SSThirdParty *NouveauTiers, Boolean newTiers, bool auditMode = false);
			CSDialogCounterparty(const sophis::gui::CSRFitDialog * parent,long ident,bool auditMode = false);
			~CSDialogCounterparty();

			void	Initialize(const sophis::gui::CSRFitDialog * parent,SSThirdParty *NouveauTiers, Boolean newTiers, bool auditMode = false);
			void	Initialize(const sophis::gui::CSRFitDialog * parent,long ident,bool auditMode = false);
			virtual int		GetExtraElementSize() { return 0; }
			virtual void	CreateExtraElements(int nb) { };
			
			virtual	void	Open(void);			
			virtual bool	CreateNextAuditCode( long* nextCode,char * compo_table,sophis::backoffice_kernel::eSavingMode *mode );			//
			virtual	Boolean	Close(void);
			virtual void	Destroy();			
			virtual	void	ElementValidation(int NAE_Modifie);
			virtual bool	CanSave(void);
			virtual bool	Save(sophis::backoffice_kernel::eSavingMode mode);			
			virtual long	CreateIdentifier();			
			virtual void	SetIdent(long id) { fIdent = id; }
			sophis::gui::CSRFitDialog* GetParent() const { return fParent; }

			void	CreateElement();			
			void    DisableAllElement();
			bool	GetAuditMode() { return fDoAudit; }
			bool	GetSaved() { return fSaved; }
			SSThirdParty *GetTiers() { return fInfoTiers; }

			sophis::backoffice_kernel::CSRThirdPartyDlg* GetThirdParty() { return fThirdPartyOwner; }
			void SetThirdParty(sophis::backoffice_kernel::CSRThirdPartyDlg* tparty) { fThirdPartyOwner = tparty; }

			bool	fNewTiers;
		protected:
			void EnableBankInfo();
			bool CheckElement();

			bool	fIsReadOnly;

			SSThirdParty *fInfoTiers;
			long	fBankType;
			bool	fSaved;
			bool	fCreate;
			bool	fDeleteInfoTiers;
			DialogOpenChecker fDlgOpenChk;
			long	fIdent;
			sophis::gui::CSRFitDialog* fParent;

			// Used to determine if the Thirdparty associated
			// with this Dialog is a Clone (and deleting it)
			sophis::backoffice_kernel::CSRThirdPartyDlg* fThirdPartyOwner;
		};
	}
}
SPH_EPILOG
#endif
