/*
 	File:	SphDividendTaxCondition.h

 	Contains:	Abstract base class which can be used to extend popup menu of Condition1, 
				Condition2, Condition3 columns of Dividends Taxation Rules window 
				to add client specific functionality.

 	Copyright:	� 2004-2005 Sophis.

*/

/*! \file SphDividendTaxCondition.h
	\brief Abstract base class which can be used to extend popup menu of Condition1, 
		   Condition2, Condition3 columns of Dividends Taxation Rules window
		   to add client specific functionality.
*/

#ifndef __SPHDividendTaxCondition_H_
#define __SPHDividendTaxCondition_H_
#pragma once

#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"



#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(set)

SPH_PROLOG


namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
}

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_DIVIDEND_TAX_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRDividendTaxCondition)
#define CONSTRUCTOR_DIVIDEND_TAX_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_DIVIDEND_TAX_CONDITION(derivedClass)
/*
 *	Macro to register derived client classes in Risque
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to identify registrated class.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Dividends Taxation Rules window.
 */
#define	INITIALISE_DIVIDEND_TAX_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)


namespace sophis {
	namespace backoffice_kernel {

		/** Interface to create a new condition to select a dividends taxation rule.
		When executing a corporate action (dividend or tax credit), the engine will first select
		a rule browsing the rules selector. When the criteria match, it plays the user conditions. 
		A new condition can be added by implementing this interface.
		@since 4.5.1.0.17
		*/
		class SOPHIS_BO_KERNEL CSRDividendTaxCondition 
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRDividendTaxCondition() {}

			/*
			 *	Pure virtual method.
			 *	Used while selecting the rule from Dividends Taxation rules set.
			 *	Method is called for Condition1, Condition2, Condition3 columns. Logical 'AND' is used
			 *	to select the matching rule - found by framework.
			 *	The result has to be TRUE to make the rule selected.
			 *	@instr is the instrument
			 *	@return is the boolean and is calculated by the client code.
			 */
			virtual bool GetCondition(const sophis::instrument::CSRInstrument*instr) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_DIVIDEND_TAX_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSRDividendTaxCondition* Clone() const = 0;

			/** typedef for the prototype : the key is a string
			*/
			typedef sophis::tools::CSRPrototype<CSRDividendTaxCondition, 
												const char *, 
												sophis::tools::less_char_star> prototype;
			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_DIVIDEND_TAX_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

		/** Structure giving the list of rules for an Instrument.
		@since 4.5.1.0.17
		*/
		struct SSDividendRule
		{
			/** Id of the rule to apply.*/
			long	fId;

			/** Sql condition on a depositary and entity (in english) to get the list of deals where to apply.
			If there is no condition, fWhere is an empty string.
			*/
			_STL::string	fWhere;


			/** One element to generate by where condition.
			*/
			struct Value
			{
				/** Id of the corporate action to apply.*/
				long	fId;

				/** Percentage of the amount to receive; 0.8 for 80%.
				*/
				double	fPercentage;

				/** Business event to apply. if 0, use the standard one.
				*/
				long	fBusinessEvent;

				/** Counterparty to put in the deal. If 0, use the depositary. */
				long	fCounterpart;

				/** Value date of the transaction. If 0, the payment date of the corporate action.*/
				long	fSettlementDate;
				
				/** Filter on the quantity.*/
				_STL::string fQuantityFilter;

			};

			/** List of element to generate by where condition.
			This is a ordered vector; note that the third element has to be generated 
			when the third where matches but also the two first one do not match. For the 
			transactions which matchs no element, the standard generation is taken.
			*/
			typedef _STL::vector<Value> ValueList;
			ValueList	fValueList;

			/** Amount type used to find what to generate.
			*/
			enum	AmountType
			{
				eCash,
				eTaxCredit
			};

			/** Result of generation to do for one dividend on one instrument.
			*/
			typedef _STL::vector<SSDividendRule> List;

			/** Get a list of events to generate by counterpart/entity.
			@param instrumentCode is the instrument id where the amount is to generate.
			@param type is the type of amount to generate.
			@param businessEvent is the 1st business event of the corporate action
			@param list is the output.
			*/
			static SOPHIS_BO_KERNEL void GetGeneration( long instrumentCode, 
														AmountType type, 
														short businessEvent,
														long date, 
														List &list);

		private:
			/** Build the fWhere condition from some parameters:
			@param instrumentCode is the instrument id where the amount is to generate.
			@param corporateActionType is the type of amount to generate.
			@param businessEvent is the 1st business event of the corporate action
			*/
			void SetWhere(long instrumentCode, short corporateActionType, short businessEvent,
						  const _STL::set<long>& rules);
		};
	}
}



SPH_EPILOG

#endif //__SPHDividendTaxCondition_H_
