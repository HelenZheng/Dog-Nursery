#ifndef __SphDividendTaxationRuleEngine_H_
#define __SphDividendTaxationRuleEngine_H_

#include "SphInc/backoffice_kernel/SphDividendTaxCondition.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {

			class SOPHIS_BO_KERNEL DividendTaxationRuleEngine
			{
			public:
				/** Get the tax factor that applies to a dividend filtered by the given parameters
				@param instrumentCode is the instrument id where the dividends are defined.
				@param mvtIdent Id of the position.
				@param type is the type of amount to generate.
				@param businessEvent is the 1st business event of the corporate action or position.
				@param entity to match.
				@param depositary to match.
				@param counterparty to match.
				@return the tax factor
				@since 6.2
				*/
				virtual double GetFactor(long instrumentCode,
										portfolio::PositionIdent mvtIdent,
										SSDividendRule::AmountType type,
										short businessEvent,
										long entity,
										long depositary,
										long counterparty);
				
				static DividendTaxationRuleEngine& GetInstance();
				static void SetInstance(DividendTaxationRuleEngine& newInstance);
			protected:
				DividendTaxationRuleEngine(){};
				virtual ~DividendTaxationRuleEngine(){};
				static		DividendTaxationRuleEngine	fInstance;
			};
	}
}

SPH_EPILOG
#endif