/*
 	File:		SphEditBusinessEvent.h

 	Contains:	Class for the handling of user's resources

 	Copyright:	� 1995-2000 Sophis.

*/

/*! \file SphEditBusinessEvent.h
	\brief Handling user resources.
*/

#pragma once

#ifndef _SphEditBusinessEvent_H
#define _SphEditBusinessEvent_H

#include "SphInc/gui/SphCustomMenu.h"

#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis	{
	namespace backoffice_kernel	{

		/** Class for editing a business event as a pop-up menu.
		It also works without the Back Office module.
		*/
		class SOPHIS_FIT CSREditBusinessEvent : public sophis::gui::CSRCustomMenu {
		public:
			/** Constructor when editing in a dialog.
			@param dialog is the dialog where the item has to be edited.
			@param ERId_Menu is the item number in the dialog with a shift of ID_ITEM_SHIFT.
			@param editable to allow writing mode.
			@param value is the default business event ID.
			@param columName is the field name in the database which may be required when saving.
			@see CSRElement
			*/
			CSREditBusinessEvent(	gui::CSRFitDialog 	*dialog,
									int 			ERId_Menu,
									bool			editable=true,
									short			value = 0,
									const char 		*columnName=kUndefinedField);

			/** Constructor when editing in a list.
			@param list is the list where the item has to be edited.
			@param CNb_Menu is the column number in the list.
			@param editable to allow writing mode.
			@param columName is the field name in the database which may be needed when saving.
			@see CSRElement
			*/
			CSREditBusinessEvent(	gui::CSREditList		*list,
									int 			CNb_Menu,
									bool			editable=true,
									const char 		*columnName=kUndefinedField);

		protected:
			void BuildMenu();
			void SetValueFromList();
			void SetListFromValue();

		private:
			/** this vector will serve as an index to allow BE be sorted in the menu
				separator value between sophis BEs and user BEs is also reserved in it 
			*/
			SPH_BEGIN_NOWARN_EXPORT
			_STL::vector< long > fBEId;
			SPH_END_NOWARN_EXPORT
		};
	}
}

SPH_EPILOG

#endif // _SphEditBusinessEvent_H
