/*
 	File:		SphKernelRights.h
 
 	Contains:	Class to determine new deal access rights
 
 	Copyright:	� 2001-2003 Sophis.
*/

#pragma once

#ifndef _SphEditModel_H_
#define _SphEditModel_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_kernel
	{

		/** Interface to describe fields in dialogs or blotters to be able to modify.
		This is used in a workflow rule to disable events applicable to the deal or message.
        Deriving from this model interface we create Prototypes of model sets for deal input dialog 
        or confirmation/payment blotters
		@since 4.7.0
		*/
		class SOPHIS_BO_KERNEL CSREditModel
		{
		public:

			/** method to decide if user has access right to control
			@param right is a string containing user right
			@param item_number
			this is the identifier of the control element for which access is decided.
			This identifier is interpreted differently depending on the sub-class overridding the method:

			1-
			for {@link backoffice_kernel::CSRKernelEditModel}, the model checks the access to an item on
			the transaction dislog. The identifier item_number passed to CSRKernelEditModel::has_access
			is the number as defined by the enumeration {@link gui::eDealInputID}.
			For a new item added by the toolkit (overload the transaction dialog), the value of item_number
			passed is whatever value the element list 'elemsV' is loaded with. The list 'elemsV' is loaded
			by overridding the method {@link gui::CSRTransactionDialog::GetSpecificElements}.

			2-
			for {@link backoffice_otc::CSROTCEditModel}, the model checks access to a column on the OTC
			blotter. The identifier item_number passed to has_access is the ranking of the column name
			in the string resource.

			@returns true if has access the control item, otherwise - false
			*/
			virtual bool has_access(const char* right,						
									long item_number) const = 0;

		protected:
			CSREditModel();
			bool item_matched( int item,int first, ... ) const;
			bool has_right(const char* right) const;
		};

	}
}

SPH_EPILOG

#endif // _SphEditModel_H_

