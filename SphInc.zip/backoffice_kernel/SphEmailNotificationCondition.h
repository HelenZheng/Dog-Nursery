/*
 	File:	SphEmailNotificationCondition.h

 	Contains:	Abstract base class which can be used to extend popup menu of Condition1, 
				Condition2, Condition3 columns of Email Notification Rules window to add client 
				specific funcionality.

 	Copyright:	� 2010 Sophis.

*/

#pragma once


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_EMAIL_NOTIFICATION_RULES_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSREmailNotificationCondition)
#define CONSTRUCTOR_EMAIL_NOTIFICATION_RULES_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_EMAIL_NOTIFICATION_RULES_CONDITION(derivedClass)
/*
 *	Macro to be placed in the clients <main>.cpp to register derived client classes
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Email Notification Rules window.
 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
 */
#define	INITIALISE_EMAIL_NOTIFICATION_RULES_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel {


		/** Interface to create a new condition to be applied when selecting an email notification rule.
		Only available with back office kernel.
		@since 6.0.1
		*/
		class SOPHIS_BO_KERNEL CSREmailNotificationCondition
		{
		public:
			/*
			 *	Pure virtual method.
			 *	Used by the framework while selecting an email notification rule.
			 *	Method is called for Condition1, Condition2, Condition3 columns. Logical 'AND' is used
			 *	to make desision if to select the matching rule - found by framework.
			 *	The result has to be TRUE to make the rule selected.
			 *	@tr is the reference to the transaction assosiated with the processed deal;
			 *	it is the final (resp. initial) state for a deal created or modified (resp. canceled).
			 *	@return is the boolean and is calculated by the client code.
			 */
			virtual bool GetCondition(const portfolio::CSRTransaction* tr) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_EMAIL_NOTIFICATION_RULES_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSREmailNotificationCondition* Clone() const = 0;

			/** typedef for the prototype : the key is a string
			*/
			typedef sophis::tools::CSRPrototype<CSREmailNotificationCondition, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_EMAIL_NOTIFICATION_RULES_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

	}	// namespace backoffice_kernel
}		// namespace sophis

SPH_EPILOG
