#pragma once

#ifndef _SphISROtcInput_H_
#define _SphISROtcInput_H_

#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/portfolio/SphTransactionEnums.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"
#include "SphInc/instrument/SphInstrumentEnums.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/portfolio/SphTransaction.h"

SPH_PROLOG
namespace sophis
{
	namespace tools {
		class CSREventVector;

		namespace dataModel {
			class DataSet;
		}
	}
	
	namespace backoffice_kernel {
		class ISRSsiLinksTkCriteria;
		class ISKernCondArg;
		struct  TAccAmountInfoExt;

#define DECLARATION_OTC_INPUT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::ISROtcInput)
#define CONSTRUCTOR_OTC_INPUT(derivedClass)
#define WITHOUT_CONSTRUCTOR_OTC_INPUT(derivedClass)
#define	INITIALISE_OTC_INPUT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

struct SOPHIS_BO_KERNEL SSDocGenerationCriteria 
{
	char amount_type [40];
	long recipient_type;
	SSDocGenerationCriteria(char *a=NULL, long r=0);
};

class SOPHIS_BO_KERNEL ISROtcInput
{
public:
	ISROtcInput() {}
	virtual ~ISROtcInput() {}
	
	virtual ISROtcInput* GetOTCInputIface(portfolio::TransactionIdent tradeID,
	                                      long sourceVersion) const = 0;

	virtual sophis::portfolio::TransactionIdent GetSourceID() = 0;
	virtual short GetSourceVersion() = 0;
	virtual short GetSourceLatestVersion() = 0;
	virtual accounting::eTradeType GetSourceType() const = 0;


	virtual long GetInstrumentID() = 0;
	virtual const instrument::CSRInstrument* GetInstrument(sophis::tools::CSREventVector *messages) const = 0;
	virtual instrument::ePositionType GetPositionType() const = 0;
	virtual sophis::portfolio::PositionIdent GetPositionID() = 0;
	virtual long GetFolioID() = 0;
	virtual long GetBusinessEvent() const = 0;
	virtual long GetSettlementDate() = 0;
	virtual long GetTransactionDate() { return 0; }	
	virtual long GetSettlementCurrency() = 0;
	virtual long GetSettlementMethod() const = 0;
	virtual long GetPaymentMethod() const = 0;
	virtual eTransactionOriginType GetCreationType() const = 0;
	virtual sophis::portfolio::eBODeliveryType GetDeliveryType() const = 0;
	
	/** Returns the SSI path id for the nostro cash.
	* function in 6.3 returned the Nostro acocunt id.
	* @since 7.0.0*/
	virtual long GetNostroAccountId() const = 0;
	/** Returns the SSI path id for the lostro cash.
	* @since 7.0.0*/
	virtual long GetLostroAccountId() const = 0;

	virtual long GetEntity() const = 0;
	virtual long GetCounterparty() const = 0;
	virtual long GetCounterparty2() const = 0;
	virtual long GetBroker() const = 0;
	virtual long GetDepositary() const = 0;
	virtual long GetDepositaryOfCounterparty() const = 0;
	virtual long GetClearingHouse() const = 0;
	virtual long GetClearingMember() const = 0;
	virtual long GetThirdPartyIDForTemplateSelection( void) = 0;
	virtual void SetThirdPartyIDForTemplateSelection( long thirdPartyID) = 0;

	virtual long GetBOStatus() const = 0;

	virtual _STL::string GetLogHeader() const = 0;
	virtual void RegenerateOtcMessage( long otcType, sophis::tools::CSREventVector & mess) = 0;

#pragma region XML

	/* returns ref to data set that was created inside parameter data set to describe underlying source*/
	virtual tools::dataModel::DataSet&  DescribeSource( tools::dataModel::DataSet& dtccDS) const = 0;
	//virtual void GetXMLSourceInformation() = 0;
	//virtual void DescribeTKSourceExtension( tools::dataModel::DataSet& dtccDS) const = 0;

	virtual void AjustSettlementDateInXML( tools::dataModel::DataSet& ds );

#pragma endregion XML

#pragma region Toolkit	

	virtual backoffice_kernel::ISRSsiLinksTkCriteria* GetSSILinksTKCriteria() = 0;
	virtual double GetAmountType( const char* amountTypeName,  TAccAmountInfoExt & amountInfo) = 0; 
	virtual long GetPostingDate( const char* postingDateName) = 0;

	virtual ISKernCondArg* GetKernCondArgument() const = 0;
	/** Check the condition of the third party document generation rules to determine whether a message has to be generated.
	@param conditionName the name of the condition to check.
	@param criteria is the data of the message in the third party.
	@return true if the message has to be generated.
	*/
	bool CheckDocGenCondition( const char* conditionName, SSDocGenerationCriteria &crit) const;

#pragma endregion Toolkit

#pragma region Prototype

	/** Get the id (mandatory method for CSRPrototypeWithId)
	It is the source type.
	*/
	int GetId() const;
	/** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_OTC_INPUT.
	@see tools::CSRPrototype
	*/
	virtual ISROtcInput* Clone() const = 0;
	/** The key for the prototype is a const char *
	@see CSRPrototype
	*/
	typedef sophis::tools::CSRPrototypeWithId<ISROtcInput
		,const char *
		,sophis::tools::less_char_star> prototype;
	/** Access to the prototype singleton.
	To add a trigger to this singleton, use INITIALISE_OTC_INPUT.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();

#pragma endregion Prototype
};

	}

}

SPH_EPILOG

#endif // _ISROtcInput_H_
