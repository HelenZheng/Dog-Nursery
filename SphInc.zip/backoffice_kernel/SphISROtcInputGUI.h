#pragma once

#ifndef _SphISROtcInputGUI_H_
#define _SphISROtcInputGUI_H_

#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"

SPH_PROLOG
namespace sophis
{
	
	namespace backoffice_kernel {
		class ISROtcInput;
		struct KernEvent;

#define DECLARATION_OTC_INPUT_GUI(derivedClass)		DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_kernel::ISROtcInputGUI)
#define CONSTRUCTOR_OTC_INPUT_GUI(derivedClass)
#define WITHOUT_CONSTRUCTOR_OTC_INPUT_GUI(derivedClass)
#define	INITIALISE_OTC_INPUT_GUI(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

class SPH_BO_KERNEL_GUI ISROtcInputGUI
{
public:
	ISROtcInputGUI() {}
	virtual ~ISROtcInputGUI() {}

	virtual accounting::eTradeType GetSourceType() const = 0;
	virtual long DisplaySource(const ISROtcInput & oInput) const = 0;
	virtual bool ApplyKEventDialog(const ISROtcInput & oInput, KernEvent & ke) const = 0;

	/** Get the id (mandatory method for CSRPrototypeWithId)
	It is the source type.
	*/
	int GetId() const;

	/** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_OTC_INPUT_GUI.
	@see tools::CSRPrototype
	*/
	virtual ISROtcInputGUI* Clone() const = 0;

	/** The key for the prototype is a const char *
	@see CSRPrototype
	*/
	typedef sophis::tools::CSRPrototypeWithId<ISROtcInputGUI
		,const char *
		,sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	To add a trigger to this singleton, use INITIALISE_OTC_INPUT_GUI.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();
};

	}
}

SPH_EPILOG
#endif // _ISROtcInputGUI_H_
