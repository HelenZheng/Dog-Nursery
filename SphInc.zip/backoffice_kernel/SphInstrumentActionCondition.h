#ifndef _SPH_INSTRUMENT_ACTION_CONDITION_H_
#define _SPH_INSTRUMENT_ACTION_CONDITION_H_


#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"

#define DECLARATION_INSTRUMENT_ACTION_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRInstrumentActionCondition)
#define CONSTRUCTOR_INSTRUMENT_ACTION_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_INSTRUMENT_ACTION_CONDITION(derivedClass)
#define	INITIALISE_INSTRUMENT_ACTION_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}

	namespace backoffice_kernel
	{
		/** Interface to define a condition on saving an instrument.
		Need the back office kernel module to work.
		When defining a rule for saving instrument, a condition to check on that instrument can be specified.
		To add a new condition in the list, an implementation of this interface must be done.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRInstrumentActionCondition
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRInstrumentActionCondition() {}

			/** Method to check if the modified instrument is correct.
			It is called to select the right rule to apply when saving.
			@param instrument is the modified instrument; to get the original one, use {@link CSRInstrument::GetInstance}.
			@return true if the condition applies.
			*/
			virtual bool IsCorrect(const instrument::CSRInstrument &instrument) const = 0;
			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSTRUMENT_ACTION_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSRInstrumentActionCondition* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef tools::CSRPrototype<CSRInstrumentActionCondition, const char *, tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a condition to this singleton, use INITIALISE_INSTRUMENT_ACTION_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};


	} // backoffice_kernel
} // sophis

SPH_EPILOG

#endif //_SPH_INSTRUMENT_ACTION_CONDITION_H_