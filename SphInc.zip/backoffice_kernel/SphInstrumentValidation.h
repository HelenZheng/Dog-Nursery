#ifndef _SphInstrument_Validation_h_
#define _SphInstrument_Validation_h_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphValidation.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_INSTRUMENT_MODIFIED_ACTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRInstrumentModifiedAction)
#define CONSTRUCTOR_INSTRUMENT_MODIFIED_ACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_MODIFIED_ACTION(derivedClass)
#define	INITIALISE_INSTRUMENT_MODIFIED_ACTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace tools
	{
		struct VoteException;
		class CSREventVector;
	}
	namespace instrument
	{
		class CSRInstrument;
	}

	namespace backoffice_kernel {

		struct ValidationData
		{
			long	fBusinessEvent;
			long	fKernelEvent;
			long	fGroupStatus;
		};

		/** Interface for triggering actions when saving an instrument using validation.
		Only available with back office kernel.
		Once the rule for saving an instrument is found, the trigger defined in the rule is executed 
		during a vote and notify for instrument.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRInstrumentModifiedAction
		{
		public:

			/** Trivial Destructor.
			*/
			virtual ~CSRInstrumentModifiedAction() {};

			/** Ask for a modification of an instrument.
			When modifying, all of the triggers will be called via VoteForModification to check if they accept the
			modification in the order eOrder + lexicographical order.
			@param instrument is the instrument to modify. It is a non-const object so it can
			be modified. To get the original instrument, do gApplicationContext->GetCSRInstrument(instrument.GetCode()).
			@throws VoteException if you reject that modification.
			*/
			virtual void VoteForModification(instrument::CSRInstrument &instrument) const
				throw (tools::VoteException, sophisTools::base::ExceptionBase)  {};


			/** Ask what to notify when modifying.
			When saving, after all the triggers have accepted the modification, they are called again
			in the order eOrder + lexicographical order via
			NotifyModified to check if there is data to save in the database or to send to other servers.
			@param instrument is the instrument to modify. It is a const object so it cannot
			be modified. To get the original instrument, do gApplicationContext->GetCSRInstrument(instrument.GetCode()).
			@param message is an event vector to set the messages to send, after the data is committed. If you need to send data, you cannot do it immediately because you must be sure that the
			message is in concordance with the database, which will be the case after committing. Moreover, if there is an exception in another trigger, the message must not be sent.
			@throws ExceptionBase if that modification is rejected. Do not send a VoteException. This can be problematic, as in the case of multi-saving, it will assume that no data or message is done. Do not commit, nor Rollback either,
			this is performed elsewhere.
			*/
			virtual void NotifyModified(const instrument::CSRInstrument &instrument,const ValidationData &data, tools::CSREventVector &message) const
				throw (sophisTools::base::ExceptionBase) {};


			/** typedef for the prototype : the key is a string
			*/
			typedef tools::CSRPrototype<CSRInstrumentModifiedAction, const char *, sophis::tools::less_char_star> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_INSTRUMENT_MODIFIED_ACTION.
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSTRUMENT_MODIFIED_ACTION.
			@see tools::CSRPrototype
			*/
			virtual CSRInstrumentModifiedAction * Clone() const = 0;


		};

 
	} //namespace backoffice_kernel
} //namespace sophis
SPH_EPILOG

#endif //_SphInstrument_Validation_h_
