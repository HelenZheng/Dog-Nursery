#ifndef __SPHKernelActionCondition_H_
#define __SPHKernelActionCondition_H_


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_KERNEL_ACTION_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRKernelActionCondition)
#define CONSTRUCTOR_KERNEL_ACTION_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_KERNEL_ACTION_CONDITION(derivedClass)
#define	INITIALISE_KERNEL_ACTION_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace portfolio	{
		class CSRTransaction;
	}

	namespace backoffice_kernel {

		/** Interface to define a condition in kernel action.
		A kernel action condition is checked when an action is run in kernel engine.
		@since 5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelActionCondition
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRKernelActionCondition() {}

			/** Method called when an event is executed on a deal and the workflow tells to execute this action.
			This is called during an internal notify transaction action when new transaction is created.
			Action is excluded from execution if this method returns false.
			@param transaction - new transaction.
			*/
			virtual bool VoteForCreation(const portfolio::CSRTransaction &transaction) const = 0;

			/** Method called when an event is executed on a deal and the workflow tells to execute this action.
			This is called during an internal notify transaction action when transaction is modified.
			Action is excluded from execution if this method returns false.
			@param original is the transaction before modification.
			@param transaction - transaction after modification.
			*/
			virtual bool VoteForModification(const portfolio::CSRTransaction & original, const portfolio::CSRTransaction &transaction) const = 0;

			/** Method called when an event is executed on a deal and the workflow tells to execute this action.
			This is called during an internal notify transaction action when transaction is deleted.
			Action is excluded from execution if this method returns false.
			@param transaction - transaction for deletion.
			*/
			virtual bool VoteForDeletion(const portfolio::CSRTransaction &transaction) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_KERNEL_ACTION_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSRKernelActionCondition* Clone() const = 0;

			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRKernelActionCondition
												,const char *
												,sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_KERNEL_ACTION_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

	}
}
SPH_EPILOG
#endif //__SPHKernelActionCondition_H_
