#ifndef _SphKernelBlotterColumn_H_
#define _SphKernelBlotterColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
struct SSCellStyle;
union SSCellValue;
class CSDumpMenu;

namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel {

/**
 * Interface for blotter context.
 * @version 7.0
 */
class SOPHIS_BO_KERNEL CSRKernelBlotterContext
{
public:
	virtual ~CSRKernelBlotterContext();
};

/**
 * Macros for handling kernel blotter column prototype implementation.
 * @version 7.0
 */
#define DECLARATION_KERNEL_BLOTTER_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_kernel::CSRKernelBlotterColumn)
#define CONSTRUCTOR_KERNEL_BLOTTER_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_KERNEL_BLOTTER_COLUMN(derivedClass)
#define	INITIALISE_KERNEL_BLOTTER_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Kernel blotter column and prototype.
 * These columns work in conjunction with transaction columns (SphInc/portfolio/SphTransactionColumn.h)
 * but are specific to the kernel blotter.
 * @version 7.0
 */
class SOPHIS_BO_KERNEL CSRKernelBlotterColumn
{
public:
	/** Destructor. */
	virtual ~CSRKernelBlotterColumn() {}

	/** 
	 * Method to check the equality of tr1 and tr2 by this column field. 
	 */
	bool IsEqual(const portfolio::CSRTransaction& tr1, const portfolio::CSRTransaction& tr2) const;

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param ctx Kernel blotter context calling the display.
	 * @param trans Transaction being displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCell(const CSRKernelBlotterContext& ctx,
		const portfolio::CSRTransaction& trans,
		SSCellValue *value,
		SSCellStyle *style) const = 0;

	/** 
	 * Returns the default cell size in pixels.
	 */
	virtual short GetDefaultWidth() const;

	/**
	 * Returns icon id to display when grouping by that column.
	 */
	virtual short GetGroupIcon() const;

	/**
	 * Determines if cell is a pop up cell or not. Default is false.
	 */
	virtual bool IsPopupCol(const CSRKernelBlotterContext& ctx) const;

	/**
	 * Determines if cell is a text. Default is true. 
	 */
	virtual bool IsTextCol(const CSRKernelBlotterContext& ctx) const;

	/**
	 * Determines if cell is editable. Default is false.
	 */
	virtual bool IsFolioElemtEditable(const CSRKernelBlotterContext& ctx) const;

	/**
	 * Popup menu processing.
	 */
	virtual CSDumpMenu* GetPopupMenu(const CSRKernelBlotterContext& ctx,
		int etat, long folioref, long rec_num, long field_num, short mods) const;

	/**
	 * Popup menu modification processing.
	 */
	virtual Boolean OnPopupMenuChange(CSRKernelBlotterContext& ctx,
		int etat, long folioref, CSDumpMenu* menu, int selection) const;

	/**
	 * Popup menu selection processing.
	 */
	virtual int GetPopupSelection(const CSRKernelBlotterContext& ctx,
		int etat, long folioref, CSDumpMenu* menu) const;

	/**
	 * Returns the id.
	 * The value is created at the end of the initialise because it must be unique according to the table COLUMN_NAME.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * Used when building the columns by {@link CSUReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototypeWithId<CSRKernelBlotterColumn, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_KERNEL_BLOTTER_COLUMN.
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/** Internal. */
	static void RefreshPrototype();

protected:
	long	fId;
};

	} // backoffice_kernel
} // sophis

SPH_EPILOG

#endif // _SphKernelBlotterColumn_H_
