/*
 	File:	SphKernelCondition.h

 	Contains:	Abstract base class which can be used to extend popup menu of Condition1, 
				Condition2, Condition3 columns of Kernel Workflow Definition window to add client 
				specific funcionality.

 	Copyright:	� 1995-2003 Sophis.

*/

/*! \file SphKernelCondition.h
	\brief Abstract base class which can be used to extend popup menu of Condition1, 
		   Condition2, Condition3 columns of Kernel Workflow Definition window to add client 
		   specific funcionality.
*/

#ifndef __SPHKernelCondition_H_
#define __SPHKernelCondition_H_
#pragma once


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/accounting/SphAccountingEnums.h"

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_WORKFLOW_DEF_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRKernelCondition)
#define CONSTRUCTOR_WORKFLOW_DEF_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_WORKFLOW_DEF_CONDITION(derivedClass)
/*
 *	Macro to be placed in the clients <main>.cpp to register derived client classes
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Kernel Workflow Definition window.
 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
 */
#define	INITIALISE_WORKFLOW_DEF_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel {

		class ISROtcInput;

		/** Data used to select a workflow.
		Used by the kernel condition {@link CSRKernelCondition} to find the workflow for a deal on an instrument not yet created.
		@since 4.5.2
		*/

		struct SOPHIS_FIT SSKernelInstrumentSelector
		{
			SSKernelInstrumentSelector();
			SSKernelInstrumentSelector(const SSKernelInstrumentSelector& s);
			SSKernelInstrumentSelector(long allotment, long currency, long market);

			long fAllotment; 
			long fCurrency;
			long fMarket; 
		};
		
		class SOPHIS_FIT ISKernCondArg
		{
		public: 
			virtual accounting::eTradeType GetSourceType() const = 0;
		};

		class SOPHIS_FIT CSKernCondTransactionArg: public ISKernCondArg
		{
		public: 
			CSKernCondTransactionArg( portfolio::CSRTransaction* tr): fDeal(tr) {}
			virtual accounting::eTradeType GetSourceType() const { return accounting::ttTrade; }
			portfolio::CSRTransaction* GetTransaction() const { return fDeal;}
		protected:
			portfolio::CSRTransaction* fDeal;
		};

		/** Interface to create a new condition to select a workflow or a rule in a workflow.
		Only available with back office kernel.
		When creating or modifying a transaction, the kernel engine will first select a workflow browsing the
		workflows selector; when the criteria matchs, it plays the user conditions. A new condition can be added
		by implementing this interface. Once the workflow has been selected, then the kernel engine selects a rule
		browsing the worflow rule; when the criteria matchs, it plays the same user conditions.
		@since 4.5.2
		*/
		class SOPHIS_FIT CSRKernelCondition //BR-22.12.2006 CLR
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRKernelCondition() {}

			/**	Pure virtual method.
			Used by the framework while selecting the rule from Workflow Definition rules set.
			Method is called for Condition1, Condition2, Condition3 columns. Logical 'AND' is used
			to make decision if to select the matching rule - found by framework.
			The result has to be TRUE to make the rule selected.
			@tr is the reference to the transaction assosiated with the processed deal;
			it is the final (resp. initial) state for a deal created or modified (resp. canceled).
			@sel is a structure giving some information about the instrument created; As the instrument may be
			not yet created, the structure gives some data coming from the future instrument created; if the instrument is created,
			the structure gives the data from the instrument.
			@return is the boolean and is calculated by the client code.
			*/
			virtual bool GetCondition(const portfolio::CSRTransaction& tr, const SSKernelInstrumentSelector &sel) const = 0;

			/*Method that dispatches to GetCondition(CSRTransaction,...)
			or evaluates condition for other arguments 
			*/
			virtual bool GetCondition(const ISKernCondArg& kcArg, const SSKernelInstrumentSelector &sel) const;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_WORKFLOW_DEF_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSRKernelCondition* Clone() const = 0;

			/** typedef for the prototype : the key is a string
			*/
			typedef sophis::tools::CSRPrototype<CSRKernelCondition, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_WORKFLOW_DEF_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

	}	// namespace backoffice_kernel
}		// namespace sophis
SPH_EPILOG
#endif //__SPHKernelCondition_H_
