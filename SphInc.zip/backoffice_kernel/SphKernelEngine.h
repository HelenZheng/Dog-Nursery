  #ifndef __SPHKernelEngine_H_
#define __SPHKernelEngine_H_


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_KERNEL_ENGINE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRKernelEngine)
#define CONSTRUCTOR_KERNEL_ENGINE(derivedClass)
#define WITHOUT_CONSTRUCTOR_KERNEL_ENGINE(derivedClass)
#define	INITIALISE_KERNEL_ENGINE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace tools	{
		class CSREventVector;
	}
	namespace backoffice_kernel {

		enum eGenerationType
		{
			egtNormal=1
			,egtModification
			,egtCancellation
		};

		struct SSKernelInstrumentSelector;

		/** Interface to define an action in kernel engine.
		A kernel action is run when an event is executed on a deal (for instance a confirmation).
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelEngine
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRKernelEngine() {}

			/** Method called when an event is executed on a deal and the workflow tells to execute this action.
			This is called during an internal notify transaction action.
			By default, calls the other Run method (for compatibility reason).
			@param original is the transaction before modification/deletion. 0 if new transaction.
			@param final is the transaction after creation/modification. 0 if deletion.
			@param generationType is defined at the action level.
			@param mess is a list of events to add your own messages.
			@param event_id is the kernel event exectuted to move from one transition to another one.
			@version 5.3 add a parameter event_id.
			@version 5.2 add a parameter final.
			*/
			virtual void Run( const portfolio::CSRTransaction* original,
							  const portfolio::CSRTransaction* final,
							  const _STL::vector<long>& recipientType,
							  eGenerationType generationType,
							  tools::CSREventVector& mess,
							  long event_id) const;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_KERNEL_ENGINE.
			@see tools::CSRPrototype
			*/
			virtual CSRKernelEngine* Clone() const = 0;

			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRKernelEngine
												,const char *
												,sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_KERNEL_ENGINE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		private:
			/** 
			@deprecated 5.2
			*/
			virtual void Run( const portfolio::CSRTransaction& transaction,
							  _STL::vector<long> recipientType,
							  eGenerationType generationType,
							  tools::CSREventVector& mess,
							  bool newTransaction = false) const;
			/** 
			@deprecated 5.3
			*/
			virtual void Run( const portfolio::CSRTransaction* original,
							  const portfolio::CSRTransaction* final,
							  const _STL::vector<long>& recipientType,
							  eGenerationType generationType,
							  tools::CSREventVector& mess) const;
		};

	}
}

SPH_EPILOG
#endif //__SPHKernelEngine_H_
