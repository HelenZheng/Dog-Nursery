/*
 	File:	SphKernelEvent.h

 	Contains:	the class of event.

 	Copyright:	� 2003-2004 Sophis.

*/

/*! \file SphKernelEvent.h
	\brief class for a back office event
*/

#ifndef __SPHKernelEvent_H_
#define __SPHKernelEvent_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"



#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {

		/** Describe what kind of user can execute this event.
		@see CSRKernelEvent::GetTier
		@since 4.5.2
		*/
		enum eBOEventTier
		{
			etrAll = -1,
			etrUndefined = 0,
			etrFrontOffice,
			etrBackOffice,
			etrAPI,
			etrAll2
		};

		enum eBOEventSTP
		{
			esNotSTP = 1,
			esSTP
		};



		/** Class to handle a kernal status. Available only with Back office kernel module.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelEvent
		{
		public:
			/** Constructor.
			@param id is the kernel event id for instance coming from {@link CSRTransaction::GetBackOfficeType()}.
			*/
			CSRKernelEvent(long id);
			

			/** Get the kernel event id.*/
			long	GetId() const;

			/**
			 * Get the kernel event internal code given a name. It is case sensitive.
			 @return 0 if it does not exist.
			 @since 5.2.1.0
			 */
			static long GetIdByName(_STL::string eventName);

			/** Get the name.
			@return a C string which must not be deleted; return "" if status does not exist.
			*/
			const char * GetName() const;

			/** Get the event type.
			@return a C string which must not be deleted; return "" if status does not exist.
			*/
			eBOEventTier	GetTier() const;

			/** Get the list of event available from a status.
			@param status is the id of the in initial status; may be -1 for creation.
			@param workflow is the id of a workflow.
			@param event_list is a output vector to get the events available from this status in a workflow; 
			if the status or the workflow do not exist, return an empty list.
			*/
			static void GetAvailableEvents(long status, long workflow, _STL::vector<long> &event_list);


			/** Find an event in a workflow.
			Generally used in a {@link CSRTransactionAction} to get the event id which generates this modification.
			@param workflow is the workflow id.
			@param initial_status is the initial status of the deal.
			@param final_status is the final status of the subscription.
			@return the event id.
			@throw GeneralException if final status not found.
			*/
			static CSRKernelEvent	Find(long workflow, long initial_status, long final_status);


		protected:
			/** Id of the event */
			long	fId;

		private:
			static const char * __CLASS__;
		};
	}
}
SPH_EPILOG

#endif
