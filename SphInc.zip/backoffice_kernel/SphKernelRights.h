/*
 	File:		SphKernelRights.h
 
 	Contains:	Class to determine new deal access rights
 
 	Copyright:	� 2001-2003 Sophis.
*/

#pragma once

#ifndef _SPHKERNELRIGHTS_H_
#define _SPHKERNELRIGHTS_H_
#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphEditModel.h"

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_KERNEL_EDIT_MODEL(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRKernelEditModel)
#define CONSTRUCTOR_KERNEL_EDIT_MODEL(derivedClass)
#define WITHOUT_KERNEL_EDIT_MODEL(derivedClass)
/** macro used for installing the kernel right in Risk
	@param derivedClass is the type of posting derived from CSRKernelRights
	@param name is the name of this right which will be used to store it in 
	database and for building menu of all kernel rights
*/
#define	INITIALISE_KERNEL_EDIT_MODEL(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

/** Deprecated macros and class
*/
#define DECLARATION_KERNEL_RIGHTS DECLARATION_KERNEL_EDIT_MODEL
#define CONSTRUCTOR_KERNEL_RIGHTS CONSTRUCTOR_KERNEL_EDIT_MODEL
#define WITHOUT_KERNEL_RIGHTS WITHOUT_KERNEL_EDIT_MODEL
#define INITIALISE_KERNEL_RIGHTS INITIALISE_KERNEL_EDIT_MODEL
#define	CSRKernelRights CSRKernelEditModel

SPH_PROLOG
namespace sophis
{
	namespace backoffice_kernel
	{

		/** Interface to describe fields in the purchase dialog to be able to modify.
		This is used in a workflow rule to disable events applicable to the deal.
		@since 4.5.2
		*/
        class SOPHIS_BO_KERNEL CSRKernelEditModel: public virtual CSREditModel
		{
		public:

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_KERNEL_RIGHTS.
			@see tools::CSRPrototype
			*/
			virtual CSRKernelEditModel* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRKernelEditModel, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_DATE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

		protected:
			CSRKernelEditModel();
		} ;
	}
}
SPH_EPILOG
#endif // _SPHKERNELRIGHTS_H_

