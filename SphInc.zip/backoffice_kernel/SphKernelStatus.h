/*
 	File:	SphKernelStatus.h

 	Contains:	the class of status.

 	Copyright:	� 2003-2004 Sophis.

*/

/*! \file SphKernelStatus.h
	\brief class for a back office status
*/

#ifndef __SPHKernelStatus_H_
#define __SPHKernelStatus_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"



#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {


		/** Class to handle a kernal status. Available only with Back office kernel module.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelStatus
		{
		public:
			/** Constructor.
			@param id is the kernel status id for instance coming from {@link CSRTransaction::GetBackOfficeType()}.
			*/
			CSRKernelStatus(long id);
			

			/** Get the kernel status id.*/
			long	GetId() const;

			/** Get the name.
			@return a C string which must not be deleted; return "" if status does not exist.
			*/
			const char * GetName() const;
			

			/** Get the final status in a workflow.
			Generally used to get the status to save when an event is applied.
			@param workflow is the workflow id.
			@param initial_status is the initial status of the deal.
			@param event is the event id to apply to the transaction.
			@return the final status.
			@throw GeneralException if final status not found.
			*/
			static CSRKernelStatus	 Find(long workflow, long initial_status, long event);

			/** Get the list of statuses.
			@param status_list is a output vector to get the list of all statuses;
			*/
			static void GetList(_STL::vector<long> &status_list);

		protected:
			/** Low level structute */
			long	fId;

		private:
			static const char * __CLASS__;

		};
	}
}

SPH_EPILOG
#endif
