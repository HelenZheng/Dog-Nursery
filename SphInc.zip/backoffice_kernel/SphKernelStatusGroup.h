/*
 	File:	SphKernelStatusGroup.h

 	Contains:	the class of status.

 	Copyright:	� 2003-2004 Sophis.

*/

/*! \file SphKernelStatusGroup.h
	\brief class for a back office group of statuses
*/

#ifndef __SPHKernelStatusGroup_H_
#define __SPHKernelStatusGroup_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"



#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {


		/** Class to handle a kernel group. Available only with Back office kernel module.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelGroupOfStatuses
		{
		public:
			/** Constructor.
			@param id is the kernel group of statuses id.
			*/
			CSRKernelGroupOfStatuses(long id);
			

			/** Get the kernel status id.*/
			long	GetId() const;

			/** Get the name.
			@return a C string which must not be deleted; return "" if status does not exist.
			*/
			const char * GetName() const;
			

			/** Get the list of status in a group of a status.
			@param status_list is a output vector to get the statuses belonging to the group; 
			if the group does not exist, return an empty list.
			*/
			void GetStatuses(_STL::vector<long> &status_list);


			/** Get the total list of group.
			@param group_list is a vector containing all groups id.
			*/
			static void GetList(_STL::vector<long> &group_list);

		protected:
			/** Id of the group. */
			long	fId;

		private:
			static const char * __CLASS__;

		};
	}
}

SPH_EPILOG
#endif
