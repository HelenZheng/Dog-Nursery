/*
 	File:	SphKernelWorkflowRule.h

 	Contains:	the class of a workflow rule.

 	Copyright:	� 2003-2004 Sophis.

*/

/*! \file SphKernelWorkflowRule.h
	\brief class for a back office kernel workflow rule
*/

#ifndef __SPHKernelWorkflowRule_H_
#define __SPHKernelWorkflowRule_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"



#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {

		/** Internal structure of a workflow rule. */
		struct KernWFRuleIDPlus;

		/** Class to handle a kernal workflow rule. Available only with Back office kernel module.
		Note that an instance is still valid after a change of the workflow but the data is not updated.
		@since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRKernelWorkflowRule
		{
		public:
			/** Constructor.
			@param id is the kernel worfflow rule id; id may be 0.
			*/
			CSRKernelWorkflowRule(long id = 0);
			
			/** Destructor. */
			~CSRKernelWorkflowRule();

			/** Get the list of rules available from a status.
			@param status is the id of the in initial status; may be -1 for creation.
			@param workflow is the id of a workflow.
			@param rule_list is a output vector to get the rule id available from this status in a workflow; 
			if the status or the workflow do not exist, return an empty list.
			*/
			static void GetAvailableRules(long status, long workflow, _STL::vector<long> &rule_list);

			/** Get the kernel workflow rule id.*/
			long	GetId() const;


			/** Get the workflow of the rule.
			@return the workflow id; 0 if no rule with id.
			*/
			long	GetWorkflow() const;

			/** Get the event .
			@return the id of the event.
			*/
			long	GetEvent() const;

			/** Get the initial status .
			@return the id of the status; may be -1 for creation.
			*/
			long	GetInitialStatus() const;

			/** Get the initial status .
			@return the id of the status; may be -1 for deletion.
			*/
			long	GetFinalStatus() const;

			/** Get the action to do when the event occurs.
			@return the id of the action to do; 0 for nothing to do.
			*/
			long	GetActionToDo() const;

			/** Get user right to authorize that modification.
			@param which may be 0 or 1.
			@return a C string which must not be deleted and not keeped outside the life of the instance.
			*/
			const char *	GetRightToHave(int which) const;


			/** Get authorized fields to modify by this event.
			@param which may be 0 or 1.
			@return a C string to use in the prototype of the class {@link CSRKernelRights}.
			*/
			const char *	GetModifiableFields(int which) const;

			/** Get condition on transaction to authorize this rule.
			@param which may be 0, 1 or 2.
			@return a C string to use in the prototype of the class {@link CSRKernelCondition}.
			*/
			const char *	GetCondition(int which) const;

			/** Get comments.
			@return a C string which must not be deleted and not keeped outside the life of the instance.
			*/
			const char *	GetComments() const;

			/** Get check deal to do when voting.
			@return a C String to use in the prototype of the class {@link CSRCheckDeal}.
			*/
			const char *	GetCheckDeal() const;

			/** Find a workflow per event.
			This method will look for a rule corresponding to an event.
			@param workflow_if is a valid workdlow id.
			@param initial_status is the initial status.
			@param event_id is the event id.
			@throws InvalidArgument if no such workflow rule. 
			*/
			void	FindByEvent(long workflow_id, long initial_status, long event_id);

		protected:

			/** Pointer on the basic structure */
			KernWFRuleIDPlus * fData;
			
		private:
			static const char * __CLASS__;

			/** Copy constructor not implemented.*/
			CSRKernelWorkflowRule(const CSRKernelWorkflowRule &);

			/** operator = not implmented.*/
			CSRKernelWorkflowRule & operator =(const CSRKernelWorkflowRule &);
		};
	}
}

SPH_EPILOG
#endif
