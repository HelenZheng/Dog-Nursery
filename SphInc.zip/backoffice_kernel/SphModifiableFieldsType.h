/*
 	File:	SphCheckDealType.h

 	Contains:	Abstract base class which can be used to extend popup menu's of Trade Checking Rules 
	window to add client specific funcionality.
*/


#ifndef _SPH_MODIFIABLE_FIELDS_TYPE_H_
#define _SPH_MODIFIABLE_FIELDS_TYPE_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphValidation.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_MODIFIABLE_FIELDS_TYPE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRModifiableFieldsType)
#define CONSTRUCTOR_MODIFIABLE_FIELDS_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_MODIFIABLE_FIELDS_TYPE(derivedClass)
#define	INITIALISE_MODIFIABLE_FIELDS_TYPE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace backoffice_kernel
	{
		/** Class to check if a deal's fields are modifiable
		With the back office kernel module, for each workflow rule in the workflow definition up to two modifiable
		fields rules may be specified. This modifiable fields condition is executed when attempting to modify a deal,
		and determines what fields may be edited using the workflow rule
		@since 7.1.2
		@see CSMKernelEditModel
		*/
		class SOPHIS_BO_KERNEL CSRModifiableFieldsType
		{
		public:
							
			/** Trivial destructor.
			*/
			virtual ~CSRModifiableFieldsType() {}
				
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRModifiableFieldsType, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_MODIFIABLE_FIELD_TYPE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			
			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_MODIFIABLE_FIELD_TYPE.
			@see tools::CSRPrototype
			*/
			virtual CSRModifiableFieldsType* Clone() const = 0;
			

			/** 
			Determines the name of the field. The value will be used to populate the Field Name menu
			@returns string naming the field
			@version 7.1.2
			*/
			virtual _STL::string GetFieldName(); 

			/**
			Determines the type of the field. 
			Determines the ID of the field in line with the Kernel Edit Model
			@return the type of field
			@version 7.1.2
			*/
			virtual int GetFieldID();

			/**
			Specify if editing the field has a back office impact
			@param transaction is the deal being checked
			@return the string value to compare
			@version 7.1.2
			*/
			virtual bool GetBackOfficeImpact();

		};

	} 
} 
SPH_EPILOG
#endif //_