/*! \file SphKernelEvent.h
	\brief class for the singleton of external operations
*/


#ifndef __CSRPOSITIONEXTOPREFCACHE_H
#define __CSRPOSITIONEXTOPREFCACHE_H

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(set)


#include "SphInc/tools/SphValidation.h"

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


#define EXTOPREF_SIZE	256

SPH_PROLOG
/* ---------------------------------------------------------------------- */
namespace sophis {
	namespace backoffice_kernel {

		/** Singleton class used to cache External Operation References associated
		* with positions. The DB is accessed only when the requested value si not
		* already present in the cache.
		*
		* To get the External Operation Reference associated with a position, call:
		*
			char extOpRef[40] = "";
			CSRPositionExtOpRefCache::GetInstance()->Get(posIdent, extOpRef, sizeof(extOpRef));
		*
		* When user changes the External Operation Reference associated with a position, call:
		*
			CSRPositionExtOpRefCache::GetInstance()->Change(posIdent, newExtOpRef);
		* @version 5.2.3 Add the notion of internal operation for stock loan.
		* @since 4.5.2
		*/
		class SOPHIS_BO_KERNEL CSRPositionExtOpRefCache
		{
		public:
			/**
			* Typedef for type uniformisation
			*/

			typedef _STL::set<portfolio::PositionIdent> PositionIdents;

			/* Constructor - Create the DB query
			*/
			CSRPositionExtOpRefCache(void);

			/* Destructor - Destroy the DB query
			*/
			~CSRPositionExtOpRefCache(void);

			/* GetInstance - Returns a pointer to the singleton instance
			*/
			static CSRPositionExtOpRefCache *GetInstance(void);

			/* Get - Returns the External Operation Reference associated with
			* the specified position identifier. It is returned from the cache
			* map if present, or loaded from DB if needed and added to the map.
			* Returns null/false if no result was found.
			*/
			const char *Get(portfolio::PositionIdent posIdent);

			/** Get the external reference.
			@return false if no operation; note that in that case, extOpRefBuffer is not updated.
			*/
			bool Get(portfolio::PositionIdent posIdent, char *extOpRefBuffer, int extOpRefBufferSize);

			/**
			@deprecated 4.5.2 buffer-overrun prone method 
			*/
			bool Get(portfolio::PositionIdent posIdent, char *extOpRefBuffer);

			/** Update the internal reference with this data.
			@return 0 if no internal reference and external reference.
			@since 5.2.3
			*/
			const char * GetInternal(portfolio::PositionIdent posIdent);	

			/** Retrieves a position matching to the given external operation reference
			*/
			portfolio::PositionIdent Get(const char * extOpRef) ;

			/**
			 * Retrieves list of positions corresponding to the given external operation reference
			 * @return true if at least one mvtident has been found, false else
			 * @since 5.3.3
			 */
			bool Get(const char * extOpRef, PositionIdents& mvtIdents);

			
			/**
			 * Retrieves list of positions corresponding to the given internal OR operation reference
			 * @return true if at least one mvtident has been found, false else
			 * @since 6.3.1.3
			 */
			bool Get(const char * extOpRef, PositionIdents& mvtIdents, bool internal);

			/* Update - Notifies to the cache that the External Operation Reference
			* of the specified position has changed. The cache map is updated accordingly.
			* @version 5.2.3 new parameter internal
			*/
			void Update(portfolio::PositionIdent posIdent, 
						const char *extOpRef, 
						bool internal = false);	// cache entry is updated with the new extOpRef value

			/* Change - Updates the cache and sends a RealTime coherency message
			* @version 5.2.3 new parameter internal
			*/
			void Change(portfolio::PositionIdent posIdent, 
			            const char *extOpRef, 
			            bool internal = false);

			/* Updates the extOpRef if the message already exists or creates a new one.
			* @param posIdent is the ident of the position.
			* @param extOpRef is the new name for the position.
			* @param messages is the list of messages to search posIdent and update with extOpRef.
			* @param overloadIfExisting is a flag, if true extOpRef overloads if there is already an ElemOpe message.
			* @version 5.3.6
			*/
			void SetExtOpRef(portfolio::PositionIdent posIdent, 
			                 const char *extOpRef, 
			                 sophis::tools::CSREventVector & messages, 
			                 bool overloadIfExisting = true);

			//Reload of table EXTERNAL_OP_REF on EORU event 
			void Load();

			bool IsLoaded() { return fLoaded;}
		private:
			/* fInstance - Pointer to the singleton instance of this class
			*/
			static CSRPositionExtOpRefCache *fInstance;

			struct name
			{
				char buffer[EXTOPREF_SIZE];
				char bufferInternal[EXTOPREF_SIZE];
			};
			typedef _STL::map<sophis::portfolio::PositionIdent, name> MapData;
			/* fCache - Map used as a cache container
			*/
			MapData fCache;


			mutable bool fLoaded;
		};

	}
}


SPH_EPILOG

/* ---------
------------------------------------------------------------- */


#endif // __CSRPOSITIONEXTOPREFCACHE_H
