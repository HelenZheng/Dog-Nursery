/*
 	File:		SphPostingAmountForTrade.h

 	Contains:	Base Class for different trade posting amounts.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphPostingAmountForTrade.h
	\brief Base Class for different trade posting amounts.
*/

#if (defined(WIN32)||defined(_WIN64))
#   pragma once
#endif

#ifndef _SPHPOSTINGAMOUNTFORTRADE_H_
#define _SPHPOSTINGAMOUNTFORTRADE_H_

#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(vector)

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphPostingAmountInfo.h"

#define DECLARATION_POSTING_AMOUNT_FOR_TRADE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRPostingAmountForTrade)
#define CONSTRUCTOR_POSTING_AMOUNT_FOR_TRADE(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_AMOUNT_FOR_TRADE(derivedClass)
#define	INITIALISE_POSTING_AMOUNT_FOR_TRADE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_kernel
	{
		/** Interface to create a posting amount from a trade.
		In the accounting engine or OTC engine, define an amount for a trade.
		You can implement this interface to add an amount on the list.
		The accounting trade engine, when finding a rule with an amount, will call 
		the method get_posting_amount to create the amount in the posting.
		The otc engine will call the same method to fill the amount field in the table bo_messages.
		@version 4.5.0 Standardisation using the prototype.
		@version 4.4.0 Used also for otc engine to define the amount in the message.
		@since 4.2.1
		*/
		class SOPHIS_BO_KERNEL CSRPostingAmountForTrade
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingAmountForTrade() {}

			/** Return the posting amount.
			@param trade is the transaction to get corresponding posting for which this amount is posted.
			@param currency is code of currency of amount for posting; the amount posted can be converted
			according the currency wanted in the accounting rule.
			@param third_party is code of third party of transaction; it is used to find the account in the chart.
			@param instrument is code of instrument for this posting; it is used to find the account in the chart.
			@returns amount for this posting.
			*/
			virtual double get_posting_amount(	const portfolio::CSRTransaction& trade,
												long* currency,
												long* third_party,
												long* instrument ) const = 0 ;

			/** Return the posting amount.
			@param trade is the transaction to get corresponding posting for which this amount is posted.
			@param currency is code of currency of amount for posting; the amount posted can be converted
			according the currency wanted in the accounting rule.
			@param third_party is code of third party of transaction; it is used to find the account in the chart.
			@param instrument is code of instrument for this posting; it is used to find the account in the chart.
			@param quantityCoeff: quantity of the posting will be multiplied by this value
			@returns amount for this posting.
			*/

			virtual double get_posting_amount(	const portfolio::CSRTransaction& trade,
												long* currency,
												long* third_party,
												long* instrument,
												double* quantityCoeff) const;
			/** Return the posting amount.
			@param trade is the transaction to get corresponding posting for which this amount is posted.
			@param amountInfo corresponds to the structure (currency, third_party, instrument, quantityCoeff, accounts and depositaries)
			@returns amount for this posting.
			*/
			virtual double get_posting_amount(	const portfolio::CSRTransaction& trade,
												TAccAmountInfoExt & amountInfo) const;
			
			/** Vector version of 'double get_posting_amount(...)' function
			*/
			virtual void get_posting_amount(const portfolio::CSRTransaction& trade
											,VTAccAmountInfo& amountInfo);

			/** Get the singleton for one amount.
			This is equivalent to CSRPostingAmountForTrade::GetPrototype().GetData(modelName).
			except that exception is caught to return 0 if the amount name is not found.
			@param amountName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingAmountForTrade* getInstance( const char* amountName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_AMOUNT_FOR_TRADE.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingAmountForTrade* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingAmountForTrade, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_AMOUNT_FOR_TRADE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			static const char* __CLASS__;
		} ;

	}
}
SPH_EPILOG
#endif //_SPHPOSTINGAMOUNTFORTRADE_H_
