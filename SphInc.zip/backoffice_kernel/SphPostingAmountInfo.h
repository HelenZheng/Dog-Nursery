/*
 	File:		SphPostingAmountInfo.h

 	Contains:	struct TAccAmountInfo definition

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphPostingAmountInfo.h
	\brief struct TAccAmountInfo definition used for amount calculation in TradeAccountingEngine and 
			in PnLAccountingEngine
*/

#if (defined(WIN32)||defined(_WIN64))
#   pragma once
#endif

#ifndef _SPHPOSTINGAMOUNTINFO_H_
#define _SPHPOSTINGAMOUNTINFO_H_

#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_kernel
	{

		/** Struct to handle amount info of the posting
		*/
		struct SOPHIS_BO_KERNEL TAccAmountInfo
		{
			double	amount;
			/**
			currency is code of currency of amount for posting; the amount posted can be converted
			according the currency wanted in the accounting rule.
			*/
            long	currency;
			/**
			third_party is code of third party of transaction; it is used to find the account in the chart.
			*/
			long	third_party;
			/**
			instrument is code of instrument for this posting; it is used to find the account in the chart.
			*/
			long	instrument;

			/**
			posting quantity will by multiplied by this value; default: 1
			*/
			double	quantityCoeff;

			/**
			date_lock determines if values should be taken as a difference of two values, the start value, or the end value
			used in Accounting Forecasting
			*/
			int date_lock;

			TAccAmountInfo();
			TAccAmountInfo(	double	i_posting_amount, long	i_currency,
							long	i_third_party, long	i_instrument, long i_quantityCoeff);
			TAccAmountInfo(	const TAccAmountInfo& aa_info);
			~TAccAmountInfo(){};
		};

		typedef _STL::vector< TAccAmountInfo>	VTAccAmountInfo;
		typedef VTAccAmountInfo::iterator		IVTAccAmountInfo;


		/** Struct to handle extended amount info of the posting
		*/
		struct SOPHIS_BO_KERNEL TAccAmountInfoExt : public TAccAmountInfo
		{
			/*
			The Nostro cash account id (SSI path)
			*/
			long	nostroAccount;
			/**
			The Lostro cash account id (SSI path)
			*/
            long	lostroAccount;
			/**
			The depository for the sender. 
			*/
			long	senderDepo;
			/**
			The depository for the receiver. 
			*/
			long	receiverDepo;

			/*
			The Nostro cash account id (SSI path) for the second leg, if it exists
			*/
			
			long	nostroAccount2;
			/**
			The Lostro cash account id (SSI path) for the second leg, if it exists
			*/
            long	lostroAccount2;

			/**
			The depository for the sender for the second leg, if it exists
			*/
			long	senderDepo2;

			/**
			The depository for the receiver for the second leg, if it exists
			*/
			long	receiverDepo2;

			/*
			The amount for the second leg
			*/
			double amount2;

			/*
			The currency for the second leg
			*/
			double currency2;

			TAccAmountInfoExt();
			TAccAmountInfoExt(double i_posting_amount, long	i_currency,
							long i_third_party, long i_instrument, long i_quantityCoeff,
							long i_nostroAccount, long i_lostroAccount, long i_senderDepo, long i_receiverDepo,	
							long i_nostroAccount2, long i_lostroAccount2, long i_senderDepo2, long i_receiverDepo2, 
							long i_currency2, double i_amount2);
			TAccAmountInfoExt(	const TAccAmountInfoExt& aa_infoExt);
			~TAccAmountInfoExt(){};
		};
	}
}
SPH_EPILOG
#endif // _SPHPOSTINGAMOUNTINFO_H_
