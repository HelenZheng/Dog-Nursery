/*
 	File:		SphPostingDate.h

 	Contains:	Base Class for different posting dates.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphPostingDate.h
	\brief Base Class for different posting dates
*/

#pragma once

#ifndef _SPH_POSTINGDATE_H_
#define _SPH_POSTINGDATE_H_


#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_POSTING_DATE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRPostingDate)
#define CONSTRUCTOR_POSTING_DATE(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_DATE(derivedClass)
#define	INITIALISE_POSTING_DATE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_kernel
	{

		/** Interface to create a posting date from a trade.
		In the accounting engine or OTC engine, define a date for a trade.
		You can implement this interface to add a date on the list.
		The accounting trade engine, when finding a rule with a date, will call 
		the method get_posting_amount to create the date in the posting.
		The otc engine will call the same method to fill the date field in the table bo_messages.
		@version 4.5.0 Standardisation using the prototype.
		@version 4.4.0 Used also for otc engine to define the amount in the message.
		@since 4.2.1
		*/
		class SOPHIS_BO_KERNEL CSRPostingDate
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingDate() {}

			/** Return posting date.
			@param trade  transaction to get corresponding posting date.
			@returns posting date for transaction.
			*/
			virtual long get_posting_date(const portfolio::CSRTransaction& trade) const = 0 ;

			/** Get the singleton for one amount.
			This is equivalent to CSRPostingDate::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the date name is not found.
			@param modelName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingDate* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_DATE.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingDate* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingDate, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_DATE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
}
SPH_EPILOG
#endif
