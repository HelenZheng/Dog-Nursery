/*
 	File:		SphPostingNostroAccountingSource.h

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphPostingNostroAccountingSource.h
	\brief Class to determine the nostro account source for transaction
*/

#pragma once

#ifndef _SPHPOSTINGNOSTROACCOUNTINGSOURCE_H_
#define _SPHPOSTINGNOSTROACCOUNTINGSOURCE_H_
#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

/** Macro defines Clone function for instantiating of derivedClass posting.
	@param derivedClass is the type of posting derived from CSRPostingNostroAccountingSource.
*/
#define DECLARATION_POSTING_NOSTRO_ACCOUNTING_SOURCE(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRPostingNostroAccountingSource)
#define CONSTRUCTOR_POSTING_NOSTRO_ACCOUNTING_SOURCE(derivedClass)
#define WITHOUT_CONSTRUCTOR_NOSTRO_ACCOUNTING_SOURCE(derivedClass)

/** macro used for installing the posting in Risk
	@param derivedClass is the type of posting derived from CSRPostingNostroAccountingSource
	@param name is the name of this posting which will be used to store it in 
	database and for building menu of all postings
*/
#define	INITIALISE_POSTING_NOSTRO_ACCOUNTING_SOURCE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_kernel
	{

		/** Interface to create a nostro accounting source selector.
		@since 6.0
		*/
		class SOPHIS_BO_KERNEL CSRPostingNostroAccountingSource
		{
		public:


			/** Trivial destructor.
			*/
			virtual ~CSRPostingNostroAccountingSource() {}

			/** 
			*/
			virtual int GetNostroAccountId(const portfolio::CSRTransaction& trade) const = 0 ;

			/** Get the singleton for one to do if date.
			This is equivalent to CSRPostingNostroAccountingSource::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the to do if name is not found.
			@param modelName is a C string for the to do if.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingNostroAccountingSource* getInstance( const char* modelName ) ;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_NOSTRO_ACCOUNTING_SOURCE.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingNostroAccountingSource* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingNostroAccountingSource
				,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_NOSTRO_ACCOUNTING_SOURCE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;
	}
}

SPH_EPILOG
#endif // _SPHPOSTINGNOSTROACCOUNTINGSOURCE_H_

