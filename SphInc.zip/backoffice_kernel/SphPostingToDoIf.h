/*
 	File:		SphPostingToDoIf.h

 	Contains:	Class to determine the necessity of ToDoIf posting for transaction.

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphPostingToDoIf.h
	\brief Class to determine the necessity of ToDoIf posting for transaction
*/

#pragma once

#ifndef _SPHPOSTINGTODOLF_H_
#define _SPHPOSTINGTODOLF_H_
#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG

/** Macro defines Clone function for instantiating of derivedClass posting.
	@param derivedClass is the type of posting derived from CSRPostingToDoIf.
*/
#define DECLARATION_POSTING_TO_DO_IF(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRPostingToDoIf)
#define CONSTRUCTOR_POSTING_TO_DO_IF(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_TO_DO_IF(derivedClass)

/** macro used for installing the posting in Risk
	@param derivedClass is the type of posting derived from CSRPostingToDoIf
	@param name is the name of this posting which will be used to store it in 
	database and for building menu of all postings
*/
#define	INITIALISE_POSTING_TO_DO_IF(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

/** Macro defines Clone function for instantiating of derivedClass posting.
	@param derivedClass is the type of posting derived from CSRPostingToDoIfPosition.
*/
#define DECLARATION_POSTING_TO_DO_IF_POSITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRPostingToDoIfPosition)

#define CONSTRUCTOR_POSTING_TO_DO_IF_POSITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_TO_DO_IF_POSITION(derivedClass)

/** Macro used for installing the posting in Risk.
	@param derivedClass is the type of posting derived from CSRPostingToDoIfPosition.
	@param name is the name of this posting which will be used to store it in 
	database and for building menu of all postings.
*/
#define	INITIALISE_POSTING_TO_DO_IF_POSITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)


namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
		class CSRPosition;
	}

	namespace backoffice_kernel
	{

		/** Interface to create a to do if condition in a simple trade or balance rule.
		In the accounting trade or balance engine, define a condition to apply simple rules.
		The difference with the {@link CSRRulesConditionTransaction} is that the condition applies to
		a rule as a group of posting to select the right rule to apply. That one applies to a single posting
		once the rule is selected to know if that amount has to be posted.
		You can implement this interface to add an to do if on the list.
		The accounting trade engine, when finding a rule with an amount, will call 
		the method to_do to know if the amount has to be posted once the amount and currency is calculated.
		The balance engine will call the same method for each account to transfer when the balance is calculated.
		@version 4.5.0 Used also for balance engine for forex balance engine.
		@see CSRRulesConditionTransaction
		@since 4.2.1
		*/
		class SOPHIS_BO_KERNEL CSRPostingToDoIf
		{
		public:


			/** Trivial destructor.
			*/
			virtual ~CSRPostingToDoIf() {}

			/** Filter to decide if ToDoIf posting should be applied to transaction.
			@param trade is transaction to analyze.
			@param amount is amount of posting.
			@param posting_currency is currency of amount.
			@param accounting_currency is currency of accounting entity.
			@param amount_currency is currency 'Currency Type' column in parameterisation screen.
			@returns true if posting has to be applied, otherwise - false.
			*/
			virtual bool to_do(	const portfolio::CSRTransaction& trade,
								double amount,
								long posting_currency,
								long accounting_currency,
								long amount_currency) const = 0 ;

			/** Get the singleton for one to do if date.
			This is equivalent to CSRPostingToDoIf::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the to do if name is not found.
			@param modelName is a C string for the to do if.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingToDoIf* getInstance( const char* modelName ) ;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_TO_DO_IF.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingToDoIf* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingToDoIf
				,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_TO_DO_IF.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

		/** Interface to create a to do if condition in a p&l rule.
		In the p&l engine, define a condition to apply simple rules.
		The difference with the {@link CSRRulesConditionPosition} is that the condition applies to
		a rule as a group of posting to select the right rule to apply. That one applies to a single posting
		once the rule is selected to know if that amount has to be posted.
		You can implement this interface to add a to do if on the list.
		The p&l engine, when finding a rule with an amount, will call 
		the method to_do to know if the amount has to be posted once the amount and currency is calculated.
		The balance engine will call the same method for each account to transfer when the balance is calculated.
		@version 4.5.0 Used also for balance engine for forex balance engine.
		@see CSRRulesConditionPosition
		@since 4.2.1
		*/
		class SOPHIS_BO_KERNEL CSRPostingToDoIfPosition
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingToDoIfPosition() {}

			/** filter to decide if ToDoIf posting should be applied to position
			@param position is position to analyze
			@param amount is amount of posting
			@param posting_currency is currency of amount
			@param accounting_currency is currency of accounting entity
			@param amount_currency is currency 'Currency Type' column in parameterisation screen
			@returns true if posting has to be applied, otherwise - false
			*/
			virtual bool to_do(	const portfolio::CSRPosition& position,
								double amount,
								long posting_currency,
								long accounting_currency,
								long amount_currency) const = 0 ;

			/** Get the singleton for one to fo if date.
			This is equivalent to CSRPostingToDoIf::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the to do if name is not found.
			@param modelName is a C string for the to do if.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingToDoIfPosition* getInstance( const char* modelName ) ;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_TO_DO_IF_POSITION.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingToDoIfPosition* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingToDoIfPosition
				,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_TO_DO_IF_POSITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;
	}
}

SPH_EPILOG

#endif // _SPH_POSTINGDATESETTLEMENT_H_

