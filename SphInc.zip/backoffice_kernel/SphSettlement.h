#ifndef _SPH_SETTLEMENT_H_
#define _SPH_SETTLEMENT_H_

#include "SphInc/backoffice_kernel/SphThirdParty.h"
#include "SphInc/backoffice_kernel/SphThirdPartyStruct.h"
#include "SphInc/backoffice_otc/SphBOEnums.h"
#include "SphInc/portfolio/SphTransactionEnums.h"

SPH_PROLOG

struct SSCellStyle;
union SSCellValue;

/// Internal
struct TLib;

namespace sophis
{
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRTransaction;
	}
	namespace treasury
	{
		/// Internal
		class ConditionValues;
	}
	namespace backoffice_kernel {
		/**
		 * Interface for fetching instrument parameters as quickly as possible.
		 * Abstracts the actual instrument implementation (via TLib or CSRInstrument).
		 * @version 6.3
		 */
		class ISRSettlementDealInstrument
		{
		public:
			virtual ~ISRSettlementDealInstrument() {}

			/// Returns currency information.
			virtual long GetCurrency() const = 0;

			/// Returns allotment information if it is available or 0 to indicate allotment information needs to be fetched.
			virtual long HasAllotment() const = 0;
			/// Returns allotment information; fetching allotment may be costly, one should use HasAllotment() first.
			virtual long GetAllotment() const = 0;

			/// Returns market information if it is available or 0 to indicate market information needs to be fetched.
			virtual long HasMarket() const = 0;
			/// Returns market information; fetching market may be costly, one should use HasMarket() first.
			virtual long GetMarket() const = 0;

			/// Returns underlying currency information.
			virtual long GetUnderlyingCurrency() const = 0;

			/// Returns underlying allotment information if it is available or 0 to indicate underlying underlying allotment information needs to be fetched.
			virtual long HasUnderlyingAllotment() const = 0;
			/// Returns underlying allotment information; fetching underlying allotment may be costly, one should use HasUnderlyingAllotment() first.
			virtual long GetUnderlyingAllotment() const = 0;

			/// Returns underlying market information if it is available or 0 to indicate underlying market information needs to be fetched.
			virtual long HasUnderlyingMarket() const = 0;
			/// Returns underlying market information; fetching underlying market may be costly, one should use HasUnderlyingMarket() first.
			virtual long GetUnderlyingMarket() const = 0;

			/// Returns if given instrument is a special Nostro Account movement instrument.
			virtual bool IsNostroAccount(long& nostroAccount, long& lostroAccount) const = 0;

			/// Returns instrument object, if applicable.
			virtual const instrument::CSRInstrument* GetInstrument() const = 0;
		};

		/**
		 * Utility class to help create common implementations of ISRSettlementDealInstrument.
		 * @version 6.3
		 */
		class SOPHIS_FIT CSRSettlementDealInstrumentFactory
		{
		private:
			CSRSettlementDealInstrumentFactory() {}
		public:
			/** Returned pointer must be deleted. */
			static ISRSettlementDealInstrument* NewSettlementDealInstrument(long sicovam);
			/** Returned pointer must be deleted. */
			static ISRSettlementDealInstrument* NewSettlementDealInstrument(const TLib& ph);
			/** Returned pointer must be deleted. */
			static ISRSettlementDealInstrument* NewSettlementDealInstrument(const instrument::CSRInstrument& instr);
			/** Returned pointer must be deleted. */
			static ISRSettlementDealInstrument* NewSettlementDealInstrument(const portfolio::CSRTransaction& transaction);
		};

		/**
		 * Interface for minimal stuff required to pass deal via SSI.
		 * Should be used with either ConditionValues or CSRTransaction.
		 * @version 6.3
		 */
		class ISRSettlementDealInput
		{
		public:
			virtual ~ISRSettlementDealInput() {}

			virtual long GetCounterparty() const = 0;
			virtual long GetDepositary() const = 0;
			virtual long GetEntity() const = 0;
			virtual long GetPaymentMethod() const = 0;
			virtual eMessageSign GetSignOfQuantity() const = 0;
			virtual long GetSettlementCurrency() const = 0;
			virtual long GetTransactionType() const = 0;
			virtual long GetSettlementDate() const = 0;
			virtual long GetPortfolioID() const = 0;
			virtual long GetDeliveryType() const = 0;
			virtual long GetWorkflowId() const = 0;

			/// This should indicate type of account we're looking for, both, cash, or instrument
			virtual long GetAccountType() const = 0;

			/// This should indicate type of role for SSI lookup (like counterparty or entity)
			virtual long GetPartyRole() const = 0;
		};

		/**
		 * Structure for storing SM/DT (settlement method, delivery type) pair.
		 */
		struct SOPHIS_FIT SMDT
		{
			/** Trivial Constructor. */
			SMDT() 
				: fWorkflowID(0)
				, fDeliveryTypeID(sophis::portfolio::bdtNA)
			  {
			  }

			/** Constructor with given data. */
			SMDT(long workflowID, sophis::portfolio::eBODeliveryType deliveryTypeID)
				: fWorkflowID(workflowID)
				, fDeliveryTypeID(deliveryTypeID)
			{
			}

			/** Equal operator. */
			bool operator== (const SMDT& smdt) const
			{
				return ((fWorkflowID == smdt.fWorkflowID) &&
					(fDeliveryTypeID == smdt.fDeliveryTypeID));
			}

			/** Settlement workflow (method) id. */
			long fWorkflowID;
			/** Delivery type. */
			sophis::portfolio::eBODeliveryType fDeliveryTypeID;			
		};

		/**
		 * Structure for storing SM/DT/PM (settlement method, delivery type, payment method) lookup.
		 * It it used as part of GetSMDTs() method.
		 */
		struct SOPHIS_FIT SettlementResult
		{
			/** Constructor, empty payment methods. */
			SettlementResult(const _STL::string& displayName, long workflowID, sophis::portfolio::eBODeliveryType deliveryTypeID)
				: fDisplayName (displayName)
				, fSMDT (workflowID, deliveryTypeID)
			{
			}

			/** Copy Constructor */
			SettlementResult(const SettlementResult& sr)
				: fDisplayName(sr.fDisplayName),
				fSMDT(sr.fSMDT.fWorkflowID, sr.fSMDT.fDeliveryTypeID),
				fPaymentMethod(sr.fPaymentMethod),
				fSILineID(sr.fSILineID)
			{
			}

			/** Equal operator (internal) only cheks for SM/DT, not PM */
			bool operator== (const SettlementResult& sr) const
			{
				return (fSMDT == sr.fSMDT);
			}

			/** SM/DT display name (for menus, etc.) */
			_STL::string fDisplayName;
			/** SM/DT value pair */
			SMDT fSMDT;

			/** Payment method list from counterparty that corresponds to given SM/DT. */
			_STL::vector<long> fPaymentMethod;
			/** Settlement instruction (SSI) line ids corresponding to the selected lines in which the payment method was chosen from.
			 * There is a direct one to one correlation between fPaymentMethod and fSILineID index info. */
			_STL::vector<long> fSILineID;
		};

		/**
		 * Collection of utilities for working with settlement rules.
		 * Utilities include SSI lookup for one or all matching lines, SM/DT fetching, etc.
		 *
		 * SM/DT/PM = settlement method (settlement workflow), delivery type (N/A, DVP or FOP), payment method.
		 *
		 * Implementation uses internal caching where possible.
		 *
		 * @version 6.3
		 */
		class SOPHIS_FIT CSRSettlementDataCache
		{
		private:
			CSRSettlementDataCache() {}
		public:
			/** Alternative (faster) way of calling CSRThirdparty::GetSettlementLinksFullFilter().
			 * Perform SSI lookup against given third party and input (filter) parameters. */
			static bool GetSettlementLinksFullFilter(long thirdId,
				const SettlementLinksFullFilterCriteria& linksCriteria, SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Generic method of performing SSI lookup against given third party and input (filter) parameters. */
			static bool GetSettlementList(long thirdId, 
				const ISRSettlementDealInput& deal, const ISRSettlementDealInstrument& instr,
				const ISRSsiLinksTkCriteria* tkCriteria, SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Internal. Entity SSI lookup for all matching lines (specific to Nostro engine). */
			static bool GetNostroSettlementList(const ISRSettlementDealInput& deal, const ISRSettlementDealInstrument& instr,
				const treasury::ConditionValues& conditionValues, const portfolio::CSRTransaction* transaction,
				SSThirdPartySettlementPtrList& resultList);

			/** Internal. Entity SSI lookup for the first matching line (specific to Nostro engine). */
			static bool GetNostroSettlementList(const ISRSettlementDealInput& deal, const ISRSettlementDealInstrument& instr,
				const treasury::ConditionValues& conditionValues, const portfolio::CSRTransaction* transaction,
				SSThirdPartySettlementPtr& result);

			/** Entity SSI lookup for all (or first) matching lines for the cash or both accounts.
			 * Depositary is used in the filtering; SM/DT/PM are not used in the filtering unless in case of DVP.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetNostroCashSettlementList(const portfolio::CSRTransaction& trans,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Entity SSI lookup for all (or first) matching lines for the specified or any account type.
			 * This method should be used to pull securities or both or any accounts.
			 * @param accountType type of account (CSRThirdParty::eAccountType) or 0 means any type.
			 * Depositary, settlement method, delivery type, payment method are all used in the filtering.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetNostroAnySettlementList(const portfolio::CSRTransaction& trans, long accountType,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Entity SSI lookup for all (or first) matching lines for the securities or both accounts.
			 * Redirects call to GetNostroAnySettlementList().
			 * Depositary, settlement method, delivery type, payment method are all used in the filtering.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetNostroSecuritiesSettlementList(const portfolio::CSRTransaction& trans,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult)
			{
				return GetNostroAnySettlementList(trans, CSRThirdParty::atInstrument, instr, resultList, onlyFirstResult);
			}

			/** Counterparty SSI lookup for all matching lines for the cash or both accounts.
			 * Depositary of counterparty or depositary is used; SM/DT/PM are not used in the filtering unless its a DVP.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetLostroCashSettlementList(const portfolio::CSRTransaction& trans,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Counterparty SSI lookup for all matching lines for the specified or any account type.
			 * @param accountType type of account (CSRThirdParty::eAccountType) or 0 means any type.
			 * Depositary of counterparty or depository is used; SM/DT/PM are also used in the filtering.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetLostroAnySettlementList(const portfolio::CSRTransaction& trans, long accountType,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult);

			/** Counterparty SSI lookup for all matching lines for the securities or both accounts.
			 * Redirects call to GetLostroAnySettlementList().
			 * Depositary of counterparty or depositary, SM/DT/PM are all used in the filtering.
			 * Instrument is optional and should be used for new (non-existent) or in-memory instruments. */
			static bool GetLostroSecuritiesSettlementList(const portfolio::CSRTransaction& trans,
				const instrument::CSRInstrument* instr,	SSThirdPartySettlementPtrList& resultList,
				bool onlyFirstResult)
			{
				return GetLostroAnySettlementList(trans, CSRThirdParty::atInstrument, instr, resultList, onlyFirstResult);
			}

			/** Obtain valid SM/DT/PM (settlement method, delivery type, payment method) combinations for given transaction.
			 * Instrument is optional and should be used when instrument only exists in memory (like new contract booking). */
			static void GetSMDTs(const portfolio::CSRTransaction& trans, const instrument::CSRInstrument* instr, _STL::vector<SettlementResult>& resultList);

			/** Populate cell (display) information with specified part of Nostro or Lostro account (securities or cash)
			 * from given transaction.
			 * @param trans Transaction.
			 * @param instr Instrument is optional and should be used when instrument only exists in memory.
			 * @param nostroLostroType Type of account sought (see {@link sophis::portfolio::eNostroLostroType}).
			 * @param columnType Element of settlement to display (see {@link sophis::backoffice_kernel::eSettlementListColumns}).
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type. */
			static bool GetNostroLostroCell(const portfolio::CSRTransaction& trans,
				const instrument::CSRInstrument* instr,
				long nostroLostroType,
				long columnType,
				SSCellValue *value, SSCellStyle *style);

			/** Populate cell (display) information with specified part of Nostro or Lostro account (securities or cash)
			 * from given settlement path object.
			 * @param ssiPath Settlement path object.
			 * @param columnType Element of settlement to display (see {@link sophis::backoffice_kernel::eSettlementListColumns}).
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type. */
			static bool GetNostroLostroCell(const SSThirdPartySettlementPath& ssiPath,
				long columnType,
				SSCellValue *value, SSCellStyle *style);

			/** Populate cell (display) information with specified part of Nostro or Lostro account (securities or cash)
			 * from given settlement path information.
			 * @param ssiPathId Settlement path id.
			 * @param columnType Element of settlement to display (see {@link sophis::backoffice_kernel::eSettlementListColumns}).
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type. */
			static bool GetNostroLostroCell(long ssiPathId,
				long columnType,
				SSCellValue *value, SSCellStyle *style);
		};

		/**
		 * Class to work with SSI lookup for Nostro, creates a bridge between SQL conditions
		 * inside CSRSettlementRulesCondition and C++ conditions based on ISRSsiLinksTkCriteria.
		 *
		 * Used inside CSRSettlementDataCache::GetNostroSettlementList().
		 * The custom generated ISRSsiLinksTkCriteria object will be passed 
		 * insde CSRSettlementRulesCondition::checkCondition().
		 * 
		 * @version 6.3.0
		 */
		class SOPHIS_FIT ISRNostroSettlementCondition
		{
		public:
			/**
			 * Must generate new custom ISRSsiLinksTkCriteria from the input data.
			 * The returned object will the be passed to CSRSettlementRulesCondition::checkCondition().
			 * The returned object will be destroyed by the API after the call.
			 * @param deal Minimal stuff fetched from the DB required to pass deal via SSI.
			 * @param instr Instrument information.
			 * @param conditionValued Condition values obtained via SQL (internal).
			 */
			virtual ISRSsiLinksTkCriteria* new_SsiLinksTkCriteria(
				const ISRSettlementDealInput& deal
				, const ISRSettlementDealInstrument& instr
				, const treasury::ConditionValues& conditionValues
				) const = 0;

			/**
			 * Registers the provided implementation of the SSI lookup for Nostro.
			 * Note the provided reference is used and therefore must not be destroyed.
			 * @param nostroSettlementConditionImpl Implementation class.
			 */
			static void SetNostroSettlementConditionImpl(const ISRNostroSettlementCondition* nostroSettlementConditionImpl);

			/**
			 * Returns the registered implementation of the SSI lookup for Nostro,
			 * or null pointer if nothing has been registered.
			 */
			static const ISRNostroSettlementCondition* GetNostroSettlementConditionImpl();
		};

	}
}

SPH_EPILOG

#endif
