/*! \file SphThirdParty.h
\brief Handling third parties.
*/

#ifndef _CSRThirdParty_H_
#define _CSRThirdParty_H_

#include "SphInc\backoffice_kernel\SphThirdPartyStruct.h"
#include "SphInc/SphMacros.h"
#include "SphTools/sphvector.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#include "SphInc/portfolio/SphTransactionEnums.h"
#include "SphInc/portfolio/SphTransaction.h"
#include "SphInc/tools/SphValidation.h"


#include __STL_INCLUDE_PATH(vector)



SPH_PROLOG

const int	kThirdPartyDialogId=902;
const int	kThirdPartyDialogElemCount=19;

#define DECLARATION_THIRD_PARTY(derivedClass)			DECLARATION_DERIVE_AVEC_PARAM(derivedClass, SSThirdParty)
#define CONSTRUCTOR_THIRD_PARTY(derivedClass)			CONSTRUCTEUR_DERIVE_AVEC_PARAM(derivedClass, CSRThirdParty, SSThirdParty)
#define WITHOUT_CONSTRUCTOR_THIRD_PARTY(derivedClass)	SANS_CONSTRUCTEUR_DERIVE_AVEC_PARAM(derivedClass, SSThirdParty)

struct	SSThirdParty;	// internal
class	CSTiers;		// internal
class   CSWindow;		// internal


namespace sophis
{
	namespace gui
	{
		class	CSRDatabaseDialog;
		class	CSRFitDialog;
	}
	namespace portfolio
	{
		class	CSRTransaction;
	}
	namespace instrument
	{
		class	CSRInstrument;
	}
	namespace tools
	{
		namespace dataModel
		{
			class Data;
			class DataSet;
			class DataModelException;
		}
	}
};

enum eBankType 
{
	bCustodian,
	bInvestment,
	bMerchant,
	bSavings
};

enum eConfirmationMethodType 
{
	cmEMail = 1,
	cmTelex,
	cmFax
};

struct SSRoutingCode 
{
	char Code[41];
};

enum ePaymentMethodType 
{
	pmTelex = 1,
	pmSwift,
	pmCheque,
	pmChaps
};

namespace sophis 
{
	namespace gui
	{
		class CSREditList;
	}
}

namespace sophis {
	namespace backoffice_kernel {

		struct SOPHIS_FIT SettlementLink
		{
			enum eSettlementLink{
				LENGTH = 40
			};
			char intermed0[LENGTH];	//for lostro1/nostro1 (e.g. swift)
			char intermed1[LENGTH];
			char intermed2[LENGTH];
			char intermed1_account[LENGTH];
			char intermed2_account[LENGTH];
			long id3rd;				//3rd party ID, needed to perform cache update based on this ID
			long paymentMethod;
			long row;
			long siLineId;	//5.2.4 onwards - settlement instruction line id
			long placeOfSettlement; //5.2.4 onwards - id of place of settlment
			long depositary;//5.2.6 onwards - id of the depositary
			long workflowId;
			long treasuryAccount;//5.3.2 onwards - name of the treasury account
			long SSIPath; //7.0 onwards - the SSI path of the settlement instruction
			sophis::portfolio::eBODeliveryType deliveryType;
			SettlementLink();
			SettlementLink( char *i1, char*i2, char *i1a, char *i2a, char* i0, long id3, long ta = 0, long pm=0, long r=-1, long pset = 0, long depo = 0, long sli = 0,
				long sm = -1, sophis::portfolio::eBODeliveryType dt = sophis::portfolio::bdtNA );
			SettlementLink( SettlementLink& sl);
			SettlementLink(SSThirdPartySettlementPtr&);
			SettlementLink& operator=(const SettlementLink&);
			bool IsValid();
			friend SOPHIS_FIT bool operator==( const SettlementLink& s1, const SettlementLink& s2);		    
		};

		struct SettlementLinksFullFilterCriteria;
		struct SettlementLinksLOSTROFilterCriteria;
		struct SettlementLinksNOSTROFilterCriteria;

		/** Exception thrown by the method Find when no party matches the given criteria
		@see CSRThirdParty
		*/
		class SOPHIS_FIT NoSuchPartyException : public sophisTools::base::ExceptionBase
		{
		public:
			NoSuchPartyException(const char * details);
			NoSuchPartyException();
		};

		/** Exception thrown by the method Create when an existing party is already defined with the same identifiers
		@see CSRThirdParty
		*/
		class SOPHIS_FIT DuplicatePartyException : public sophisTools::base::ExceptionBase
		{
		public:
			DuplicatePartyException(const char * details);
			DuplicatePartyException();
		};


		class SOPHIS_FIT CSRThirdParty
		{
		public:
			enum	eMsgRoleInSettlement
			{
				mrsAll = 1,
				msrCounterpart,
				msrBroker,
				msrDepositary,
				msrEntity,
				msrCounterpart2
			};

			enum eMsgDestinationCode
			{
				COUNTERPART1 = 1,
				COUNTERPART2,
				BROKER,
				DEPOSIT,
				INTERNAL,
				PREPAYMENT_ADVICE
			};

			/**Enum for the Account Type menu in the Settlement Instructions list
			@version 4.5.2
			*/
			enum eAccountType
			{
				atBoth = 1,
				atInstrument,
				atCash
			};
			typedef _STL::vector<eAccountType> VeAccountType;
			typedef VeAccountType::iterator    IVeAccountType;
			typedef VeAccountType::const_iterator    KIVeAccountType;

		public:

			/** This ctor is used when working via the API
			*  to create new thirdparties
			*/
			CSRThirdParty();
			CSRThirdParty(long thirdPartyID);
			CSRThirdParty(const CSRThirdParty& rhs);

			bool operator== (const CSRThirdParty& rhs) const;
			bool operator!= (const CSRThirdParty& rhs) const;
			bool operator== (long ThirdPartyID) const;
			bool operator!= (long ThirdPartyID) const;
			bool IsValid() const;
			bool operator ! () const;
			CSRThirdParty& operator=(const CSRThirdParty& rhs);
			CSRThirdParty& operator=(const long thirparty_id);

			virtual ~CSRThirdParty();

			/**Retrieves the ID of the third party.
			@return	the id of the third party.
			@version 4.5.2
			*/
			long	GetIdent() const;

			/**
			* Reserve the code for a new thirdparty (which is different than setCode())
			* After a call to reserveCode() the ThirdParty is still considered as a
			* 'new' one.
			* This is useful when the ident has to be set just after thirparty
			* creation, and not when it is saved.
			* @param	code code to reserve when the thirdparty will be saved
			* @throw	InvalidInvocationOrder if the thirparty is not a new one, but an existing one.
			*/
			void	reserveCode(long code);
			
			/**Retrieves the parent third party (if there is one) in the event of a group.
			@return	the id of the parent group (or 0 if there is no parent defined)
			@version 4.5.2
			*/
			long	GetHolding() const;

			/**Retrieves the parent third party as a pointer to a CSRThirdParty
			@return	the the actual third party (if it exists)
			@version 4.5.2
			*/
			const CSRThirdParty GetParent() const;

			/**
			*
			*/
			void SetParent(long ident);

			/**Retrieves the reference of the third party
			@param	reference will be where the reference of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetReference(char *reference) const;

			/**Retrieves the external reference of the third party
			@param	externalReference will be where the external reference of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetExternalReference(char *externalReference) const;

			/**Retrieves the name of the third party
			@param	name will be where the external name of the Third Party will be stored.
			* The buffer must be at least 40 bytes long. The name returned is truncated to 39 characters.
			* GetFullName() should be used to get untruncated name.
			@version 4.5.2
			@version 6.3 now returns std::string
			*/
			_STL::string GetName() const;

			/**Retrieves the name of the third party
			@version 6.2.1
			@returns external name of the Third Party
			*/
			//_STL::string	GetFullName() const;

			/**Retrieves the legal name of the third party
			@param	name will the Legal name of the Third Party.
			@version 6.0.1
			*/
			void	GetLegalName(char *name) const;

			/**Retrieves the comment information associated with the third party
			@param	infos will be where the comment information of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetComment(char *infos) const;

			/**Retrieves the internal code of the share issued by the Third Party.
			@return	0 if no such association has been defined.
			@version 4.5.2
			*/
			long	GetIssuedShareCode() const;


			inline bool IsAccessibleByUser() const;

			/** Returns the Institution Type of the third party
			@version 7.1
			*/
			int		GetInstitutionType() const;

			/**Determines whether or not the third party is a parent group.
			@return	true if the third party is a parent group.
			@version 4.5.2
			*/
			bool	IsAGroup(void) const;

			/**Determines whether or not the third party is a counterparty
			@return	true if the third party is a counterparty.
			@version 4.5.2
			*/
			bool	IsACounterparty(void) const;

			/**Determines whether or not the third party is a boker
			@return	true if the third party is a broker.
			@version 4.5.2
			*/
			bool	IsABroker(void) const;

			/**Determines whether or not the third party is a depositary.
			@return	true if the third party is a depositary.
			@version 4.5.2
			*/
			bool	IsADepositary(void) const;

			/**Determines whether or not the third party is a customer/client.
			@return	true if the third party is a customer/client.
			@version 4.5.2
			*/
			bool	IsACustomer(void) const;

			/**Determines whether or not the third party is an entity.
			@return	true if the third party is an entity.
			@version 4.5.2
			*/
			bool	IsEntity() const;

			/**Determines whether or not the third party is a bank.
			@return	true if the third party is a bank.
			@version 4.5.2
			*/
			bool	IsABank(void) const;

			/**Determines whether or not the third party is a Corporate.
			@return	true if the third party is a corporate.
			@version 4.5.2
			*/
			bool	IsACorporate(void) const;

			/**Determines whether or not the third party is an Exchange.
			@return	true if the third party is an Exchange.
			@version 4.5.2
			*/
			bool	IsAnExchange(void) const;

			/**Determines whether or not the third party is an Institution.
			@return	true if the third party is an Institution.
			@version 4.5.2
			*/
			bool	IsASupranational(void) const;

			/**Determines whether or not the third party is of another different form.
			@return	true if the third party is of another different form.
			@version 4.5.2
			*/
			bool	IsAnother(void) const;

			/**Determines whether or not the third party is an investment bank
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool IsAInvestmentBank(void) const;

			/**Determines whether or not the third party is a merchant
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool IsAMerchant(void) const;

			/**Determines whether or not the third party is a savings bank
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool IsASavingsBank(void) const;

			/**Determines whether or not the third party is of a custodian
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool IsACustodian(void) const;

			/**Determines whether or not the third party is a PSET (Place of Settlement).
			@return	true if the third party is a PSET.
			@version 5.2.4
			*/
			bool	IsAPSET(void) const;

			/**Determines whether or not the third party is a Clearing House
			@return	true if the third party is a Clearing House.
			@version 7.1.0
			*/
			bool	IsAClearingHouse(void) const;

			/**Determines whether or not the third party is a Clearing Member
			@return	true if the third party is a Clearing Member.
			@version 7.1.0
			*/
			bool	IsAClearingMember(void) const;

			bool IsActif(long thirdPartyType) const;

			bool SetAccessibilityByUser(bool bAccessible);

			/**Retrieves the loaction of the third party.
			@param	buffer is where the the location string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetLocation(char *buffer, int size=0) const;

			/**Retrieves the domicile of the third party.
			@param	buffer is where the the domicile string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetDomicile(char *buffer, int size=0) const;

			/**Retrieves the language of the third party.
			@param	buffer is where the the language string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetLanguage(char *buffer, int size=0) const;

			eBankType		GetBankType() const;

			/**Determines whether or not the third party is a Custodian Bank.
			@return	true if the third party is a Custodian Bank.
			@version 4.5.2
			*/
			bool			GetCustodian() const;

			/**Determines whether or not the third party is an Investment Bank.
			@return	true if the third party is an Investment Bank.
			@version 4.5.2
			*/
			bool			GetInvestment() const;

			/**Determines whether or not the third party is a Merchant Bank.
			@return	true if the third party is a Merchant Bank.
			@version 4.5.2
			*/
			bool			GetMerchant() const;

			/**Determines whether or not the third party is a Savings Bank.
			@return	true if the third party is a Savings Bank.
			@version 4.5.2
			*/
			bool			GetSavings() const;

			/**Determines whether or not the Market Tax flag is set or not.
			@return	true if Market tax is set.
			@version 4.5.2
			*/
			bool			GetMarketTax() const;

			/**Determines whether or not the Gross price flag is set or not.
			@return	true if Gross price is set.
			@version 4.5.2
			*/
			bool			GetGrossPrice() const;

			/**Determines whether or not the Avergage price flag is set or not.
			@return	true if Average price is set.
			@version 4.5.2
			*/
			bool			GetAveragePrice() const;


			bool			GetPropertyList(SSThirdPartyPropertyIter& start, SSThirdPartyPropertyIter& end) const;

			/**Retrieves a given Property from the third party's list of properties.
			@param	property the name of the property that is to be retrieved.
			@param	buffer is where the value of the property is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetProperty(const char *property, char *buffer, int size=0) const;
			
			/**Set the value of a given Property from the third party's list of properties.
			@param	property the name of the property that is to be retrieved.
			@param	value is the value of the property to store.
			@version 6.2
			*/
			void			SetProperty(const char *property, char *value);

			/**Retrieves the Short Code of the third party.
			@param	buffer is where the the short code string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetShortCode(char *buffer, int size=0) const;

			/**Retrieves the ISIN Code of the third party.
			@param	buffer is where the the ISIN code string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetISINCode(char *buffer, int size=0) const;

			/** Retrieves the Swift Code of the third party. Calls GetThirdTabList using the boolean toLoad
			@param	buffer is where the the swift code string is stored.
			@param	size specify here what size the buffer should be.
			@param	toLoad indicates if we're coming from the GUI or not
			@see GetThirdTabList
			@version 4.5.2
			*/
			void			GetSwiftCode(char *buffer, int size=0) const;

			/**Retrieves the Phone number of the third party.
			@param	buffer is where the the phone number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetPhoneNumber(char *buffer, int size=0) const;

			/**Retrieves the Fax number of the third party.
			@param	buffer is where the the fax number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetFaxNumber(char *buffer, int size=0) const;

			/**Retrieves the Telex number of the third party.
			@param	buffer is where the the telex number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetTelexNumber(char *buffer, int size=0) const;

			/**Retrieves the E-mail of the third party.
			@param	buffer is where the the E-mail string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetEmail(char *buffer, int size=0) const;

			/**Retrieves the first line of the address of the third party.
			@param	buffer is where the the addresses first line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress1(char *buffer, int size=0) const;

			/**Retrieves the second line of the address of the third party.
			@param	buffer is where the the addresses second line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress2(char *buffer, int size=0) const;

			/**Retrieves the third line of the address of the third party.
			@param	buffer is where the the addresses third line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress3(char *buffer, int size=0) const;

			/**Retrieves the fourth line of the address of the third party.
			@param	buffer is where the the addresses fourth line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress4(char *buffer, int size=0) const;

			/**Retrieves the fifth line of the address of the third party.
			@param	buffer is where the the addresses fifth line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress5(char *buffer, int size=0) const;

			/**Retrieves the list of contacts defined for the Third party.
			@return	a CSREditList of the contacts that are defined.
			@version 4.5.2
			*/
			bool			GetContactList(SSThirdPartyContactIter& start, SSThirdPartyContactIter& end) const;

			/**Given the title this function returns the Name of a contact.
			@param	title the title of the contact to be retrieved
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContact(const char *title, char *buffer, int size=0) const;

			/**Given the title this function returns the phone number of a contact.
			@param	title the phone number of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactPhone(const char *title, char *buffer, int size=0) const;

			/**Given the title this function returns the fax number of a contact.
			@param	title the fax number of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactFax(const char *title, char *buffer, int size=0) const;

			/**Given the title this function returns the email address of a contact.
			@param	title the email address of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactEmail(const char *title, char *buffer, int size=0) const;

			/** Returns id of site assigned to third party.
			Ids and names of sites are stored in CPTYSITEMENU table
			@version 5.2
			*/
			long GetSite() const;

			void			GetSettlementInstructionList(SSThirdPartySettlementIter& start, SSThirdPartySettlementIter& end) const;

			SSThirdPartySettlementPtr	LoadSettlementLine(long iIndex) const;
			/**Gets the swift code assigned to the third party in the Address tab of the Third party dialog.
			It should be noted that the returned character array is a dynamically allocated character array,
			and should be deleted by the caller when finished with to avoid memory leaks.
			Alternatively, call GetSWIFT(char *), passing in an appropriatly sized character array.
			@return the swift code of the third party
			*/
			char*			GetSWIFT(void) const;

			/*Gets the swift code assigned to the third party in the Address tab of the Third party dialog.
			@param swift is the output parameter which will contain the swift code
			*/
			void			GetSWIFT(char *swift) const; 

		public:
			/**Retrieves the document generation list defined for the Third party.
			@return	a CSREditList of the possible document generations that are defined.
			@version 4.5.2
			*/
			void			GetDocumentationGenerationList(SSThirdPartyConfirmationIter&start, SSThirdPartyConfirmationIter&end) const;

			/**Retrieves the first Document to be generated that matches the criteria
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the settlement insructions.
			@param	event if not -1 then this much match the Business Event column for the document generation
			@param	currency the currency of the document that we wish to find a match for.
			@param	lineNum returns the line number (0....n) if an instruction is found that matches the criteria. 
			@param	msg_code this is the criteria for Recipient Type.
			@return	true is returned if a matching document generation is found.
			@version 4.5.2
			*/
			SSThirdPartyConfirmationPtr		GetFirstConfirmation(long thirdPartyId, int allotment, short event, long currency, int msg_code = -1) const;

			/**Retrieves the Contact name for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	buffer is where the name will be stored on returning.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetConfirmationContactName(long thirdPartyId, int allotment, long currency, char *buffer, int size=0) const;

			/**Retrieves the means by which the confirmation is to be sent.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	msg_code this is the criteria for Recipient Type.
			@return	returns Fax, Email or Telex.
			@version 4.5.2
			*/
			eConfirmationMethodType		GetConfirmationMethod(long thirdPartyId, int allotment, long currency, int msg_code = -1) const;

			/**Retrieves the Confirmation Address for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	buffer is where the name will be stored on returning.
			@param	size specify here what size the buffer should be.
			@param	msg_code this is the criteria for Recipient Type.
			@version 4.5.2
			*/
			void			GetConfirmationAddress(long thirdPartyId, int allotment, long currency, char *buffer, int size, int msg_code) const;

			/**Retrieves the Template name for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	event the Business Event for the document to be generated.
			@param	currency the currency of the document that we wish to find a match for.
			@return the template id if a matched confirmation if found
			@version 4.5.2
			*/
			long			GetConfirmationTemplate(long thirdPartyId, int allotment, short event, long currency) const;

			/**Retrieves the number of Document Generation rows
			~version 7.1
			*/
			int				GetDocumentGenerationListCount() const;

			/**Retrieves the agreements list defined for the Third party.
			@return	a CSREditList of the agreements list that is defined.
			@version 4.5.2
			*/
			void	GetAgreementsList(SSThirdPartyAgreementIter& start, SSThirdPartyAgreementIter& end) const;

			/**Retrieves the first Agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	lineNum returns the line number (0....n) if an agreement is found that matches the criteria. 
			@return	first Agreement that matches the criteria.
			@version 4.5.2
			*/
			SSThirdPartyAgreementPtr GetFirstAgreement(int allotment) const;

			/**Retrieves the Agreement value from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the agreement is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreement(int allotment, char *buffer, int size) const;

			/**Returns the Agreement version from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the version of the agreement.
			@version 4.5.2
			*/
			long			GetAgreementVers(int allotment) const;

			/**Retrieves the Law from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the law is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementLaw(int allotment, char *buffer, int size=0) const;

			/**Returns the Effectiveness Date from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the date in long format.
			@version 4.5.2
			*/
			long			GetAgreementEffectivenessDate(int allotment) const;

			/**Returns the Ammendment Date from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the date in long format.
			@version 4.5.2
			*/
			long			GetAgreementAmendmentDate(int allotment) const;

			/**Gets the Termination Currency from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the ID of the currency is returned.
			@version 4.5.2
			*/
			long			GetAgreementTerminationCurrency(int allotment) const;

			/**Retrieves the Contact name from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the name is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactName(int allotment, char *buffer, int size=0) const;

			/**Retrieves the Contact phone number from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the phone number is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactPhone(int allotment, char *buffer, int size=0) const;

			/**Retrieves the Contact fax number from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the fax number is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactFax(int allotment, char *buffer, int size=0) const;

			/**Retrieves the Termination Comment from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the comment is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementTerminationComment(int allotment, char *buffer, int size=0) const;

			/**Retieves the row number of the chosen agreement given the allotment, currency and sender
			@param	allotment is the allotment to search for in the agreements.
			@param	currency is the currency to search for in the list of agreements.
			@param	entity the ID of the third party that is the sender.
			@return	the row number is returned (0....n)
			@version 4.5.2
			*/
			long			GetAgreementRow(int allotment, long currency, long entity) const;

			/**Retrieves the Note for the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the note is stored here on returning.
			@param	size the size the buffer should be.
			@version 4.5.2
			*/
			void			GetAgreementNote(int allotment, char *buffer, int size=0) const;

			/**Retrieves the Credit Details for the first agreement matched.
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the details are stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementCreditDetails(int allotment, char *buffer, int size=0) const;

			/**Retrieves the name of the Credit Document for the first agreement matched.
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the name of the document is stored here on returning.
			@param	size set the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementCreditDocument(int allotment, char *buffer, int size=0) const;

			/**Retrieves the number of Agreement rows for the thirdparty
			@version 7.1
			*/
			int				GetAgreementListCount() const;

			/**Retrieves the netting list defined for the Third party.
			@return	a CSREditList of the netting list that is defined.
			@version 4.5.2
			*/
			void			GetNettingList(SSThirdPartyNettingIter&start, SSThirdPartyNettingIter&end) const;

			/**Retrieves general tab toolkit data defined for the Third party
			@return shared pointer to toolkit data of the Third party
			@version 7.0.0
			*/
			SSThirdPartyGeneralTkPtr GetGeneralTk();

			/**Retrieves extended toolkit data defined for the Third party
			@param tkName - name of the extended toolkit to be retrieved
			@return shared pointer to toolkit data of the Third party
			@version 7.0.0
			*/
			SSThirdPartyExtendedTkPtr GetExtendedTk(_STL::string tkName);

			// Write Methods

			/**Sets the reference for this third party
			@param	reference string of the reference to be stored.
			@version 4.5.2
			*/
			void			SetReference(char *reference);

			/**Sets the name for this third party
			@param	name string of the name to be stored.
			@version 4.5.2
			*/
			void			SetName(char *name);

			/**Sets the legal name for this third party
			@param	name string of the name to be stored.
			@version 4.5.2
			*/
			void			SetLegalName(char *name);

			/**Sets the location for this third party
			@param	location string of the location to be stored.
			@version 4.5.2
			*/
			void			SetLocation(char *location);

			/**Sets the domicile for this third party
			@param	domicile string of the domicile to be stored.
			@version 4.5.2
			*/
			void			SetDomicile(char *domicile);

			/**Sets the comment for this third party
			@param	comment string of the comment to be stored.
			@version 4.5.2
			*/
			void			SetComment(char *comment);

			/**Sets the external reference for this third party
			@param	extRef string of the external reference to be stored.
			@version 4.5.2
			*/
			void			SetExternalReference(char *extRef);

			/**Sets the code of the share issued by the third party.
			@param	internal code of the instrument.
			@version 4.5.2
			*/
			void			SetIssuedShareCode(long code);

			/**Sets whether this is a group or not
			@param	state true if it is a group
			@version 4.5.2
			*/
			void			SetGroup(bool state);

			/**Sets whether this third party is a counterparty or not
			@param	state true if it is a counterparty.
			@version 4.5.2
			*/
			void			SetCounterparty(bool state);

			/**Sets whether this third party is a broker or not
			@param	state true if it is a broker.
			@version 4.5.2
			*/
			void			SetBroker(bool state);

			/**Sets whether this third party is a depositary or not
			@param	state true if it is a depositary.
			@version 4.5.2
			*/
			void			SetDepository(bool state);

			/**Sets whether this third party is a customer or not
			@param	state true if it is a customer.
			@version 4.5.2
			*/
			void			SetCustomer(bool state);

			/**Sets whether this third party is a PSET (Place of Settlement) or not
			@param	state true if it is a customer.
			@version 5.2.4
			*/
			void			SetPSET(bool state);

			/**Sets whether this third party is a Clearing House or not
			@param	state true if it is a Clearing House.
			@version 7.1
			*/
			void			SetClearingHouse(bool state);

			/**Sets whether this third party is a Clearing Member or not
			@param	state true if it is a Clearing Member.
			@version 7.1
			*/
			void			SetClearingMember(bool state);

			/**Sets whether this third party is corporate or not
			@param	state true if it is corporate.
			@version 4.5.2
			*/
			void			SetCorporate(bool state);

			/**Sets whether this third party is an exchange or not.
			@param	state true if it is an exchange.
			@version 4.5.2
			*/
			void			SetExchange(bool state);

			/**Sets whether this third party is an institution or not.
			@param	state true if it is an institution.
			@version 4.5.2
			*/
			void			SetInstitution(bool state);

			/**Sets whether this third party is another type or not.
			@param	state true if it is another type.
			@version 4.5.2
			*/
			void			SetOther(bool state);

			/**Sets whether this third party is a bank or not.
			@param	state true if it is a bank.
			@version 4.5.2
			*/
			void			SetBank(bool state);

			/**Sets the bank type.
			@param	type enum stating the bank type.
			@version 4.5.2
			*/
			void			SetBankType(eBankType type);

			/**Sets whether this third party is an entity or not.
			@param	state true if it is an entity.
			@version 4.5.2
			*/
			void			SetEntity(bool state);

			/**Sets the market tax to true or false.
			@param	state the state to set market tax to.
			@version 4.5.2
			*/
			void			SetMarketTax(bool state);

			/**Sets the gross price to true or false.
			@param	state the state to set gross price to.
			@version 4.5.2
			*/
			void			SetGrossPrice(bool state);

			/**Sets the average price to true or false.
			@param	state the state to set average price to.
			@version 4.5.2
			*/
			void			SetAveragePrice(bool state);

			/**Sets the language of the third party
			@param	state the state to set market tax to.
			@version 4.5.2
			*/
			void			SetLanguage(char *language);

			/**Sets whether this third party is a custodian or not.
			@param	state true if it is a custodian.
			@version 4.5.2
			*/
			void			SetCustodian(bool state);

			/**Sets whether this third party is an investment bank or not.
			@param	state true if it is an investment bank.
			@version 4.5.2
			*/
			void			SetInvestment(bool state);

			/**Sets whether this third party is a merchant bank or not.
			@param	state true if it is a merchant bank.
			@version 4.5.2
			*/
			void			SetMerchant(bool state);

			/**Sets whether this third party is a savings bank or not.
			@param	state true if it is a savings bank.
			@version 4.5.2
			*/
			void			SetSavings(bool state);



			/**Sets the short code for the third party
			@param	code the text for the short code.
			@version 4.5.2
			*/
			void			SetShortCode(char *code);

			/**Sets the swift code for the third party
			@param	code the text for the swift code.
			@version 4.5.2
			*/
			void			SetSwiftCode(char *code);

			/**Sets the ISIN code for the third party
			@param	code the text for the ISIN code.
			@version 4.5.2
			*/
			void			SetISINCode(char *code);

			/**Sets the phone number for the third party
			@param	phone the phone number.
			@version 4.5.2
			*/
			void			SetPhoneNumber(char *phone);

			/**Sets the fax number for the third party
			@param	fax the fax number.
			@version 4.5.2
			*/
			void			SetFaxNumber(char *fax);

			/**Sets the telexx number for the third party
			@param	telex the telex number.
			@version 4.5.2
			*/
			void			SetTelexNumber(char *telex);

			/**Sets the email address for the third party
			@param	email the email address.
			@version 4.5.2
			*/
			void			SetEmailAddress(char *email);

			/** Sets third party's site 
			@param site - site id to set. 
			Ids and names of sites are stored in CPTYSITEMENU
			@version 5.2
			*/
			void			SetSite( long site);

			/**Sets the first line for the address for the third party
			@param	line the first line.
			@version 4.5.2
			*/
			void			SetAddress1(char *line);

			/**Sets the second line for the address for the third party
			@param	line the second line.
			@version 4.5.2
			*/
			void			SetAddress2(char *line);

			/**Sets the third line for the address for the third party
			@param	line the third line.
			@version 4.5.2
			*/
			void			SetAddress3(char *line);

			/**Sets the fourth line for the address for the third party
			@param	line the fourth line.
			@version 4.5.2
			*/
			void			SetAddress4(char *line);

			/**Sets the fifth line for the address for the third party
			@param	line the fifth line.
			@version 4.5.2
			*/
			void			SetAddress5(char *line);

			/**Retrieves the currency associated with the third party for Accounting purposes.
			@return	the id of the currency defined.
			@version 4.5.2
			*/
			long	GetCurrency() const;

			/**Retrieves the account for the general ledger for Accounting purposes.
			@return	the account number of the general ledger associated with the third party.
			@version 4.5.2
			*/
			long	GetGeneralLedgerAccount() const;

			/**Retrieves the account number for the market fees.
			@return	the account number to be used for the market fees.
			@version 4.5.2
			*/
			long	GetMarketFeesAccount() const;


			/**Retrieves a long value from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@return	the long value is returned from the fucntion
			@version 4.5.2
			*/
			long	GetLongInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition) const;

			/**Retrieves a string from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@param	buffer this where the resulting string is stored.
			@param	size specify here the size that the buffer should be.
			@version 4.5.2
			*/
			void	GetStringInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition, char *buffer, int size=0) const;

			/**Retrieves a date as a long value from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@return	the long value is returned from the fucntion
			@version 4.5.2
			*/
			long	GetDateInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition) const;

			/**Retrieves the number of third parties that are entities.
			@return	the number of entities found in the third parties.
			@version 4.5.2
			*/
			static long 					GetEntityCount();

			/**Retrieves the nth Entity in the list of entities
			@param	which given n entities, this can be a number anywhere from 1 to n.
			@return	returns a pointer to the third party that is an entity or NULL if it is not found.
			@version 4.5.2
			*/
			static const CSRThirdParty*		GetNthEntity(int which);
			

			/**Get the number of third parties of a specific type.
			@param	thirdtype enum specifying which type of third party to count.
			@version 4.5.2
			*/
			static long 					GetThirdPartyCount(eThirdPartyType thirdtype);

			/**Get the nth third party of a specific type.
			Returns pointer to CSRThirdParty object or 0 if such third party does not exist.
			The returned pointer must not be deleted.
			@param	lequel specify a number from 1...n where n is the number of third parties.
			@param	thirdtype enum specifying which type of third party to get.
			@return	returns a pointer to the third party that is of the given type.
			@version 4.5.2
			*/
			static const CSRThirdParty*		GetNthThirdParty(int lequel, eThirdPartyType thridtype);

			/** Returns pointer to CSRThirdParty object or 0 if such third party does not exist.
			* The returned pointer must not be deleted.
			*/
			static const CSRThirdParty*		GetCSRThirdParty(long thirdPartyId);

			/**Retrieve a third party by name.
			Returns pointer to CSRThirdParty object or 0 if such third party does not exist.
			The returned pointer must not be deleted.
			@param	name the name of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given name.
			@version 4.5.2
			*/
			static const CSRThirdParty*		GetCSRThirdParty(char* name);

			/**Retrieve a third party by reference.
			Returns pointer to CSRThirdParty object or 0 if such third party does not exist.
			The returned pointer must not be deleted.
			@param	ref the reference of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given reference.
			@version 4.5.2
			*/
			static const CSRThirdParty*		GetCSRThirdPartyByReference(char* ref);

			/**Retrieve a third party by external reference.
			Returns pointer to CSRThirdParty object or 0 if such third party does not exist.
			The returned pointer must not be deleted.
			@param	extRef the external reference of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given external reference.
			@version 4.5.2
			*/
			static const CSRThirdParty*		GetCSRThirdPartyByExternalRef(char* extRef);

			/**Retrieve a vector of third parties based on type
			@param	thirdtype enum specifying which type of third party to get.
			@param	ret Result vector of third parties.
			@version 7.0
			*/
			static void GetThirdParties(eThirdPartyType thirdtype, _STL::vector<CSRThirdParty>& ret);

			/**Retrieve a vector of third parties based on type and possibly taking into account the broker fees
			@param	thirdtype enum specifying which type of third party to get.
			@param  takeFeesInAccount boolean that specifies whether the broker fees are taken into account or not (the transaction must be specified)
			@param  tr pointer to the transaction
			@param	ret Result vector of third parties.
			@version 7.1.3
			*/
			static void GetThirdParties(eThirdPartyType thirdtype, bool takeFeesInAccount, sophis::portfolio::CSRTransaction *tr, _STL::vector<CSRThirdParty>& ret);

			/**Retrieve the categorization menu value.
			@return	the value of categorization in the MiFID tab.
			@version 6.1
			*/
			eMiFIDCategorization GetMiFIDCategorization() const;
			/**Retrieve the reporter menu value.
			@return	the value of reporter in the MiFID tab.
			@version 6.1
			*/
			eMiFIDReporter GetMiFIDReporter() const;
			/**Retrieve the trading capacity menu value.
			@return	the value of trading capacity in the MiFID tab.
			@version 6.1
			*/
			eMiFIDTradingCapacity GetMiFIDTradingCapacity() const;
			/**Set the categorization menu value.
			@version 6.1
			*/
			void SetMiFIDCategorization(eMiFIDCategorization value);
			/**Set the reporter menu value.
			@version 6.1
			*/
			void SetMiFIDReporter(eMiFIDReporter value);
			/**Set the trading capacity menu value.
			@version 6.1
			*/
			void SetMiFIDTradingCapacity(eMiFIDTradingCapacity value);

			/**
			* Save any changes made to a new or existing Thirdparty. This save
			* is for use via the API, as it bypasses much of the UI functionality
			* @param	mode specifies whether the save is being carried out by the API(default) or GUI
			* @throws VoteException if one CSRThridPartyAction rejects modifications. Note that in such a case
			* no modification of the database has been done so that your previous save are still correct.
			*/
			void Save (eSavingMode mode = smApi) 
				throw (sophis::tools::VoteException);

			/**
			* Requests every 'action' registered, to vote for save, but do not perform any
			* real saving.
			* @throw	VoteException If any action rejected the vote.
			*/
			void validate()
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);

			/**
			* Requests every 'action' registered, to vote for removal, but do not perform any
			* real saving.
			* @throw	VoteException If any action rejected the vote.
			*/
			void validateForRemoval()
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);

			/**
			* Remove an existing ThirdParty via the API, if the code is not
			* specified, then the one passed in the ctor is used (if not 0)
			* @param	mode specifies whether the remove is being carried out by the API(default) or GUI
			*/
			void Remove(eSavingMode mode = smApi) 
				throw (sophis::tools::VoteException);            

			/**
			* Clone and return a new instance of an existing Thirdparty which can be 
			* modified outside the UI through API calls
			* @params if load is true the internal dialog is loaded
			*/
			CSRThirdParty* Clone(bool load = true) const;

			/**
			* Serializes party description into a Data
			* Fills directly the data with the party description
			* @since 5.3
			*/
			void Describe(tools::dataModel::Data & data) const;

			/**
			* Serializes party description into a DataSet
			* Creates a sub element "party" (type "Party") to the DataSet and fills it with the description
			* Cf. grammar "www.sophis.net/party" in party.xsd for this type
			*/
			void Describe(tools::dataModel::DataSet& dataSet) const;

			/**
			* Serializes party identifiers into a Data
			* Fills directly the data with the party identifiers
			* @since 5.3
			*/
			void DescribeIdentifier(tools::dataModel::Data & data) const;

			/**
			* Serializes party identifiers into a DataSet
			* Creates a sub element "partyReference" (type "PartyReference") to the DataSet and fills it with the identifiers
			* Cf. grammar "www.sophis.net/party" in party.xsd for this type
			*/
			void DescribeIdentifier(tools::dataModel::DataSet& dataSet) const;

			/**
			* Update a party from a Data
			* @param data : can be an element "party" (type "Party") or an other element. In this last case,
			* data is considered as a element of type "Party" (it has to contain directly elements of type "Party").
			* Cf. grammar "www.sophis.net/party" in party.xsd
			* @since 5.3
			*/
			void Update(const tools::dataModel::Data & data);

			/**
			* Update a party from a DataSet
			* @param data_set : must contain a element "party" (type "Party")
			* Cf. grammar "www.sophis.net/party" in party.xsd for these 2 types
			*/
			void Update(const tools::dataModel::DataSet& dataSet);

			/**
			* @throws DuplicatePartyException
			*/
			static CSRThirdParty * Create(const tools::dataModel::DataSet& dataSet);

			/**
			* Retrieves a party from a Data
			* @param data : can be an element "party" (type "Party") or "partyReference" (type "PartyReference")
			* or an other element. In this last case, data is considered as a element of type "PartyReference" (it has to contain
			* directly partyId element(s)).
			* Cf. grammar "www.sophis.net/party" in party.xsd
			* @param exceptionIfNotFound : if true, if party not found throws a NoSuchData exception (default=true)
			* @since 5.3
			*/
#ifndef GCC_XML
			static const CSRThirdParty * Find(const tools::dataModel::Data & data, bool exceptionIfNotFound = true)
				throw (sophis::tools::dataModel::DataModelException,sophisTools::base::ExceptionBase);
#endif
			/**
			* Retrieves a party from a DataSet
			* @param data_set : must contain a element "party" (type "Party") or "partyReference" (type "PartyReference")
			* Cf. grammar "www.sophis.net/party" in party.xsd for these 2 types
			* @param exceptionIfNotFound : if true, if party not found throws a NoSuchData exception (default=true)
			* @throws sophis::tools::dataModel::InvalidDataValue if data_set does not contain a good element
			*/
			static const CSRThirdParty * Find(const tools::dataModel::DataSet & data_set, bool exceptionIfNotFound = true);

		public:
			DECLARATION_CASTAGE2

		private:
			long								fCode;
		};


		/**
		 * Interface for settlement (SSI) conditions input data.
		 * @version 6.3
		 */
		class SOPHIS_FIT ISRSsiLinksTkCriteria
		{
		public:
			virtual ~ISRSsiLinksTkCriteria() {}
			virtual long GetSettlementDate() = 0;
		};

		/**
		 * Transaction specific implementation of ISRSsiLinksTkCriteria.
		 * @version 6.3
		 */
		class SOPHIS_FIT CSRSsiLinksTransactionTkCriteria: public ISRSsiLinksTkCriteria
		{
		public:
			/**
			 * @param tr Transaction
			 * @param instr Instrument (optional), if NULL then we try to fetch instrument from transaction.
			 */
			CSRSsiLinksTransactionTkCriteria(const portfolio::CSRTransaction *tr, const instrument::CSRInstrument* instr) : fDeal(tr), fInstr(instr) {}
			virtual ~CSRSsiLinksTransactionTkCriteria() {}
			virtual long GetSettlementDate(); 

			const portfolio::CSRTransaction* GetCriteriaTransaction() const { return fDeal;}
			const instrument::CSRInstrument* GetCriteriaInstrument() const;

		protected:
			const portfolio::CSRTransaction *fDeal;
			const instrument::CSRInstrument *fInstr;
		};

		/**
		 * Input parameters for SSI lookup.
		 */
		SPH_BEGIN_NOWARN_EXPORT
		struct SOPHIS_FIT SettlementLinksFullFilterCriteria
		{
			// constructor
			SettlementLinksFullFilterCriteria
				(
				long								bankID,
				int									allotment,
				long								currency,
				long								market,
				int									sign, 
				long								depositary,
				CSRThirdParty::eMsgRoleInSettlement role,
				long								workflowID,
				sophis::portfolio::eBODeliveryType	deliveryTypeID,
				CSRThirdParty::VeAccountType accountTypes,
				long								paymentMethod,
				long								underlyingCurrency,
				long								underlyingMarket,
				int									underlyingAllotment,
				long								businessEvent,
				long								today,
				long								portfolio_id,
				ISRSsiLinksTkCriteria				*tkCriteria = NULL
				) :
			bnkID										(bankID),
				allot										(allotment),
				curr										(currency),
				mrkt										(market),
				sgn											(sign),
				depos										(depositary),
				rl											(role),
				fWorkflowID									(workflowID),
				fDeliveryTypeID								(deliveryTypeID),
				fAccountTypes								(accountTypes),
				fPaymentMethod								(paymentMethod),
				underlyingCurr								(underlyingCurrency),
				underlyingMrkt								(underlyingMarket),
				underlyingAllot								(underlyingAllotment),
				fBusinessEvent								(businessEvent),
				fToday										(today),
				fPortfolio_id								(portfolio_id),
				fTKCriteria 								(tkCriteria)
			{
			}

			long										bnkID;
			int											allot;
			long										curr;
			long										mrkt;
			int											sgn;
			long										depos;
			CSRThirdParty::eMsgRoleInSettlement			rl;
			long										fWorkflowID;
			sophis::portfolio::eBODeliveryType			fDeliveryTypeID;
			CSRThirdParty::VeAccountType				fAccountTypes;
			long										fPaymentMethod;
			long										underlyingCurr;
			long										underlyingMrkt;
			int											underlyingAllot;
			long										fBusinessEvent;
			long										fToday;//5.2.8: The day to use to compare with FROM/TO date. If NULL, deal settlement date will be used. If that is zero, prices date will be used (from version 6.1 on).
			long										fPortfolio_id;
			ISRSsiLinksTkCriteria						*fTKCriteria;
		};
		SPH_END_NOWARN_EXPORT

	}  //namespace

    /*function used to query the schema owning the Sophis objects, needed for customers that have a two schema setup such as: 
    -one schema containing the Sophis objects
    -another schema allowed to do only select and DML operations on the objects in the Sophis schema through the use of synonyms*/
    _STL::string SOPHIS_FIT GetSchemaName();


}  // namespace


SPH_EPILOG

#endif
