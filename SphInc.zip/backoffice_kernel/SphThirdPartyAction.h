/*
 	File:		SphThirdPartyAction.h
 
 	Contains:	Class to generate action on a thirdparty when saved.
 
 	Copyright:	� 2003 Sophis.
 
*/


#pragma once

#ifndef _SphThirdPartyAction_H_
#define _SphThirdPartyAction_H_

#ifndef _SphPrototype_H_
	#include "SphTools/SphPrototype.h"
#endif
#ifndef _SphAlgorthm_H_
	#include "SphInc/tools/SphAlgorithm.h"
#endif

#ifndef _SphValidation_H_
	#include "SphInc/tools/SphValidation.h"
#endif

#ifndef _SPH_THIRD_PARTY_ENUMS_H_
	#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#endif


SPH_PROLOG

#define DECLARATION_THIRDPARTY_ACTION(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRThirdPartyAction)
#define CONSTRUCTOR_THIRDPARTY_ACTION(derivedClass)			
#define WITHOUT_THIRDPARTY_ACTION(derivedClass)	
#define	INITIALISE_THIRDPARTY_ACTION(derivedClass, order,  name)		INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

#define DECLARATION_THIRDPARTY_EVENT(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::CSRThirdPartyEvent)
#define CONSTRUCTOR_THIRDPARTY_EVENT(derivedClass)			
#define WITHOUT_CONSTRUCTOR_THIRDPARTY_EVENT(derivedClass)	
#define	INITIALISE_THIRDPARTY_EVENT(derivedClass, order,  name)		INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

namespace sophis {
   namespace backoffice_kernel {
      class CSRThirdPartyDlg;

enum eTCPMessageType
{
   tp_modified,
   tp_new,
   tp_deleted,
   tp_delete_fe,
   tp_transferred,
   tp_transferred_fe,
   tp_ssitab_modified 
};

/** Interface to trigger some actions when saving third parties.
You can overload this class and insert your own triggers.
@since 4.4.1.2
*/
class SOPHIS_FIT CSRThirdPartyAction
{
public:

	/** Specify the order of the triggers.
	*/
	enum	eOrder	{
		/** Before saving the data
		*/
		oBefore,
		
		/** Used internally : the code for saving is actually a trigger ordered by this enum
		*/
		oSave,

		/** After saving the data
		*/
		oAfter
	};


	/** Trivial constructor
	*/
	CSRThirdPartyAction();

	/** Trivial destructor
	*/
	virtual ~CSRThirdPartyAction();

	/** Ask for a creation of a thirdparty.
	When creating, first all the triggers will be called via VoteForCreation to check if they accept the
	creation in the order eOrder + lexicographical order.
	The thirdparty id can be  null; it will then created by the Sophis trigger.
	@param thirdparty is the thirdparty to create. It is a non const object so that you can
	modify it.
	@throws VoteException if you reject that creation.
	*/
	virtual void VoteForCreation(sophis::backoffice_kernel::CSRThirdPartyDlg &tparty)
		throw (sophis::tools::VoteException);

	/** Ask for accepting a modification
	When saving, first all the triggers will be called via VoteForModification to check if they accept the
	modification in the order eOrder + lexicographical order.
	@param thirdparty is the thirdparty to save. It is a non const object so that you can
	modify it.
	@throws VoteException if you reject that modification.
	*/
	virtual void VoteForModification(sophis::backoffice_kernel::CSRThirdPartyDlg &tparty)
		throw (sophis::tools::VoteException);

	/** Ask for a transfer of a thirdparty.
	When moving a thirdparty, first all the triggers will be called via VoteForTransfer to check if they accept the
	transfer in the order eOrder + lexicographical order.
	@param thirdparty is the thirdparty to transfer.
	@throws VoteException if you reject that creation.
	*/
	virtual void VoteForTransfer(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty)
		throw (sophis::tools::VoteException);

	/** Ask for deletion of a thirdparty.
	When deleting, first all the triggers will be called via VoteForDeletion to check if they accept the
	deletion in the order eOrder + lexicographical order.
	@param thirdparty is the thirdparty to delete.
	@throws VoteException if you reject that deletion.
	*/
	virtual void VoteForDeletion(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty)
		throw (sophis::tools::VoteException);

	/** Ask what to notify when creating.
	When saving, after that all the triggers have accepted the creation, they are called again 
	in the order eOrder + lexicographical order via
	NotifyCreated to check if they have something to save in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param thirdparty is the thirdparty to create. It is a non const object so that you cannot
	modify it. The thirdparty id is created at this level by the trigger oCreation as well as
	the reference if empty.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that creation. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyCreated(eSavingMode mode, const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty, sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** Ask what to notify when modifying.
	When saving, after that all the triggers have accepted the modification, they are called again 
	in the order eOrder + lexicographical order via
	NotifyModified to check if they have something to save in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param thirdparty is the thirdparty to save. It is a const object so that you cannot
	modify it.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyModified(eSavingMode mode, const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty, sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** Ask what to notify when transferring.
	When transferring, after that all the triggers have accepted the transfer, they are called again 
	in the order eOrder + lexicographical order via
	NotifyTransferred to check if they have something to save in the database or send to other servers.
	@param thirdparty is the thirdparty to transfer.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@param nbElem the number of elements to move.
	@param TabElem pointer to the list of elements to move.
	@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
	some trouble, as in case of multi-saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyTransferred(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty,
	                               sophis::tools::CSREventVector & message,
								   int nbElem, LONG_PTR *TabElem)
		throw (sophisTools::base::ExceptionBase); 

	/** Ask what to notify when deleting.
	When deleting, after that all the triggers have accepted the creation, they are called again 
	in the order eOrder + lexicographical order via
	NotifyDeleted to check if they have something to delete in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param thirdparty is the thirdparty to delete.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyDeleted(eSavingMode mode, const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty, sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** key for the prototype is eOrder + lexicographical 
	*/
	typedef sophis::tools::ordered_name<eOrder> ordered_name;
	
	/** typedef for the prototype
	*/
	typedef sophis::tools::CSRPrototype<CSRThirdPartyAction, ordered_name> prototype;

	/** access to the prototype singleton
	To add a trigger to this singleton, use INITIALISE_THIRDPARTY_ACTION
	@see tools::CSRPrototype
	*/
	static prototype & GetPrototype();

	/** Clone method needed by the prototype
	Usually, it is done automaticly by the macro DECLARATION_THIRDPARTY_ACTION
	@see tools::CSRPrototype
	*/
	virtual CSRThirdPartyAction * Clone() const = 0;
 private:
    void Vote(sophis::backoffice_kernel::CSRThirdPartyDlg* tparty)
         throw (sophis::tools::VoteException);

    void Notify(sophis::backoffice_kernel::CSRThirdPartyDlg &tparty,sophis::tools::CSREventVector & mess)
	     throw (sophisTools::base::ExceptionBase);



};

/** Interface triggered when another workstation has modified the thirdparty
You can overload this class and insert your own triggers
@version 4.4.1.2
*/
class SOPHIS_FIT CSRThirdPartyEvent
{
public:

	/** Specify the order of the triggers.
	*/
	enum	eOrder	{
		/** Before updating the data
		In the trigger, a call CSRPortfolio::GetCSRPortfolio will give the old portfolio structure.
		*/
		oBefore,
		
		/** Used internally : the code for updating is actually a trigger ordered by this enum
		*/
		oUpdate,

		/** After updating the data
		In the trigger, a call CSRPortfolio::GetCSRPortfolio will give the new portfolio structure.
		*/
		oAfter
	};


	/** Trivial constructor
	*/
	CSRThirdPartyEvent();

	/** Trivial Destructor
	*/
	virtual ~CSRThirdPartyEvent();

	/** Called when a thirdparty has been created in another workstation.
	When receiving a creation event for portfolio, all the triggers are called by this method
	 in the order eOrder + lexicographical order.
	@param thirdparty is a thirdparty instance with the new data; note that this instance is not
	the one given by CSRPortfolio::GetCSRPortfolio and will be deleted soon; you can modify it in 
	listenner of type oBefore but it is not recommanded.
	@return false to bypass this event; In that case the other triggers are not executed
	and the windows are not updated; Use it with moderation, only in the case oBefore.
	*/
	virtual bool HasBeenCreated(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty, long selection);

	/** Called when a thirdparty has been updated in another workstation.
	When receiving an update event for portfolio, all the triggers are called by this method
	 in the order eOrder + lexicographical order.
	@param thirdparty is a thirdparty instance with the new data; note that this instance is not
	the one given by CSRPortfolio::GetCSRPortfolio and will be deleted soon; you can modify it in 
	listenner of type oBefore but it is not recommanded.
	*/
	virtual void HasBeenModified(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty,long selection);

	/** Called when a thirdparty has been created in another workstation.
	When receiving a transfer event for portfolio, all the triggers are called by this method
	 in the order eOrder + lexicographical order.
	@param thirdparty is a thirdparty instance with the new data; note that this instance is not
	the one given by CSRPortfolio::GetCSRPortfolio and will be deleted soon; you can modify it in 
	listenner of type oBefore but it is not recommanded.
	@return false to bypass this event; In that case the other triggers are not executed
	and the windows are not updated; Use it with moderation, only in the case oBefore.
	*/
	virtual void HasBeenTransferred(const sophis::backoffice_kernel::CSRThirdPartyDlg &tparty,long selection);

	/** Called when a thirdparty has been created in another workstation.
	When receiving a delete event for thirdparty, all the triggers are called by this method
	 in the order eOrder + lexicographical order.
	@param code is the code of the thirdparty before deletion.
	*/
	virtual void HasBeenDeleted(long code);

	/** key for the prototype is eOrder + lexicographical 
	*/
	typedef sophis::tools::ordered_name<eOrder> ordered_name;
	
	/** typedef for the prototype
	*/
	typedef sophis::tools::CSRPrototype<CSRThirdPartyEvent, ordered_name> prototype;

	/** access to the prototype singleton
	To add a trigger to this singleton, use INITIALISE_THIRDPARTY_EVENT
	@see CSRPrototype
	*/
	static prototype & GetPrototype();

	/** Clone method needed by the prototype
	Usually, it is done automatically by the macro DECLARATION_THIRDPARTY_EVENT
	@see CSRPrototype
	*/
	virtual CSRThirdPartyEvent * Clone() const = 0;

};

   }
}



SPH_EPILOG

#endif