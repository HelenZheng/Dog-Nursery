/*
File:		SphThirdParty.h

Contains:	Class for the handling of a third party.

Copyright:	� 1995-2003 Sophis.

*/

/*! \file SphThirdParty.h
\brief Handling third parties.
*/

#ifndef _CSRThirdPartyDlg_H_
#define _CSRThirdPartyDlg_H_

#include "SphInc\backoffice_kernel\SphThirdParty.h"
#include "SphInc/SphMacros.h"
#include "SphTools/sphvector.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#include "SphInc/portfolio/SphTransactionEnums.h"
#include "SphInc/tools/SphValidation.h"


#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG

struct	SSThirdParty;	// internal
class	CSTiers;		// internal
class   CSWindow;




namespace sophis
{
	namespace gui
	{
		class	CSRDatabaseDialog;
		class	CSRFitDialog;
	}
	namespace portfolio
	{
		class	CSRTransaction;
	}
	namespace tools
	{
		namespace dataModel
		{
			class Data;
			class DataSet;
			class DataModelException;
		}
	}
};


namespace sophis 
{
	namespace gui
	{
		class CSREditList;
	}
}

namespace sophis {
	namespace backoffice_kernel {
		class SOPHIS_FIT CSRThirdPartyDlg
		{
		public:

			/** This ctor is used when working via the API
			*  to create new thirdparties
			*/
			CSRThirdPartyDlg();
			CSRThirdPartyDlg(SSThirdParty* tiers);

			/**
			Constructor that is initialised using the CSTiers class
			*/
			CSRThirdPartyDlg(const CSTiers* tiers);

			virtual ~CSRThirdPartyDlg();

			/**Retrieves the ID of the third party.
			@return	the id of the third party.
			@version 4.5.2
			*/
			long	GetIdent() const;

			/**Retrieves the parent third party (if there is one) in the event of a group.
			@return	the id of the parent group (or 0 if there is no parent defined)
			@version 4.5.2
			*/
			long	GetHolding() const;

			/**Retrieves the parent third party as a pointer to a CSRThirdPartyDlg
			@return	the the actual third party (if it exists)
			@version 4.5.2
			*/
			const CSRThirdPartyDlg* GetParent() const;

			bool SetProperty(const char *property, char *value);

			/**
			*
			*/
			void SetParent(long ident);

			static CSRThirdPartyDlg* GetCSRThirdParty(long thirdPartyId);

			/**Retrieves the reference of the third party
			@param	reference will be where the reference of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetReference(char *reference) const;

			/**Retrieves the external reference of the third party
			@param	externalReference will be where the external reference of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetExternalReference(char *externalReference) const;

			/**Retrieves the name of the third party
			@param	name will be where the external name of the Third Party will be stored.
			@version 4.5.2
			@version 6.3 now returns std::string
			*/
			_STL::string GetName() const;

			/**Retrieves the legal name of the third party
			@param	name will the Legal name of the Third Party.
			@version 6.0.1
			*/
			void	GetLegalName(char *name) const;

			/**Retrieves the comment information associated with the third party
			@param	infos will be where the comment information of the Third Party will be stored.
			@version 4.5.2
			*/
			void	GetComment(char *infos) const;

			/**Retrieves the internal code of the share issued by the Third Party.
			@return	0 if no such association has been defined.
			@version 4.5.2
			*/
			long	GetIssuedShareCode() const;

			/**Determines whether or not the third party is a parent group.
			@return	true if the third party is a parent group.
			@version 4.5.2
			*/
			bool	IsAGroup(void) const;

			/**Determines whether or not the third party is a counterparty
			@return	true if the third party is a counterparty.
			@version 4.5.2
			*/
			bool	IsACounterparty(void) const;

			/**Determines whether or not the third party is a boker
			@return	true if the third party is a broker.
			@version 4.5.2
			*/
			bool	IsABroker(void) const;

			/**Determines whether or not the third party is a depositary.
			@return	true if the third party is a depositary.
			@version 4.5.2
			*/
			bool	IsADepositary(void) const;

			/**Determines whether or not the third party is a customer/client.
			@return	true if the third party is a customer/client.
			@version 4.5.2
			*/
			bool	IsACustomer(void) const;

			/**Determines whether or not the third party is an entity.
			@return	true if the third party is an entity.
			@version 4.5.2
			*/
			bool	IsEntity() const;

			/**Determines whether or not the third party is a bank.
			@return	true if the third party is a bank.
			@version 4.5.2
			*/
			bool	IsABank(void) const;

			/**Determines whether or not the third party is a Corporate.
			@return	true if the third party is a corporate.
			@version 4.5.2
			*/
			bool	IsACorporate(void) const;

			/**Determines whether or not the third party is an Exchange.
			@return	true if the third party is an Exchange.
			@version 4.5.2
			*/
			bool	IsAnExchange(void) const;

			/**Determines whether or not the third party is an Institution.
			@return	true if the third party is an Institution.
			@version 4.5.2
			*/
			bool	IsASupranational(void) const;

			/**Determines whether or not the third party is of another different form.
			@return	true if the third party is of another different form.
			@version 4.5.2
			*/
			bool	IsAnother(void) const;

			/**Determines whether or not the third party is an investment bank
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool CSRThirdPartyDlg::IsAInvestmentBank(void) const;

			/**Determines whether or not the third party is a merchant
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool CSRThirdPartyDlg::IsAMerchant(void) const;

			/**Determines whether or not the third party is a savings bank
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool CSRThirdPartyDlg::IsASavingsBank(void) const;

			/**Determines whether or not the third party is of a custodian
			@return	true if the third party is of another different form.
			@version 6.0.1
			*/
			bool CSRThirdPartyDlg::IsACustodian(void) const;

			/**Determines whether or not the third party is a PSET (Place of Settlement).
			@return	true if the third party is a PSET.
			@version 5.2.4
			*/
			bool	IsAPSET(void) const;

			/**Determines whether or not the third party is a Clearing House
			@return	true if the third party is a Clearing House.
			@version 7.1.0
			*/
			bool	IsAClearingHouse(void) const;

			/**Determines whether or not the third party is a Clearing Member
			@return	true if the third party is a Clearing Member.
			@version 7.1.0
			*/
			bool	IsAClearingMember(void) const;

			/**Retrieves the loaction of the third party.
			@param	buffer is where the the location string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetLocation(char *buffer, int size) const;

			/**Retrieves the domicile of the third party.
			@param	buffer is where the the domicile string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetDomicile(char *buffer, int size) const;

			/**Retrieves the language of the third party.
			@param	buffer is where the the language string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetLanguage(char *buffer, int size) const;

			eBankType		GetBankType() const;

			/**Determines whether or not the third party is a Custodian Bank.
			@return	true if the third party is a Custodian Bank.
			@version 4.5.2
			*/
			bool			GetCustodian() const;

			/**Determines whether or not the third party is an Investment Bank.
			@return	true if the third party is an Investment Bank.
			@version 4.5.2
			*/
			bool			GetInvestment() const;

			/**Determines whether or not the third party is a Merchant Bank.
			@return	true if the third party is a Merchant Bank.
			@version 4.5.2
			*/
			bool			GetMerchant() const;

			/**Determines whether or not the third party is a Savings Bank.
			@return	true if the third party is a Savings Bank.
			@version 4.5.2
			*/
			bool			GetSavings() const;

			/**Determines whether or not the Market Tax flag is set or not.
			@return	true if Market tax is set.
			@version 4.5.2
			*/
			bool			GetMarketTax() const;

			/**Determines whether or not the Gross price flag is set or not.
			@return	true if Gross price is set.
			@version 4.5.2
			*/
			bool			GetGrossPrice() const;

			/**Determines whether or not the Avergage price flag is set or not.
			@return	true if Average price is set.
			@version 4.5.2
			*/
			bool			GetAveragePrice() const;

			/**Retrieves the list of properties defined for the Third party.
			@return	a CSREditList of the properties that are defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetPropertiesList() const;

			/**Retrieves a given Property from the third party's list of properties.
			@param	property the name of the property that is to be retrieved.
			@param	buffer is where the value of the property is stored. 
			@param	size specify here what size the buffer should be. A max of 140(value string length) + 1 bytes will be copied to buffer
			@version 4.5.2
			*/
			void			GetProperty(const char *property, char *buffer, int size) const;





			/**Retrieves the Short Code of the third party.
			@param	buffer is where the the short code string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetShortCode(char *buffer, int size) const;

			/**Retrieves the ISIN Code of the third party.
			@param	buffer is where the the ISIN code string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetISINCode(char *buffer, int size) const;

			/** Retrieves the Swift Code of the third party. Calls GetThirdTabList using the boolean toLoad
			@param	buffer is where the the swift code string is stored.
			@param	size specify here what size the buffer should be.
			@param	toLoad indicates if we're coming from the GUI or not
			@see GetThirdTabList
			@version 4.5.2
			*/
			void			GetSwiftCode(char *buffer, int size, bool toLoad = true) const;

			/**Retrieves the Phone number of the third party.
			@param	buffer is where the the phone number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetPhoneNumber(char *buffer, int size) const;

			/**Retrieves the Fax number of the third party.
			@param	buffer is where the the fax number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetFaxNumber(char *buffer, int size) const;

			/**Retrieves the Telex number of the third party.
			@param	buffer is where the the telex number string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetTelexNumber(char *buffer, int size) const;

			/**Retrieves the E-mail of the third party.
			@param	buffer is where the the E-mail string is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetEmail(char *buffer, int size) const;

			/**Retrieves the first line of the address of the third party.
			@param	buffer is where the the addresses first line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress1(char *buffer, int size) const;

			/**Retrieves the second line of the address of the third party.
			@param	buffer is where the the addresses second line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress2(char *buffer, int size) const;

			/**Retrieves the third line of the address of the third party.
			@param	buffer is where the the addresses third line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress3(char *buffer, int size) const;

			/**Retrieves the fourth line of the address of the third party.
			@param	buffer is where the the addresses fourth line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress4(char *buffer, int size) const;

			/**Retrieves the fifth line of the address of the third party.
			@param	buffer is where the the addresses fifth line is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetAddress5(char *buffer, int size) const;

			/**Retrieves the list of contacts defined for the Third party.
			@return	a CSREditList of the contacts that are defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetContactsList() const;

			/**Given the title this function returns the Name of a contact.
			@param	title the title of the contact to be retrieved
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContact(const char *title, char *buffer, int size) const;

			/**Given the title this function returns the phone number of a contact.
			@param	title the phone number of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactPhone(const char *title, char *buffer, int size) const;

			/**Given the title this function returns the fax number of a contact.
			@param	title the fax number of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactFax(const char *title, char *buffer, int size) const;

			/**Given the title this function returns the email address of a contact.
			@param	title the email address of the contact to be retrieved.
			@param	buffer is where the name of the contact is stored.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetContactEmail(const char *title, char *buffer, int size) const;

			/** Returns site assigned to third party
			@version 5.2
			*/
			long GetSite() const;



			/**Retrieves the list of settlement instructions defined for the Third party.
			@return	a CSREditList of the settlement instructions that are defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetSettlementInstructionList() const;

			/**Gets the swift code assigned to the third party in the Address tab of the Third party dialog.
			It should be noted that the returned character array is a dynamically allocated character array,
			and should be deleted by the caller when finished with to avoid memory leaks.
			Alternatively, call GetSWIFT(char *), passing in an appropriatly sized character array.
			@return the swift code of the third party
			*/
			char*			GetSWIFT(void) const;

			/*Gets the swift code assigned to the third party in the Address tab of the Third party dialog.
			@param swift is the output parameter which will contain the swift code
			*/
			void			GetSWIFT(char *swift) const; 

			/**Given a list of line numbers in the list of instructions this function returns the appropriate
			details that are needed in SettlementLink.
			@param	lines the lines in the settlement instructions list that we are concerned with.
			@param	size stores the number of SettlementLinks that is returned.
			@return	a pointer to an array of settlement links is returned.
			@version 4.5.2
			*/
			SettlementLink* GetSettlementLinks(_STL::vector<long> &lines, int *size) const;

		public:
			/**Retrieves the document generation list defined for the Third party.
			@return	a CSREditList of the possible document generations that are defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetDocumentationGenerationList() const;

			/**Retrieves the first Document to be generated that matches the criteria
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the settlement insructions.
			@param	event if not -1 then this much match the Business Event column for the document generation
			@param	currency the currency of the document that we wish to find a match for.
			@param	lineNum returns the line number (0....n) if an instruction is found that matches the criteria. 
			@param	msg_code this is the criteria for Recipient Type.
			@return	true is returned if a matching document generation is found.
			@version 4.5.2
			*/
			bool			GetFirstConfirmation(long thirdPartyId, int allotment, short event, long currency, int &lineNum, int msg_code = -1) const;

			/**Retrieves the Contact name for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	buffer is where the name will be stored on returning.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetConfirmationContactName(long thirdPartyId, int allotment, long currency, char *buffer, int size) const;

			/**Retrieves the means by which the confirmation is to be sent.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	msg_code this is the criteria for Recipient Type.
			@return	returns Fax, Email or Telex.
			@version 4.5.2
			*/
			eConfirmationMethodType		GetConfirmationMethod(long thirdPartyId, int allotment, long currency, int msg_code = -1) const;

			/**Retrieves the Confirmation Address for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	currency the currency of the document that we wish to find a match for.
			@param	buffer is where the name will be stored on returning.
			@param	size specify here what size the buffer should be.
			@param	msg_code this is the criteria for Recipient Type.
			@version 4.5.2
			*/
			void			GetConfirmationAddress(long thirdPartyId, int allotment, long currency, char *buffer, int size, int msg_code) const;

			/**Retrieves the Template name for the document that is to be generated.
			@param	thirdPartyId id of the third party that must match the Entity column.
			@param	allotment is the allotment to search for in the document generation list.
			@param	event the Business Event for the document to be generated.
			@param	currency the currency of the document that we wish to find a match for.
			@param	buffer is where the name will be stored on returning.
			@param	size specify here what size the buffer should be.
			@version 4.5.2
			*/
			void			GetConfirmationTemplate(long thirdPartyId, int allotment, short event, long currency, char *buffer, int size) const;




			/**Retrieves the agreements list defined for the Third party.
			@return	a CSREditList of the agreements list that is defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetAgreementsList() const;

			/**Retrieves the first Agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	lineNum returns the line number (0....n) if an agreement is found that matches the criteria. 
			@return	true is returned if a matching legal agreement is found.
			@version 4.5.2
			*/
			bool			GetFirstAgreement(int allotment, int &lineNum) const;

			/**Retrieves the Agreement value from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the agreement is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreement(int allotment, char *buffer, int size) const;

			/**Returns the Agreement version from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the version of the agreement.
			@version 4.5.2
			*/
			long			GetAgreementVers(int allotment) const;

			/**Retrieves the Law from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the law is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementLaw(int allotment, char *buffer, int size) const;

			/**Returns the Effectiveness Date from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the date in long format.
			@version 4.5.2
			*/
			long			GetAgreementEffectivenessDate(int allotment) const;

			/**Returns the Ammendment Date from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the date in long format.
			@version 4.5.2
			*/
			long			GetAgreementAmendmentDate(int allotment) const;

			/**Gets the Termination Currency from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@return	the ID of the currency is returned.
			@version 4.5.2
			*/
			long			GetAgreementTerminationCurrency(int allotment) const;

			/**Retrieves the Contact name from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the name is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactName(int allotment, char *buffer, int size) const;

			/**Retrieves the Contact phone number from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the phone number is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactPhone(int allotment, char *buffer, int size) const;

			/**Retrieves the Contact fax number from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the fax number is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementContactFax(int allotment, char *buffer, int size) const;

			/**Retrieves the Termination Comment from the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the comment is stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementTerminationComment(int allotment, char *buffer, int size) const;

			/**Retieves the row number of the chosen agreement given the allotment, currency and sender
			@param	allotment is the allotment to search for in the agreements.
			@param	currency is the currency to search for in the list of agreements.
			@param	entity the ID of the third party that is the sender.
			@return	the row number is returned (0....n)
			@version 4.5.2
			*/
			long			GetAgreementRow(int allotment, long currency, long entity) const;

			/**Retrieves the Note for the first agreement that matches the criteria
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the note is stored here on returning.
			@param	size the size the buffer should be.
			@version 4.5.2
			*/
			void			GetAgreementNote(int allotment, char *buffer, int size) const;

			/**Retrieves the Credit Details for the first agreement matched.
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the details are stored here on returning.
			@param	size the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementCreditDetails(int allotment, char *buffer, int size) const;

			/**Retrieves the name of the Credit Document for the first agreement matched.
			@param	allotment is the allotment to search for in the agreements.
			@param	buffer the name of the document is stored here on returning.
			@param	size set the size required for the buffer.
			@version 4.5.2
			*/
			void			GetAgreementCreditDocument(int allotment, char *buffer, int size) const;




			/**Retrieves the netting list defined for the Third party.
			@return	a CSREditList of the netting list that is defined.
			@version 4.5.2
			*/
			sophis::gui::CSREditList*	GetNettingList() const;




			// Write Methods

			/**Sets the reference for this third party
			@param	reference string of the reference to be stored.
			@version 4.5.2
			*/
			void			SetReference(char *reference);

			/**Sets the name for this third party
			@param	name string of the name to be stored.
			@version 4.5.2
			*/
			void			SetName(char *name);

			/**Sets the legal name for this third party
			@param	name string of the name to be stored.
			@version 4.5.2
			*/
			void			SetLegalName(char *name);

			/**Sets the location for this third party
			@param	location string of the location to be stored.
			@version 4.5.2
			*/
			void			SetLocation(char *location);

			/**Sets the domicile for this third party
			@param	domicile string of the domicile to be stored.
			@version 4.5.2
			*/
			void			SetDomicile(char *domicile);

			/**Sets the comment for this third party
			@param	comment string of the comment to be stored.
			@version 4.5.2
			*/
			void			SetComment(char *comment);

			/**Sets the external reference for this third party
			@param	extRef string of the external reference to be stored.
			@version 4.5.2
			*/
			void			SetExternalReference(char *extRef);

			/**Sets the code of the share issued by the third party.
			@param	internal code of the instrument.
			@version 4.5.2
			*/
			void			SetIssuedShareCode(long code);

			/**Sets whether this is a group or not
			@param	state true if it is a group
			@version 4.5.2
			*/
			void			SetGroup(bool state);

			/**Sets whether this third party is a counterparty or not
			@param	state true if it is a counterparty.
			@version 4.5.2
			*/
			void			SetCounterparty(bool state);

			/**Sets whether this third party is a broker or not
			@param	state true if it is a broker.
			@version 4.5.2
			*/
			void			SetBroker(bool state);

			/**Sets whether this third party is a depositary or not
			@param	state true if it is a depositary.
			@version 4.5.2
			*/
			void			SetDepository(bool state);

			/**Sets whether this third party is a customer or not
			@param	state true if it is a customer.
			@version 4.5.2
			*/
			void			SetCustomer(bool state);

			/**Sets whether this third party is a PSET (Place of Settlement) or not
			@param	state true if it is a customer.
			@version 5.2.4
			*/
			void			SetPSET(bool state);

			/**Sets whether this third party is a Clearing House or not
			@param	state true if it is a Clearing House.
			@version 7.1.0
			*/
			void			SetClearingHouse(bool state);

			/**Sets whether this third party is a Clearing Member or not
			@param	state true if it is a Clearing Member.
			@version 7.1.0
			*/
			void			SetClearingMember(bool state);

			/**Sets the LEI value
			@param	lei .
			@version 7.1.1
			*/
			void			SetLEI(const char *lei);

			/**Sets the usi_namespace value
			@param	usi .
			@version 7.1.1
			*/
			void			SetUSINamespace(const char* usi);

			/**Sets whether this third party is a Designated Trade Repository or not
			@param	state true if it is a Trade Repository.
			@version 7.1.1
			*/
			void			SetTradeRepositary(bool state);

			/**Sets whether this third party is a Reporting Party or not
			@param	state true if it is a Reporting Party.
			@version 7.1.1
			*/
			void			SetReportingParty(bool state);

			/**Sets whether this third party is an Execution Venue or not
			@param	state true if it is an Execution Venue.
			@version 7.1.1
			*/
			void			SetExecutionVenue(bool state);

			/**Sets this third party Swap Role (End User,Major Swap Participant,Swap Dealer)
			@param	role (should be between 1..3)
			@version 7.1.1
			*/
			void			SetSwapRole(long role);

			/**Sets whether this third party is corporate or not
			@param	state true if it is corporate.
			@version 4.5.2
			*/
			void			SetCorporate(bool state);

			/**Sets whether this third party is an exchange or not.
			@param	state true if it is an exchange.
			@version 4.5.2
			*/
			void			SetExchange(bool state);

			/**Sets whether this third party is an institution or not.
			@param	state true if it is an institution.
			@version 4.5.2
			*/
			void			SetInstitution(bool state);

			/**Sets whether this third party is another type or not.
			@param	state true if it is another type.
			@version 4.5.2
			*/
			void			SetOther(bool state);

			/**Sets whether this third party is a bank or not.
			@param	state true if it is a bank.
			@version 4.5.2
			*/
			void			SetBank(bool state);

			/**Sets the bank type.
			@param	type enum stating the bank type.
			@version 4.5.2
			*/
			void			SetBankType(eBankType type);

			/**Sets whether this third party is an entity or not.
			@param	state true if it is an entity.
			@version 4.5.2
			*/
			void			SetEntity(bool state);

			/**Sets the market tax to true or false.
			@param	state the state to set market tax to.
			@version 4.5.2
			*/
			void			SetMarketTax(bool state);

			/**Sets the gross price to true or false.
			@param	state the state to set gross price to.
			@version 4.5.2
			*/
			void			SetGrossPrice(bool state);

			/**Sets the average price to true or false.
			@param	state the state to set average price to.
			@version 4.5.2
			*/
			void			SetAveragePrice(bool state);

			/**Sets the language of the third party
			@param	state the state to set market tax to.
			@version 4.5.2
			*/
			void			SetLanguage(char *language);

			/**Sets whether this third party is a custodian or not.
			@param	state true if it is a custodian.
			@version 4.5.2
			*/
			void			SetCustodian(bool state);

			/**Sets whether this third party is an investment bank or not.
			@param	state true if it is an investment bank.
			@version 4.5.2
			*/
			void			SetInvestment(bool state);

			/**Sets whether this third party is a merchant bank or not.
			@param	state true if it is a merchant bank.
			@version 4.5.2
			*/
			void			SetMerchant(bool state);

			/**Sets whether this third party is a savings bank or not.
			@param	state true if it is a savings bank.
			@version 4.5.2
			*/
			void			SetSavings(bool state);



			/**Sets the short code for the third party
			@param	code the text for the short code.
			@version 4.5.2
			*/
			void			SetShortCode(char *code);

			/**Sets the swift code for the third party
			@param	code the text for the swift code.
			@version 4.5.2
			*/
			void			SetSwiftCode(char *code);

			/**Sets the ISIN code for the third party
			@param	code the text for the ISIN code.
			@version 4.5.2
			*/
			void			SetISINCode(char *code);

			/**Sets the phone number for the third party
			@param	phone the phone number.
			@version 4.5.2
			*/
			void			SetPhoneNumber(char *phone);

			/**Sets the fax number for the third party
			@param	fax the fax number.
			@version 4.5.2
			*/
			void			SetFaxNumber(char *fax);

			/**Sets the telexx number for the third party
			@param	telex the telex number.
			@version 4.5.2
			*/
			void			SetTelexNumber(char *telex);

			/**Sets the email address for the third party
			@param	email the email address.
			@version 4.5.2
			*/
			void			SetEmailAddress(char *email);

			/** Sets third party's site 
			@param site - site to set
			@version 5.2
			*/
			void			SetSite( long site);

			/**Sets the first line for the address for the third party
			@param	line the first line.
			@version 4.5.2
			*/
			void			SetAddress1(char *line);

			/**Sets the second line for the address for the third party
			@param	line the second line.
			@version 4.5.2
			*/
			void			SetAddress2(char *line);

			/**Sets the third line for the address for the third party
			@param	line the third line.
			@version 4.5.2
			*/
			void			SetAddress3(char *line);

			/**Sets the fourth line for the address for the third party
			@param	line the fourth line.
			@version 4.5.2
			*/
			void			SetAddress4(char *line);

			/**Sets the fifth line for the address for the third party
			@param	line the fifth line.
			@version 4.5.2
			*/
			void			SetAddress5(char *line);

			/**Retrieves the currency associated with the third party for Accounting purposes.
			@return	the id of the currency defined.
			@version 4.5.2
			*/
			long	GetCurrency() const;

			/**Retrieves the account for the general ledger for Accounting purposes.
			@return	the account number of the general ledger associated with the third party.
			@version 4.5.2
			*/
			long	GetGeneralLedgerAccount() const;

			/**Retrieves the account number for the market fees.
			@return	the account number to be used for the market fees.
			@version 4.5.2
			*/
			long	GetMarketFeesAccount() const;

			/**Retrieves a long value from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@return	the long value is returned from the fucntion
			@version 4.5.2
			*/
			long	GetLongInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition) const;

			/**Retrieves a string from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@param	buffer this where the resulting string is stored.
			@param	size specify here the size that the buffer should be.
			@version 4.5.2
			*/
			void	GetStringInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition, char *buffer, int size) const;

			/**Retrieves a date as a long value from the database given some search criteria.
			@param	szField the column that is to returned.
			@param	szTable the table that is being queried.
			@param	szKey the key of the table that is to be used in the 'where' part of the query.
			@param	szCondition the 'where' clause for the query.
			@return	the long value is returned from the fucntion
			@version 4.5.2
			*/
			long	GetDateInfo(const char *szField, const char *szTable, const char *szKey, char *szCondition) const;





			typedef void *WindowPtr;

			/**Retrieves the number of third parties that are entities.
			@return	the number of entities found in the third parties.
			@version 4.5.2
			*/
			static long 					GetEntityCount();

			/**Retrieves the nth Entity in the list of entities
			@param	which given n entities, this can be a number anywhere from 1 to n.
			@return	returns a pointer to the third party that is an entity or NULL if it is not found.
			@version 4.5.2
			*/
			static const CSRThirdPartyDlg*		GetNthEntity(int which);

			/**Specify the third party to edit.
			@param	thirdPartyId the id of the third party.
			@version 4.5.2
			*/
			static void						EditThirdParty(long thirdPartyId);

			/**Get the number of third parties of a specific type.
			@param	thirdtype enum specifying which type of third party to count.
			@version 4.5.2
			*/
			static long 					GetThirdPartyCount(eThirdPartyType thirdtype);

			/**Get the nth third party of a specific type.
			@param	lequel specify a number from 1...n where n is the number of third parties.
			@param	thirdtype enum specifying which type of third party to get.
			@return	returns a pointer to the third party that is of the given type.
			@version 4.5.2
			*/
			static const CSRThirdPartyDlg*		GetNthThirdParty(int lequel, eThirdPartyType thridtype);

			/**Retrieve a third party by name.
			@param	name the name of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given name.
			@version 4.5.2
			*/
			static CSRThirdPartyDlg*	GetCSRThirdParty(char* name);

			/**Retrieve a third party by reference.
			@param	ref the reference of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given reference.
			@version 4.5.2
			*/
			static CSRThirdPartyDlg*	GetCSRThirdPartyByReference(char* ref);

			/**Retrieve a third party by external reference.
			@param	extRef the external reference of the third party that is to be retrieved.
			@return	returns a pointer to the third party with the given external reference.
			@version 4.5.2
			*/
			static CSRThirdPartyDlg*	GetCSRThirdPartyByExternalRef(char* extRef);

			/**Retrieve the id of the icon associated with the third party.
			@return	the id of the third party's icon.
			@version 4.5.2
			*/
			short			GetIconNumber() const;	//internal

			/**Retrieve the categorization menu value.
			@return	the value of categorization in the MiFID tab.
			@version 6.1
			*/
			eMiFIDCategorization GetMiFIDCategorization() const;
			/**Retrieve the reporter menu value.
			@return	the value of reporter in the MiFID tab.
			@version 6.1
			*/
			eMiFIDReporter GetMiFIDReporter() const;
			/**Retrieve the trading capacity menu value.
			@return	the value of trading capacity in the MiFID tab.
			@version 6.1
			*/
			eMiFIDTradingCapacity GetMiFIDTradingCapacity() const;
			/**Set the categorization menu value.
			@version 6.1
			*/
			void SetMiFIDCategorization(eMiFIDCategorization value);
			/**Set the reporter menu value.
			@version 6.1
			*/
			void SetMiFIDReporter(eMiFIDReporter value);
			/**Set the trading capacity menu value.
			@version 6.1
			*/
			void SetMiFIDTradingCapacity(eMiFIDTradingCapacity value);


			// *********************************************************************
			// Some API calls that allow the modification of thirdparties
			// without needs the UI (although it does use some of the existing UI
			// interfaces and classes). To use any of the "Set" method calls the
			// object must be cloned via the Clone() method


			sophis::gui::CSRFitDialog* CSRThirdPartyDlg::GetDialog() const;

			/**
			* Build and load the internal objects & UI object needed to hold the
			* thirdparty data. 
			* @return true if loaded otherwise false.
			*/
			bool Load () const;   

			/**
			* Build and load the internal objects & UI object needed to hold the
			* thirdparty data when we are in Front Office mode. 
			* @return true if loaded otherwise false.
			*/
			bool LoadFrontOffice () const;

			/**
			* Save any changes made to a new or existing Thirdparty. This save
			* is for use via the API, as it bypasses much of the UI functionality
			* @param	mode specifies whether the save is being carried out by the API(default) or GUI
			* @throws VoteException if one CSRThridPartyAction rejects modifications. Note that in such a case
			* no modification of the database has been done so that your previous save are still correct.
			*/
			void Save (eSavingMode mode = smApi) 
				throw (sophis::tools::VoteException);

			/**
			* Requests every 'action' registered, to vote for save, but do not perform any
			* real saving.
			* @throw	VoteException If any action rejected the vote.
			*/
			void validate()
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);

			/**
			* Requests every 'action' registered, to vote for removal, but do not perform any
			* real saving.
			* @throw	VoteException If any action rejected the vote.
			*/
			void validateForRemoval()
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);

			/**
			* Remove an existing ThirdParty via the API, if the code is not
			* specified, then the one passed in the ctor is used (if not 0)
			* @param	mode specifies whether the remove is being carried out by the API(default) or GUI
			*/
			void Remove(eSavingMode mode = smApi) 
				throw (sophis::tools::VoteException);            

			/**
			* Transfer Thirdparty elements from one group to another
			* within the management structure
			* @params nbElem the number of elements to move
			* @params TabElem pointer to the elements being moved
			*/
			void Transfer(int nbElem, LONG_PTR *TabElem) const throw (sophis::tools::VoteException);

			/**
			* Clone and return a new instance of an existing Thirdparty which can be 
			* modified outside the UI through API calls
			* @params if load is true the internal dialog is loaded
			*/
			CSRThirdPartyDlg* Clone(bool load = true) const;

			/**
			* Used to determine if the object is a Clone 
			* @return   true if object is clone
			*/
			bool IsClone() const;

			/**
			* Load the list specified by the "type" argument, if the list
			* is already loaded then it just returns.
			* @param	thirdtype enum specifying which type of third party tab
			*/
			void LoadList(int type) const;

			/**
			* Load all the internal TAB dialog data which is associated with each of
			* the six dialog tabs.
			*/
			void LoadAllLists();

			/**
			* Returns true if the thirdpart dialog and been created and the default
			* tabs are loaded (.i.e the first two), otherwise false
			* @return   true is loaded
			*/
			bool IsLoaded() const;


			/**
			* Returs true if the lists in the specified specified tab are
			* loaded, otherwise false.
			* @param	thirdtype enum specifying which type of third party tab
			* @return   true is loaded
			*/

			bool IsListLoaded(int type) const;

			/**
			* Used to destroy the Thirdparty internal dialog when a tcp message
			* is recieved, indicating a change in the thirdparty. The next time the
			* thirdparty is used the dialog is rebuilt.
			*/
			void DestroyDialogue();

			/**
			* Can be called instead of Load to only create the Thirdpartydialog
			* Tabs object. The pointer can them be retrieved to activate the
			* dialog (enable the use of all GUI objects)
			* @thirdPartyGroup group id which will be used as a parent for a newly created thirdparty
			*/
			bool CreateDialogOnly(bool usingFE, long thirdPartyGroup = -1) const;

			void SetModified(int tab);

			/**
			* Reserve the code for a new thirdparty (which is different than setCode())
			* After a call to reserveCode() the ThirdParty is still considered as a
			* 'new' one.
			* This is useful when the ident has to be set just after thirparty
			* creation, and not when it is saved.
			* @param	code code to reserve when the thirdparty will be saved
			* @throw	InvalidInvocationOrder if the thirparty is not a new one, but an existing one.
			*/
			void reserveCode(long code);

			/**
			* @return	the reserved code by a previous call to reserveCode().
			* @return	0 if no code was reserved.
			*/
			long getReservedCode() const;


			bool IsNew() const { return fNew;}

			/**
			* An API call that returns the ThirdParty Dialog Tab which can be modified.
			* (only after cloning!!!)
			* @param	thirdtype enum specifying which type of third party tab
			* return    Tthe database diaglog to modify
			*/
			sophis::gui::CSRDatabaseDialog* GetThirdTabList(int type,bool doLoad = true) const;


			/** Save in a transaction mode.
			In this mode, you can save different data before commiting it to the database.
			It executes the insert or update query and fill the message.
			It is not commited or roll back. You must do it when all your data is saved.
			It is not sent to the other workstations. You must do it by messages. ExecuteAll().
			@param mode specifies whether the action is being carried out by the API or GUI.
			@param event_list is the event vector which will record all the messages to send after commiting.
			@throws VoteException if one CSRThirdPartyAction rejects that modification. Note that it is supposed that
			no modification of the database has been done so that your previous save are still correct
			and can be commited.
			@throws ExceptionBase if there is one problem when saving. Here you have to roll back all the previous modification.
			*/
			void MultiSave(eSavingMode mode, sophis::tools::CSREventVector &event_list)
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);


			/** Delete in a transaction mode.
			In that mode, you can delete different data before commiting in the database
			It executes the delete queries and fill the message.
			It is not commited or roll back. You must do it when all your data is saved
			It is not sent to the other workstations. You must do it by messages.ExecuteAll()
			@param mode specifies whether the action is being carried out by the API or GUI.
			@param messages is the event vector which will record all the messages to send after commiting.
			@throws VoteException if one CSRThirdPartyAction rejects that modification. Note that it is supposed that
			no modification of the database has been done so that your previous save are still correct
			and can be committed
			@throws ExceptionBase if there is one problem when saving. Here you have to roll back all the previous modification.
			*/

			void MultiDelete(eSavingMode mode, sophis::tools::CSREventVector	&event_list) const
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);


			/** Transfer in a transaction mode.
			In that mode, you can delete different data before commiting in the database
			It executes the delete queries and fill the message.
			It is not commited or roll back. You must do it when all your data is saved
			It is not sent to the other workstations. You must do it by messages.ExecuteAll()
			@param messages is the event vector which will record all the messages to send after commiting.
			@throws VoteException if one CSRThirdPartyAction rejects that modification. Note that it is supposed that
			no modification of the database has been done so that your previous save are still correct
			and can be committed
			@throws ExceptionBase if there is one problem when saving. Here you have to roll back all the previous modification.
			*/

			void MultiTransfer(sophis::tools::CSREventVector	&event_list,
				int nbElem, LONG_PTR *TabElem) const
				throw (sophis::tools::VoteException,sophisTools::base::ExceptionBase);

			/**
			* Serializes party description into a Data
			* Fills directly the data with the party description
			* @since 5.3
			*/
			void Describe(tools::dataModel::Data & data) const;

			/**
			* Serializes party description into a DataSet
			* Creates a sub element "party" (type "Party") to the DataSet and fills it with the description
			* Cf. grammar "www.sophis.net/party" in party.xsd for this type
			*/
			void Describe(tools::dataModel::DataSet& dataSet) const;

			/**
			* Serializes party identifiers into a Data
			* Fills directly the data with the party identifiers
			* @since 5.3
			*/
			void DescribeIdentifier(tools::dataModel::Data & data) const;

			/**
			* Same as before but with the possibility to exclude the custom identifiers
			* @since 7.1
			*/
			void DescribeIdentifier(tools::dataModel::Data & data, bool includeCustom) const;

			/**
			* Serializes party identifiers into a DataSet
			* Creates a sub element "partyReference" (type "PartyReference") to the DataSet and fills it with the identifiers
			* Cf. grammar "www.sophis.net/party" in party.xsd for this type
			*/
			void DescribeIdentifier(tools::dataModel::DataSet& dataSet) const;

			/**
			* Same as before but with the possibility to exclude the custom identifiers
			* @since 7.1
			*/
			void DescribeIdentifier(tools::dataModel::DataSet& dataSet, bool includeCustom) const;

			/**
			* Update a party from a Data
			* @param data : can be an element "party" (type "Party") or an other element. In this last case,
			* data is considered as a element of type "Party" (it has to contain directly elements of type "Party").
			* Cf. grammar "www.sophis.net/party" in party.xsd
			* @since 5.3
			*/
			void Update(const tools::dataModel::Data & data);

			/**
			* Update a party from a DataSet
			* @param data_set : must contain a element "party" (type "Party")
			* Cf. grammar "www.sophis.net/party" in party.xsd for these 2 types
			*/
			void Update(const tools::dataModel::DataSet& dataSet);

			/**
			* @throws DuplicatePartyException
			*/
			static CSRThirdPartyDlg * Create(const tools::dataModel::DataSet& dataSet);

			/**
			* Retrieves a party from a Data
			* @param data : can be an element "party" (type "Party") or "partyReference" (type "PartyReference")
			* or an other element. In this last case, data is considered as a element of type "PartyReference" (it has to contain
			* directly partyId element(s)).
			* Cf. grammar "www.sophis.net/party" in party.xsd
			* @param exceptionIfNotFound : if true, if party not found throws a NoSuchData exception (default=true)
			* @since 5.3
			*/
#ifndef GCC_XML
			static const CSRThirdPartyDlg * Find(const tools::dataModel::Data & data, bool exceptionIfNotFound = true)
				throw (sophis::tools::dataModel::DataModelException,sophisTools::base::ExceptionBase);
#endif
			/**
			* Retrieves a party from a DataSet
			* @param data_set : must contain a element "party" (type "Party") or "partyReference" (type "PartyReference")
			* Cf. grammar "www.sophis.net/party" in party.xsd for these 2 types
			* @param exceptionIfNotFound : if true, if party not found throws a NoSuchData exception (default=true)
			* @throws sophis::tools::dataModel::InvalidDataValue if data_set does not contain a good element
			*/
			static const CSRThirdPartyDlg * Find(const tools::dataModel::DataSet & data_set, bool exceptionIfNotFound = true);

		public:
			bool LoadGeneralElement(int ERId_Element, void *address) const; 
			bool SaveGeneralElement(int ERId_Element, void *address) const; 

			bool LoadGeneralElement(int ERId_List, int lineNumber, int CNb_Column, void *address) const; 
			bool SaveGeneralElement(int ERId_List, int lineNumber, int CNb_Column, void *address) const; 

			int		GetGeneralLineCount(int 	ERId_List) const;
			bool SaveGeneralLineCount(int ERId_List, int newLineCount); 
			bool DeleteGeneralLine(int ERId_List, int lineNumber); 

			/**
			* This method should not be called directly, it is used internally 
			* for cloning.
			*/
			void SetSSThirdparty(SSThirdParty* value);

			SSThirdParty* GetSSThirdparty() const;

			CSTiers* GetCSTiers() const;

			/**
			* Used internally
			*/
			void SetListLoaded(int type, bool loaded = true) const;

			long GetAltFees() const;
			void SetAltFees( long altFees);

		public:
			DECLARATION_CASTAGE2

		protected:
			void Initialize(SSThirdParty* tiers);
			void Initialize(const CSTiers* tiers);

		private:

			/**
			* Used internally to determine if we have access
			* to a tab page
			*/
			bool HasAccessToTab(int type) const;

			/**
			* Used internally to alter the selction value if some
			* of the tabs have not been loaded
			*/
			int ShiftSelection(int type) const;

			/**
			* Used internally
			*/
			sophis::gui::CSRDatabaseDialog* GetRawTabList(int type) const;

			/**
			* Used internally
			*/
			void SetDialogue(sophis::gui::CSRFitDialog* dlg) const;

			/**
			*  Unloads internal UI structure without saving
			*/
			void UnLoad();

			/*
			* Gets the element of type specified from the tab requested.
			*/
			template <typename tabClass, typename elementClass>
			elementClass* GetThirdTabElementByRelativeId(eThirdPartyTabs tabID, short elementID) const;


			// Used for cloning
			CSRThirdPartyDlg(const CSRThirdPartyDlg* original);

			SSThirdParty						*fThirdParty;
			mutable const CSTiers				*fCTiers;
			mutable sophis::gui::CSRFitDialog	*fThirdTabs;
			long								fCode;
			bool								fIsClone, fNew;
			mutable	_STL::map<int, bool>		fLoadedLists;
			long								fReservedCode;
			long								fAlternativeThirdFees;

			_SOPHIS_DEPRECATED("Use CSRBackOfficeKernelUI::ThirdPartyDlg::GetInstance instead") static const CSRThirdPartyDlg *GetInstance(const CSWindow * window, LONG_PTR id);
			_SOPHIS_DEPRECATED("Use CSRBackOfficeKernelUI::ThirdPartyDlg::ShowWindow instead") static void	ShowWindow(eThirdGuiFilterMode filterMode);
			_SOPHIS_DEPRECATED("Use CSRBackOfficeKernelUI::ThirdPartyDlg::OpenDialog instead") void OpenDialog() const;
		};

	}  //namespace backoffice_kernel
}  // namespace



SPH_EPILOG

#endif
