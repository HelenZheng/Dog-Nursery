
/*
 	File:		SphThirdPartyEnums.h
 
 	Contains:	Enums of third party.
 
 	Copyright:	� 1995-2003 Sophis.
 
*/

#pragma once

#ifndef _SPH_THIRD_PARTY_ENUMS_H_
#define _SPH_THIRD_PARTY_ENUMS_H_

#include "SphInc/SphMacros.h"

/** This is the define for the length of a counteraprty name.
@since 5.3 was 40, becomes 80
*/
#define COUNTERPATY_NAME_SIZE 80

SPH_PROLOG
namespace sophis	{ 
	namespace backoffice_kernel	{

		/** Third party enums.
		*/
		enum eThirdPartyType 
		{
			/** Used only for {@link CSRThirdPartyMenu}
			*/
			ttAll = -1,

			ttGroup,
			ttCounterparty,
			ttBroker,
			ttDepositary,
			ttClient,
			ttBank,
			ttCorporate,
			ttExchange,
			ttSupranational,
			ttOther,
			ttPSET,			
			ttClearingHouse,
			ttClearingMember,
			ttReportingCtpy,
			ttExecutionVenue,
			ttTradeRepository
		};

		/** Filter mode on the third party list window.
		Each enum corresponds to a bit on an integer defining the filter.
		@version 4.4.1.2 available to toolkit
		*/
		enum  eThirdGuiFilterMode
		{
			mfNone				= 0x0000,
			mfClients			= 0x0001,
			mfCounterpart		= 0x0002,
			mfBroker			= 0x0004,
			mfDepositary		= 0x0008,
			mfPSET				= 0x0010, 
			mfClearingHouse		= 0x0020, 
			mfClearingMember	= 0x0040, 
			mfExecutionVenue	= 0x0080, 
			mfTradeRepository	= 0x0100, 
			mfAll				= 0xFFFF
		};

		/**
			Where Third Party is assigned to
		*/
		enum  eThirdPartySite
		{
			tptNotDefined = -1,
			tptInternal = 0,
			tptDomestic,
			tptInternational,
		};
		
		/**
		 * Enumeration of the main third party base tab.
		 */
		enum eThirdTab
		{
			ttThirdParty = 1
		};

		/**
		 * Enumeration of all the tabs in a third party.
		 */
		enum eThirdPartyTabs
		{
			tptGeneralTab,
			tptAddressTab,
			tptSettlementTab,
			tptDocGenerationTab,
			tptAgreementsTab,
			tptNettingTab,
			tptMiFIDTab,
			tptMax
		};

		/**
		* The property list columns.
		*/
		enum ePropertyListColumns
		{
			plcName,
			plcValue
		};

		/**
		* The contact list columns.
		*/
		enum eContactListColumns
		{
			clcTitle,
			clcContact,
			clcAddress,
			clcPhone,
			clcFax,
			clcTelex,
			clcEmail,
			clcDefaultClient,
			clcAllotment
		};

		/**
		* The settlement instruction columns.
		*/
		enum eSettlementListColumns
		{
			slcIdent,
			slcFinancialInst,
			slcRole,
			slcWorkflow,
			slcDeliveryType,		

			slcStartValidity,		
			slcEndValidity,		
			slcCurrency,
			slcMarket,
			slcDepositary,

			slcSign,				
			slcAllotment,		
			slcAccountType,
			slcPaymentMethod,
			slcTreasuryId,

			slcAccountName,			
			slcCustodianID,			
			slcCustodianSwift,			
			slcAccountCustodian,	
			slcAgentID,		

			slcAgentSwift,		
			slcAccountAgent,
			slcCountryCode,			
			slcUnderlyingAllotment,	
			slcUnderlyingCurrency, 

			slcUnderlyingMarket,
			slcBusinessEvent,
			slcPSET,				
			slcCondition,
			slcCondition2,

			slcCondition3,
			slcCarveOut,
			slcSSIPathId, //hidden column, not present on dialog. add new columns before this one
			slcColumnLast
		};

		/**
		* The document generation columns.
		*/
		enum eDocumentGenerationColumns
		{
			dgcSourceType,
			dgcAllotment,
			dgcTemplateName,
			dgcMessageStatus,
			dgcCurrency,
			dgcEntity,
			dgcDepository,
			dgcEvent,
			dgcSign,
			dgcRecipientType,
			dgcAmountType,
			dgcPostingDate,
			dgcMethod,
			dgcCondition,
			dgcContact,
			dgcAddress,
			dgcCondition2,
			dgcCondition3,
			dgcDepofCpty,

			dgcColumnCount
		};

		/**
		* The agreements list columns.
		*/
		enum eAgreementsListColumns
		{
			alcAllotment,
			alcTermCurrency,
			alcEntity,
			alcAgreement,
			alcAgreementVersDate,
			alcLaw,
			alcEffectDate,
			alcAmmendDate,
			alcContactName,
			alcContactPhone,
			alcContactFax,
			alcTermComment,
			alcNote,
			alcCreditDetails,
			alcCreditDocument,
			alcClearingHouse,
			alcClearingMember
		};

		/**
		* The columns for netting.
		*/
		enum eNettingColumns
		{
			ncEntity,
			ncCurrency,
			ncAllotment,
			ncMethod,
			ncMarket,
			ncPosition,
			ncSign,
			ncGroup,
			ncSameInstrument,
			ncSourceType,
			ncCondition1,
			ncCondition2,
			ncCondition3,
			ncColumnLast,
		};

		/**
		* MiFID Categorization
		*/
		enum eMiFIDCategorization {
			mfdRetail = 1, 
			mfdProfessional, 
			mfdEligibleCounterparty,

			mfdTKCategorization = 100
		};

		/**
		* MiFID Reporter
		*/
		enum eMiFIDReporter {
			mfdThird = 1, 
			mfdEntity,

			mfdTKReporter = 100
		};

		/**
		* MiFID Trading Capacity
		*/
		enum eMiFIDTradingCapacity {
			mfdOwnAccount = 1,
			mfdProprietaryAccount,
			mfdClientAccount,
			mfdAll,

			mfdTKTradingCapacity = 100
		};

		/**
		* Where modificactions are made
		*/
		enum eSavingMode
		{
			smApi = 1,
			smGui
		};
	}
}

SPH_EPILOG

#endif