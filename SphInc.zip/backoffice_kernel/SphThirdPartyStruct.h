#ifndef __SophisThirdPartyStruct_H__
#define __SophisThirdPartyStruct_H__

#include "SphInc/SphMacros.h"
#include "exception"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#include "SphInc/backoffice_kernel/SphThirdPartyToolkit.h"

#include "SphInc\tools\SphDescribable.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)
// Boost library is not managed by gcc_xml
#ifndef GCC_XML
	BOOST_INCLUDE_BEGIN
	#include BOOST_INCLUDE_PATH(unordered_map.hpp)
	BOOST_INCLUDE_END
#else
	#include __STL_INCLUDE_PATH(unordered_map)
#endif

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(memory)

SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
 
namespace sophis
{
	namespace gui
	{
		class CSRElement;
	}

	namespace backoffice_kernel
	{
		struct SOPHIS_FIT SSProperty
		{
			long			code;
			_STL::string	fPropertyName;
			_STL::string	fPropertyValue;
		};

		typedef _STL::shared_ptr<SSProperty>				SSThirdPartyPropertyPtr;
		typedef _STL::multimap<long, SSThirdPartyPropertyPtr>	SSThirdPartyPropertyList;
		typedef SSThirdPartyPropertyList::const_iterator		SSThirdPartyPropertyIter;


		struct SOPHIS_FIT SSThirdPartyGeneral 
		{
			long					code;
			long					fOption;
			long					fBankType;
			long					fParentID;
			_STL::string			fPartyReference;
			_STL::string			fPartyName;
			_STL::string			fLegalName;
			_STL::string			fPartyLocation;
			_STL::string			fPartyDomicile;
			long					fIssuedShareCode;
			_STL::string			fComments;
			_STL::string			fExternalReference;
			long					fPartySite;
			_STL::string			fPartyLanguage;

			_STL::string			fLEI;
			_STL::string			fUSINamespace;
			long					fSwapRole;
			bool					fISReportCpty;
			bool					fIsExecutionVenue;
			bool					fIsTradeRepo;

			bool	fIsGroup;
			bool	fIsCounterparty;
			bool	fIsBroker;
			bool	fIsDepositary;
			bool	fIsCustomer;
			bool	fIsPSET;
			bool	fIsCorporate;
			bool	fIsExchange;
			bool	fIsInternational;
			bool	fIsAnother;
			bool	fIsBank;
			bool	fIsEntity;
			bool	fIsClearingHouse;
			bool	fIsClearingMember;
			bool	fIsMarketTax;
			bool	fIsGrossPrice;
			bool	fIsAveragePrice;
			bool	fIsBankCustodian;
			bool	fIsBankInvestment;
			bool	fIsBankMerchant;
			bool	fIsBankSavings;
			bool	fAccessibleByUser;
			bool	fBrutOuNet;
			long*	fThirdPartyStub;
			SSThirdPartyGeneral();
			~SSThirdPartyGeneral();
			SSThirdPartyGeneral(const SSThirdPartyGeneral&obj);
			SSThirdPartyGeneral& operator=(const SSThirdPartyGeneral&rhs);
		private : 
			void CopyObj(const SSThirdPartyGeneral&obj);
		};
		typedef _STL::shared_ptr<SSThirdPartyGeneral>		SSThirdPartyGeneralPtr;
		typedef _STL::map<long, SSThirdPartyGeneralPtr>			SSThirdPartyGeneralList;
		typedef SSThirdPartyGeneralList::const_iterator			SSThirdPartyGeneralIter;

		struct SOPHIS_FIT SSContact
		{
			long					code;
			_STL::string			fTitle;
			_STL::string			fContact;
			_STL::string			fAddress;
			_STL::string			fPhone;
			_STL::string			fFax;
			_STL::string			fTelex;
			_STL::string			fEmail;
			long					fDefaultClient;
			long					fAllotment;
		};

		typedef _STL::shared_ptr<SSContact>					SSThirdPartyContactPtr;
		typedef _STL::multimap<long, SSThirdPartyContactPtr>	SSThirdPartyContactList;
		typedef SSThirdPartyContactList::iterator				SSThirdPartyContactIter;

		struct SOPHIS_FIT SSThirdPartyContactInfo
		{
			long					code;
			_STL::string			fShortCode;
			_STL::string			fSwiftCode;
			_STL::string			fISIN;
			_STL::string			fAddress1;
			_STL::string			fAddress2;
			_STL::string			fAddress3;
			_STL::string			fAddress4;
			_STL::string			fAddress5;
			_STL::string			fMainPhone;
			_STL::string			fMainTelex;
			_STL::string			fMainFax;
			_STL::string			fMainEmail;
		};

		typedef _STL::shared_ptr<SSThirdPartyContactInfo>	SSThirdPartyMainContactPtr;
		typedef _STL::map<long, SSThirdPartyMainContactPtr>		SSThirdPartyMainContactList;
		typedef SSThirdPartyMainContactList::iterator			SSThirdPartyMainContactIter;

		struct SOPHIS_FIT SSThirdPartySettlement
		{			
            SSThirdPartySettlement()
                :code(0)
                ,fRow(0)
                ,fSettlement(0)			//slcIdent
                ,fFinancialInstitution(0)	//slcFinancialInst
                ,fPartyRole(0)				//slcRole
                ,fWorkflow(0)				//slcWorkflow
                ,fDeliveryType(0)			//slcDeliveryType
                ,fValidFrom(0)				//slcStartValidity
                ,fValidTo(0)				//slcEndValidity
                ,fCurrency(0)				//slcCurrency
                ,fMarket(0)				//slcMarket
                ,fDepositary(0)			//slcDepositary
                ,fSign(0)					//slcSign
                ,fAllotment(0)				//slcAllotment
                ,fAccountType(0)			//slcAccountType
                ,fPaymentMethod(0)			//slcPaymentMethod
                ,fSSIPathID(0)				//slcSSIPathId
                ,fTreasuryID(0)			//slcTreasuryId

                ,fCarveOut(0)				//slcCarveOut

                ,fUnderlyingAllotment(0)	//slcUnderlyingAllotment
                ,fUnderlyingCurrency(0)	//slcUnderlyingCurrency
                ,fUnderlyingMarket(0)		//slcUnderlyingMarket
                ,fBusinessEvent(0)			//slcBusinessEvent
                ,fSettlementPlace(0)		//slcPSET			
            {
            }

			long			code;
			long			fRow;
			long			fSettlement;			//slcIdent
			long			fFinancialInstitution;	//slcFinancialInst
			long			fPartyRole;				//slcRole
			long			fWorkflow;				//slcWorkflow
			long			fDeliveryType;			//slcDeliveryType
			long			fValidFrom;				//slcStartValidity
			long			fValidTo;				//slcEndValidity
			long			fCurrency;				//slcCurrency
			long			fMarket;				//slcMarket
			long			fDepositary;			//slcDepositary
			long			fSign;					//slcSign
			long			fAllotment;				//slcAllotment
			long			fAccountType;			//slcAccountType
			long			fPaymentMethod;			//slcPaymentMethod
			long			fSSIPathID;				//slcSSIPathId
			long			fTreasuryID;			//slcTreasuryId
			_STL::string	fAccountName;			//slcAccountName
			_STL::string	fCustodianCode;			//slcCustodian
			_STL::string	fAccountCustodian;		//slcAccountCustodian
			_STL::string	fAgentCode;				//slcAgentCode
			_STL::string	fAccountAgent;			//slcAccountAgent
			_STL::string	fCountryCode;			//slcCountryCode
			_STL::string	fPortfolio;				//---
			long			fCarveOut;				//slcCarveOut

			long			fUnderlyingAllotment;	//slcUnderlyingAllotment
			long			fUnderlyingCurrency;	//slcUnderlyingCurrency
			long			fUnderlyingMarket;		//slcUnderlyingMarket
			long			fBusinessEvent;			//slcBusinessEvent
			long			fSettlementPlace;		//slcPSET			
			_STL::string	fCondition;				//slcCondition
			_STL::string	fCondition2;				//slcCondition2
			_STL::string	fCondition3;				//slcCondition3			
		};


		/**
		 * Provide implementation if the extra data added to the standard settlement path
		 * Extra data needs to be describable (also have to store data), so all the describable virtual needs to be overridden
		 * @version 7.1.2.6
		 */
		class SOPHIS_FIT ISRThirdPatrySettlementPathExtraData : public sophis::tools::ISRDescribable
		{
		public:
			ISRThirdPatrySettlementPathExtraData() {}
			virtual ~ISRThirdPatrySettlementPathExtraData() {}
			virtual ISRThirdPatrySettlementPathExtraData * Clone() const = 0;
			
			//return 0 when equal
			virtual long Compare(const ISRThirdPatrySettlementPathExtraData & other) const = 0;

			virtual int GetFieldCount() const {return 0;}

			virtual void GetField(int i, Field& field) const
				throw (InvalidRangeException) {}

			virtual void SetField(int i, const Field & field){}

			/* used by the framework when setting elements from the UI */
			virtual void SetField(int i, const sophis::gui::CSRElement & element) {}
		};
		
		
		/* Support class to handle extra data creation
			* Handler is a singleton and can be replaced via toolkit
			* @version 7.1.2.6
		*/
		class SOPHIS_FIT CSRThirdPartySettlementPathExtraDataHandler
		{
		public:
			//will release previously registered handler
			static void RegisterThirdPartySettlementPathExtraDataHandler(const CSRThirdPartySettlementPathExtraDataHandler * handler);
			static const CSRThirdPartySettlementPathExtraDataHandler * GetThirdPartySettlementPathExtraDataHandler();

			virtual int GetThirdPartySettlementPathExtraDataFieldCount() const;
			//has to contain all the empty fields (GetFieldCount is used)
			virtual ISRThirdPatrySettlementPathExtraData * new_ThirdPartySettlementPathExtraData() const;

			/* called by the framework when getting the settlement line data, in the override can populate extra data based on the settlement line */
			virtual void FillThirdPartySettlementPathExtraData(ISRThirdPatrySettlementPathExtraData * extradata, const SSThirdPartySettlement & settlementline) const {};
		};

		class SOPHIS_FIT SSThirdPartySettlementPath
		{
		public:
			SSThirdPartySettlementPath();
			SSThirdPartySettlementPath(long SSIPathId, long TreasuryAccountId, _STL::string Thirdparty, _STL::string AccountName, _STL::string Custodian, _STL::string CountryCode, _STL::string AccountAtCustodian, _STL::string AgentCode, _STL::string AccountAtAgent, ISRThirdPatrySettlementPathExtraData * ExtraData = NULL);
			SSThirdPartySettlementPath(const SSThirdPartySettlementPath & other);
			virtual ~SSThirdPartySettlementPath();
			
			SSThirdPartySettlementPath & operator=(const SSThirdPartySettlementPath & other);
			
			long fSSIPathId;
			long fTreasuryAccountId;
			_STL::string fThirdparty;
			_STL::string fAccountName;
			_STL::string fCustodian;
			_STL::string fCountryCode;
			_STL::string fAccountAtCustodian;
			_STL::string fAgentCode;
			_STL::string fAccountAtAgent;
			ISRThirdPatrySettlementPathExtraData * fExtraData;
			
		};

		class SOPHIS_FIT CSRThirdPartySettlementPathCache
		{
		public:
			static bool GetThirdPartySettlementPath(long ssiPathId, SSThirdPartySettlementPath & ssiPath, bool load = true);
			static bool GetThirdPartySettlementPathReverseLookup(SSThirdPartySettlementPath & ssiPath, const ISRThirdPatrySettlementPathExtraData * extraFields, bool load = true);
			static bool GetThirdPartySettlementPath(long nostroAccountId, long & ssiPath, bool load = true);
		};


		typedef _STL::shared_ptr<SSThirdPartySettlement>	SSThirdPartySettlementPtr;
		typedef _STL::list<SSThirdPartySettlementPtr>		SSThirdPartySettlementPtrList;
		typedef _STL::vector<SSThirdPartySettlementPtr>		SSThirdPartySettlementVector;
		typedef _STL::multimap<long, SSThirdPartySettlementPtr>	SSThirdPartySettlementList;
		typedef SSThirdPartySettlementList::const_iterator	SSThirdPartySettlementIter;
		typedef _STL::map<long, SSThirdPartySettlementPtr>		SettlementMapping;
		typedef SettlementMapping::const_iterator				SettlementMappingIter;

		struct SOPHIS_FIT SSThirdPartyConfirmation
		{
			long				code;
			long				fAllotment;			//dgcAllotment
			long				fTemplateName;		//dgcTemplateName
			long				fMessageStatus;		//dgcMessageStatus
			long				fCurrency;			//dgcCurrency
			long				fEntity;			//dgcEntity
			long				fDepositary;		//dgcDepository
			long				fEvent;				//dgcEvent
			long				fSign;				//dgcSign
			long				fRecipientType; 	//dgcRecipientType---msg_code
			_STL::string		fAmountType;		//dgcAmountType
			_STL::string		fPostingDate;		//dgcPostingDate
			long				fSendingMethod;		//dgcMethod
			_STL::string		fCondition1;		//dgcCondition
			_STL::string		fContact;			//dgcContact
			_STL::string		fAddress;			//dgcAddress
			_STL::string		fCondition2;		//dgcCondition2
			_STL::string		fCondition3;		//dgcCondition3
		};

		typedef _STL::shared_ptr<SSThirdPartyConfirmation>	SSThirdPartyConfirmationPtr;
		typedef _STL::multimap<long, SSThirdPartyConfirmationPtr>	SSThirdPartyConfirmationList;
		typedef SSThirdPartyConfirmationList::const_iterator	SSThirdPartyConfirmationIter;

		struct SOPHIS_FIT SSThirdPartyAgreement
		{
			long				code;
			long				fAllotment;				//alcAllotment
			long				fTerminationCurrency;	//alcTermCurrency
			long				fEntity;				//alcEntity - SENDER
			_STL::string		fAgreement;				//alcAgreement
			long				fAgreementVersionDate;	//alcAgreementVersDate
			_STL::string		fLaw;					//alcLaw
			long				fEffectiveDate;			//alcEffectDate
			long				fAmendmentDate;			//alcAmmendDate
			_STL::string		fContactName;			//alcContactName
			_STL::string		fContactPhone;			//alcContactPhone
			_STL::string		fContactFax;			//alcContactFax
			_STL::string		fTerminationComment;	//alcTermComment
			_STL::string		fNote;					//alcNote
			_STL::string		fCreditDetails;			//alcCreditDetails
			_STL::string		fCreditDocument;		//alcCreditDocument
			long				fClearingHouse;			//alcClearingHouse
			long				fClearingMember;		//alcClearingMember
		};

		typedef _STL::shared_ptr<SSThirdPartyAgreement>	SSThirdPartyAgreementPtr;
		typedef _STL::multimap<long, SSThirdPartyAgreementPtr>	SSThirdPartyAgreementList;
		typedef SSThirdPartyAgreementList::const_iterator	SSThirdPartyAgreementIter;

		struct SOPHIS_FIT SSThirdPartyNetting
		{
			long				code;
			long				fEntity;
			long				fCurrency;
			long				fAllotment;
			long				fPaymentMethod;
			long				fMarket;
			long				fSamePosition;
			long				fSign;
			long				fGroup;  // Confirmation or Payment
			long				fSameInsturment;
		};
		typedef _STL::shared_ptr<SSThirdPartyNetting>	SSThirdPartyNettingPtr;
		typedef _STL::multimap<long, SSThirdPartyNettingPtr>	SSThirdPartyNettingList;
		typedef SSThirdPartyNettingList::const_iterator	SSThirdPartyNettingIter;

		struct SOPHIS_FIT SSThirdPartyMiFID
		{
			long					code;
			eMiFIDCategorization    fCategorization	;   // mfdCategorization
			eMiFIDReporter          fReporter		;   // mfdReporter
			eMiFIDTradingCapacity   fTradingCapacity;   // mfdTradingCapacity
		};

		typedef _STL::shared_ptr<SSThirdPartyMiFID>	SSThirdPartyMiFIDPtr;
		typedef _STL::map<long, SSThirdPartyMiFIDPtr>	SSThirdPartyMiFIDList;
		typedef SSThirdPartyMiFIDList::const_iterator	SSThirdPartyMiFIDIter;
		typedef GCC_UNORDORED_NS::unordered_map<_STL::string, SSThirdPartyExtendedTkList> SSThirdPartyExtededTkListHMap;
		typedef SSThirdPartyExtededTkListHMap::iterator					 SSThirdPartyExtededTkListHMapIter;

		typedef _STL::vector<long>	KeyVector;
		typedef KeyVector::const_iterator KeyIter;

		/// Internal
		struct TSettlementCache;

		class SOPHIS_FIT CSRThirdPartyCache
		{
			friend class CSRThirdParty;
		protected:
			long		fCode;
			static const char*	__CLASS__;	

			static SSThirdPartyGeneralList			fGeneralList;		// 1-1
			static SSThirdPartyGeneralTkList		fGeneralTkList;
			static SSThirdPartyExtededTkListHMap	fExtendedTkListHMap;
			static SSThirdPartyMainContactList		fMainContactList;	// 1-1
			static SSThirdPartyMiFIDList			fMiFIDList;			// 1-1
			static SSThirdPartyContactList			fContactList;		// 1-n
			static SSThirdPartyPropertyList			fPropertyList;		// 1-n
			static SSThirdPartySettlementList		fSettlementList;	// 1-n  thirdparty_id->Settlemnt
			static SettlementMapping				fSettlementMapping;	// 1-1  settlement_id->Settlemnt
			static SSThirdPartyConfirmationList		fDocumentList;		// 1-n
			static SSThirdPartyAgreementList		fAgreementList;		// 1-n
			static SSThirdPartyNettingList			fNettingList;		// 1-n
		public:
			static bool LoadGeneral(bool bReload = false);
			static bool LoadSettlementList(long code, SSThirdPartySettlementList& settlementList, bool loadall = false);
		protected:
			static bool LoadGeneral(long code);
			static bool LoadGeneralTk(bool bReload = false);
			static bool LoadGeneralTk(long code);
			static bool LoadExtendedToolkit(_STL::string tkName, long code);
			static bool LoadPropertyList(long code);
			static bool LoadMainContact();
			static bool LoadMainContact(long code);
			static bool LoadContactList(long code);
			static bool LoadSettlementList(long code);
			static bool LoadSettlementByID(long SettlementID);
			static bool LoadConfirmationList(long code);
			static bool LoadAgreementList(long code);
			static bool LoadNettingList(long code);
			static bool LoadMiFID(long code);
			static void AssignSettlement(SSThirdPartySettlementPtr&to, TSettlementCache&from);
		public:

			static void	GetAllThirdPartyMenu(KeyVector& vec);
			static void	GetGroupMenu(KeyVector& vec);
			static void	GetCounterpartyMenu(KeyVector& vec);
			static void	GetBrokerMenu(KeyVector& vec);
			static void	GetDepositaryMenu(KeyVector& vec);
			static void	GetClientMenu(KeyVector& vec);
			static void	GetBankMenu(KeyVector& vec);
			static void	GetCorporateMenu(KeyVector& vec);
			static void	GetExchangeMenu(KeyVector& vec);
			static void	GetInternationalInstitutionMenu(KeyVector& vec);
			static void	GetOtherMenu(KeyVector& vec);
			static void	GetPSETMenu(KeyVector& vec);
			static void	GetEntityMenu(KeyVector& vec);

			static SSThirdPartyGeneralPtr			GetGeneral(long code);
			static SSThirdPartyGeneralTkPtr			GetGeneralTk(long code);
			static SSThirdPartyExtendedTkPtr		GetExtendedTk(_STL::string tkName, long code);
			static SSThirdPartyMainContactPtr		GetMainContact(long code);
			static SSThirdPartyMiFIDPtr				GetMiFID(long code);

			static bool	GetPropertyList		(long code, SSThirdPartyPropertyIter& start, SSThirdPartyPropertyIter& end);
			static bool GetContactList		(long code, SSThirdPartyContactIter& start, SSThirdPartyContactIter& end);
			static bool GetSettlementList	(long code, SSThirdPartySettlementIter& start, SSThirdPartySettlementIter& end);
			static SSThirdPartySettlementPtr	GetSettlementLine	(long SettlementLineID);

			static bool GetDocumentationGenerationList	(long code, SSThirdPartyConfirmationIter& start, SSThirdPartyConfirmationIter& end);
			static bool GetAgreementList	(long code, SSThirdPartyAgreementIter& start, SSThirdPartyAgreementIter& end);
			static bool GetNettingList		(long code, SSThirdPartyNettingIter& start, SSThirdPartyNettingIter& end);

			static bool SetAccessibilityByUser	(long code, bool bAccessible);
			static bool IsAccessibleByUser		(long code);
			static void SetBrutOuNet			(long code, bool BrutOuNet);
			static bool GetBrutOuNet			(long code);

			/** Change the given _STL::string into a System::String
			@param code Third party ID code for which child list is returned
			@param vec vector of thirdparties ID. Will be cleared inside the function and filled with the child of 'code' Third Party
			@return Returns nothing
			@version 7.1.3
			*/
			static void GetChildList			(long code, KeyVector& vec);

			CSRThirdPartyCache()
			{
				LoadGeneral();
			};
			virtual ~CSRThirdPartyCache()
			{
				ReleaseAll();
			};
			void Initialize()
			{
			}
			//
			// Cache all third parties
			//
			static void ReleaseAll()
			{
				fGeneralList.clear();
				fMainContactList.clear();	
				fMiFIDList.clear();			
				fContactList.clear();		
				fPropertyList.clear();		
				fSettlementList.clear();	
				fDocumentList.clear();	
				fAgreementList.clear();		
				fNettingList.clear();		
			}
		public:
			static long GetParent(long id);
			static long GetIdentByName(const _STL::string& name);
			static long GetIdentByRef(const _STL::string& ref);
			static long GetIdentByExternalRef(const _STL::string& ExtRef);
			static long GetIdentBySwiftCode(const _STL::string& SwiftCode);
			static const char* GetReference(long id);
			static const char* GetExternalReference(long id);
			static const char* GetName(long id);
			static const char* GetNameBySwiftCode(const _STL::string& SwiftCode);
			static const char* GetLegalName(long id);
			static const char* GetComment(long id);
			static const char* GetLocation(long id);
			static const char* GetDomicile(long id);
			static const char* GetLanguage(long id);

			static bool IsValid(long id);
			static bool IsActif(long id, long thirdPartyType);
			static bool IsGroup(long id);
			static bool IsCounterparty(long id);
			static bool IsBroker(long id);
			static bool IsDepositary(long id);
			static bool IsCustomer(long id);
			static bool IsPSET(long id);
			static bool IsClearingHouse(long id);
			static bool IsClearingMember(long id);
			static bool IsCorporate(long id);
			static bool IsExchange(long id);
			static bool IsInternational(long id);
			static bool IsOther(long id);
			static bool IsBank(long id);
			static bool IsBankType(long id, long BankType);
			static bool IsCustodianBank(long id);
			static bool IsInvestmentBank(long id);
			static bool IsMerchantBank(long id);
			static bool IsSavingBank(long id);
			static bool IsEntity(long id);
			static bool IsMarketTax(long id);
			static bool IsGrossPrice(long id);
			static bool IsAveragePrice(long id);
			static long GetIssuedShareCode(long id);
			static long GetSite(long id);
			static long GetEntityCount();
			static long GetNthEntity(long nIndex);
			static long GetThirdPartyCount(eThirdPartyType option);
			static long GetNthThirdParty(long nIndex, eThirdPartyType option);
			static long GetIconNumber(long id);
			static const char* GetShortCode(long id);
			static const char* GetSwiftCode(long id);
			static const char* GetISIN(long id);
			static const char* GetAddress1(long id);
			static const char* GetAddress2(long id);
			static const char* GetAddress3(long id);
			static const char* GetAddress4(long id);
			static const char* GetAddress5(long id);
			static const char* GetPhone(long id);
			static const char* GetTelex(long id);
			static const char* GetFax(long id);
			static const char* GetEmail(long id);

			static eMiFIDCategorization GetMiFIDCategorization(long id);
			static eMiFIDReporter GetMiFIDReporter(long id);
			static eMiFIDTradingCapacity GetMiFIDTradingCapacity(long id);
			
			static const char* GetLEI(long id);
			static const char* GetUSINamespace(long id);
			static long GetSwapRole(long id);
			static bool IsReportingCpty(long id);
			static bool IsExecutionVenue(long id);
			static bool IsTradeRepository(long id);

			static void ReInitThirdParty(void* ptrEvent);
		};

	}
}

SPH_END_NOWARN_EXPORT
SPH_EPILOG

#endif//__SophisThirdPartyStruct_H__
