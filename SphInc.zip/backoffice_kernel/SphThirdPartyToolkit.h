/*
 	File:		SphThirdPartyToolkit.h

 	Contains:	Base Class for third parties toolkit data cache.

 	Copyright:	� 2001-2011 Sophis.

*/

/*! \file SphThirdPartyToolkit.h
	\base Class for third parties toolkit data cache
*/

#pragma once

#ifndef __SophisThirdPartyToolkit_H__
#define __SophisThirdPartyToolkit_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#include __STL_INCLUDE_PATH(memory)


SPH_PROLOG



#define DECLARATION_THIRDPARTY_EXTENDED_TK(derivedClass)	DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::ISRThirdPartyExtededTk)
#define CONSTRUCTOR_THIRDPARTY_EXTENDED_TK(derivedClass)
#define WITHOUT_CONSTRUCTOR_THIRDPARTY_EXTENDED_TK(derivedClass)
#define	INITIALISE_THIRDPARTY_EXTENDED_TK(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

namespace sophis
{
	namespace sql
	{
		class CSRStatement;
	}
	namespace backoffice_kernel
	{
		class SOPHIS_FIT ISRThirdPartyGeneralTk
		{
		public: 
			static ISRThirdPartyGeneralTk * (*GetInstance)();
			/** Destructor.
			*/
			virtual ~ISRThirdPartyGeneralTk() {};			


			ISRThirdPartyGeneralTk( const ISRThirdPartyGeneralTk& tk) {}

			virtual void FeedFieldsStatement(sql::CSRStatement& stmt) {};
			virtual long GetCode() { return -1;}
			virtual ISRThirdPartyGeneralTk* Clone() { return NULL;}

		protected:
			// Only derived classes can instantiate this
			ISRThirdPartyGeneralTk() {};
		private:
			static ISRThirdPartyGeneralTk* CreateBasicInstance();
		};

		typedef _STL::shared_ptr<ISRThirdPartyGeneralTk>	SSThirdPartyGeneralTkPtr;
		typedef _STL::map<long, SSThirdPartyGeneralTkPtr>	SSThirdPartyGeneralTkList;
		typedef SSThirdPartyGeneralTkList::const_iterator		SSThirdPartyGeneralTkIter;

		class SOPHIS_FIT ISRThirdPartyExtendedTk
		{
		public: 
			ISRThirdPartyExtendedTk() {}
			ISRThirdPartyExtendedTk( const ISRThirdPartyExtendedTk& tk) {}
			virtual ~ISRThirdPartyExtendedTk() {}

			virtual bool Read() = 0;
			virtual long GetCode() = 0;
			
			/** Get the singleton for one amount.
			This is equivalent to ISRThirdPartyGeneralTk::GetPrototype().GetData(modelName).
			except that exception is caught to return 0 if the date name is not found.
			@param modelName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			virtual ISRThirdPartyExtendedTk* Clone() = 0;
			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<ISRThirdPartyExtendedTk, const char*
											, sophis::tools::less_char_star> prototype;

			static prototype& GetPrototype();
		};

		typedef _STL::shared_ptr<ISRThirdPartyExtendedTk>	SSThirdPartyExtendedTkPtr;
		typedef _STL::map<long, SSThirdPartyExtendedTkPtr>	SSThirdPartyExtendedTkList;
		typedef SSThirdPartyExtendedTkList::const_iterator		SSThirdPartyExtendedTkIter;
	}
}


SPH_EPILOG

#endif//__SophisThirdPartyToolkit_H__
