#pragma once

#ifndef _Sph_TpDocGenRulesCondition_h_
#define _Sph_TpDocGenRulesCondition_h_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"


#define DECLARATION_TP_DOC_GEN_RULES_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_kernel::ISRTpDocGenRulesCondition)
#define CONSTRUCTOR_TP_DOC_GEN_RULES_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_TP_DOC_GEN_RULES_CONDITION(derivedClass)
#define	INITIALISE_TP_DOC_GEN_RULES_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_kernel {

struct SSDocGenerationCriteria;
class ISROtcInput;

/** Interface to create a condition to run before generating a message of confirmation or payment.
Only available with the back office otc.
When defining a message to send, it is possible to add a condition. To implement a new condition,
an implementation of ISRTpDocGenRulesCondition must be done.
@since 4.5.2
*/
class SOPHIS_BO_KERNEL ISRTpDocGenRulesCondition
{
public:
	/** Test if message has to be generated.
	@param trade is the transaction to generate the message.
	@param criteria is the data of the message in the third party.
	@return true if the message has to be generated.
	*/
	virtual bool get_condition( const portfolio::CSRTransaction& trade
		,const backoffice_kernel::SSDocGenerationCriteria& criteria) const = 0;

	/** Test if message has to be generated.
	By default call get_condition(transaction)
	@param otcInput is the otc input to generate the message.
	@param criteria is the data of the message in the third party.
	@return true if the message has to be generated.
	*/
	virtual bool get_condition( const ISROtcInput& input
		,const backoffice_kernel::SSDocGenerationCriteria& criteria) const;
	
	/** Get the singleton for one condition.
	This is equivalent to ISRTpDocGenRulesCondition::GetPrototype().GetData(modelName).
	except that exception is catched to return 0 if the amount name is not found.
	@param modelName is a C string for the condition.
	@return a pointer which must not be deleted but can be null.
	*/
	static ISRTpDocGenRulesCondition* getInstance( const char* modelName );

	/** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_TP_DOC_GEN_RULES_CONDITION.
	@see tools::CSRPrototype
	*/
	virtual ISRTpDocGenRulesCondition* Clone() const = 0;


	/** Typedef for the prototype (the key is a string).
	*/
	typedef sophis::tools::CSRPrototype<ISRTpDocGenRulesCondition
										,const char*
										,sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	To add an amount to this singleton, use INITIALISE_TP_DOC_GEN_RULES_CONDITION.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();
} ;
	}
}

SPH_EPILOG
#endif // _Sph_TpDocGenRulesCondition_h_
