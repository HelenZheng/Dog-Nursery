#ifndef __sphThirdPartySSIColumn_H__
#define __sphThirdPartySSIColumn_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphThirdPartyStruct.h"
#include "SphInc/portfolio/SphPortfolioColumn.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

	namespace sophis{
		namespace backoffice_kernel{

#define DECLARATION_THIRD_PARTY_SSI_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_kernel::CSRThirdPartySSIColumn)
#define CONSTRUCTOR_THIRD_PARTY_SSI_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_THIRD_PARTY_SSI_COLUMN(derivedClass)
#define CONSTRUCTOR_THIRD_PARTY_SSI_COLUMN_GROUP(derivedClass, group)	public : derivedClass::derivedClass() {fColumnGroup = group;} \
	WITHOUT_CONSTRUCTOR_THIRD_PARTY_SSI_COLUMN(derivedClass)
#define	INITIALISE_THIRD_PARTY_SSI_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

		class SOPHIS_BO_KERNEL CSRThirdPartySSIColumn
		{
		public:	
			/** Constructor. */
			CSRThirdPartySSIColumn() : fId(0), fColumnGroup("") {}
			/** Constructor. */
			CSRThirdPartySSIColumn(const _STL::string & columnGroup) : fId(0), fColumnGroup(columnGroup) {}

			/** 
			* Main method to display the content.
			* Must be implemented in derived classes.	
			* @param result line to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			virtual	void GetCell(const sophis::backoffice_kernel::SSThirdPartySettlement &ssiLine, 
				SSCellValue *value, SSCellStyle *style)  const = 0;
			
			/** 
			 * Method to get the cell type.
			 * Must be implemented in derived classes.
			 * return value is the type of the value displayed in the column
			*/
			virtual NSREnums::eDataType GetCellType() const = 0;

			/** 
			* Method to display the content of a group of cells.			
			* @param result line to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/

			virtual void GetAggregatedCell(const sophis::backoffice_kernel::SSThirdPartySettlementPtrList &ssiLines, 
				SSCellValue *value, SSCellStyle *style) const;

			/**
			* Fills cell style with the given currency.
			* Useful for GUI display.
			* @param ccy Currency to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/

			virtual void FillStyleCurrency(long ccy, SSCellStyle *style);

			/**
			* Fills cell style with date style.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillStyleDate(SSCellValue *value, SSCellStyle *style);

			/* 
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			 * Sets the id.
			 * Used when building the columns by {@link CSUReorderColumns}.
			 */
			void SetId(long id)
			{
				fId = id;
			}
			/** 
			* Returns true if the cells can be grouped, false otherwise
			*/			
			virtual bool CanGroup() const;
			
			/** 
			* * Returns true if the cells can be aggregated, false otherwise
			*/			
			virtual bool CanAggregate() const;

			/**
			 * Returns the name of the column group for the given column.
			 * @version 7.2
			*/
			const _STL::string& GetColumnGroup() const
			{
				return fColumnGroup;
			}
	
			/** 
			 * Returns the default cell size in pixels.
			 */
			virtual short GetDefaultWidth() const;

			/** 
			 * Typedef for the prototype : the key is a const char*.
			 */
			typedef tools::CSRPrototypeWithId<CSRThirdPartySSIColumn, const char*, tools::less_char_star> prototype;
			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();

			/**
			* Clone method required by the prototype.
			* Use DECLARATION_CASH_RECON_CONTEXT_COLUMN macro in the implementation of the derived class.
			*/
			virtual CSRThirdPartySSIColumn* Clone() const = 0;

		protected:	
			int fId;
			_STL::string fColumnGroup;
		};

	} // backoffice_kernel
} // sophis

SPH_EPILOG
#endif // __sphThirdPartySSIColumn_H__
