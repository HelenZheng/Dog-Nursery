#ifndef __sphThirdPartySSIContextMenu__
#define __sphThirdPartySSIContextMenu__

#include "SphTools/sphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphThirdPartyDlg.h"

#include __STL_INCLUDE_PATH(list)

SPH_PROLOG

namespace sophis{
	namespace backoffice_kernel{

		/**
		* Macro to be used instead of the Clone() method in the clients derived classes.
		* Prototype framework will be responsible to instantiate clients objects.
		* @param derivedClass is the name of the client derived class.
		*/
#define DECLARATION_THIRD_PARTY_SSI_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_kernel::CSRThirdPartySSIContextMenu)
#define CONSTRUCTOR_THIRD_PARTY_SSI_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_THIRD_PARTY_SSI_CONTEXT_MENU(derivedClass)
#define	INITIALISE_THIRD_PARTY_SSI_CONTEXT_MENU(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name); derivedClass::GetPrototype().GetData(name)->SetId(++sophis::backoffice_kernel::CSRThirdPartySSIContextMenu::fCount)

		/**
		* The key string of the derived element is displayed in the menu.
		*
		* Note that menu items on the dialog appear in the order they are registered within the application.
		* Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
		*
		* @version 7.1.3
		*/

class SOPHIS_BO_KERNEL CSRThirdPartySSIContextMenu
{
public:

	/**
	* Returns the id.
	* The value is automatically created at the initialization because it must be unique.
	* For internal use.
	*/
	int GetId() const
	{
		return fId;
	}

	/**
	* Sets the id.
	* The value is automatically created at the initialization because it must be unique.
	* For internal use.
	*/
	void SetId(long id) const
	{
		(const_cast<CSRThirdPartySSIContextMenu*>(this))->fId = id;
	}

	/** 
	* Typedef for the prototype : the key is a string.
	*/
	typedef tools::CSRPrototypeWithId<CSRThirdPartySSIContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	* Access to the prototype singleton.
	* To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
	*/
	static prototype& GetPrototype();
	
	/*
		IsAuthorized
		Determines if there is authorization to use the menu.
	*/
	virtual bool IsAuthorized(const SSThirdPartySettlementPtrList& ssiLines) const { return false;}
	/*
		Invoked when a context menu is selected.
		SSThirdPartySettlementPtrList: The List of SSI lines as displayed on the grid.
		long index: Optional index argument which may be used bu the menu.
		CSRThirdPartyDlg*: Optional CSRThirdPartyDlg implemenation which may be used by the menu.
	*/
	virtual bool DoThirdPartySSIContextMenu(SSThirdPartySettlementPtrList& ssiLines, long index = 0, 
		CSRThirdPartyDlg* thirdDlg = 0) const{return false;}

	/**
	* Allows to group context menu items in the specified order.
	* Items in different groups will be separated by a separator.
	* Groups 0 to 9 are reserved by Sophis.
	*/
	virtual long GetContextMenuGroup() const { return 0; }

	virtual _STL::string GetMenuLabel(const SSThirdPartySettlementPtrList& ssiLines) const;

	/**
	* Counts the number of prototypes installed and assigns each prototype a number in sequence.
	* For internal use.
	*/
	static long fCount;

	virtual CSRThirdPartySSIContextMenu * Clone() const = 0;

protected:
	long fId;
};
	}// backoffice_kernel
}// sophis

SPH_EPILOG

#endif // __sphThirdPartySSIContextMenu__

