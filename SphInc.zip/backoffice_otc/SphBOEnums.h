#if (defined(WIN32)||defined(_WIN64))
#   pragma once
#endif

#ifndef _BOENUMS_H_INCLUDED_
#define _BOENUMS_H_INCLUDED_

#include "SphInc/SphMacros.h"

SPH_PROLOG

#undef AUDIT_DATE_TIME
/*
enum eMessageType
{
	mtPayment		= 1,
	mtConfirmation,
	mtInstruction,	// additional template type
	mtAccounting,
	mtUnknown
};
*/

#define IDS_BO_KERNEL_STATUS_GROUPS		496
enum NettingSignType
{
	ePositive = 1, 
	eNegative=-1, 
	eAllSign=0
};

enum NettingGroupType
{
	ePayment=1, 
	eConfirmation=2, 
	eInstructions=3, 
	eAllGroup=-1
};

enum eMessageSign
{
	emsPlus = 1,
	emsZero,
	emsMinus
};

enum eSpecificTemplate
{
	stNoConfirmation	= -1,
	stNoPayment			= -2
};

enum eBO_LENGHT{
	RULE_LENGTH				    = 100
	,NUMBER_LENGTH			    = 80
	,NAME_LENGTH			    = 48
	,POST_DATE_TYPE_LENGTH	    = 40
	,COMMENTS_LENGTH		    = 100
	,POST_AMOUNT_LENGTH		    = 40
	,THIRD_PARTY_TYPE_LENGTH    = 40
	,POST_QUANTITY_LENGTH	    = 40
	,BOOK_NAME_LENGTH		    = 40
	,ENTITY_NAME_LENGTH		    = 40
	,ACCOUNT_NAME_LENGTH	    = 80
	,ACCOUNT_NAME_CATEGORY_LENGTH = 50 // is not going to be used in hierhandles, that's why not x4
	,AUDIT_DATE_TIME		    = 44
	,KERNEL_STATUS_LENGTH	    = 40
	,CONDITION_LENGTH		    = 40
	,CHECK_DEAL_LENGTH		    = 40
    ,CHECK_BOMESSAGE_LENGTH     = 40
	,FIELDMODIF_LENGTH		    = 40
   	,USERRIGHT_LENGTH		    = 40
	,KERNEL_WFLOW_NAME_LENGTH   = 40
	,KERNEL_RULESDESC_NAME_LEN  = 40
	,KERNEL_ACTION_NAME_LEN     = 40
	,KERNEL_ENGINE_NAME_LEN     = 40
	,KERNEL_INSTR_VALIDATION_ACTION_LENGTH = 256
	,KERNEL_USER_RIGHT_NAME	    = 40
    ,OTC_STATUS_NAME            = 40
    ,OTC_EVENT_NAME             = 40
    ,OTC_ACTION_NAME_LEN        = 40
    ,OTC_ENGINE_NAME_LEN        = 40
    ,OTC_WFSELECTOR_NAME_LEN    = 40
  	,OTC_WFDEFINITION_NAME_LEN  = 40
	,IMC_INSTRUMENT_TYPE_NAME	= 40	// OPMC: Option Pricing Model Category
	,IMC_META_MODEL_NAME		= 40
	,IMC_YIELD_CURVE_FAMILY_NAME= 40
	,ALLOTMENT_CONDITION_LENGTH	= 48
	,IMC_FASTPNL_MODE = 40
	,IMC_FASTPNL_TRIGGER = 40
	,GROUP_NAME_LENGTH			= 40
	,ALLOTMENT_NAME_LENGTH		= 40
	,BUSINESS_EVENT_NAME_LENGTH	= 40
	,OTC_TPTSELECT0R_NAME_LEN = 40
	,X228_TOPICSELECTOR_NAME_LEN = 40
	,X228_TOPICSELECTOR_TOPIC_LEN = 40
	,X228_TOPICSELECTOR_CLEARER_LEN = 40
	,X228_TOPICSELECTOR_COUNTER_LEN = 40
	,IMC_CRITERIA_FILTER		= 500
	,IMC_OPTIMISATION			= 1000
};


SPH_EPILOG

#endif //_BOENUMS_H_INCLUDED_
