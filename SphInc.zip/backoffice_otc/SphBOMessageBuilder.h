#ifndef __BOMESSAGEBUILDER__
#define __BOMESSAGEBUILDER__

#include "SphInc/backoffice_otc/SphMessage.h"
#include "SphInc/backoffice_otc/SphBOTemplateFactory.h"
#include "SphInc/backoffice_kernel/SphThirdParty.h"

namespace sophis {
	namespace backoffice_kernel {
		class CSRThirdParty;
		struct  SettlementLink;
		class ISROtcInput;
	}
}

#include "SphInc/portfolio/SphTransactionEnums.h"


SPH_PROLOG

class CSRBOTemplateFactory;

class SOPHIS_BO_OTC CSRBOMessageBuilder
{
public:
	CSRBOMessageBuilder( void);

	void GetRawMessagesList(CSRBOTemplateFactory *factory, sophis::backoffice_otc::VCSRMessages &messages);
	void Init(CSRBOTemplateFactory *factory);
	void ProcessSingleMessage(sophis::backoffice_otc::CSRMessage	&msg, CSRBOTemplateFactory *factory,
		SSGeneratedTemplate *current);
	void ProcessReceiverSenderLinks(sophis::backoffice_otc::CSRMessage &msg);
	void ProcessPostingDateAmount(sophis::backoffice_otc::CSRMessage &msg, char *amountType, 
		char *dateType, long msgType, 
		eFactoryAction action);

private:
	sophis::backoffice_kernel::ISROtcInput *fOtcInputIface;
	char		    fSender[BO_OTC_MESSAGE_SIZE_SETTLE];
	long			fAllotment;
	long			fCurrency;
	long			fMarket;
	int				fSign;
	long			fWorkflowID;
	long			fUnderlyingCurrency;
	long			fUnderlyingMarket;
	int				fUnderlyingAllotment;
	long			fBusinessEvent;
	sophis::portfolio::eBODeliveryType	fDeliveryTypeID;

			sophis::backoffice_kernel::CSRThirdParty  fEntity;
			sophis::backoffice_kernel::CSRThirdParty  fDepositary;
			sophis::backoffice_kernel::CSRThirdParty  fDepositaryOfCntrprty;
	
	sophis::backoffice_kernel::CSRThirdParty  fDepositary2;
	sophis::backoffice_kernel::CSRThirdParty  fDepositaryOfCntrprty2;
	long	fCurrency2;

};

SPH_EPILOG

#endif
