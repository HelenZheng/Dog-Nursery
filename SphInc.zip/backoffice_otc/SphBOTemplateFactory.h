#ifndef __BOTEMPLATEFACTORY__
#define __BOTEMPLATEFACTORY__

#include "SphInc/accounting/SphAccountingEnums.h"
#include "SphInc/backoffice_otc/SphBOEnums.h"

#include "SphInc/backoffice_otc/SphMessage.h"
#include "SphInc/backoffice_otc/SphMessageEngine.h"
//#include "SphInc/backoffice_kernel/SphTpDocGenRulesCondition.h"


SPH_PROLOG
namespace sophis {
	namespace backoffice_kernel {
		class ISROtcInput;
	}
}

enum eFactoryAction
{
	faNewDeal		= 1,
	faModifyDeal,
	faCancelDeal,
	faNothing
};

struct SSWorkingPair
{
	bool operator < (const SSWorkingPair &pair) const;

	SSWorkingPair(){}
	SSWorkingPair(sophis::backoffice_otc::eMessageType i_grpCode
		,long i_msgCode): grpCode(i_grpCode), msgCode(i_msgCode){}

	sophis::backoffice_otc::eMessageType	
		grpCode;
	long	msgCode;
};

struct SSWorkingStatus
{
	enum eStatusPair
	{
		spToBeReversed	= 1,
		spFinished,
		spCreate
	};

	SSWorkingStatus(){}
	SSWorkingStatus(long i_id, eStatusPair	i_status): id(i_id), status(i_status){}

	long		id;
	eStatusPair	status;
};

typedef _STL::map<SSWorkingPair, SSWorkingStatus> MWorkingStatuses;

class SOPHIS_BO_OTC WorkingStatusesForReversal
{
public:
	static WorkingStatusesForReversal* Instance();
	MWorkingStatuses GetWorkingStatuses() { 
		return fStatuses;
	}
	void UpdateStatusesMap(SSWorkingPair theKey
		,SSWorkingStatus theStatus
		,sophis::portfolio::TransactionIdent iSourceID = 0
		,long iSourceVersion = 0
		,sophis::accounting::eTradeType iSourceType = sophis::accounting::ttTrade
		,long oCPTY = 0) { 
			fStatuses.insert(MWorkingStatuses::value_type(theKey, theStatus));
			if (oCPTY) 
			{
				originalCPTY	= oCPTY;
				sourceID		= iSourceID;
				sourceVersion	= iSourceVersion;
				sourceType		= iSourceType;
			}
	}
	void Init() { 
		fStatuses.clear();
		originalCPTY	= 0;
		sourceID		= 0;
		sourceVersion	= 0;
		sourceType		= sophis::accounting::ttTrade;
	}

	long				originalCPTY;
	sophis::portfolio::TransactionIdent				sourceID;
	long				sourceVersion;
	sophis::accounting::eTradeType
						sourceType;

private:
	WorkingStatusesForReversal():originalCPTY(0), sourceID(0), sourceVersion(0), sourceType(sophis::accounting::ttTrade) {};

	MWorkingStatuses    fStatuses;

	static WorkingStatusesForReversal *_instance;
};


struct SOPHIS_BO_OTC SSGeneratedTemplate
{
	enum eStatusTemplate
	{
		stNotSent	= 1,
		stSent
	};
	enum eStatusCreation
	{
		scToPending	= 1,
		scToReady,
		scToSent
	};


	long	type;
	long	row;
	long	templateID;
	sophis::backoffice_otc::eMessageType	
		grpCode;
	long	recipient;
	char	amountType[POST_AMOUNT_LENGTH];
	char	dateType[POST_DATE_TYPE_LENGTH];
	char    condition1[CONDITION_LENGTH];
	char    condition2[CONDITION_LENGTH];
	char    condition3[CONDITION_LENGTH];
	long    eventCreation;
	eStatusTemplate	
		status;
	long	reversalID;
	long	nettingType;
	long	nettingID;
	long	generationMethod;
	long	sendingMethod;		//(vvf, 12/11/03) --sending method
	long	sign;

	SSGeneratedTemplate();
	SSGeneratedTemplate(const SSGeneratedTemplate& gt);	
	SSGeneratedTemplate& operator=(const SSGeneratedTemplate& gt);
	friend _STL::ostream & operator << (_STL::ostream &stream, const SSGeneratedTemplate& gt);

private:
	static const char	*__CLASS__;
};

typedef _STL::vector< SSGeneratedTemplate> VSSGeneratedTemplate;
typedef VSSGeneratedTemplate::iterator     IVSSGeneratedTemplate;

class SOPHIS_BO_OTC CSRBOTemplateFactory
{
public:

	enum eGenerateMessages
	{
		gmPayments		= 1,
		gmConfirmations,
		gmPaysAndConfs,
		gmNothing
	};

	CSRBOTemplateFactory(void);
	virtual ~CSRBOTemplateFactory(void);

	eFactoryAction	GetAction(void) { return fAction; }

	void    Init( const sophis::backoffice_kernel::ISROtcInput *dIface
		,eFactoryAction action
		,_STL::vector<long> recipients);


	VSSGeneratedTemplate*
		GetTemplatesArray(void) { return	&fCurrentCPTYTemplArray;}
	sophis::backoffice_kernel::ISROtcInput*
		GetOtcInputIface(void) { return fCurrentOtcInputIface; }
	void    GetTemplates(void);


	void	UpdateStatusesMap(SSWorkingPair theKey, SSWorkingStatus theStatus);

protected:

	//	This function is used to check extra condition for the template items
	bool CheckExtraCondition(IVSSGeneratedTemplate& it
		,sophis::backoffice_kernel::ISROtcInput *dIface);
	bool CheckSignCondition(IVSSGeneratedTemplate& it
		,sophis::backoffice_kernel::ISROtcInput *dIface);

	void    FillVectorFromDB(VSSGeneratedTemplate &templates
		,sophis::backoffice_kernel::ISROtcInput* dIface);
	sophis::backoffice_otc::eEngineResult	
		RefineVectorWithConditions(void);
	void	RefineVectorWithOriginalCancelTemplates(void);
	void	UpdateVectorWithMap(void);
	sophis::backoffice_otc::eEngineResult 
		UpdateVectorWithMapNew(void);

	void    FinishMapProcessing(void);
	sophis::backoffice_otc::eEngineResult	
		FinishVectorProcessing(void);

	SSGeneratedTemplate 
		GetCancelTemplate(SSGeneratedTemplate& templateToReplace);

	SSGeneratedTemplate // AV 13/8/04 Put in comment from 4.5.1 to compile only
		GetDefaultMessage( long id = 0,long recipient = 1); // Third 1 by default

	sophis::backoffice_kernel::ISROtcInput *fCurrentOtcInputIface;
	sophis::backoffice_kernel::ISROtcInput *fOtcInputIfaceOfSentMessage;

	MWorkingStatuses						fStatuses;
	eFactoryAction							fAction;

	VSSGeneratedTemplate					fCurrentCPTYTemplArray;
	VSSGeneratedTemplate					fCPTYofSentMessageTemplArray;

	_STL::vector<long>                      fRecipients;

	_STL::map<long, long>					fNoGenerateRows;

private:
	void			FindNoGenerateRows();
	virtual bool	CanBeGenerated(const SSGeneratedTemplate &current);

	static const char	*__CLASS__;
	virtual int     GetNoGenerateID() = 0;
	virtual sophis::backoffice_otc::eMessageType     
		GetGrpCode() = 0;
	virtual char*   GetPrefDefaultTemlate() = 0;
	virtual char*   GetPrefDefaultTemlateCancel() = 0;
};

class CSRBOTemplateFactoryConf: public virtual CSRBOTemplateFactory
{
public:
	CSRBOTemplateFactoryConf(void){}
	virtual ~CSRBOTemplateFactoryConf(void){}

	virtual int     GetNoGenerateID(){ return stNoConfirmation;}
	virtual sophis::backoffice_otc::eMessageType
		GetGrpCode(){ return sophis::backoffice_otc::mtConfirmation;}
	virtual char*   GetPrefDefaultTemlate(){ return "DEFAULT_CONFIRMATIONS_TEMPLATE";}
	virtual char*   GetPrefDefaultTemlateCancel(){ return "DEFAULT_CONFIRMATIONS_TEMPLATE_CANCEL";}

};

class CSRBOTemplateFactoryPayment: public virtual CSRBOTemplateFactory
{
public:
	CSRBOTemplateFactoryPayment(void){}
	virtual ~CSRBOTemplateFactoryPayment(void){}

	virtual int     GetNoGenerateID(){ return stNoPayment;}
	virtual sophis::backoffice_otc::eMessageType
		GetGrpCode(){ return sophis::backoffice_otc::mtPayment;}
	virtual char*   GetPrefDefaultTemlate(){ return "DEFAULT_PAYMENTS_TEMPLATE";}
	virtual char*   GetPrefDefaultTemlateCancel(){ return "DEFAULT_PAYMENTS_TEMPLATE_CANCEL";}
};



SPH_EPILOG

#endif
