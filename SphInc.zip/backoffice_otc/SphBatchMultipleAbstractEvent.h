#pragma once

#include "SphInc/backoffice_otc/SphOTCEngine.h"
#include "SphInc/tools/SphValidation.h"
#include "SphInc/backoffice_otc/SphMessage.h"


SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{
		typedef _STL::vector<CSRMessage> VCSRMessage;
		typedef VCSRMessage::iterator    IVCSRMessage;

		class SOPHIS_BO_OTC CSRBatchMultipleAbstractEvent: public virtual sophis::tools::CSRAbstractEvent
		{
		public:
			CSRBatchMultipleAbstractEvent(){}
			~CSRBatchMultipleAbstractEvent(){}
			void InitWithAbstractEVector(sophis::tools::CSREventVector& v)
			{
				fAbstractEVector = &v;
			}

			void AddMessage(const CSRMessage& m) 
			{ 
				fVBOMessage.push_back(m); 
			}
			virtual void Send()
				throw (sophisTools::base::ExceptionBase);

			virtual bool RunSingle(const CSRMessage& m
								   ,sophis::tools::CSREventVector& v
								   ,_STL::string& error) = 0;

		private:
			void RunBatch();
			_STL::vector<CSRMessage> fVBOMessage;
			sophis::tools::CSREventVector *fAbstractEVector;
			static const char* __CLASS__;

		};
	}
}

SPH_EPILOG

