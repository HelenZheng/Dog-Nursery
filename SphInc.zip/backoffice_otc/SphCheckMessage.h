#ifndef _SPH_CHECK_MESSAGE_H_
#define _SPH_CHECK_MESSAGE_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphValidation.h"

#define DECLARATION_CHECK_MESSAGE(derived)		DECLARATION_PROTOTYPE(derived,sophis::backoffice_otc::CSRCheckMessage)
#define	INITIALISE_CHECK_MESSAGE(derived, name)	INITIALISE_PROTOTYPE(derived, name)

SPH_PROLOG
namespace sophis
{
   	namespace tools	{
		struct VoteException;
	}

	namespace backoffice_otc
	{

class CSRMessage;
/**	Class for validating the change of status of an OTC message.
This is an abstract class, where the derived class will define conditions for the transfer of messages from one status to another,
after an event takes place. The OTC message changes from one status to another in response to an event. This is defined as the workflow
of the message.
@version 4.7.0
*/
class SOPHIS_BO_OTC CSRCheckMessage
{
public:
	/**	Object that holds the list of all CSRCheckMessage-derived validation classes defined by the user.
	Each validation class is uniquely identified by a string.
	A new validation class is added to the list using INITIALISE_CHECK_MESSAGE
	@see CSRPrototype
	@version 4.7.0
	*/
	typedef sophis::tools::CSRPrototype<CSRCheckMessage, const char*, sophis::tools::less_char_star>	prototype;

	/**	Obtains the list of all defined CSRCheckMessage-derived validation classes.
	A new validation class is added to the list using INITIALISE_CHECK_MESSAGE
	@return reference to list of validation classes
	@see CSRPrototype
	@version 4.7.0
	*/
	static prototype& GetPrototype();

	/** Creates an instance of the validation class.
	Overriding method creates an object of the CSRCheckMessage-derived validation class.
	@return a pointer to a newly created CSRCheckMessage-derived validation object.
	@version 4.7.0
	*/
	virtual CSRCheckMessage* Clone() const = 0;

	/** Ask for a creation of a BO message.
    When creating, once the the workflow selector and the event have been found,
	and if a checked message condition has been added, this method is executed.
	@param message is the bo message to create. It is a non-const object so you can
	modify it.
	@throws VoteException if you reject that creation.
	*/
	virtual void VoteForCreation(CSRMessage& message) const
			throw (tools::VoteException) {}

	/** Ask for a modification of a BO message.
	When modifying, once the the workflow selector and the event have been found,
	and if a checked message condition has been added, this method is executed.
	@param original is the original BO message before any modification.
	@param message is the modified BO message. It is a non-const object so you can
	modify it.
	@throws VoteException if you reject that modification.
	*/
	virtual void VoteForModification(const CSRMessage& original, 
									 CSRMessage& message) const
		    throw (tools::VoteException) {}

	/** Ask for a deletion of a BO message.
	When deleting, once the the workflow selector and the event have been found,
	and if a checked message condition has been added, this method is executed.
	@param message is the original BO message before any modification.
	@throws VoteException if you reject that deletion.
	*/
	virtual void VoteForDeletion(const CSRMessage& message) const
			throw (tools::VoteException) {}
};

	}
}
SPH_EPILOG
#endif