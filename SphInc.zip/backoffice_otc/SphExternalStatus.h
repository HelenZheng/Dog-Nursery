/*
 	File:		SphExternalStatus.h

 	Contains:	Class for describing external statuses of incoming messages.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphExternalStatus.h
	\brief Class for describing external statuses of incoming messages
*/

#ifndef SPH_BO_OTC_EXTERNAL_STATUS
#define SPH_BO_OTC_EXTERNAL_STATUS



#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRExternalStatus

/** Represents external statuses for incoming messages.
*/

class SOPHIS_BO_OTC CSRExternalStatus
{
public:

	CSRExternalStatus();
	CSRExternalStatus(const CSRExternalStatus& im);
	~CSRExternalStatus();

	void Init();

	long		fID;
	char		fName[40];
	char		fComments[100];
};
////////////////////////////////////////////////////////////////////////////////

	}
}
SPH_EPILOG

#endif //  SPH_BO_OTC_EXTERNAL_STATUS

