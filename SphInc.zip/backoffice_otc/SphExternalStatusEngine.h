/*
 	File:		SphExternalStatusEngine.h

 	Contains:	Database interface to handle external statuses for incoming messages.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphExternalStatusEngine.h
	\brief Database interface for handling external statuses for incoming messages.
*/

#ifndef SPH_BO_OTC_EXTERNAL_STATUS_ENGINE
#define SPH_BO_OTC_EXTERNAL_STATUS_ENGINE

#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/backoffice_otc/SphExternalStatus.h"



SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRExternalStatusEngineException

/** General exception.
Exception thrown when there are problems with retreival or inserting external status
	in database or if a certain external status ID does not exist in the engine.
	Generally, this exception is for all problems in CSRExternalStatusEngine.
	@see CSRExternalStatusEngine
*/

class SOPHIS_BO_OTC CSR_ESE_Exception : public sophisTools::base::GeneralException
{
public:

	/** Constructor.
		@param description is the description of the error.
		@param file is the file name where this exception is thrown.
		@param lineNumber is the place in the file where this exception is thrown.
		@param function is the name of function issuer of exception.
	*/
	CSR_ESE_Exception(char* description, char* fileName, long lineNumber, char* function);

	const _STL::string GetDescription() const;
	const _STL::string GetFileName() const;
	const long GetLineNumber() const;
	const _STL::string GetFunction() const;

private:
	_STL::string fDescription;
	_STL::string fFileName;
	long fLineNumber;
	_STL::string fFunction;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//	CSRExternalStatusEngine

/** Interface to handle External Statuses used for incoming messages.
*/
class SOPHIS_BO_OTC CSRExternalStatusEngine
{
public:
	CSRExternalStatusEngine();
	~CSRExternalStatusEngine();
	/** Retrieves an External Status by its ID and stores it in the engine.
		@param ID is ID of external status to retrieve.
		@returns true if external status was found, otherwise - false.
		@throws CSR_ESE_Exception if the specified ID occurred more than once in the table.
	*/
	bool RetrieveWithID(long ID)
		throw (CSR_ESE_Exception);

	/** Retrieves External Status by its name and stores it in the engine.
		@param name is name of external status to retrieve.
		@returns true if external status was found, otherwise - false.
		@throws CSR_ESE_Exception if the specified name occurred more than once in the table.
	*/
	bool RetrieveWithName(const char* name)
		throw (CSR_ESE_Exception);

	/** Retrieves from database all External Statuses available.
	*/
	void RetrieveAll()
		throw (CSR_ESE_Exception);

	/** Number of Ext Status.
	@returns the number of External Statuses retrieved from database.
	*/
	long GetResultsListLength() const;

	/** Ext Status by index.
	@returns External Status by its index in the engine.
		@param index is the index of external status in the engine.
			Do not take index for external status ID. If you want to find the external
			status by its ID using this function, you have to scan all of them in sequence.
		@throws CSR_ESE_Exception if index is out of range.
	*/
	const CSRExternalStatus& GetResult(long index) const
		throw (CSR_ESE_Exception);

	/** Returns External Status by its ID.
	@returns External Status by its ID
		@param esID is the desired external status ID.
		@throws CSR_ESE_Exception if can not find status with this ID.
	*/
	const CSRExternalStatus& GetExternalStatus(long esID) const
		throw (CSR_ESE_Exception);

	/** Adds new External Status in database.
		@param es is the external status to insert in database.
		@throws CSR_ESE_Exception if insertion failed.
	*/
	static void CSRExternalStatusEngine::addExternalStatus(CSRExternalStatus& es)
		throw (CSR_ESE_Exception);

private:
	void PerformQuery(char* where)
        throw (CSR_ESE_Exception);

	_STL::vector<CSRExternalStatus>	fESs;
	typedef _STL::vector<CSRExternalStatus>::const_iterator  ESCITER;
};
////////////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG



#endif //  SPH_BO_OTC_EXTERNAL_STATUS_ENGINE

