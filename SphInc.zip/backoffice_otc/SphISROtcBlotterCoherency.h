/*
File:		SphISROTCBlotterCoherency.h

Contains:	Class to propagate coherency messages recieved by OTC blotters to toolkit

Copyright:	� 2011 Mysis/Sophis.
*/
#pragma once

#ifndef _SphISROtcBlotterCoherency_H_
#define _SphISROtcBlotterCoherency_H_

#include "SphLLInc\backoffice_otc\BO_OTC_GUI_Exports.h"

SPH_PROLOG
namespace sophis	{
	namespace event {
		class ISEvent;
	}
	namespace backoffice_otc {

		class SPHBO_OTC_GUI ISROtcBlotterCoherency
		{
		public:
			/** Create an instance of ISROTCBlotterCoherency or a derived.
			You can redirect the pointer, in order to create your own derivated class.
			It is called when an otc blotter opens.
			*/
			static ISROtcBlotterCoherency* (*GetInstance)();
			static ISROtcBlotterCoherency* CreateBasicInstance();

			/** Interface is called when the blotter opens
			*/
			virtual void BlotterOpen( void);
			/** Interface is called when the blotter closes
			*/
			virtual void BlotterClose( void);
			/** Interface is called when the refresh button of the blotter is pushed
			*/
			virtual void ReInitialise( void);
			/** Interface is called when a coherency event is recieved and processed
			  by the blotter
			*/
			virtual void HandleNewEvent(const sophis::event::ISEvent & event);
		};
	}
}
SPH_EPILOG
#endif
