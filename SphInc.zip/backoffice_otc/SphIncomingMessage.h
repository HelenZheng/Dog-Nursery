/*
 	File:		SphIncomingMessage.h

 	Contains:	Class describing incoming messages.

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphIncomingMessage.h
	\brief Class describing incoming messages
*/


#ifndef SPH_BO_OTC_INCOMING_MESSAGE
#define SPH_BO_OTC_INCOMING_MESSAGE



#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"

#define BO_OTC_INCOMING_MSG_SIZE_COMMENTS 	512

SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRIncomingMessage

class SOPHIS_BO_OTC CSRIncomingMessage
{
public:

	CSRIncomingMessage();
	CSRIncomingMessage(const CSRIncomingMessage& im);
	~CSRIncomingMessage();

	void Init();

	long		fID;
	long		fPaymentID;
	char		fForeignKey[40];
	double		fAmount;
	long		fCurrencyAmount;
	double		fAdjustment;
	long		fAdjustmentType;
	long		fGenerationDate;
	long		fMessageDate;
	long		fEffectiveDate;
	long		fOTCEventID;	// new in 500 - replace Status
	long		fKernelEventID; // new in 500
	char		fComments[BO_OTC_INCOMING_MSG_SIZE_COMMENTS];
	char		fReasonCode[40];
};
////////////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG

#endif //  SPH_BO_OTC_INCOMING_MESSAGE

