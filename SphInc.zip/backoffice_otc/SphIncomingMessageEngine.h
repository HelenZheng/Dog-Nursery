/*
 	File:		SphIncomingMessageEngine.h

 	Contains:	Database interface to handle incoming messages.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphIncomingMessageEngine.h
	\brief Database interface to handle incoming messages
*/

#ifndef SPH_BO_OTC_INCOMING_MESSAGE_ENGINE
#define SPH_BO_OTC_INCOMING_MESSAGE_ENGINE

#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/backoffice_otc/SphIncomingMessage.h"


SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRIncomingMessageEngineException

/** General exception.
Exception thrown when there are problems with retrieval or inserting incoming messages
	in the database or if a certain incoming message or its ID does not exist in the engine.
	Generally, this exception is suitable for all problems in CSRIncomingMessageEngine.
	@see CSRIncomingMessageEngine
*/

class SOPHIS_BO_OTC CSR_IME_Exception : public sophisTools::base::GeneralException
{
public:

	/** Constructor.
		@param description is the description of the error.
		@param file is the file name where this exception is thrown.
		@param lineNumber is the place in the file where this exception is thrown.
		@param function is the name of function issuer of exception
	*/
	CSR_IME_Exception(char* description, char* fileName, long lineNumber, char* function);

	const _STL::string GetDescription() const;
	const _STL::string GetFileName() const;
	const long GetLineNumber() const;
	const _STL::string GetFunction() const;

private:
	_STL::string fDescription;
	_STL::string fFileName;
	long fLineNumber;
	_STL::string fFunction;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//	CSRIncomingMessageEngine

/** Interface for handling incoming messages.
*/

class SOPHIS_BO_OTC CSRIncomingMessageEngine
{
public:
	CSRIncomingMessageEngine();
	~CSRIncomingMessageEngine();

	/** Retrieves an incoming message by its ID and stores it in the engine.
		@param ID is the ID of the incoming message to retrieve.
		@throws CSR_IME_Exception if database query fails.
	*/
	void RetrieveWithID(long ID)
		throw (CSR_IME_Exception);

	/** Retrieves an incoming message by payment ID and stores it in the engine.
		@param ID is payment ID of the incoming message to retrieve.
		@throws CSR_IME_Exception if database query fails.
	*/
	void RetrieveWithPaymentID(long ID)
		throw (CSR_IME_Exception);

	/** Retrieves all incoming messages and stores them in the engine.
		@throws CSR_IME_Exception if database query fails.
	*/
	void RetrieveAll()
		throw (CSR_IME_Exception);

	/** Returns the number of incoming messages retrieved from the database.
	*/
	long GetResultsListLength() const;

	/** Returns incoming message by its index in engine.
		@param index is index of incoming message in engine.
			Do not use index for an incoming message ID. If you want to find an incoming
			message by its ID using this function you have to scan all of them in sequence.
		@throws CSR_IME_Exception if index is out of range.
	*/
	const CSRIncomingMessage& GetResult(long index) const
		throw (CSR_IME_Exception);

	/** Adds a new incoming message to the database.
		@param im is the incoming message to insert in the database.
		@throws CSR_IME_Exception if insertion failed.
	*/
	static void CSRIncomingMessageEngine::addIncomingMessage(CSRIncomingMessage& im)
		throw (CSR_IME_Exception);

private:
	void PerformQuery(char* where)
        throw (CSR_IME_Exception);

	_STL::vector<CSRIncomingMessage>	fIMs;
};
////////////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG

#endif //  SPH_BO_OTC_INCOMING_MESSAGE_ENGINE

