/*
 	File:		SphIncomingMessageEngine.h

 	Contains:	Class CSRSettlementEngineIncomingMessage.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphIncomingPaymentAccountEngine.h
	\brief Contains class CSRSettlementEngineIncomingMessage
*/

#ifndef SPH_INCOMING_PAYMENT_ACCOUNT_ENGINE_H
#define SPH_INCOMING_PAYMENT_ACCOUNT_ENGINE_H

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace accounting
	{
      class SSFinalPosting;
	  class CSREngineQueriesPayment;
	}
	namespace backoffice_otc
	{
      class CSRIncomingMessage;
	}
};

/** Class for implementing interface for GetAllPosting function from within BOWS.
*/

class SOPHIS_BO_OTC CSRSettlementEngineIncomingMessage
{
public:

	/** Called from BOWS to process postings for transaction trade.
	@param trade is transaction involved in postings.
	@param version is version of transaction involved.
	@param payment is payment incoming messages involved.
	@param finalPostingArray is array of posting for transaction trade.
	@param sizeFinalPostingArray is the size of posting array.
	@param engQueries is queries engine used to get the postings.
	@returns true if postings were processed successfully, otherwise - false.
	*/
	static bool GetAllPostings(	const sophis::portfolio::CSRTransaction&		trade,
		                        long											version,
								const sophis::backoffice_otc::CSRIncomingMessage& payment,
								sophis::accounting::SSFinalPosting**			finalPostingArray,
								int*											sizeFinalPostingArray,
								sophis::accounting::CSREngineQueriesPayment*	engQueries) ;

};

SPH_EPILOG
#endif
