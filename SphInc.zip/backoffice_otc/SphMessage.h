/*
 	File:		SphIncomingMessageEngine.h

 	Contains:	Class describing Back Office Message.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphMessage.h
	\brief Contains class CSRMessage.
*/

#ifndef SPH_BO_OTC_MESSAGE_H
#define SPH_BO_OTC_MESSAGE_H


#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif

#include "SphInc/tools/SphValidation.h"

#include "SphTools/SphCommon.h"

#include "SphInc/accounting/SphAccountingEnums.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


SPH_PROLOG

class CSBOEventNotifier;
class CSDocRetriever;
class CSDocGenerator;

namespace sophis {

    namespace tools {
		struct  VoteException;
		class CSREventVector;
	}	

   	namespace backoffice_kernel	{
        class ISROtcInput;
    }

	namespace tools
	{
		namespace dataModel
		{
			class Data;
			class DataSet;
			class DataModelException;
		}
	}

	namespace backoffice_otc {

	class CSRMessageXMLExtension;
	typedef _STL::vector<CSRMessageXMLExtension*> VCSRMessageXMLExtension;


#define	BO_OTC_MESSAGE_SIZE_REMARKS		512
#define	BO_OTC_MESSAGE_SIZE_NOTES		256
#define	BO_OTC_MESSAGE_SIZE_SETTLE		40
#define BO_OTC_MESSAGE_DOCUMENT_NAME	256
#define BO_OTC_MESSAGE_SIZE_PLACE_OF_SETTLEMENT		50
#define BO_OTC_MESSAGE_SIZE_EXTERNAL_OPERATION_REFERENCE	256

/*
* Defines Back Office Message types available in RISQUE.
*
* ATTENTION: this definition is duplicated in SMLServer (SMLServerImpl.cpp)
* if you change this, change correspondend definition in SMLServerImpl.cpp
*/
enum eMessageType
{
	mtPayment		= 1,
	mtConfirmation,
	mtInstruction,	// additional template type
	mtAccounting,
	mtXNettingPayment,
	mtUnknown
};

enum eMessageNettingType
{
	eMessageNettingTypeNoNetting=0,
	eMessageNettingTypeToOtherCSRMessage,
	eMessageNettingTypeToInstruction
};

class CSRMessageEngine;

/** Represents Back Office Message for mtPayment and mtConfirmation type
*/
class SOPHIS_BO_OTC CSRMessage
{	
public:
	
	CSRMessage(void);
	CSRMessage( const CSRMessage& m);
	CSRMessage& operator= (const CSRMessage& m);

	/** ID, version and source type of the underlying object related to this CSRMessage.
	*/
	portfolio::TransactionIdent			sourceID;
	long			sourceVersion;
	accounting::eTradeType			
					sourceType;

	/** mtPayment or mtConfirmation.
	*/
	eMessageType	otcType;

	/** Parameterised in Third Party dialog.
	*/
	long			recipientType;

	/** Status of current CSRMessage.
	*/
    long            status;

	/** ID of the template that is used by the SML server to generate a document
		related to this CSRMessage.
	*/
	long			templateID;

	/** Date when this CSRMessage was generated if it is a reversal message.
	*/
	long			reversalDate;

	/** Back Office remarks.
	*/
	mutable char	remarks[BO_OTC_MESSAGE_SIZE_REMARKS];
	
	/** User Notes for BO Message.
	*/
	mutable char	docNotes[BO_OTC_MESSAGE_SIZE_NOTES];

	/** User Notes for BO Message.
	*/
	long			userID;

	/**	Swift codes and accounts of financial institutions involved in processing of this
		message.
	*/
// 	char			sender1[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			sender2[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			sender3[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			senderAccount1[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			senderAccount2[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			receiver1[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			receiver2[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			receiver3[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			receiverAccount1[BO_OTC_MESSAGE_SIZE_SETTLE];
// 	char			receiverAccount2[BO_OTC_MESSAGE_SIZE_SETTLE];

	/** ID of corresponding reversed CSRMessage if this CSRMessage is a reversal.
	*/
	long			linkReversalID;

	/** ID of netting CSRMessage if this CSRMessage is netted (0 - if not netted).
	*/
	long			nettingID;

	/** Type of netting: 0 if not netted, 1 if classic CSRMessage netting, 2 if netted to an instruction(StockLoan netting).
	*/
	long			nettingType;

	/** ID of the entity and the counterparty involved in this CSRMessage.
	*/
	long			counterpartyID;
	long			entityID;

	/** ID of the third party used for this message
	*/
	long			thirdPartyIDForTemplateSelection;

	/** Amount and currency of this CSRMessage.
	*/
	double			amount;
	long			currencyAmount;

	/** All these dates are parameterised in the Third Party Dialog,
		generationDate is of double type to store date and time.
	*/
	long			valueDate;
	long			matchDate;
	double			generationDate;

	/** Internal.
	*/
	long			senderSSIPath;
	long			receiverSSIPath;
	long			senderSSIPath2;
	long			receiverSSIPath2;
	long			senderSSIRow;
	long			receiverSSIRow;
	long			senderSSIRow2;
	long			receiverSSIRow2;
	long			templateRow;
	long			agreementRow;
	long			nettingRow;
	char			placeOfSettlement[BO_OTC_MESSAGE_SIZE_PLACE_OF_SETTLEMENT];
	char			externalOperationReference[BO_OTC_MESSAGE_SIZE_EXTERNAL_OPERATION_REFERENCE];


	/** Parameterised in Third Party dialog.
	*/
	long			paymentMethod;
	
	/** parameterised in Third Party dialog
	*/
	long			sendingMethod;


	/** Instrument ID of related transaction.
	*/
	long			instrumentID;

	/** Folio ID of related transaction.
	*/
	long			bookID;

	/** ID of document generated by the SML server for this CSRMessage.
	*/
	mutable long	docID;

	/**	Version of document generated by SML server.
	*/
	mutable long	docModification;

    /** Status and reference of incoming message related to this CSRMessage.
	*/
	long			externalStatus;
	char			externalReference[BO_OTC_MESSAGE_SIZE_SETTLE];

	/** ID of CSRMessage.
	*/
	long			ident;

	///** Last saved status.
	//*/
    //long            initialStatus;

	///** Busines event of related transaction, parameterised in Third Party dialog.
	//*/
	long			businessEvent;
    
    /** 
    * Used to decide how OTC WF rule will be retrieved. If OTCEventID is qreater then zero 
    * then it is valid and can be used to retrieve OTC WF rule to get OTC actions for deal. 
    * All this is done for example in OTC Transaction Action, 
    * and can be done in the same manner in customer transaction actions
    */
    long            OTCEventID;

	/**
	* Treasury Account ID associated with the Sender fields for the financial institutions involved
	* @since 5.3.2
	*/
	//long			fTreasuryAccount;

	/**
	* This field stores file name if user chooses custom file from thirdparty.
	* @since 5.2.2
	*/
	char			documentName[BO_OTC_MESSAGE_DOCUMENT_NAME];

	/**
	* This field stores the last OTC rule ID to be applied to the message
	* @since 6.0
	*/

	long		oTCWFRuleID;
	
	sophis::portfolio::PositionIdent		ntl_mvtident;
	long		ntl_sign;
	long		ntl_instrument;

	/** Updates in database fields of CSRMessage available for editing
		from Payment or Confirmation blotter.
		Save() and Delete() are used to save/remove single message from the database.
		Commit() and Rollback() opereration are handled automatically here. But
		these two will re-throw exception if operation will fail, 
		so wrap them with try/catch block.
	*/
		
	/** @param saveNetted is a flag. If it is set to true all CSRMessages netted to 'msg'
	    will also be updated, if it is set to false nothing will be updated besides 'msg'
	    @param reSending is a flag telling if 'msg' is going to be resent it has an effect 
	    only if 'msg' was sent already
	    @return nothing if successful, throws general exception if failed, so wrap it 
		with try/catch block
	*/
	void Save(bool saveNetted = true, bool reSending = false);
	
	void Delete() const;
	
	/**	MultiSave() and MultiDelete() are used when several messages have to be 
		saved, removed from the database in the same transaction. So it's up to 
		programmer to wrap them with try/catch block as it will throw exception
		in the case of failure and do explicitly Commit/Rollback when transaction
		is over or failed.
	*/

	/** @param saveNetted is a flag. If it is set to true all CSRMessages netted to 'msg'
	    will also be updated, if it is set to false nothing will be updated besides 'msg'
	    @param reSending is a flag telling if 'msg' is going to be resent it has an effect 
	    only if 'msg' was sent already
	    @return nothing if successful, throws general exception if failed, so wrap it
		with try/catch block
	*/
	void MultiSave(sophis::tools::CSREventVector& eventList, 
					bool saveNetted = true, bool reSending = false);

	void MultiDelete(sophis::tools::CSREventVector& eventList) const;
 
    /** This function is called by the BOWS to save the changes made in a message.
		It is used in order to avoid problems with multiple changes in the message 
		(that is if modifications of the message occured in Risque for example while 
		this message was processed by the BOWS). It calls Save() but only updates the necessary
		members of CRSMessage.
	    @return nothing
		@see Save
		@since 4.5.2
    */	
	void UpdateFromExternal();

public:
    /** This function applies event to this message. MultiSave or MultiDelete is called 
        inside, so saveNetted and reSending parameters are simply passed to these functions
        @param events is the event vector which will record all the messages to send after committing;
	    if null, it means that the commit is done immediately.
        @param saveNetted to pass to MultiSave
        @param reSending to pass to MultiSave
	    @param isLocalContext is to indicate that transaction is created and exist in the local context
		(some of the triggers or actions for example) and could be not accessed when events are to be sent.
		@throws VoteException if one CSRTransactionAction rejects that deletion
		@throws ExceptionBase if there is a problem when saving.
		Note that in all cases (success or failure) the status is modified. 
		@since 4.7.0
    */
    void DoAction(long eventID, tools::CSREventVector *events, bool saveNetted = true
                          ,bool reSending = false, bool isLocalContext = false)
        throw (tools::VoteException);

     /** Get the final status using the otc workflow.
	     Will assign the associated OTC WF rule id to oTCWFRuleID
	    @return the otc status correspond to the event applied.
		@throws VoteException if any issues occured (event or transition do not exist).
		@since 4.5.2
	 */
    long GetFinalStatus(long eventID, bool *ignore)
        throw (tools::VoteException);

	/** Returns first 4 OTC events.
	    In 5.2.2 maxSize parameter is introduced with default value of 4 for backward compatibility
	*/
    bool GetOTCEvents( long & wfID, _STL::vector< long> &evIDs, unsigned long maxSize = 4);

	/** Returns true if this CSRMessage meets conditions set by initial filter blotter dialog.
		@blotterId is the Id of the blotter where initial filter is setup to be used for filtering
	*/
	bool IsFiltered( long blotterId);

	/** Return window title.
	@param name is set by this function.
		'name' is  a window title for generated document window.
	*/
	void GetWindowName(char *name);
	char* GetShortWindowName(char *name);

	long GenerateDocument( _STL::string & errorMsg, bool autosend=false) const
		throw (sophisTools::base::GeneralException);

	/** Generates XML document.
	@param generator is a pointer to Word interface
	@param errorMsg is a string to pass error message 
	occured while generating document
	*/

	long GenerateXMLDocument( CSDocGenerator* generator
		, _STL::string & errorMsg, bool autosend=false) const
		throw (sophisTools::base::GeneralException);

	/** Generates an SML non-WORD document
		@param errorMsg is a string to pass error message 
            occured while generating document
	*/
	long GenerateSMLDocument( _STL::string & errorMsg, bool autosend=false) const
        throw (sophisTools::base::GeneralException);

	/** Generates WORD document.
        @param generator is a pointer to Word interface
		@param errorMsg is a string to pass error message 
            occured while generating document
	*/
	long GenerateWordDocument( CSDocGenerator* generator
                               , _STL::string & errorMsg, bool autosend=false) const
        throw (sophisTools::base::GeneralException);
	/** Sends an SML document for non-sent CSRMessages.
  		@param errorMsg is a string to pass error message 
            occured while sending document
	*/
    bool SendSMLDocument(_STL::string & errorMsg) const
        throw (sophisTools::base::GeneralException);

    /** check sending-hours if it is allowed to send the document now
    */
    bool IsInSendHours() const;
    
    /** check sending-hours if it is allowed to send the document now
    */
    void CheckSendHours() const
        throw (sophisTools::base::GeneralException);
    
    /** compares document of this message with document of already sent related message
    */
    void NeedToSend() const 
        throw (sophisTools::base::GeneralException);
    
    /** returns ID of transaction related to the message
    */
    sophis::portfolio::TransactionIdent GetSourceID() const { return sourceID;}

    /** returns version of transaction related to the message
    */
    long GetSourceVersion() const { return sourceVersion;}

    /** returns latest version of transaction related to the message
    */
    long GetSourceLatestVersion() const;

	/** returns true when message is netted
	*/
	bool isNettingMessage() const;

	/** Return true if option includeNettedMsg is set on true for the template used on the msg
	*/
	bool IncludeNettedMsg() const;

	/**
	@deprecated 5.3.4.5
	*/
	void DescribeMessage(tools::dataModel::DataSet& dataset, CSRMessage *message) const;

	/**
	* Serializes given message description into a DataSet
	*/

	void DescribeMessage(tools::dataModel::DataSet& dataset, CSRMessage *message
		, backoffice_kernel::ISROtcInput *otcInput, VCSRMessageXMLExtension*xmlExt) const;

	/**
	* Serializes message description into a Data
	* Fills directly the data with the message description
	* @since 5.3.2
	*/
	void Describe(tools::dataModel::Data & data, bool isNetting) const;

	void Describe(tools::dataModel::Data & data, bool isNetting
		, VCSRMessageXMLExtension* xmlExt) const;

	/**
	* Serializes message description into a DataSet
	* Creates a sub element "message" to the DataSet and fills it with the description
	* Cf. grammar "www.sophis.net/otc_message" in otc_message.xsd for this type
	*/
	void Describe(tools::dataModel::DataSet& dataSet) const;
	void Describe(tools::dataModel::DataSet& dataSet
		, VCSRMessageXMLExtension* xmlExt) const;

	/** 
	* Serializes toolkited extensions related to the message
	* @since 5.3.4
	*/
	void DescribeTKSourceXMLExtension( tools::dataModel::DataSet& dataset
		, backoffice_kernel::ISROtcInput *otcInput, VCSRMessageXMLExtension *xmlExt) const;

	/**
	* Creates otc input based on sourceType, sourceId and sourceVersion
	* otc input is cloned and has to be deleted after usage
	*/
	backoffice_kernel::ISROtcInput* CreateOtcInput(); 

	/***
	* Rollback any database changes made to date (usually used in conjunction with call to MultiSave
	* @since 7.1.2
	*/
	static void EndMultiSaveBad();

protected:
    mutable CSDocRetriever	*docRetriever;

private:
   	static const char*      __CLASS__; // for logging
};

typedef _STL::vector<CSRMessage> VCSRMessages;
typedef VCSRMessages::iterator	 IVCSRMessages;

	}
}

SPH_EPILOG

#endif // SPH_BO_OTC_MESSAGE_H
