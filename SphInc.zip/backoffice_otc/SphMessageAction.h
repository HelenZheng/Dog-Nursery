//(vvf, 15/10/3)
#ifndef _MessageAction_H_
#define _MessageAction_H_

#ifndef _SphPrototype_H_
	#include "SphTools/SphPrototype.h"
#endif
#ifndef _SphAlgorthm_H_
	#include "SphInc/tools/SphAlgorithm.h"
#endif

#ifndef _SphValidation_H_
	#include "SphInc/tools/SphValidation.h"
#endif

#define CONSTRUCTOR_MESSAGE_ACTION(derivedClass)			
#define WITHOUT_MESSAGE_ACTION(derivedClass)	
#define DECLARATION_MESSAGE_ACTION(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRMessageAction)
#define	INITIALISE_MESSAGE_ACTION(derivedClass, order,  name)\
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

#define CONSTRUCTOR_MESSAGE_EVENT(derivedClass)			
#define WITHOUT_CONSTRUCTOR_MESSAGE_EVENT(derivedClass)
#define DECLARATION_MESSAGE_EVENT(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRMessageEvent)
#define	INITIALISE_MESSAGE_EVENT(derivedClass, order,  name)\
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{
		class CSRMessage;

		/** Interface to trigger some actions when saving message.
		You can overload this class and insert your own triggers.
		*/
		class SOPHIS_BO_OTC CSRMessageAction
		{
		public:

			/** Specify the order of the triggers.
			*/
			enum	eOrder	{
				/** Before saving the data
				*/
				oBefore,
				
				/** Used internally : the code for saving is actually a trigger ordered by this enum
				*/
				oSave,

				/** After saving the data
				*/
				oAfter
			};


			/** Trivial constructor
			*/
			CSRMessageAction();
		
			/** Trivial destructor
			*/
			virtual ~CSRMessageAction();

			/** Ask for a creation of a message.
			When creating, first all the triggers will be called via VoteForCreation to check if they accept the
			creation in the order eOrder + lexicographical order.
			The message id can be  null; it will then be created by the Sophis trigger.
			@param message is the message to create. It is a non const object so that you can
			modify it.
			@throws VoteException if you reject that creation.
			*/
			virtual void VoteForCreation(CSRMessage& message)
				throw (tools::VoteException);

			/** Ask for accepting a modification
			When saving, first all the triggers will be called via VoteForModification to check if they accept the
			modification in the order eOrder + lexicographical order.
			@param original is the original message before any modification.
			@param message is the message to save. It is a non const object so that you can
			modify it.
			@throws VoteException if you reject that modification.
			*/
			virtual void VoteForModification(const CSRMessage& original, CSRMessage& message)
				throw (tools::VoteException);
            /** This version of VoteForModification is deprecated in favour of two parameter version of this function
            */
            virtual void VoteForModification(CSRMessage& message)
				throw (tools::VoteException);

			/** Ask for deletion of a message.
			When deleting, first all the triggers will be called via VoteForDeletion to check if they accept the
			deletion in the order eOrder + lexicographical order.
			@param message is the message to delete.
			@throws VoteException if you reject that deletion.
			*/
			virtual void VoteForDeletion(const CSRMessage& message)
				throw (tools::VoteException);

			/** Ask what to notify when creating.
			When saving, after that all the triggers have accepted the creation, they are called again 
			in the order eOrder + lexicographical order via
			NotifyCreated to check if they have something to save in the database or send to other servers.
			@param message is the message to create. It is a non const object so that you cannot
			modify it. The message id is created at this level by the trigger oCreation as well as
			the reference if empty.
			@param events is an event vector to put your events to send after the data are commited.
			Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
			event is in concordance with the database which will be the case after commiting. Moreover, if there
			is an exception in another trigger, the event must not be sent.
			@throws ExceptionBase if you reject that creation. Do not send a VoteException. This can cause
			some trouble, as in case of multi saving it will assume that no data or event is done. Do not commit, nor Rollback either,
			it is done elsewhere.
			*/
			virtual void NotifyCreated(const CSRMessage& message, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

			/** Ask what to notify when modifying.
			When saving, after that all the triggers have accepted the modification, they are called again 
			in the order eOrder + lexicographical order via
			NotifyModified to check if they have something to save in the database or send to other servers.
			@param original is the original message before any modification. It is a const object so that you cannot
			modify it.
			@param message is the message to save. It is a const object so that you cannot
			modify it.
			@param events is an event vector to put your events to send after the data are commited.
			Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
			event is in concordance with the database which will be the case after commiting. Moreover, if there
			is an exception in another trigger, the event must not be sent.
			@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
			some trouble, as in case of multi saving it will assume that no data or event is done. Do not commit, nor Rollback either,
			it is done elsewhere.
			*/
            virtual void NotifyModified(const CSRMessage& original, const CSRMessage& message, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

            /** This version of NotifyModified is deprecated in favour of three parameter version of this function
            */
			virtual void NotifyModified(const CSRMessage& message, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

			/** Ask what to notify when deleting.
			When deleting, after that all the triggers have accepted the creation, they are called again 
			in the order eOrder + lexicographical order via
			NotifyDeleted to check if they have something to delete in the database or send to other servers.
			@param message is the message to delete.
			@param events is an event vector to put your events to send after the data are commited.
			Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
			event is in concordance with the database which will be the case after commiting. Moreover, if there
			is an exception in another trigger, the event must not be sent.
			@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
			some trouble, as in case of multi saving it will assume that no data or event is done. Do not commit, nor Rollback either,
			it is done elsewhere.
			*/
			virtual void NotifyDeleted(const CSRMessage& message, tools::CSREventVector& events)
				throw (sophisTools::base::ExceptionBase); 

			/** key for the prototype is eOrder + lexicographical 
			*/
			typedef tools::ordered_name<eOrder> ordered_name;
			
			/** typedef for the prototype
			*/
			typedef tools::CSRPrototype<CSRMessageAction, ordered_name> prototype;

			/** access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_MESSAGE_ACTION
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Clone method needed by the prototype
			Usually, it is done automaticly by the macro DECLARATION_MESSAGE_ACTION
			@see tools::CSRPrototype
			*/
			virtual CSRMessageAction* Clone() const = 0;

		};

		/** Interface triggered when another workstation has modified the message
		You can overload this class and insert your own triggers
		*/
		class CSRMessageEvent
		{
		public:

			/** Specify the order of the triggers.
			*/
			enum	eOrder	{
				/** Before updating the data
				In the trigger, a call CSRMessage::GetCSRMessage will give the old message structure.
				*/
				oBefore,
				
				/** Used internally : the code for updating is actually a trigger ordered by this enum
				*/
				oUpdate,

				/** After updating the data
				In the trigger, a call CSRMessage::GetCSRMessage will give the new message structure.
				*/
				oAfter
			};


			/** Trivial constructor
			*/
			CSRMessageEvent();
		
			/** Trivial Destructor
			*/
			virtual ~CSRMessageEvent();

			/** Called when a message has been created in another workstation.
			When receiving a creation event for message, all the triggers are called by this method
			 in the order eOrder + lexicographical order.
			@param message is a message instance with the new data; note that this instance is not
			the one given by CSRMessage::GetCSRMessage and will be deleted soon; you can modify it in 
			listenner of type oBefore but it is not recommanded.
			@return false to bypass this event; In that case the other triggers are not executed
			and the windows are not updated; Use it with moderation, only in the case oBefore.
			*/
			virtual bool HasBeenCreated(CSRMessage& message);

			/** Called when a message has been updated in another workstation.
			When receiving an update event for message, all the triggers are called by this method
			 in the order eOrder + lexicographical order.
			@param message is a message instance with the new data; note that this instance is not
			the one given by CSRMessage::GetCSRMessage and will be deleted soon; you can modify it in 
			listenner of type oBefore but it is not recommanded.
			*/
			virtual void HasBeenModified(CSRMessage& message);

			/** Called when a message has been created in another workstation.
			When receiving a delete event for message, all the triggers are called by this method
			 in the order eOrder + lexicographical order.
			@param message is is the message before deletion.
			@return false to bypass this event; In that case the other triggers are not executed
			and the windows are not updated; Use it with moderation, only in the case oBefore.
			*/
			virtual void HasBeenDeleted(long code);

			/** key for the prototype is eOrder + lexicographical 
			*/
			typedef tools::ordered_name<eOrder> ordered_name;
			
			/** typedef for the prototype
			*/
			typedef tools::CSRPrototype<CSRMessageEvent, ordered_name> prototype;

			/** access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_MESSAGE_EVENT
			@see CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Clone method needed by the prototype
			Usually, it is done automatically by the macro DECLARATION_MESSAGE_EVENT
			@see CSRPrototype
			*/
			virtual CSRMessageEvent* Clone() const = 0;

		};

	} // namespace backoffice_otc
} // namespace sophis
SPH_EPILOG
#endif