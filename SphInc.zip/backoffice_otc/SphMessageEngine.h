/*
 	File:		SphMessageEngine.h

 	Contains:	Database interface for CSRMessage.

 	Copyright:	� 2001-2002 Sophis.

*/



#ifndef SPH_BO_OTC_MESSAGE_ENGINE_H
#define SPH_BO_OTC_MESSAGE_ENGINE_H

#ifndef _SphMacros_H_
	#include "SphInc/SphMacros.h"
#endif

#ifndef _SphVector_H_
	#include "SphTools/sphvector.h"
#endif

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include "SphSDBCInc/SphSQLDataTypes.h"

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


SPH_PROLOG


class CSBOEventNotifier;

namespace sophis	{
	namespace	sql	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

namespace sophis {
	namespace tools {
		class CSREventVector;
	}
}

namespace sophis
{
	namespace backoffice_otc
	{
		class CSRMessage;

		/** Enumerates actions that can be operated on CSRMessage.
		*/
		enum eEngineAction
		{
			eaAcceptPending			= 1,
			eaRefusePending,
			eaRegenerateConfs,
			eaRegeneratePayments,
			eaRefuseBlotters,
			eaUnknownAction,
			eaFOAction,
			eaFOAccept
		};
		enum eEngineResult
		{
			erNoError = 0,
			erInternalError,
			erBadAction,
			erBadStatus,
			erRegenerationImpossible,
			erNoInstrument,
			erNoThirdParty,
			erNoEntity,
			erNoDeal,
			erNoPostingAmountForTrade,
			erNoPostingDate,
			erNoSettlementLinks,
			erUnknownRecipientType,
			erNoPreviousNetting,
			erNoInstrumentOnMessage,
			erDeletedDeal,
			erBadStatusTransition,
			erFourEyesStatusError,
			erAccountingError,
			erRiskBOWSNotLoaded,
			erAccountsAreNotEqualFofSameSign,
			erSentToReadyReject
		};
// If you update the previous enum, you have to update
// CSRBOValidation::EngineException::ConvertToString
// in CSRBackOfficeValidation.cpp


		#define QUERY_SIZE 2048


		/** Database interface for CSRMessage. This engine also notifies through CSBOEventNotifier 
			blotters about changes with CSRMessage
		*/

		class  SOPHIS_BO_OTC CSRMessageEngine
		{
			// this is a singleton class
			CSRMessageEngine();
			~CSRMessageEngine();

	        static CSRMessageEngine* _this;

		public:
	
			/** use this method to acquire pointer to CSRMessageEngine singleton
				@returns CSRMessageEngine* pointer to CSRMessageEngine singleton
			*/
			static CSRMessageEngine* GetInstance();
			
			/** this is used to deallocate singleton, but really don't need to use
				this method as singleton object exist through all life of the application
				in only one copy.
			*/
			static void DestroyInstance();

			/** Resets Event Notifier.
				@returns erInternalError in case of error, erNoError - otherwise.
			*/
			eEngineResult ClearEventNotifier();
			
			/** Sends events to proxy if it is specified, otherwise events are sent to real-time server.
				@param proxy is proxy for delayed event sending, if it is not null events are not
					actually sent but rather accumulated in proxy for later sending. If it is not specified
					(is equal to NULL) events are instantly sent to real-time server.
				@returns erInternalError in case of error, erNoError - otherwise
			*/
			eEngineResult SendEvents( CSBOEventNotifier *proxy = 0);

			/** Updates message msg in database or creates it if it was not there.
                		@param eVector is used to feed data for RT message sending
				@param msg is CSRMessage to update
				@param saveNetted is a flag. If it is set to true all CSRMessages netted to 'msg'
					will also be updated, if it is set to false nothing will be updated besides 'msg'.
				@param reSending is a flag is a flag stating whether 'msg' is going to be resent. It has an effect 
					only if 'msg' was sent already.
				@returns erNoError in case of error, or code of error otherwise
				@see eEngineResult
			*/
			eEngineResult Update(sophis::tools::CSREventVector *eVector 
                                 ,CSRMessage* msg
                                 ,bool saveNetted=true
                                 , bool reSending = false);

			/** will give you the number of netting lines and the lines itself
				this is designed to be used in a bundle with UpdateNettedLines() when 
				provide to the last non-default parameters.
				@param netting is CSRMessage which could have netting messages
				@param nettedLines is the array of such a lines (if any)
				@returns the number of netted lines or 0 if none, or -1 if an error
			*/
			long GetUpdateNettedLinesNumber(const CSRMessage *netting, long *&nettedLines);
			
			/** get bo message by specified ident
				@param ident is the identifier in BO_MESSAGES
				@param is the out param to put CSRMessage buffer
				@returns erNoError in case of error, or code of error otherwise.
				@see eEngineResult
			*/
			eEngineResult GetMessageFromID(sophis::portfolio::TransactionIdent ident, CSRMessage **nettedMessages);

			/**
				get all messagees with in the netting group
				@param netting_id specified the netting ID for the netting group
				@nbNettedLines is the number of netted lines
				@param is the out param to put CSRMessage buffer
				@returns erNoError in case of error, or code of error otherwise.
				@see eEngineResult
			*/
			eEngineResult CSRMessageEngine::GetNettedLinesMessages(sophis::portfolio::TransactionIdent nettingID, long&nbNettedLines, CSRMessage **msg);

			/** updates netting lines which are netted to CSRMessage 'netting'.
				Note: if called with default arguments will be completely the same as 
				previous (commented out) version of this method. Otherwise - will update
				only the line specified by last argument and you have explicitly to call 
				GetUpdateNettedLinesNumber() first. With default parameters it uses 
				for-loop inside to modify all lines, with non-default it doesn't use 
				for-loop, so it is up to programmer to implement it.
                @param eVector is used to feed data for RT message sending
				@param netting is CSRMessage. Its netting messages are updated by this function.
				@returns erNoError in case of error, or code of error otherwise
				@see eEngineResult
				@param nbNettedLines - return value from GetUpdateNettedLinesNumber()
				@param nettedLines - return array from GetUpdateNettedLinesNumber()
				@param lineIdx - array index, indicating the line you want to deal with
			*/
			//eEngineResult UpdateNettedLines(CSRMessage *netting);
			eEngineResult UpdateNettedLines(sophis::tools::CSREventVector *eVector
                                            ,const CSRMessage *netting
											,long nbNettedLines = -1
											,long *nettedLines = 0
											,long lineIdx = -1);		// process only this line if not -1
	
			/** Updates only docID, docModification and remarks, all of them are mutable 
				@param eVector is used to feed data for RT message sending
				@param m is a BO message to process
				@param saveNetted is a flag. If it is set to true all CSRMessages netted to 'msg'
					will also be updated, if it is set to false nothing will be updated besides 'msg'.
			*/
			eEngineResult UpdateDoc(sophis::tools::CSREventVector *eVector, const CSRMessage *m, bool saveNetted=true);

			/** Updates CSRMessages status to msSentReversed.
               	@param eVector is used to feed data for RT message sending
				@param sentMessages is an array of CSRMessages to process.
				@param nbSent is a number of CSRMessages in 'sentMessages' array.
				@returns erNoError in case of error, or code of error otherwise.
				@see eEngineResult
				@see CSRMessage::eMessageStatus
				@param lineIdx if provided indicates what exactly line to modify
			*/
			//eEngineResult UpdateSentMessageStatus(CSRMessage *sentMessages, long nbSent);
			eEngineResult UpdateSentMessageStatus(sophis::tools::CSREventVector *eVector
                                                  ,CSRMessage *sentMessages
                                                  ,long nbSent
                                                  ,long lineIdx = -1);	// process only this line if not -1

			/** Deletes CSRMessages from database.
                		@param eVector is used to feed data for RT message sending
				@param msg is an array of CSRMessages to delete
				@param nb is a number of CSRMessages in 'msg' array
				@returns erNoError in case of error, or code of error otherwise
				@see eEngineResult
				@param lineIdx if provided idicates what exactly line to delete
			*/
			//eEngineResult Delete(CSRMessage* msg, int nb = 1);
			eEngineResult Delete(sophis::tools::CSREventVector *eVector
                                 ,CSRMessage* msg
                                 ,int nb = 1
                                 ,int lineIdx = -1);			// process all only this line if not -1

			/** Retrieves CSRMessage by its ident. Data will be copied to object referenced by msg 
				so this pointer should be valid, or you'll get the crush.
				@param ident is ident of CSRMessage to retrieve
				@param msg is pointer to object to store retrieved CSRMessage
				@returns erInternalError in case of error, erNoError - otherwise
			*/
			eEngineResult GetData1( sophis::portfolio::TransactionIdent ident, CSRMessage *msg);

			/** Retrieves CSRMessage by its linkReversalID. Data will be copied to object 
                referenced by msg, so this pointer should be valid, or you'll get the crush.
				@param linkReversalID is linkReversalID of CSRMessage to retrieve
				@param msg is pointer to object to store retrieved CSRMessage
				@returns erInternalError in case of error, erNoError - otherwise
			*/
            eEngineResult GetData1ByLinkReversalID( sophis::portfolio::TransactionIdent linkReversalID, CSRMessage *msg);
			
			/** Retrieves CSRMessage using where clause. Data won't be copied and the memory 
				needs to set free afterwards.
				@param msg is pointer to an array to store retrieved CSRMessages
				@param size is a size of array of stored CSRMessages
				@param where is csrstring that contains criteria to retrieve CSRMessages
				@returns erInternalError in case of error, erNoError - otherwise
			*/
			eEngineResult GetDataN( CSRMessage **msg, int *size, sophisTools::csrstring where = "");

			/** Retrieves CSRMessage using binded where clause using a series of integer parameters.
				Data won't be copied and the memory needs to set free afterwards.
				@param msg is pointer to an array to store retrieved CSRMessages
				@param size is a size of array of stored CSRMessages
				@param where is csrstring that contains criteria to retrieve CSRMessages
				@param whereParameter is a list containing the series of integers to give as parameters
				@returns erInternalError in case of error, erNoError - otherwise
			*/
			eEngineResult GetDataN(CSRMessage **msg, int *size, sophisTools::csrstring where, _STL::list<long long>& whereParameters);

			/** Counts the messages that have the id passed as a parameter as a reversal
			*/
			eEngineResult CountLinkReversalMessages(long *count, long reversalId);			
			
			eEngineResult GetDataNForReverseOldMessages( sophis::portfolio::TransactionIdent tradeId, long grpCode, _STL::vector<long> recipients, CSRMessage **msg, int *size);
			
			/** retrieves CSRMessage using where clause. Data won't be copied and the memory 
				needs to set free afterwards.
				@param msg is csrvector to store retrieved CSRMessages (so we do not need to pass the size)
				@param where is csrstring that contains criteria to retrieve CSRMessages
				@param unionWhere is csrstring that contains additional criteria to unify with previous where clause
				@returns erInternalError in case of error, erNoError - otherwise
			*/
			eEngineResult GetDataN( sophisTools::csrvector& msg, sophisTools::csrstring where, sophisTools::csrstring unionWhere);

						
			/** could be used to put all events from EventNotifier (fEventNotifier) into 
				external EventVector. This could be usful to force events to be 
				sent through ev.ExecuteAll().
				@param ev - reference to external CSREventVector
			*/

		public:
			void PutEventNotifierIntoEventVector(sophis::tools::CSREventVector &ev);

			/** Loads messages and their related trade information into a CSRMessage[]
				The information loaded is later accessible via the getMessageCount() and getMessagePtr(int _index) methods
				These functions allow the message engine to be used in the same way as the CSRInstructionLoader
				
				@param _whereClause
				The SQL where clause to use to retrieve the messages (must not contain the keyword WHERE at the beginning)

				@param whereParameters
				A list containing the series of integers to give as parameters
				*/
			int load(_STL::string _whereClause, _STL::list<sophis::portfolio::TransactionIdent>& whereParameters);
			/** Same as above.
				
				@param _whereClause
				The SQL where clause to use to retrieve the messages (must not contain the keyword WHERE at the beginning)
			*/
			int load(_STL::string _whereClause);
			/** Returns the count of loaded messages
			 */
			int getMessageCount() const;

			/** Returns the message at position _index from the loaded messages
			 */
			CSRMessage* getMessagePtr(int _index);

			/** Returns a copy of the message at position _index from the loaded messages
			 */
			CSRMessage* getMessageCopyPtr(int _index);

		protected:
			void ClearList();

			struct SSNettedUpdateItems
			{// it's always one these fields that are modified on netted lines
			 // when modification on a netting line takes place
				long	status;
				long	matchDate;
				long	userID;
				long	docID;
				long	ident;
			};

			struct SSUpdateDocItems
			{
				long	docID;
				long	docModification;
				char	remarks[512];
				char	docNotes[256];
				long	ident;
			};

			eEngineResult InitDescriptor();
			eEngineResult InitFilterDescriptor();

			eEngineResult InitInsertQuery();
			eEngineResult InitUpdateQuery();
			eEngineResult InitUpdateNettedLineQuery();
			eEngineResult InitUpdateNettedGroupQuery();
			eEngineResult InitUpdateDocQuery();
			eEngineResult InitDeleteQuery();
			eEngineResult InitFilterQuery();
			
			sophis::sql::CSRStructureDescriptor	*fDescriptorData;
			sophis::sql::CSRStructureDescriptor	*fFilterDescriptorData;
			sophis::sql::CSRStructureDescriptor	*fDescriptorUpdateNetted;
			sophis::sql::CSRStructureDescriptor	*fDescriptorUpdateNettedGroup;
			sophis::sql::CSRStructureDescriptor	*fDescriptorUpdateDoc;
			sophis::sql::CSRStructureDescriptor	*fDescriptorDelete;

			sophis::sql::CSRSqlQuery				*fInsert;
			sophis::sql::CSRSqlQuery				*fUpdate;
			sophis::sql::CSRSqlQuery				*fUpdateDoc;
			sophis::sql::CSRSqlQuery				*fUpdateNettedLine;
			sophis::sql::CSRSqlQuery				*fUpdateNettedGroup;
			sophis::sql::CSRSqlQuery				*fDelete;

			char	  				fInsertQuery[QUERY_SIZE];
			char	  				fUpdateQuery[QUERY_SIZE];
			char	  				fUpdateNettedLineQuery[QUERY_SIZE];
			char	  				fUpdateDocQuery[QUERY_SIZE];
			sophisTools::csrstring	fFilterQuery;


			typedef struct SSFilterParams
			{
				long transactionId;
				long grpCode;
			};

			typedef struct SSFilter2Params
			{
				long transactionId;
				long version;
				long grpCode;
				char recipients[512];
			};

			typedef struct SSLong
			{
				long value;
			};

			typedef struct SSLongLong
			{
				sophis::portfolio::TransactionIdent value;
			};

			sophis::sql::CSRStructureDescriptor		*fFilterParams;
			sophis::sql::CSRStructureDescriptor		*fFilter2Params;
			sophis::sql::CSRStructureDescriptor		*fLongParams;
			sophis::sql::CSRStructureDescriptor		*fLongLongParams;

			sophis::sql::CSRSqlQuery				*fCountLinkReversalMessages;
			char									*fCountLinkReversalMessagesQuery;			

			sophis::sql::CSRSqlQuery				*fSelectGetData1;
			char									*fSelectGetData1Query;

			sophis::sql::CSRSqlQuery				*fSelectGetDataByReversalId;
			char									*fSelectGetDataByReversalIdQuery;

			sophis::sql::CSRSqlQuery				*fSelectSentMessages;
			char									*fSelectSentMessagesQuery;

			sophis::sql::CSRSqlQuery				*fSelectUnsentMessages;
			char									*fSelectUnsentMessagesQuery;

			sophis::sql::CSRSqlQuery				*fSelectNettingLines;
			char									*fSelectNettingLinesQuery;

			sophis::sql::CSRSqlQuery				*fSelectNettedLines;
			char									*fSelectNettedLinesQuery;

			int	m_MessageListCount;
			CSRMessage* m_MessageList;
		};

	}
}

SPH_EPILOG

#endif // SPH_BO_OTC_MESSAGE_ENGINE_H
