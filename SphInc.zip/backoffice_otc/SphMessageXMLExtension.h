#ifndef __CS_MESSAGE_XML_EXTENSION_H__
#define __CS_MESSAGE_XML_EXTENSION_H__


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_MESSAGEXMLEXTENSION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRMessageXMLExtension)
#define CONSTRUCTOR_MESSAGEXMLEXTENSION(derivedClass)
#define WITHOUT_CONSTRUCTOR_MESSAGEXMLEXTENSION(derivedClass)
#define	INITIALISE_MESSAGEXMLEXTENSION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {	

	namespace backoffice_kernel {
		class ISROtcInput;
	}

	namespace backoffice_otc {
		class CSRMessage;
	}
	namespace tools {
		namespace dataModel {
			class DataSet;
		}
	}

	namespace backoffice_otc {
		class CSRMessage;

		class SOPHIS_BO_OTC CSRMessageXMLExtension
		{
		public:
			/** This method must be overridden in order to provide a name
			for the dataset/extra XML node. By default, it uses 'ToolkitXML'.
			*/
			virtual _STL::string getExtraXMLDatasetName() const = 0;

			/** Overidden in order to provide custom XML extensions to messages, by adding extra 
			information in a DataSet.

			@param currentTransaction
			A (const) reference to the transaction relating to this message.

			@param dataSetToFill
			A DataSet that the implementer may fill as it chooses.
			*/
			virtual void IncludeExtraDataWithDataset(const backoffice_kernel::ISROtcInput* otcInput, 
				const backoffice_otc::CSRMessage* currentOtcMessage, 
				tools::dataModel::DataSet* dataSetToFill) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_MESSAGEXMLEXTENSION.
			@see tools::CSRPrototype
			*/
			virtual CSRMessageXMLExtension* Clone() const { throw 1; }

			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef tools::CSRPrototype<CSRMessageXMLExtension, const char *, tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();	
		};

		typedef _STL::vector<sophis::backoffice_otc::CSRMessageXMLExtension*> VCSRMessageXMLExtension;
		typedef VCSRMessageXMLExtension::iterator							  IVCSRMessageXMLExtension;
		typedef VCSRMessageXMLExtension::const_iterator						  CIVCSRMessageXMLExtension;
	}
}
SPH_EPILOG
#endif //#define __CS_MESSAGE_XML_EXTENSION_H__
