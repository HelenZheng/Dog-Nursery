/*
File:		SphOTCColumn.h

Contains:	Class for the handling of Payment and Conformation columns

Copyright:	� 2004 Sophis.
*/
#pragma once

#ifndef _SphOTCColumn_H_
#define _SphOTCColumn_H_

#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"


struct SSCellStyle;
union SSCellValue;

#define DECLARATION_OTC_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::backoffice_otc::CSROTCColumn)
#define	INITIALISE_OTC_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis	{
	namespace portfolio {
		class CSRTransaction;
	}
	namespace backoffice_cash {
		class CSRInstruction;
	}
	namespace backoffice_otc {
		class CSRMessage;

		/** Interface that provides access to transactions.
		@since 5.2.1
		*/
		class SOPHIS_BO_OTC CSTransactionCacheMgr
		{
		public:
			virtual ~CSTransactionCacheMgr() {}

			/** Returns Transaction by trade id and trade version.
			@param tradeId is the trade id of the transaction to return.
			@param tradeVer is the trade version of the transaction to return.
			*/
			virtual const sophis::portfolio::CSRTransaction& GetTransaction(portfolio::TransactionIdent tradeId, long tradeVer) const = 0;
		};

		/** Interface to handle columns in transaction dialogs.
		To add a column, derive this class, using the macro DECLARATION_OTC_COLUMN in your header
		and INITIALISE_OTC_COLUMN in UNIVERSAL_MAIN.
		The main methods providing the values to display must have no MFC code.
		For example, you cannot show a dialog using CSRFitDialog::Message.
		This can produce error MFC messages or alter the window itself.
		Also note that use of the class {@link CSRSqlQuery} method to write certain
		queries. In the verbose mode, errors generate a dialog. It is better to disable
		the verbose mode using {@link CSRSqlQuery::SetVerbose} and to deal with the
		error code yourself.
		@see CSRPortfolioColumn
		@since 5.2.1
		*/
		class SOPHIS_BO_OTC CSROTCColumn
		{
		public:
			/** Main method to display the content of OTC message.
			@param msg is the OTC message to be displayed.
			@param transactions is the cache of transactions.
			@param value is an output parameter, used to return the value to be displayed.
			@param style is an output parameter, used to describe the style and the data type.
			@param onlyTheValue optimises the return for sorting, where only the value is needed (and the data type).
			*/
			virtual	void	GetCell(
				const backoffice_otc::CSRMessage & msg,
				const CSTransactionCacheMgr& transactions,
				SSCellValue			*value,
				SSCellStyle			*style,
				bool				onlyTheValue) const = 0;

			/** Main method to display the content on netted line.
			@param instr is the netting instruction to be displayed.
			@param transactions is the cache of transactions.
			@param value is an output parameter, used to return the value to be displayed.
			@param style is an output parameter, used to describe the style and the data type.
			@param onlyTheValue optimises the return for sorting, where only the value is needed (and the data type).
			*/
			virtual	void	GetCell(
				const backoffice_cash::CSRInstruction & instr,
				const CSTransactionCacheMgr& transactions,
				SSCellValue			*value,
				SSCellStyle			*style,
				bool				onlyTheValue) const = 0;

			/** Define the default size in pixels.
			*/
			virtual short	GetDefaultWidth() const;


			/** Icon id to display when grouping by that column.
			@return a short id corresponding to a resource bmp sith a shift of 1000.
			*/
			virtual short GetGroupIcon() const;


			/** Get the id .
			The value is created at the end of the initialise because it must
			be unique according to the table COLUMN_NAME.
			*/
			int GetId() const;

			/** Set the id.
			Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id);

			/** Typedef for the prototype : the key is a const char *.
			*/
			typedef tools::CSRPrototypeWithId<CSROTCColumn, const char *, tools::less_char_star> prototype;
			/** Access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_INSTRUMENT_FACTORY
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

		protected:
			long	fId;
		};
	}
}
SPH_EPILOG
#endif
