/*
 	File:	SphOTCCondition.h

 	Contains:	Abstract base class which can be used to extend popup menu of Condition1, 
				Condition2, Condition3 columns of OTC Workflow Definition window to add client 
				specific funcionality.

 	Copyright:	� 1995-2003 Sophis.

*/

/*! \file SphOTCCondition.h
	\brief Abstract base class which can be used to extend popup menu of Condition1, 
		   Condition2, Condition3 columns of OTC Workflow Definition window to add client 
		   specific funcionality.
*/

#ifndef __SphOTCCondition_H_
#define __SphOTCCondition_H_
#pragma once


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_OTCWF_DEFINITION_CONDITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSROTCCondition)
#define CONSTRUCTOR_OTCWF_DEFINITION_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_OTCWF_DEFINITION_CONDITION(derivedClass)
/*
 *	Macro to be placed in the clients <main>.cpp to register derived client classes
 *	with the prototype framework.
 *	
 *	@param derivedClass is the name of the client derived class.
 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 *	Workflow Definition window.
 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
 */
#define	INITIALISE_OTCWF_DEFINITION_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace backoffice_otc {
        
        class CSRMessage;
		/** Interface to create a new condition to select an otc workflow or a rule in an otc workflow.
		Only available with back office otc.
		When creating or modifying a bo message, the otc engine will first select an otc workflow browsing the
		otc workflows selector; when the criteria matches, it plays the user conditions. A new condition can be added
		by implementing this interface. Once the otc workflow has been selected, then same engine selects an otc rule
		browsing the otc worflow rule; when the criteria matchs, it plays the same user conditions.
		@since 4.5.2
		*/
		class SOPHIS_BO_OTC CSROTCCondition 
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSROTCCondition() {}

			/*
			 *	Pure virtual method.
			 *	Used by the framework while selecting the rule from otc Workflow Definition rules set.
			 *	Method is called for Condition1, Condition2, Condition3 columns. Logical 'AND' is used
			 *	to make decision if to select the matching rule - found by framework.
			 *	The result has to be TRUE to make the rule selected.
			 *	@msg is the reference to the bo message;
			 *	@return is the boolean and is calculated by the client code.
			 */
			virtual bool GetCondition(const CSRMessage& msg) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_OTCWF_DEFINITION_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSROTCCondition* Clone() const = 0;

			/** typedef for the prototype : the key is a string
			*/
			typedef sophis::tools::CSRPrototype<CSROTCCondition, 
												const char *, 
												sophis::tools::less_char_star> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_WORKFLOW_DEF_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

	}	// namespace backoffice_otc
}		// namespace sophis
SPH_EPILOG
#endif //__SphOTCCondition_H_
