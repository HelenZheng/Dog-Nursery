/*
 	File:		SphOTCEditModel.h
 
 	Contains:	Base class to determine a model comprising editable fields of BO message
                it is almost identical to CSRKernelRights
 
 	Copyright:	� 2001-2003 Sophis.
*/

#pragma once

#ifndef _SphOTCEditModel_h_
#define _SphOTCEditModel_h_

#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/backoffice_kernel/SphEditModel.h"

/*
 *	Macro to be used instead of the Clone() method in the clients derived classes.
 *	Prototype framework will be responsible to instantiate clients objects.
 *	
 *	@param derivedClass is the name of the client derived class.
 */
#define DECLARATION_OTC_EDIT_MODEL(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSROTCEditModel)
#define CONSTRUCTOR_OTC_EDIT_MODEL(derivedClass)
#define WITHOUT_OTC_EDIT_MODEL(derivedClass)
/** macro used for installing the edit model in Risk
	@param derivedClass is the type of model derived from CSREditModel
	@param name is the name of this model which will be used to store it in 
	database and for building menu of all edit models
*/
#define	INITIALISE_OTC_EDIT_MODEL(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

		/** Interface to describe fields of BO message to be able to modify.
		This is used in a workflow rule to disable events applicable to the BO message.
		@since 4.7.0
		*/
        class SOPHIS_BO_OTC CSROTCEditModel: public virtual backoffice_kernel::CSREditModel
		{
		public:

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_OTC_EDIT_MODEL.
			@see tools::CSRPrototype
			*/
			virtual CSROTCEditModel* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSROTCEditModel, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

		protected:
			CSROTCEditModel();
		} ;
	}
}
SPH_EPILOG
#endif // _SphOTCEditModel_h_

