#ifndef __SPHOTCEngine_H_
#define __SPHOTCEngine_H_


#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis {
	namespace tools	{
		class CSREventVector;
	}
	namespace backoffice_otc {

        class CSRMessage;

		/** Interface to define an action in OTC engine.
		An OTC action is run when an event is executed on a BO Message 
        (for instance a modification of generation of template).
		@since 4.7.0
		*/
		class SOPHIS_BO_OTC CSROTCEngine
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSROTCEngine() {}

			/** Method called when an event is executed on a BO Message and the OTC workflow tells to execute this action.
			This is called during an internal notify BO message action.
			@param boMessage is the new, modified or deleted BO Message.
			@param mess is a list of events to add your own messages.
			*/
			virtual void Run( const CSRMessage& boMessage
							  ,tools::CSREventVector & mess) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_OTC_ENGINE.
			@see tools::CSRPrototype
			*/
			virtual CSROTCEngine* Clone() const = 0;

			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSROTCEngine
												,const char *
												,sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_OTC_ENGINE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};
	}
}

#define DECLARATION_OTC_ENGINE(derivedClass) DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSROTCEngine)
#define CONSTRUCTOR_OTC_ENGINE(derivedClass)
#define WITHOUT_CONSTRUCTOR_OTC_ENGINE(derivedClass)
#define	INITIALISE_OTC_ENGINE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_EPILOG


#endif //__SPHOTCEngine_H_
