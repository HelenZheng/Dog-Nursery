#pragma once

#include "SphTools/sphvector.h"
#include "SphInc/SphMacros.h"
#include "SphMessage.h"
#include "SphBOEnums.h"

namespace sophis
{
	namespace backoffice_otc
	{

		enum eBOAPICategory
		{
			ecatGuiApi = 1,
			ecatApiOnly
		};

		enum eBOSTP
		{
			eboNotSTP = 1,
			eboSTP
		};

		struct SOPHIS_BO_OTC OTCEvent
		{
			long	id;
			char	name[OTC_EVENT_NAME+AUDIT_DATE_TIME];
			char	comments[COMMENTS_LENGTH];
			eBOAPICategory	category;
			eBOSTP			stp;

			OTCEvent():	id(0)
			{
				name[0] = '\0';
				comments[0] = '\0';
				category = ecatGuiApi;
			}
			OTCEvent(long i, char *n, char *c, eBOAPICategory cat, eBOSTP s): id(i), category(cat), stp(s)
			{
				strcpy( name, n);
				strcpy( comments, c);
			}
			OTCEvent( const OTCEvent& e): id(e.id), category(e.category), stp(e.stp)
			{
				strcpy( name, e.name);
				strcpy( comments, e.comments);
			}
		};

		struct SOPHIS_BO_OTC OTCWFRule
		{
			long eventID;
			long initialStatus;
			long finalStatus;
			long actionToDo;
			char rightToHave1[USERRIGHT_LENGTH];
			char rightToHave2[USERRIGHT_LENGTH];
			char modifiableFields1[FIELDMODIF_LENGTH];
			char modifiableFields2[FIELDMODIF_LENGTH];
			char condition1[CONDITION_LENGTH];
			char condition2[CONDITION_LENGTH];
			char condition3[CONDITION_LENGTH];
			char comments[COMMENTS_LENGTH];
			char checkBOMessage[CHECK_BOMESSAGE_LENGTH];
			long ignore;
			short stop;

			OTCWFRule() {}
			OTCWFRule(long ev_i, long is_i, long fs_i, long act_i
				,char *r1_i, char *r2_i, char *mf1_i, char *mf2_i
				,char *c1_i, char *c2_i, char *c3_i, char *cmt_i
				,char *ch_i, long ig_i, short stop_i);
			OTCWFRule( const OTCWFRule&r);

			bool operator==(const OTCWFRule &rule) const;
		};

		struct SOPHIS_BO_OTC OTCWFRuleID: public OTCWFRule
		{
			long ruleID;

			OTCWFRuleID()	{}
			OTCWFRuleID( long rid, OTCWFRule& r);
			OTCWFRuleID( const OTCWFRuleID &ri);

			bool IsConditionMet(const CSRMessage& boMsg);
		};

		class SOPHIS_BO_OTC CSROTCEnvironmentWrapper
		{
		public:
			
			bool    GetOTCEvent( long id, OTCEvent& e);

			/** Determine if a transition can be automatically applied to a transaction
			@param t is the final (resp. initial) for a deal created or modified (resp.canceled).
			@param rule_id is the output for the rule id that is to be applied to the transaction
			*/
			virtual bool CanPerformSTPTransition(const sophis::backoffice_otc::CSRMessage &msg, OTCWFRuleID &r);

			/** Find the rule for a message.
			@param msg is the final (resp. initial) for a message created or modified (resp. canceled).
			@param isid is the initial status of the message.
			@param eid is the event to apply to the message.
			@param r is the output for the data of the rule.
			@return true if rule found.
			*/
			virtual bool    FindRuleByInitialStatusAndEvent( const CSRMessage& msg, long isid, long eid, OTCWFRuleID& r);
		};
	}
}