/*
 	File:		SphPaymentStatus.h

 	Contains:	Class for describing payment statuses.

 	Copyright:	� 2001-2002 Sophis.

*/

#ifndef SPH_BO_OTC_PAYMENT_STATUS
#define SPH_BO_OTC_PAYMENT_STATUS



#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"

SPH_PROLOG
namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRPaymentStatus

/** Represents external statuses for incoming messages.
*/

class SOPHIS_BO_OTC CSRPaymentStatus
{
public:

	CSRPaymentStatus();
	CSRPaymentStatus(const CSRPaymentStatus& im);
	~CSRPaymentStatus();

	void Init();

	long		fStatus;
	char		fComments[100];
};
////////////////////////////////////////////////////////////////////////////////

	}
}

SPH_EPILOG
#endif //  SPH_BO_OTC_EXTERNAL_STATUS

