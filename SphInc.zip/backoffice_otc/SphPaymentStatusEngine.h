/*
 	File:		SphPaymentStatusEngine.h

 	Contains:	Database interface to handle payment statuses.

 	Copyright:	� 2001-2002 Sophis.

*/

/*! \file SphPaymentStatusEngine.h
	\brief Database interface for handling payment statuses.
*/

#ifndef SPH_BO_OTC_PAYMENT_STATUS_ENGINE
#define SPH_BO_OTC_PAYMENT_STATUS_ENGINE

#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

#include "SphInc/SphMacros.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/backoffice_otc/SphPaymentStatus.h"


SPH_PROLOG


namespace sophis
{
	namespace backoffice_otc
	{

////////////////////////////////////////////////////////////////////////////////
//	CSRPaymentStatusEngineException

/** General exception.
Exception thrown when there are problems with retrieval or inserting payment status
	in the database or if a payment status ID does not exist in the engine.
	Generally, this exception is for all problems in CSRPaymentStatusEngine.
	@see CSRPaymentStatusEngine
*/
class SOPHIS_BO_OTC CSR_PSE_Exception : public sophisTools::base::GeneralException
{
public:

	/** Constructor.
		@param description is the description of the error.
		@param file is the file name where this exception is thrown.
		@param lineNumber is the place in the file where this exception is thrown.
		@param function is the name of function issuer of exception
	*/
	CSR_PSE_Exception(char* description, char* fileName, long lineNumber, char* function);

	const _STL::string GetDescription() const;
	const _STL::string GetFileName() const;
	const long GetLineNumber() const;
	const _STL::string GetFunction() const;

private:
	_STL::string fDescription;
	_STL::string fFileName;
	long fLineNumber;
	_STL::string fFunction;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//	CSRPaymentStatusEngine

/** Interface used to handle Payment Statuses for incoming messages.
*/
class SOPHIS_BO_OTC CSRPaymentStatusEngine
{
public:
	CSRPaymentStatusEngine();
	~CSRPaymentStatusEngine();

	/** Retrieves and stores Payment Status in the engine by its code.
		@param status is the status code.
		@throws CSR_PSE_Exception if the database query fails.
	*/
	void RetrieveWithStatus(long status)
		throw (CSR_PSE_Exception);

	/** Retrieves all payment statuses.
		@throws CSR_PSE_Exception if the database query fails.
	*/
	void RetrieveAll()
		throw (CSR_PSE_Exception);

	/** Payment status numbers.
	@returns the number of Payment Statuses retrieved from database.
	*/
	long GetResultsListLength() const;

	/** Payment status by index.
	@returns Payment Status by its index in the engine
		@param index is index of payment status in the engine.
			Do not use index for the payment status ID. If you want to find an external
			status by its ID using this function, you have to scan all of them in sequence.
		@throws CSR_ESE_Exception if index is out of range.
	*/
	const CSRPaymentStatus& GetResult(long index) const
		throw (CSR_PSE_Exception);

	/** Adds new Payment Status in database.
		@param es is the payment status to insert in database.
		@throws CSR_ESE_Exception if insertion failed.
	*/
	static void CSRPaymentStatusEngine::addPaymentStatus(CSRPaymentStatus& es)
		throw (CSR_PSE_Exception);

private:
	void PerformQuery(char* where)
        throw (CSR_PSE_Exception);

	_STL::vector<CSRPaymentStatus>	fPSs;
};
////////////////////////////////////////////////////////////////////////////////

	}
}



SPH_EPILOG

#endif //  SPH_BO_OTC_PAYMENT_STATUS_ENGINE

