/*
 	File:		SphRulesConditionPayment.h

 	Contains:	Base Class of posting amount for payment prototypes.

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphPostingAmountForPayment.h
	\brief Base Class of posting amount for payment prototypes
*/

#ifndef _SphPostingAmountForPayment_H_
#define _SphPostingAmountForPayment_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

/** Macro defines Clone function for instantiating of derivedClass posting.
	@param derivedClass is the type of posting derived from CSRPostingAmountForPayment.
*/
#define DECLARATION_POSTING_AMOUNT_FOR_PAYMENT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRPostingAmountForPayment)

#define CONSTRUCTOR_POSTING_AMOUNT_FOR_PAYMENT(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_AMOUNT_FOR_PAYMENT(derivedClass)

/** Macro used for installing the posting in RISQUE.
	@param derivedClass is the type of posting derived from CSRPostingAmountForPayment.
	@param name is the name of this posting which will also be used to
	build a menu of all posting amounts for payment.
*/
#define	INITIALISE_POSTING_AMOUNT_FOR_PAYMENT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_otc
	{
		class CSRIncomingMessage;

		/** Interface to create a posting amount from a payement.
		It is used by the payement engine in the BOWS Server.
		You can implement this interface to add an amount on the list.
		@since 4.5.0
		@see CSRPostingDatePayment
		*/
		class SOPHIS_BO_OTC CSRPostingAmountForPayment
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingAmountForPayment() {}

			/** Get the amount to post.
			Method called by the settlement engine in the BOWS server to calculate the amount to post 
			when receiving a confirmation of a payement.
			@param trade is a transaction involved in the posting.
			@param inMessage is an incoming message involved in the posting.
			@param currency is a currency of posting. It is set by this function.
			@param instrument is the instrument of transaction. It is set by this function.
			@returns amount of this posting
			*/
			virtual double get_posting_amount(
						const portfolio::CSRTransaction& trade,
						const CSRIncomingMessage& inMessage,
						long* currency,
						long* instrument) const = 0;

			/** Get the singleton for one posting amount.
			This is equivalent to CSRPostingAmountForPayment::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the amount name is not found.
			@param modelName is a C string for the amount.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingAmountForPayment* getInstance( const char* modelName ) ;


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_AMOUNT_FOR_PAYMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingAmountForPayment* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingAmountForPayment
							,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_POSTING_AMOUNT_FOR_PAYMENT.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
};
SPH_EPILOG
#endif
