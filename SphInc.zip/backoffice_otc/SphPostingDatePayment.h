/*
 	File:		SphRulesConditionPayment.h

 	Contains:	Base Class for posting date payment prototype.

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphPostingDatePayment.h
	\brief Base Class for posting date payment prototype
*/

#ifndef _SphPostingDatePayment_H_
#define _SphPostingDatePayment_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

/** Macro defines the Clone function for instantiating the derivedClass posting.
	@param derivedClass is the type of posting derived from CSRPostingDatePayment
*/
#define DECLARATION_POSTING_DATE_PAYMENT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRPostingDatePayment)

#define CONSTRUCTOR_POSTING_DATE_FOR_PAYMENT(derivedClass)
#define WITHOUT_CONSTRUCTOR_POSTING_DATE_PAYMENT(derivedClass)

/** Macro used for installing the posting in RISQUE.
	@param derivedClass is the type of posting derived from CSRPostingDatePayment.
	@param name is the name of this posting which will also be used to
	build a menu of all posting dates.
*/
#define	INITIALISE_POSTING_DATE_PAYMENT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_otc
	{
		class CSRIncomingMessage;

		/** Interface to create a date amount from a payement.
		It is used by the payement engine in the BOWS Server.
		You can implement this interface to add a date on the list.
		@since 4.5.0
		@see CSRPostingAmountForPayment
		*/
		class SOPHIS_BO_OTC CSRPostingDatePayment
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRPostingDatePayment() {}

			/** Return the posting date.
			Method called by the settlement engine in the BOWS server to calculate the date to post 
			when receiving a confirmation of a payement.
			@param inMess is an incoming message.
			@param trade is the transaction.
			@returns date which corresponds to this posting.
			*/
			virtual long get_posting_date(const CSRIncomingMessage &inMess,
										  const portfolio::CSRTransaction& trade ) const = 0;

			/** Get the singleton for one posting date.
			This is equivalent to CSRPostingDatePayment::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the amount name is not found.
			@param modelName is a C string for the posting date.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRPostingDatePayment* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_POSTING_DATE_PAYMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRPostingDatePayment* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRPostingDatePayment
					,const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add a posting date to this singleton, use INITIALISE_POSTING_DATE_PAYMENT.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;

	}
};

SPH_EPILOG
#endif
