/*
 	File:		SphRulesConditionPayment.h

 	Contains:	Base Class for payment rules conditions.

 	Copyright:	� 2002-2003 Sophis.
*/

/*! \file SphRulesConditionPayment.h
	\brief Base Class for payment rules conditions
*/

#ifndef _SphRulesConditionPayment_H_
#define _SphRulesConditionPayment_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

/** Macro defines Clone function for instantiating the derivedClass posting.
	@param derivedClass is the type of posting derived from CSRRulesConditionPayment.
*/
#define DECLARATION_RULES_CONDITION_PAYMENT(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::backoffice_otc::CSRRulesConditionPayment)

#define CONSTRUCTOR_RULES_CONDITION_PAYMENT(derivedClass)
#define WITHOUT_CONSTRUCTOR_RULES_CONDITION_PAYMENT(derivedClass)

/** Macro used for installing the posting in RISQUE.
	@param derivedClass is the type of posting derived from CSRRulesConditionPayment.
	@param name is the name of this posting which will also be used to
	build a menu of all rule conditions.
*/
#define	INITIALISE_RULES_CONDITION_PAYMENT(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis
{
	namespace portfolio
	{
		class CSRTransaction;
	}

	namespace backoffice_otc
	{
		class CSRIncomingMessage;

		/** Interface to create a condition for the payement engine.
		It is used as a condition to know if a payement rule has to be applied.
		You can implement this interface to add a condition on the list.
		@since 4.5.0
		*/
		class SOPHIS_BO_OTC CSRRulesConditionPayment
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRRulesConditionPayment() {}

			/** Tell if the rule applied according the condition.
			This is called by the payement engine in the BOWS to know if a confirmation of a payement
			has to be applied after all the other criteria matches.
			@param inMess is the incoming Message involved in condition rule.
			@param trade is the transaction involved in the condition rule.
			@returns true if condition is met
			*/
			virtual bool get_condition(const CSRIncomingMessage& inMess
									  ,const portfolio::CSRTransaction& trade ) const = 0;

			/** Get the singleton for one condition payement.
			This is equivalent to CSRRulesConditionPayment::GetPrototype().GetData(modelName).
			except that exception is catched to return 0 if the rule condition is not found.
			@param modelName is a C string for the rule condition.
			@return a pointer which must not be deleted but can be null.
			*/
			static CSRRulesConditionPayment* getInstance( const char* modelName ) ;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_RULES_CONDITION_PAYMENT.
			@see tools::CSRPrototype
			*/
			virtual CSRRulesConditionPayment* Clone() const = 0;

			typedef sophis::tools::CSRPrototype<CSRRulesConditionPayment
												,const char*
												,sophis::tools::less_char_star> prototype;
			/** Access to the prototype singleton.
			To add a condition rule to this singleton, use INITIALISE_RULES_CONDITION_PAYMENT.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		} ;


	}
};
SPH_EPILOG
#endif
