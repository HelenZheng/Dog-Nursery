#ifndef __sphBOAccountsUtil__
#define __sphBOAccountsUtil__

#include "SphInc/portfolio/SphTransaction.h"
#include "SphInc/SphMacros.h"

SPH_PROLOG

namespace sophis {
	namespace backoffice_otc
	{
		enum eAccountTypes{
			eNostroCash = 0x01,
			eNostroSec = 0x02,
			eLostroCash = 0x04,
			eLostroSec = 0x08
		};

		struct SSNostroLostroAccounts
		{	
			SSNostroLostroAccounts()
				:fNostroCashAccount(0), fLostroCashAccount(0),fNostroSecAccount(0), fLostroSecAccount(0){}

			SSNostroLostroAccounts(const SSNostroLostroAccounts& o)
				:fNostroCashAccount(o.fNostroCashAccount), fLostroCashAccount(o.fLostroCashAccount)
				,fNostroSecAccount(o.fNostroSecAccount), fLostroSecAccount(o.fLostroSecAccount){}

			SSNostroLostroAccounts(long nostroCashAccount, long lostroCashAccount, 
				long nostroSecAccount, long lostroSecAccount)
				:fNostroCashAccount(nostroCashAccount), fLostroCashAccount(lostroCashAccount)
				,fNostroSecAccount(nostroSecAccount), fLostroSecAccount(lostroSecAccount){}

			long fNostroCashAccount;
			long fLostroCashAccount;
			long fNostroSecAccount;
			long fLostroSecAccount;	
		};		

		class SOPHIS_BO_OTC BOAccountsUtil
		{
		public:
			static bool IsAccountsModified(const portfolio::CSRTransaction & original, 
				const portfolio::CSRTransaction &modified,
				long types);

			static SSNostroLostroAccounts GetAccountsFromTransaction(const portfolio::CSRTransaction &transaction);
		};
	}
}

SPH_EPILOG

#endif
