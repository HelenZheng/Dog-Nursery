#if (defined(WIN32)||defined(_WIN64))
#	pragma once
#endif

/*
SphAsynchronousTreatment.h
Copyright: � 2003 Sophis.
*/

#ifndef _CSRAsynchronousTreatment_H_
#define _CSRAsynchronousTreatment_H_

#include "SphInc/SphMacros.h"

#include "SphTools/SphCommon.h"

#include "SphCalculationExports.h"
#include "SphInc/tools/SphSmartPtr.h"

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)


SPH_PROLOG
namespace sophis
{
	namespace calculation
	{
		/**
		* This Interface makes it possible to implement a non-blocking treatment in the Risque API.
		* This treatment is split in two distinct steps.
		* <ul>
		* <li> The first step of this treatment is processed in a different thread from the RisqueAPI one.
		*	It corresponds to the method ThreadedProcessing().
		* <li> The second step is performed after the end of the first one. 
		*	It is triggered in the Risque API thread.
		*	It corresponds to the method SafeFinalization().
		* </ul>
		*
		* To start this kind of treatment @see CSRCalculation#PerformAsynchronousTreatment()
		* 
		* Remark : This interface can be useful to implement CSRInstrument::RecomputeAll() in a 
		* non-blocking way. In this case, it is mandatory to notify the Calculation Server at the end
		* of this treatment.
		* @see CSRAsynchronousTreatment#NotifyCompletion()
		* @see CSRAsynchronousTreatment#NotifyCancelation()
		* @see CSRAsynchronousTreatment#NotifyFailure()
		*
		* @since 4.5.1.0.15
		*/
		class SOPHIS_CALCULATION CSRAsynchronousTreatment
		{
		public :
			
			CSRAsynchronousTreatment();
			
			virtual ~CSRAsynchronousTreatment();

			/**
			* First step of the treatment.
			* Called in a thread different from the Risque API one.
			* For that reason, the implementation of this method CAN'T use Risque API methods.
			*/
			virtual void ThreadedProcessing() = 0;

			/**
			* Second step of the treatment.
			* This method is called after the end of the method ThreadedProcessing() in the Risque API thread.
			* For that reason, the implementation of this method CAN use Risque API methods.
			*/
			virtual void SafeFinalization() = 0;

			/**
			* Called to warn this interface implementation that the processing treatment must be stopped
			* as soon as possible.
			*/
			virtual void Cancel() = 0;
			
			/**
			* Mandatory when this interface is used to implement an instrument pricing alogrithm.
			* When the pricing algorithm is called in a Calculator, it notifies the Calculation Manager about 
			* the instrument calculation completion.
			*
			* @param elapsedTimeInMillis	duration timed to perform the instrument pricing algorithm.
			*/
			void NotifyCompletion(long elapsedTimeInMillis);

			/**
			* Mandatory when this interface is used to implement an instrument pricing alogrithm.
			* When the pricing algorithm is called in a Calculator, it notifies the Calculation Manager about 
			* the instrument calculation Cancelation.
			*
			* @param message	dedicated to give additional information about the cancelation.
			*/
			void NotifyCancelation(const _STL::string& message);

			/**
			* Mandatory when this interface is used to implement an instrument pricing alogrithm.
			* When the pricing algorithm is called in a Calculator, it notifies the Calculation Manager about 
			* the instrument calculation Failure.
			*
			* @param message	dedicated to give additional information about the failure.
			*/
			void NotifyFailure(const _STL::string& message);

			/**
			* Internal
			* Used by the calculation server.
			*/
			void GetTreatmentCharacteristics(long& calculationId, long& instrumentId, bool& inArbitrage);

			int  fRefCount; // Smart pointer management. Must not be modified.

		private :

			long fCalculationId;
			long fInstrumentId;
			bool fInArbitrage;
		};

		typedef sophis::tools::smart_ptr<sophis::calculation::CSRAsynchronousTreatment, sophis::tools::ref_count_inside> CSRAsynchronousTreatmentHandle;
	}
}
SPH_EPILOG
#endif
