#if (defined(WIN32)||defined(_WIN64))
#	pragma once
#endif

/*
SphCalculation.h
Copyright: � 2003 Sophis.
*/

/*! \file SphCalculation.h
	\brief Allows you to launch calculations on remote machines using the Sophis Calculation Server.
*/


/**
 * This facility allows you to launch calculations on remote machines using the Sophis Calculation Server.
 * Requested calculations can be:
 * <ul>
 * <li> Portfolio Loading
 * <li> P&L computation
 * <li> Scenario computation
 * </ul>
 * <p>
 * Typical use:
 * <pre>
 * // First, checks if the calculation server can be used.
 * // If it cannot be used, the returned enum value provides the reason why.

 * eCalcServerAvailability reasonWhyICantUseIt;
 * bool canUseCalcServer = CSRCalculation::CanUseCalculationServer(reasonWhyICantUseIt);
 * if (!canUseCalcServer)
 * {
 *     cout << "The calculation server is currently unuseable" << endl;
 *	   return;
 * }
 *
 * // Creates a portfolio calculation.
 * CSRCalculationHandle aCalculation = CSRCalculation::CreatePortfolioCalculation(portfolioRecalculation);
 *
 * try {
 *     aCalculation->Run();
 * }
 * catch (...)
 * {
 *     aCalculation->Abort();
 *	   CSRCalculation::Destroy(aCalculation->GetCalculationId());
 *     cout << " The distant calculation has failed" << endl;
 *	   return;
 * }
 *
 * // Waits for the completion of the remote calculation (success or failure...)
 * bool isSuccessful = aCalculation->WaitForCompletion();
 * if (!isSuccessful)
 * {
 *     cout << "The remote calculation has completed unsuccessfully. This may be due to a cancellation or a rejection" << endl;
 *	   return;
 * }
 *
 * // Processes the available result.
 * aCalculation->DoProcessResult();
 * cout << "The distant calculation has been successfully processed" << endl;
 * </pre>
 * <p>
 * To be notified of each calculation processing step, a 'listener' can be registered to the calculation.
 * Use a listener as a monitoring system, to warn when results must be processed.
 */


#ifndef _CSRCalculation_H_
#define _CSRCalculation_H_

#include "SphCalculationExports.h"
#include "SphInc/scenario/SphScenario.h"
#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/tools/SphSmartPtr.h"


#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)



SPH_PROLOG
/**
* Defines for the classical Calculation types
*/
#define PORTFOLIO_GRID_SERVICE_NAME "PortfolioGridService"
#define SCENARIO_GRID_SERVICE_NAME  "ScenarioGridService"
#define VALUATION_GRID_SERVICE_NAME  "ValuationGridService"

namespace sophis {
	namespace scenario {
		class CSRScenario;
		class  CSRInputStrategy;
	}

	namespace calculation {
		class CSCalculationFactory;
		class CSRCalculationFactory;
		class CSRGridTask;
		class ValuationGridResult;
		class ValuationFail;
		class ValuationErrorList;

		enum eCalcServerAvailability {
			everythingOk,
			noServer,
			notAuthorized,
			noAppropriateServer,
			serverInternalError,
			calculationLocalOnly,
			userDontWantTo
		};

		enum eType {
			portfolioLoading = 0,
			portfolioRecalculation = 1,
			portfolioFastRecalculation = 2
		};

		class CSRCalculationListener;
		class CSRAsynchronousTreatment;

		class SOPHIS_CALCULATION CalculationInitFailureException : public sophisTools::base::ExceptionBase
		{
		public:
			CalculationInitFailureException();
		};

		/**
		* This exception is raised by calculation service when an invalid input (data or value) is sent during the initialization phase 
		*/
		class SOPHIS_CALCULATION CalculationInvalidInputException : public sophisTools::base::GeneralException
		{
		public:
			CalculationInvalidInputException(const char * msg, long err = 0);
			virtual ~CalculationInvalidInputException();
		};


		class SOPHIS_CALCULATION CSComputationUnavailableException : public sophisTools::base::GeneralException
		{
		public:
			CSComputationUnavailableException(const char * msg, long err = 0);
			virtual ~CSComputationUnavailableException();
		};

		struct SOPHIS_CALCULATION InstrumentComputation
		{
			long calculationId;
			bool positionInArbitrage;
		};

		/**
		* This class is designed to manage the distant processing of P&L or Scenario calculations using the Calculation Server.
		* It allows you to start, cancel or follow the progress of the handled calculation.
		*
		* Dedicated factory methods deliver the CSRCalculation instance suitable for the calculation you want
		* to perform.
		*/

		class SOPHIS_CALCULATION CSRCalculation
		{
		public:

			/**
			* Returns true if the Calculation Server can be used.
			* Otherwise, returns the reason.
			*
			* @param why			 returned status regarding the calculation server availability.
			* @param gridServiceName the name of Grid service we want to use, by default Sophis Portfolio Gridservice,
			*						 it means we try to use PNL computation. @since 6.0
			*/
			static bool CanUseCalculationServer(enum eCalcServerAvailability & why, const char* gridServiceName = PORTFOLIO_GRID_SERVICE_NAME, bool isAPINeeded = false);

			/**
			* Returns the calculation corresponding to the given identifier.
			*
			* @param id				identifier of the calculation.
			*
			* @throws	UnknownCalculationIdException
			*			If the given ID does not correspond to a known
			*			calculation.
			*/
			static CSRCalculation* GetCalculation(int id);

			/**
			* Creates a portfolio calculation.
			*
			* @param type			type of the calculation.
			* @param extraction		extraction used for the calculation.
			* @param portfolioId	identifier of the portfolio (0 for the root portfolio).
			*
			* @throws	CalculationInitFailureException
			*			If the initialisation of the created calculation has failed.
			*/
			static CSRCalculation* CreatePortfolioCalculation(enum eType type,
															  sophis::portfolio::PSRExtraction extraction = 0,
															  long portfolioId = 0)
				throw(CalculationInitFailureException);

			/**
			* Creates a scenario calculation.
			* Note : the given scenario instance will be used for the calculation.
			*
			* @param scenario			scenario to calculate.
			* @param name				name of the scenario to calculate.
			* @param extraction			extraction used for the calculation.
			* @param portfolioId		identifier of the portfolio (0 for the root portfolio).
			* @param underlyingId		SICOVAM of the underlying used for the scenario
			*							calculation. If equal to 0, the scenario is calculated
			*							with every underlyings.
			*
			* @throws	CalculationInitFailureException
			*			If the initialisation of the created calculation has failed.
			*/
			static CSRCalculation* CreateScenarioCalculation(sophis::scenario::CSRScenario* scenario,
															 const _STL::string & scenarioName,
															 sophis::portfolio::PSRExtraction extraction = 0,
															 long portfolioId = 0,
															 long underlyingId = 0,
															 bool scenarioInitialised = false)
				throw(CalculationInitFailureException);

			/**
			* Creates a scenario calculation.
			*
			* @param scenario			scenario to compute
			* @param name				name of the scenario to calculate.
			* @param extraction			extraction used for the calculation.
			* @param portfolioId		identifier of the portfolio (0 for the root portfolio).
			* @param underlyingId		SICOVAM of the underlying used for the scenario
			*							calculation. If equal to 0, the scenario is calculated
			*							with every underlying.
			*
			* @throws	CalculationInitFailureException
			*			If the initialisation of the created calculation has failed.
			*/
			static CSRCalculation* CreateScenarioCalculation(const _STL::string & scenarioName,
															 sophis::portfolio::PSRExtraction extraction = 0,
															 long portfolioId = 0,
															 long underlyingId = 0)
				throw(CalculationInitFailureException);


			/**
			* Creates an instrument calculation based on a scenario distribution
			* Rem : the given scenario instance will be used for the computation.
			*
			* @param scenario			scenario to compute
			* @param name				name of the scenario to compute
			* @param instrumentId		identifier of the instrument supposed to be calculated
			*							thanks to the distributed calculation of the given scenario.
			* @param persistencyTag		tag associated with the given instrumentId to create a key.
			*							This key is used to identify the time statistic that 
			*							will be taken into account for dispatching. It also will 
			*							be updated with the new measured calculation time. 
			*							If persistencyTag is equal to default value, the given scenario 
			*							name is used.
			*
			* @throws	CalculationInitFailureException	
			*			If the initialisation of the created calculation has failed.
			*/
			static CSRCalculation* CreateInstrumentCalculation(scenario::CSRScenario* scenario,
															   const _STL::string & scenarioName,
															   long instrumentId,
															   _STL::string persistencyTag = "")
				throw(CalculationInitFailureException);

			/**
			* Creates a valuation calculation
			* Rem : the given XML valuation request will be used for the computation.
			*
			* @param valuationSet		XML valuation request
			*
			* @throws	CalculationInitFailureException	
			*			If the initialisation of the created calculation has failed.
			*/
			static CSRCalculation* CreateValuationCalculation(const char* valuationRequest, long valuationRequestSize, ValuationGridResult &result ,  ValuationErrorList &valuationErrors, ValuationFail  &failedValuation)
				throw(CalculationInitFailureException);

			/**
			* Creates a grid task calculation
			*
			* @param	gridTask		the grid task to compute 
			* @see CSRGridTask	
			*
			* @throws CalculationInitFailureException	
			* If the initialization of the created calculation has failed.
			* @since 5.1.0.0
			*/

			static CSRCalculation* CreateGridTaskCalculation( CSRGridTask* gridTask )
				throw(CalculationInitFailureException);

			/**
			* Must be called for life cycle management purpose, when the corresponding
			* calculation is not used anymore.
			*
			* @param id		identifier of the calculation to purge.
			*
			* @throws	UnknownCalculationIdException
			*			If the given ID does not correspond to a known
			*			calculation.
			*/
			static void Destroy(int id);

			/**
			* Destructor.
			*/
			virtual ~CSRCalculation();

			/**
			* Calls RunServers and starts external calculations
			* @see RunServers()
			*/
			virtual void Run();

			/**
			* Asks the server to run the calculation.
			* Registered listeners will be notified when
			- the calculation is waiting or rejected
			- its waiting rank has changed
			- it is started
			- it is in process
			- it is finished.
			* <p>
			* Warning!
			* The calling thread must also deal with CSRAPI::ProcessEvents() or call the method
			* WaitForCompletion().
			*
			* @see WaitForCompletion()
			* @see CSRCalculationListener#CalculationIsWaiting()
			* @see CSRCalculationListener#CalculationIsRejected()
			* @see CSRCalculationListener#WaitingRankHasChanged()
			* @see CSRCalculationListener#CalculationIsStarted()
			* @see CSRCalculationListener#CalculationIsFinished()
			*/
			virtual void RunServers();

			/**
			* Dedicated to be called just after the method Run().
			* Processes CSREvents until the completion of the calculation.
			* Returns if:
			* <ul>
			* <li> Results are available and must be processed
			* <li> The calculation is canceled, rejected or aborted.
			* </ul>
			*
 			* @return true if the calculation is successful, otherwise return false.
			*/
			virtual bool WaitForCompletion();


			/**
			* Designed to be called just after the method Run().
			* Requests the calculation server for an instruments sub-list from this
			* Calculation, in order to process their calculation on the client side.
			* In this case, the instruments will not be dispatched to any Calculators
			* as they should be calculated by this method requester.
			* Moreover, this calculation will not be considered complete, until the
			* method NotifyLocalComputationCompletion() is called for the reserved
			* instruments.
			*
			* @see NotifyLocalComputationCompletion()
			*
			* @return a list of InstrumentComputation. This list is supposed to be
			* deleted by the method requester.
			*/
			virtual _STL::list<InstrumentComputation>* GetInstrumentsForLocalComputation();

			/**
			* Designed to be called when instruments that are reserved using the method
			* GetInstrumentsForLocalComputation(), have completed calculations.
			* The given instruments will then be considered as computed by the Calculation
			* Server.
			* @see GetInstrumentsForLocalComputation()
			*
			* @param computedInstruments	List of instruments description calculated
			* @param elapsedTimeInMillis	Number of milliseconds spent to compute the list of instruments.
			* successfully on the client side.
			*/
			virtual void NotifyLocalComputationCompletion(const _STL::list<InstrumentComputation>& computedInstruments, long elapsedTimeInMillis);

			/**
			* Designed to be called just after the method Run().
			* Requests the calculation server for an step sub-list from this
			* Calculation, in order to process their calculation on the client side.
			* In this case, the steps will not be dispatched to any Calculators
			* as they should be calculated by this method requester.
			* Moreover, this calculation will not be considered complete, until the
			* method NotifyStepsLocalComputationCompletion() is called for the reserved
			* steps.
			*
			* @see NotifyStepsLocalComputationCompletion()
			*
			* @return a list of stepId. This list is supposed to be
			* deleted by the method requester.
			* @since 5.1.0.0
			*/
			virtual _STL::list<_STL::string>* GetStepsForLocalComputation();

			/**
			* Designed to be called when steps that have been reserved using the method
			* GetStepsForLocalComputation(), have completed calculations.
			* The given steps will then be considered as computed by the Calculation
			* Server.
			* @see GetStepsForLocalComputation()
			*
			* @param computedSteps	List of calculated steps
			* @param elapsedTimeInMillis	Number of milliseconds spent to compute the list of steps.
			* successfully on the client side.
			* @since 5.1.0.0
			*/
			virtual void NotifyStepsLocalComputationCompletion(const _STL::list<_STL::string>& computedSteps, long elapsedTimeInMillis);

			/**
			* Locally performs the received result processing.
			* Must be called only when Registered listeners are notified or when the
			* method WaitForCompletion() returns true.
			*
			* @see CSRCalculationListener#ResultProcessingIsAsked()
			*/
			virtual void DoProcessResult();

			/**
			* Asks the server to stop the calculation.
			* Registered listeners will be notified that the calculation is cancelled.
			*
			* @see CSRCalculationListener#CalculationIsCancelled()
			*/
			virtual void Stop();

			/**
			* Asks the server to stop the calculation.
			* Registered listeners will be notified thatthe calculation is cancelled.
			*
			* @see CSRCalculationListener#CalculationIsCancelled()
			*/
			virtual void Abort();

			/**
			* Releases resources used by this calculation.
			*/
			virtual void Dispose();

			/**
			* Returns the unique ID of this calculation.
			*/
			virtual int GetCalculationId();

			/**
			* Returns the name of this calculation.
			*/
			virtual const char * GetName() const;

			/**
			* Registers the given listener to this calculation. It will be notified of every
			* modification of this calculation.
			*
			* @param listener		listener to register.
			*/
			virtual void AddCalculationListener(CSRCalculationListener* listener);

			/**
			* Unregisters the given listener from this calculation.
			*
			* @param listener		listener to unregister.
			*/
			virtual void RemoveCalculationListener(CSRCalculationListener* listener);

			/**
			* To be used on SERVER SIDE only.
			*
			* Returns true if the cancellation for the Calculation, currently processed by this Calculator,
			* has been requested.
			*/
			static bool IsCancelationRequested();

			/**
			* Return a duration in milliseconds calculated according to stored statistics corresponding to the given parameters
			* and to the average speed of the calculators.
			* If no statistics are available or if no calculator is running, the returned value is -1.
			* 
			* A calculation statistic is identified thanks to 2 parameters:
			*
			* @param instrumentId	 identifier of the calculated instrument.
			* @param persistencyTag	 identifier usually defining the calculation type.
			* @since 4.5.1.0.15
			*/
			static long GetEstimatedCalculationDuration(long instrumentId, const _STL::string& persistencyTag);

			/**
			* Return a duration in milliseconds calculated according to stored statistics corresponding to the given parameters
			* and to the average speed of the calculators.
			* If no statistics are available or if no calculator is running, the returned value is -1.
			* 
			* A calculation statistic is identified thanks to 2 parameters:
			*
			* @param stepId identifier of the calculated step.
			* @param persistencyTag	 identifier usually defining the calculation type.
			* @since 5.1.0.0
			*/
			static long GetEstimatedStepCalculationDuration(const _STL::string& stepId, const _STL::string& persistencyTag);

			/**
			* Trigger the asynchronous processing of the given treatment.
			* @see CSRAsynchronousTreatment
			*
			* @param treatment		treatment suppose to be started.
			* @since 4.5.1.0.15
			*/
			static void PerformAsynchronousTreatment(CSRAsynchronousTreatment* treatment)
				throw(sophisTools::base::ExceptionBase);


			/**
			* Internal
			* Used by the calculation server.
			* @since 4.5.1.0.15
			*/
			static bool IsAsynchronouslyPerformed(long calculationId, long instrumentId, bool inArbitrage);


			int fRefCount; // Smart pointer management. Must not be modified.
			

			/** Ask for calculations.
			In GUI show a dialog box asking for calculations servers. In API return true.
			@return a boolean defining the user choice.
			@since 4.5.1.0.13
			*/
			static bool AskUserConfirmation();

			/** 
			In GUI, Open a dialog box displaying the current state and progress of the calculation with the given Id.
			In API, return false.
			@return a boolean defining if the dialog has been successfully opened.
			@since 5.2.0
			*/
			static bool CreateCalculationProgressDialog(long calculationId, long folioId = -1);

			/** Get the number of the calculations.
			@return The number of the calculations.
			@since 5.2.0.0.0
			*/
			static long GetCalculationsNumber();
				
			/** Get the number of the processing calculations.
			@return The number of the queued calculations.
			@since 5.2.0.0.0
			*/
			static long GetProcessingCalculationsNumber();
			
			/** Get the number of the queued calculations.
			@return The number of the queued calculations.
			@since 5.2.0
			*/
			static long GetQueuedCalculationsNumber();

			/** Get the title of the support which will be displayed.
			For example, it can be "Portfolio Name", "Instrument Name", ...
			@return the title of the support which will be displayed.
			@since 5.2.1
			*/
			virtual const char* GetDisplayedSupportTitle();

			/** Get the name of the support which will be displayed.
			For example, it can be the name of a portfolio, a sicovam for an instrument, ...
			@return the name of the support which will be displayed.
			@since 5.2.1
			*/
			virtual const char* GetDisplayedSupportName();

			/** Get the calculation type which will be displayed.
			For example, it can be a portfolio PnL, a Monte-Carlo, a scenario, ...
			@return the calculation type which will be displayed.
			@since 5.2.1
			*/
			virtual const char* GetDisplayedCalculationType();

			/** Set the strategy for the report.
			Must be done before launching the scenario.
			@param reportStrategy is a strategy of report which will be used by the scenario to
			export the results; it is not deleted by the scenario.
			@see CSRReportStrategy
			@since 5.3
			*/
			virtual void	SetReportStrategy(sophis::scenario::CSRReportStrategy * reportStrategy);

			/** Get the percentage of the calculation in length, according to time statistics.
			Engine speeds are not taken into account.
			@return the percentage of the calculation, between 0 (not started or not available) and 100 (completed).
			@since 7.0
			*/
			virtual int GetPercentage() const;

			/** Get a boolean value indicating whether the calculation is completed or not.
			@return the boolean value indicating whether the calculation is completed or not.
			@since 7.0
			*/
			virtual bool IsComplete() const;

		protected :
			CSRCalculation();

			friend class CSCalculationFactory;

			static void SetCalculationFactory(CSRCalculationFactory* calculationFactory); // Internal

			static int GetCalculationIdFromDatabase();
		};

		typedef sophis::tools::smart_ptr<CSRCalculation, sophis::tools::ref_count_inside> CSRCalculationHandle;


		/**
		* This interface defines a set of callback methods designed to give progress information
		* to its implementation class.
		* An instance of the implementation class must be registered to the Calculation to
		* be monitored.
		* @see CSRCalculation#AddCalculationListener()
		*
		* Warning!
		* Callback method of registered Listeners will be called in a THREAD other than the RISQUE API thread.
		* For that reason, do not directly request RISQUE API methods in your implementation.
		*
		* On the other hand, the callback methods are called as soon as the information is received from the
		* Calculation Server, even if the RISQUE API thread is busy.
		*
		* If your callback method implementations need to realise a direct call to the RISQUE API method, the
		* CSRSafeCalculationListener interface is recommended.
		* @see CSRSafeCalculationListener
		*/
		class SOPHIS_CALCULATION CSRCalculationListener
		{
		public :

			CSRCalculationListener();

			virtual ~CSRCalculationListener();

			/**
			* Called when the calculation has been asked to "run".
			*
			* @see CSRCalculation#Run()
			*/
			virtual void CalculationIsSent() = 0;

			/**
			* Called once the calculation has been pushed in the waiting queue.
			*
			* @param waitingTime time in ms
			* @see CSRCalculation#Run()
			*/
			virtual void CalculationIsWaiting() = 0;

			/**
			* Gives the remaining time before the begining of the calculation computation.
			*
			* @param startDate		estimated starting date of the calculation
			* @param duration		estimated duration (in ms) of the calculation
			*/
			virtual void WaitingRankHasChanged(long newRank, time_t startDate, long duration) = 0;

			/**
			* Called when the calculation is extracted from the waiting queue and starts to be processed.
			*/
			virtual void CalculationIsStarted() = 0;

			/**
			* Specific method for GridTask Calculation.
			* Called when some Task steps have been completed on server side.
			* Their corresponding Result archive can be accessed thanks to the corresponding CSRGridTask instance.
			*
			* @see CSRGridTask#GetStepResultArchive()
			*/
			virtual void StepsAreCompleted(const _STL::list<_STL::string> & completedStepsId) = 0;

			/**
			* Called when Results are available and must be processed in the main thread to finalize
			* the computation.
			*
			* @see CSRCalculation#DoProcessResult()
			*/
			virtual void ResultProcessingIsAsked() = 0;

			/**
			* Called when the calculation is cancelled.
			*/
			virtual void CalculationIsCancelled() = 0;

			/**
			* Called when the calculation is finished.
			*/
			virtual void CalculationIsFinished() = 0;

			/**
			* Called if the calculation has been rejected when asked to "run".
			*
			* @see CSRCalculation#Run()
			*/
			virtual void CalculationIsRejected( const _STL::string &reason) = 0;

			/**
			* Called in result of "Abort" Calculation method.
			*
			* @see CSRCalculation#Abort()
			*/
			virtual void CalculationIsAborted() = 0;

			/**
			* Called when processing results is performed and must be processed in 
			* the main thread to finalize the computation.
			*
			* @param taskResults List of results used during the perform.
			*
			* @see CSRCalculation#DoProcessResult()
			*/
			virtual void ResultProcessingIsPerformed(const _STL::list<sophis::tools::CSRArchive *>& taskResults, bool isRejected) = 0;

			int fRefCount;// Smart pointer management. Must not be modified.

		};

		typedef sophis::tools::smart_ptr<CSRCalculationListener, sophis::tools::ref_count_inside> CSRCalculationListenerHandle;


		/**
		* This interface is similiar to its mother interface CSRCalculationListener.
		* @see CSRCalculationListener
		*
		* The main difference is that the callback methods of registered Listeners
		* are called in the RISQUE API thread.
		* For that reason, if the RISQUE API thread is busy when details are recieved from the Calculation Server,
		* a delay can be observed before the callback method is performed.
		*
		* On the other hand, your callback method implementations can realise a direct RISQUE API method call, since they
		* are executed in the same thread.
		*/

		class SOPHIS_CALCULATION CSRSafeCalculationListener : public virtual CSRCalculationListener
		{
		public :

			CSRSafeCalculationListener();

			virtual ~CSRSafeCalculationListener();
		};

		typedef sophis::tools::smart_ptr<CSRSafeCalculationListener, sophis::tools::ref_count_inside> CSRSafeCalculationListenerHandle;

	}
}

SPH_EPILOG
#endif
