#pragma once

#ifndef _SphCalculationExports_H_
#define _SphCalculationExports_H_

#if (defined(WIN32)||defined(_WIN64))
#	ifdef SOPHISCALCULATION_EXPORTS
#		define SOPHIS_CALCULATION __declspec(dllexport)
#	else
#		define SOPHIS_CALCULATION __declspec(dllimport)
#	endif
#else
#	define SOPHIS_CALCULATION
#endif

#endif

