#if(defined(WIN32) || defined(_WIN64))
#	pragma once
#endif

#ifndef _CSRExternalCalculation_H_
#define _CSRExternalCalculation_H_

#include "SphCalculationExports.h"
#include "SphGridComputing.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(memory)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(string)

namespace sophis 
{
	namespace scenario
	{
		class CSRScenario;
	}

	namespace tools
	{
		class CSRArchive;
	};

	namespace calculation
	{
		class CSRExternalCalculation;
		class CSRExternalCalculationListener;
		class CSRExternalCalculationThread;
		class CSRExternalCalculator;

		struct SOPHIS_CALCULATION SSExternalStepData
		{
			SSExternalStepData();
			SSExternalStepData(float estimatedTime);
			SSExternalStepData(const SSExternalStepData & copy);
			float fEstimatedTime;
		};

		/**
		 * This class is designed to be called by external calculations in
		 * order to notify the API that an instrument has been computed or
		 * that the calculation of an instrument failed.
		 */
		class SOPHIS_CALCULATION CSRExternalCalculationListener
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~CSRExternalCalculationListener();

			/**
			* Notify the API that a step has been computed.
			* @param calculation The calculation that has computed the step.
			* @param step The computed step.
			* @param result the Result of the computation.
			*/
			virtual void OnExternalStepComputed(
				CSRExternalCalculation & calculation,
				const _STL::string & step, 
				_STL::auto_ptr<sophis::tools::CSRArchive> result) = 0;

			/**
			* Notify the API that the computation of a step failed.
			* @param calculation The calculation that has computed the
			* instrument.
			* @param step The computed step.
			* @param message An error message.
			*/
			virtual void OnExternalStepError(
				CSRExternalCalculation & calculation,
				const _STL::string & step, 
				const _STL::string & message) = 0;
		};

		/**
		 * this class represents an external calculation.
		 */
		class SOPHIS_CALCULATION CSRExternalCalculation
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~CSRExternalCalculation();

			/**
			 * Returns the calculator that has created this calculation.
			 * Useful to get the calculator name.
			 * @return The calculator that has created this calculation.
			 */
			virtual CSRExternalCalculator & GetCalculator() const = 0;

			/**
			 * Returns the list of steps that will be computed by this 
			 * calculation. It should be a  subset of the steps given
			 * to CSRExternalCalculator.
			 * @param steps The list of steps that will be computed 
			 * by this calculation.
			 */
			virtual void GetSteps(_STL::map<_STL::string, SSExternalStepData> & steps) const = 0;

			/**
			 * Implemented by CSRExternalSynchronousCalculation and 
			 * CSRExternalAsynchronousCalculation.
			 * Start the external calculation.
			 */
			virtual void Start() = 0;

			/**
			 * Implemented by CSRExternalSynchronousCalculation and 
			 * CSRExternalAsynchronousCalculation.
			 * Cancel the external calculation.
			 * Useful for asynchronous implementation.
			 */
			virtual void Cancel() = 0;

			/**
			 * Implemented by CSRExternalSynchronousCalculation and 
			 * CSRExternalAsynchronousCalculation.
			 * Wait for the completion of the external calculation.
			 * Useful for asynchronous implementation.
			 */
			virtual void WaitForCompletion() = 0;
		};

		/**
		 * this class is the calculation factory
		 */
		class SOPHIS_CALCULATION CSRExternalCalculator
		{
		public:
			/**
			 * Destructor.
			 */
			virtual ~CSRExternalCalculator();

			/**
			 * Returns the name of the calculator (for log purpose).
			 * @return The name of the calculator.
			 */
			virtual _STL::string GetName() const = 0;

			/**
			 * Creates a portfolio calculation.
			 * @param steps The list of the steps to compute.
			 * @param managedSteps The list of steps managed by the 
			 * returned calculation.
			 * @param listener The listener that the created calculation will
			 * have to call.
			 * @return The created calculation.
			 */
			virtual CSRExternalCalculation * CreatePortfolioCalculation(
				const _STL::set<_STL::string> & steps,
				_STL::set<_STL::string> & managedSteps,
				CSRExternalCalculationListener & listener) = 0;

			/**
			 * Creates a scenario calculation
			 * @param scenario The scenario to compute.
			 * @param steps The list of the steps to compute.
			 * @param managedSteps The list of steps managed by the 
			 * returned calculation.
			 * @param listener The listener that the created calculation will
			 * have to call.
			 * @return The created calculation.
			 */
			virtual CSRExternalCalculation * CreateScenarioCalculation(
				sophis::scenario::CSRScenario & scenario,
				const _STL::set<_STL::string> & steps,
				_STL::set<_STL::string> & managedSteps,
				CSRExternalCalculationListener & listener) = 0;
		};

		// List of all external calculator. Must be filled by toolkit.
		// First calculator has the highest priority: if an instrument can be 
		// computed by two external calculator, only the first one will be 
		// used.
		extern SOPHIS_CALCULATION _STL::list<CSRExternalCalculator *> gExternalCalculators;
	}
}

#endif
