/********************************************************************
*	@date:		29.08.2005 
*	
*	@file:	 	SphGridComputing.h
*
*				Copyright (C) 2005 SOPHIS
*	
*	@purpose:	
*
*	@since		5.0.4
*
*
*/
#if (defined(WIN32)||defined(_WIN64))
#	pragma once
#endif


#ifndef _SphGridComputing_H_
#define _SphGridComputing_H_

#include "SphTools/SphExceptions.h"
#include "SphTools/SphArchive.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphSmartPtr.h"
#include "SphInc/calculation/SphCalculationExports.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(set)

#define DECLARATION_GRID_SERVICE(derivedClass)		DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derivedClass,sophis::calculation::CSRGridService)
#define	INITIALISE_GRID_SERVICE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

/**
* The following #define for UNIVERSAL_MAIN_FOR_GRID_SERVICES is the same as UNIVERSAL_MAIN 
* which is in SphInc/SphMacros.h. The use is also the same.
* 
* To enable the use of grid services, you must initialize your grid service with the 
* INITIALISE_GRID_SERVICE macro inside this entry point. 
*
* 1. USE OF GRID SERVICES 
* =======================
* If you intend to use grid service only in a external application like lite calculators,
* use an empty UNIVERSAL_MAIN as the following :
* 
	UNIVERSAL_MAIN
	{
	
	}

	UNIVERSAL_MAIN_FOR_GRID_SERVICES
	{
	
	// Initialise your grid services here ...
	INITIALISE_GRID_SERVICE(MyGridService, "My grid service");

	}
*
*
*
* 2. USE OF GRID SERVICES LOCALLY IN RISQUE OR VALUE.
* ===================================================
* If you intend to use your grid service locally in Risque or Value, you have to call 
* both UNIVERSAL_MAIN and INITIALISE_GRID_SERVICE as the following :
*
	bool isUniversalMainCalled = false;
	bool isUniversalMainForGridServicesCalled = false;

	UNIVERSAL_MAIN;
	UNIVERSAL_MAIN_FOR_GRID_SERVICES;

	UNIVERSAL_MAIN
	{
		if (isUniversalMainCalled)
			return;

		// Initialise your stuff here ...

		isUniversalMainCalled = true;
		EntryPointForGridServices(indirectionPtr);	
	}

	UNIVERSAL_MAIN_FOR_GRID_SERVICES
	{
		if (isUniversalMainForGridServicesCalled)
			return;

		// Initialise your grid services here ...
		INITIALISE_GRID_SERVICE(MyGridService, "My grid service");

		isUniversalMainForGridServicesCalled = true;
		EntryPoint(indirectionPtr);	
	}
*
*/
#if (defined(WIN32)||defined(_WIN64))

#ifndef _CPPRTTI
#error( "tick RTTI option in the C++ settings of your project" )
#endif

#define UNIVERSAL_MAIN_FOR_GRID_SERVICES \
	extern "C" { __declspec( dllexport ) void EntryPointForGridServices(void *indirectionPtr);} \
	__declspec( dllexport ) \
	void EntryPointForGridServices(void *indirectionPtr)
#else
#   ifdef __cplusplus
extern "C" {
#   endif
#       define UNIVERSAL_MAIN_FOR_GRID_SERVICES void EntryPointForGridServices(void *indirectionPtr)
	void EntryPointForGridServices(void *indirectionPtr);
#   ifdef __cplusplus
}
#   endif
#endif


SPH_PROLOG
namespace sophis
{
	namespace tools	{
		class CSRArchive;
	}

	namespace TimeStatisticsManager {
		struct STimeStatStepData;
	}

	namespace calculation
	{
		class CSRCalculationListener; //forward

		enum eStatisticPolicy 
		{
			globalTaskLevelAccuracy,
			averageStepLevelAccuracy,
			perStepLevelAccuracy,
			scenarioLevelAccuracy				
		};

		enum eGridComputingSystem
		{
			sophisCalculationServer,
			externalSystem
		};

		enum eGridComputingProcessingState 
		{
			completedSuccessfully,
			completedWithWarnings,
			aborted,
			notImplemented
		};

		enum eGridServiceInitializationType
		{
			singlePartInitialization,
			multiPartInitialization
		};

		class SOPHIS_FIT GridComputingException : public sophisTools::base::ExceptionBase
		{
		public:
			GridComputingException(const _STL::string& message);
		};

		class SOPHIS_FIT RestartCSException : public GridComputingException
		{
		public:
			RestartCSException(const _STL::string& message);
		};

		class SOPHIS_FIT UnavailableDataException : public GridComputingException
		{
		public:
			UnavailableDataException(const _STL::string& message);
		};

		class SOPHIS_FIT NoGridServicesRegisteredException : public GridComputingException
		{
		public:
			NoGridServicesRegisteredException();
		};

		//-----------------------------------------------------------------------------
		SPH_BEGIN_NOWARN_EXPORT
		struct SOPHIS_FIT SSTaskDescriptor
		{
			SSTaskDescriptor();
			~SSTaskDescriptor();
			_STL::map<_STL::string, double> fStepIdToLength;
			_STL::set<_STL::string> fStepIdToComputeOnServer;
			sophis::tools::CSRArchive * fTaskData;
			_STL::vector<sophis::tools::CSRArchive*> fInitializationPackets;
			_STL::map<_STL::string , sophis::tools::CSRArchive *> fStepIdToData;
			double fTimeStampData;
			double fLength;
		};

		/**
		*
		*/
		class SOPHIS_FIT CSRGridTask
		{
		public:
		
			virtual ~CSRGridTask();
			/** Factory method to create a Grid Computing task
			*/
			virtual sophis::tools::CSRArchive& GetTaskSharedDataArchive();

			virtual sophis::tools::CSRArchive& NewInitializationPacket();

			virtual const _STL::vector<sophis::tools::CSRArchive*>& GetInitializationPackets();

			virtual long GetInitializationPacketsNumber();

			virtual void AddStepToProcess(const _STL::string& stepIdent, bool external);

			virtual sophis::tools::CSRArchive& GetStepInputDataArchive(const _STL::string& stepIdent, bool createArchive = true)
				throw (UnavailableDataException);

			virtual void ClearStepInputDataArchive(const _STL::string& stepIdent)
				throw (UnavailableDataException);

			virtual sophis::tools::CSRArchive& GetStepResultArchive(const _STL::string& stepIdent, bool createArchive = false)
				throw (UnavailableDataException);

			virtual void ClearStepResultArchive(const _STL::string& stepIdent)
				throw (UnavailableDataException);

			virtual const _STL::list<sophis::tools::CSRArchive *>& GetTaskResultArchives()
				throw (UnavailableDataException);
			
			virtual eGridComputingProcessingState ProcessLocally(_STL::list<CSRCalculationListener*> listenerList, _STL::string& status);

			virtual int GetPercentage() const;

			virtual bool IsComplete() const;

			// Accessor method
			long			 GetStepCount();

			_STL::string	 GetGridServiceId();
			
			_STL::string	 GetPersistencyTag();
			
			eStatisticPolicy GetStatisticPolicy();

			int fRefCount; // Smart pointer management. Must not be modified.

			const char* GetDisplayedSupportName();
			const char* GetDisplayedSupportTitle();
			const char* GetDisplayedCalculationType();

			void SetDisplayedSupportName(const char* supportName);
			void SetDisplayedSupportTitle(const char* supportTitle);
			void SetDisplayedCalculationType(const char* calculationType);

		protected:
			CSRGridTask(const _STL::string& gridServiceId, 
								   eStatisticPolicy policy,
								   const char* persistencyTag,
								   sophis::tools::CSRArchive * (*archiveFactoryMethod)());

			_STL::string											fTargetGridServiceId;
			SSTaskDescriptor										fTaskDescription;
			eStatisticPolicy										fStatisticPolicy;
			_STL::map<_STL::string, sophis::tools::CSRArchive *>	fStepIdToResult; 
			_STL::list<sophis::tools::CSRArchive *>					fTaskResults;
			_STL::string											fPersistencyTag;
			sophis::tools::CSRArchive *								(*fArchiveFactory)();

			_STL::string											fSupportName;
			_STL::string											fSupportTitle;
			_STL::string											fCalculationType;
			double													fComputedLength;
		};
		SPH_END_NOWARN_EXPORT

		typedef sophis::tools::smart_ptr<CSRGridTask, sophis::tools::ref_count_inside> CSRGridTaskHandle;

		/**
		*
		*/
		class SOPHIS_CALCULATION CSRGridTaskFactory
		{
		public:
			static CSRGridTask* CreateInstance(const _STL::string& gridServiceId, eStatisticPolicy policy = perStepLevelAccuracy, const char* persistencyTag=NULL, eGridComputingSystem system=sophisCalculationServer);
		};

		/**
		*
		*/

		class SOPHIS_FIT CSRGridService
		{
		public:
			CSRGridService();
			virtual ~CSRGridService();

			//-----------------------------------------------------------------------------
			/**
			* from SphPrototype interface
			*/

			/** typedef for the prototype
			*/
			typedef sophis::tools::CSRPrototype<CSRGridService, _STL::string > prototype;

			/** access to the prototype singleton
			*	
			*	To add a trigger to this singleton, use INITIALISE_GRID_SERVICE
			*	@see CSRPrototype
			*/
			static prototype & GetPrototype();

			/**
			 * Maps grid services names to "extended" names as defined in the INI configuration file.
			 * Extended names are in the format : serviceName:extension
			 */
			static void InitializeGridServicesMapping();

			/**
			 * Translate a grid service name into an extended name.
			 * This method should be called at registration time (outside INITIALISE_GRID_SERVICE).
			 * For instance INITIALISE_GRID_SERVICE(CSRMyGridService, GetServiceExtendedName("MyServiceName"))
			 */
			static _STL::string GetServiceExtendedName(_STL::string serviceName);

			/** Clone method needed by the prototype
			*	
			*	Usually, it is done automatically by the macro DECLARATION_GRID_SERVICE
			*	@see CSRPrototype
			*/
			virtual CSRGridService * Clone() const = 0;

			/** Must Return the name used for declaration with DECLARATION_GRID_SERVICE
			*/
			virtual const _STL::string& GetName() = 0;

			/** Must Return true if an already initialized API is requested to perform the Service
			* The default value is false
			*/
			virtual bool IsAlreadyInitializedAPINeeded();

			/** Must Return true if an already initialized API is requested to perform the Service
			* The default value is false
			*/
			virtual bool IsSynchronizedMarketDataNeeded();

			/** Handles multi-part initialization packets on the grid-service side.
			* Typically : import init data
			* @see : CSRGridTask::NewInitializationPacket
			*/
			virtual void AddInitializationPacket(const sophis::tools::CSRArchive& initializationPacket);

			/**
			 * Method called in multi-part initialization mode right after the last packet is received
			 */
			virtual void CompleteMultiPartInitialization();

			//-----------------------------------------------------------------------------
			
			virtual void Initialize(const sophis::tools::CSRArchive& taskInputData, eGridServiceInitializationType initializationType = singlePartInitialization) = 0;				

			virtual void PrepareforStepList(const _STL::list<_STL::string>& listToProcess) = 0;

			virtual void  PerformStep(const _STL::string stepId, sophis::tools::CSRArchive& stepInputData, sophis::tools::CSRArchive& stepResultData, sophis::TimeStatisticsManager::STimeStatStepData& timestat) = 0;

			virtual void Finalize() = 0;

			//-----------------------------------------------------------------------------
			bool IsCancelationRequested();

			virtual bool IsTaskRejectionRequested(_STL::string& failureMessage) = 0;

		public:
			int fRefCount; // Smart pointer management. Must not be modified.

			// Internal Management method.
			// Must not be used.
			virtual	void SetCancelationState(bool mustCancel);

		private:
			bool fIsCanceling;
		};

		typedef sophis::tools::smart_ptr<CSRGridService, sophis::tools::ref_count_inside> CSRGridServiceHandle;

		struct SOPHIS_FIT SSCalculationStepData
		{
			SSCalculationStepData();
			SSCalculationStepData(bool canBeComputedOnServer);
			SSCalculationStepData(const SSCalculationStepData & copy);
			bool fCanBeComputedOnServer;
			_STL::set<_STL::string> fDependencies;
		};

		// Moved from CalculationDataInterface.h to avoid circular depedency
		class ArchiveFactorySwitcher {
		public:
			ArchiveFactorySwitcher(sophis::tools::CSRArchive* (*newFactory)())
			{
				fPrevFactory = sophis::tools::CSRArchive::CreateInstance;
				sophis::tools::CSRArchive::CreateInstance = newFactory;
			};

			~ArchiveFactorySwitcher()
			{
				sophis::tools::CSRArchive::CreateInstance = fPrevFactory;
			};
		private:
			sophis::tools::CSRArchive * (*fPrevFactory)();
		};

		/** Defines a calculation step for portfolio calculation.
		@since 7.1
		*/
		SOPHIS_FIT _STL::string ToPortfolioStep(long sicovam, bool arbitrage);

		/** Defines a calculation step for standard scenario calculation.
		@since 7.1
		*/
		SOPHIS_FIT _STL::string ToScenarioStep(long sicovam, bool arbitrage, int marketDataIndex);

		/** Get information related to a portfolio calculation.
		@since 7.1
		*/
		SOPHIS_FIT void FromPortfolioStep(const _STL::string & step, long & sicovam, bool & arbitrage);

		/** Get information related to a portfolio calculation.
		@since 7.1
		*/
		SOPHIS_FIT void FromScenarioStep(const _STL::string & step, long & sicovam, bool & arbitrage, int & marketDataIndex);

		/**
		 * Method used by calculation server clients to know dependencies between calculation steps
		 * in case a step represent an instrument.
		 * @param stepsData Map keys represent inputs. Dependencies are stored in the map values.
		 * @version 7.1
		*/
		SOPHIS_FIT void BuildDependencies(_STL::map<_STL::string, SSCalculationStepData> & stepsData);
	}
}

// For archives

extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::calculation::SSTaskDescriptor& td);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::calculation::SSTaskDescriptor & td);

extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const  _STL::map<_STL::string, sophis::tools::CSRArchive*> &v);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, _STL::map<_STL::string, sophis::tools::CSRArchive*> &v);


SPH_EPILOG

#endif
