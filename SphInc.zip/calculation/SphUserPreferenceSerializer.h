/********************************************************************
*	@date:		24.03.2005 
*	
*	@file:	 	SphUserPreferenceSerializer.h
*
*				Copyright (C) 2005 SOPHIS
*	
*	@purpose:	Allows transfer user preferences, defined in Toolkit dll, 
*				and needed during calculation, to Calculator.
*
*				The source code example can be found in ~/SphToolkit/SphSrc/UserPreferenceSerializer
*
*	@since		4.5.1.0.18
*
*
*/
#if (defined(WIN32)||defined(_WIN64))
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SphUserPreferenceSerializer_H_
#define _SphUserPreferenceSerializer_H_

/**
* System includes
*/
#include "SphTools/SphCommon.h"
#include "SphTools/SphExceptions.h"
#include __STL_INCLUDE_PATH(string)

/**
* Application includes
*/

#include "SphTools/SphPrototype.h"

#include "SphInc/SphMacros.h"

/**
* defines
*/

/**
* typedef and classes
*/


/**
* forward declarations of classes
*/



#define DECLARATION_USER_PREFERENCE_SERIALIZER(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::calculation::CSRUserPreferenceSerializer)
#define	INITIALISE_USER_PREFERENCE_SERIALIZER(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis
{
	namespace tools	{
		class CSRArchive;
	}
	
	namespace calculation
	{

		/** Interface to transfer user preferences to the calculation server.
		You derive that class for each set of preferences you want to transfer
		and you instanciate using the prototype. 
		Then for each element of the prototype, export is called on the client level
		using an archive and at the server level, Import is called to deserialize.
		Of course, it is essential that the servers and the client use the same dll
		to serialize and deserialize the same way otherwise the behaviour of the 
		calculation server is unpredictable.
		@since 4.5.1.1.18
		@see CSRArchive
		*/
		class SOPHIS_FIT CSRUserPreferenceSerializer
		{
		public:
			/** Constructor.
			*/
			CSRUserPreferenceSerializer();

			/** Destructor.
			*/
			virtual ~CSRUserPreferenceSerializer();

		public:
			//-----------------------------------------------------------------------------
			/**
			 * from SphPrototype interface
			 */

			/** typedef for the prototype
			*/
			typedef sophis::tools::CSRPrototype<CSRUserPreferenceSerializer, _STL::string > prototype;

			/** access to the prototype singleton
			*	
			*	To add a trigger to this singleton, use INITIALISE_USER_PREFERENCE_SERIALIZER
			*	@see CSRPrototype
			*/
			static prototype & GetPrototype();

			/** Clone method needed by the prototype
			*	
			*	Usually, it is done automatically by the macro DECLARATION_USER_PREFERENCE_SERIALIZER
			*	@see CSRPrototype
			*/
			virtual CSRUserPreferenceSerializer * Clone() const = 0;

		public:
			//-----------------------------------------------------------------------------
			/** CSRUserPreferenceSerializer interface
			 *  
			 *	Those methods will be called for all registered user serializers during 
			 *	transferring preferences to & from Calculator
			 *
			 */

			/**	Serializer
			 * 
			 *	Insert data into archive
			 * 
			 *	@see CSRArchive
			 */
			virtual void Export( sophis::tools::CSRArchive & data) const = 0;
			
			/** Deserializer
			 * 
			 *	Extracts data from archve
			 * 
			 *	@see CSRArchive
			 */
			virtual void Import( const sophis::tools::CSRArchive & data) const = 0;
		
		};
	} // end of namespace misc

}// end of namespace sophis


SPH_EPILOG


/**
* Globals
*/

/**
* Inline Methods
*/

#endif // _SphUserPreferenceSerializer_H_

