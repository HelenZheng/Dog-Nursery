#ifndef _SphCashReconBalanceColumn_H_
#define _SphCashReconBalanceColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphEnums.h"
#include "SphInc/SphMacros.h"
#include "SphInc/cash_recon/SphCashReconContext.h"
#include "SphInc/cash_recon/SphCashReconBalanceResultData.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)

using namespace sophis;
using namespace tools;

struct SSCellStyle;
union SSCellValue;

SPH_PROLOG
namespace sophis
{
	namespace cash_recon 
	{
		class CSRCashReconContext;

		/**
		* Macros for handling Cash Balance Reconciliation Column prototype implementation.
		*/
#define DECLARATION_CASH_RECON_BALANCE_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconBalanceColumn)

#define WITHOUT_CONSTRUCTOR_CASH_RECON_BALANCE_COLUMN(derivedClass)
#define CONSTRUCTOR_CASH_RECON_BALANCE_COLUMN_GROUP(derivedClass, group)	derivedClass::derivedClass() {fColumnGroup = group;} \
	WITHOUT_CONSTRUCTOR_CASH_RECON_BALANCE_COLUMN(derivedClass)

#define	INITIALISE_CASH_RECON_BALANCE_COLUMN(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/**
		* Cash Balance Reconciliation column and prototype.
		* 
		* To add a column, derive this class, using the macro DECLARATION_CASH_RECON_BALANCE_COLUMN in your header
		* and INITIALISE_CASH_RECON_BALANCE_COLUMN in UNIVERSAL_MAIN.
		*
		*/

		class SOPHIS_CASH_RECON CSRCashReconBalanceColumn
		{
				public:
			/** Constructor. */
			CSRCashReconBalanceColumn() : fId(0), fColumnGroup("") {}

			CSRCashReconBalanceColumn(const _STL::string & columnGroup) : fId(0), fColumnGroup(columnGroup) {}

			/** 
			* Main method to display the value for the column.
			* Must be implemented in derived classes.
			* @param context [in] the context the report has been run.
			* @param result [in] the data line for the column
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			virtual	void GetCell(const CSRCashReconContext & context, const CSRCashReconBalanceResultData &result, SSCellValue *value, SSCellStyle *style)  const = 0;
			
			/** 
			* Main method to display the aggregated value for the column. The aggregation logic is done in the columns.
			* This is called by the framework if the column supports aggregation which can be controlled by the CanAggregate function.			
			* @param context [in] the context the report has been run.
			* @param results [in] the list data line for the column
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			virtual void GetAggregatedCell(const CSRCashReconContext & context, const CSRCashReconBalanceResultDataList & results, SSCellValue *value, SSCellStyle *style) const;


			/**
			* Clone method required by the prototype.
			* Use DECLARATION_BO_CASH_REPORT_COLUMN macro in the implementation of the derived class.
			*/
			virtual CSRCashReconBalanceColumn* Clone() const = 0;

			/** 
			* Returns the default cell size in pixels.
			*/
			virtual short GetDefaultWidth() const;

			/**
			* Returns icon that is displayed in tree view when grouped by this column
			*/
			virtual short GetIconId() const;

			
			/**
			* Returns whether the column is available for grouping
			*/
			virtual bool CanGroup() const;
			
			/**
			* Returns whether the column is available for aggregation
			*/
			virtual bool CanAggregate() const;

			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id)
			{
				fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashReconBalanceColumn, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();

			/**
			 * Returns the name of the column group for the given column.
			 * @version 7.0
			*/
			const _STL::string& GetColumnGroup() const
			{
				return fColumnGroup;
			}


			/**
			 * Fills cell value and style with given amount in given currency.
			 * Useful for GUI only.
			 * @param x Amount in given currency to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param ccy Currency of the amount.
			 */
			static void FillMoney(double x, SSCellValue *value, SSCellStyle *style, long ccy);

			/**
			 * Fills cell value and style with given date.
			 * Useful for GUI only.
			 * @param date Date to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 */
			static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

			/**
			* Fills cell style with the given currency.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the instrument for the amount.
			*/
			static void FillStyleMoney(SSCellStyle *style, long ccy);

			/**
			* Fills cell style with the given currency.
			* Useful for GUI display.
			* @param ccy Currency to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillStyleCurrency(long ccy, SSCellStyle *style);

			/**
			* Fills cell style with date style.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillStyleDate(SSCellValue *value, SSCellStyle *style);

			/**
			* Fills style for display of a double value.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the double value.
			* @param dec Number of decimals to be displayed.
			*/
			static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

			static void FillValueMoney(SSCellValue *value, long ccy, double amount);


			/** Internal. */
			static void RefreshPrototype();

		protected:
			long	fId;
			_STL::string fColumnGroup;
			
		};	
	}
}


SPH_EPILOG
#endif