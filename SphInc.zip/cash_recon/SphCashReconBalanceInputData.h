#pragma once
#ifndef _SphCashReconBalanceInputData_H_
#define _SphCashReconBalanceInputData_H_

#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace cash_recon {

/**
 * Basic interface of cash reconciliation balance data fetched by the source.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconBalanceInputData
{
protected:
	CSRCashReconBalanceInputData(){};
public:
	virtual ~CSRCashReconBalanceInputData(){};
	virtual CSRCashReconBalanceInputData * Clone() const = 0;
	virtual long GetAccountId() const = 0;
	virtual long GetBalanceDate() const = 0;
	virtual double GetClosingBalance() const = 0;
	virtual double GetOpeningBalance() const = 0;
	virtual long GetCurrency() const = 0;
	virtual long GetEntity() const = 0;
	virtual _STL::string GetSourceTypeName() const = 0;	
	virtual _STL::string GetSourceName() const = 0;
};

typedef _STL::list<CSRCashReconBalanceInputData *> CSRCashReconBalanceInputDataList;

	} // sophis
} // cash_recon

SPH_EPILOG

#endif // _SphCashReconBalanceInputData_H_
