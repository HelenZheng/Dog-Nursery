#ifndef _SphCashReconBalanceRuleCondition_H_
#define _SphCashReconBalanceRuleCondition_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphEnums.h"
#include "SphInc/SphMacros.h"
#include "SphInc/cash_recon/SphCashReconBalanceInputData.h"

#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis {
	namespace cash_recon{

		/**
		* Macros for handling Cash balance reconciliation rule conditions prototype implementation.
		*/
#define DECLARATION_CASH_RECON_BALANCE_RULE_CONDITION(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconBalanceRuleCondition)
#define WITHOUT_CONSTRUCTOR_CASH_RECON_BALANCE_RULE_CONDITION(derivedClass)
#define	INITIALISE_CASH_RECON_BALANCE_RULE_CONDITION(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/**
		* Cash balance reconciliation rule condition and prototype.
		* 
		* To add a condition, derive this class, using the macro DECLARATION_CASH_RECON_BALANCE_RULE_CONDITION in your header
		* and INITIALISE_CASH_RECON_BALANCE_RULE_CONDITION in UNIVERSAL_MAIN.
		*
		*/
		class SOPHIS_CASH_RECON CSRCashReconBalanceRuleCondition
		{
		public:
			enum eType
				{
					ePercent = 0, 
					eAbsolute = 1, 
					eCustom = 2
				};
			/** Constructor. */
			CSRCashReconBalanceRuleCondition(){}

			/**
			* Clone method required by the prototype.
			* Use DECLARATION_CASH_RECON_BALANCE_RULE_CONDITION macro in the implementation of the derived class.
			*/
			virtual CSRCashReconBalanceRuleCondition* Clone() const = 0;

			virtual bool GetCondition(const CSRCashReconBalanceInputDataList & balanceInputList) const = 0;

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototype<CSRCashReconBalanceRuleCondition, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();
			
		};
	} // namespace cash_recon
} // namespace sophis

SPH_EPILOG

#endif
