#pragma once

#ifndef _SphCashReconColumn_H_
#define _SphCashReconColumn_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphDescribable.h"
#include "SphInc/cash_recon/SphCashReconContext.h"
#include "SphInc/cash_recon/SphCashReconResultData.h"
#include  "SphTools\SphPrototype.h"
#include  "SphInc\tools\SphAlgorithm.h"
#include "SphInc\gui\SphColor.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis
{
	namespace cash_recon 
	{
		class CSRCashReconContext;

		/**
		* Macros for handling Cash Recon Context Column prototype implementation.
		*/
#define DECLARATION_CASH_RECON_CONTEXT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconColumn)

#define WITHOUT_CONSTRUCTOR_CASH_RECON_CONTEXT_COLUMN(derivedClass)
#define CONSTRUCTOR_CASH_RECON_CONTEXT_COLUMN_GROUP(derivedClass, group)	derivedClass::derivedClass() {fColumnGroup = group;} \
	WITHOUT_CONSTRUCTOR_CASH_RECON_CONTEXT_COLUMN(derivedClass)

#define	INITIALISE_CASH_RECON_CONTEXT_COLUMN(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/**
		* Cash Recon Context column and prototype.
		* 
		* To add a column, derive this class, using the macro DECLARATION_CASH_RECON_CONTEXT_COLUMN in your header
		* and INITIALISE_CASH_RECON_CONTEXT_COLUMN in UNIVERSAL_MAIN.
		*
		*/

		class SOPHIS_CASH_RECON CSRCashReconColumn
		{
				public:
			/** Constructor. */
			CSRCashReconColumn() : fId(0), fColumnGroup("") {}
			/** Constructor. */
			CSRCashReconColumn(const _STL::string & columnGroup) : fId(0), fColumnGroup(columnGroup) {}

			virtual ~CSRCashReconColumn();

			/** 
			* Main method to display the content.
			* Must be implemented in derived classes.
			* @param report is the CashRecon Context.
			* @param result line to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			virtual	void GetCell(const CSRCashReconContext & report, const CSRCashReconResultData &result, SSCellValue *value, SSCellStyle *style)  const = 0;
			
			/** 
			* Method to display the content of a group of cells.		
			* @param report is the CashRecon Context.
			* @param result line to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/

			virtual void GetAggregatedCell(const CSRCashReconContext & report, const CSRCashReconResultDataList & results, SSCellValue *value, SSCellStyle *style) const;

			/**
			* Clone method required by the prototype.
			* Use DECLARATION_CASH_RECON_CONTEXT_COLUMN macro in the implementation of the derived class.
			*/
			virtual CSRCashReconColumn* Clone() const = 0;

			/** 
			* Returns the default cell size in pixels.
			*/
			virtual short GetDefaultWidth() const;

			/**
			* Returns icon that is displayed in tree view when grouped by this column
			*/
			virtual short GetIconId() const;			
			
			/** 
			* Returns true if the cells can be grouped, false otherwise
			*/			
			virtual bool CanGroup() const;
			
			/** 
			* * Returns true if the cells can be aggregated, false otherwise
			*/			
			virtual bool CanAggregate() const;

			/** 
			* * Returns true if the cells can be used for calculations, false otherwise
			*/			
			virtual bool CanBeUsedForCalculations() const;
			

			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id)
			{
				fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashReconColumn, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();

			/**
			 * Returns the name of the column group for the given column.
			 * @version 7.0
			*/
			const _STL::string& GetColumnGroup() const
			{
				return fColumnGroup;
			}


			/**
			 * Fills cell value and style with given amount in given currency.
			 * Useful for GUI only.
			 * @param x Amount in given currency to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param ccy Currency of the amount.
			 */
			static void FillMoney(double x, SSCellValue *value, SSCellStyle *style, long ccy);

			/**
			 * Fills cell value and style with given date.
			 * Useful for GUI only.
			 * @param date Date to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 */
			static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

			/**
			* Fills cell style with the given currency.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the instrument for the amount.
			*/
			static void FillStyleMoney(SSCellStyle *style, long ccy);

			/**
			* Fills cell style with the given currency.
			* Useful for GUI display.
			* @param ccy Currency to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillStyleCurrency(long ccy, SSCellStyle *style);

			/**
			* Fills cell style with date style.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillStyleDate(SSCellValue *value, SSCellStyle *style);

			/**
			* Fills style for display of a double value.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the double value.
			* @param dec Number of decimals to be displayed.
			*/
			static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);
			
			
			/**
			* Rounds the amount of the currency and fills the value parameter with the rounded amount if the currency Id exists,
			* if not the value is set to the amount.
			* Useful for GUI display.
			* @param value an output parameter, used to round the amount of the currency .
			* @param ccy Currency of the double value.
			* @param amount of the currency.
			*/
			static void FillValueMoney(SSCellValue *value, long ccy, double amount);


			/** Internal. */
			static void RefreshPrototype();

		protected:
			/* the ID of the column*/
			long	fId;
			/*The column group*/
			_STL::string fColumnGroup;
			
		};	

		class SOPHIS_CASH_RECON ICashReconReportCustomiseValues
		{
		public:
			/**
			 * Function to get a translation for the reconciliation status based on a result
			 * @param context is the Cash Reconciliation Context.
			 * @param result is line to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 */
			virtual void GetCashReconStatusCell(const CSRCashReconContext & context, const CSRCashReconResultData & result, SSCellStyle * style, SSCellValue * value) const = 0;
			
			/**
			 * Function to get a translation for the reconciliation status based on its numerical value
			 * @param context is the Cash Reconciliation Context.
			 * @param result is line to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 */
			virtual void GetCashReconStatusCell(const CSRCashReconContext & context, long reconStatus, SSCellStyle * style, SSCellValue * value) const = 0;
			
			/**
			 * Function to get a color for reconciliation result
			 * @param context is the Cash Reconciliation Context.
			 * @param result is line to be displayed.
			 * rerutn value is the color
			 */
			virtual sophis::gui::SSRgbColor GetResultColor(const CSRCashReconContext & context, const CSRCashReconResultData & result)const = 0;
			
			/**
			 * Function to return color depending on the matching status i.e Break,Tolerance etc.
			 * @param status is the eCashReconMatchingStatus.			 
			 * rerutn value is the color
			 */
			virtual sophis::gui::SSRgbColor GetStatusColor(const int status) const = 0;
			
			static const ICashReconReportCustomiseValues * GetCashReconReportCustomiseValues();
			static void SetCashReconReportCustomiseValues(ICashReconReportCustomiseValues * customiser);
		};
	}
}


SPH_EPILOG
#endif