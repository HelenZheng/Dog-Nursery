#pragma once

#ifndef _SphCashReconContext_H_
#define _SphCashReconContext_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis {
	namespace cash_recon {

class CSRCashReconInputParam;
class CSRCashReconMatchingGroup;
class CSRCashReconInputData;
/**
 * Context for running cash reconciliation.
 *
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconContext
{
public:
	/** Constructor. */
	CSRCashReconContext();

	/** Destructor. */
	virtual ~CSRCashReconContext();

	/** Sets default context. */
	virtual void SetDefaultContext(CSRCashReconContext* defaultContext) {}

	/** Called at the start of reconciliation process. */
	virtual void Prepare(const CSRCashReconInputParam& param) {}
	
	/** Get matching group for a data (to skip matching process the groups can be assigned before matching) */
	virtual const CSRCashReconMatchingGroup * GetDefaultMatchingGroup(const CSRCashReconInputData * data) const {return 0;}

	virtual long GetReferenceCcy() const {return 0;}
	virtual long GetReferenceDate() const {return 0;}
	
	static double GetForex(long refCcy, long ccy, long date);
	
protected:
	/** Default context implementation. */
	CSRCashReconContext* fDefaultContext;
};

	} // cash_recon
} // sophis

SPH_EPILOG
#endif // _SphCashReconContext_H_