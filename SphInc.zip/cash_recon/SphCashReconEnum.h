#pragma once
#ifndef _SphCashReconEnum_H_
#define _SphCashReconEnum_H_

#include "SphInc/SphMacros.h"


SPH_PROLOG
namespace sophis {
	namespace cash_recon {

/**
 * Defines matching status for one to one matching condition.
 * @version 7.1
 */
enum eCashReconMatchingStatus
{
	crmsNotApplicable = -1,
	crmsUndefined = 0,
	crmsMatch,
	crmsTolerance,
	crmsBreak,
};

	} // cash_recon
} // sophis

SPH_EPILOG
#endif // _SphCashReconEnum_H_
