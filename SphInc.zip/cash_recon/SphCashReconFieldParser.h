#pragma once

#ifndef _SphCashReconFieldParser_H_
#define _SphCashReconFieldParser_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphDescribable.h"
#include "SphTools\SphPrototype.h"
#include  "SphInc\tools\SphAlgorithm.h"

#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)


SPH_PROLOG
namespace sophis
{
	namespace tools{
		namespace dataModel{			
			class DataSet;			
		}
	}
	namespace cash_recon 
	{


		/**
		* Macros for handling cash recon field parser prototype implementation.
		*/
		#define DECLARATION_CASH_RECON_FIELD_PARSER(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconFieldParser)		
		#define WITHOUT_CONSTRUCTOR_CASH_RECON_FIELD_PARSER(derivedClass)
		#define	INITIALISE_CASH_RECON_FIELD_PARSER(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/**
		* Interface for passing input to a Field Parser.
		*/

		class SOPHIS_CASH_RECON ICashReconFieldParserInput{
			public:
				/** Field parser input type. */
				virtual _STL::string GetType() const = 0;
		};

		/**
		* Class for passing string input to a Field Parser.
		*/

		class SOPHIS_CASH_RECON CSRCashReconFieldParserStringInput : public ICashReconFieldParserInput{
			public:
				/** Constructor. */
				CSRCashReconFieldParserStringInput(_STL::string input)
					:fInput(input){;}
				/** Field parser input type. */
				virtual _STL::string GetType() const;				
				/** Field parser input value. */
				virtual _STL::string GetInput() const;
			protected:
				_STL::string fInput;
		};

#ifndef GCC_XML

		/**
		* * Class for passing XML DataSet Input to a Field Parser.
		*/

		class SOPHIS_CASH_RECON CSRCashReconFieldParserXmlDataSetInput : public ICashReconFieldParserInput{
			public:
				/** Field parser input type. */
				virtual _STL::string GetType() const = 0;

				/** Field parser input value. */
				virtual const sophis::tools::dataModel::DataSet& GetInput() const = 0;

				static CSRCashReconFieldParserXmlDataSetInput* new_CSRCashReconFieldParserXmlDataSetInput(
					const sophis::tools::dataModel::DataSet& dataSet);
		};	
#endif
		/**
		* Class for handling the Field Parse result.
		*/
		class SOPHIS_CASH_RECON CSRCashReconFieldParserResult
		{
		public:	
			/** Constructor. */
			CSRCashReconFieldParserResult() {}
				/** destructor. */
			virtual ~CSRCashReconFieldParserResult() {}
			/** 
			This function returns the number of fields that have been parsed
			@return number of fields that have been parsed
			*/
			virtual int GetFieldCount() const=0;	
			/** 
			This function assigns the values to the members of the ISRDescribable::Field based on the fieldIndex;
			@param 	fieldIndex - the index of the field 		
			@param 	field - a reference to an ISRDescribable field who's members will be populated with the values that have been parsed out.
			*/
			virtual void GetField(int fieldIndex, sophis::tools::ISRDescribable::Field & field) const = 0;
			
		};
		
		/**
		* Cash Recon  Field parser and prototype.
		* 
		* To add a field parser, derive this class, using the macro DECLARATION_CASH_RECON_FIELD_PARSER in your header
		* and INITIALISE_CASH_RECON_FIELD_PARSER in UNIVERSAL_MAIN.
		*
		*/
		class SOPHIS_CASH_RECON CSRCashReconFieldParser
		{
		public:			
			/** Constructor. */
			CSRCashReconFieldParser() {fId=0;}
			/** destructor. */
			virtual ~CSRCashReconFieldParser(){}
			/************************************************************************/
			/* This method takes a
			@param implementation of ICashReconFieldParserInput that needs to be parsed 
			and returns a pointer to the result object.                                                                      */
			/************************************************************************/
			virtual CSRCashReconFieldParserResult * ParseFields(const ICashReconFieldParserInput & input) const = 0;
			/** This function creates an SQL query from the list of parser objects, Input string and table name  
			@param fieldParsers -  This is a list of field parser objects
			@param input this is the input to be parsed by the parsers.
			@param  tableName - this is the table which the insert SQL statment is used for.
			@return this method returns the SQL insert query
			*/
			static _STL::string GetQuery(const _STL::list<const CSRCashReconFieldParser*> & fieldParsers, 
				const ICashReconFieldParserInput & input, 
				const _STL::string & tableName);
			
			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table.
			*/

			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the parser
			*/
			void SetId(long id)
			{
				fId = id;
			}
			/** 
			* Typedef for the prototype : the key is a const char*.
			*/			

			typedef tools::CSRPrototypeWithId<CSRCashReconFieldParser, const char*, tools::less_char_star> prototype;
			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();
		
		protected:
			/**
			Id of the CSRCashReconFieldParser object
			*/
			long	fId;
		};		
	}
}
SPH_EPILOG
#endif