#pragma once
#ifndef _SphCashReconInputData_H_
#define _SphCashReconInputData_H_

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

#include __STL_INCLUDE_PATH(string)
SPH_PROLOG

namespace sophis {
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace cash_recon {

class CSRCashReconInputData;

/**
 * Provide implementation if the extra data added to the standard input data
 * @version 7.1.2
 */
class SOPHIS_CASH_RECON ISRCashReconExtraInputData
{
public:
	ISRCashReconExtraInputData(){}
	virtual ~ISRCashReconExtraInputData() {};
	
	/**
	 * Function to fetch extra data. Will be called by the framework when processing extra data
	 * @param inputData - reference to the standard input data
	 */
	virtual void LoadExtraData(const CSRCashReconInputData & inputData) = 0;
	
	virtual ISRCashReconExtraInputData * Clone() const  = 0;
};



//class CSRCashReconInputId;
class CSRCashReconInputSource;

/**
 * Provide implementation if the data can provide transaction.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetTransaction
{
public:
	virtual const sophis::portfolio::CSRTransaction * GetTransaction() const = 0;
};

/**
 * Provide implementation if the data can provide reference.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetReference
{
public:
	virtual _STL::string GetReference() const = 0;
};

/**
 * Provide implementation if the data can provide instrument reference.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetInstrumentReference
{
public:
	virtual _STL::string GetInstrumentReference() const = 0;
	virtual _STL::string GetInstrumentReferenceType() const = 0;
};

/**
 * Provide implementation if the data can provide thirdparty references.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetThirdReference
{
public:
	virtual _STL::string GetEntityReference() const = 0;
	virtual _STL::string GetCounterpartyReference() const = 0;
	virtual _STL::string GetDepositaryReference() const = 0;
	virtual _STL::string GetBrokerReference() const = 0;
};

/**
 * Provide implementation if the data can provide notional value.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetNotional
{
public:
	virtual double GetNotional() const = 0;
};

/**
 * Provide implementation if the data can provide external instrument value.
 * @version 7.1
 */
class SOPHIS_CASH_RECON ICashReconGetExternalInstrumentValue
{
public:
	virtual _STL::string GetExternalInstrumentValue() const = 0;
};

/**
 * Provide implementation if the data can provide reference.
 * @version 7.13
 */
class SOPHIS_CASH_RECON ICashReconGetTradeIdReference
{
public:
	virtual _STL::string GetTradeIdReference() const = 0;
};

/**
 * Basic structure of cash reconciliation data fetched by the source.
 * @version 7.1
 */
struct SOPHIS_CASH_RECON SSCashReconInputData
{
	// No constructor.

	/** Account id. */
	long fAccountId;

	/** Currency of the amount. */
	long fCurrency;

	/** Amount in given currency. */
	double fAmount;

	/** Trade date. */
	long fTradeDate;

	/** Settlement (value) date. */
	long fValueDate;

	/** Instrument id (if applicable). */
	long fInstrumentId;

	/** Trade id (if applicable). */
	sophis::portfolio::TransactionIdent fTradeId;

	/** Quantity (if applicable). */
	long fQuantity;

	/** Price (if applicable). */
	double fPrice;

	/** Counterparty (if applicable). */
	long fCounterparty;

	/** Entity (if applicable). */
	long fEntity;

	/** Broker (if applicable). */
	long fBroker;

	/** Depositary (if applicable). */
	long fDepositary;

	/** Counterparty fees (if applicable). */
	double fCounterpartyFees;

	/** Market fees (if applicable). */
	double fMarketFees;

	/** Broker fees (if applicable). */
	double fBrokerFees;

	/** Fees (if applicable). */
	double fFees;
	
	/** Allotment (if applicable). */
	long fAllotment;

	/** Business event (if applicable). */
	long fBusinessEvent;
	
	/** Gross amount (if applicable). */
	double fGrossAmount;
};

/**
 * interface for the input data.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconInputData
{
public:
	virtual ~CSRCashReconInputData()
	{
		if(fExtraInputData)
			delete fExtraInputData;
	};
	
	virtual CSRCashReconInputData* Clone() const = 0;
	/*{
		return new CSRCashReconInputData(*this);
	}*/

	virtual const CSRCashReconInputSource* GetSource() const {return fSource; };

	virtual bool equal(const CSRCashReconInputData& lhs, const CSRCashReconInputData& rhs) const;
	virtual bool less(const CSRCashReconInputData& lhs, const CSRCashReconInputData& rhs) const;

	/** Compares two elements if they are pointing to the same input data, like trade id. */
	static long Compare(const CSRCashReconInputData& lhs, const CSRCashReconInputData& rhs);

	/** Account id. */
	virtual long GetAccountId() const = 0;

	/** Currency of the amount. */
	virtual long GetCurrency() const = 0;

	/** Amount in given currency. */
	virtual double GetAmount() const = 0;

	/** Trade date. */
	virtual long GetTradeDate() const = 0;

	/** Settlement (value) date. */
	virtual long GetValueDate() const = 0;;

	/** Instrument id (if applicable). */
	virtual long GetInstrumentId() const = 0;

	/** Trade id (if applicable). */
	virtual sophis::portfolio::TransactionIdent GetTradeId() const = 0;

	/** Quantity (if applicable). */
	virtual long GetQuantity() const = 0;

	/** Price (if applicable). */
	virtual double GetPrice() const = 0;

	/** Gross amount if applicable. */
	virtual double GetGrossAmount() const = 0;

	/** Counterparty (if applicable). */
	virtual long GetCounterparty() const = 0;

	/** Entity (if applicable). */
	virtual long GetEntity() const = 0;

	/** Broker (if applicable). */
	virtual long GetBroker() const = 0;

	/** Depositary (if applicable). */
	virtual long GetDepositary() const = 0;

	/** Counterparty fees (if applicable). */
	virtual double GetCounterpartyFees() const = 0;

	/** Market fees (if applicable). */
	virtual double GetMarketFees() const = 0;

	/** Broker fees (if applicable). */
	virtual double GetBrokerFees() const = 0;

	/** Fees (if applicable). */
	virtual double GetFees() const = 0;

	/** Allotment (if applicable). */
	virtual long GetAllotment() const = 0;

	/** Business event (if applicable). */
	virtual long GetBusinessEvent() const = 0;

	/** Returns a pointer to the extra data if any */
	ISRCashReconExtraInputData * GetExtraInputData() const { return fExtraInputData;}
	
	/** To attach extra data to the standard input data */
	void SetExtraInputData(ISRCashReconExtraInputData * extraInputData) const	//not nice
	{
		if(fExtraInputData)
			delete fExtraInputData;
		fExtraInputData = extraInputData ? extraInputData->Clone() : NULL;
	}

protected:
	CSRCashReconInputData(const CSRCashReconInputSource* source)
		:fSource(source)
		, fExtraInputData(NULL)
	{}

	CSRCashReconInputData(const CSRCashReconInputData & other)
	{
		fSource = other.fSource;
		fExtraInputData = other.fExtraInputData ? other.fExtraInputData->Clone() : NULL;
	}

	const CSRCashReconInputSource* fSource;
	mutable ISRCashReconExtraInputData * fExtraInputData;
};


	} // sophis
} // cash_recon


SPH_EPILOG
#endif // _SphCashReconInputData_H_
