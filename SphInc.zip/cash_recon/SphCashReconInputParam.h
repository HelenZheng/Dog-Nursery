#pragma once
#ifndef _SphCashReconInputParam_H_
#define _SphCashReconInputParam_H_

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(set)
#include "SphInc\treasury\SphTreasuryAccount.h"

using namespace sophis::treasury;

SPH_PROLOG
namespace sophis {
	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}	

	namespace cash_recon {
		
class CSRInputSourceParam;
class CSRInputSourceParamValue;
typedef _STL::list<CSRInputSourceParam *> CSRInputSourceParamList;

/**
 * Data input (source) parameterization for running cash reconciliation.
 *
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconInputParam
{
public:
	enum eCashReconFlags
	{
		eFlagNone			= 0x00,
		eAccountLevelRecon	= 0x01		
	};

	/** Constructor. */
	CSRCashReconInputParam();

	/** Copy Constructor. */
	CSRCashReconInputParam(const CSRCashReconInputParam& other);

	/** Copy Constructor. */
	CSRCashReconInputParam * Clone() const;

	/** Destructor. */
	virtual ~CSRCashReconInputParam();
public:
	long StartDate() const ;
	void SetStartDate(long startDate);

	long NumberOfDays() const ;
	void SetNumberOfDays(long noOfDays);

	long ReferenceDate() const ;
	void SetReferenceDate(long ReferenceDate);

	long ReferenceCcy() const ;
	void SetReferenceCcy(long ccy);

	long Flags() const ;
	void SetFlags(long flags);

	bool ExcludeBlockedCash() const ;
	void SetExcludeBlockedCash(bool excludeBlockedCash);

	bool TradeDateExtraction() const;
	void SetTradeDateExtraction(bool tradeDateExtraction);


	long GroupId() const ;
	void SetGroupId(long groupId);

	_STL::string Name() const ;
	void SetName(_STL::string name);

	_STL::string SavePath() const;
	void SetSavePath(_STL::string strSavePath);

	_STL::string Comment() const ;
	void SetComment(_STL::string comment);

	_STL::set<long> EntityList() const ;
	void SetEntityList(const _STL::set<long>& entityList);

	const _STL::set<_STL::string>& CustodianList() const ;
	void SetCustodianList(const _STL::set<_STL::string>& custodianList);

	const _STL::set<long>& CcyList() const ;
	void SetCcyList(const _STL::set<long>& ccyList);

	const _STL::set<long>& AccountIdList() const ;
	void SetAccountIdList(const _STL::set<long>& accIdList);

	CSRInputSourceParamList& SourceParamList();	
	const CSRInputSourceParamValue* SourceParamValue(unsigned int index) const;	
	
	/* see if two instances of CSRCashReconInputParam are equal*/
	bool operator==(const CSRCashReconInputParam& other) const;

	/* see if two instances of CSRCashReconInputParam are not equal*/
	bool operator!=(const CSRCashReconInputParam& other) const;

	bool IsTreasuryAccountIncluded(const CSRTreasuryAccount& account) const;
	void GetTreasuryAccountList(_STL::vector<long>& treasuryAccountList, long currency, const backoffice_kernel::CSRThirdParty::VeAccountType& acTypes) const;
public:
	/** Internalize the DataSet param.*/
	virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);


	/** Populate the DataSet with report data*/	 
	virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
private:	
	void GetSourceParamList(tools::dataModel::DataSet& parent) const;
	void UpdateSourceParamListFromDescription(const tools::dataModel::DataSet& parent);	
public:
	CSRInputSourceParamList fSourceParamList;
private:	
	long fStartDate;
	long fNumberOfDays;		
	long fReferenceDate;
	long fReferenceCcy;
	long fFlags;
	bool fExcludeBlockedCash;
	bool fTradeDateExtraction;
	long fGroupId;
	_STL::string	fName;
	_STL::string	fSavePath;
	_STL::string	fComment;
	_STL::set<long> fEntityList;
	_STL::set<_STL::string> fCustodianList;
	_STL::set<long> fCcyList;
	_STL::set<long> fAccountIdList;		
};

	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconInputParam_H_