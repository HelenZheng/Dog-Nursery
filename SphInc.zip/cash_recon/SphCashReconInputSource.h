#pragma once

#ifndef _SphCashReconInputSource_H_
#define _SphCashReconInputSource_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphPacketVector.h"
#include "SphInc/cash_recon/SphCashReconBalanceInputData.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}
	namespace cash_recon {

class CSRCashReconInputParam;
struct SSCashReconInputData;
class CSRCashReconInputData;
class ISRCashReconExtraInputData;
class CSRCashReconContext;

/** List of records extracted from source. */
typedef _STL::vector<const CSRCashReconInputData*> CSRCashReconInputDataList;

class CSRCashReconInputSource;
class CSRCashReconInputSourceData;

/*
 *	Provide parameters to a cash reconciliation input source.
 *  @version 7.1
 */

class SOPHIS_CASH_RECON CSRInputSourceParamValue
{
public:
	/* Update the param value with the DataSet description.*/
	virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet) {;}			

	/* Get the DataSet description from the param value.*/	
	virtual void GetDescription(tools::dataModel::DataSet& dataSet) const {;}

	/** Clone interface. */
	virtual CSRInputSourceParamValue * Clone() const = 0;	

	/* See if two instances are equal*/
	virtual bool operator==(const CSRInputSourceParamValue & other) const {return false;}
};

/**
 * Data feed input for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconInputSourceData
{
public:
	/** Destructor. */
	virtual ~CSRCashReconInputSourceData();

	/** Clone interface. */
	virtual CSRCashReconInputSourceData* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRCashReconInputSourceData& source);

	/** Prepare (fetch) the data.
	 * @param param Report parameters.
	 */
	virtual void Prepare(CSRCashReconContext& context, const CSRCashReconInputParam& param) = 0;

	/** Test whether there are any results. Takes constant time unlike size(). */
	virtual bool empty() const = 0;

	/** Returns number of results. */
	virtual unsigned long size() const = 0;

	/** Shortcut to data list iterator. See begin() and end(). */
	typedef CSRCashReconInputDataList::iterator iterator;

	/** Returns iterator to the start of the result container. */
	virtual iterator begin() = 0;

	/** Returns iterator to the end of the result container. */
	virtual iterator end() = 0;

protected:
	CSRCashReconInputSourceData();
};

/**
 * Factory that can be registered to the source to create extra data.
  * @version 7.1.2
 */
class SOPHIS_CASH_RECON ISRCashReconExtraInputDataFactory
{
public:
	
	/** Function to create extra input data instance
	 */
	virtual ISRCashReconExtraInputData * new_CashReconExtraInputData() const = 0;
	
	virtual ISRCashReconExtraInputDataFactory * Clone() const = 0;
};

/**
 * Data feed input factory for cash reconciliation.
 * Responsible for treating data feed correctly.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconInputSource
{
public:
	/** Constructor. */
	CSRCashReconInputSource();

	/** Destructor. */
	virtual ~CSRCashReconInputSource();

	/** Clone interface. */
	virtual CSRCashReconInputSource* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRCashReconInputSource& source);

	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRCashReconInputSource, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();

	/** Allows a custom data feed interface to be provided (in case where additional parameterization is required). */
	virtual const CSRCashReconInputSourceData* GetSourceData(const CSRCashReconInputParam& cashReconParam, long paramIndex) const { return 0; }

	/** Creates a new input data object, which may provide source specific input data as well as basic data.
	 * @param basicData Basic set of fields.
	 * @param sourceData Source specific set of fields. */
	virtual CSRCashReconInputData* new_CashReconInputData(const SSCashReconInputData& basicData, _STL::string& sourceData) const;

	/** Loads extra input data to the input data list (call this from your GetSourceData if extra input data needs to be processed)
	 * @param inputData - the list of input data
	*/
	virtual void ProcessExtraInputData(CSRCashReconInputSourceData* inputData) const;
	
	/** 
	 *  Allows the creation of a custom input source parameter value.
	 */
	virtual CSRInputSourceParamValue * new_CashReconInputSourceParamValue() const{ return 0;}

	/** Source results for the balance reconciliation
		It's the callers responsibility to release memory allocated by the results
	*/
	virtual void GetSourceBalanceData(const CSRCashReconInputParam& cashReconParam, CSRCashReconBalanceInputDataList & results, long paramIndex) const = 0;

	/** Returns the name of the source. */
	_STL::string GetName() const { return fName; }

	/** Sets the name of the criteria. INTERNAL. */
	void SetName(const char* name) { fName = name; }

protected:
	_STL::string fName;
	ISRCashReconExtraInputDataFactory * fExtraDataFactory;
};

/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_CASH_RECON_INPUT_SOURCE(derivedClass)\
public:\
	derivedClass();\
	virtual sophis::cash_recon::CSRCashReconInputSource* Clone() const { derivedClass* c = new derivedClass(); c->Initialise(*this); return c; }
#define CONSTRUCTOR_CASH_RECON_INPUT_SOURCE(derivedClass)\
	derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_CASH_RECON_INPUT_SOURCE(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRCashReconInputSource::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_CASH_RECON_INPUT_SOURCE(derivedClass, name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::cash_recon::CSRCashReconInputSource*>(sophis::cash_recon::CSRCashReconInputSource::GetPrototype().GetData(name))->SetName(name);

	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconInputSource_H_