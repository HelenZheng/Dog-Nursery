#pragma once
#ifndef _SphCashReconMatchingCondition_H_
#define _SphCashReconMatchingCondition_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/cash_recon/SphCashReconEnum.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace cash_recon {

class CSRCashReconMatchingCondition;
class CSRCashReconInputData;
typedef _STL::vector<const CSRCashReconInputData*> CSRCashReconInputDataList;
typedef CSRCashReconInputDataList::const_iterator CSRCashReconInputDataPtr;
typedef _STL::list<CSRCashReconInputDataPtr> CSRCashReconInputDataPtrList;

/**
 * Structure defining tolerance status for cash reconciliation matching condition.
 * @version 7.1
 */
struct SOPHIS_CASH_RECON SSCashReconMatchingConditionTolerance
{
	enum eType
	{
		eNoTolerance = -1,
		ePercent = 0, 
		eAbsolute = 1, 
		eCustom = 2
	};

	/** Constructor. */
	SSCashReconMatchingConditionTolerance();
	/** Constructor, takes given input values */
	SSCashReconMatchingConditionTolerance(eType type, double tolerance, double absTolerance, const _STL::string& customTolerance);
	/** Clone interface. */
	SSCashReconMatchingConditionTolerance* Clone() const;
	/** The type of tolerance. */
	eType fType;
	/** Tolerance in % */
	double fTolerance;
	/** Tolerance in Absolute Value */
	double fAbsTolerance;
	/** Custom tolerance. */
	_STL::string fCustomTolerance;
	/** Returns reference to pre-defined no tolerance instance. */
	static const SSCashReconMatchingConditionTolerance& NoTolerance();
};

/**
 * Matching condition, part of the matching rule.
 *
 * To add a condition, derive this class, using the macro
 * DECLARATION_CASH_RECON_MATCHING_CONDITION in your header and
 * INITIALISE_CASH_RECON_MATCHING_CONDITION in UNIVERSAL_MAIN.
 *
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingCondition
{
public:
	/** Constructor. */
	CSRCashReconMatchingCondition();

	/** Destructor. */
	virtual ~CSRCashReconMatchingCondition();

	/** Clone interface. */
	virtual CSRCashReconMatchingCondition* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRCashReconMatchingCondition& condition);

	/** Perform one against one condition checking based on the given tolerance.
	 * @param input1 Value to match against each other.
	 * @param input2 Value to match against each other.
	 * @param tolerance Acceptable tolerance levels for the match, may be null.
	 */
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const = 0;

	/** Defines matching status for M to N matching condition. */
	struct SSStatus
	{
		eCashReconMatchingStatus fStatus;
		CSRCashReconInputDataPtrList fResultList1;
		CSRCashReconInputDataPtrList fResultList2;
	};

	/** Perform M versus N condition checking based on the given tolerance.
	 * Default implementation is to perform one to one matching when there is only one element in each list,
	 * otherwise the condition is considered not matched.
	 * @param inputList1 Values to match against other list.
	 * @param inputList2 Values to match against other list.
	 * @param tolerance Acceptable tolerance levels for the match, may be null.
	 */
	virtual void GetMatchingStatus(const CSRCashReconInputDataList& inputList1,
		const CSRCashReconInputDataList& inputList2,
		const SSCashReconMatchingConditionTolerance* tolerance,
		_STL::list<SSStatus>& resultList) const;

	/** Get the icon id for the matching condition. */
	virtual short GetIcone() const { return 200; }

	/** Returns the name of the matching condition. */
	_STL::string GetName() const { return fName; }

	/** Returns a bool indicating if tolerance is supported for this condition. */
	virtual bool IsToleranceSupported(){return false;}

	/** Sets the name of the matching condition. INTERNAL. */
	void SetName(const char* name) { fName = name; }

	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRCashReconMatchingCondition, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();

	/** Get the nth matching condition of the prototype.
	 * @param index Starts from zero.
	 * @return Matching condition object or 0 if out of bounds. */
	static const CSRCashReconMatchingCondition* GetMatchingCondition(unsigned int index);

	/** Get the matching condition from the prototype by name.
	 * @param name Matching condition name.
	 * @return Matching condition object or 0 if out of bounds. */
	static const CSRCashReconMatchingCondition* GetMatchingCondition(_STL::string& name);

	/** Get the index of given matching condition in the prototype by name.
	 * @param name Matching condition name.
	 * @return Index in the prototype or -1 if does not exist. */
	static int GetMatchingConditionIndex(_STL::string& name);

	/** Get the nth matching condition name from the prototype.
	 * @param index Starts from zero.
	 * @return Matching condition name or empty string if does not exist. */
	static _STL::string GetMatchingConditionName(unsigned int index);

	/** Install "overloaded" matching condition which allows same condition name to be shared between multiple sources. */
	static void InstallOverload(CSRCashReconMatchingCondition* condition, const char* name);

protected:
	_STL::string fName;
};

/**
 * Macros for handling cash reconciliation matching condition derived classes and prototype.
 * @version 7.1
 */
#define DECLARATION_CASH_RECON_MATCHING_CONDITION(derivedClass)\
	public:\
	derivedClass();\
	virtual  sophis::cash_recon::CSRCashReconMatchingCondition* Clone() const { derivedClass* c = new derivedClass(); c->Initialise(*this); return c; }
#define CONSTRUCTOR_CASH_RECON_MATCHING_CONDITION(derivedClass)\
	derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_CASH_RECON_MATCHING_CONDITION(derivedClass)
#define	INITIALISE_CASH_RECON_MATCHING_CONDITION(derivedClass,name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::cash_recon::CSRCashReconMatchingCondition*>(sophis::cash_recon::CSRCashReconMatchingCondition::GetPrototype().GetData(name))->SetName(name);

/**
 * Macros for installing a overloaded condition.
 * Overloaded matching condition allows same condition name to be shared between multiple sources.
 * @version 7.1
 */
#define	INITIALISE_CASH_RECON_MATCHING_CONDITION_OVERLOAD(derivedClass,name)\
	sophis::cash_recon::CSRCashReconMatchingCondition::InstallOverload(new derivedClass(), name);\
	const_cast<sophis::cash_recon::CSRCashReconMatchingCondition*>(sophis::cash_recon::CSRCashReconMatchingCondition::GetPrototype().GetData(name))->SetName(name);

	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconMatchingCondition_H_