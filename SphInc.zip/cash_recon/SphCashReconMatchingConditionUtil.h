#pragma once

#ifndef _SphCashReconMatchingConditionUtil_H_
#define _SphCashReconMatchingConditionUtil_H_

#include "SphInc/SphMacros.h"
#include "SphInc/cash_recon/SphCashReconMatchingCondition.h"

SPH_PROLOG
namespace sophis {
	namespace cash_recon {

/**
 * Account matching condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionAccount : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionAccount)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
};

/**
 * Currency matching condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionCurrency : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionCurrency)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * Amount matching condition for cash reconciliation.
 * For M vs N, the sum of all amounts are compared.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionAmount : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionAmount)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual void GetMatchingStatus(const CSRCashReconInputDataList& inputList1,
		const CSRCashReconInputDataList& inputList2,
		const SSCashReconMatchingConditionTolerance* tolerance,
		_STL::list<SSStatus>& resultList) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * Trade date matching condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionTradeDate : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionTradeDate)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
};

/**
 * Settlement (value) date matching condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionValueDate : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionValueDate)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
};

/**
 * Instrument id condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionInstrumentId : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionInstrumentId)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
};

/**
 * External Instrument condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionExternalInstrumentValue : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionExternalInstrumentValue)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
};

/**
 * Trade id condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionTradeId : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionTradeId)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
};

/**
 * Quantity condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionQuantity : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionQuantity)

	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	void GetMatchingStatus(const CSRCashReconInputDataList& inputList1,
		const CSRCashReconInputDataList& inputList2,
		const SSCashReconMatchingConditionTolerance* tolerance,
		_STL::list<SSStatus>& resultList) const;

	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * price condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionPrice : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionPrice)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

class SOPHIS_CASH_RECON CSRCashReconMatchingConditionThirdparty : public virtual CSRCashReconMatchingCondition
{
public:
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
	const SSCashReconMatchingConditionTolerance* tolerance) const;
	
	// To get the thirdparty id based on an input
	virtual long GetThirdPartyId(const CSRCashReconInputData& input) const = 0;
};

/**
 * counterparty condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionCounterparty : public virtual CSRCashReconMatchingConditionThirdparty
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionCounterparty)
	// To get the thirdparty id based on an input
	virtual long GetThirdPartyId(const CSRCashReconInputData& input) const;
};

/**
 * entity condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionEntity : public virtual CSRCashReconMatchingConditionThirdparty
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionEntity)
	// To get the thirdparty id based on an input
	virtual long GetThirdPartyId(const CSRCashReconInputData& input) const;
};

/**
 * broker condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionBroker : public virtual CSRCashReconMatchingConditionThirdparty
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionBroker)
	// To get the thirdparty id based on an input
	virtual long GetThirdPartyId(const CSRCashReconInputData& input) const;
};

/**
 * depositary condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionDepositary : public virtual CSRCashReconMatchingConditionThirdparty
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionDepositary)
	// To get the thirdparty id based on an input
	virtual long GetThirdPartyId(const CSRCashReconInputData& input) const;
};


class SOPHIS_CASH_RECON CSRCashReconMatchingConditionFees : public virtual CSRCashReconMatchingCondition
{
public:
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;

	// To get the amount of fee based on an input
	virtual double GetFee(const CSRCashReconInputData& input) const = 0;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * broker fee condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionBrokerFee : public virtual CSRCashReconMatchingConditionFees
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionBrokerFee)
	// To get the amount of fee based on an input
	virtual double GetFee(const CSRCashReconInputData& input) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * counterparty fee condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionCounterpartyFee : public virtual CSRCashReconMatchingConditionFees
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionCounterpartyFee)
	// To get the amount of fee based on an input
	virtual double GetFee(const CSRCashReconInputData& input) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * market fee condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionMarketFee : public virtual CSRCashReconMatchingConditionFees
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionMarketFee)
	// To get the amount of fee based on an input
	virtual double GetFee(const CSRCashReconInputData& input) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * total fee condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionTotalFee : public virtual CSRCashReconMatchingConditionFees
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionTotalFee)
	// To get the amount of fee based on an input
	virtual double GetFee(const CSRCashReconInputData& input) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};


/**
 * allotment  condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionAllotment : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionAllotment)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
};

/**
 * Business event condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionBusinessEvent : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionBusinessEvent)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
};

/**
 * Gross Amount matching condition for cash reconciliation.
 * For M vs N, the sum of all gross amounts are compared.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionGrossAmount : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionGrossAmount)
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;
	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual void GetMatchingStatus(const CSRCashReconInputDataList& inputList1,
		const CSRCashReconInputDataList& inputList2,
		const SSCashReconMatchingConditionTolerance* tolerance,
		_STL::list<SSStatus>& resultList) const;
	/// See {@link CSRCashReconMatchingCondition::GetIcone}
	virtual short GetIcone() const;
	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

/**
 * Notional/Quantity condition for cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingConditionNotionalQuantity : public virtual CSRCashReconMatchingCondition
{
public:
	DECLARATION_CASH_RECON_MATCHING_CONDITION(CSRCashReconMatchingConditionNotionalQuantity)

	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	void GetMatchingStatus(const CSRCashReconInputDataList& inputList1,
		const CSRCashReconInputDataList& inputList2,
		const SSCashReconMatchingConditionTolerance* tolerance,
		_STL::list<SSStatus>& resultList) const;

	/// See {@link CSRCashReconMatchingCondition::GetMatchingStatus}
	virtual eCashReconMatchingStatus GetMatchingStatus(const CSRCashReconInputData& input1, const CSRCashReconInputData& input2,
		const SSCashReconMatchingConditionTolerance* tolerance) const;

	/// See {@link CSRCashReconMatchingCondition::IsToleranceSupported}
	bool IsToleranceSupported();
};

	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconMatchingConditionUtil_H_
