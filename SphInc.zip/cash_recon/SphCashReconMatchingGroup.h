#pragma once
#ifndef _SphCashReconMatchingGroup_H_
#define _SphCashReconMatchingGroup_H_

#include "SphInc/SphMacros.h"
#include "SphInc/cash_recon/SphCashReconEnum.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)


SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSREventVector;
	}
	namespace cash_recon {

class CSRCashReconMatchingRule;
class CSRCashReconInputData;
typedef _STL::vector<const CSRCashReconInputData*> CSRCashReconInputDataList;
typedef CSRCashReconInputDataList::const_iterator CSRCashReconInputDataPtr;
typedef _STL::list<CSRCashReconInputDataPtr> CSRCashReconInputDataPtrList;
struct SSMatchingGroupData;

/**
 * Structure representing the step-by-step matching results, for each rule/condition applied.
 * @version 7.1
 */
struct SSCashReconMatchingHistoryStep
{
	SSCashReconMatchingHistoryStep()
		:fConditionName("")
		,fStatus(crmsUndefined)
	{
	}

	SSCashReconMatchingHistoryStep(const _STL::string& conditionName, eCashReconMatchingStatus status)
		:fConditionName(conditionName)
		,fStatus(status)
	{
	}
	
	SSCashReconMatchingHistoryStep(const SSCashReconMatchingHistoryStep & other)
		:fConditionName(other.fConditionName)
		,fStatus(other.fStatus)
	{
	}

	_STL::string fConditionName;
	eCashReconMatchingStatus fStatus;
};

typedef _STL::vector<SSCashReconMatchingHistoryStep> CSRCashReconMatchingHistory;


/**
 * Matching group.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingGroup
{
public:

	enum eCashMatchingGroupType
	{
		eCashMatchingGroupManual,
		eCashMatchingGroupAutomatic,
	};

	/** Destructor. */
	~CSRCashReconMatchingGroup();

	/** Constructor. Internal. */
	CSRCashReconMatchingGroup(const SSMatchingGroupData& internalData);

	/** Copy Constructor. */
	CSRCashReconMatchingGroup(const CSRCashReconMatchingGroup& copy);

	/** New matching group for given rule and one to one matching. */
	static CSRCashReconMatchingGroup* new_MatchingGroup(eCashReconMatchingStatus status
		, const CSRCashReconMatchingRule* rule
		, const CSRCashReconMatchingHistory & matchingHistory
// 		, const CSRCashReconInputData* input1
// 		, const CSRCashReconInputData* input2
		);

	static CSRCashReconMatchingGroup * new_MatchingGroup(eCashReconMatchingStatus status, const _STL::string & matchingGroupName, const _STL::string & matchingGroupComment, const CSRCashReconMatchingHistory & matchingHistory, long reconStatus = -1);

// 	/** New matching group for given rule and multi to multi matching. */
// 	static CSRCashReconMatchingGroup* new_MatchingGroup(eCashReconMatchingStatus status
// 		, const CSRCashReconMatchingRule* rule
// // 		, CSRCashReconInputDataPtrList& resultList1
// // 		, CSRCashReconInputDataPtrList& resultList2
// 		);

	/** Returns id of the matching group. */
	long GetId() const { return fId; }

	/** Returns id of the rule used to create this matching group. */
	long GetRuleId() const { return fRuleId; }
	
	/** Sets the rule Id of the rule used to create this matching group. */
	void SetRuleId(long ruleId);

	/** Returns matching status of the matching group. */
	eCashReconMatchingStatus GetMatchingStatus() const { return fStatus; }

	/** Sets the matching status of the matching group. */
	void SetMatchingStatus(eCashReconMatchingStatus  status) { fStatus = status; }

	_STL::string GetMatchingGroupName() const { return fMatchingGroupName; }
	_STL::string GetMatchingGroupComment() const { return fMatchingGroupComment;}

	void SetMatchingGroupName(const _STL::string matchingGroupName);
	void SetMatchingGroupComment(const _STL::string matchingGroupComment);

	long GetReconStatus() const { return fReconStatus; } 
	void SetReconStatus(long reconStatus); 

	eCashMatchingGroupType GetMatchingGroupType() const {return fType; }
	void SetMatchingGroupType(eCashMatchingGroupType type);

	void SetMatchingHistory(const CSRCashReconMatchingHistory & matchingHistory);
	const CSRCashReconMatchingHistory & GetMatchingHistory() const;

	//static function to set the rule id in the matching group
	static void SetMatchingGroupStatus(long matchingGroupId, eCashReconMatchingStatus  status);
	static void SetMatchingGroupRuleId(long matchingGroupId, long matchingRuleID);
	static void SetMatchingGroupReconStatus(long matchingGroupId, long reconStatus);
	static void SetMatchingGroupName(long matchingGroupId, const _STL::string matchingGroupName);
	static void SetMatchingGroupComment(long matchingGroupId, const _STL::string matchingGroupComment);


	/** Populates the vector with ids of the results that belong to this matching group. */
	//void GetMatchingResultList(_STL::vector<long>& ids) const;

	/** Populates the matching group results per source. */
	//void GetMatchingResultPairs(_STL::vector<long>& ids1, _STL::vector<long>& ids2) const;

	/** Returns new unique matching group id from the corresponding database sequence. */
	static long GetNewId();

// 	/**	Reserve the code for a new matching group. */
// 	void ReserveId(long code);
// 
// 	/**	Reserve the code for a new matching group. */
// 	void ReserveId() { ReserveId(GetNewId()); }
// 
// 	/** Returns reserved id or 0 if no reservation was made. */
// 	long GetReservedId() const { return fReservedId; }

	/** Returns current instance of the matching group. It is not safe to store this pointer. */
	static const CSRCashReconMatchingGroup* GetMatchingGroup(long matchingGroupId);

	/** Loads multiple matching groups at once. */
	static void GetMatchingGroups(const _STL::vector<long>& matchingGroupIds, _STL::vector<const CSRCashReconMatchingGroup*>& matchingGroups);

	/** Performs data consistency sanity checking if the matching group can be saved or not. */
	bool IsReady();

	/** Perform standalone save. */
	void Save() const;

	/** Save matching group in transaction mode. */
//	void MultiSave(tools::CSREventVector &messages);

	/** Perform standalone delete of the matching group. */
//	void Delete();

	/** Delete matching group in transaction mode. */
//	void Delete(tools::CSREventVector &messages);

protected:
	CSRCashReconMatchingGroup();

private:
	mutable long fId;
//	long fReservedId;
	eCashReconMatchingStatus fStatus;
	long fRuleId;
	long fModifDate;
	_STL::string fModifTime;
	long fUserId;
	_STL::string fMatchingGroupName;
	_STL::string fMatchingGroupComment;
	long fReconStatus;
	eCashMatchingGroupType fType;
	CSRCashReconMatchingHistory fMatchingHistory;

	//_STL::list<_STL::pair<long, const CSRCashReconInputData*> > fResultList[2];
};

	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconMatchingGroup_H_