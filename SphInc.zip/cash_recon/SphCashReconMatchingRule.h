#pragma once
#ifndef _SphCashReconMatchingRule_H_
#define _SphCashReconMatchingRule_H_

#include "SphInc/SphMacros.h"
#include "SphInc\cash_recon\SphCashReconMatchingCondition.h"
#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG
namespace sophis {
	namespace cash_recon {

class CSRCashReconMatchingCondition;
struct SSCashReconMatchingConditionTolerance;

/**
 * Matching rule for cash reconciliation.
 *
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconMatchingRule
{
public:
	/** Flags to indicate special kinds of processing for the matching rule. */
	enum eRule
	{
		/// Default processing. Default assumed 1 to 1 matching.
		crmrDefault = 0x00,
		/// Stop processing in case of mismatch and flag elements mismatched.
		crmrStopOnMismatch = 0x01,
		/// Perform M vs N matching.
		crmrMultiMulti = 0x02,
		/// Perform bucketing
		crmrBucketing = 0x04,
	};
	
	enum eRelationShipType{
		// 1 to 1 matching.
		eOneToOne = 0, 
		// Many to N matching.
		eManyToN = 1
	};

	/** One line of the matching rule. */
	struct SOPHIS_CASH_RECON SSCashReconMatchingRule
	{
		/** Default Constructor. */
		SSCashReconMatchingRule();
		/** Constructor. Makes copy (clone) of the input parameters. */
		SSCashReconMatchingRule(const CSRCashReconMatchingCondition* condition, const SSCashReconMatchingConditionTolerance* tolerance, eRule rule);
		/** Copy Constructor. */
		SSCashReconMatchingRule(const SSCashReconMatchingRule& copy);
		/** Destructor. */
		~SSCashReconMatchingRule();
		/** Clone. */
		SSCashReconMatchingRule* Clone() const;
		/** Matching condition. */
		CSRCashReconMatchingCondition* fCondition;
		/** Corresponding tolerance. */
		SSCashReconMatchingConditionTolerance* fTolerance;
		/** Condition result treatment. */
		eRule fRule;
	};

	/** Type definition for list of matching rules. */
	typedef _STL::vector<SSCashReconMatchingRule*> SSCashReconMatchingRuleList;

	/* Helper function to clear the list and free memory */
	static void ClearMatchingRuleList(SSCashReconMatchingRuleList list);

	/** Constructor. */
	CSRCashReconMatchingRule();

	/** Constructor which takes a list of rules with tolerances. */
	CSRCashReconMatchingRule(long id, _STL::string name,	
	long enabled, long quality, long priority, eRelationShipType relationshipType,	
	long assetclassfilter, _STL::string description, const SSCashReconMatchingRuleList& ruleList,_STL::string condition1,_STL::string condition2,_STL::string condition3);

	/** Destructor. */
	~CSRCashReconMatchingRule();

	/** Clone interface. */
	CSRCashReconMatchingRule* Clone() const;

	/*Check to see if the condition is matched when applied to the relevant InputData and returns true if it is matched*/
	bool IsConditionMatched(_STL::string conditionName, const CSRCashReconInputData & inputData) const;
	

	/** Par of clone interface. */
	void Initialise(long id, _STL::string name,	
	long enabled, long quality, long priority, eRelationShipType relationshipType,	
	long assetclassfilter, _STL::string description, const SSCashReconMatchingRuleList& ruleList,_STL::string condition1,_STL::string condition2, _STL::string condition3);

	/** Rules list. */
	SSCashReconMatchingRuleList fRuleList;

	/** Rule id, assigned by the system. */
	long fId;

	/** Rule Name. */
	_STL::string fName;

	/** Enabled. */
	bool fEnabled;

	/** Match quality. */
	long fQuality;

	/** Priority per instance. */
	long fPriority;

	/** The rule relationship. */
	eRelationShipType fRelationshipType;

	/** Restrict to a specific allotment. */
	long fAssetclassfilter;

	/** Rule Description. */
	_STL::string fDescription;
	
	/**Match based on this condition */
	_STL::string fCondition1;

	/**Match based on this condition */
	_STL::string fCondition2;

	/**Match based on this condition */
	_STL::string fCondition3;


};
	} // cash_recon
} // sophis

SPH_EPILOG
#endif // _SphCashReconMatchingRule_H_