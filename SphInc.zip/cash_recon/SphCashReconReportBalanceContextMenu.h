#ifndef _SphCashReconReportBalanceContextMenu_H_
#define _SphCashReconReportBalanceContextMenu_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/cash_recon/SphCashReconBalanceResultData.h"

#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis {
	namespace cash_recon {

/**
* Macro to be used instead of the Clone() method in the clients derived classes.
* Prototype framework will be responsible to instantiate clients objects.
* @param derivedClass is the name of the client derived class.
*/
#define DECLARATION_CASH_RECON_BALANCE_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconReportBalanceContextMenu)
#define CONSTRUCTOR_CASH_RECON_BALANCE_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_CASH_RECON_BALANCE_CONTEXT_MENU(derivedClass)
#define	INITIALISE_CASH_RECON_BALANCE_CONTEXT_MENU(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name); derivedClass::GetPrototype().GetData(name)->SetId(++sophis::cash_recon::CSRCashReconReportBalanceContextMenu::fCount)

/**
* The key string of the derived element is displayed in the menu.
*
* Note that menu items on the dialog appear in the order they are registered within the application.
* Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
*
* @version 7.1
*/

class SOPHIS_CASH_RECON CSRCashReconReportBalanceContextMenu
{
public:

	/**
	* Returns the id.
	* The value is automatically created at the initialization because it must be unique.
	* For internal use.
	*/
	int GetId() const
	{
		return fId;
	}

	/**
	* Sets the id.
	* The value is automatically created at the initialization because it must be unique.
	* For internal use.
	*/
	void SetId(long id) const
	{
		(const_cast<CSRCashReconReportBalanceContextMenu*>(this))->fId = id;
	}

	/** 
	* Typedef for the prototype : the key is a string.
	*/
	typedef tools::CSRPrototypeWithId<CSRCashReconReportBalanceContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	* Access to the prototype singleton.
	* To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
	*/
	static prototype& GetPrototype();

	
	virtual bool IsAuthorized(const CSRCashReconBalanceResultDataList& results) const = 0;

	
	virtual bool DoCashReconReportBalanceContextMenu(const CSRCashReconBalanceResultDataList& results, _STL::string& menuLabel) const = 0;

	/**
	* Allows to group context menu items in the specified order.
	* Items in different groups will be separated by a separator.
	* Groups 0 to 9 are reserved by Sophis.
	*/
	virtual long GetContextMenuGroup() const { return 0; }

	virtual _STL::string GetMenuLabel(const CSRCashReconBalanceResultDataList& results) const;

	/**
	* Counts the number of prototypes installed and assigns each prototype a number in sequence.
	* For internal use.
	*/
	static long fCount;

	virtual CSRCashReconReportBalanceContextMenu * Clone() const = 0;

protected:
	long fId;
};
	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconReportBalanceContextMenu_H_