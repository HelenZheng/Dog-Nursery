#ifndef _SphCashReconReportDoubleClick_H_
#define _SphCashReconReportDoubleClick_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

namespace sophis {

	namespace cash_recon {

		class CSRCashReconResultData;
		class CSRCashReconColumn;
		class CSRCashReconContext;


		/**
		* Macro to be used instead of the Clone() method in the clients derived classes.
		* Prototype framework will be responsible to instantiate clients objects.
		* @param derivedClass is the name of the client derived class.
		*/
#define DECLARATION_CASH_RECON_REPORT_DOUBLE_CLICK(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconReportDoubleClick)
#define CONSTRUCTOR_CASH_RECON_REPORT_DOUBLE_CLICK(derivedClass)
#define WITHOUT_CONSTRUCTOR_CASH_RECON_REPORT_DOUBLE_CLICK(derivedClass)
#define	INITIALISE_CASH_RECON_REPORT_DOUBLE_CLICK(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name); derivedClass::GetPrototype().GetData(name)->SetId(++sophis::cash_recon::CSRCashReconReportDoubleClick::fCount)

		/**
		*
		* To handle double clicks for each input source in the trade cash reconciliation report.
		* @version 7.1
		*/
		class SOPHIS_CASH_RECON CSRCashReconReportDoubleClick
		{
		public:

			/**
			* Returns the id.
			* The value is automatically created at the initialization because it must be unique.
			* For internal use.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* The value is automatically created at the initialization because it must be unique.
			* For internal use.
			*/
			void SetId(long id) const
			{
				(const_cast<CSRCashReconReportDoubleClick*>(this))->fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a string.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashReconReportDoubleClick, const char*, tools::less_char_star> prototype;

			/** 
			* Access to the prototype singleton.
			* To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
			*/
			static prototype& GetPrototype();

			
			/* function to determine that the double click can be executed. */
			virtual bool IsAuthorized(const CSRCashReconContext & context, const CSRCashReconResultData& result, const CSRCashReconColumn& col) const = 0;
			
			/* action of the double click */
			virtual bool DoCashReconReportDoubleClick(const CSRCashReconContext & context, const CSRCashReconResultData& result, const CSRCashReconColumn& col) const = 0;


			virtual CSRCashReconReportDoubleClick * Clone() const = 0;

			/**
			* Counts the number of prototypes installed and assigns each prototype a number in sequence.
			* For internal use.
			*/
			static long fCount;

		protected:
			long fId;
		};

	} // namespace cash_recon
} // namespace sophis

#endif // _SphCashReconReportDoubleClick_H_
