#ifndef __SphCSRCashReconReportInputParam_h__
#define __SphCSRCashReconReportInputParam_h__

#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(set)

namespace sophis {
	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}	
	namespace cash_recon
	{
/**
 * Data input (source) parameterization for running cash reconciliation report.
 *
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconReportInputParam
{
public:
	/** Constructor. */
	CSRCashReconReportInputParam();

	/** Copy Constructor. */
	CSRCashReconReportInputParam(const CSRCashReconReportInputParam& other);

	/** Copy Constructor. */
	CSRCashReconReportInputParam * Clone() const;

	/** Destructor. */
	virtual ~CSRCashReconReportInputParam();

public:
	long StartDate() const ;
	void SetStartDate(long startDate);

	_STL::string SavePath() const ;
	void SetSavePath(_STL::string savePath);

	long NumberOfDays() const ;
	void SetNumberOfDays(long noOfDays);

	long ReferenceDate() const ;
	void SetReferenceDate(long ReferenceDate);

	long ReferenceCcy() const ;
	void SetReferenceCcy(long ccy);

	_STL::set<long> ReconInstanceIdList() const ;
	void SetReconInstanceIdList(const _STL::set<long>& reconInstanceIdList);

	bool TradeDateExtraction() const;
	void SetTradeDateExtraction(bool tradeDateExtraction);
public:
	/** Internalize the DataSet param.*/
	virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);

	/** Populate the DataSet with report data*/	 
	virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

	void Update(const char* xmlBuffer);
	// Returned buffer must be destroyed with a call to the C function free()
	char* CreateBuffer();
private:	
	long fStartDate;
	_STL::string fSavePath;
	long fNumberOfDays;		
	long fReferenceDate;
	long fReferenceCcy;
	_STL::set<long> fInstanceIdList;
	bool fTradeDateExtraction;
};
	}
} //sophis
#endif
