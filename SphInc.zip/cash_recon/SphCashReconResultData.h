#pragma once
#ifndef _SphCashReconResultData_H_
#define _SphCashReconResultData_H_

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace cash_recon {

class CSRCashReconInputData;
class CSRCashReconInputSource;
class CSRCashReconMatchingGroup;

/**
  *implement this interface if result can provide input data
  * @version 7.1
  */
class ICashReconGetInputData
{
public:
	virtual const CSRCashReconInputData * GetInputData() const = 0;
};

/**
 * Interface that represents result of cash reconciliation.
 * @version 7.1
 */
class SOPHIS_CASH_RECON CSRCashReconResultData
{
public:
	/** Destructor. */
	virtual ~CSRCashReconResultData();

	/** Clone interface. */
	virtual CSRCashReconResultData* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRCashReconResultData& copy);

	/** Unique id of the result. */
	virtual long GetId() const = 0;

	/** Id of the scenario to which this result belongs to. */
	virtual long GetScenarioId() const = 0;

	/** Index of the input source (prototype) that generated the result. */
	virtual long GetSourceIndex() const = 0;

	/** Name of the input source (prototype) that generated the result. */
	virtual _STL::string GetSourceName() const = 0;

	/** Type name of the input source (prototype) that generated the result. */
	virtual _STL::string GetSourceTypeName() const = 0;

	/** Input source prototype that generated the result. */
	virtual const CSRCashReconInputSource* GetSource() const = 0;

	/** Matching group, if any, corresponding to the result. */
	virtual long GetMatchingGroupId() const = 0;

	/** Set the Matching Group Id */
	virtual void SetMatchingGroupId(long matchingGroupId) = 0;

	/** Matching group, if any, corresponding to the result. */
	virtual const CSRCashReconMatchingGroup* GetMatchingGroup() const = 0;

	/** Account id. */
	virtual long GetAccountId() const = 0;

	/** Currency of the amount. */
	virtual long GetCurrency() const = 0;

	/** Amount in given currency. */
	virtual double GetAmount() const = 0;

	/** Trade date. */
	virtual long GetTradeDate() const = 0;

	/** Settlement (value) date. */
	virtual long GetValueDate() const = 0;

	/** Instrument id. */
	virtual long GetInstrumentId() const = 0;

	/** Trade id. */
	virtual sophis::portfolio::TransactionIdent GetTradeId() const = 0;

	/** Name/Reference. */
	virtual _STL::string GetReference() const = 0;

	/** Returns whether the result has been modified*/
	virtual bool IsDirty() const = 0;

	/** Price. */
	virtual double GetPrice() const = 0;

	/** Gross Amount. */
	virtual double GetGrossAmount() const = 0;

	/** Quantity. */
	virtual long GetQuantity() const = 0;
	
	/** Counterparty (if applicable). */
	virtual long GetCounterparty() const = 0;

	/** Entity (if applicable). */
	virtual long GetEntity() const = 0;

	/** Broker (if applicable). */
	virtual long GetBroker() const = 0;

	/** Depositary (if applicable). */
	virtual long GetDepositary() const = 0;

	/** Counterparty fees (if applicable). */
	virtual double GetCounterpartyFees() const = 0;

	/** Market fees (if applicable). */
	virtual double GetMarketFees() const = 0;

	/** Broker fees (if applicable). */
	virtual double GetBrokerFees() const = 0;

	/** Fees (if applicable). */
	virtual double GetFees() const = 0;

	/** Allotment (if applicable). */
	virtual long GetAllotment() const = 0;

	/** Business event (if applicable). */
	virtual long GetBusinessEvent() const = 0;

	/** The comments added to the result from newest on top to the oldest **/
	virtual const _STL::vector<_STL::string>& GetComments () const = 0;
protected:
	CSRCashReconResultData();
};

typedef _STL::list<CSRCashReconResultData*> CSRCashReconResultDataList;
	} // cash_recon
} // sophis


SPH_EPILOG
#endif // _SphCashReconResultData_H_
