#ifndef _SphCashReconRuleCondition_H_
#define _SphCashReconRuleCondition_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphEnums.h"
#include "SphInc/SphMacros.h"
#include "SphInc/cash_recon/SphCashReconMatchingCondition.h"


#include __STL_INCLUDE_PATH(list)

namespace sophis {
	namespace cash_recon{
		class CSRCashReconInputData;

		/** List of records extracted from source. */
		typedef _STL::vector<const CSRCashReconInputData*> CSRCashReconInputDataList;

		/**
		* Macros for handling Cash balance reconciliation rule conditions prototype implementation.
		*/
#define DECLARATION_CASH_RECON_RULE_CONDITION(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, CSRCashReconRuleCondition)
//#define CONSTRUCTOR_BO_CASH_REPORT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_CASH_RECON_RULE_CONDITION(derivedClass)
#define	INITIALISE_CASH_RECON_RULE_CONDITION(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/**
		* Cash balance reconciliation rule condition and prototype.
		* 
		* To add a condition, derive this class, using the macro DECLARATION_CASH_RECON_RULE_CONDITION in your header
		* and INITIALISE_CASH_RECON_RULE_CONDITION in UNIVERSAL_MAIN.
		*
		*/
		class SOPHIS_CASH_RECON CSRCashReconRuleCondition
		{
		public:
			
			/** Constructor. */
			CSRCashReconRuleCondition() : fId(0) {}

			/**
			* Clone method required by the prototype.
			* Use DECLARATION_CASH_RECON_RULE_CONDITION macro in the implementation of the derived class.
			*/
			virtual CSRCashReconRuleCondition* Clone() const = 0;
			
			/**
			* Returns true if the the condition when applied to the InputData is is met.
			* @param InputData [in] the input data the whose value is to be tested with the condition.
			*/
			virtual bool GetCondition(const CSRCashReconInputData & InputData) const = 0;
			
			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique 
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			*/
			void SetId(long id)
			{
				fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashReconRuleCondition, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();

		protected:
			long	fId;
			
		};
	} // namespace cash_recon
} // namespace sophis

#endif
