#pragma once

#ifndef _SphCashReconSourceParamDlg_H_
#define _SphCashReconSourceParamDlg_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialog.h"


SPH_PROLOG
namespace sophis {
	namespace cash_recon {

		class CSRInputSourceParamValue;
		
	
#define DECLARATION_CASH_RECON_SOURCE_PARAM_DLG(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconSourceParamDlg)

#define	INITIALISE_CASH_RECON_SOURCE_PARAM_DLG(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass, name);	\
	derivedClass::GetPrototype().GetData(name)->SetId(++sophis::cash_recon::CSRCashReconSourceParamDlg::fCount);


/**
 * Dialog to parameterize the cash reconciliation sources.
 * 
 * To add a specific dialog, derive this class, using the macro DECLARATION_CASH_RECON_SOURCE_PARAM_DLG in your header
 * and INITIALISE_CASH_RECON_SOURCE_PARAM_DLG in UNIVERSAL_MAIN.
 * Make sure that the name registers matches with the name of the cash reconciliation source. (see SphInc\cash_recon\SphCashReconInputSource.h)
 * 
 * @version 7.1
 */

		class SOPHIS_CASH_RECON_GUI CSRCashReconSourceParamDlg: public sophis::gui::CSRFitDialog
		{ 
		public:
			/** Constructor. */
			CSRCashReconSourceParamDlg() : fId(0) {}
			CSRCashReconSourceParamDlg(const CSRCashReconSourceParamDlg & other) : fId(other.fId) {}

			virtual void GetParameterValues(CSRInputSourceParamValue & values) const=0;
			virtual void SetParameterValues(const CSRInputSourceParamValue & values)=0;
			virtual void InitElements()=0;
			virtual CSRCashReconSourceParamDlg * Clone() const = 0;
			static CSRCashReconSourceParamDlg * GetCashReconSourceParamDlg(const char * sourceName);			
			static _STL::string GetNameBySource(const CSRCashReconSourceParamDlg * source);
			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id) const
			{
				(const_cast<CSRCashReconSourceParamDlg*>(this))->fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashReconSourceParamDlg, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype();

			/**
			* Counts the number of prototypes installed and assigns each prototype a number in sequence.
			* For internal use.
			*/
			static long fCount;

		protected:
			long	fId;
		};

	} // namespace cash_recon
} // namespace sophis


SPH_EPILOG
#endif
