#ifndef _SphCashReconTradeEventHandler_H_
#define _SphCashReconTradeEventHandler_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphPacketVector.h"
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

#include __STL_INCLUDE_PATH(string)


namespace sophis {
	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}
	namespace cash_recon {

class CSRCashReconContext;

/**
  * Parameter to pass to the event to apply
  * by default it has to support the filtering by source type
  * @version 7.1	
  */
class SOPHIS_CASH_RECON ISRCashReconTradeEventHandlerParam
{
public:
	virtual _STL::string GetSourceTypeName() const = 0;
};

/**
  * Event to apply when trades are inserted, modified or deleted for an input source
  * have to take care about the matching groups and the result tables (default implementation)
  * @version 7.1	
  */
class SOPHIS_CASH_RECON CSRCashReconTradeEventHandler
{
public:
	
	enum eCashReconTradeEventType
	{
		eCashReconTradeEvent_Create,
		eCashReconTradeEvent_Modify,
		eCashReconTradeEvent_Delete,
	};

	/** Constructor. */
	CSRCashReconTradeEventHandler();

	/** Destructor. */
	virtual ~CSRCashReconTradeEventHandler();

	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRCashReconTradeEventHandler, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();
	/**
	  * Function to handle trade action
	  * context [in] - the context to handle the event
	  * tradeId [in] - id of the trade (within the source)
	  * eventType [in] - the type of trade event to be handled
	  * param [in] - extra parameters to take into account
	  * doCommit [in] - flag to allow commit in the handler
	*/
	virtual void HandleTradeAction(const CSRCashReconContext * context, sophis::portfolio::TransactionIdent tradeId, eCashReconTradeEventType eventType, const ISRCashReconTradeEventHandlerParam * param, bool doCommit) const;

	/**
	/**
	  * Function to handle trade event
	  * context [in] - the context to handle the event
	  * tradeId [in] - id of the trade (within the source)
	  * eventType [in] - the type of trade event to be handled
	  * param [in] - extra parameters to take into account
	  * doCommit [in] - flag to allow commit in the handler
	*/
	virtual void HandleTradeEvent(const CSRCashReconContext * context, 
	                              sophis::portfolio::TransactionIdent tradeId, 
	                              eCashReconTradeEventType eventType, 
	                              const ISRCashReconTradeEventHandlerParam * param,
								  bool doCommit) const;

# ifndef GCC_XML
	/// @deprecated 7.1.3
	DEPRECATED_TRANSACTION_IDENT
	virtual void HandleTradeEvent(const CSRCashReconContext * context, 
	                              long tradeId, 
	                              eCashReconTradeEventType eventType, 
	                              const ISRCashReconTradeEventHandlerParam * param) const
	{
		throw sophisTools::base::NotImplemented("HandleTradeEvent");
	}
# endif GCC_XML

	/** Returns the name of the handler. */
	_STL::string GetName() const { return fName; }

	/** Sets the name of the criteria. INTERNAL. */
	void SetName(const char* name) { fName = name; }

protected:
	_STL::string fName;
};

		/**
		* Macros for handling Cash Recon Context Column prototype implementation.
		*/
#define DECLARATION_CASH_RECON_TRADE_EVENT_HANDLER(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::cash_recon::CSRCashReconTradeEventHandler)

#define WITHOUT_CONSTRUCTOR_CASH_RECON_TRADE_EVENT_HANDLER(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRCashReconTradeEventHandler::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_CASH_RECON_TRADE_EVENT_HANDLER(derivedClass, name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::cash_recon::CSRCashReconTradeEventHandler*>(sophis::cash_recon::CSRCashReconTradeEventHandler::GetPrototype().GetData(name))->SetName(name);

	} // cash_recon
} // sophis

#endif // SphCashReconTradeEventHandler+