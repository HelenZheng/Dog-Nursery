#ifndef __AGREEMENTINITIALMARGINVALUE_H__
#define __AGREEMENTINITIALMARGINVALUE_H__

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)

namespace sophis {
	namespace collateral {

enum agreementType {
	eAgreementNotSet = 0,
	eMarginAgreed,
	eAgreementAgreed	
};

struct AgreementKey{
	AgreementKey():cptyId(0),entityId(0),conventionId(0){};
	AgreementKey(const AgreementKey& val):cptyId(val.cptyId), entityId(val.entityId), conventionId(val.conventionId){};
	AgreementKey(long _cptyId, long _entityId, long _conventionId):cptyId(_cptyId), entityId(_entityId), conventionId(_conventionId){};
	bool operator == (const AgreementKey& pa) const{
		return (this->cptyId == pa.cptyId && 
			this->entityId == pa.entityId && 
			this->conventionId == pa.conventionId);
	}

	long cptyId;
	long entityId;
	long conventionId;
};

struct less_AgreementKey
{
	bool operator()(AgreementKey x, AgreementKey y) const
	{ 
		if ((x.cptyId < y.cptyId)||
			((x.cptyId == y.cptyId)&&(x.entityId < y.entityId))||
			((x.cptyId == y.cptyId)&&(x.entityId == y.entityId)&&(x.conventionId < y.conventionId)))
			return true;

		return false;
	}
};


struct SVarAgreedValue
{
	/** Default constructor. */
	SVarAgreedValue()
		: fCtpyValue(.0)
		, fEntityValue(.0)
		, fAgreedValue(.0)
		, fCurrency(0)
		, fDate(0)
		, fAgreeType(eAgreementNotSet)
	{
	}
	/** Constructor with specified values. */
	SVarAgreedValue(double ctpyValue, double entityValue, double agreedValue, long currency,long date,agreementType agreeType=eAgreementNotSet)
		: fCtpyValue(ctpyValue)
		, fEntityValue(entityValue)
		, fAgreedValue(agreedValue)
		, fCurrency(currency)
		, fDate(date)
		, fAgreeType(agreeType)
	{
	}
	/** Counterparty value. */
	double fCtpyValue;
	/** Entity value. */
	double fEntityValue;
	/** Agreed value. */
	double fAgreedValue;
	/** Currency of the values. */
	long fCurrency;
	/** Date of the agreed value. */
	long fDate;
	/** Differentiates between Agreed IM agreed and Agreed VM*/
	agreementType fAgreeType;
};

typedef _STL::vector<SVarAgreedValue> SVarAgreedValueList;

typedef _STL::map<AgreementKey, SVarAgreedValueList, less_AgreementKey> SAgreementVarAgreedValueMap;

	}
}
#endif //__AGREEMENTINITIALMARGINVALUE_H__