#pragma once
#ifndef _SphBOCashInstructionExtraction_H_
#define _SphBOCashInstructionExtraction_H_

#include "SphInc/Collateral/SphSecuritiesExtraction.h"
#include "SphInc/Collateral/SphSecuritiesReportResult.h"

SPH_PROLOG
namespace sophis {
	namespace treasury {
		class SSIConditionsMgr;
	}
	namespace collateral {

/**
 * Structure representing extra quantities fetched from BO_CASH_INSTRUCTION table.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRBOCashInstructionReportQuantities : public virtual CSRSecuritiesReportQuantities
{
public:
	/** Constructor, all zero quantities. */
	CSRBOCashInstructionReportQuantities();
	/** Destructor. */
	virtual ~CSRBOCashInstructionReportQuantities();
	/** Clone. */
	virtual CSRSecuritiesReportQuantities* Clone() const;
	/** Part of the clone interface. */
	virtual void Initialise(const CSRSecuritiesReportQuantities& copy);
	/** Reset quantities. */
	virtual void Clear();

	/** Add quantities from the given SSSecuritiesExtractionTrade structure. */
	virtual void AddLowLevelQuantities(const SSSecuritiesExtractionTrade& rhs,
		const CSRSecuritiesReportStatusAvailability* rhsSA);

	/** Sets quantities from self into low level trade information. */
	virtual void SetTradeQuantities(CSRSecuritiesExtractionTrade& trade) const;
	/** Quantities vector. */
	double fInstructionQuantities[CSRSecuritiesReportResult::eqtLast];

};

/**
 * Data structure for fetching extra fields from BO_CASH_INSTRUCTION table.
 * @version 6.3
 */
struct SOPHIS_COLLATERAL SSBOCashInstructionExtractionTrade : SSSecuritiesExtractionTrade
{
	long fTradeDate;
	long fWorkflowId;
	long fDeliveryType;
	long fPaymentMethod;
	long fBusinessEvent;
	char fAccountNo[41];

	double fTheoQuantity;
	double fTheoBookQuantity;
	double fTheoSLQuantity;
	double fTheoCollatQuantityPool;
	double fTheoCollatQuantityContract;

	double fOutgoingQuantity;
	double fOutgoingBookQuantity;
	double fOutgoingSLQuantity;
	double fOutgoingCollatQuantityPool;
	double fOutgoingCollatQuantityContract;
};

SOPHIS_COLLATERAL SSBOCashInstructionExtractionTrade& operator += (SSBOCashInstructionExtractionTrade& lhs, const SSBOCashInstructionExtractionTrade& rhs);

typedef CSRSecuritiesExtractionTradeImpl<SSBOCashInstructionExtractionTrade> CSRBOCashInstructionExtractionTrade;

/**
 * Implementation of Securities Report extraction for fetching additional
 * data from BO_CASH_INSTRUCTION table.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRBOCashInstructionExtraction : public virtual CSRSecuritiesExtraction {
public:
	CSRBOCashInstructionExtraction();
	virtual ~CSRBOCashInstructionExtraction();
	virtual	void AllDeals(SecuritiesExtractionTradeList &list, const CSRSecuritiesReportParam& param, eSecuritiesExtractionType extrType, long date, long projectionEndDate);
	virtual _STL::string GetFieldDetailedReporting(eSecuritiesExtractionType extrType) const;
	virtual _STL::string GetMiddleLevelFieldReporting(sophis::collateral::eSecuritiesExtractionType extrType) const;
	virtual _STL::string GetFieldGroupReporting(eSecuritiesExtractionType extrType) const;
	virtual _STL::string GetGroupByReporting(eSecuritiesExtractionType extrType) const;
	virtual void ExtraFieldsForReporting(eSecuritiesExtractionType extrType, VecSExtraFieldInfo& outExtraFields) const;
	virtual _STL::string GetUnderlyingCondition(eSecuritiesExtractionType extrType) const;
	virtual unsigned long GetFlags(eSecuritiesExtractionType extrType) const;
	virtual _STL::string GetDateClause(eSecuritiesExtractionType extrType, unsigned long dateFlags) const;
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const SSSecuritiesExtractionTrade& trade) const;
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const portfolio::CSRTransaction& transaction, eSecuritiesExtractionType dateType, long securitiesCode, bool invertQuantities) const;
	virtual void TransactionToTrade(const portfolio::CSRTransaction& transaction, SSSecuritiesExtractionTrade& trade, eSecuritiesExtractionType dateType, long securitiesCode, bool invertQuantities) const;
	virtual CSRSecuritiesReportQuantities* new_SecuritiesReportQuantities() const;
	virtual bool UseRealSettlementDate() const;

protected:
	treasury::SSIConditionsMgr* fConditionsMgr;
	mutable bool fProjection;
private:
	//! Never defined, prohibits copying.
	CSRBOCashInstructionExtraction(const CSRBOCashInstructionExtraction&);
	//! Never defined, prohibits assignment.
	void operator=(const CSRBOCashInstructionExtraction&);

	static const char* __CLASS__;
};

/**
 * Status and availability model for results fetched from BO_CASH_INSTRUCTION table.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRBOCashInstructionReportStatusAvailability : public virtual CSRSecuritiesReportStatusAvailability
{
public:
	CSRBOCashInstructionReportStatusAvailability();
	virtual ~CSRBOCashInstructionReportStatusAvailability();
	virtual CSRSecuritiesReportStatusAvailability* Clone() const;
	virtual void Initialise(const CSRSecuritiesReportStatusAvailability& copy);

	virtual void Initialise(const CSRSecuritiesReportResult& result);
	virtual void BeginAccumulation();
	virtual void Accumulate(const CSRSecuritiesReportStatusAvailability& childStatusAvailability);
	virtual void EndAccumulation();

	virtual void GetStyle(SSCellStyle *style) const;
};

}	//< namespace collateral
}	//< namespace sophis
SPH_EPILOG
#endif // _SphBOCashInstructionExtraction_H_
