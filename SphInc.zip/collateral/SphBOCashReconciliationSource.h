#pragma once
#ifndef _SphBOCashReconciliationSource_H_
#define _SphBOCashReconciliationSource_H_

#include "SphInc/collateral/SphSecuritiesReportSource.h"
#include "SphInc/collateral/SphSecuritiesExtraction.h"
#include "SphInc/collateral/SphSecuritiesReportColumn.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Structure representing BO_CASH_RECONCILIATION table.
 * @version 6.3
 */
struct SOPHIS_COLLATERAL SSBOCashReconciliationSourceData : SSSecuritiesExtractionTrade
{
	char fAccountNo[41];
	char fInstrumentType[41];
	char fInstrumentRef[41];
	char fCustodian[41];
};

SOPHIS_COLLATERAL SSBOCashReconciliationSourceData& operator += (SSBOCashReconciliationSourceData& lhs,	const SSBOCashReconciliationSourceData& rhs);

#ifndef GCC_XML
/**
 * Data source representing BO_CASH_RECONCILIATION table.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRBOCashReconciliationSourceData : public virtual CSRSecuritiesReportSourceData
{
public:
	CSRBOCashReconciliationSourceData();
	virtual ~CSRBOCashReconciliationSourceData();
	virtual CSRSecuritiesReportSourceData* Clone() const;
	virtual void Initialise(const CSRSecuritiesReportSourceData& source);
	virtual void DoSecuritiesExtraction(const CSRSecuritiesReportParam& param, long date);
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const SSSecuritiesExtractionTrade& trade) const;
	virtual bool empty() const;
	virtual unsigned long size() const;
	virtual iterator begin();
	virtual iterator end();

protected:
	SecuritiesExtractionTradeList* fDealList;
private:
	static const char* __CLASS__;
};
#endif

/**
 * Fetches information from BO_CASH_RECONCILIATION table.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRBOCashReconciliationSource : public virtual CSRSecuritiesReportSource
{
public:
	CSRBOCashReconciliationSource();
	virtual ~CSRBOCashReconciliationSource();
	virtual CSRSecuritiesReportSource* Clone() const;
	virtual void Initialise(const CSRSecuritiesReportSource& source);
	virtual const CSRSecuritiesReportSourceData* GetSourceData() const;
	virtual CSRSecuritiesReportResult* new_SecuritiesReportResult(CSRSecuritiesExtractionTrade * trade = 0) const;
	virtual CSRSecuritiesReportResultHier * new_SecuritiesReportResultHier(CSRSecuritiesReportResultHier & node) const;

private:
	static const char* __CLASS__;
};

typedef CSRSecuritiesExtractionTradeImpl<SSBOCashReconciliationSourceData> CSRBOCashReconciliationSourceTrade;

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphBOCashReconciliationSource_H_
