#ifndef _AGREEMENT_TESTER_H_
#define _AGREEMENT_TESTER_H_

#include "SphInc/SphMacros.h" // For SOPHIS_COLLATERAL
SPH_PROLOG
namespace sophis {
	namespace collateral {


struct ForecastResults
{
  double fCollateral;
  double fPrincipal;
  double fExposure;
  double fFreeCash;
};

// This class is used to facilitate testing.
class SOPHIS_COLLATERAL CSRCFDForecastHelper
{
  public:
    bool GenerateForecastForCFDAgreement(long cpty, long enty, long perim, long forecastdate, bool autoTransmit, ForecastResults& results);
	// This function calls the other GenerateForecastForCFDAgreement overload with autoTransmit = false
	bool GenerateForecastForCFDAgreement(long cpty, long enty, long perim, long forecastdate, ForecastResults& results);
	bool TodayForecast(bool div_on, bool alert_on, bool ost_on, bool generateCorpAction, long fFolio, bool autoTransmit, bool alertFile);
	// This function calls the other TodayForecast overload with autoTransmit = false and alertFile = false
	bool TodayForecast(bool div_on, bool alert_on, bool ost_on, bool generateCorpAction, long fFolio);
};
	}
}
SPH_EPILOG
#endif