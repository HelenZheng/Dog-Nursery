#ifndef _SphCFDReportingAPI_H_
#define _SphCFDReportingAPI_H_

#include "SphInc/collateral/SphCollateralReportingAPI.h"
#include "SphTools/SphCommon.h"
#include "SphInc/collateral/SphCollateralIndicator.h"
#include "SphInc/portfolio/SphPortfolioEnums.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {

	namespace portfolio {
		class CSRExtraction;
	}

	namespace collateral {
		class CSRLBAgreement;
		class CSRCFDResult;
		struct SCFDCalculationResults;
		struct SCollateralIndicatorDetails;
		class CSRCollateralReportContext;
		
		struct CFDReportIndicatorDetails : public SCollateralIndicatorDetails
		{
			double fFreeCashAmt;
			long fDefaultCollateralLastMarginDate;
			double fDefaultCollateralBalance;
		};

		/**
		* Bit flags used to control the behavior and output of CFD calculation API.
		* Custom (user-defined) flags should start from 0x10000.
		* @version 5.3.5
		*/
		enum eCFDReportingAPIFlags
		{
			/**
			* Minimum reporting results, no explanations.
			*/
			eCFDRFMinimum = 0x00,

			/**
			* Compute CFD fees explanation.
			*/
			eCFDRFComputeFees = 0x01,

			/**
			* Compute cash interest explanation for cash collateral.
			*/
			eCFDRFComputeCashInterest = 0x02,

			/**
			* To include empty CFD contracts and cash collateral sections even if 
			* there is no collateral.
			*/
			eCFDRFAllowEmptyPools = 0x04,

			/**
			* Can be used by XML report to generate not just Entity view (default one) but also Counterparty view
			*/
			eCFDRFIsEntityView = 0x08,

			/**
			* Flags used by XML report to generate detailed interest explanations
			*/
			eCFDRFComputeFeesDetails = 0x10,
			eCFDRFComputeCashInterestDetails = 0x20,

			/**
			* All settings required for common GUI display of the API results.
			*/
			eCFDRFCommonGui = eCFDRFComputeFees | eCFDRFComputeCashInterest | eCFDRFAllowEmptyPools | eCFDRFIsEntityView,	//==15

			/*
			 * Default values displayed when a new reporting template is being created.
			 */
			eCFDRFDefaultReporting = eCFDRFIsEntityView,

			/**
			* To hide closed positions in the report.
			*/
			eCFDRFHideClosedPositions = 0x40,
			
			/**
			* To display only aggregation lines
			*/
			eCFDRFDisplayOnlyAggregation = 0x80,
			
			/**
			* The same as above, but inverted (e.g. Counterparty view)
			*/
			eCFDRFCommonGuiCptyView = eCFDRFCommonGui ^ eCFDRFIsEntityView,	//==7
		};

		/**
		 * API for building and handling CFD reporting results.
		 * @since 5.3.4
		 */
		class SOPHIS_COLLATERAL CSRCFDReportingAPI : public virtual ISRCollateralReportingAPI
		{
		public:

			/**
			 * Structure to specify additional report parameters.
			 * @since 6.2.1
			 */
			struct SOPHIS_COLLATERAL SReportingParametersCFD : public ISRCollateralReportingAPI::SReportingParameters
			{
				SReportingParametersCFD();
				SReportingParametersCFD(eCFDReportingAPIFlags initialFlags);
				SReportingParametersCFD(const SReportingParametersCFD& copy);
				virtual ~SReportingParametersCFD() {}

				/** Optional Default Spot Historic Column. */
				int fHistoricSpotMethod;
				/** Optional Default Spot Time (Today/Yesterday). */
				long fTimeSpotMethod;

				/// See {@link ISRDescribable}
				virtual int GetFieldCount() const;
				/// See {@link ISRDescribable}
				virtual void GetField(int i, Field& field) const
					throw (ISRDescribable::InvalidRangeException);
				/// See {@link SReportingParameters::Clone}
				virtual ISRCollateralReportingAPI::SReportingParameters* Clone() const;
			};

			/**
			 * Creates an API which is going to use CFD reporting results defined by resultName.
			 * @param modelName Name of the CFD reporting result implementation to use.
			 * If not specified, the default CFD result reporting implementation is used.
			 * {@link CSRCFDResult::GetInstance}.
			 */
			CSRCFDReportingAPI(const char *modelName = 0);

			/**
			 * Destructor.
			 * Deletes all internal results.
			 */
			virtual ~CSRCFDReportingAPI();

			/**
			 * Builds a complete result hierarchy of all CFD and cash collateral deals
			 * related to the given collateral agreement.
			 * @param lba Collateral Agreement to which deals must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeAll(const CSRLBAgreement *lba, long calculationDate, long crfFlags);

			/**
			 * Builds a complete result hierarchy of all CFD and cash collateral deals
			 * related to the given collateral agreement specified as cpty/entity/convention.
			 * The values of cpty/entity/convention MUST point to a valid Collateral Agreement.
			 * @param cpty Counterparty of Collateral Agreement to which deals must belong (map) to.
			 * @param entity Entity of Collateral Agreement to which deals must belong (map) to.
			 * @param convention Convention of Collateral Agreement to which deal's instrument must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param extraParams Pointer to structure containing extra reporting parameters.
			 */
			virtual void ComputeAll(long cpty, long entity, long convention, long calculationDate, SReportingParameters *extraParams = 0);

			/**
			 * Builds a result for a given CFD position.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param mvtident Position Id (mvtident).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeOne(const CSRLBAgreement *lba, long calculationDate, sophis::portfolio::PositionIdent mvtident, long crfFlags);

			/**
			 * {@link ISRCollateralReportingAPI::GetResult}.
			 * Calls GetCFDResult().
			 */
			virtual const CSRCollateralResult* GetResult() const;

			/**
			 * Builds a dummy (blank) result tree that can be used to generate an XSD description.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeDummy(const CSRLBAgreement *lba, long crfFlags = -1);

			/**
			 * Returns the result pointer which must not be deleted.
			 */
			const CSRCFDResult* GetCFDResult() const;

			/**
			 * Returns calculation date as used for the result computation.
			 */
			long GetCalculationDate() const
			{
				return fCalculationDate;
			}

			/**
			 * Returns model name used to build CFD reporting results.
			 */
			const _STL::string& GetModelName() const
			{
				return fResultName;
			}

			/**
			 * This function is used to get the CFD report results from an extraction.
			 */
			static void sGetCfdForecastResult(const CSRLBAgreement *lba, 
											long reportingDate, 
											sophis::portfolio::PSRExtraction extr,
											CFDReportIndicatorDetails* detailedResults);

			/**
			 * This is the same as the other sGetCfdForecastResult with the exception of the isAgreementForecast parameter.
			 * If this is set to true, some of the agreement forecast specific behavior will occur.
			 */
			 static void sGetCfdForecastResult(const CSRLBAgreement *lba, 
											long reportingDate, 
											sophis::portfolio::PSRExtraction extr,
											CFDReportIndicatorDetails* detailedResults,
											bool isAgreementForecast);

			/**
			 * This function is used to save a CFD Report to the DB as a blob.
			 * It can then be used later as an explanation for an auto ticket.
			 * @param ctx Report context from where SaveCFDReportToDBAsXml() is being called.
			 * @param root is the root of the CFD Report to be saved to the DB as Xml.
			 * @param lba is the agreement the CFD Report is displaying.
			 * @param reportHistoryID is an id specific to a forecast/date/agreement. If a forecast is run on a CFD agreement
			 * there will only be one reportHistoryID. But if a global forecast is run, there will be one for each agreement
			 * that is keeping track of the explanations for auto tickets. This is not just for CFDs.
			 * @param reportingDate the date the report is run.
			 */
			static void SaveCFDReportToDBAsXml(const CSRCollateralReportContext &ctx, const CSRCFDResult * root, const CSRLBAgreement *lba, long reportHistoryID, long reportingDate);

			/**
			 * This function is used to get the last margin call date of the default collateral
			 * cash account. This is useful when running the forecast.
			 */
			long GetDefaultCollateralLastMarginDate() const;
			/**
			 * This function is used to get the balance of the default collateral cash account.
			 */
			double GetDefaultCollateralBalance() const;
			SCFDCalculationResults* fCfdReportingResult;

		protected:
			_STL::string fResultName;
			CSRCFDResult *fResult;
			long fCalculationDate;
						
			/**
			 * Internal use.
			 */
			void Initialize(const char *modelName = 0);

			long fDefaultCollateralLastMarginDate;
			double fDefaultCollateralBalance;
		private:
			static const char *__CLASS__;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCFDReportingAPI_H_
