#ifndef _SphCFDResult_H_
#define _SphCFDResult_H_

#include "SphInc/Collateral/SphCollateralResult.h"
#include "SphInc/Collateral/SphCreditRiskCalcModel.h"
#include "SphInc/portfolio/SphExtraction.h"
//#include "SphLLInc/Collateral/Engine/SphCollateralData.h"

#include "SphInc/collateral/SphStockLoanResult.h"
#include "SphInc/Collateral/SphLbaType.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/collateral/SphCollateralInitialAmountExplanation.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {

	//namespace portfolio {
	//	struct SSReportingTrade;
	//}

	namespace instrument {
		class CSRContractForDifference;
	}

	namespace collateral {
		struct FredDataCFD;
		union FredCFDReportingData;
		struct CashCollateral;

		/**
		 * Macro to be used instead of the Clone() method in the clients derived classes.
		 * Prototype framework will be responsible to instantiate clients objects.
		 * @param derivedClass is the name of the client derived class.
		 */
		#define DECLARATION_CFD_RESULT(derivedClass) \
			public: virtual CSRCFDResult* CloneCFD() const { return new derivedClass(*this); }

		#define LBA_CFD_MODEL "CFD Model"
	
		/**
		 * Represents detailed information of CFD or collateral position obtained via reporting.
		 * @version 5.3.3
		 */
		class SOPHIS_COLLATERAL CSRCFDResult: public CSRCollateralResult, public CSRCreditRiskCalcModel
		{
			static const char* __CLASS__;

		public:
			DECLARATION_CFD_RESULT(CSRCFDResult);

			virtual CSRCreditRiskCalcModel* Clone() const OVERRIDE { return CloneCFD(); }
			virtual CSRCollateralResult* CloneCollat() const OVERRIDE { return CloneCFD(); }

			/**
			* Defines line types of the result.
			* Also used to build hierarchy window of the results.
			*/
			enum eCFDResultLineType 
			{
				eCFDResultUndefined = 1000,
				eCFDResultRoot,				// 'Root', level-1
				eCFDResultContractsGroup,	// 'CFD Contracts', level-2
				eCFDResultCashPoolGroup,	// 'Cash Pool Collateral', level-2
				eCFDFreeCashGroup,          // 'Free Cash', level-2
				// level-3
				eCFDFreeCash,               //
				eCFDResultContracts = CSRLbaType::eSecVsCashPool,		// e.g. 'CFD-ACCOR-...', level-3
				eCFDResultCashPool = cmTypeCashPoolGroup				// e.g. 'EUR-EONIA-...', level-3
			};

			/**
			 * Returns a particular CFD result implementation singleton.
			 * @param modelName The name of the CFD result sought.
			 * @return A pointer which must not be deleted.
			 */
			static const CSRCFDResult* GetInstance(const char *modelName = LBA_CFD_MODEL);

		public:
			CSRCFDResult();
			CSRCFDResult(const CSRCFDResult& copy);
			virtual ~CSRCFDResult();

			void Initialise(const CSRLBAgreement* lba, int lineType, long reportingDate, bool isInverted = false);
			// This overload allows the setting of the line name. This will override the method for generating the line names.
			void Initialise(const CSRLBAgreement* lba, int lineType, long reportingDate, const _STL::string& lineName);
			const sophis::instrument::CSRContractForDifference* GetCFDInstrument() const;
			const CSRCFDResult& GetCFDMaster() const;
			void GetCFDChildren(_STL::vector<const CSRCFDResult*>& children) const;
			
			/**
			* Copies the name of hierarchy into the name parameter. 
			* Name parameter must point to preallocated area of memory.
			*/
			virtual void GetLineTypeName(char *name) const;

			/**
			 * @see {@link CSRCollateralResult::IsLower}
			 */
			virtual bool IsLower(const CSRCollateralResult& result1, const CSRCollateralResult& result2) const;

			virtual void AddChildValues(const CSRCollateralResult *child);

			/**
			 * @see {@link CSRCollateralResult::GetInstrumentInformationCode}
			 */
			virtual long GetInstrumentInformationCode() const;

			/**
			 * Check if the reporting date is the same as the folio date. This may have an
			 * affect on some columns in the CFD Report.
			 */
			bool IsReportingDateSameAsFolioDate() const;

		protected:
			/** FOR INTERNAL USE ONLY.
			* Computes custom values for the result based on given reporting data.
			* @param reportingData Low-level reporting data.
			* @param lba Collateral Management Agreement.
			* @param calcualtionDate Reporting date.
			* @param ccy Reference currency, if not specified, reference currency of the collateral agreement is used.
			*/
			void Compute(const FredCFDReportingData& reportingData, 
				const CSRLBAgreement *lba, long calculationDate, long ccy = 0);

			/** FOR INTERNAL USE ONLY.
			* Computes cash interest and commission explanations for the result based on given reporting data.
			* @param reportingData Low-level reporting data.
			* @param lba Collateral Management Agreement.
			* @param calcualtionDate Reporting date.
			*/
			void ComputeExplanations(const FredCFDReportingData& reportingData, 
				const CSRLBAgreement *lba, long calculationDate);

			/*
			void ComputeCash(const CashCollateral* cashCollateral);
			void ComputeCFD(sophis::portfolio::PositionIdent positionId, const FredDataCFD* fredDataCFD);
			*/

		public:
			bool fReInit;
			int fInitialMethodPrototypeIdx;

		protected:
			long fReportingDate;
			long fCfdCode;			// instrument ID
			sophis::portfolio::PositionIdent fPositionId;			
			long fPortfolioCode;
			long fRefCcy;
			double fPrincipal;
			double fCollateral;
			long fLastMarginDate;
			
			// 
			// Used for Indicators
			//

			//contracts
			long   fSecNumber;				// Number of CFD underlying securities
			double fLastUnderlyingSpot;		// Last value of CFD underlying security
			double fAveragePrice;			// Average Price computed with FIFO methodology
			double fAssetValue;				// Asset Value of Underlying Securities
			double fFeesSettled;			// sum of all Commissions + Interests up-to last reset date
			double fFeesAccrued;			// sum of last Commission + Interest since last reset date
			double fUnRealized;				// unrealized - the collateral view, using the LBA prices setup
			double fUnRealizedFolio;		// unrealized - the same as in the portfolio
			double fRealized;				// realized - the same as in the portfolio
			double fDivRecvCoupon;			// divident receivable coupon
			double fDivRebUnsettled;		// divident rebate unsettled
			double fDivRebSettled;			// divident rebate settled
			double fRealizedSettled;
			double fRealizedUnSettled;
			double fUnrealizedSettled;
			double fTotalFees;
			double fCFDResult;
			double fForexValue;
			double fForexCFD;
			double fCFDFolioResult;
			double fCFDFolioBalance;
			double fForexUnderlyingToLBA;
			double fForexCFDtoLBA;
			bool fFeesInAveragePrice;
			double fInitialMarginOnPrice;
			double fInitialMarginOnAccrual;
			double fInitialMarginOnPremium;
			double fUnderlyingParity;
			double fUnderlyingPremium;
			
			double fBrokerFees;
			double fCptyFees;
			double fMarketFees;
			double fTransactionFees;
			double fCFDPerformance;
			long fInitialMarginCcy;

			_STL::set<long> collCashVirtualMvt;

			CSRCashInterestExplanationList *fFundingInterestExplanationList;
			CSRCommissionExplanationList *fBorrowingInterestExplanationList;

			// cash pool

			/** Internal, cash pool collateral information. */
			CashCollateral *fCashCollateral;

			/** Internal, free cash pool information. */
			CashCollateral *fFreeCashAcc;

			/** Cash pool cash interest explanation list. */
			CSRCashInterestExplanationList *fCashPoolInterestExplanationList;

			/** Free cash interest explanation list. */
			CSRCashInterestExplanationList *fFreeCashInterestExplanationList;

			/** Haircut value as defined by the user. This may be different to the haircut value used for calculations. */
			double fCashPoolHaircutInProduct;
			/** It's the actual value of the haircut used in the internal computations. */
			double fCashPoolHaircutForCalculation;
			/** Fx between cash pool currency and reference currency. */
			double fCashPoolForex;
			
			double fInterestSettled;
			double fInterestAccrued;
			double fCashDeposit;
			double fCashTotalInterest;

			// header
			double fTotalResult;
			double fEntityMtm;
			double fPendingCashFlows;
			double fCFDExposure;
			double fCfdCreditRisk;
			double fCashCollateralValue;
			double fFreeCashValue;
			double fInitialMargin;
			double fMarginRate;			// Initial margin rate			
			CSRCollateralInitialAmountExplanation * fInitialMarginExpl;
			double fBalance;

			double fCFDNotional;
			double fInterestUnsettled;
			double fFeesUnsettled;
			double fCashDepositUnsettled;

			double fInterestYesterday;
			double fInterestPaidToday;

			/** IM Value */
			double fIMCounterpartyValue;
			/** Agreement level Agreed value */ 
			double fVMAgreementAgreedValue;
			/** Agreement level Counterparty value */ 
			double fVMAgreementCounterpartyValue;			
			/** Accumulated total for counterparty value for all positions for the given date */ 						
			double fVMCounterpartyPositionTotalValue;
			/** Accumulated total for agreed value for all positions for the given date */ 
			double fVMAgreedPositionTotalValue;
			/** Agreement level Entity value */ 
			double fVMAgreementEntityValue;			
			/** Total initial margin requirement. */
			double fIMTotal;

			_STL::string fLineName; // Only used if the CSRCFDResult has been initialised with a line name.

			/** Name of the indicator used to overload the computed value. */
			_STL::string fIndicatorName;

		public:
			// contracts
			long GetNumberOfSecurities() const { return fSecNumber; }
			double GetLast() const { return fLastUnderlyingSpot; }
			double GetAveragePrice() const { return fAveragePrice; }
			double GetAssetValue() const { return fAssetValue; }
			double GetRealized() const { return fRealized; }
			double GetUnRealizedFolio() const { return fUnRealizedFolio; }
			double GetUnRealized() const { return fUnRealized; }
			double GetCFDNotional() const { return fCFDNotional; }
			double GetDivRecvCoupon() const { return fDivRecvCoupon; }
			double GetDivRebUnsettled() const { return fDivRebUnsettled; }
			double GetDivRebSettled() const { return fDivRebSettled; }
			double GetRealizedSettled() const { return fRealizedSettled; }
			double GetRealizedUnsettled() const { return fRealizedUnSettled; }
			
			double GetForexValue() const { return fForexValue; }
			double GetCFDForexValue() const { return fForexCFD; }
			
			double GetUnrealizedSettled() const { return fUnrealizedSettled; }
			bool IsFeesInAveragePrice() const { return fFeesInAveragePrice; }
			double GetInterestYesterday() const { return fInterestYesterday;}
			double GetInterestPaidToday() const { return fInterestPaidToday;}
			double GetForexUnderlyingToLBA() const { return fForexUnderlyingToLBA; }
			double GetForexCFDtoLBA() const { return fForexCFDtoLBA; }
			
			double GetInitialMarginOnPrice() const { return fInitialMarginOnPrice; }
			double GetInitialMarginOnAccrual() const { return fInitialMarginOnAccrual; }
			double GetInitialMarginOnPremium() const { return fInitialMarginOnPremium; }
						
			double GetIMCounterpartyValue() const { return fIMCounterpartyValue; }
			/** Agreement level Agreed value */
			double GetVMAgreementAgreedValue() const { return fVMAgreementAgreedValue; }
			/** Agreement level Counterparty value */ 
			double GetVMAgreementCtpyValue() const { return fVMAgreementCounterpartyValue; }
			/** Accumulated total for counterparty value for all positions for the given date */ 									
			double GetVMAgreedPositionValueTotal() const { return fVMAgreedPositionTotalValue; }
			/** Accumulated total for agreed value for all positions for the given date */ 
			double GetVMCtpyPositionValueTotal() const { return fVMCounterpartyPositionTotalValue; }						
			/** Agreement level Entity value */ 
			double GetVMAgreementEntityValue() const { return fVMAgreementEntityValue; }
			/** Returns total initial margin, which is the agreement agreed initial margin (if applicable) and contracts initial margin.
			 * @version 7.1.1 */
			double GetIMTotal() const { return fIMTotal; }

			/* SetIMTotal @version 7.1.2 */ 
			void SetIMTotal(double imTotal) { fIMTotal = imTotal;}

			virtual double GetOneDayAccruedInterest() const;
			const CSRCashInterestExplanationList* GetFundingInterestExplanationList() const
			{
				return fFundingInterestExplanationList;
			}
			const CSRCommissionExplanationList* GetBorrowingInterestExplanationList() const
			{
				return fBorrowingInterestExplanationList;
			}

			double GetInitialMargin() const { return fInitialMargin; }
			double GetMarginRate() const { return fMarginRate; }
			const CSRCollateralInitialAmountExplanation * GetInitialAmountExplanation() const { return fInitialMarginExpl; }

			double GetBalance() const { return fBalance; }
			double GetUnderlyingParity() const { return fUnderlyingParity; }
			double GetUnderlyingPremium() const { return fUnderlyingPremium; }
			
			// cash pool

			/** Cash pool currency. */
			virtual long GetCashPoolCurrency() const;
			/** Cash pool interest rate (sicovam). */
			virtual long GetCashPoolInterestRate() const;
			/** Returns cash pool interest explanation list or null if there is no cash explanation list.
			* @return NULL or the pointer that must not be deleted. */
			const CSRCashInterestExplanationList* GetCashPoolInterestExplanationList() const;

			/** Returns free cash interest explanation list or null if there is no cash explanation list.
			* @return NULL or the pointer that must not be deleted. */
			const CSRCashInterestExplanationList* GetFreeCashInterestExplanationList() const;

			/** Balance (amount) of cash pool in cash pool currency. */
			double GetCashPoolAmount() const;
			/** Interest on cash pool amount since last frequency date in cash pool currency. */
			double GetCashPoolInterest() const;
			/** Yesterday's interest on cash pool amount since last frequency date in cash pool currency. */
			virtual double GetCashPoolYesterdayInterest() const;
			/** Interest paid today on cash pool interest, in cash pool currency. */
			double GetCashPoolInterestPaidToday() const;
			/** Haircut value for cash pool to be used in calculation.
			* @param haircutInProduct The value as specified by the user. */
			virtual double GetCashPoolHaircut(double* haircutInProduct = 0) const;
			/** Forex between cash pool currency and reference currency. */
			double GetCashPoolForex() const;

			/** Free Cash pool currency. */
			virtual long GetFreeCashPoolCurrency() const;
			/** Free Cash pool interest rate (sicovam). */
			virtual long GetFreeCashPoolInterestRate() const;
			/** If this is true, it is displaying the report in explanations mode 
			 *  This means the report is not displaying the normal mode and some of the functionality will
			 *  be disabled. 
			 */
			virtual bool IsExplanationMode() const {return false;}

			double GetCashDeposit() const { return fCashDeposit; }
			double GetCashDepositUnsettled() const { return fCashDepositUnsettled; }
			virtual double GetTotalInterest() const { return fInterestSettled + fInterestAccrued + fInterestUnsettled + fTotalFees; }
			
			double GetCashCollateralValue() const { return fCashCollateralValue; }
			double GetFreeCashValue() const { return fFreeCashValue; }
			void SetCollCashVirtualMvt(_STL::set<long> &mvtSet);
			const _STL::set<long>& GetCollCashVirtualMvt() const{return collCashVirtualMvt;}
			//AUX
		public:
			long GetReferenceCurrency() const { return fRefCcy; }
			sophis::portfolio::PositionIdent GetPositionId() const { return fPositionId; }
			double GetPrincipalValueInReferenceCurrency() const { return fPrincipal; }
			double GetCollateralValueInReferenceCurrency() const { return fCollateral; }
			long GetPortfolioCode() const { return fPortfolioCode; }
			virtual double GetInterestSettled() const;
			virtual double GetInterestUnsettled() const;
			virtual double GetInterestAccrued() const;
			double GetTotalFees() const { return fTotalFees; }
			double GetCFDResult() const { return fCFDResult; }
			double GetCFDFolioResult() const { return fCFDFolioResult; }
			double GetCFDFolioBalance() const { return fCFDFolioBalance; }
			
			double GetRiskValueInReferenceCurrency() const
			{
				// RISK = -PRINCIPAL + COLLATERAL, however, PRINCIPAL is already calculated using '-' sign :-)
				return GetPrincipalValueInReferenceCurrency() + GetCollateralValueInReferenceCurrency();
			}
			
			virtual double GetBrokerFees() const;
			virtual double GetCptyFees() const;
			virtual double GetMarketFees() const;

			double GetTotalResult();
			double GetMtMExposure();
			double GetEntityMtm();
			virtual long GetCFDResultCurrency() const;
			double GetTransactionFees() const { return fTransactionFees; }
			double GetCFDPerformance() const { return fCFDPerformance; }

			/*
			* Returns the date of the last margin call made.
			* @version 5.3.6
			*/
			inline long GetLastMarginDate() const { return fLastMarginDate; }

			/*
			* Returns the reporting date
			* @version 5.3.6
			*/
			long GetReportingDate() const { return fReportingDate; }

			/*
			* Get Initial Margin Currency
			*/
			long GetInitialMarginCcy() const { return fInitialMarginCcy; }

			/** Returns name of the overloaded indicator used to compute given line values. */
			_STL::string GetIndicatorName() const;

			// Header
		public:	
			virtual double GetExposureHdr(const CSRCFDResult *parent = NULL);
			virtual double GetAssetValueHdr(const CSRCFDResult *parent = NULL);
			virtual double GetCollateralValueHdr(const CSRCFDResult *parent = NULL);
			virtual double GetTotalResultHdr(const CSRCFDResult *parent = NULL);
			virtual double GetMtMExposureHdr(const CSRCFDResult *parent = NULL);

			virtual double GetInitialMarginHdr (const CSRCFDResult *parent = NULL);	

			virtual double GetFreeCashValueHdr(const CSRCFDResult *parent = NULL);
			virtual double GetCFDPerformanceHdr(const CSRCFDResult *parent= NULL);
			virtual double GetCFDAndCollatInterestHdr(const CSRCFDResult *parent = NULL);
			virtual double GetTransactionFeesHdr(const CSRCFDResult *parent = NULL);
			virtual double GetFreeCashInterestHdr(const CSRCFDResult *parent = NULL);
			double GetTotalUnrealizedHdr(const CSRCFDResult *parent = NULL);
			friend class CSRCFDReportingAPI;
			double GetUnsecuredExposureHdr();
			double GetThresholdHdr();
		private:
			virtual void SetInitialMarginHdr (double initialMargin, CSRCFDResult *parent = NULL);	
		public:
			
			mutable bool fIsInverted;	//used by GUI and XML Report to switch between Entity/Cpty View 
			friend class CSRInitialMarginProxy;
		};
	
	}	//namespace
}	//namespace
SPH_EPILOG
#endif // _SphCFDResult_H_