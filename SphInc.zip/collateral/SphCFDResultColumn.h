#ifndef _SphCFDResultColumn_H_
#define _SphCFDResultColumn_H_

#include "SphInc/collateral/SphCollateralResultColumn.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

#define DECLARATION_CFD_RESULT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralResultColumn)
#define CONSTRUCTOR_CFD_RESULT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_CFD_RESULT_COLUMN(derivedClass)
#define	INITIALISE_CFD_RESULT_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class CSRCFDResult;

/**
 * Interface to handle columns in CFD GUI.
 * To add a column, derive this class, using the macro DECLARATION_CFD_RESULT_COLUMN in your header
 * and INITIALISE_CFD_RESULT_COLUMN in UNIVERSAL_MAIN.
 *
 * @version 5.3.3
 */
class SOPHIS_COLLATERAL CSRCFDResultColumn : public virtual CSRCollateralResultColumn
{
public:

	CSRCFDResultColumn()
	{}

	/**
	 * {@link CSRCollateralResultColumn::GetCell}
	 * Invokes GetCFDCell().
	 */
	virtual	void GetCell(const CSRCollateralReportContext &ctx, const CSRCollateralResult &result, SSCellValue *value, SSCellStyle *style) const;

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param result CFD result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	*/
	virtual	void GetCFDCell(const CSRCollateralReportContext &ctx, const CSRCFDResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_CFD_RESULT_COLUMN
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/**
	 * name/id pair for a column. This is only used for the retrieval of name/id pairs 
	 * using the function GetColumnNameIDPairs.                                                                    
	 */
	struct ColumnNameIDPair
	{
		_STL::string name;
		int id;
	};

	/**
	 * It is not possible to access the columns in the prototype from the toolkit.
	 * The following allows the names and ids of all the columns registered in the prototype 
	 * to be accessed from the toolkit.
	 * @param columns A vector of ColumnNameIDPair which will be used to retrieve the list of names and ids
	 * of all the registered columns.
	 */
	static void GetColumnNameIDPairs(_STL::vector<ColumnNameIDPair>& columns);

protected:
	virtual bool NeedToInvertWhenSwitchingView(const CSRCFDResult &result) const;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
