#ifndef _CFDSPREADS_H_
#define _CFDSPREADS_H_
#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace collateral
	{
		struct CFDSpreads
		{
		public:
			CFDSpreads()
			{
				beginDate = 0;
				longSpread = shortSpread = 0.0;
			}
			CFDSpreads(long date, double sLong, double sShort)
				: beginDate(date), longSpread(sLong), shortSpread(sShort){}
			long beginDate;
			double longSpread;
			double shortSpread; 
		};
	}
}
SPH_EPILOG
#endif