#ifndef _SphCashInterestExplanation_H_
#define _SphCashInterestExplanation_H_

#include "SphInc/static_data/SphInterestRate.h" // For SOPHIS_COLLATERAL
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class CSRCollateralResult;
		class CSRLBAgreement;
		union FredReportingData;

/**
 * Macro to be used instead of the Clone() method in the clients classes derived from CSRCashInterestExplanation.
 * Clone() method duplicates the given explanation (deep copy).
 * The caller of the Clone() takes ownership of the resulting object and must destroy it.
 *
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_CASH_INTEREST_EXPLANATION(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRCashInterestExplanation)

/**
 * Macro to be used instead of the Clone() and CreateInstance() methods 
 * in the clients classes derived from CSRCashInterestExplanationList.
 * 
 * Clone() method duplicates the given explanation list (deep copy), including each individual explanation.
 * Clone() is useful, for example, in GUI mode for detaching explanation screens
 * from the main collateral reporting calculation and results.
 * 
 * CreateInstance() method returns an empty copy of the list.
 *
 * In either case the caller takes ownership of the resulting object and must destroy it.
 *
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_CASH_INTEREST_EXPLANATION_LIST(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRCashInterestExplanationList) \
	virtual CSRCashInterestExplanationList* CreateInstance() const { return new derivedClass; }


		/**
		 * Represents a particular cash interest explanation detail which is available as part of collateral reporting.
		 * @version 5.2.7.
		 */
		class SOPHIS_COLLATERAL CSRCashInterestExplanation
		{
		public:

			/**
			 * Constructor. Initialises everything to zero (null).
			 */
			CSRCashInterestExplanation();

			/**
			 * Copy constructor.
			 */
			CSRCashInterestExplanation(const CSRCashInterestExplanation& src);

			/**
			 * Destructor.
			 */
			virtual ~CSRCashInterestExplanation();

			DECLARATION_CASH_INTEREST_EXPLANATION(CSRCashInterestExplanation)

			/**
			 * Returns the start date of the cash remuneration period.
			 * The date refers to when the cash transfer or spread change occur.
			 */
			inline long GetStartDate() const { return fStartDate; }

			/**
			 * Sets a start date of the cash remuneration period.
			 * The date refers to when the cash transfer or spread change occur.
			 * @param startDate A date.
			 */
			inline void SetStartDate(long startDate) { fStartDate=startDate; }

			/**
			 * Returns the end date of the cash remuneration period.
			 */
			inline long GetEndDate() const { return fEndDate; }

			/**
			 * Sets an end date of the cash remuneration period.
			 * @param endDate A Date.
			 */
			inline void SetEndDate(long endDate) { fEndDate=endDate; }

			/**
			 * Returns the total cash amount for the date to remunerate.
			 */
			inline double GetCashAmount() const { return fAmount; }

			/**
			 * Sets the total cash amount for the date to remunerate.
			 * @param amount An Amount.
			 */
			inline void SetCashAmount(double amount) { fAmount=amount; }

			/**
			 * Returns the currency id (sicovam) of the cash amount.
			 */
			inline long GetCurrency() const { return fCurrency; }

			/**
			 * Sets a currency id (sicovam) of the cash amount.
			 * @param ccy Currency id (sicovam).
			 */
			inline void SetCurrency(long ccy) { fCurrency=ccy; }

			/**
			 * Returns the interest rate id (sicovam) of the interest rate used for remuneration.
			 */
			inline long GetInterestRate() const { return fInterestRate; }

			/**
			 * Sets an interest rate id (sicovam) of the interest rate used for remuneration.
			 * @param interestRateId Interest rate id (sicovam).
			 */
			inline void SetInterestRate(long interestRateId) { fInterestRate=interestRateId; }

			/**
			 * Returns the spread applied to calculate the remuneration.
			 */
			inline double GetSpread() const { return fSpread; }

			/**
			 * Sets a spread applied to calculate the remuneration.
			 * @param spread Spread applied to the interest rate for cash interest calculation.
			 */
			inline void SetSpread(double spread) { fSpread=spread; }

			/**
			* Returns the interest calculated between start and end dates.
			*/
			inline double GetInterestAmount() const { return fInterest; }

			/**
			* Sets an interest amount calculated between start and end dates.
			* @param interestAmount Interest amount.
			*/
			inline void SetInterestAmount(double interestAmount) { fInterest=interestAmount; }

			/**
			* Returns the interest paid (in case of roll) at end date.
			*/
			inline double GetInterestPaidAmount() const { return fInterestPaidInAdvance; }

			/**
			* Sets an interest paid (in case of roll) at end date.
			* @param interestAmount Interest amount.
			*/
			inline void SetInterestPaidAmount(double interestAmount) { fInterestPaidInAdvance=interestAmount; }

			/**
			* @return the settlement of the interest paid (in case of roll) at end date. 0 if no interest date.
			*/
			inline long GetInterestPaidSettlementDate() const { return fInterestPaidInAdvanceSettlementDate; }

			/**
			* Sets an interest paid (in case of roll) at end date.
			* @param date is the date of payment.
			*/
			inline void SetInterestPaidSettlementDate(long date) { fInterestPaidInAdvanceSettlementDate=date; }

			/**
			* @return the detailed calculation of floating interest.
			*/
			const _STL::vector<static_data::SSInterestExplanation> & GetDetailledInterest() const ;

			/**
			* Sets the detailed calculation of floating interest.
			* @param detail_interest is the detailed calculation of floating interest.
			*/
			void SetDetailledInterest(const _STL::vector<static_data::SSInterestExplanation> & detail_interest) ;

			/** Only available in detailed calculation.
			*/
			double GetFixingRate() const { return fFixingRate; }
			void SetFixingRate(double fixingRate) { fFixingRate = fixingRate; }
			long GetFixingDate() const { return fFixingDate; }
			void SetFixingDate(long fixingDate) { fFixingDate = fixingDate; }

			/** Update a detailed explanation.
			This is called by {@link CSRCashInterestExplanationList::DetailedExplanation} 
			for each element of the vector fInterestExplanation.
			@param day is the daily commission from day to day+1
			*/
			virtual void UpdateDetailed(const static_data::SSInterestExplanation &expl);

			/**
			* @return interest amount before any rounding.
			* @version 7.1.1
			*/
			inline double GetInterestUnroundedAmount() const { return fUnroundedInterest; }

			/**
			* Sets interest amount before any rounding.
			* @param amount is the amount to set.
			* @version 7.1.1
			*/
			inline void SetInterestUnroundedAmount(double amount) { fUnroundedInterest=amount; }

			/**
			 * @return unique id of agreement to which the contract and its explanation belongs to.
			 * @version 7.1.1
			 */
			inline long GetAgreementId() const { return fAgreementId; }

			/** 
			 * Set the agreement id.
			 * @param agreementId is the id to set.
			 * @version 7.1.1
			 */
			inline void SetAgreementId(long agreementId) { fAgreementId = agreementId; }

			/**
			 * Indicates if given line is not an explanation line, but rather a totals line.
			 * @version 7.1.1
			 */
			bool IsTotalsLine() const;

			/**
			 * Access to borrowing and funding interest
			 * Only applicable for CFDResult
			 @param borrowingInterest - out parameter, borrowing interest is returned
			 @param fundingInterest - out parameter, funding interest is returned
			 @return false if not available in which case borrowingInterest and fundingInterest are not modified
			*/
			bool GetBorrowingAndFundingInterest(double * borrowingInterest, double * fundingInterest) const;

		private:
			long fStartDate;
			long fEndDate;
			double fAmount;
			long fCurrency;
			long fInterestRate;
			double fSpread;
			double fInterest;
			double	fInterestPaidInAdvance;
			long	fInterestPaidInAdvanceSettlementDate;
			double fFixingRate;
			long fFixingDate;
			/** Details of how the interest was calculated. */
			_STL::vector<static_data::SSInterestExplanation> fInterestExplanation;
			double fUnroundedInterest;
			long fAgreementId;
		
		friend class CSRCashInterestExplanationList;
		};


		/**
		 * Represents cash interest explanation details which are available as part of collateral reporting.
		 * These details are usually associated with a cash pool or a per contract position involving cash.
		 *
		 * @version 5.2.7.
		 */
		class SOPHIS_COLLATERAL CSRCashInterestExplanationList : public _STL::vector<const CSRCashInterestExplanation*>
		{
		public:

			/**
			 * Constructor.
			 */
			CSRCashInterestExplanationList();
			
			/**
			* Copy Constructor.
			*/
			CSRCashInterestExplanationList(const CSRCashInterestExplanationList& src);

			/**
			 * Destructor.
			 * Invokes DeleteAll() to delete all the details including those in the list.
			 */
			virtual ~CSRCashInterestExplanationList();

			DECLARATION_CASH_INTEREST_EXPLANATION_LIST(CSRCashInterestExplanationList)

			/**
			 * Creates new cash interest explanation element.
			 */
			virtual CSRCashInterestExplanation* new_CSRCashInterestExplanation() const;

			/** FOR INTERNAL USE ONLY.
			 * Computes custom values for the result based on given reporting data.
			 * Deletes all existing values from the list.
			 * @param result Result to which the explanation corresponds to.
			 * @param reportingData Low-level reporting data.
			 * @param calcualtionDate Reporting date.
			 * @param lba Collateral Agreement.
			 */
			void Compute(const CSRCollateralResult &result,
				const FredReportingData &reportingData, long calculationDate, const CSRLBAgreement *lba);

			/**
			 * Deletes all the details including those in the list.
			 */
			virtual void DeleteAll();

			/**
			 * Adds an explanation record to the list.
			 * Can be overwritten by the clients if they want to use
			 * default computation but still add some values to the explanation.
			 */
			virtual void AddCashInterestExplanation(CSRCashInterestExplanation *expl);

			/** Provide a detailed explanation for floating interest.
			This is used when e detailed explanation in the guy is asked .
			The standard one is called and then this method is called to get more explanation.
			By default, create a new instance and then loop on the vector; for each element 
			having a vector of explanation empty, add the same one; otherwise loop on these explanation and
			call {@link CSRCashInterestExplanation::UpdateDetailed} before adding it.
			@return a new pointer which must be deleted.
			*/
			virtual CSRCashInterestExplanationList*	DetailedExplanation() const;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCashInterestExplanation_H_
