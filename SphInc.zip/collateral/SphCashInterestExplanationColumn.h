#ifndef _SphCashInterestExplanationColumn_H_
#define _SphCashInterestExplanationColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralEnums.h"

struct SSCellStyle;
union SSCellValue;

#define DECLARATION_CASH_INTEREST_EXPLANATION_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCashInterestExplanationColumn)
#define CONSTRUCTOR_CASH_INTEREST_EXPLANATION_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_CASH_INTEREST_EXPLANATION_COLUMN(derivedClass)
#define	INITIALISE_CASH_INTEREST_EXPLANATION_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace collateral {
		class CSRCashInterestExplanation;
		class CSRCollateralReportContext;

		/**
		* Interface to handle cash interest explanation columns in Collateral Management GUI.
		* To add a column, derive this class, using the macro DECLARATION_CASH_INTEREST_EXPLANATION_COLUMN in your header
		* and INITIALISE_CASH_INTEREST_EXPLANATION_COLUMN in UNIVERSAL_MAIN.
		*
		* @version 5.3
		*/
		class SOPHIS_COLLATERAL CSRCashInterestExplanationColumn
		{
		public:
			/** Destructor. */
			virtual ~CSRCashInterestExplanationColumn() {}

			/** 
			 * Returns the content to be displayed.
			 * @param ctx Report context from where GetCell() is being called.
			 * @param result Cash Interest explanation to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param ccy An output parameter, used to describe the currency id of the value.
			 */
			virtual void GetCell(const CSRCollateralReportContext &ctx, const CSRCashInterestExplanation &result, SSCellValue *value, SSCellStyle *style, long *ccy = 0) const = 0;

			/** 
			* Used to set the field on the result object using the string value.
			* @param ctx Report context.
			* @param result Cash Interest explanation to be set.
			* @param value The string representation of the value to be set.
			*/
			virtual void SetCell(const CSRCollateralReportContext &ctx, CSRCashInterestExplanation &result, const _STL::string& value) const;

			/** 
			* Returns the default cell size in pixels.
			*/
			short GetDefaultWidth() const;

			
			/** Some columns may or may not be available according the window explanations.
			This is known by calling that method. By default, it is true.
			@param type is the window type.
			@return true if available.
			*/
			virtual bool IsAvailable(eExplanationType type) const;



		public:
			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id)
			{
				fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRCashInterestExplanationColumn, const char*, tools::less_char_star> prototype;

			/** 
			* Access to the prototype singleton
			* To add a trigger to this singleton, use INITIALISE_CASH_INTEREST_EXPLANATION_COLUMN
			* @see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

			/**
			 * Fills cell value and style with given amount in given currency.
			 * Useful for GUI only.
			 * @param x Amount in given currency to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param ccy Currency of the amount.
			 * @version 5.3.2
			 */
			static void FillMoney(double x, SSCellValue *value, SSCellStyle *style, long ccy);

			/**
			 * Fills cell value and style with string representation of given currency.
			 * Useful for GUI only.
			 * @param ccy Currency to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @version 5.3.2
			 */
			static void FillCurrency(long ccy, SSCellValue *value, SSCellStyle *style);

			/**
			 * Fills cell value and style with given date.
			 * Useful for GUI only.
			 * @param date Date to be displayed.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @version 5.3.2
			 */
			static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

			/**
			 * Fills style for display of a double value.
			 * Useful for GUI only.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param ccy Currency of the double value.
			 * @param dec Number of decimals to be displayed.
			 * @version 5.3.2
			 */
			static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

			/**
			 * Fills cell value and style with given forex rate between two given currencies.
			 * Takes care of correct forex order etc.
			 * Useful for GUI only.
			 * @param fx Forex rate between fromCcy and toCcy.
			 * @param value An output parameter, used to return the value to be displayed.
			 * @param style An output parameter, used to describe the style and the data type.
			 * @param fromCcy From currency.
			 * @param toCcy To currency.
			 * @version 5.3.2
			 */
			static void FillForex(double fx, SSCellValue *value, SSCellStyle *style, long fromCcy, long toCcy);

		protected:
			long	fId;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
