/*
File:		SphCfdDialog.h

Contains:	Handle a dialog for purchasing of CFD.
Copyright:	� 1995-2006 Sophis.

*/


#pragma once

#ifndef _SphCfdDialog_H_
#define _SphCfdDialog_H_

#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphTransactionDialog.h"

struct TSaveData;
struct TDataMvts;
class TPETitre;
struct TAchatPE;

SPH_PROLOG
namespace sophis {
	namespace instrument	{
		class CSRContractForDifference;
	}
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace tools {
		class CSREventVector;
	}

	
	
	const int	kCfdDialogId = 638;

	

	namespace collateral {
		/** 
		@since 5.1.1
		*/

		/** Dialog to book a Contract for difference.
		Overload that class to modify this dialog using INITIALISE_DIALOG macro.
		@since 5.1.1
		*/
		class  SOPHIS_PORTFOLIO_GUI CSRCfdDialog : public sophis::gui::CSRTransactionDialog
		{
		public:
		
			/** Called before the transaction is created.
			@param transaction the transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateTransaction(portfolio::CSRTransaction& transaction, sophis::tools::CSREventVector &messages);

			/** Called before the transaction is created.
			@param transaction the transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnModifyTransaction(portfolio::CSRTransaction& transaction, sophis::tools::CSREventVector &messages);

			/** Called before the instrument is created.
			@param loan the instrument created. 
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateCfd(sophis::instrument::CSRContractForDifference& cfd, sophis::tools::CSREventVector &messages);

		protected:


		private:

			// for log purpose
			static const char * __CLASS__;
		};
	}
}

SPH_EPILOG
#endif	//_SphCfdDialog_H_
