/*
File:		SphCollAgreeColumn.h

Contains:	Class for the handling of Collateral Agreement columns

Copyright:	� 2006 Sophis.
*/
#pragma once

#ifndef _SphCollAgreeColumn_H_
#define _SphCollAgreeColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralAgreement.h"

struct SSCellStyle;
union SSCellValue;

#define DECLARATION_CA_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollAgreeColumn)
#define	INITIALISE_CA_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis	{
	namespace collateral {


		/** Interface to handle columns in Collateral Agreement Management blotter.
		To add a column, derive this class, using the macro DECLARATION_CA_COLUMN in your header
		and INITIALISE_CA_COLUMN in UNIVERSAL_MAIN.
		The main methods providing the values to display must have no MFC code.
		For example, you cannot show a dialog using CSRFitDialog::Message.
		This can produce error MFC messages or alter the window itself.
		Also note that use of the class {@link CSRSqlQuery} method to write certain
		queries. In the verbose mode, errors generate a dialog. It is better to disable
		the verbose mode using {@link CSRSqlQuery::SetVerbose} and to deal with the
		error code yourself.
		@see CSRPortfolioColumn
		@since 5.3.5
		*/
		class SOPHIS_COLLATERAL CSRCollAgreeColumn
		{
		public:
			/** Destructor. */
			virtual ~CSRCollAgreeColumn() {}

			/** Main method to display the content of OTC message.
			@param data contains accounting posting information and transactions cache.
			@param value is an output parameter, used to return the value to be displayed.
			@param style is an output parameter, used to describe the style and the data type.
			*/
			virtual	void	GetCell(
				const CollateralAgreement & data,
				SSCellValue				* value,
				SSCellStyle				* style) const = 0;

			/** Define the default size in pixels.
			*/
			virtual short	GetDefaultWidth() const;


			/** Icon id to display when grouping by that column.
			@return a short id corresponding to a resource bmp with a shift of 1000.
			*/
			virtual short GetGroupIcon() const;


			/** Get the id .
			The value is created at the end of the initialise because it must
			be unique according to the table COLUMN_NAME.
			*/
			int GetId() const;

			/** Set the id.
			Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id);

			/** Typedef for the prototype : the key is a const char *.
			*/
			typedef tools::CSRPrototypeWithId<CSRCollAgreeColumn, const char *, tools::less_char_star> prototype;
			/** Access to the prototype singleton
			To add a trigger to this singleton, use INITIALISE_INSTRUMENT_FACTORY
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

			/** Internal. */
			static void RefreshPrototype();

		protected:
			long	fId;
		};
	}
}
SPH_EPILOG
#endif
