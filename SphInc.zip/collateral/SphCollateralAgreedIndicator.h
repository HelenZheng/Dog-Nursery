#pragma once
#ifndef __SphCollateralAgreedIndicator_H__
#define __SphCollateralAgreedIndicator_H__

#include "SphInc/collateral/SphCollateralIndicatorAPI.h"
#include __STL_INCLUDE_PATH(list)
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSREventVector;
	}
	namespace collateral {

/**
 * Structure holding an agreed result.
 * @version 6.2
 */
struct SCollateralAgreedIndicatorValue
{
	/** Default constructor. */
	SCollateralAgreedIndicatorValue()
		: fValue(.0)		
		, fCurrency(0)
		, fDate(0)
		, fCounterpartyValue(.0)
	{
	}
	/** Constructor with specified values. */
	SCollateralAgreedIndicatorValue(double value, long currency, long date, double counterpartyValue)
		: fValue(value)		
		, fCurrency(currency)
		, fDate(date)
		, fCounterpartyValue(counterpartyValue)
	{
	}
	/** Agreed value in given currency. */
	double fValue;
	/** Currency of the agreed value. */
	long fCurrency;
	/** Date of the agreed value. */
	long fDate;
	/** Counterparty Value */
	double fCounterpartyValue;
};

/**
 * Array of agreed collateral indicator valuations.
 * @version 6.2
 */
typedef _STL::vector<SCollateralAgreedIndicatorValue> SCollateralAgreedIndicatorValueList;

/**
 * Collateral Indicator agreed with counterparty.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralAgreedIndicator : public virtual CSRCollateralIndicator
{
public:
	/// See {@link CSRCollateralIndicator::Clone}
	virtual CSRCollateralIndicator* Clone() const;

	/// See {@link CSRCollateralIndicator::GetCollateralIndicator}
	virtual double GetCollateralIndicator(const sophis::portfolio::CSRPosition* pos, const CSRLBAgreement* lba,
		const CSRCollateralIndicatorForex* collateralForex = 0,
		SCollateralIndicatorDetails* detailedResults = 0,
		long date = 0) const;

	/**
	 * Fetches agreed collateral indicator value.
	 * @param agreedValue Where the agreed value is written.
	 * @param positionId Position identifier.
	 * @param date Date for which agreed value is sought.
	 * @return false if no agreed value is present; true if agreed value exists.
	 */
	static bool GetAgreedIndicatorValue(SCollateralAgreedIndicatorValue& agreedValue,
		sophis::portfolio::PositionIdent positionId, long date);

	/**
	 * Fetches agreed collateral indicator values for the specified period.
	 * @param agreedValueList List of agreed values fetched.
	 * @param positionId Position identifier.
	 * @param endDate End period (optional).
	 * @return false if no agreed value is present; true if agreed value exists.
	 */
	static bool GetAgreedIndicatorValueList(SCollateralAgreedIndicatorValueList& agreedValueList,
		sophis::portfolio::PositionIdent positionId);

	/**
	 * Sets agreed collateral indicator value.
	 * @param agreedValue Value to be set.
	 * @param positionId Position identifier.
	 * @param commit Commit and clear cache.
	 */
	static void SetAgreedIndicatorValue(const SCollateralAgreedIndicatorValue& agreedValue,
		sophis::portfolio::PositionIdent positionId, bool commit);

	/**
	 * Sets agreed collateral indicator value (the event vector version).
	 * @param agreedValue Value to be set.
	 * @param positionId Position identifier.
	 * @param messages The event vector which will record all the messages to send after committing.
	 */
	static void SetAgreedIndicatorValue(const SCollateralAgreedIndicatorValue& agreedValue,
		sophis::portfolio::PositionIdent positionId, sophis::tools::CSREventVector& messages);

	/**
	 * Sets agreed collateral indicator values.
	 * @param agreedValueList List of agreed values to be saved.
	 * @param positionId Position identifier.
	 * @param commit Commit and clear cache.
	 */
	static void SetAgreedIndicatorValueList(const SCollateralAgreedIndicatorValueList& agreedValueList,
		sophis::portfolio::PositionIdent positionId, bool commit);

	/**
	 * Sets agreed collateral indicator values (the event vector version).
	 * @param agreedValueList List of agreed values to be saved.
	 * @param positionId Position identifier.
	 * @param messages The event vector which will record all the messages to send after committing.
	 */
	static void SetAgreedIndicatorValueList(const SCollateralAgreedIndicatorValueList& agreedValueList,
		sophis::portfolio::PositionIdent positionId, sophis::tools::CSREventVector& messages);

private:
	static const char *__CLASS__;
};
	} // collateral
} // sophis
SPH_EPILOG
#endif // __SphCollateralAgreedIndicator_H__
