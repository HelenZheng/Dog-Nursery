#ifndef _SPH_COLLATERAL_AGREEMENT_H_
#define _SPH_COLLATERAL_AGREEMENT_H_

#include "SphInc/SphMacros.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis
{
	namespace collateral
	{
		/**
		 * Information about collateral agreement pulled from agreement cache.
		 * This data is used for the agreement blotter display.
		 * @version 5.3.6
		 * @version 7.1.2
		 */
		struct SOPHIS_COLLATERAL CollateralAgreement
		{
		public:			
			long ident; // agreement id
			long cptyID;		// CounterParty IDENT, eg. CTPY_ID
			long entyID;		// Entity IDENT, eg. ENTITY_ID
			long perID;		// Perimeter ID, eg. PERIMETER_ID
			_STL::string name;
			_STL::string model;
			long beginDate;
			long endDate;
			_STL::string externalRef; 

			_STL::string cptyName;
			_STL::string entyName;
			_STL::string perName;

			_STL::string status;
			int isValid;

			/** Obtain list of agreements, all or of specific type.
			 * @version 7.1.2 */
			static void GetCollateralAgreementList(_STL::vector<CollateralAgreement>& agreementList,
				sophis::collateral::eCacheLbaType lbaType = eCacheLbaTypeAny, bool strictType = false);
		};
	}
}
SPH_EPILOG
#endif