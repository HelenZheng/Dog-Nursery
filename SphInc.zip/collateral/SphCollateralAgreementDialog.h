#pragma once
#ifndef _SphCollateralAgreementDialog_H_
#define _SphCollateralAgreementDialog_H_

#ifndef GCC_XML

#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDatabaseAuditDialog.h"
#include "SphInc/gui/SphTabButton.h"
#include "SphInc/gui/SphEditList.h"
#include "SphInc/tools/SphValidation.h"
#include "SphInc/collateral/SphLBAgreement.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRLBAgreementDialog;

/**
 * Tab button page for Collateral Agreement tabs dialog.
 * @version 5.0
 */
class SOPHIS_COLLATERAL CSRLBAgreementTabs : public gui::CSRTabButton
{
public:
	CSRLBAgreementTabs (_STL::string& model,
		_STL::vector<gui::CSRElement*>& queryKey,
		gui::CSRFitDialog* dialog, 
		int dialogElementID,
		long compoIdent,
		bool auditMode,
		backoffice_kernel::eSavingMode mode);
	virtual gui::CSRFitDialog* GetPageDlg(short page);
	virtual	void Open();
	void SetIdentAudit(long ident);
	bool GetModified() const; //for this method to be invoked need CSRDialogLBAgreementTabs::GetTab() return CSRLBAgreementTabs*

private:
	_STL::vector<gui::CSRElement*> fQueryKey;
	long fIdentAudit;
	bool fAuditMode;
	backoffice_kernel::eSavingMode fMode;
	_STL::string fModel;

	bool SetTabRights();
};

/**
 * The dialog representing Collateral Agreement tabs.
 * @version 5.0
 */
class SOPHIS_COLLATERAL CSRDialogLBAgreementTabs : public gui::CSRFitDialog 
{
public:

	static CSRDialogLBAgreementTabs* CreateTabsDialogLBA(_STL::string& model, _STL::vector<gui::CSRElement*>& queryKey,
		long compoIdent = 0L, bool auditMode = false, backoffice_kernel::eSavingMode mode = backoffice_kernel::smApi);
	CSRDialogLBAgreementTabs (_STL::string& model, _STL::vector<gui::CSRElement*>& queryKey,
		long compoIdent = 0L, bool auditMode = false, backoffice_kernel::eSavingMode mode = backoffice_kernel::smApi);
	~CSRDialogLBAgreementTabs ();

	static _STL::string winTitle;

	virtual	void Open();
	virtual Boolean Close();	
	virtual void TabChanged(int tabFrom, int tabTo);

	__forceinline long GetIdentAudit() 
	{ 
		return fIdentAudit; 
	}

	CSRLBAgreementTabs* GetTab() 
	{ 
		return (CSRLBAgreementTabs*) fElementList[0]; 
	}

	void SetIdentAudit(long ident) 
	{
		fIdentAudit = ident;
		GetTab()->SetIdentAudit(ident);
	}

	void SetAPI(sophis::collateral::CSRLBAgreementDialog* api) { fAPI = api; }
	sophis::collateral::CSRLBAgreementDialog* GetAPI() { return fAPI; }

	void SetModel(_STL::string model) { fModel=model; }
	const _STL::string& GetModel() const { return fModel; }

protected:
	long fIdentAudit;
	bool fAuditMode;

private:
	virtual void SaveAllTabs(tools::CSREventVector &ev, backoffice_kernel::eSavingMode mode, bool isNew)
		throw (sophis::collateral::CSRCollateralException);
	virtual void DeleteAllTabs(tools::CSREventVector &ev, backoffice_kernel::eSavingMode mode)
		throw (sophis::collateral::CSRCollateralException);

	sophis::collateral::CSRLBAgreementDialog *fAPI;
	_STL::string fModel;

	friend sophis::collateral::CSRLBAgreementDialog;
};

/**
 * Base class for tab of the Collateral Agreement dialog.
 * @version 5.0
 */
class SOPHIS_COLLATERAL CLBADialogTab : public sophis::gui::CSRDatabaseAuditDialog 
{
	int fLastFocusId;	// -1 means nothing was under focus yet

public:
	CLBADialogTab (_STL::vector<gui::CSRElement*>& queryKey, 
		gui::CSRFitDialog* dlg, long compoIdent, bool auditMode, char *table);
	virtual ~CLBADialogTab ();

	virtual	void	Open(void);
	virtual bool	CreateNextAuditCode( long *nextCode, char* compo_table, backoffice_kernel::eSavingMode *mode );
	virtual long	CreateIdentifier();

	bool	ReadData();
	bool	ReadData(long compoIdent);
	virtual	bool	SaveData();			// true is OK, false is NOT_OK, overload this method to do tab's specific savings	
	virtual	bool	DeleteData();			// true is OK, false is NOT_OK
	bool	GetAuditMode() { return fDoAudit; }

	void	CheckLinesEditList();
	virtual bool	HasWriteAcces() {return !fIsReadOnly;}	

	// returns if record for this given tab exists in the database or not
	// true = need to create; false = record exists, need to update.
	virtual	bool	IsNew();

	// used by buttons (delete, up, down)
	int GetLastFocusId() const { return fLastFocusId; }
	void SetLastFocusId(int id) { fLastFocusId = id; }

	// This function is useful to get an element in one of the other dialogs.
	// This is sometimes necessary, for example the value of the Ref Currency in the agreement is
	// important to some other fields in the agreement.
	virtual gui::CSRElement* GetElementInOtherTab(int tab, int field);
	bool fIsReadOnly;

protected:
	long fCompoIdent;
	CSRDialogLBAgreementTabs* fParentTab;

	virtual void SetTabRights()
	{
		// 2. Check for Write/Read access
		gui::CSREditList* tmp = NULL;

		for (int i = 0; i < this->GetElementCount(); i++)
		{
			if ( (tmp = dynamic_cast<gui::CSREditList*>(fElementList[i])) )
				continue;
			else
				this->DisableElement(fElementList[i]->GetRelativeId());	
		}
	}

private:

	virtual CLBADialogTab* CreateNewDialogTab(gui::CSRFitDialog* dlg, long compoIdent, bool auditMode, backoffice_kernel::eSavingMode mode) = 0;
};

/**
 * Utility class to register custom Collateral Agreement tab.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRCollateralAgreementCustomTab
{
public:
	/** To set resIdTitle field of the tab page. */
	virtual unsigned int GetCustomTabResIdTitle() const = 0;
	/** To set dialog field of the tab page. */
	virtual CLBADialogTab* new_CustomTabDialog(_STL::vector<gui::CSRElement*>& queryKey, gui::CSRFitDialog* dlg, long compoIdent, bool auditMode, backoffice_kernel::eSavingMode mode) const = 0;
	/** Object for storing data in the cache which must be constructed from the agreement dialog. */
	virtual CSRCollateralAgreementCustomData* new_CustomData() const = 0;
	/** Fill cache data from the dialog data. */
	virtual bool FillDataFromDialog(CSRCollateralAgreementCustomData& data, const sophis::gui::CSRDatabaseDialog& tab) const = 0;
	/** Fill the dialog based on the given cache data. */
	virtual bool FillDialogFromData(sophis::gui::CSRDatabaseDialog& tab, const CSRCollateralAgreementCustomData& data) const = 0;

	/** Returns custom tab, if available, for the given model. */
	static const CSRCollateralAgreementCustomTab* GetCustomTab(const _STL::string& model);
	/** Returns custom tab, if available, for the given existing agreement. Obtains a model and calls GetCustomTab(model). */
	static const CSRCollateralAgreementCustomTab* GetCustomTab(long cpty, long entity, long convention);
	/** Register custom tab implementation for specific model. */
	static void SetCustomTab(const _STL::string& model, const CSRCollateralAgreementCustomTab* customTab);

	/// Bridge to CSRLBAgreementDialog
	static sophis::gui::CSRFitDialog* GetDialog(const CSRLBAgreementDialog* lbaDialog);
	static sophis::backoffice_kernel::eSavingMode GetMode(const CSRLBAgreementDialog* lbaDialog);
	static sophis::gui::CSRDatabaseDialog* GetTab(const CSRLBAgreementDialog* lbaDialog, eLBAgreementTabs type);
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // GCC_XML
#endif // _SphCollateralAgreementDialog_H_
