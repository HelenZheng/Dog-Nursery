#pragma once
#ifndef __SphCollateralAgreementPositionExtraction_H__
#define __SphCollateralAgreementPositionExtraction_H__

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRPosition;
	}
	namespace collateral {

class CSRLBAgreement;
class CSRCollateralLimitResult;

/**
 * A key is a data on which positions are filtered.
 * Default key means everything is matched.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralAgreementPositionExtractionKey
{
public:
	/** Constructor. */
	CSRCollateralAgreementPositionExtractionKey();

	/** Destructor. */
	virtual ~CSRCollateralAgreementPositionExtractionKey();

	/** Clone interface. */
	virtual CSRCollateralAgreementPositionExtractionKey* Clone() const;

	/** Part of clone interface. */
	virtual void Initialise(const CSRCollateralAgreementPositionExtractionKey& key);

	/**
	 * Determines if position matches the key or not.
	 * Must be implemented in derived classes.
	 * @return true if position matches the key, false otherwise.
	 */
	virtual bool Match(const portfolio::CSRPosition& position) const { return true; }
};

/// Definition of list of keys
typedef _STL::vector<const CSRCollateralAgreementPositionExtractionKey*> CollateralAgreementPositionExtractionKeyList;

/// Result for particular key, a pair of {position id, limit result corresponding to it}
typedef _STL::map<long, const CSRCollateralLimitResult*> CollateralAgreementPositionExtractionResult;

/// Result vector, corresponds to input vector
typedef _STL::vector<CollateralAgreementPositionExtractionResult> CollateralAgreementPositionExtractionResultList;

/// INTERNAL
struct SLimitsCalculationResults;

/**
 * Utility class to help determine positions belonging to a given collateral agreement.
 * Note that the result structures are valid as long as the extraction object is valid.
 * If longer access to results is required, they must be cloned.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralAgreementPositionExtraction
{
public:
	/** Constructor. */
	CSRCollateralAgreementPositionExtraction(long cpty, long entity, long convention);

	/** Destructor. */
	~CSRCollateralAgreementPositionExtraction();

	/** Obtain the list of matching positions. */
	void GetMatchingPositionList(long date,
		const CollateralAgreementPositionExtractionKeyList& keyList,
		CollateralAgreementPositionExtractionResultList& resultList);

	inline long GetCpty() const { return fCpty; }
	inline long GetEntity() const { return fEntity; }
	inline long GetConvention() const { return fConvention; }

private:
	long fCpty;
	long fEntity;
	long fConvention;

	/// INTERNAL
	SLimitsCalculationResults* fLimitsCalculationResults;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // __SphCollateralAgreementPositionExtraction_H__
