/*
 	File:	SphCollateralEligibilityCondition.h

 	Contains:	Abstract base class which can be used to extend popup menu of Condition1, 
				Condition2, Condition3 columns of Allotment Rules on the Collateral and Principal t
				abs of Collateral Agreement Dialogto add client specific funcionality.

 	Copyright:	� 1995-2013 Sophis.

*/

#ifndef _SphCollateralEligibilityCondition_H_
#define _SphCollateralEligibilityCondition_H_
#pragma once

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

namespace sophis {	
	namespace collateral {
		class CSRLBAgreement;

		/*
		 *	Macro to be used instead of the Clone() method in the clients derived classes.
		 *	Prototype framework will be responsible to instantiate clients objects.
		 *	
		 *	@param derivedClass is the name of the client derived class.
		 */
		#define DECLARATION_COLLATERAL_RULES_CONDITION(derivedClass)	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralEligibilityCondition)
		/*
		 *	Macro to be placed in the clients <main>.cpp to register derived client classes
		 *	with the prototype framework.
		 *	
		 *	@param derivedClass is the name of the client derived class.
		 *	@param name is the unique string to be used as a key to indentify registrated class in the framework.
		 *	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
		 *	Collateral and Principal tabs.
		 *	Clients have to use this name in GetInstance() static method to instantiate the clients class objects.
		 */
		#define	INITIALISE_COLLATERAL_RULES_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

		/** enum {Principal or Collateral} 
		to differentiate between Principal and Collateral stocks tabs
		*/
		enum eCollateralStockType
		{		
			stCollateralStocks = 0, 
			stPrincipalStocks,
			stPrincipalUnderlyingStocks
		};

		/**		
		Allotment Rules conditions prototype
		@version 7.2
		*/
		class SOPHIS_FIT CSRCollateralEligibilityCondition 
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRCollateralEligibilityCondition() {}

			/** Method is called for Condition1, Condition2, Condition3 columns of collateral rules.
			@lba - Collateral Agreement
			@ccy  - Currency
			@eCollStockStype - Differentiates between the Collateral Stocks and Principal Stocks tabs
			@qty - 
			@lineIndex
			*/
			virtual bool GetCurrencyCondition(const CSRLBAgreement *lba, long ccy, eCollateralStockType eCollStockStype, double qty, long lineIndex) const = 0;

			/** Method is called for Condition1, Condition2, Condition3 columns of collateral rules.
			@lba - Collateral Agreement
			@instruIdent - Instrument ID
			@eCollStockStype - Differentiates between the Collateral Stocks and Principal Stocks tabs
			@date -
			@lineIndex
			*/
			virtual bool GetInstrumentCondition(const CSRLBAgreement *lba, long instruIdent, eCollateralStockType eCollStockStype, double qty, long date, long lineIndex) const = 0;

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro INITIALISE_COLLATERAL_RULES_CONDITION.
			@see tools::CSRPrototype
			*/
			virtual CSRCollateralEligibilityCondition* Clone() const = 0;

			/** typedef for the prototype : the key is a string
			*/
			typedef sophis::tools::CSRPrototype<CSRCollateralEligibilityCondition, 
				const char *, 
				sophis::tools::less_char_star> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_COLLATERAL_RULES_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};
	} 
} 

#endif //_SphCollateralEligibilityCondition_H_

