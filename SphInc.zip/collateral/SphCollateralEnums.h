#ifndef _SphCollateralEnums_H_
#define _SphCollateralEnums_H_

#include "SphInc/backoffice_otc/SphBOEnums.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

		/** Type of window for explanation.
		@see CSR
		*/
		enum eExplanationType
		{
			/** No explanation. */
			etNone = -1,
			/** Standard explanation. */
			etStandard = 0,
			/** Detailed (daily) explanation. */
			etDetailed = 1
		};
		/**
		 * Defines a hierarchy type for the stock loan reporting result.
		 * It starts from 100 so it can be used in conjunction with CSRLbaType::eLbaType.
		 * {@link CSRLbaType::eLbaType}
		 *
		 * @version 5.3.
		 */
		enum eStockLoanReportingResultType
		{
			cmTypeGlobal = 100,			// level 0
			cmTypeContractGlobal,		// level 1
			cmTypeContractGroupSecVsCash,	// level 2
			cmTypeContractGroupSecVsSec,	// level 2
			cmTypeContractGroupCashVsSec,	// level 2
			cmTypeNoCollateralGlobal,	// level 1
			cmTypeNoCollateralGroupSec, 	// level 2
			cmTypeNoCollateralGroupCash,	// level 2
			cmTypeCashPoolGlobal,		// level 1
			cmTypeCashPoolGroup,		// level 2
			cmTypeSecPoolGlobal,		// level 1
			cmTypeSecPoolGroup,			// level 2
			cmTypeSecPoolCash,			// level 2
			cmTypeSecPoolSec,			// level 2
			cmTypeSecPoolMCGroup,		// level 2 (TriParty)
			cmTypeSecPoolMarginCall,	// level 3 (TriParty)
			/** @version 5.3.6.5, to support Cash vs Dedicated Security Pool */
			cmTypeSecPoolCashContract,
			/** @version 7.1, to support Exchange Repo */
			cmTypeExchangeRepoGlobal,
			cmTypeExchangeRepoDeal,
			cmTypeSecPoolStockContract, // to support stock vs Dedicated Security Pool
		};

		/** List of haircut types for different types of collateral.
		@since 5.2.5
		*/
		enum eHairCutType	{
			hcInitialDeposit,
			hcMarginCall,
			hcPool
		};

		/**
		 * The enum to indicate the source of the hedging or haircut of the actual value used.
		 * In certain cases, when invoke methods like CSRLoanAndRepo::GetHedgingInProduct(lba, ...)
		 * you do not know where the value actually comes from.
		 * @since 5.2.5
		 */
		enum eHedgingHaircutSource {
			/** No hedging/haircut value present, a default (either 0 or 100) is returned.
			 */
			hhsDefault = 0,
			/** Hedging/haircut value pulled from the stock loan instrument.
			 */
			hhsStockLoan = 1,
			/** Hedging/haircut value pulled from the collateral agreement.
			 */
			hhsCollateralAgreement = 2,
		};
 		enum eInverseHaircut
		{
			ihINVERSE_DEFAULT = 0,
			ihINVERSE_NONE,
			ihINVERSE_HAIRCUT,
			ihINVERSE_HEDGING,
			ihINVERSE_HAIRCUT_HEDGING,
			ihLAST,
		};
		/**
		 * The enum to specify various parameters of Collateral Indicator Selector and Collateral Indicator API.
		 * @since 5.2.7
		 */
		enum eCollateralIndicatorEnvironment {
			cieIndicatorNameLength = 40,
			cieIndicatorConditionLength = 40,
			cieIndicatorCommentsLength = 100,
			cieIndicatorRuleNameLength = 40,
			cieIndicatorAuditDateTime = AUDIT_DATE_TIME,
		};

		/**
		 * The flags to specify how Stock Loan or Repo vs No Collateral contracts are taken
		 * into account during Limits Calculation and Stock Loan and Repo Mgmt.
		 * @since 5.3.5
		 */
		enum eStockLoanNoCollateralRiskExpo {
			slcreNone = 0x00, 
			slcreSL = 0x01,
			slcreRepo = 0x02,
		};

		/**
		 * Defines various supported types of Free Cash Movement
		 * @version 5.3.6
		 */
		enum eFreeCashMovementType
		{
			/** Cash impact from normal (non-treasury) deal. */
			eFreeCashMovementNone = 0,

			/** Cash adjustment, like initial balance or due to mistakes. */
			eFreeCashMovementCreditDebit,

			/** Cash transfer between two accounts. */
			eFreeCashMovementTransfer,

			/** Internal. Specifies number of supported types. */
			eFreeCashMovementLast,
		};

		/** 
		 * Lending opportunity indicators.
		 * @see {@link CSRCollateralSchedulerResult::GetIndicator}.
		 * @version 5.3.6
		 */
		enum eLOIndicators
		{
			eloiMarketSpread = 0,
			eloiMarketRebate,
			eloiMaturityDate,
			eloiDaysToMaturity,
			eloiExCouponDate,
			eloiNextCouponPay,
			eloiRecordDate,
			eloiCouponValue,
		};

		/**
		 * Misc constants.
		 */
		enum eMiscCollateralConstants
		{
			/** 
			 * Changed it to 31 because when it is used in derived CSRGlobalMarginCallList LineData::DataToDisplay structure,
			 * the memory allocated should be 4-bytes aligned or otherwise we have problems either in display or sorting.
			 */
			GLOBAL_MC_FIELD_LENGTH = 31
		};

		/**
		* To inquire about particular types of collateral agreement.
		* @version 5.3.3
		*/
		enum eCacheLbaType
		{
			eCacheLbaTypeAny = 0,
			eCacheLbaTypeCollateral,
			eCacheLbaTypeStockLoan,
			eCacheLbaTypeCFD,
			eCacheLbaTypeBondRepo,
			eCacheLbaTypeBondLoan
		};

		/**
		 * Type of thirds belonging to the agreement.
		 * It is used to create multi tiers agreement hierarchy.
		 * @version 7.1
		 */
		enum eAgreementThirdsType
		{
			/** None, default. */
			eThirdsTypeNone = 0,
			/** Sub agreements list is controlled by the user. */
			eThirdsTypeManual = 1,
			/** Sub agreements are handled automatically by the system. */
			eThirdsTypeAutomatic = 2,
		};

		/**
		* Type of tri_parties of the agreement.
		* It is used to identify exchange repo or original tri-party usage.
		* @version 7.1
		*/
		enum eAgreementTriPartyType
		{
			/** None, default. */
			eTriPartyNone = 0,
			/** Tri-Party as before. */
			eTriParty = 1,
			/** For new exchange repo type agreement. */
			eExchangeRepo = 2,
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralEnums_H_
