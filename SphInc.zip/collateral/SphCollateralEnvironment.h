#ifndef _ICollateral_Environment_H_
#define _ICollateral_Environment_H_

#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphCustomMenu.h"

struct TLib;

SPH_PROLOG
namespace sophis 
{	
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		struct SSReportingTrade;
		class CSRTransaction;
	}
	namespace collateral 
	{
		/**
		 * Interface for dealing with collateral convention.
		 */
		class SOPHIS_FIT ISRCollateralEnvironment 
		{
			public:
				static ISRCollateralEnvironment * Instance();

				/** Call this to get the CDS Name Ident of specified Convention (Perimeter).
				@param ident is the ID of Convention (Perimeter) as ID column from BO_PE_PERIMETER_DEF table.
				@return the CDS Name Id (CDS_NAME_IDENT column from BO_PE_PERIMETER_DEF table) 
				or -1 if not found or internal error.
				* @version 5.3.1
				*/
				virtual long GetPerimeterCDSNameIdent	(long ident) = 0;

				/**	Checks if there is a convention (perimeter) with particular id.
				 * @param ident is the convention (perimeter) id which corresponds 
				 * to ID column from BO_PE_PERIMETER_DEF table.
				 * @return true if convention exists, false otherwise.
				 * @version 5.3.1
				 */
				virtual bool IsPerimeterAvailable(long ident) = 0;

				/**	Returns name of the specified convention (perimeter).
				 * @param ident is the convention (perimeter) id which corresponds 
				 * to ID column from BO_PE_PERIMETER_DEF table.
				 * @return the name as pointer to c-string (NAME column of the same table).
				 * @version 5.3.4
				 */
				virtual char* GetPerimeterName(long ident) = 0;

				/**	Returns comments description of the specified convention (perimeter).
				 * @param ident is the convention (perimeter) id which corresponds 
				 * to ID column from BO_PE_PERIMETER_DEF table.
				 * @return the comment as pointer to c-string (COMMENTS column of the same table).
				 * @version 5.3.4
				 */
				virtual char* GetPerimeterComment(long ident) = 0;

				/**	Returns name of the specified convention (perimeter).
				 * @param ident is the convention (perimeter) id which corresponds 
				 * to ID column from BO_PE_PERIMETER_DEF table.
				 * @return the external reference as pointer to c-string (EXTERNAL_REF column of the same table).
				 * @version 5.3.4
				 */
				virtual char* GetPerimeterExtRef(long ident) = 0;

				/** Returns Portfolio Ident of specified convention (perimeter).
				 * @param ident is the convention (perimeter) id which corresponds 
				 * to ID column from BO_PE_PERIMETER_DEF table.
				 * @return the portfolio Id (PORTFOLIO column from BO_PE_PERIMETER_DEF table).
				 * @version 5.3.4
				 */
				virtual long GetPerimeterFolio(long ident) = 0;

				/** Returns convention (perimeter) ident specified by given name.
				 * @param name is the convention (perimeter) name.
				 * @return the ident of the corresponding convention (perimeter), or -1 if nothing is found.	
				 * @version 5.3.4
				 */
				virtual long FindPerimeterByName(const char *name) = 0;

				/** Returns the first matching convention (perimeter) for an instrument.
				 * The search is done through the convention selector.
				 * This method is to work with convention selector, the return result
				 * is NOT the one returned by CSRInstrument::GetPerimeter().
				 * @param instr pointer to the instrument.
				 * @return the first matching perimeter ident if found, -1 otherwise.
				 * @version 5.3.4
				 */
				virtual long FindPerimeterByInstrument(const instrument::CSRInstrument *instr) = 0;

				/** Returns the first matching convention (perimeter) for an instrument.
				 * The search is done through the convention selector.
				 * This method is to work with convention selector, the return result
				 * is NOT the one returned by CSRInstrument::GetPerimeter().
				 * @param sicovam the instrument id.
				 * @return the first matching perimeter ident if found, -1 otherwise.
				 * @version 5.3.4
				 */
				virtual long FindPerimeterByInstrument(long sicovam) = 0;

				/** Returns the first matching convention (perimeter) for an instrument.
				 * The search is done through the convention selector.
				 * The full instrument is not loaded unless required to.
				 * @version 6.3.2
				 */
				virtual long FindPerimeterByInstrument(TLib*& ph) = 0;

				/** Returns the first matching convention (perimeter) for an instrument
				 * and given counterparty and entity.
				 * The search is done through the convention group selector. If nothing is specified
				 * in the convention group selector, the convention (perimeter) of the instrument is returned,
				 * that is CSRInstrument::GetPerimeter().
				 * @param instr pointer to the instrument.
				 * @param cpty counterparty.
				 * @param entity entity.
				 * @return convention id as found in the convention group selector, or instrument convention (perimeter).
				 * @version 5.3.4
				 */
				virtual long FindPerimeterGroup(const instrument::CSRInstrument *instr, long cpty, long entity) = 0;

				/**
				 * Returns the matching convention (perimeter) for the given trade.
				 * The reportDate parameter is optional, default is gDate.position.
				 * The reportDate parameter is used to differentiate between FX Spot and FX Forward,
				 * see isForwardDeal() for more details.
				 * The search is done through the convention group selector.
				 * The full instrument is not loaded unless required to.
				 * @version 6.3.2
				 */
				virtual long FindPerimeterGroup(portfolio::SSReportingTrade* mvt, long reportDate = 0) = 0;

				/**
				 * Returns the matching convention (perimeter) for the given trade.
				 * Instrument is optional, default is from trans object.
				 * The search is done through the convention group selector.
				 * @version 6.3.2
				 */
				virtual long FindPerimeterGroup(const portfolio::CSRTransaction* trans, const instrument::CSRInstrument *instr = 0) = 0;

				/**
				 * Returns the first matching convention (perimeter) for an instrument
				 * and given counterparty and entity.
				 * The full instrument is not loaded unless required to.
				 * @version 6.3.2
				 */
				virtual long FindPerimeterGroup(TLib*& ph, long cpty, long entity) = 0;

				/** Creates new menu with list of collateral conventions.
				 * @version 5.3.6
				 */
				gui::CSRCustomMenu* new_ConventionMenu(gui::CSRFitDialog * dialog,
					int 				ERId_Menu,
					const char *		columnName = kUndefinedField,
					bool				addStarToMenu	= false,
					bool				isResetPossible = false);

				/** Creates new menu with list of collateral conventions.
				 * @version 5.3.6
				 */
				gui::CSRCustomMenu* new_ConventionMenu(gui::CSREditList * theList,
					int 				CNb_Menu,
					const char *		columnName = kUndefinedField,
					bool				addStarToMenu	= false,
					bool				isResetPossible = false);
		};
	}
}
SPH_EPILOG
#endif	