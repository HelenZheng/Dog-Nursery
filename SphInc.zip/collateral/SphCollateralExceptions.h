#ifndef _CSRCollateral_Exceptions_H_
#define _CSRCollateral_Exceptions_H_

#include "SphInc/tools/SphValidation.h"
#include "SphTools/SphExceptions.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace collateral {
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_COLLATERAL CSRCollateralException : public sophisTools::base::GeneralException 
		{
			_STL::string fErrMsg;

		public:
			CSRCollateralException(const char *errMsg) 
				: GeneralException(errMsg)
			{
				fErrMsg = errMsg;
			}

			const char* GetErrorMessage() const 
			{ 
				return fErrMsg.c_str(); 
			}
		};
		SPH_END_NOWARN_EXPORT
	}
}
SPH_EPILOG
#endif // _CSRCollateral_Exceptions_H_