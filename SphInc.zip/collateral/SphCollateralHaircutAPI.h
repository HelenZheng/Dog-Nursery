#ifndef __SphCollateralHaircutAPI_H__
#define __SphCollateralHaircutAPI_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralEnums.h"

namespace sophis {

	namespace collateral {

		class CSRLBAgreement;

/**
 * Interface for building Haircut Calculation function.
 * @version 7.1
 */
class SOPHIS_FIT CSRCollateralHaircut
{
public:

	/** Trivial destructor.
	*/
	virtual ~CSRCollateralHaircut() {}

	/** Clone method needed by the prototype.
	Clones the CSRCollateralHaircut object and returns a pointer to the copy.
	Usually, it is done automatically by the macro DECLARATION_COLLATERAL_HAIRCUT.
	@see tools::CSRPrototype
	*/
	virtual CSRCollateralHaircut* Clone() const = 0;

	/**
	 * Method doing the Haircut calculation for securities. To be implemented in derived classes.
	 * @see CSRLBAgreement::GetCollateralHaircut.
	 */
	virtual double GetCollateralHaircut(const CSRLBAgreement& lba,
		long instrIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0, long date = 0) const = 0;

	/**
	 * Method doing the Haircut calculation for cash. To be implemented in derived classes.
	 * @see CSRLBAgreement::GetCurrencyHaircut.
	 */
	virtual double GetCurrencyHaircut(const CSRLBAgreement& lba,
		long ccyIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0) const = 0;

	/*typedef for the prototype : the key is a string
	*/
	typedef sophis::tools::CSRPrototype<CSRCollateralHaircut, const char*, sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton instance.
	To add a trigger to this singleton, use INITIALISE_COLLATERAL_HAIRCUT.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();
};

/**
Macro to be used instead of the Clone() method in the clients derived classes.
Prototype framework will be responsible to instantiate clients objects.

@param derivedClass is the name of the client derived class.
@version 7.1
*/
#define DECLARATION_COLLATERAL_HAIRCUT(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, CSRCollateralHaircut)
#define CONSTRUCTOR_COLLATERAL_HAIRCUT(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_HAIRCUT(derivedClass)
/**
Macro to be placed in the clients <main>.cpp to register derived client classes
with the prototype framework.

@param derivedClass is the name of the client derived class.
@param name is the unique string to be used as a key to identify the registered class in the framework.
It is also what will appear in the "Haircut Rule" drop down menu.
Clients have to use this name in CSRPerimeterSelectorCondition::GetPrototype().GetData(condName) 
method to instantiate the clients class objects.

@version 7.1
*/
#define	INITIALISE_COLLATERAL_HAIRCUT(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass,  name)

	} //collateral
} //sophis

#endif //__SphCollateralHaircutAPI_H__
