/*
File:		SphCollateralIndicator.h

Contains:	Class used for instrument->GetCollateralIndicator() calls.

Copyright:	� 1995-2005 Sophis.

*/

#ifndef _SphCollateralIndicator_H_
#define _SphCollateralIndicator_H_

#include "SphInc/market_data/SphMarketData.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Interface used by collateral and stock loan risk calculations to allow use of custom forex.
 *
 * <P>
 * The risk value (or risk indicator) in Collateral Management is calculated
 * in certain currency, like currency of the instrument or currency of the Collateral Management Agreement.
 * This interface allows to specify custom forex conversion to be used
 * inside collateral risk indicator calculations, while converting from
 * the deal (position) or instrument currency to the target currency.
 *
 * @see CSRLBAgreement::GetCurrency()
 * @see CSRInstrument::GetCollateralIndicator()
 *
 * @since 5.1
 */
class SOPHIS_COLLATERAL CSRCollateralIndicatorForex
{
public:
	/**
	 * Calculates Fx value between two currencies. 
	 *
	 * @param currency1 Original currency.
	 * @param currency2 Target currency.
	 * @param date Optional date, if specified, the Fx value should be calculated for given date,
	 * otherwise, the last Fx rate should be returned.
	 * @param forexDate Optional parameter. Returns the forex date. @version 5.2.7
	 *
	 * @return Fx value between currencies.
	 */
 	virtual double GetForex(long currency1, long currency2, long date=0, long * forexDate = 0) const = 0;
};

/**
 * Default implementation of CSRCollateralIndicatorForex interface
 * which returns the last available system Fx.
 *
 * <P>
 * This implementation does not take the date into the account
 * and is equivalent of calling 
 * <code>sophis::market_data::gApplicationContext->GetForex(currency1,currency2)</code>.
 *
 * @see sophis::market_data::gApplicationContext
 * @see sophis::market_data::CSRMarketData::GetForex(long,long)
 *
 */
class CSRDefaultCollateralIndicatorForex : public virtual CSRCollateralIndicatorForex
{
public:
    virtual double GetForex(long currency1, long currency2, long date=0, long * forexDate = 0) const
    {
		if (forexDate)
			*forexDate = 0;
        return sophis::market_data::gApplicationContext->GetForex(currency1,currency2);
    }

	/**
	 * Returns pointer to the static instance of default CSRCollateralIndicatorForex implementation.
	 * Returned pointer must not be deleted.
	 * 
	 * @return Pointer to default CSRCollateralIndicatorForex implementation which must not be deleted.
	 */
    static const CSRCollateralIndicatorForex* GetDefaultCollateralIndicatorForex()
    {
        static CSRCollateralIndicatorForex* forex = new CSRDefaultCollateralIndicatorForex();
        return forex;
    }
};

/**
 * Structure used by <code>GetCollateralIndicator()</code> to store detailed results of the 
 * collateral risk calculation.
 *
 * <P>
 * The Collateral Management Module uses <code>GetCollateralIndicator()</code>
 * to calculate risk value. The risk value (or risk indicator) is calculated
 * on per-instrument, per-position basis. 
 * The <code>GetCollateralIndicator()</code> method returns risk value represented
 * in instrument currency.
 * To better understand the source of risk and break it down between Principal
 * and Collateral parts (where applicable), the <code>GetCollateralIndicator()</code> method accepts 
 * <code>SCollateralIndicatorDetails</code> structure to be populated with detailed results.
 *
 * <P>
 * There is a maximum of four different currencies involved in the collateral risk calculation: 
 * <UL>
 * <LI><code>ccy0</code> -- currency of the Instrument
 * <LI><code>ccy1</code> -- currency of the underlying (for Principal) 
 * <LI><code>ccy2</code> -- currency of the collateral (for Collateral) 
 * <LI><code>ccy3</code> -- currency of the agreement (the CMA reference currency) 
 * </UL>
 *
 * Conversion between currencies is performed via CSRCollateralIndicatorForex interface.
 * The resulting values in each currency are then populated into the <code>SCollateralIndicatorDetails</code> 
 * structure.
 *
 *
 * <P>
 * It is important to understand that risk is calculated per triplet <code>COUNTERPARTY</code>, 
 * <code>ENTITY</code>, <code>CONVENTION</code>. Such triplet is unique and defines 
 * the Collateral Management Agreement (CMA). By parameterizing the CMA you impact on how the risk is calculated. 
 *
 * <P>
 * The global formula for risk calculation inside the collateral management module is: <pre>
 * RISK = - PRINCIPAL VALUE + COLLATERAL VALUE</pre>
 * The total risk per CMA is a summary of all matching deals from all loaded portfolios. 
 *
 * <P>
 * A <i>negative</i> risk value means that the counter-party is at risk of loosing money. 
 * A <i>positive</i> value means that the entity is at risk, so if the counter-party goes bankrupt, 
 * the entity looses money. A value of zero indicates there is no risk for either counter-party or entity. 
 * The aim is to keep the risk value within certain <i>limits</i>, 
 * as defined in the Limits Definition Window in RISQUE. 
 *
 * @see CSRInstrument::GetCollateralIndicator()
 *
 * @since 5.1
 */
struct SCollateralIndicatorDetails
{
	/**
	 * Instrument code (also known as sicovam).
	 */
	long fCode; // instrument code
	/**
	 * Currency of the instrument and the result.
	 * This is the currency of instrument pointed to by <code>fCode</code>.
	 * The result of <code>GetCollateralIndicator()</code> (i.e. risk value) is 
	 * represented in this currency.
	 */
	long fCurrency; // currency of the result
	/**
	 * Currency of the Collateral Management Agreement.
	 */
	long fRefCurrency; // collateral management agreement (cma) reference currency

	/**
	 * Instrument code of the Principal part of the instrument.
	 * Principal instrument may or may not be present.
	 * This is applicable only to certain type instruments, like Stock Loans, Repos, etc.
	 */
	long fPrincipalCode;
	/**
	 * Currency of the Principal instrument.
	 */
	long fPrincipalCcy;
	/**
	 * Quantity (amount) of the Principal instrument.
	 */
	double fPrincipalQty;
	/**
	 * Spot of the Principal instrument used for Principal value calculations.
	 * The spot is represented in currency of the Principal instrument (<code>fPrincipalCcy</code>).
	 */
	double fPrincipalSpot; // value in fPrincipalCcy
	/**
	 * Spot date of the Principal instrument used for Principal value calculations (<code>fPrincipalSpot</code>).
	 */
	long fPrincipalSpotDate;
	/**
	 * Accrued for the principal.
	 */
	double fPrincipalAccrued;
	/**
	 * Principal value in resulting currency.
	 */
	double fPrincipalValue; // value in fCurrency
	/**
	 * Principal value in Principal instrument currency.
	 */ 
	double fPrincipalValueInPrincipalCcy; // value in fPrincipalCcy
	/**
	 * Principal value in Collateral Management Agreement currency (reference currency).
	 */
	double fPrincipalValueInRefCcy; // value in fRefCurrency

	/**
	 * Instrument code of the Collateral part of the instrument.
	 * Collateral part may or may not be present.
	 */
	long fCollateralCode;
	/**
	 * Currentcy of the Collateral instrument.
	 */
	long fCollateralCcy;
	/**
	 * Quantity (amount) of the Collateral instrument.
	 */
	double fCollateralQty;
	/**
	 * Spot of the Collateral instrument used for Collateral value calculations.
	 * The spot is represented in Collateral instrument currency (<code>fCollateralCcy</code>).
	 */
	double fCollateralSpot; // value in fCollateralCcy
	/**
	* Spot date of the Collateral instrument used for Collateral value calculations (<code>fCollateralSpot</code>).
	*/
	long fCollateralSpotDate;
	/**
	 * Accrued for the collateral.
	 */
	double fCollateralAccrued;
	/**
	 * Collateral value in resulting currency.
	 */
	double fCollateralValue; // value in fCurrency
	/**
	 * Collateral value in Collateral instrument currency.
	 */
	double fCollateralValueInCollateralCcy; // value in fCollateralCcy
	/**
	 * Collateral value in Collateral Management Agreement currency (reference currency).
	 */
	double fCollateralValueInRefCcy; // value in fRefCurrency

	/**
	 * Risk value in resulting currency.
	 * Calculated as: <code>fRiskValue = -fPrincipalValue + fCollateralValue</code>.
	 */
	double fRiskValue; // value in fCurrency; = -fPrincipalValue + fCollateralValue
	/**
	 * Risk value in Collateral Management Agreement currency (reference currency).
	 * Calculated as: <code>fRiskValueInRefCcy = -fPrincipalValueInRefCcy + fCollateralValueInRefCcy</code>.
	 */
	double fRiskValueInRefCcy; // value in fRefCurrency; = -fPrincipalValueInRefCcy + fCollateralValueInRefCcy

	/**
	* Forex of the Principal instrument used for Principal value in fRefCurrency (<code>fPrincipalValueInRefCcy</code>).
	*/
	double fPrincipalForex;
	/**
	* Forex date of the Principal instrument used for Principal value in fRefCurrency (<code>fPrincipalValueInRefCcy</code>).
	*/
	long fPrincipalForexDate;
	/**
	* Forex of the Collateral instrument used for Collateral value in fRefCurrency (<code>fCollateralValueInRefCcy</code>).
	*/
	double fCollateralForex;
	/**
	* Forex date of the Collateral instrument used for Collateral value in fRefCurrency (<code>fCollateralValueInRefCcy</code>).
	*/
	long fCollateralForexDate;
};


	}
}
SPH_EPILOG
#endif // _SphCollateralIndicator_H_
