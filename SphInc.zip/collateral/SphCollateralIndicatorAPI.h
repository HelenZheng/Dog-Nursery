#ifndef __SphCollateralIndicatorAPI_H__
#define __SphCollateralIndicatorAPI_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRPosition;
		struct SSReportingTrade;
	}
	namespace collateral {
	
		class CSRLBAgreement;
		class CSRCollateralIndicatorForex;
		struct SCollateralIndicatorDetails;

/**
 * Interface for building calculators for Limits Calculation functionality.
 * The result of the limit calculation is known as limit indicator, thus
 * the name.
 *
 * Before 5.2 there was only one standard calculation process available as defined in
 * {@link CSRInstrument::GetCollateralIndicator}.
 * It has changed in 5.2 to allow for the custom ones to be built.
 * The standard indicator uses the calculation procedure previously defined in 
 * {@link CSRInstrument::GetCollateralIndicator}.
 *
 * @since 5.2
 */
class SOPHIS_COLLATERAL CSRCollateralIndicator
{
public:

	/** Trivial destructor.
	*/
	virtual ~CSRCollateralIndicator() {}

	/** Clone method needed by the prototype.
	Usually, it is done automatically by the macro DECLARATION_COLLATERAL_INDICATOR.
	@see tools::CSRPrototype
	*/
	virtual CSRCollateralIndicator* Clone() const = 0;

	/**
	 * Main method doing the indicator calculation. To be implemented in derived classes.
	 *
	 * Calculates and returns collateral risk indicator value on given position using given
	 * collateral agreement and forex exchange function.
	 * 
	 * @param pos Position for which the risk (collateral indicator) is calculated.
	 * @param lba Collateral agreement that should be used for getting the calculations settings etc.
	 * @param collateralForex Interface to be used inside GetCollateralIndicator for forex conversion between any two currencies.
	 * @param detailedResults Optional parameter to obtain detailed calculations results.
	 * @param date Optional parameter to obtain correct maturity date (if relative). 0 means today. @version 5.2.7
	 * @return indicator value in currency of the collateral agreement.
	 */
	virtual double GetCollateralIndicator (const sophis::portfolio::CSRPosition* pos, const CSRLBAgreement* lba,
		const CSRCollateralIndicatorForex* collateralForex = 0,
		SCollateralIndicatorDetails* detailedResults = 0,
		long date = 0) const = 0;

	/** typedef for the prototype : the key is a string
	*/
	typedef sophis::tools::CSRPrototype<CSRCollateralIndicator , 
		const char* , 
		sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	To add a trigger to this singleton, use INITIALISE_COLLATERAL_INDICATOR.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();
};

/**
Macro to be used instead of the Clone() method in the clients derived classes.
Prototype framework will be responsible to instantiate clients objects.

@param derivedClass is the name of the client derived class.
@since 5.2
*/
#define DECLARATION_COLLATERAL_INDICATOR(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, CSRCollateralIndicator)
#define CONSTRUCTOR_COLLATERAL_INDICATOR(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INDICATOR(derivedClass)
/**
Macro to be placed in the clients <main>.cpp to register derived client classes
with the prototype framework.

@param derivedClass is the name of the client derived class.
@param name is the unique string to be used as a key to indentify registrated class in the framework.
It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
Perimeter Selector window.
Clients have to use this name in CSRPerimeterSelectorCondition::GetPrototype().GetData(condName) 
method to instantiate the clients class objects.

@since 5.2
*/
#define	INITIALISE_COLLATERAL_INDICATOR(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass,  name)

	} //collateral
} //sophis
SPH_EPILOG
#endif //__SphCollateralIndicatorAPI_H__
