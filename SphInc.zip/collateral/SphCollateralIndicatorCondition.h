#ifndef __SphCollateralCondition_H__
#define __SphCollateralCondition_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG

struct TLib;

namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRPosition;
		class CSRTransaction;
		struct SSReportingTrade;
	}
	namespace collateral {
	
		class CSRLBAgreement;
		class CSRCollateralIndicatorForex;
		struct SCollateralIndicatorDetails;

/**
 * Macros for handling collateral indicator and initial amount condition.
 * To be used instead of the Clone() method in the derived classes.
 * @param derivedClass is the name of the client derived class.
 * @version 5.2
 * @version 6.2 Extended interface, also to be used with initial amount.
 */
#define DECLARATION_COLLATERAL_INDICATOR_CONDITION(derivedClass)	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralIndicatorCondition)
#define CONSTRUCTOR_COLLATERAL_INDICATOR_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INDICATOR_CONDITION(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to indentify registrated class in the framework.
 * It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 * the Collateral Indicator Selector window.
 * @version 5.2
 */
#define	INITIALISE_COLLATERAL_INDICATOR_CONDITION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Interface for adding conditions to the Collateral Indicator Selector menu.
 * With the introduction of multiple calculation algorithms for the Limits Calculation procedure in 5.2,
 * the Collateral Indicator Selector menu has been added to select between calculation algorithms (indicators).
 * The interface allows to fine-tune such selection by defining additions conditions
 * to be checked by Collateral Indicator Selector when choosing the right calculation algorithm (indicator).
 *
 * @version 5.2
 * @version 6.2 Extended interface, also to be used with initial amount.
 */
class SOPHIS_COLLATERAL CSRCollateralIndicatorCondition
{
public:

	/**
	 * Trivial destructor.
	 */
	virtual ~CSRCollateralIndicatorCondition() {}

	/**
	 * Clone method needed by the prototype.
	 * Usually, it is done automatically by the macro DECLARATION_COLLATERAL_INDICATOR_CONDITION.
	 * @see tools::CSRPrototype
	 */
	virtual CSRCollateralIndicatorCondition* Clone() const = 0;

	/**
	 * Checks to see if given position matches the condition rules. To be implemented in derived classes.
	 * 
	 * During calculation algorithm (indicator) selection process for the position, 
	 * the Collateral Indicator Selector ensures all conditions specified for the rule 
	 * are met. It calls GetCondition() method and checks the return value.
	 * Should the return value be false, the condition is not accepted and the given
	 * rule is rejected, with Collateral Indicator Selector moving onto the next rule
	 * to check if it is suitable.
	 * 
	 * @param instr Instrument of the position.
	 * @param portfolioCode Portfolio code of position or transaction.
	 * @param positionId Position id of position or transaction (can be 0).
	 * @param pos Position object (can be NULL for new position) for which the collateral indicator / intiail amount method is sought.
	 * @param trans Transaction object (only for new deal/position creation, NULL otherwise).
	 * @param lba Collateral agreement applicable to the position (can be NULL).
	 *
	 * @return false to indicate the rule is not acceptable; true to allow condition and make the rule active.
	 *
	 * @version 6.2
	 */
	virtual bool GetCondition(
		const instrument::CSRInstrument& instr, long portfolioCode, sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos, const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba, long date) const = 0;

	/**
	 * Checks to see if given deal matches the condition rules.
	 *
	 * This is called during Collateral Limits Extraction to avoid doing reporting
	 * calculation on the deals that can be filtered out.
	 *
	 * @version 5.3.6
	 * @param deal Extraction data for one deal.
	 * @param lba Collateral agreement applicable to the position (can be NULL).
	 * @param date Extraction date (if applicable).
	 *
	 * @return false to indicate the rule is not acceptable; true to allow condition and make the rule active.
	 */
	virtual bool GetCondition (const sophis::portfolio::SSReportingTrade*& deal, const CSRLBAgreement* lba = 0, long date = 0) const { return true; }

	/** typedef for the prototype : the key is a string
	*/
	typedef sophis::tools::CSRPrototype<CSRCollateralIndicatorCondition , 
		const char* , 
		sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	To add a trigger to this singleton, use INITIALISE_COLLATERAL_INDICATOR_CONDITION.
	@see tools::CSRPrototype
	*/
	static prototype& GetPrototype();
};

/**
 * Simple bridge class for compatibility with versions prior to 6.2.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralIndicatorPositionCondition : public virtual CSRCollateralIndicatorCondition
{
public:
	/** Bridge. */
	virtual bool GetCondition(
		const instrument::CSRInstrument& instr, long portfolioCode, sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos, const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba, long date) const
	{
		return this->GetCondition(pos, lba, date);
	}

	/**
	 * To be implemented in derived classes.
	 * Interface compatible with versions 5.2 and later.
	 */
	virtual bool GetCondition(const portfolio::CSRPosition*& pos, const CSRLBAgreement* lba = 0, long date = 0) const = 0;
};

/**
 * Simple utility / wrapper class for conditions depending on instrument information only.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralIndicatorInstrumentCondition : public virtual CSRCollateralIndicatorCondition
{
public:
	/** Bridge. */
	virtual bool GetCondition(
		const instrument::CSRInstrument& instr, long portfolioCode, sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos, const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba, long date) const;

	/** Bridge. */
	virtual bool GetCondition (const sophis::portfolio::SSReportingTrade*& deal,
		const CSRLBAgreement* lba = 0, long date = 0) const;

	/**
	 * To be implemented in derived classes.
	 * @param sicovam Instrument id.
	 * @param lba Collateral agreement (if applicable).
	 * @param date Report date (if applicable).
	 */
	virtual bool GetCondition(long sicovam, const CSRLBAgreement* lba, long date) const = 0;
};

/**
 * INTERNAL.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralIndicatorTLibCondition : public virtual CSRCollateralIndicatorInstrumentCondition
{
public:
	/** Bridge. */
	virtual bool GetCondition(long sicovam, const CSRLBAgreement* lba, long date) const;

	/**
	 * To be implemented in derived classes.
	 * @param ph TLib.
	 * @param lba Collateral agreement (if applicable).
	 * @param date Report date (if applicable).
	 */
	virtual bool GetCondition(TLib*& ph, const CSRLBAgreement* lba, long date) const = 0;
};

	} //collateral
} //sophis

SPH_EPILOG
#endif // __SphCollateralCondition_H__
