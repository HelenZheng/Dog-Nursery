#ifndef _SphCollateralInitialAmount_H_
#define _SphCollateralInitialAmount_H_

#include "SphInc/collateral/SphCollateralInitialAmountMethod.h"

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRPosition;
		class CSRTransaction;
	}
	namespace collateral {

class CSRLBAgreement;
class CSRCollateralInitialAmountMethod;

/**
 * Interface for collateral initial amount operations.
 * @version 6.2
 */
class CSRCollateralInitialAmount
{
public:
	/** Trivial Constructor. */
	CSRCollateralInitialAmount() {}
	/** Trivial Destructor. */
	virtual ~CSRCollateralInitialAmount() {}

	/**
	 * Return collateral agreement to which given positions maps to.
	 */
	virtual const CSRLBAgreement* GetCollateralAgreementFromTransaction(
		const instrument::CSRInstrument& instr,
		const portfolio::CSRTransaction& trans)
	{
		return 0;
	}

	/**
	 * Return collateral agreement to which given position maps to.
	 * If information inside position object is not sufficient, a transaction is extracted from position
	 * and collateral agreement is determined based on instrument and transaction.
	 */
	virtual const CSRLBAgreement* GetCollateralAgreementFromPosition(
		const instrument::CSRInstrument& instr,
		const portfolio::CSRPosition& pos)
	{
		return 0;
	}

	/**
	 * Calculates the existing or default initial amount for given data.
	 * Default implies that initial amount value is first taken from position (if applicable)
	 * and then from the collateral agreement.
	 *
	 * @return initial method applied or NULL if no initial method is applicable.
	 */
	virtual const CSRCollateralInitialAmountMethod* GetInitialAmountDefault(
		const instrument::CSRInstrument& instr,
		long portfolioCode,
		portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos,
		const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba,
		long date,
		SInitialAmount& initialAmount)
	{
		return 0;
	}

	/**
	 * Calculates the initial amount for given data.
	 * This method will look strictly in one place based on the IM Negotiation Type setting in collateral agreement.
	 * For Per Position only lookup inside position is done; for Per Agreement only lookup inside agreement/selector is done.
	 *
	 * @return initial method applied or NULL if no initial method is applicable.
	 */
	virtual const CSRCollateralInitialAmountMethod* GetInitialAmount(
		const instrument::CSRInstrument& instr,
		long portfolioCode,
		portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos,
		const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba,
		long date,
		SInitialAmount& initialAmount)
	{
		return 0;
	}
};

/**
 * Global handler (implementation) of collateral initial amount.
 * @version 6.2
 */
extern SOPHIS_FIT CSRCollateralInitialAmount *gCollateralInitialAmount;

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralInitialAmount_H_
