#pragma once
#ifndef _SphCollateralInitialAmountCurrencyType_H_
#define _SphCollateralInitialAmountCurrencyType_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


/**
 * Macros for handling collateral initial amount currency type.
 * To be used instead of the Clone() method in the derived classes.
 * @version 6.2
 */
#define DECLARATION_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE(derivedClass)	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralInitialAmountCurrencyType)
#define CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to indentify registrated class in the framework.
 * @version 6.2
 */
#define	INITIALISE_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE(derivedClass, name) \
	sophis::collateral::CSRCollateralInitialAmountCurrencyType::sOrderIndex.insert(_STL::make_pair<_STL::string, long>(name, sophis::collateral::CSRCollateralInitialAmountCurrencyType::sInstallOrder++)); \
	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRPosition;
		class CSRTransaction;
	}
	namespace collateral {

		class CSRLBAgreement;

/**
 * A notion of currency type for collateral initial amount.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralInitialAmountCurrencyType
{
public:
	/** 
	 * Trivial destructor.
	 */
	virtual ~CSRCollateralInitialAmountCurrencyType() {}

	/** 
	 * Clone method needed by the prototype. To be implemented by derived classes.
	 * Usually, it is done automatically by the macro DECLARATION_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE.
	 * @see tools::CSRPrototype
	 */
	virtual CSRCollateralInitialAmountCurrencyType* Clone() const = 0;

	/**
	 * Must return currency to be used as the result currency for the initial amount.
	 * To be implemented in derived classes.
	 */
	virtual long GetInitialAmountCurrency(const instrument::CSRInstrument& instr,
		long portfolioCode,
		sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos,
		const portfolio::CSRTransaction* trans,
		const CSRLBAgreement* lba) const = 0;

	static long sInstallOrder;
	static _STL::map<_STL::string, long> sOrderIndex;
	/**
	 * Internal, controls the order of registering records in the prototype.
	 */
	struct order_as_installed
	{
		bool operator()(const char * x, const char * y) const
		{
			long o1 = 0L, o2 = 0L;
			_STL::map<_STL::string, long>::iterator it;
			it = CSRCollateralInitialAmountCurrencyType::sOrderIndex.find(x);
			if(it == CSRCollateralInitialAmountCurrencyType::sOrderIndex.end())
				return false;
			o1 = (*it).second;
			it = CSRCollateralInitialAmountCurrencyType::sOrderIndex.find(y);
			if(it == CSRCollateralInitialAmountCurrencyType::sOrderIndex.end())
				return false;
			o2 = (*it).second;

			return (o1 < o2) ? true : false;
		}
	};

	/** 
	 * Typedef for the prototype, the key is a const char*, order is install order.
	 */
	typedef tools::CSRPrototype<CSRCollateralInitialAmountCurrencyType, const char*, order_as_installed> prototype;

	/**
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_INITIAL_AMOUNT_CURRENCY_TYPE.
	 * @see tools::CSRPrototype
	 */
	static prototype& GetPrototype();

	/**
	 * Get the collateral initial amount based on id from the prototype.
	 * @param id is unique id, assigned during initialisation.
	 * @throws CSRPrototype::ExceptionNotFound if id does not match with any id.
	 */
	static const CSRCollateralInitialAmountCurrencyType& GetInstance(long id);

	/** 
	 * Returns the id of the instance.
	 * The value is created automatically at the end of the initialise.
	 */
	int GetId() const
	{
		return fId;
	}

	/** 
	 * Set the id.
	 * Used when building the columns by {@link CSPReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

protected:
	long	fId;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralInitialAmountCurrencyType_H_
