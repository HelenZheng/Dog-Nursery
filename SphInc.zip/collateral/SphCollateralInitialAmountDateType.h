#ifndef _SphCollateralInitialAmountDateType_H_
#define _SphCollateralInitialAmountDateType_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

/**
 * Macros for handling collateral initial amount date type.
 * To be used instead of the Clone() method in the derived classes.
 * @version 6.2
 */
#define DECLARATION_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE(derivedClass)	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralInitialAmountDateType)
#define CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to indentify registrated class in the framework.
 * @version 6.2
 */
#define	INITIALISE_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE(derivedClass, name) \
	sophis::collateral::CSRCollateralInitialAmountDateType::sOrderIndex.insert(_STL::make_pair<_STL::string, long>(name, sophis::collateral::CSRCollateralInitialAmountDateType::sInstallOrder++)); \
	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRPosition;
		class CSRTransaction;
	}
	namespace collateral {

/**
 * A notion of date type for collateral initial amount.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralInitialAmountDateType
{
public:
	struct DateValues
	{
		long fTradeDate;
		long fValueDate;
		long fId;

		DateValues()
			: fTradeDate(0), fValueDate(0), fId(0) {}
		DateValues(long tradeDate, long valueDate, long id)
			: fTradeDate(tradeDate), fValueDate(valueDate), fId(id) {}
	};
	typedef _STL::vector<DateValues> DateVec;

	/** 
	 * Trivial destructor.
	 */
	virtual ~CSRCollateralInitialAmountDateType() {}

	/** 
	 * Clone method needed by the prototype. To be implemented by derived classes.
	 * Usually, it is done automatically by the macro DECLARATION_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE.
	 * @see tools::CSRPrototype
	 */
	virtual CSRCollateralInitialAmountDateType* Clone() const = 0;

	/**
	 * Must return number of securities to take into account into initial amount calculation.
	 * To be implemented in derived classes.
	 */
	virtual double GetNumberOfSecurities(const instrument::CSRInstrument& instr,
		long portfolioCode,
		sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos,
		const portfolio::CSRTransaction* trans,
		long date) const = 0;

	/**
	 * Returns the list of the valid dates from the given dates.
	 * Used  by the TRS basket independent amount methods to select the valid dates and pick the right adjustments.
	 */
	virtual void GetValidDates(const DateVec& dates, DateVec& validDates, long date) const = 0;

	static long sInstallOrder;
	static _STL::map<_STL::string, long> sOrderIndex;
	/**
	 * Internal, controls the order of registering records in the prototype.
	 */
	struct order_as_installed
	{
		bool operator()(const char * x, const char * y) const
		{
			long o1 = 0L, o2 = 0L;
			_STL::map<_STL::string, long>::iterator it;
			it = CSRCollateralInitialAmountDateType::sOrderIndex.find(x);
			if(it == CSRCollateralInitialAmountDateType::sOrderIndex.end())
				return false;
			o1 = (*it).second;
			it = CSRCollateralInitialAmountDateType::sOrderIndex.find(y);
			if(it == CSRCollateralInitialAmountDateType::sOrderIndex.end())
				return false;
			o2 = (*it).second;

			return (o1 < o2) ? true : false;
		}
	};

	/** 
	 * Typedef for the prototype, the key is a const char*, order is install order.
	 */
	typedef tools::CSRPrototype<CSRCollateralInitialAmountDateType, const char*, order_as_installed> prototype;

	/**
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_INITIAL_AMOUNT_DATE_TYPE.
	 * @see tools::CSRPrototype
	 */
	static prototype& GetPrototype();

	/**
	 * Get the collateral initial amount based on id from the prototype.
	 * @param id is unique id, assigned during initialisation.
	 * @throws CSRPrototype::ExceptionNotFound if id does not match with any id.
	 */
	static const CSRCollateralInitialAmountDateType& GetInstance(long id);

	/** 
	 * Returns the id of the instance.
	 * The value is created automatically at the end of the initialise.
	 */
	int GetId() const
	{
		return fId;
	}

	/** 
	 * Set the id.
	 * Used when building the columns by {@link CSPReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

protected:
	long	fId;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralInitialAmountDateType_H_
