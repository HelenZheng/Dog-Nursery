#ifndef _SphCollateralInitialAmountExplanation_H_
#define _SphCollateralInitialAmountExplanation_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis {
	namespace tools {
		namespace dataModel {
			class DataSet;
		}
	}
	namespace collateral {


/**
 * Macros for handling collateral initial amount explanation.
 * @version 6.2
 */
#define DECLARATION_COLLATERAL_INITIAL_AMOUNT_EXPLANATION(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralInitialAmountExplanation)
#define CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_EXPLANATION(derivedClass) derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_EXPLANATION(derivedClass)
#define	INITIALISE_COLLATERAL_INITIAL_AMOUNT_EXPLANATION(derivedClass,name) INITIALISE_PROTOTYPE(derivedClass, name)

/**
* Class that handles initial amount explanation
* @see sophis::collateral::SInitialAmount
* @version 6.2
*/
class SOPHIS_COLLATERAL CSRCollateralInitialAmountExplanation
{
public:
	virtual ~CSRCollateralInitialAmountExplanation() {};
	virtual CSRCollateralInitialAmountExplanation* Clone() const = 0;

	/** Retrieve a description from an explanation.
	* To be overloaded by derived class.
	* @param dataSet is the description to be filled with this explanation.
	* It is called by static GetDescription to generate XML. 
	* @version 6.2
	*/
	virtual void GetDescription(sophis::tools::dataModel::DataSet& dataSet) const = 0;

	/** Initialize explanation from description.
	* To be overloaded by derived class.
	* @param dataSet is the description which contains data to initialize this explanation.
	* It is called by static CreateFromDescription to initial explanation from XML.
	* @version 6.2
	*/
	virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet) = 0;
	
	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRCollateralInitialAmountExplanation, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();

	/** Retrieve a description from an explanation.
	* @param dataSet is the description to be filled with explanation.
	* @param explanation is the explanation which data is to be put into dataSet
	* It fills <CSRCollateralInitialAmountExplanation_name> with prototype name and then calls CSRCollateralInitialAmountExplanation::GetDescription
	* @version 6.2
	*/
	static void GetDescription(sophis::tools::dataModel::DataSet& dataSet, const CSRCollateralInitialAmountExplanation& explanation);

	/** Creates an explanation from a description
	* @param dataSet is the description which contains data to initialize explanation.
	* @returns explanation initialized from description
	* Creates new explanation identified by <CSRCollateralInitialAmountExplanation_name> and then calls CSRCollateralInitialAmountExplanation::UpdateFromDescription
	* @version 6.2
	*/
	static CSRCollateralInitialAmountExplanation* CreateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralInitialAmountExplanation_H_
