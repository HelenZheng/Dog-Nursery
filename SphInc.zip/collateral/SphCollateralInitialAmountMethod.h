#ifndef _SphCollateralInitialAmountMethod_H_
#define _SphCollateralInitialAmountMethod_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralInitialAmountExplanation.h"
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


/**
 * Macros for handling collateral initial amount method.
 * To be used instead of the Clone() method in the derived classes.
 * @version 6.2
 */
#define DECLARATION_COLLATERAL_INITIAL_AMOUNT_METHOD(derivedClass)	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralInitialAmountMethod)
#define CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_METHOD(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_INITIAL_AMOUNT_METHOD(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to indentify registrated class in the framework.
 * @version 6.2
 */
#define	INITIALISE_COLLATERAL_INITIAL_AMOUNT_METHOD(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace portfolio {
		class CSRPosition;
		class CSRTransaction;
	}
	namespace collateral {

class CSRCollateralInitialAmountDateType;
class CSRCollateralInitialAmountCurrencyType;
class CSRLBAgreement;

/**
 * Structure representing a result of the initial amount calculation.
 * @version 6.2
 */
struct SInitialAmount
{
	SInitialAmount() 
		:fCurrency(0)
		, fValue(.0)
		, fMarginRate(.0)
		, fExplanation(NULL)
	{}
	SInitialAmount(const SInitialAmount& copy) 
		: fCurrency(copy.fCurrency)
		, fValue(copy.fValue)
		, fMarginRate(copy.fMarginRate)
		, fExplanation(copy.fExplanation ? copy.fExplanation->Clone() : NULL)
	{}
	~SInitialAmount() { delete fExplanation; }
	/** Initial amount in specified currency. */
	double fValue;
	/** Currency of the initial amount. */
	long fCurrency;
	/** Margin rate in %, if applicable. */
	double fMarginRate;
	/** Explanation */
	CSRCollateralInitialAmountExplanation * fExplanation;
};

/**
 * A notion of method for calculating collateral initial amount.
 * @version 6.2
 */
class SOPHIS_COLLATERAL CSRCollateralInitialAmountMethod
{
public:
	/** 
	 * Trivial destructor.
	 */
	virtual ~CSRCollateralInitialAmountMethod() {}

	/** 
	 * Clone method needed by the prototype. To be implemented by derived classes.
	 * Usually, it is done automatically by the macro DECLARATION_COLLATERAL_INITIAL_AMOUNT_METHOD.
	 * @see tools::CSRPrototype
	 */
	virtual CSRCollateralInitialAmountMethod* Clone() const = 0;

	/**
	 * Initial amount calculation method.
	 * To be implemented by derived classes.
	 * @param iaDateType As configured by selector.
	 * @param iaCurrencyType As configured by selector.
	 * @param iaValue As configured by selector.
	 * @param initialAmount the result initial amount
	 * @return false if no initial amount is applicable; true if applicable, the result value is inside the initialAmount.
	 */
	virtual bool GetInitialAmount(const instrument::CSRInstrument& instr,
		long portfolioCode,
		sophis::portfolio::PositionIdent positionId,
		const portfolio::CSRPosition* pos,
		const portfolio::CSRTransaction* trans,
		const CSRCollateralInitialAmountDateType& iaDateType,
		const CSRCollateralInitialAmountCurrencyType& iaCurrencyType,
		double iaValue,
		const CSRLBAgreement* lba,
		long date,
		SInitialAmount& initialAmount,
		bool ignoreClosedPosition = false) const = 0;

	/** 
	 * Typedef for the prototype, the key is a const char*.
	 */
	typedef tools::CSRPrototype<CSRCollateralInitialAmountMethod, const char*, tools::less_char_star> prototype;

	/**
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_INITIAL_AMOUNT_METHOD.
	 * @see tools::CSRPrototype
	 */
	static prototype& GetPrototype();
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralInitialAmountMethod_H_
