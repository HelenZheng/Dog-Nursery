#ifndef _SphCollateralLimits_H_
#define _SphCollateralLimits_H_

#ifndef GCC_XML

#include "SphInc/limit/SphLimitsEngine.h"
#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/SphPreference.h"
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(memory)	// shared_ptr

SPH_PROLOG
namespace sophis {
	namespace limits {
		class CSRLimitRule;
		class CSRLimitRuleCriteria;
		class CSRLimit;
	}
	namespace collateral {

class CSRLBAgreement;
typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;
struct SLBACacheKey;

/**
 * Helper class to manage collateral limit rules.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRCollateralLimitsHelper
{
protected:
	CSRCollateralLimitsHelper() {};
	virtual ~CSRCollateralLimitsHelper() {};
public:
	static CSRCollateralLimitsHelper& GetInstance();
	/** Rule to handle collateral limits. */
	virtual const limits::CSRLimitRule& GetRule() = 0;
	/** List of collateral limit rules. */
	virtual const limits::CSRLimitRuleCriteria& GetLimits() = 0;
	/** Returns flag indicating if counterparty or entity filter can be applied to limits calculation, based on limit rules. */
	virtual bool CanFilter() = 0;
	/** Re-read collateral limit rules form the database. */
	virtual void RefreshLimits() = 0;
	/** Rule valid for specific collateral agreement (triplet), if found or 0 otherwise.
	 * The pointer remains valid until next RefreshLimits() call. */
	virtual const limits::CSRLimit* GetLimit(long cpty, long entity, long convention) = 0;
	/** Fills given key according to triplet. */
	virtual void FillKey(limits::CSREngineKey& key, long cpty, long entity, long convention) = 0;
	/** Fills triplet according to given key. */
	virtual void FillTriplet(limits::CSREngineKey& key, long& cpty, long& entity, long& convention) = 0;
};

/**
 * API to calculate collateral limits.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRCollateralLimitsAPI
{
public:
	/**
	 * Runs global collateral limits calculation and puts result in given explanation.
	 * @param explanation Where to put explanation.
	 * @param date Reporting date.
	 * @param pref Date type of reporting.
	 * @return the result of the check.
	 */
	static limits::CSRResultList CalculateAll(limits::CSRExplanation& explanation,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	 * Runs collateral limits calculation for specific collateral agreements and puts result in given explanation.
	 * @param explanation Where to put explanation.
	 * @param lbaList List of collateral agreements.
	 * @param date Reporting date.
	 * @param pref Date type of reporting.
	 * @return the result of the check.
	 */
	static limits::CSRResultList CalculateLBA(limits::CSRExplanation& explanation, _STL::set<const CSRLBAgreement*>& lbaList,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	 * Runs collateral limits calculation for specific counterparties and puts result in given explanation.
	 * @param explanation Where to put explanation.
	 * @param cptyList List of counterparties for which to run collateral limits.
	 * @param date Reporting date.
	 * @param pref Date type of reporting.
	 * @return the result of the check.
	 */
	static limits::CSRResultList CalculateCpty(limits::CSRExplanation& explanation, _STL::set<long>& cptyList,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	 * Runs collateral limits calculation for specific entities and puts result in given explanation.
	 * @param explanation Where to put explanation.
	 * @param entityList List of entities for which to run collateral limits.
	 * @param date Reporting date.
	 * @param pref Date type of reporting.
	 * @return the result of the check.
	 */
	static limits::CSRResultList CalculateEntity(limits::CSRExplanation& explanation, _STL::set<long>& entityList,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	 * Runs collateral limits calculation for specific limit rule and puts result in given explanation.
	 * @param explanation Where to put explanation.
	 * @param limit Collateral limit rule.
	 * @param date Reporting date.
	 * @param pref Date type of reporting.
	 * @return the result of the check.
	 */
	static limits::CSRResultList CalculateLimit(limits::CSRExplanation& explanation, limits::CSRLimit& limit,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	 * Internal.
	 */
	static limits::CSRResultList CalculateKey(limits::CSRExplanation& explanation, _STL::set<SLBACacheKey>& keyList,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

	/**
	* Internal.
	*/
	static limits::CSRResultList CalculateKey(limits::CSRExplanation& explanation, _STL::set<SLBACacheKey>& keyList, eCacheLbaType agreementType,
		long date = 0, portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate);

};

	} // collateral
} // sophis
SPH_EPILOG
#endif // GCC_XML

#endif // _SphCollateralLimits_H_
