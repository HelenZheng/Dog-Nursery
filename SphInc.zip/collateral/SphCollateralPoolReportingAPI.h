#ifndef _SphCollateralPoolReportingAPI_H_
#define _SphCollateralPoolReportingAPI_H_

#include "SphInc/collateral/SphCollateralReportingAPI.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {

	namespace collateral {
		class CSRLBAgreement;
		class CSRCollateralPoolResult;

		/**
		 * API for building and handling collateral pool calculation results.
		 * @version 5.3.2
		 */
		class SOPHIS_COLLATERAL CSRCollateralPoolReportingAPI : public virtual ISRCollateralReportingAPI
		{
		public:

			/**
			 * Bit flags used to control the behavior and output of detailed collateral limit calculation API.
			 * Custom (user-defined) flags should start from 0x10000.
			 */
			enum eReportingFlags
			{
				/**
				 * Minimum reporting results, no explanations.
				 */
				eCPRMinimum = 0x00,

				/**
				 * Compute cash interest explanation for cash collateral.
				 */
				eCPRComputeCashInterest = 0x01,

				/**
				 * To include empty cash and securities collateral section even if 
				 * there is no collateral.
				 * Useful if using this API for data display in GUI mode.
				 */
				eCPRAllowEmptyPools = 0x02,

				/**
				 * To exclude cash collateral from the report.
				 */
				eCPRExcludeCashPools = 0x04,

				/**
				 * To exclude securities collateral from the report.
				 */
				eCPRExcludeSecPools = 0x08,

				/**
				 * All settings required for common GUI display of the API results.
				 */
				eCPRCommonGui = (eCPRComputeCashInterest | eCPRAllowEmptyPools),
			};

			/**
			 * Structure to specify additional report parameters.
			 */
			struct SOPHIS_COLLATERAL SCollateralPoolReportingParameters : public SReportingParameters
			{
				SCollateralPoolReportingParameters();
				SCollateralPoolReportingParameters(const SCollateralPoolReportingParameters& copy);
				virtual ~SCollateralPoolReportingParameters() {}

				/** Optional start date. */
				long fStartDate;
				/** Optional reference currency. */
				long fRefCcy;
				/** Name of exclude filter prototype implementation. */
				char fExcludeFilter[40];

				/// See {@link ISRDescribable}
				virtual int GetFieldCount() const;
				/// See {@link ISRDescribable}
				virtual void GetField(int i, Field& field) const
					throw (InvalidRangeException);
				/// See {@link SReportingParameters::Clone}
				virtual SReportingParameters* Clone() const { return new SCollateralPoolReportingParameters(*this); }
			};

			/**
			 * Creates an API.
			 */
			CSRCollateralPoolReportingAPI();

			/**
			 * Destructor.
			 * Deletes all internal results.
			 */
			virtual ~CSRCollateralPoolReportingAPI();

			/**
			 * Builds a complete result hierarchy of all collateral related to the given collateral agreement.
			 * @param lba Collateral Agreement to which deals must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeAll(const CSRLBAgreement *lba, long calculationDate, long crfFlags);

			/**
			 * Builds a complete result hierarchy of all collateral related to given 
			 * counterparty/entity/convention filter (which can be omitted).
			 * @param cpty Counterparty to which deals must belong (map) to.
			 * @param entity Entity to which deals must belong (map) to.
			 * @param convention Convention to which deal's instrument must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeAll(long cpty, long entity, long convention, long calculationDate, SReportingParameters *extraParams = 0);

			/**
			 * Not applicable.
			 */
			virtual void ComputeOne(const CSRLBAgreement *lba, long calculationDate, sophis::portfolio::PositionIdent mvtident, long crfFlags);

			/**
			 * {@link ISRCollateralReportingAPI::GetResult}.
			 * Calls GetPoolResult().
			 */
			virtual const CSRCollateralResult* GetResult() const;

			/**
			 * Builds a dummy (blank) result tree that can be used to generate an XSD description.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeDummy(const CSRLBAgreement *lba, long crfFlags = eCPRCommonGui);

			/**
			 * Returns the result pointer which must not be deleted.
			 */
			const CSRCollateralPoolResult* GetCollateralPoolResult() const;

		protected:
			CSRCollateralPoolResult *fResult;

		private:
			static const char *__CLASS__;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralPoolReportingAPI_H_
