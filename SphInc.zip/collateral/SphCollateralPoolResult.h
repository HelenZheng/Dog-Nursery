#ifndef _SphCollateralPoolResult_H_
#define _SphCollateralPoolResult_H_

#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/Collateral/SphCollateralResult.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class CSRCashInterestExplanationList;
		struct CashCollateral;

/**
 * Class representing result tree of the Collateral Pools Calculation results.
 *
 * @see CSRCollateralResult
 * @version 5.3.2
 */
class SOPHIS_COLLATERAL CSRCollateralPoolResult : public virtual CSRCollateralResult
{
public:
	/**
	 * Defines line types of the result.
	 * Also used to build hierarchy window of the results.
	 */
	enum ePoolResultLineType {
		ePoolResultUndefined = 0,
		ePoolResultCpty,
		ePoolResultEntity,
		ePoolResultLBA,
		ePoolResultCashPoolGroup,
		ePoolResultCashPool,
		ePoolResultSecPoolGroup,
		ePoolResultSecPool,
	};

	/**
	 * Returns a new result of given type to be filled.
	 * @param cpty Counterparty.
	 * @param entity Entity.
	 * @param convention Convention.
	 * @param lineType Line type of the result sought.
	 * @return Pointer to new result line which must be deleted.
	 */
	static CSRCollateralPoolResult* CreateInstance(long cpty, long entity, long convention, ePoolResultLineType lineType = ePoolResultUndefined);

	CSRCollateralPoolResult();
	CSRCollateralPoolResult(long cpty, long entity, long convention, ePoolResultLineType lineType = ePoolResultUndefined);
	CSRCollateralPoolResult(const CSRCollateralPoolResult& copy);
	virtual ~CSRCollateralPoolResult();
	virtual CSRCollateralResult* Clone() const;
	virtual CSRCollateralResult* CloneCollat() const OVERRIDE { return Clone(); }

	/**
	 * Returns the master (top of the tree).
	 */
	const CSRCollateralPoolResult& GetCollateralPoolMaster() const;

	/**
	 * In case of hierarchical result, searches through the hierarchy in an attempt to locate
	 * result of given type.
	 * @return Result matching the line type or null.
	 */
	const CSRCollateralPoolResult* FindCollateralPoolChildByType(ePoolResultLineType lineType) const;

	/**
	 * Populates the given vector with its direct children.
	 */
	void GetCollateralPoolChildren(_STL::vector<const CSRCollateralPoolResult*>& children) const;

	/**
	 * Populates the given vector with flat list.
	 */
	void GetCollateralPoolFlatListView(_STL::vector<const CSRCollateralPoolResult*>& flatList) const;

	/**
	 * Populates the given vector with flat list of collateral results only, that is only
	 * cash pools and security pools.
	 */
	void GetCollateralPoolFlatListResultOnly(_STL::vector<const CSRCollateralPoolResult*>& flatList) const;

	/**
	 * Returns new instance of cash pool collateral explanation list.
	 * The list explains cash interest calculations for a given cash pool.
	 *
	 * @return New object to be filled or null if no cash interest explanation is required.
	 */
	virtual CSRCashInterestExplanationList* new_CSRCashInterestExplanationList() const;

	/**
	 * Returns cash pool collateral interest explanation list or null if there is no cash explanation list.
	 * The pointer must not be deleted.
	 * @return NULL or the pointer that must not be deleted.
	 */
	const CSRCashInterestExplanationList* GetCashPoolInterestExplanationList() const { return fCashPoolInterestExplanationList; }

	/**
	 * Copies the name of hierarchy into the name parameter. 
	 * Name parameter must point to preallocated area of memory.
	 */
	virtual void GetLineTypeName(char *name) const;

	/**
	 * @see {@link CSRCollateralResult::IsLower}
	 */
	virtual bool IsLower(const CSRCollateralResult& a, const CSRCollateralResult& b) const;

	/**
	 * @see {@link CSRCollateralResult::GetInstrumentInformationCode}
	 */
	virtual long GetInstrumentInformationCode() const;

public:
	//
	// Correspond to Columns
	//

	/** 
	 * Returns instrument code (also known as sicovam) of the result.
	 * The instrument code matches the position instrument code where position is available.
	 * For Cash Pools, it returns the instrument code of the corresponding Commission instrument.
	 * For Security Pools, it returns the instrument code of the security.
	 * @return Instrument code (sicovam).
	 */
	inline long GetInstrumentCode() const { return fInstrumentCode; }

	/**
	 * Result currency.
	 */
	inline long GetRefCurrency() const { return fRefCurrency; }

	/**
	 * Collateral value in reference currency.
	 */
	inline double GetCollateralValueInRefCcy() const { return fCollateralValueInRefCcy; }

	/**
	 * Collateral value in Instrument currency.
	 */
	inline double GetCollateralValueInInstrumentCcy() const { return fCollateralValueInInstrumentCcy; }

	/** 
	 * Unique depositary used for securities collateral transfer.
	 * @return 0 if no depositary is specified or CSRPosition::eMultiValues if there is more than one.
	 */
	inline long GetSecCollateralDepositary() const { return fDepositary; }

	/**
	 * Unique depositary of counterparty used for securities collateral transfer.
	 * @return 0 if no depositary is specified or CSRPosition::eMultiValues if there is more than one.
	 */
	inline long GetSecCollateralDepositaryOfCounterparty() const { return fDepositaryOfCpty; }

	/**
	 * Unique settlement method used for securities collateral transfer.
	 * @return 0 if no settlement method specified or it is not unique.
	 */
	inline long GetSecCollateralSettlementMethod() const { return fSettlementMethod; }

	/**
	 * Unique delivery type used for securities collateral transfer.
	 * @return 0 if no delivery type specified or it is not unique.
	 */
	inline long GetSecCollateralDeliveryType() const { return fDeliveryType; }

	/**
	 * Unique payment method used for securities collateral transfer.
	 * @return 0 if no payment method specified or it is not unique.
	 */
	inline long GetSecCollateralPaymentMethod() const { return fPaymentMethod; }

	/** 
	 * Haircut value as defined by the user. 
	 * This may be different to the haircut value used for calculations because of the inversion rules.
	 */
	inline double GetHaircutInProduct() const { return fHaircutInProduct; }

	/** 
	 * Clean spot of the collateral security.
	 */
	inline double GetSecCollateralSpot() const { return fSecCollateralSpot; }

	/**
	 * Accrued of the collateral security (if available).
	 */
	inline double GetSecCollateralAccrued() const { return fSecCollateralAccrued; }

	/**
	 * Quantity of the held securities collateral.
	 */
	inline double GetSecCollateralQty() const { return fSecCollateralQty; }

	/** 
	 * Last margin call date. 
	 */
	inline long GetLastMarginDate() const { return fLastMarginDate; }

	/**
	 * Returns Cash collateral currency for a cash pool.
	 */
	long GetCashCollateralCurrency() const;

	/**
	 * Returns Cash collateral currency for a cash pool.
	 */
	long GetCashCollateralInterestRate() const;

	/**
	 * Returns Amount of the cash collateral for a cash pool.
	 */
	double GetCashCollateralAmount() const;

	/**
	 * Returns current amount of interest on cash collateral (based on calculation date).
	 */
	double GetCashCollateralInterest() const;

	/**
	 * Returns yesterday amount of interest on cash collateral (based on calculation date - 1).
	 */
	double GetCashCollateralYesterdayInterest() const;

	/**
	 * Returns amount of interest paid today (based on calculation date).
	 */
	double GetCashCollateralInterestPaidToday() const;

	/**
	 * Returns name of the indicator used to compute given line values.
	 * In case where more than one indicator has been used, "N/A" is returned.
	 */
	inline const char* GetIndicatorName() const { return fIndicatorName; }

	/**
	 * Returns portfolio id (opcvm) for the margin calls.
	 */
	inline long GetPortfolioCode() const { return fPortfolioCode; }
	
	/**
	* Returns the value of the Haircut as used in the calculations.
	*/
	inline double GetHaircutForCalculation() const{ return fHaircutForCalculation;}

	/**
	 * Returns spot date of securities collateral
	 */
	inline long GetCollateralSpotDate() const { return fCollateralSpotDate; }

	/**
	* Returns flag whether spot date of securities collateral is up to date
	*/
	inline long GetCollateralSpotIsUptodate() const { return fCollateralSpotIsUptodate; }

	/**
	 * Returns forex of collateral
	 */
	inline double GetCollateralForex() const { return fCollateralForex; }

	/** 
	 * Return forex date of collateral
	 */
	inline long GetCollateralForexDate() const { return fCollateralForexDate; }

	/**
	* Returns flag whether forex date of collateral is up to date
	*/
	inline long GetCollateralForexIsUptodate() const { return fCollateralForexIsUptodate; }

	/**
	 * Returns the next dividend or coupon date for the collateral securities,
	 * according to the calculation date.
	 */
	inline long GetSecCollateralNextDividendCouponDate() const { return fSecCollateralNextDividendCouponDate; }

	/**
	 * Returns maturity of the position or collateral instrument.
	 */
	inline long GetMaturity() const { return fMaturity; }

	/**
	 * Returns true if given collateral is due for substitution.
	 */
	bool GetMakeSubstitutionState() const;

	/**
	 * Returns thirdparty owner of the collateral, or 0 if unspecified.
	 */
	long GetCollateralOwner() const;

	/**
	 * Returns counterparty to which given result maps to.
	 * For root result, returns counterparty as specified in the API request parameters.
	 */
	inline long GetCpty() const { return fCpty; }

	/**
	 * Returns entity to which given result maps to.
	 * For root result, returns entity as specified in the API request parameters.
	 */
	inline long GetEntity() const { return fEntity; }

	/**
	 * Returns convention to which given result maps to.
	 * For root result, returns convention as specified in the API request parameters.
	 */
	inline long GetConvention() const { return fConvention; }

protected:

	/**
	 * Sets key specific to this result.
	 */
	void SetKey(long cpty, long entity, long convention);

	/**
	 * Aggregates child values to the given result and propagates it to the parent.
	 */
	virtual void AddChildValues(const CSRCollateralResult *child);

protected:
	void Initialize(long cpty, long entity, long convention, ePoolResultLineType lineType = ePoolResultUndefined);
	void Initialize(const CSRCollateralPoolResult& copy);

	/** Instrument code (also known as sicovam). Together with line type identifies a result position
	 * in the result tree. */
	long fInstrumentCode;

	/** Internal, cash pool collateral information. */
	CashCollateral *fCashCollateral;

	/** Cash pool cash interest explanation list. */
	CSRCashInterestExplanationList *fCashPoolInterestExplanationList;

	/** Result currency which is also the currency of the Collateral Management Agreement. */
	long fRefCurrency;

	/** Risk value in Collateral Management Agreement currency (reference currency). */
	double fCollateralValueInRefCcy;

	/** Risk value in instrument (local) currency. */
	double fCollateralValueInInstrumentCcy;

	/** Depositary used for securities collateral transfer. Only applicable to sec pool. */
	long fDepositary;

	/** Depositary of the counterparty used for securities collateral transfer. Only applicable to sec pool. */
	long fDepositaryOfCpty;

	/** Settlement method used for securities collateral transfer. Only applicable to sec pool. */
	long fSettlementMethod;

	/** Delivery type used for securities collateral transfer. Only applicable to sec pool. */
	long fDeliveryType;

	/** Payment method used for securities collateral transfer. Only applicable to sec pool. */
	long fPaymentMethod;

	/** Haircut value as defined by the user. This may be different to the haircut value used for calculations. */
	double fHaircutInProduct;

	/** Clean spot. */
	double fSecCollateralSpot;

	/** Accrued for security collateral. Used to calculate dirty spot. */
	double fSecCollateralAccrued;

	/** Last margin call date. */
	long fLastMarginDate;

	/** Name of the indicator used to compute the value. */
	char fIndicatorName[cieIndicatorNameLength];

	/** Portfolio id for the margin calls. */
	long fPortfolioCode;

	/** number of collateral assets */
	double fSecCollateralQty;
	
	/** it's the actual value of the haircut used in the internal computations*/
	double fHaircutForCalculation;
	
	/** collateral spot date */
	long fCollateralSpotDate;

	/** Collateral spot	is up to date. 0 - not applicable, -1 - out of date, 1 - up to date*/
	long fCollateralSpotIsUptodate;

	/** collateral forex */
	double fCollateralForex;

	/** collateral forex date */
	long fCollateralForexDate;

	/** Collateral forex is up to date. 0 - not applicable, -1 - out of date, 1 - up to date*/
	long fCollateralForexIsUptodate;

	/** Next dividend or coupon date for the securities collateral. */
	long fSecCollateralNextDividendCouponDate;

	/** Maturity. */
	long fMaturity;

	/** Flags including if substitution is needed. */
	long fCallState;

	/** Counterparty to which this result maps to. */
	long fCpty;

	/** Entity to which this result maps to. */
	long fEntity;

	/** Convention to which this result maps to. */
	long fConvention;

private:

	static const char *__CLASS__;

	friend class CSRCollateralPoolReportingAPI;
	friend class CSRCollateralPoolExtraction;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif