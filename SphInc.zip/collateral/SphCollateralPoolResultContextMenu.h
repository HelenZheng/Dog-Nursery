#ifndef _SphCollateralPoolResultContextMenu_H_
#define _SphCollateralPoolResultContextMenu_H_

#include "SphInc/Collateral/SphCollateralResultContextMenu.h"

SPH_PROLOG
namespace sophis {

	namespace collateral {

		class CSRCollateralPoolResult;
		class CSRLBAgreement;

/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_COLLATERAL_POOL_RESULT_CONTEXT_MENU(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralPoolResultContextMenu)
#define CONSTRUCTOR_COLLATERAL_POOL_RESULT_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_POOL_RESULT_CONTEXT_MENU(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRCollateralPoolResultContextMenu::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_COLLATERAL_POOL_RESULT_CONTEXT_MENU(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass, name); \
	derivedClass::GetPrototype().GetData(name)->SetId(++sophis::collateral::CSRCollateralPoolResultContextMenu::fCount)


/**
 * Interface for creating custom context menu (explanation) dialogs in Collateral Pool Report GUI.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 5.3.2
 */
class SOPHIS_COLLATERAL_GUI CSRCollateralPoolResultContextMenu : public virtual CSRCollateralResultContextMenu
{
public:
	/** 
	 * {@link CSRCollateralResultContextMenu::IsAuthorized}
	 */
	virtual bool IsCollateralPoolResultAuthorized(const CSRCollateralReportContext &ctx, const CSRCollateralPoolResult& line) const = 0;

	/**
	 * {@link CSRCollateralResultContextMenu::DoCollateralResultContextMenu}
	 */
	virtual bool DoCollateralPoolResultContextMenu(const CSRCollateralReportContext &ctx, const CSRCollateralPoolResult& line) const = 0;

	/** 
	* {@link CSRCollateralResultContextMenu::IsEnabled}
	*/
	virtual bool IsCollateralPoolResultEnabled(const CSRCollateralReportContext &ctx, const CSRCollateralPoolResult& line) const { return true; }

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_POOL_RESULT_CONTEXT_MENU.
	 * {@link tools::CSRPrototype}
	 */
	static prototype& GetPrototype();

	/**
	 * Counts the number of prototypes installed and assigns each prototype a number in sequence.
	 * For internal use.
	 */
	static long fCount;

	/**
	 * Invokes IsCollateralPoolResultAuthorized().
	 */
	virtual bool IsAuthorized(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;

	/**
	 * Invokes DoCollateralPoolResultContextMenu().
	 */
	virtual bool DoCollateralResultContextMenu(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;

	/**
	* Invokes IsCollateralPoolResultEnabled().
	*/
	virtual bool IsEnabled(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralPoolResultContextMenu_H_
