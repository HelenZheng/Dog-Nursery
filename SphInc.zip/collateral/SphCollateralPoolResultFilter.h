#ifndef _SphCollateralPoolResultFilter_H_
#define _SphCollateralPoolResultFilter_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#define DECLARATION_COLLATERAL_POOL_RESULT_FILTER(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralPoolResultFilter)
#define CONSTRUCTOR_COLLATERAL_POOL_RESULT_FILTER(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_POOL_RESULT_FILTER(derivedClass)
#define	INITIALISE_COLLATERAL_POOL_RESULT_FILTER(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRCollateralPoolResult;

/**
 * Interface to filter results for Collateral Pool Calculation GUI.
 * To add a filter, derive this class, using the macro DECLARATION_COLLATERAL_POOL_RESULT_FILTER in your header
 * and INITIALISE_COLLATERAL_POOL_RESULT_FILTER in UNIVERSAL_MAIN.
 *
 * @version 5.3.2
 */
class SOPHIS_COLLATERAL CSRCollateralPoolResultFilter
{
public:
	/** Trivial Destructor. */
	virtual ~CSRCollateralPoolResultFilter() {}

	/** Typedef for the prototype : the key is a const char*. */
	typedef sophis::tools::CSRPrototype<CSRCollateralPoolResultFilter, const char *, sophis::tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_POOL_RESULT_FILTER
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/**
	 * To see if the given result should be excluded from the results.
	 * To be implemented by derived classes.
	 * @param poolResult Collateral Pool result line, corresponding to either
	 * cash pool or security pool collateral.
	 * @return true if the result must be excluded according to the filter; false if the result is valid.
	 */
	virtual bool IsExcluded(const CSRCollateralPoolResult& poolResult) const = 0;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralPoolResultFilter_H_
