#ifndef _SphCollateralReportingAPI_H_
#define _SphCollateralReportingAPI_H_

#include "SphInc/SphMacros.h" // For SOPHIS_COLLATERAL
#include "SphInc/tools/SphDescribable.h" // ISRDescribable

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

#ifdef GCC_XML
#define NULL 0
#endif

SPH_PROLOG
namespace sophis {

	namespace collateral {
		class CSRLBAgreement;
		class CSRCollateralResult;

/**
 * Interface for any API building hierarchical collateral reporting results.
 * @version 5.2.7.
 */
class SOPHIS_COLLATERAL ISRCollateralReportingAPI
{
public:
	/**
	 * Structure to allow for custom parameters to be passed to inside the report.
	 * @version 5.3.2
	 */
	struct SOPHIS_COLLATERAL SReportingParameters : public tools::ISRDescribable
	{
		SReportingParameters() : fFlags(0) {}
		SReportingParameters(const SReportingParameters& copy) : fFlags(copy.fFlags) {}
		virtual ~SReportingParameters() {}

		/** Flags indicating desired output. */
		long fFlags;

		/// See {@link ISRDescribable}
		virtual int GetFieldCount() const;
		/// See {@link ISRDescribable}
		virtual void GetField(int i, Field& field) const
			throw (InvalidRangeException);

		/** Clone. */
		virtual SReportingParameters* Clone() const { return new SReportingParameters(*this); }
	};

	/**
	 * Destructor.
	 * Deletes all internal results.
	 */
	virtual ~ISRCollateralReportingAPI() {}

	/**
	 * Builds a complete result hierarchy.
	 * @param lba Collateral Agreement to which deals must belong (map) to.
	 * @param calculationDate Reporting date (can be zero which means use the system date).
	 * @param crfFlags Flags indicating desired output.
	 */
	virtual void ComputeAll(const CSRLBAgreement *lba, long calculationDate, long crfFlags) = 0;

	/**
	 * Builds a complete result hierarchy.
	 * @param cpty Counterparty to which deals must belong (map) to.
	 * @param entity Entity to which deals must belong (map) to.
	 * @param convention Convention to which deal's instrument must belong (map) to.
	 * @param calculationDate Reporting date (can be zero which means use the system date).
	 * @param extraParams Pointer to structure containing extra reporting parameters.
	 * @version 5.3.2
	 */
	virtual void ComputeAll(long cpty, long entity, long convention, long calculationDate, SReportingParameters *extraParams = 0) = 0;

	/**
	 * Builds a result for a given position.
	 * @param lba Collateral Agreement to which deal must belong (map) to.
	 * @param calculationDate Reporting date (can be zero which means use the system date).
	 * @param mvtident Position Id (mvtident).
	 * @param crfFlags Flags indicating desired output.
	 */
	virtual void ComputeOne(const CSRLBAgreement *lba, long calculationDate, sophis::portfolio::PositionIdent mvtident, long crfFlags) = 0;

	/**
	 * Returns the result pointer which must not be deleted.
	 */
	virtual const CSRCollateralResult* GetResult() const = 0;

	/**
	 * Builds a dummy (blank) result tree that can be used to generate an XSD description.
	 * @param lba Collateral Agreement to which deal must belong (map) to.
	 * @param crfFlags Flags indicating desired output (-1 to indicate default, 0 to indicate minimum).
	 */
	virtual void ComputeDummy(const CSRLBAgreement *lba, long crfFlags = -1) = 0;

};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralReportingAPI_H_
