#ifndef _SphCollateralResult_H_
#define _SphCollateralResult_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(memory)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRLBAgreement;
typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;

/**
 * Base class for representing result tree various Collateral Calculation results.
 *
 * The result can be used individually, or to build a hierarchy window.
 * It contains pointer to the parent result which has its own values plus the aggregate of all children.
 * Similarly, each parent contains a list of children.
 *
 * @version 5.2.7
 */
class SOPHIS_COLLATERAL CSRCollateralResult
{
public:

	/**
	 * Constructor.
	 */
	CSRCollateralResult();

	/**
	* Constructor.
	* @param lba Collateral Agreement this result line references to.
	* @param lineType Line type.
	*/
	CSRCollateralResult(_STL::string modelName, const CSRLBAgreement *lba = 0, int lineType = 0);

	/**
	 * Copy Constructor.
	 * Performs a deep copy of all the data, including the children.
	 * Note: The parent is not set.
	 */
	CSRCollateralResult(const CSRCollateralResult& copy);

	/**
	 * Destructor. Also destroys all children.
	 */
	virtual ~CSRCollateralResult();

	/**
	 * Performs a deep copy (duplicates) the given result including all child
	 * results and details.
	 * This is useful to make a copy or in GUI mode for detaching explanation screens
	 * from the main collateral reporting calculation and results.
	 * Note that the returned duplicate does not have a parent.
	 * The caller takes ownership of the resulting object and must destroy it.
	 * This method may need to be overwritten in the derived class.
	 *
	 * @return Pointer to the new CSRCollateralResult object which is a duplicate (deep copy)
	 * of the existing one. Pointer must be deleted by the caller.
	 */
	virtual CSRCollateralResult* CloneCollat() const = 0;

	/**
	 * Returns pointer to the parent of the given result.
	 * May return NULL if the result has no parent.
	 * @return Pointer to the parent or NULL if the result has no parent.
	 */
	inline const CSRCollateralResult* GetParent() const { return fParent; }

	/**
	 * Returns reference to the root of the given result.
	 * In case a line has no parent, it returns reference to self, as it is the root.
	 * @return Reference to the root of the results tree.
	 */
	inline const CSRCollateralResult& GetMaster() const { return fParent ? fParent->GetMaster() : *this; }

	/**
	 * Adds a child to the given result.
	 * The result then becomes a parent and aggregates the whatever results of the children.
	 * The aggregation is then propagates to the current line parents etc. until it reaches
	 * the root of the tree.
	 */
	void AddChild(CSRCollateralResult *child);

	typedef _STL::vector<const CSRCollateralResult*> ChildrenVector;
	/**
	 * Returns the vector of children (vector may be empty).
	 * @return Vector of children.
	 */
	inline const ChildrenVector& GetChildren() const { return fChildrenList; }

	/**
	 * Returns children common line type if available.
	 * If the line has no children, the current line's type is returned.
	 * If and only if all children share the same line type, it is returned, otherwise 0 is returned.
	 *
	 * @return line type of the children if and only if all children share the same line type,
	 * otherwise 0.
	 */
	int GetChildrenLineType() const;

	/**
	 * In case of hierarchical result tree, searches through the hierarchy in an attempt to locate
	 * result of given type.
	 * @return First result matching the line type or null.
	 */
	const CSRCollateralResult* FindChildByType(int lineType) const;

	/**
	 * Returns line type of the current result.
	 */
	inline int GetLineType() const { return fLineType; }

	/**
	 * Copies the name of hierarchy into the name parameter. 
	 * Name parameter must point to preallocated area of memory.
	 */
	virtual void GetLineTypeName(char *name) const;

	/**
	 * Populates flat list view of given result and all child results.
	 */
	void GetFlatListView(_STL::vector<const CSRCollateralResult*> &flatList) const;

	/** 
	 * Gets Collateral Agreement of the context.
	 */
	const CSRLBAgreement* GetLBA() const;

	/**
	 * Gets Collateral Agreement of the context.
	 * @return shared pointer to the agreement.
	 */
	const CSRLBAgreementPtr& GetLBASafePtr() const;

	/**
	 * Returns model name used for this given result.
	 */
	_STL::string GetModelName() const { return fModelName; }

	/**
	 * Sorts children and all sub-children using the IsLower() method.
	 */
	void Sort();

	/**
	 * Compares two results. To be implemented in derived classes.
	 */
	virtual bool IsLower(const CSRCollateralResult& result1, const CSRCollateralResult& result2) const = 0;

	/**
	 * Returns instrument code to be used for instrument information (if applicable) for the current line.
	 * @return instrument code (sicovam) or 0 (default) if not applicable.
	 * @version 7.0
	 */
	virtual long GetInstrumentInformationCode() const;

	/**
	 * Returns the real counterparty of the position in the line (useful for multi-tier agreements).
	 * @since 6.3.2
	 */
	long GetRealCounterparty() const { return fRealCounterparty;}

	/**
	 * Returns the real entity of the position in the line (useful for multi-tier agreements).
	 * @since 6.3.2
	 */
	long GetRealEntity() const { return fRealEntity;}

	/**
	 * Set the real counterparty of the position in the line (useful for multi-tier agreements).
	 * @since 6.3.2
	 */
	void SetRealCounterparty(long cpty) { fRealCounterparty = cpty;}

	/**
	 * Set the real entity of the position in the line (useful for multi-tier agreements).
	 * @since 6.3.2
	 */
	void SetRealEntity(long entity) { fRealEntity = entity;}

	/**
	 * Set reporting date for the result.
	 * @param calculationDate Reporting date (can be zero which means use the system date).
	 * @version 7.1.1
	 */
	inline void SetCalculationDate(long calculationDate) { fCalculationDate = calculationDate; }

	/**
	 * Returns the result reporting date, if set.
	 * @version 7.1.1
	 */
	inline long GetCalculationDate() const { return fCalculationDate; }
        /** returns number of delivered instruments
    * @since 7.1.3
    **/
    inline double GetDeliveredInstrumentCount() const {return fDeliveredInstrumentCount;}
    
	/** sets number of delivered instruments
    * @since 7.1.3
    **/
    void SetDeliveredInstrumentCount(double count) {fDeliveredInstrumentCount = count;}

protected:
	/**
	 * Aggregates child values to the given result and propagates it to the parent.
	 */
	virtual void AddChildValues(const CSRCollateralResult *child);

	/**
	 * Sets line type of the current result.
	 */
	inline void SetLineType(int lineType) { fLineType = lineType; }

	/**
	 * Set this line result to reference to the given Collateral Agreement.
	 */
	void SetLBA(const CSRLBAgreement *lba);

	/**
	 * Set this line result to reference to the given Collateral Agreement.
	 */
	void SetLBA(const CSRLBAgreementPtr& lba);

	/**
	 * Set this line result to reference to the given Collateral Agreement.
	 */
	void SetLBA(long cpty, long entity, long convention);

	void Initialize(_STL::string modelName = "", const CSRLBAgreement *lba=0, int lineType = 0);
	void Initialize(const CSRCollateralResult& copy);

private:
	_STL::string fModelName;
	CSRCollateralResult *fParent;
	ChildrenVector fChildrenList;
	CSRLBAgreementPtr fLBA;
	int fLineType;
	long fRealCounterparty;
	long fRealEntity;
	long fCalculationDate; // reporting date, if set
    double fDeliveredInstrumentCount;

	static const char *__CLASS__;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
