#ifndef _SphCollateralResultContextMenu_H_
#define _SphCollateralResultContextMenu_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralResultColumn.h"

SPH_PROLOG
namespace sophis {

	namespace collateral {

		class CSRCollateralResult;
		class CSRLBAgreement;

class ISRSpecialCollateralResultContextMenuManager;

/**
 * Interface for creating custom context menu (explanation) dialogs in any of the Collateral calculation GUI.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 5.2.7
 */
class SOPHIS_COLLATERAL_GUI CSRCollateralResultContextMenu
{
public:

	/**
	 * Returns the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	void SetId(long id) const
	{
		(const_cast<CSRCollateralResultContextMenu*>(this))->fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototypeWithId<CSRCollateralResultContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
	 */
	static prototype& GetPrototype(const char *name);

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsAuthorized returns true, the key of the prototype (that is its name) is added in the context menu.
	 * Must be overloaded and implemented in custom classes.
	 * @param ctx Report context from where IsAuthorized() is being called.
	 * @param line The line from the Collateral calculation GUI on which the context menu is called.
	 * @return true to include the prototype in the context menu, false to skip it.
	 */
	virtual bool IsAuthorized(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const = 0;

	/** 
	* This function is called when opening the dynamic context menu. 
	* If IsEnabled returns true, the key of the prototype (that is its name) is enabled in the context menu.
	* User should generally override IsEnabled().
	* @param ctx Report context from where IsEnabled() is being called.
	* @param line The line from the Collateral calculation GUI on which the context menu is called.
	* @return true to enabled the prototype in the context menu, false to disable it.
	*/
	virtual bool IsEnabled(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const { return true; }

	/**
	 * Perform some action (like open a specific dialog) using the given results line.
	 * Must be overloaded and implemented in custom classes.
	 * @param ctx Report context from where DoCollateralResultContextMenu() is being called.
	 * @param line The line from the Collateral calculation GUI on which the context menu is called.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoCollateralResultContextMenu(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const = 0;

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }

	/**
	 * Allows to specify custom manager via which to invoke actions.
	 * By default no special manager is implemented.
	 */
	virtual ISRSpecialCollateralResultContextMenuManager* GetSpecialManager() const { return 0; }

protected:
	long fId;
};

/**
 * Interface to allow 'special' invocation of context menu actions via the manager.
 * Useful if you need to treat things somewhat differently or pass extra parameters to the call.
 * @version 5.3.3
 */
class ISRSpecialCollateralResultContextMenuManager
{
public:
	/**
	 * Called to process IsAuthorized() action on given menu and line.
	 */
	virtual bool IsAuthorized(const CSRCollateralResultContextMenu& menu, const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const = 0;

	/**
	 * Called to process DoCollateralResultContextMenu() action on given menu and line.
	 */
	virtual bool DoCollateralResultContextMenu(const CSRCollateralResultContextMenu& menu, const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const = 0;

	/**
	* Called to process IsEnabled() action on given menu and line.
	*/
	virtual bool IsEnabled(const CSRCollateralResultContextMenu& menu, const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const = 0;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralResultContextMenu_H_
