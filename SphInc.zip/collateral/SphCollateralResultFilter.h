#pragma once

#ifndef _SphCollateralResultFilter_H_
#define _SphCollateralResultFilter_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"


class CSWindHier;	// internal


SPH_PROLOG
namespace sophis {

	namespace collateral {

// forward declaration
class CSRCollateralResult;

/**
 * Interface to allow to interact between filter and hierarchical result window.
 * @version 5.3.6
 * @version 6.2.2
 */
class SOPHIS_COLLATERAL_GUI ISRCollateralResultFilterManager
{
public:
	/** Returns reporting date of the report. */
	virtual long GetReportingDate() const = 0;

	/** Returns the view window object, if applicable. */
	virtual const CSWindHier* GetWindHier() const = 0;
protected:
	virtual ~ISRCollateralResultFilterManager();
};

/**
 * Interface for creating custom filtering in any of the Collateral calculation GUI.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 *
 * @version 5.3.6
 * @version 6.2.2
 */
class SOPHIS_COLLATERAL_GUI CSRCollateralResultFilter
{
public:
	virtual ~CSRCollateralResultFilter();
	/** 
	 * Check if given result object should be displayed or not.
	 * Must be implemented in derived classes.
	 * @param mgr Window manager.
	 * @param result Result object to be or not to be displayed on the ui.
	 * @return true to hide from display; false to do nothing (keep).
	 */
	virtual bool IsExcluded(const ISRCollateralResultFilterManager& mgr, const CSRCollateralResult& result) const = 0;

	/**
	 * Must provide icon corresponding to the filter.
	 */
	virtual int GetIcon() const = 0;

	/**
	 * Clone method required by the prototype.
	 * Use DECLARATION_XXX_FILTER macro in the implementation of the derived class.
	 */
	virtual CSRCollateralResultFilter* Clone() const = 0;

	/**
	 * Checks if all the children of the given hierarchical result are also excluded by the filter.
	 * @param mgr Window manager.
	 * @param result Result object to be or not to be displayed on the ui.
	 * @return true if result is non-hierarchical node; otherwise check through all the children.
	 */
	virtual bool AreChildrenExcluded(const ISRCollateralResultFilterManager& mgr, const CSRCollateralResult & result) const;

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototypeWithId<CSRCollateralResultFilter, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_FILTER.
	 */
	static prototype& GetPrototype(const char *name);

	/**
	 * Returns the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	void SetId(long id) const
	{
		(const_cast<CSRCollateralResultFilter*>(this))->fId = id;
	}

protected:
	long fId;
};

	} // namespace collateral
} // namespace sophis


SPH_EPILOG
#endif // _SphCollateralResultFilter_H_
