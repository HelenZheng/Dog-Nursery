#ifndef _SphCollateralScheduler_H_
#define _SphCollateralScheduler_H_

#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/portfolio/SphCriteria.h"
#include "SphInc/collateral/SphLbaType.h"
#include "SphInc/collateral/SphCollateralEnums.h"

struct SSCellStyle;
union SSCellValue;
struct TLib;

SPH_PROLOG
namespace sophis {
	namespace collateral {

/// INTERNAL
struct SCollateralSchedulerValue;

/// Forward declaration
class CSRCollateralSchedulerResult;
class CSRCollateralSchedulerExtraction;

/**
 * Criteria to extract correct underlying from the instrument for Collateral Scheduler.
 * @since 5.3.4
 */
class SOPHIS_COLLATERAL CSRCollateralSchedulerCriteria : public virtual portfolio::CSRCriterium
{
public:
	DECLARATION_CRITERIUM(CSRCollateralSchedulerCriteria)
	CSRCollateralSchedulerCriteria();

	/// See {@link CSRCriterium::GetCode}
	virtual long GetCode(portfolio::SSReportingTrade* mvt) const;
	/// See {@link CSRCriterium::GetUnderlyingCode}
	virtual long GetUnderlyingCode(long code) const;
	/// See {@link CSRCriterium::GetName}
	virtual void GetName(long code, char* name) const;
	/// See {@link CSRCriterium::new_FieldElement}
	virtual gui::CSRElement* new_FieldElement(int i, gui::CSREditList* l, int nre, bool editable, const char* nameDB) const;
	/// See {@link CSRCriterium::GetIcone}
	virtual short GetIcon(long code) const;
	/// See {@link CSRCriterium::Initialize}
	virtual void Initialize(const CSRCriterium* rule);

	/** Sets a list of instruments to be specially handled, excluded or included.
	 * @param instruments Instruments list must be ordered for STL::binary_search to work. */
	void SetInstruments(const _STL::vector<long>& instruments);
	/** Specifies whether the instruments list must be excluded or included.
	 * By default the state is false, which means instruments specified via SetInstruments() are included. */
	void SetExcludeInstruments(bool state);

	/** INTERNAL. */
	long GetCode(portfolio::SSReportingTrade* mvt, TLib*& ph, CSRLbaType::eLbaType& lbaType) const;
public:
	DECLARATION_CASTAGE2

private:
	_STL::vector<long> fInstruments;
	bool fExcludeInstruments;
};

/**
 * Collateral Scheduler engine, parametrisation, and processing.
 * @since 5.3.4
 */
class SOPHIS_COLLATERAL CSRCollateralSchedulerEngine
{
protected:
	/** Internal. */
	CSRCollateralSchedulerEngine(_STL::shared_ptr<CSRCollateralSchedulerExtraction> extr);
public:

	/**
	 * Enum to specify type of result sought, with or without extra criteria.
	 */
	enum eCollateralSchedulerDisplay
	{
		/** Default is with user specified (complete) criteria and hierarchy. */
		kWithCriteria = 1,
		/** Only taking into account instrument and date and without additional (if any) criteria. */
		kWithoutCriteria,
	};

	CSRCollateralSchedulerEngine();
	~CSRCollateralSchedulerEngine();
	/**
	 * Creates new engine to invoke collateral scheduler reporting based on given 
	 * collateral scheduler extraction.
	 * @param extractionID ID of the portfolio extraction with model 'Collateral Scheduler'.
	 * @return engine pointer or null if the extraction is not found or of invalid model.
	 */
	static CSRCollateralSchedulerEngine* new_Engine(long extractionID);
	/**
	 * Creates new engine to invoke collateral scheduler reporting based on given
	 * collateral scheduler extraction.
	 * @param extr Extraction with model 'Collateral Scheduler'.
	 * @return engine pointer or null if the extraction is not found or of invalid model.
	 */
	static CSRCollateralSchedulerEngine* new_Engine(portfolio::PSRExtraction extr);

	/** Adds criteria to the report. The actual criteria used will be the cloned one.
	 * Must be called before ApplyCriteria() and before creation of extraction. */
	void AddCriteria(const portfolio::CSRCriterium& criteria);
	/** Adds criteria to the report. The name must be registered in CSRCriterium prototype.
	 * Must be called before ApplyCriteria() and before creation of extraction. */
	void AddCriteria(const char *name);
	/** Applies all criterias specified via AddCriteria() to the underlying report.
	 * Must be done before creation of extraction. */
	void ApplyCriteria();
	/** Sets a list of portfolio entry points. Must be done before the creation of extraction. */
	void SetEntryPoints(const _STL::vector<long>& entryPoints);
	/** Returns the list of specified portfolio entry points. */
	const _STL::vector<long>& GetEntryPoints() const;
	/** Specifies whether the portfolio entry points must be excluded or included.
	 * By default the state is false, which means folios specified via SetEntryPoints() are included. */
	void SetExcludeEntryPoints(bool state);
	/** Returns flag indicating whether the portfolio entry points are excluded or included.
	 * Default setting is false, which means folios specified via SetEntryPoints() are included. */
	bool GetExcludeEntryPoints() const;
	/** Sets a list of instruments to be specially handled  by the report. Must be done before the creation of extraction. */
	void SetInstruments(const _STL::vector<long>& instruments);
	/** Returns the list of instruments which are specially handled by the report. */
	const _STL::vector<long>& GetInstruments() const;
	/** Specifies whether the instruments list must be excluded or included.
	 * By default the state is false, which means instruments specified via SetInstruments() are included. */
	void SetExcludeInstruments(bool state);
	/** Returns flag indicating whether instruments list must be excluded or included. 
	 * Default setting is false, which means instruments specified via SetInstruments() are included.*/
	bool GetExcludeInstruments() const;
	/** Sets the SQL query for filter on deals. Must be done before the creation of extraction. */
	void SetQuery(const char *query);
	/** Sets name of the extraction. */
	void SetName(const char *name);
	/** Returns name of the extraction. */
	const char* GetName() const;
	/** Sets start date of the report processing. Only deals after start date are displayed on daily basis.
	 * Must be done before the creation of extraction. */
	void SetStartDate(long date);
	/** Returns start date of the report processing. Default is zero which defaults to gDateFinBase() during processing. */
	long GetStartDate() const;
	/** Sets end date (reporting date) of the report processing. Only deals until this date will be taken into account.
	 * Must be done before the creation of extraction. Default is zero which defaults to gDateFinBase() plus offset. */
	void SetEndDate(long date);
	/** Returns end date (reporting date) of the report processing. Only deals until this date will be taken into account.
	 * Default is gDateFinBase() plus offset. */
	long GetEndDate() const;

	/** Runs initial collateral scheduler extraction and reporting.
	 * @param endDate Optional, calls SetEndDate() before running the reporting.
	 * If endDate parameters is zero the system uses either a default end date one or one set earlier via SetEndDate(). */
	void DoCollateralScheduler(long endDate = 0);
	/** Updates collateral scheduler extraction and reporting.
	 * @param endDate Optional, calls SetEndDate() before running the reporting.
	 * If endDate parameters is zero the system uses either a default end date one or one set earlier via SetEndDate(). */
	void UpdateCollateralScheduler(long endDate = 0);

	inline portfolio::PSRExtraction GetExtraction() const { return fExtraction; }
	inline const CSRCollateralSchedulerResult* GetResult() const { return fResult; }
	
	/** Returns the selected CSRCollateralSchedulerResult object. It may return NULL.
	 * @param selected Optional, can be either kWithCriteria or kWithoutCriteria. */
	const CSRCollateralSchedulerResult* GetSelectedResult(eCollateralSchedulerDisplay selected = kWithCriteria) const;
	/** Returns the total number of criteria elements used by extraction.
	 * It includes the default criteria of instrument and date. */
	int GetNumCriteria() const;

protected:
	CSRCollateralSchedulerResult* new_CSRCollateralSchedulerResult();
	void InitCollateralSchedulerResult(CSRCollateralSchedulerResult& result, const portfolio::CSRPortfolio* portfolio, bool withCriteriaKey = true);

private:
	portfolio::PSRExtraction fExtraction;
	_STL::list<portfolio::CSRCriterium*> fCriteriaList;
	CSRCollateralSchedulerResult* fResult;
	CSRCollateralSchedulerResult* fResultWithoutCriteria;
	friend struct SCollateralSchedulerValue;
};


/**
 * Collateral Scheduler result object and tree.
 * @since 5.3.4
 */
class SOPHIS_COLLATERAL CSRCollateralSchedulerResult
{
public:
	/** Allows to split total number of securities between different sources. */
	enum eQuantityType
	{
		eqtTotal = 0,
		eqtBook,
		eqtSL,
		eqtCollateral,
		eqtLast,
	};

	/** Helps identify quantity source. */
	enum ePositionType
	{
		eptUnknown = 0,
		eptBook,
		eptSLPrincipal,
		eptCollateralPerContract,
		eptCollateralPool,
	};

public:
	/** Constructor. */
	CSRCollateralSchedulerResult();
	/** Copy Constructor. */
	CSRCollateralSchedulerResult(const CSRCollateralSchedulerResult& copy);
	/** Destructor. */
	~CSRCollateralSchedulerResult();
	/** Performs a deep copy (duplicates) the given result including all child
	 * results and details. */
	CSRCollateralSchedulerResult* Clone() const;

	/** Returns pointer to the parent of the given result. */
	inline const CSRCollateralSchedulerResult* GetParent() const { return fParent; }
	/** Returns reference to the root result. */
	inline const CSRCollateralSchedulerResult& GetRoot() const { return fParent ? fParent->GetRoot() : *this; }
	/** Adds a child to the given result. The result then becomes a parent and aggregates the whatever 
	 * results of the children. The aggregation is then propagates to the current line parents until 
	 * it reaches the root of the tree. */
	void AddChild(CSRCollateralSchedulerResult *child, bool recalculate);

	typedef _STL::vector<const CSRCollateralSchedulerResult*> ChildrenVector;
	/** Returns the vector of children (vector may be empty). */
	inline const ChildrenVector& GetChildren() const { return fChildrenList; }

	/** Sorts children and all sub-children using the IsLower() method. */
	void Sort();
	/** Compares two results. */
	bool IsLower(const CSRCollateralSchedulerResult& result1, const CSRCollateralSchedulerResult& result2) const;

	/** Returns extraction key corresponding to given result in the result hierarchy. */
	const portfolio::CSRExtractionKey* GetExtractionKey() const;

	/** Returns instrument code (sicovam) of the security to which this result belongs to.
	 * The code may different from the actual instrument code of the position. */
	long GetSecuritiesCode() const;

	/** Returns date to which the result values correspond to. May be zero for lines
	 * that do not correspond to any particular date. */
	long GetDate() const;

	/** Returns number of available securities for given date. */
	double GetQuantityTotal() const;

	/** Returns number of available securities of given source type for given date. */
	double GetQuantity(eQuantityType eqt) const;

	/** Returns change in total number of securities for given date. */
	double GetDeltaTotal() const;

	/** Returns change in number of securities of given source type for given date. */
	double GetDelta(eQuantityType eqt) const;

	/** Returns portfolio with details of deals and positions, when applicable. */
	const portfolio::CSRPortfolio* GetPortfolio() const;

	/** Returns position corresponding to given result, when applicable. */
	const portfolio::CSRPosition* GetPosition() const;

	/** Returns position id corresponding to given result, when applicable.
	 * For stock loan securities collateral, it returns position id of main deal,
	 * instead of the virtual id obtained via GetPosition(). */
	sophis::portfolio::PositionIdent GetPositionId() const;

	/** For stock loan and repo positions, returns refcon of initial stock loan contract. */
	sophis::portfolio::TransactionIdent GetStockLoanRepoInitialDeal() const;

	/** Returns type of quantities source for the postion representing given result. */
	ePositionType GetPositionType() const;

	/** Returns name of the result (folio or position) to be displayed. */
	const char* GetName() const;

	/** Returns the lending opportunity indicator specified by type. 
	 *  In case it shouldn't be displayed will return 0, to display '0' will return -1. 
	 *  @since 5.3.6
	 *  @param Type of indicator to return.
	 */
	double GetIndicator(eLOIndicators type) const;

	/** Sets the generation date. 
	 *  @since 5.3.6
	 *  @param Date to store in fGenerationDate.
	 **/
	inline void SetGenerationDate(long date) { fGenerationDate = date; }

protected:
	/** Aggregates child values to the given result and propagates it to the parent. */
	void AddChildValues(const CSRCollateralSchedulerResult *child);

	/** Recalculates totals and propagates to the children. */
	bool Recalculate(const CSRCollateralSchedulerResult *parent, double* gpquantities);

	/** INTERNAL. */
	SCollateralSchedulerValue* fValue;

	/** Date when the report has been generated */
	long fGenerationDate;


private:
	CSRCollateralSchedulerResult* fParent;
	ChildrenVector fChildrenList;
	friend class CSRCollateralSchedulerEngine;
	friend struct SCollateralSchedulerValue;
};

/**
 * Macros for handling Collateral Scheduler report column prototype implementation.
 * @since 5.3.4
 */
#define DECLARATION_COLLATERAL_SCHEDULER_REPORT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralSchedulerReportColumn)
#define CONSTRUCTOR_COLLATERAL_SCHEDULER_REPORT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_SCHEDULER_REPORT_COLUMN(derivedClass)
#define	INITIALISE_COLLATERAL_SCHEDULER_REPORT_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Collateral Scheduler report column and prototype.
 * @since 5.3.4
 */
class SOPHIS_COLLATERAL CSRCollateralSchedulerReportColumn
{
public:
	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param result Collateral Scheduler result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCell(const CSRCollateralSchedulerResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Returns the default cell size in pixels.
	 */
	virtual short GetDefaultWidth() const;

	/**
	 * Returns the id.
	 * The value is created at the end of the initialise because it must
	 * be unique according to the table COLUMN_NAME.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * Used when building the columns by {@link CSUReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototypeWithId<CSRCollateralSchedulerReportColumn, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_COLLATERAL_SCHEDULER_REPORT_COLUMN
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/**
	 * Fills cell value and style with given quantity in given currency.
	 * Useful for GUI display.
	 * @param x Quantity in given currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the instrument for the quantity.
	 */
	static void FillQuantity(double x, SSCellValue *value, SSCellStyle *style, long ccy);

	/**
	 * Fills cell value and style with string representation of given currency.
	 * Useful for GUI display.
	 * @param ccy Currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillCurrency(long ccy, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills cell value and style with given date.
	 * Useful for GUI display.
	 * @param date Date to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills style for display of a double value.
	 * Useful for GUI display.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the double value.
	 * @param dec Number of decimals to be displayed.
	 */
	static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

protected:
	long	fId;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphCollateralScheduler_H_
