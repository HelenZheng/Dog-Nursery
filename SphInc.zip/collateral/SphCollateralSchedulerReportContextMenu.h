#ifndef _SphCollateralSchedulerReportContextMenu_H_
#define _SphCollateralSchedulerReportContextMenu_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis {

	namespace collateral {

		class CSRCollateralSchedulerResult;
		class CSRCollateralSchedulerEngine;


/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_COLLATERAL_SCHEDULER_REPORT_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralSchedulerReportContextMenu)
#define CONSTRUCTOR_COLLATERAL_SCHEDULER_REPORT_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_COLLATERAL_SCHEDULER_REPORT_CONTEXT_MENU(derivedClass)
#define	INITIALISE_COLLATERAL_SCHEDULER_REPORT_CONTEXT_MENU(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name); derivedClass::GetPrototype().GetData(name)->SetId(++sophis::collateral::CSRCollateralSchedulerReportContextMenu::fCount)

/**
 * Interface for creating custom context menu in Collateral 
 * Scheduler Report window.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 5.3.4
 */
class SOPHIS_COLLATERAL_GUI CSRCollateralSchedulerReportContextMenu
{
public:

	/**
	 * Returns the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	void SetId(long id) const
	{
		(const_cast<CSRCollateralSchedulerReportContextMenu*>(this))->fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototypeWithId<CSRCollateralSchedulerReportContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class 
	 * INITIALISE_COLLATERAL_SCHEDULER_REPORT_CONTEXT_MENU.
	 */
	static prototype& GetPrototype();

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsAuthorized returns true, the key of the prototype (that is its name) is added in the context menu.
	 * Must be overloaded and implemented in custom classes.
	 * @return true to include the prototype in the context menu, false to skip it.
	 */
	virtual bool IsAuthorized(const CSRCollateralSchedulerEngine& engine, const CSRCollateralSchedulerResult& result) const = 0;

	/** 
	* This function is called when opening the dynamic context menu. 
	* If IsEnabled returns true, the key of the prototype (that is its name) is enabled in the context menu.
	* Must be overloaded and implemented in custom classes.
	* @return true to enable the prototype in the context menu, false to disable it.
	*/
	virtual bool IsEnabled(const CSRCollateralSchedulerEngine& engine, const CSRCollateralSchedulerResult& result) const { return true; }

	/**
	 * Perform some action (like open a specific dialog) using the given results line.
	 * Must be overloaded and implemented in custom classes.
	 * @param menuLabel The actual context menu label that was selected.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoContextMenu(const CSRCollateralSchedulerEngine& engine, const CSRCollateralSchedulerResult& result, _STL::string& menuLabel) const = 0;

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }

	/**
	* Counts the number of prototypes installed and assigns each prototype a number in sequence.
	* For internal use.
	*/
	static long fCount;

protected:
	long fId;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralSchedulerReportContextMenu_H_
