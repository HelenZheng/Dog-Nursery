#ifndef _SphCommissionExplanation_H_
#define _SphCommissionExplanation_H_

#include "SphInc/SphMacros.h" // For SOPHIS_COLLATERAL
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class CSRCollateralResult;
		class CSRLBAgreement;
		union FredReportingData;

/**
 * Macro to be used instead of the Clone() method in the clients classes derived from CSRCommissionExplanation.
 * Clone() method duplicates the given explanation (deep copy).
 * The caller of the Clone() takes ownership of the resulting object and must destroy it.
 *
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_COMMISSION_EXPLANATION(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRCommissionExplanation)

/**
 * Macro to be used instead of the Clone() and CreateInstance() methods 
 * in the clients classes derived from CSRCommissionExplanationList.
 * 
 * Clone() method duplicates the given explanation list (deep copy), including each individual explanation.
 * Clone() is useful, for example, in GUI mode for detaching explanation screens
 * from the main collateral reporting calculation and results.
 * 
 * CreateInstance() method returns an empty copy of the list.
 *
 * In either case the caller takes ownership of the resulting object and must destroy it.
 *
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_COMMISSION_EXPLANATION_LIST(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRCommissionExplanationList) \
	virtual CSRCommissionExplanationList* CreateInstance() const { return new derivedClass; }


		/**
		 * Represents a particular commission explanation detail which is available as part of collateral reporting.
		 * @version 5.3.
		 */
		class SOPHIS_COLLATERAL CSRCommissionExplanation
		{
		public:

			/**
			 * Constructor.
			 */
			CSRCommissionExplanation();

			/**
			 * Copy Constructor.
			 */
			CSRCommissionExplanation(const CSRCommissionExplanation& src);

			/**
			 * Destructor.
			 */
			virtual ~CSRCommissionExplanation();

			DECLARATION_COMMISSION_EXPLANATION(CSRCommissionExplanation)

			/**
			 * Returns stock loan or repo instrument id for which commission explanation is provided.
			 * This information can be used to retrieve commission type or other 
			 * commission calculation related values.
			 */
			inline long GetLoanAndRepoCode() const { return fLoanAndRepoCode; }

			/**
			 * Sets the stock loan or repo instrument code for the explanation.
			 */
			inline void SetLoanAndRepoCode(long code) { fLoanAndRepoCode = code; }

			/**
			 * Returns the start date of the commission calculation period.
			 * The date refers to when principal quantity, commission rate, principal spot change.
			 */
			inline long GetStartDate() const { return fStartDate; }

			/**
			 * Sets a start date of the commission calculation period.
			 * @param startDate Start Date.
			 */
			inline  void SetStartDate(long startDate) { fStartDate=startDate; }

			/**
			 * Returns the end date of the commission calculation period.
			 */
			inline  long GetEndDate() const { return fEndDate; }

			/**
			 * Sets an end date of the commission calculation period.
			 * @param endDate Start Date.
			 */
			inline  void SetEndDate(long endDate) { fEndDate=endDate; }

			/**
			 * Returns the principal amount value used for commission calculation in billing currency.
			 */
			inline  double GetPrincipalAmountInBillingCurrency() const { return fPrincipalAmountInBillingCurrency; }

			/**
			 * Sets a principal amount value used for commission calculation in billing currency.
			 * @param amount Principal amount in billing currency.
			 */
			inline  void SetPrincipalAmountInBillingCurrency(double amount) { fPrincipalAmountInBillingCurrency=amount; }

			/**
			 * Returns the principal amount value used for commission calculation in principal currency.
			 */
			inline double GetPrincipalAmountInPrincipalCurrency() const { return fPrincipalAmountInPrincipalCurrency; }

			/**
			 * Sets a principal amount value used for commission calculation in principal currency.
			 * @param amount Principal amount in principal currency.
			 */
			inline void SetPrincipalAmountInPrincipalCurrency(double amount) { fPrincipalAmountInPrincipalCurrency=amount; }

			/**
			 * Returns the commission rate used for calculation.
			 */
			inline double GetCommissionRate() const { return fCommissionRate; }

			/**
			 * Sets a commission rate used for calculation.
			 * @param rate Commission rate.
			 */
			inline void SetCommissionRate(double rate) { fCommissionRate=rate; }

			/**
			 * Returns the commission (fees due) calculated between start and end dates.
			 */
			inline double GetCommissionAmount() const { return fCommission; }

			/**
			 * Sets a commission (fees due) calculated between start and end dates.
			 * @param commission Commission amount.
			 */
			inline void SetCommissionAmount(double commission) { fCommission=commission; }

			/**
			 * Returns the date that represents the principal spot and forex.
			 */
			inline long GetSpotDate() const { return fSpotDate; }

			/**
			 * Sets a date that was used to calculate the principal spot and forex.
			 * @param spotDate Date that represents principal spot and forex values.
			 */
			inline void SetSpotDate(long spotDate) { fSpotDate=spotDate; }

			/**
			 * Returns the principal spot used to calculate the principal amount.
			 * The spot value is in principal currency.
			 */
			inline double GetPrincipalSpot() const { return fSpot; }

			/**
			 * Sets a principal spot used to calculate the principal amount.
			 * @param spot Spot value in principal currency.
			 */
			inline void SetPrincipalSpot(double spot) { fSpot=spot; }

			/**
			 * Returns the quantity of principal stock lent or borrowed.
			 */
			inline double GetPrincipalQuantity() const { return fQuantity; }

			/**
			 * Sets a quantity of principal stock lent or borrowed.
			 * @param quantity Quantity of principal stock.
			 */
			inline void SetPrincipalQuantity(double quantity) { fQuantity=quantity; }

			/**
			 * Returns the forex between principal currency and billing currency.
			 * Use CSRForexSpot::GetForexInverse to display it.
			 */
			inline double GetForexForCommission() const { return fForexForCommission; }

			/**
			 * Sets a forex between principal currency and billing currency.
			 * @param fx Forex Spot between principal currency and billing currency.
			 */
			inline void SetForexForCommission(double fx) { fForexForCommission=fx; }

			/**
			 * Returns the currency of the principal.
			 */
			inline long GetPrincipalCurrency() const { return fPrincipalCurrency; }

			/**
			 * Sets a currency of the principal.
			 * @param ccy Principal currency (sicovam).
			 */
			inline void SetPrincipalCurrency(long ccy) { fPrincipalCurrency=ccy; }
			
			/**
			 * Returns the fixing (commission) currency (if different than principal currency).
			 */
			inline long GetFixingCurrency() const { return fFixingCurrency; }
			
			/**
			 * Sets currency of the fixings.
			 * @param ccy Fixing currency (sicovam).
			 */
			inline void SetFixingCurrency(long ccy) { fFixingCurrency =ccy; }

			/**
			 * Returns the billing (commission) currency.
			 */
			inline long GetBillingCurrency() const { return fBillingCurrency; }

			/**
			 * Sets a billing (commission) currency.
			 * @param ccy Billing (commission) currency (sicovam).
			 */
			inline void SetBillingCurrency(long ccy) { fBillingCurrency=ccy; }

			/**
			* Returns commission paid today
			*@version 5.3.2
			*/
			inline double GetCommissionPaidToday() const { return fCommissionPaidToday; }
			
			/**
			* Sets commission paid today
			*@version 5.3.2
			*/
			inline void SetCommissionPaidToday(double commissionPaid) { fCommissionPaidToday = commissionPaid; }
			
			/**
			* Returns commission paid on SettlementDate
			*@version 5.3.2
			*/
			inline long GetCommissionPaidSettlementDate() const { return fCommissionSettlementDate; }
			
			/**
			* Sets commission paid on SettlementDate
			*@version 5.3.2
			*/
			inline void SetCommissionPaidSettlementDate(long commissionSettlementDate) { fCommissionSettlementDate = commissionSettlementDate; }

			/**
			 * Returns if the commission is collateralised.
			 * It is controlled by the corresponding Collateral Agreement.
			 */
			inline bool GetIsCommissionCollateralised() const { return fIsCommissionCollateralised; }

			/**
			 * Sets flag if commission value is collateralised, which is usually set according to the Collateral Agreement.
			 * @param isCollateralised True or false.
			 */
			inline  void SetIsCommissionCollateralised(bool isCollateralised) { fIsCommissionCollateralised = isCollateralised; }

			/**
			 * Returns the collateralised principal amount value used for collateralised commission calculation in billing currency.
			 */
			inline  double GetPrincipalCollateralisedAmountInBillingCurrency() const { return fPrincipalCollateralisedAmountInBillingCurrency; }

			/**
			 * Sets a collateralised principal amount value used for collateralised commission calculation in billing currency.
			 * @param amount Collateralised principal amount in billing currency.
			 */
			inline  void SetPrincipalCollateralisedAmountInBillingCurrency(double amount) { fPrincipalCollateralisedAmountInBillingCurrency=amount; }

			/**
			 * Returns the collateralised principal amount value used for collateralised commission calculation in principal currency.
			 */
			inline double GetPrincipalCollateralisedAmountInPrincipalCurrency() const { return fPrincipalCollateralisedAmountInPrincipalCurrency; }

			/**
			 * Sets a collateralised principal amount value used for collateralised commission calculation in principal currency.
			 * @param amount Collateralised principal amount in principal currency.
			 */
			inline void SetPrincipalCollateralisedAmountInPrincipalCurrency(double amount) { fPrincipalCollateralisedAmountInPrincipalCurrency=amount; }

			/**
			 * Returns the non-collateralised commission (fees due) calculated between start and end dates.
			 */
			inline double GetCommissionNonCollateralisedAmount() const { return fCommissionNonCollateralised; }

			/**
			 * Sets a non-collateralised commission (fees due) calculated between start and end dates.
			 * @param commission Non-collateralised commission amount.
			 */
			inline void SetCommissionNonCollateralisedAmount(double commission) { fCommissionNonCollateralised=commission; }

			/**
			 * Returns commission amount in principal currency before any rounding.
			 * @version 7.1.1
			 */
			inline double GetCommissionUnroundedAmount() const { return fCommissionUnroundedAmount; }

			/**
			 * Set commission amount in principal currency before any rounding.
			 * @version 7.1.1
			 */
			inline void SetCommissionUnroundedAmount(double amount) { fCommissionUnroundedAmount = amount; }

			/**
			 * Returns unique id of agreement to which the contract and its explanation belongs to.
			 * @version 7.1.1
			 */
			inline long GetAgreementId() const { return fAgreementId; }

			/** 
			 * Set the agreement id.
			 * @version 7.1.1
			 */
			inline void SetAgreementId(long agreementId) { fAgreementId = agreementId; }

			/** Update a detailed explanation.
			This is called by {@link CSRCommissionExplanationList::DetailedExplanation} 
			for each element day by day.
			*/
			virtual void UpdateDetailed(long day);

			/**
			 * Indicates if given line is not an explanation line, but rather a totals line.
			 * @version 7.1.1
			 */
			bool IsTotalsLine() const;

			/** 
			 * Returns Price for Commission
			 * @version 7.1.2
			 */
			inline double GetCommissionPrice() const { return fCommissionPrice; }

			/** 
			 * Sets Price for Commission
			 * @version 7.1.2
			 */
			inline void SetCommissionPrice(double commissionPrice) { fCommissionPrice = commissionPrice; }

		private:
			long fLoanAndRepoCode;
			long fStartDate;
			long fEndDate;
			double fPrincipalAmountInBillingCurrency;
			double fPrincipalAmountInPrincipalCurrency;
			double fCommissionRate;
			double fCommission;
			long fSpotDate;
			double fSpot;
			double fQuantity;
			double fForexForCommission;
			long fPrincipalCurrency;
			long fBillingCurrency;
			long fFixingCurrency;
			double fCommissionPaidToday;
			long fCommissionSettlementDate;
			bool fIsCommissionCollateralised;
			double fPrincipalCollateralisedAmountInBillingCurrency;
			double fPrincipalCollateralisedAmountInPrincipalCurrency;
			double fCommissionNonCollateralised;
			double fCommissionUnroundedAmount;
			long fAgreementId;
			double fCommissionPrice;
		};


		/**
		 * Represents commission explanation details which are available as part of collateral reporting.
		 * These details are usually associated with a particular securities lending/borrowing position.
		 *
		 * @version 5.3
		 */
		class SOPHIS_COLLATERAL CSRCommissionExplanationList : public _STL::vector<const CSRCommissionExplanation*>
		{
		public:

			/**
			 * Trivial constructor.
			 */
			CSRCommissionExplanationList();

			/**
			* Copy constructor.
			*/
			CSRCommissionExplanationList(const CSRCommissionExplanationList &src);

			/**
			 * Destructor.
			 * Invokes DeleteAll() to delete all the details including those in the list.
			 */
			virtual ~CSRCommissionExplanationList();

			DECLARATION_COMMISSION_EXPLANATION_LIST(CSRCommissionExplanationList)

			/**
			 * Creates new commission explanation element.
			 */
			virtual CSRCommissionExplanation* new_CSRCommissionExplanation() const;

			/** FOR INTERNAL USE ONLY.
			 * Computes custom values for the result based on given reporting data.
			 * Deletes all existing values from the list.
			 * @param result Result to which the explanation corresponds to.
			 * @param reportingData Low-level reporting data.
			 * @param calcualtionDate Reporting date.
			 * @param lba Collateral Agreement.
			 */
			void Compute(const CSRCollateralResult &result, 
				const FredReportingData &reportingData, long calculationDate, const CSRLBAgreement *lba);

			/**
			 * Deletes all the details including those in the list.
			 */
			virtual void DeleteAll();

			/**
			 * Adds an explanation record to the list.
			 * Can be overwritten by the clients if they want to use
			 * default computation but still add some values to the explanation.
			 */
			virtual void AddCommissionExplanation(CSRCommissionExplanation *expl);

			/** Provide a detailed explanation for floating commission.
			This is used when a detailed explanation in the guy is asked .
			The standard one is called and then this method is called to get more explanation.
			By default, create a new instance and then loop on the vector; for each element 
			break down by day and call {@link CSRCommissionExplanation::UpdateDetailed} before adding it.
			@return a new pointer which must be deleted.
			*/
			virtual CSRCommissionExplanationList*	DetailedExplanation() const;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCommissionExplanation_H_
