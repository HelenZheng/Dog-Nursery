/*
 	File:		SphCreditCallFrequency.h
 
 	Contains:	
               
 
 	Copyright:	� 2001-2004 Sophis.
*/

#pragma once

#ifndef _SphCreditCallFrequency_h_
#define _SphCreditCallFrequency_h_

#include "SphInc/SphMacros.h"

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"


SPH_PROLOG
namespace sophis
{
    namespace static_data
	{
	   class CSRCalendar;
    }

	namespace collateral
	{
		/*
		*	Macro to be used instead of the Clone() method in the clients derived classes.
		*	Prototype framework will be responsible to instantiate clients objects.
		*	
		*	@param derivedClass is the name of the client derived class.
		*/
#define DECLARATION_CREDIT_CALL_FREQUENCY(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCreditCallFrequency)

#define CONSTRUCTOR_CREDIT_CALL_FREQUENCY(derivedClass)
#define WITHOUT_CREDIT_CALL_FREQUENCY(derivedClass)

		/** macro used for installing the edit model in Risk
		@param derivedClass is the type of model derived from CSREditModel
		@param name is the name of this model which will be used to store it in 
		database and for building menu of all edit models
		*/

#define	INITIALISE_CREDIT_CALL_FREQUENCY(derivedClass, name) \
	CSRCreditCallFrequency::sOrderIndex.insert(_STL::make_pair<_STL::string, CSRCreditCallFrequency::tOrder>(name, CSRCreditCallFrequency::sInstallOrder++)); \
	INITIALISE_PROTOTYPE(derivedClass, name)

		SPH_BEGIN_NOWARN_EXPORT
        class SOPHIS_FIT CSRCreditCallFrequency
		{
		public:

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_CREDIT_RISK_CALC_MODEL.
			@see tools::CSRPrototype
			*/
			virtual CSRCreditCallFrequency* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			
			typedef long tOrder;
			static tOrder sInstallOrder;
			static _STL::map<_STL::string, tOrder> sOrderIndex; 

			struct SOPHIS_FIT order_as_installed
			{
				bool operator()(const char * x, const char * y) const;
			};

			typedef sophis::tools::CSRPrototype<CSRCreditCallFrequency,
												const char*,
												order_as_installed> prototype;
												
			/** Access to the prototype singleton.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
	
			/** Get the next date from the frequency.
			@param refDate is a date.
			@param cal is a calendar to use. May be null.
			@return the next date (refDate excluded).
			*/
			virtual long GetNextDate(long refDate, const static_data::CSRCalendar * calendar) const = 0;

			/** Get the previous date from the frequency.
			@param refDate is a date.
			@param cal is a calendar to use. May be null.
			@return the previous date (refDate excluded).
			*/
			virtual long GetDateBefore(long refDate, const static_data::CSRCalendar * calendar) const = 0;

			virtual bool doesDateMatchFrequency(long refDate, const static_data::CSRCalendar * calendar) const;

			/** Get the credit call frequency.
			@param id is a frequency id.
			@return a pointer which must not be deleted.
			@throws CSRPrototype::ExceptionNotFound if id does not match with any id.
			*/
			static const CSRCreditCallFrequency & GetInstance(long id);

 			/** Get the id (instrument type).
			The value is created at the end of the initialise because it must
			be calculated according the table instrument type.
			*/
			int GetId() const
			{
				return fId;
			}


 			/** Set the id.
			Used when building the columns by {@link CSUReorderColumns}
			*/
			void SetId(long id)
			{
				fId = id;
			}

      protected:
			long	fId;
		};
		SPH_END_NOWARN_EXPORT
	}
}

SPH_EPILOG


#endif // _SphCreditCallFrequency_h_

