#ifndef _FEEMARK_H_
#define _FEEMARK_H_
#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(set)

SPH_PROLOG
namespace sophis
{
	namespace collateral
	{
		/**
			Interface to access FeeMark data
		*/
		class SOPHIS_COLLATERAL IFeeMark
		{
		public:
			virtual IFeeMark* Clone() const = 0;

			virtual void SetDate(long date) = 0;
			virtual void SetSpot(double spot) = 0;
			virtual void SetCurrency(long currency) = 0;
			virtual void SetType(long type) = 0;
			virtual void SetInsertType(long type) = 0;
			virtual void SetFx(double fx) = 0;			
			virtual void SetTradeId(long long id) = 0;

			virtual long GetDate() const = 0;
			virtual double GetSpot() const = 0;
			virtual double GetFx() const = 0;
			virtual long long GetTradeId() const = 0;
			virtual long GetCurrency() const = 0;
			virtual long GetUserId() const = 0;
			virtual long GetInstrumentId() const = 0;
			virtual long GetEntity() const = 0;
			virtual long GetCounterparty() const = 0;
			virtual long GetPerimeter() const = 0;
			virtual long GetPositionId() const = 0;
			virtual long GetType() const = 0;
			virtual long GetInsertType() const = 0;
		};

		/**
			Wrapper to IFeeMark 
			This is used to manage IFeeMark lifecycle in both native and managed environment
			It shouldn't be extended or modified.
		*/
		class SOPHIS_COLLATERAL FeeMarkWrapper : public IFeeMark
		{
		public:
			FeeMarkWrapper();
			FeeMarkWrapper(IFeeMark* mark);
			IFeeMark& Get() const;
			void Set(IFeeMark* mark); 
			void operator=(const IFeeMark& mark);
			bool operator<(const FeeMarkWrapper&) const;
			
			virtual IFeeMark* Clone() const OVERRIDE;

			virtual void SetDate(long date) OVERRIDE;
			virtual void SetSpot(double spot) OVERRIDE;
			virtual void SetCurrency(long currency) OVERRIDE;
			virtual void SetType(long type) OVERRIDE;
			virtual void SetInsertType(long type) OVERRIDE;
			virtual void SetFx(double fx) OVERRIDE;			
			virtual void SetTradeId(long long id) OVERRIDE;

			virtual long GetDate() const OVERRIDE;
			virtual double GetSpot() const OVERRIDE;
			virtual double GetFx() const OVERRIDE;
			virtual long long GetTradeId() const OVERRIDE;
			virtual long GetCurrency() const OVERRIDE;
			virtual long GetUserId() const OVERRIDE;
			virtual long GetInstrumentId() const OVERRIDE;
			virtual long GetEntity() const OVERRIDE;
			virtual long GetCounterparty() const OVERRIDE;
			virtual long GetPerimeter() const OVERRIDE;
			virtual long GetPositionId() const OVERRIDE;
			virtual long GetType() const OVERRIDE;
			virtual long GetInsertType() const OVERRIDE;

		private:
			_STL::shared_ptr<IFeeMark> self;
		};
		
		/**
			Filter used in FeeMarkCollection to specify which fee marks should be loaded
		*/
		class SOPHIS_COLLATERAL FeeMarkScope
		{
		public:
			FeeMarkScope();
			FeeMarkScope(long entity, long counterparty, long perimeter);
			FeeMarkScope(long positionid);
			FeeMarkScope Type(long type);
			FeeMarkScope InsertType(long type);
			FeeMarkScope Instrument(long instrumentId);
			FeeMarkScope Currency(long currency);
			FeeMarkScope MaxDate(long date);
			FeeMarkScope Trade(long long tradeId);

			bool Accept(FeeMarkWrapper mark) const;

			_STL::set<long> GetInstrumentId() const;
			long GetEntity() const;
			long GetCounterparty() const;
			long GetPerimeter() const;
			long GetPositionId() const;
			long GetCurrency() const;
			long GetType() const;
			long GetInsertType() const;
			long GetMaxDate() const;
			long long GetTradeId() const;

		private:
			_STL::set<long> instrumentId;
			long positionId;
			long entity;
			long counterparty;
			long perimeter;
			long currency;
			long type;
			long insertType;
			long dateMax;
			long long tradeId;
		};

		/**
			Main class to access and handle Fee Marks
			
			- GetInstance can be used to inject an implementation of IFeeMarkCollection
			- GetOneInstance() should be used to get a non-const instance (that will have to be deleted!)
		*/
		class SOPHIS_COLLATERAL IFeeMarkCollection 
		{
		public:
			/**
				Get/Register a const IFeeMarkCollection instance
			*/
			static const IFeeMarkCollection& GetInstance(IFeeMarkCollection* instance = nullptr);
			
			/**
				Get a non-const instance of IFeeMarkCollection
				Don't forget to delete it after usage
			*/
			static IFeeMarkCollection* GetOneInstance(); 

			/**
				Clone IFeeMarkCollection instance
			*/
			virtual IFeeMarkCollection* Clone() const = 0;
			
			/**
				Get (fetch) existing fee marks for a given filter
			*/
			virtual void Get(const FeeMarkScope& filter, _STL::vector<FeeMarkWrapper>& out) const = 0;

			/**
				Tag a fee mark for save (insert/update)
			*/
			virtual FeeMarkWrapper AddOrUpdate(FeeMarkWrapper mark) = 0;
			
			/**
				Create a new fee mark per agreement
			*/
			virtual FeeMarkWrapper AddOrUpdate(long entity, long counterparty, long perimeter, long instrumentId) = 0;
			
			/**
				Create a new fee mark per position
			*/
			virtual FeeMarkWrapper AddOrUpdate(long positionid, long instrumentId) = 0;

			/**
				Tag a fee mark 'to be deleted'
			*/
			virtual void Remove(FeeMarkWrapper mark) = 0;
			
			/**
				This method will remove Fee marks tagged 'to remove' using Remove method, 
				and save (insert/update) Fee marks tagged 'to add' using AddOrUpdate method.
				
				No commit is done inside this, so you will have to commit after using it.
			*/
			virtual void Save() = 0;
		};
	}
}
SPH_EPILOG

#endif // _FEEMARK_H_