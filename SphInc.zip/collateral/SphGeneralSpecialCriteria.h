#ifndef _SphGeneralSpecialCriteria_H
#define _SphGeneralSpecialCriteria_H

#include "SphInc\gui\SphElement.h"
#include "SphInc/portfolio/SphCriteria.h"
#include "SphLLInc/interface/CustomMenu.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class SOPHIS_COLLATERAL CSRDateOfNextCouponCriteria : public virtual portfolio::CSRCriterium
		{
		public:
			DECLARATION_CRITERIUM_WITH_CAPS(CSRDateOfNextCouponCriteria, false, true, false)

			CSRDateOfNextCouponCriteria();
			virtual void GetCode(const sophis::portfolio::CSRPosition& position, TCodeList& list) const;
			virtual sophis::gui::CSRElement* new_FieldElement(int i, sophis::gui::CSREditList* l, int nre, bool editable, const char* nameDB) const;
			bool less(long code1, long code2) const;
		};

		class SOPHIS_COLLATERAL CSRDaysUntilNextCouponCriteria : public virtual portfolio::CSRCriterium
		{
		public:
			DECLARATION_CRITERIUM_WITH_CAPS(CSRDaysUntilNextCouponCriteria, false, true, false)

			CSRDaysUntilNextCouponCriteria();
			virtual void GetCode(const sophis::portfolio::CSRPosition& position, TCodeList& list) const;
			virtual sophis::gui::CSRElement* new_FieldElement(int i, sophis::gui::CSREditList* l, int nre, bool editable, const char* nameDB) const;
		};

		class SOPHIS_COLLATERAL CSRRepoRateCriteria : public virtual portfolio::CSRCriterium
		{
		public:
			DECLARATION_CRITERIUM_WITH_CAPS(CSRRepoRateCriteria, false, false, true)

			CSRRepoRateCriteria();
			virtual void GetCode(const sophis::instrument::CSRInstrument& instrument, const sophis::CSRComputationResults* results, TCodeList& list) const;
			virtual sophis::gui::CSRElement* new_FieldElement(int i, sophis::gui::CSREditList* l, int nre, bool editable, const char* nameDB) const;
			virtual void GetName(long code, char* name) const;

			mutable double fRepoRate;
		};

	} // collateral
} // sophis

SPH_EPILOG
#endif //_SphGeneralSpecialCriteria_H