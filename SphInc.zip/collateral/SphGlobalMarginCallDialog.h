#pragma once
#ifndef _SphGlobalMarginCallDialog_H_
#define _SphGlobalMarginCallDialog_H_

#ifndef GCC_XML

#include "SphInc/collateral/SphLbaType.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/gui/SphColumnExplDialog.h"
#include "SphInc/instrument/SphUniversalReference.h"		//CSRUniversalReferenceList
#include "SphInc/gui/SphButton.h"
#include "SphInc/gui/SphCheckBox.h"
#include "SphInc/gui/SphColumnConfigurationMgr.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"
#include __STL_INCLUDE_PATH(memory)

struct TMvtFull;

struct TCol;

SPH_PROLOG
namespace sophis {
	namespace gui{
		class CSRCheckBox;
		class CSRButton;
		struct SSColumn;
	}
	namespace collateral {

	class CSRGlobalMarginCallDialog;
	class CSRLBAgreement;
	class CSRMarginCall;
	class CSRStockLoanResult;
	class CSRCollateralReportContext;
	class CSRGlobalMarginCallKWFMgr;
	class CashMarginCallCalculation;
	typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;

/** 
 * Kernel event button for global margin call dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRPoolKernelEventButton : public gui::CSRButton
{
public:
	CSRPoolKernelEventButton(sophis::gui::CSRFitDialog * dlg, int item);
	void Action();	// overload
};

/**
 * Global margin call list with support for columns configuration.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRGlobalMarginCallList : public gui::CSRColumnExplList
{
public:
	CSRGlobalMarginCallList(CSRGlobalMarginCallDialog *dialog, int ERId_List);
	virtual ~CSRGlobalMarginCallList();

	/// See {@link CSREditList::LoadLine}
	virtual Boolean LoadLine(int lineNumber) const;
	/// See {@link CSREditList::SaveLine}
	virtual void SaveLine(int lineNumber);
	/// See {@link CSREditList::CanSort}
	virtual bool CanSort(void){return true;}
	/// See {@link CSREditList::RemoveLine}
	virtual void RemoveLine(int lineNumber){}; //can implement later if needed
	/// See {@link CSREditList::Selection}
	virtual	void Selection(int lineNumber);
	/// See {@link CSREditList::LoseSelection}
	virtual	void LoseSelection(int lineNumber);
	/// See {@link CSREditList::Sort}.
	virtual void Sort(int NRC_Colonne, Boolean croissant);

	/** Must calculate the margin call amount for given line. */
	virtual void CalculateNetAmount(size_t line) = 0;
	/** Must calculate rolling interest amount for given line. */
	virtual void CalculateRollingInterest(size_t line) = 0;
	/** Must handle the update of given cell. */
	virtual void ColumnModification(size_t line, long column_id) = 0;
	/** Must return pointer to the given cell data. */
	virtual void * GetElemData(int line, int elemId) const = 0;

	/** Invoked by the rounding check-box to recalculate net amounts as necessary. */
	void RecalculateNetAmounts();
	/** Invoked by the rolling interest check-box to recalculate rolling interest amounts as necessary. */
	void RecalculateRollingInterests();
	
	enum {
		eTotalsLine = 0,
		eNumExtraLines
	};

protected:
	friend class CSRGlobalMarginCallDialog;
	/// See {@link CSRColumnExplList::InitData}. Replaced by InitMarginCall().
	virtual void InitData() {}
	/// See {@link CSRColumnExplList::CreateColumnElement}. Unused as we override both UpdateColumns() and InitColumns().
	virtual void CreateColumnElement(gui::SSColumn *column, int elemId, int width) {}
	/// See {@link CSRColumnExplList::GetTxtResourceID}. Must specify TXT resource id for columns.
	virtual int GetTxtResourceID() const = 0;
	/// See {@link CSRColumnExplList::GetResourceID}. Must specify ID for columns configuration storage.
	virtual long GetResourceID() const = 0;
	/// See {@link CSRColumnExplList::UpdateColumns}.
	virtual void UpdateColumns(TCol ** hCol) = 0;
	/// See {@link CSRColumnExplList::InitColumns}.
	virtual void InitColumns() = 0;

	/** Must be implemented by derived classes. Initialises the data. */
	virtual void InitMarginCall(long margin_date) = 0;
	/** Called on modification of any of the columns. Must be implemented. */
	virtual void ColumnModification(int whichColumn) = 0;

	void SetColumnElement(sophis::gui::SSColumn *column, int index, CSRElement* element,  int width, sophis::gui::eAlignmentType align);

	int  fNbLines;
	CSRGlobalMarginCallDialog* fDlog;
	_STL::vector<const CSRStockLoanResult*> fPoolList;
	sophis::instrument::CSRUniversalReferenceList fUnivRefList;
	bool fRounding;

	virtual double GetMarginCallCurrency(long lineNumber){return 0.0;}
	virtual double GetMarginCallValue(long lineNumber){return 0.0;}
	virtual double GetMarginCallInCollatCcy(long lineNumber){return 0.0;}
	virtual double GetNetAmountTotal(long lineNumber){return 0.0;}
	virtual void SetMarginCallValue(long lineNumber, double value){}
	virtual void SetMarginCallInCollatCcy(long lineNumber, double value){}
	virtual void SetNetAmountTotal(long lineNumber, double value){}
	virtual char *GetDataLine() const { return 0; }
	virtual char *GetDataLine(long line) const { return 0; }
};

template <typename DataT>
struct Getter
{
	Getter() : fGetter(NULL){}
	Getter(void * (DataT::*getter)()) : fGetter(getter){}
	void * GetValue(DataT* t)
	{
		assert(fGetter != NULL);
		if (fGetter)
			return (t->*fGetter)();
		else
			return NULL;
	}

	void * (DataT::*fGetter)();
};

typedef _STL::shared_ptr<sophis::gui::CSRElement> CSRElementPtr;
//////////////////////////////////////////////////////////////////////////
// List used for SecuritiesVsCash global margin call screen
class SOPHIS_COLLATERAL_GUI CSRSecVsCashList : public CSRGlobalMarginCallList
{
public:
	enum { 
		ePositionId = 0,
		eInstrument,
		ePrincipalCcy,
		eISIN,
		eQuantity, 
		eValueDate,
		eHedgingRatio,
		ePrincipalValue,
		eForexRate,
		ePriceInPrincipalCcy,
		eCollateralizedPrice,
		eCurrentCollateral,
		eInitialCollateral,
		eCollateralName,
		eCollateralHaircut,
		eCreditRisk,
		eNetAmount,
		eCashAmount,	
		eMCValue,
		eRollingInterest,
		eFORemarks,
		eNeededCollateral,
		eInitialCollateralAmount,
		eCurrentCollateralAmount,
		ePartialReturnQuantity,
		eDepositary,
		eNumItems
	};
public:
	CSRSecVsCashList(CSRGlobalMarginCallDialog *dialog, int ERId_List);
	virtual ~CSRSecVsCashList();
	virtual void InitMarginCall(long margin_date);
	virtual void ColumnModification(int whichColumn);
	virtual void Sort(int NRC_Colonne, Boolean croissant);
	virtual void CalculateNetAmount(size_t line);
	virtual void CalculateRollingInterest(size_t line);
	virtual void ColumnModification(size_t line, long column_id);
	virtual int GetTxtResourceID() const;
	virtual long GetResourceID() const;
	virtual void GetCellStyle(long lineNumber, long colNumber, sophis::gui::SSListCellStyle* state);

	virtual void * GetElemData(int lineIndex, int elemId) const;
	struct LineData{
		struct DataToDisplay{
			sophis::portfolio::PositionIdent positionId;								void * get_positionId(){return &positionId;}
			char   instrumentName[GLOBAL_MC_FIELD_LENGTH+1];void * get_instrumentName(){return instrumentName;}
			char	principalCcy[GLOBAL_MC_FIELD_LENGTH+1];	void * get_principalCcy(){return principalCcy;}
			char   ISIN[GLOBAL_MC_FIELD_LENGTH+1];			void * get_ISIN(){return ISIN;}
			double quantity;								void * get_quantity(){return &quantity;}
			long   valueDate;								void * get_valueDate(){return &valueDate;}
			double hedging;									void * get_hedging(){return &hedging;}
			double principalValue;							void * get_principalValue(){return &principalValue;}
			double forex;									void * get_forex(){return &forex;}
			double principalSpot;							void * get_principalSpot(){return &principalSpot;}
			double collateralizedSpot;						void * get_collateralizedSpot(){return &collateralizedSpot;}
			double currentCollateral;						void * get_currentCollateral(){return &currentCollateral;}
			double initialCollateral;						void * get_initialCollateral(){return &initialCollateral;}
			char   collatName [GLOBAL_MC_FIELD_LENGTH +1];	void * get_collatName(){return collatName;} 
			double collateralHaircut;						void * get_collateralHaircut(){return &collateralHaircut;} 
			double creditRisk;								void * get_creditRisk(){return &creditRisk;}
			double netAmount;								void * get_netAmount(){return &netAmount;} 
			double marginCallInCollatCcy;					void * get_marginCallInCollatCcy(){return &marginCallInCollatCcy;}
			double marginCallValue;							void * get_marginCallValue(){return &marginCallValue;}
			double rollingInterest;							void * get_rollingInterest(){return &rollingInterest;} 
			char   fo_remarks[GLOBAL_MC_FIELD_LENGTH+1];	void * get_fo_remarks(){return fo_remarks;} 
			double neededCollateral;						void * get_neededCollateral(){return &neededCollateral;}
			double initialCollateralAmount;					void * get_initialCollateralAmount(){return &initialCollateralAmount;}
			double currentCollateralAmount;					void * get_currentCollateralAmount(){return &currentCollateralAmount;}
			double partialReturnAmount;						void * get_partialReturnAmount(){return &partialReturnAmount;}
			CSRElement * depositaryElem;					void * get_depositaryElem(){return &depositaryElem;}			
		}LineInfo;
		long	marginCallCurrency;
		double	rollingInterest;
		double  collateralValue;
		const instrument::CSRLoanAndRepo* loan;
	}*fData;

	virtual void UpdateColumns(TCol ** hCol);
	virtual void InitColumns();
	typedef Getter<LineData::DataToDisplay> SecVsCashGetter;
	typedef _STL::map<int, SecVsCashGetter> GetterMap;
	mutable GetterMap fGetterMap;
	_STL::vector<CSRElementPtr> fDepositaryElements;

protected:
	virtual void	GetLineState(	int	lineIndex,
		sophis::gui::eTextStyleType		&style,
		sophis::gui::eTextColorType		&color,
		Boolean				&isSelected,
		Boolean				&canEdit,
		Boolean				&isStrikedThrough) const;
	virtual double GetMarginCallCurrency(long lineNumber);
	virtual double GetMarginCallValue(long lineNumber);
	virtual double GetMarginCallInCollatCcy(long lineNumber);
	virtual double GetNetAmountTotal(long lineNumber);
	virtual void SetMarginCallValue(long lineNumber, double value);
	virtual void SetMarginCallInCollatCcy(long lineNumber, double value);
	virtual void SetNetAmountTotal(long lineNumber, double value);
	virtual char *GetDataLine() const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur;
		++lines;
		return (char *)lines;
	}
	virtual char *GetDataLine(long line) const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur + line;
		return (char *)lines;
	}
};

//////////////////////////////////////////////////////////////////////////
// List used for CashVsSecurities global margin call screen
class SOPHIS_COLLATERAL_GUI CSRCashVsSecList : public CSRGlobalMarginCallList
{
	enum { 
		ePositionId = 0,
		eInstrument, 
		eQuantity, 
		eValueDate,
		eHedgingRatio,
		ePrincipalValue,
		eForexRate,
		ePriceInPrincipalCcy,
		eCollateralizedPrice,
		eCurrentCollateral,
		eInitialCollateral,
		//eNeededCollat,
		eCollateralName,
		eCollateralHaircut,
		//eCurrentCollatInCollatCcy,
		//eRoundedMarginCall,
		eCreditRisk,
		eNetAmount,
		eMCInCollatCcy,
		eMCValue,
		eRollingInterest,
		eFORemarks,
		eNeededCollateral,
		eCurrentCollateralAmount,
		ePartialReturnQuantity,
		eDepositary,
		eNumItems
	};
	public:
	CSRCashVsSecList(CSRGlobalMarginCallDialog *dialog, int ERId_List);
	virtual ~CSRCashVsSecList();
	virtual void InitMarginCall(long margin_date);
	virtual void ColumnModification(int whichColumn);
    virtual void Sort(int NRC_Colonne, Boolean croissant);
	virtual void CalculateNetAmount(size_t line);
	virtual void CalculateRollingInterest(size_t line);
	virtual void ColumnModification(size_t line, long column_id);
	virtual int GetTxtResourceID() const;
	virtual long GetResourceID() const;
	virtual void * GetElemData(int lineIndex, int elemId) const;
	virtual void GetCellStyle(long lineNumber, long colNumber, sophis::gui::SSListCellStyle* state);

	struct LineData{
		struct DataToDisplay{
			sophis::portfolio::PositionIdent positionId;								void * get_positionId(){return &positionId;}
			char   instrumentName[GLOBAL_MC_FIELD_LENGTH+1];void * get_instrumentName(){return instrumentName;}
			double quantity;								void * get_quantity(){return &quantity;}
			long   valueDate;								void * get_valueDate(){return &valueDate;}
			double hedging;									void * get_hedging(){return &hedging;}
			double principalValue;							void * get_principalValue(){return &principalValue;}
			double forex;									void * get_forex(){return &forex;}
			double principalSpot;							void * get_principalSpot(){return &principalSpot;}
			double collateralizedSpot;						void * get_collateralizedSpot(){return &collateralizedSpot;}
			double currentCollateral;						void * get_currentCollateral(){return &currentCollateral;}
			double initialCollateral;						void * get_initialCollateral(){return &initialCollateral;}
			//double neededCollateral;
			char   collatName [GLOBAL_MC_FIELD_LENGTH +1];	void * get_collatName(){return collatName;}
			double collateralHaircut;						void * get_collateralHaircut(){return &collateralHaircut;}
			//double collatInCollatCcy;
			//double roundedMarginCall;
			double creditRisk;								void * get_creditRisk(){return &creditRisk;}
			double netAmount;								void * get_netAmount(){return &netAmount;}
			double marginCallInCollatCcy;					void * get_marginCallInCollatCcy(){return &marginCallInCollatCcy;}
			double marginCallValue;							void * get_marginCallValue(){return &marginCallValue;}
			double rollingInterest;							void * get_rollingInterest(){return &rollingInterest;}
			char   fo_remarks[GLOBAL_MC_FIELD_LENGTH+1];	void * get_fo_remarks(){return fo_remarks;}
			double neededCollateral;						void * get_neededCollateral(){return &neededCollateral;}
			double currentCollateralAmount;					void * get_currentCollateralAmount(){return &currentCollateralAmount;}
			double partialReturnAmount;						void * get_partialReturnAmount(){return &partialReturnAmount;}
			CSRElement * depositaryElem;					void * get_depositaryElem(){return &depositaryElem;}			
		}LineInfo;
		bool	isEnabled;
		long	marginCallCurrency;
		double rollingInterest;
		double collateralValue;
		const instrument::CSRLoanAndRepo* loan;
	}*fData;


	virtual void UpdateColumns(TCol ** hCol);
	virtual void InitColumns();
	typedef Getter<LineData::DataToDisplay> CashVsSecGetter;
	typedef _STL::map<int, CashVsSecGetter> GetterMap;
	mutable GetterMap fGetterMap;
	_STL::vector<CSRElementPtr> fDepositaryElements;

protected:
	long GetSelectedLines() const;
	virtual void	GetLineState(	int	lineIndex,
		sophis::gui::eTextStyleType		&style,
		sophis::gui::eTextColorType		&color,
		Boolean				&isSelected,
		Boolean				&canEdit,
		Boolean				&isStrikedThrough) const;
	virtual double GetMarginCallCurrency(long lineNumber);
	virtual double GetMarginCallValue(long lineNumber);
	virtual double GetMarginCallInCollatCcy(long lineNumber);
	virtual void SetMarginCallValue(long lineNumber, double value);
	virtual void SetMarginCallInCollatCcy(long lineNumber, double value);
	virtual char *GetDataLine() const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur;
		++lines;
		return (char *)lines;
	}
	virtual char *GetDataLine(long line) const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur + line;
		return (char *)lines;
	}
};


//////////////////////////////////////////////////////////////////////////
// List used for SecuritiesVsSecurities global margin call screen
class SOPHIS_COLLATERAL_GUI CSRSecVsSecList : public CSRGlobalMarginCallList
{
	enum { 
		ePositionId = 0,
		eInstrument,
		ePrincipalCcy,
		eISIN,
		eQuantity, 
		eValueDate,
		eHedgingRatio,
		ePrincipalValue,
		eForexRate,
		ePriceInPrincipalCcy,
		eCollateralizedPrice,
		eCurrentCollateral,
		eInitialCollateral,
		eCollateralName,
		eCollateralHaircut,
		eCreditRisk,
		eNetAmount,
		eCashAmount,
		eMCValue,
		eRollingInterest,
		eFORemarks,
		eNeededCollateral,
		eCurrentCollateralAmount,
		ePartialReturnQuantity,
		eDepositary,
		eNumItems
	};
public:
	CSRSecVsSecList(CSRGlobalMarginCallDialog *dialog, int ERId_List);
	virtual ~CSRSecVsSecList();
	virtual void InitMarginCall(long margin_date);
	virtual void ColumnModification(int whichColumn);
    virtual void Sort(int NRC_Colonne, Boolean croissant);
	virtual void CalculateNetAmount(size_t line);
	virtual void CalculateRollingInterest(size_t line);
	virtual void ColumnModification(size_t line, long column_id);
	virtual int GetTxtResourceID() const; 
	virtual long GetResourceID() const;
	virtual void * GetElemData(int lineIndex, int elemId) const;
	virtual void GetCellStyle(long lineNumber, long colNumber, sophis::gui::SSListCellStyle* state);

	struct LineData{
		struct DataToDisplay{
			sophis::portfolio::PositionIdent positionId;								void * get_positionId(){return &positionId;}
			char   instrumentName[GLOBAL_MC_FIELD_LENGTH+1];void * get_instrumentName(){return instrumentName;}
			char	principalCcy[GLOBAL_MC_FIELD_LENGTH+1];	void * get_principalCcy(){return principalCcy;}
			char   ISIN[GLOBAL_MC_FIELD_LENGTH+1];			void * get_ISIN(){return ISIN;}
			double quantity;								void * get_quantity(){return &quantity;}
			long   valueDate;								void * get_valueDate(){return &valueDate;}
			double hedging;									void * get_hedging(){return &hedging;}
			double principalValue;							void * get_principalValue(){return &principalValue;}
			double forex;									void * get_forex(){return &forex;}
			double principalSpot;							void * get_principalSpot(){return &principalSpot;}
			double collateralizedSpot;						void * get_collateralizedSpot(){return &collateralizedSpot;}
			double currentCollateral;						void * get_currentCollateral(){return &currentCollateral;}
			double initialCollateral;						void * get_initialCollateral(){return &initialCollateral;}
			//double neededCollateral;
			char   collatName [GLOBAL_MC_FIELD_LENGTH +1];	void * get_collatName(){return collatName;}
			double collateralHaircut;						void * get_collateralHaircut(){return &collateralHaircut;}
			//double collatInCollatCcy;
			//double roundedMarginCall;
			double creditRisk;								void * get_creditRisk(){return &creditRisk;}
			double netAmount;								void * get_netAmount(){return &netAmount;}
			double marginCallInCollatCcy;					void * get_marginCallInCollatCcy(){return &marginCallInCollatCcy;}
			double marginCallValue;							void * get_marginCallValue(){return &marginCallValue;}
			double rollingInterest;							void * get_rollingInterest(){return &rollingInterest;}
			char   fo_remarks[GLOBAL_MC_FIELD_LENGTH+1];	void * get_fo_remarks(){return fo_remarks;}
			double neededCollateral;						void * get_neededCollateral(){return &neededCollateral;}
			double currentCollateralAmount;					void * get_currentCollateralAmount(){return &currentCollateralAmount;}
			double partialReturnAmount;						void * get_partialReturnAmount(){return &partialReturnAmount;}
			CSRElement * depositaryElem;					void * get_depositaryElem(){return &depositaryElem;}			
		}LineInfo;
		bool	isEnabled;
		long	marginCallCurrency;
		double rollingInterest;
		double collateralValue;
		const instrument::CSRLoanAndRepo* loan;
	}*fData;

	virtual void UpdateColumns(TCol ** hCol);
	virtual void InitColumns();
	typedef Getter<LineData::DataToDisplay> SecVsSecGetter;
	typedef _STL::map<int, SecVsSecGetter> GetterMap;
	mutable GetterMap fGetterMap;
	_STL::vector<CSRElementPtr> fDepositaryElements;

protected:
	virtual void	GetLineState(	int	lineIndex,
		sophis::gui::eTextStyleType		&style,
		sophis::gui::eTextColorType		&color,
		Boolean				&isSelected,
		Boolean				&canEdit,
		Boolean				&isStrikedThrough) const;
	virtual double GetMarginCallCurrency(long lineNumber);
	virtual double GetMarginCallValue(long lineNumber);
	virtual double GetMarginCallInCollatCcy(long lineNumber);
	virtual void SetMarginCallValue(long lineNumber, double value);
	virtual void SetMarginCallInCollatCcy(long lineNumber, double value);
	virtual char *GetDataLine() const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur;
		++lines;
		return (char *)lines;
	}
	virtual char *GetDataLine(long line) const
	{
		LineData::DataToDisplay* lines = *(LineData::DataToDisplay**)fListeValeur + line;
		return (char *)lines;
	}
};

#define	INITIALISE_GLOBAL_CALL_REGISTER(key,name)	\
	sophis::collateral::CSRGlobalMarginCallRegister::ResgisterMarginCallDialogCreator(key,name)

#define DECLARATION_MARGIN_CALL_CREATOR(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRGlobalMarginCallDialogCreator)
#define CONSTRUCTOR_MARGIN_CALL_CREATOR(derivedClass)
#define WITHOUT_CONSTRUCTOR_MARGIN_CALL_CREATOR(derivedClass)

#define	INITIALISE_MARGIN_CALL_CREATOR(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)


/**
 * Utility class to create desired implementation of the global margin call dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRGlobalMarginCallDialogCreator : public gui::ISRColumnExplCreator
{
public:
	/** Prototype class which is used in the creation of Global Margin call Dialogs.
	 */
	/// See {@link ISRColumnExplCreator::new_ColumnExplDialog}
	virtual gui::CSRColumnExplDialog* new_ColumnExplDialog() = 0;
	/// See {@link ISRColumnExplCreator::new_UserEditInfo}
	virtual CSRUserEditInfo* new_UserEditInfo() = 0;

	virtual const CSRStockLoanResult& GetParentLine() const = 0;

	/**
   	 * Clone method required by the prototype.
	 */
	virtual CSRGlobalMarginCallDialogCreator * Clone() const = 0;
	/** 
	* Typedef for the prototype : the key is a const char*.
	*/
	typedef tools::CSRPrototype<CSRGlobalMarginCallDialogCreator, const char*, tools::less_char_star> prototype;

	/** 
	* Access to prototype singleton.
	*/
	static prototype& GetPrototype();

	/**
	* Returns default filter for each tab type.
	*/
	virtual void SetValues(const CSRCollateralReportContext &ctx, const CSRStockLoanResult* parentLine, const CSRLBAgreementPtr& lba, long date) const = 0;

};

class CSRStockLoanResult;

class SOPHIS_COLLATERAL_GUI CSRGlobalMarginCallDialogCreatorDefault : public CSRGlobalMarginCallDialogCreator
{
	DECLARATION_MARGIN_CALL_CREATOR(CSRGlobalMarginCallDialogCreatorDefault)
public:
	/** Creates global margin call dialog for given line of Stock Loan and Repo Mgmt GUI.
	* @param parentLine A line from the Stock Loan and Repo Mgmt GUI, like 'Security vs EUR Contract'.
	* @param lba Collateral agreement.
	*/
	CSRGlobalMarginCallDialogCreatorDefault(){};
	CSRGlobalMarginCallDialogCreatorDefault(const CSRCollateralReportContext &ctx, const CSRStockLoanResult& parentLine, const CSRLBAgreementPtr& lba, long date = 0);
	//	static CSRGlobalMarginCallDialogCreator & CreateDialogCreator();
	/// See {@link ISRColumnExplCreator::new_ColumnExplDialog}
	virtual gui::CSRColumnExplDialog* new_ColumnExplDialog();
	/// See {@link ISRColumnExplCreator::new_UserEditInfo}
	virtual CSRUserEditInfo* new_UserEditInfo();

	const CSRStockLoanResult& GetParentLine() const { return *fParentLine; }
	virtual void SetValues(const CSRCollateralReportContext &ctx, const CSRStockLoanResult* parentLine, const CSRLBAgreementPtr& lba, long date = 0) const;	

protected:
	mutable const CSRCollateralReportContext *fCtx;
	mutable const CSRStockLoanResult *fParentLine;
	mutable const CSRLBAgreementPtr *fLBA;
	mutable long fCcy;
	mutable CSRLbaType::eLbaType fType;
	mutable long fDate;
};

/** 
 * Dialog for global margin call for stock loan and repo contract per contract.
 * 
 * The support of configuration columns has been added to global margin call window.
 * When changing display columns, pay attention to the following:
 * 1. For each member field of LineData::DataToDisplay the should be a getter method that returns the address of field in the structure
 * 2. Each getter method should be added in the constructor to the fGetterMap
 * 3. Each column must have corresponding default width which is initialised in constructor - see static array SecVsSecDefaultWidths for exaple
 * 4. The UpdateColumns method must support intialisation of all columns
 * 
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRGlobalMarginCallDialog : public gui::CSRColumnExplDialog
{	
public:
	/** Resource ids for the elements of the dialog. */
	enum {
		eGlobalMCList = 1,
		eKWButton1,
		eKWButton2,
		eKWButton3,
		eKWButton4,
		eRoundingPref,
		eKWName,
		eMarkSpotPref,
		eRollingInterestPref = 11,

		e__Dummy, e__LastElement = e__Dummy-1
	};

	static void GlobalMarginCallDialog(const CSRCollateralReportContext &ctx, const CSRStockLoanResult* parentLine, const CSRLBAgreementPtr& lba, long date = 0);
	static void GlobalMarginCallDialog(const CSRGlobalMarginCallDialogCreator& creator);
	virtual ~CSRGlobalMarginCallDialog();

	/// See {@link CSRGlobalMarginCallDialog::new_GlobalMarginCallList}
	virtual CSRGlobalMarginCallList* new_GlobalMarginCallList();
	/// See {@link CSRColumnExplDialog::GetColumnExplTitle}
	virtual _STL::string GetColumnExplTitle();
	/// See {@link CSRColumnExplDialog::Init}. Forwards call to InitMarginCall().
	virtual void Init(gui::ISRColumnExplCreator& creator);

	/** Initialises the elements. May be overridden by derived classes. */
	virtual void InitMarginCall(CSRGlobalMarginCallDialogCreator& creator, int resourceId = 0, int elementCount = 0);

	/// See {@link CSRFitDialog::Open}
	virtual void	Open();
	/// See {@link CSRFitDialog::OnGotFocus}
	virtual void OnGotFocus();

	const sophis::instrument::CSRInstrument* GetInstrument();
	TMvtFull* GetTransaction();
	bool SaveTransaction() const;
	friend class CSRGlobalMarginCallList;
	friend class CSRGlobalMarginCallKWFMgr;
	CSRGlobalMarginCallKWFMgr *fKWFMgr;

	virtual void FillPool(const CSRGlobalMarginCallDialogCreator& creator, _STL::vector<const CSRStockLoanResult*>& poolList);
	virtual void DoActionKernelBouton(int relativeId, bool selectedLinesOnly = false);
	bool GetSelectionPreference();
	const CSRCollateralReportContext& GetCollateralReportContext() const { return fCtx; }
	const CSRLBAgreementPtr& GetLBA() {return fLBA;}
	bool	GetRounding() const {return fRounding;}
	virtual void OnRoundingAction(short value);
	virtual void OnMarkSpotAction(short value);
	virtual void OnRollingInterestAction(short value);
	bool	GetRollingInterest() const {return fRollingInterest;}
	CSRLbaType::eLbaType GetType() const {return fType;}
	const CSRLBAgreement* GetAgreement() const { return fLBA.get(); }
	virtual void BeforeSaveEvent(_STL::map<sophis::portfolio::PositionIdent, void *> &lines) const { return;} ;
	virtual void AfterSaveEvent() const { return;} ;
	virtual void SaveExceptionEvent(int curLine) const { return;} ;

	bool fOnlySelectedLines;
	long fEventId;
	long	fCurrency;

protected:
	CSRGlobalMarginCallDialog(const CSRCollateralReportContext &ctx, const CSRLBAgreementPtr& lba, long margin_date, long ccy = 0, CSRLbaType::eLbaType type = CSRLbaType::eSecVsCashContract);
	CSRGlobalMarginCallList* GetGlobalMarginCallList() { return dynamic_cast<CSRGlobalMarginCallList*>(fList); }
	const CSRGlobalMarginCallList* GetGlobalMarginCallList() const { return dynamic_cast<const CSRGlobalMarginCallList*>(fList); }

	const CSRCollateralReportContext &fCtx;
	CSRLbaType::eLbaType fType;
	CSRLBAgreementPtr fLBA;
	CSRMarginCall* fMC;
	long	fMarginDate;
	bool	fRounding;
	bool	fMarkSpot;
	bool	fRollingInterest;

private:
	/// See {@link CSRColumnExplDialog::new_ColumnExplList}
	virtual gui::CSRColumnExplList* new_ColumnExplList() { return new_GlobalMarginCallList(); }

	static const char *__CLASS__;
	friend class CSRGlobalMarginCallDialogCreator;
	friend class CSRGlobalMarginCallDialogCreatorDefault;
};

//////////////////////////////////////////////////////////////////////////

/**
 * Rounding check box element of the global margin call dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRRoundingCheckBox : public gui::CSRCheckBox{
public:
	CSRRoundingCheckBox(sophis::gui::CSRFitDialog * dlg, int item, bool value = false);
	virtual void Initialisation(sophis::gui::CSRFitDialog *dialog, int &number);	
};

/**
 * Include accrued interest check box element of the global margin call dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRRollingInterestCheckBox : public gui::CSRCheckBox{
public:
	CSRRollingInterestCheckBox(sophis::gui::CSRFitDialog * dlg, int item, bool value = false);
	virtual void Initialisation(sophis::gui::CSRFitDialog *dialog, int &number);	
};

/**
 * Mark spot check box element of the global margin call dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRMarkSpotCheckBox : public gui::CSRCheckBox
{
public:
	CSRMarkSpotCheckBox(sophis::gui::CSRFitDialog * dlg, int item, bool value = false);
	virtual void Initialisation(sophis::gui::CSRFitDialog *dialog, int &number);	
};

class SOPHIS_COLLATERAL_GUI CSRGlobalMarginCallRegister
{	
public:
	static void ResgisterMarginCallDialogCreator(_STL::string key,_STL::string name)
	{
		fCreator[key] = name;
	}
	static _STL::map<_STL::string,_STL::string> fCreator;

};

}		//sophis
}			//collateral


SPH_EPILOG
#endif // GCC_XML
#endif // _SphGlobalMarginCallDialog_H_

