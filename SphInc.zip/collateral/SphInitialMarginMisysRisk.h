#pragma once
#ifndef _SphInitialMarginMisysRisk_H_
#define _SphInitialMarginMisysRisk_H_

#ifndef GCC_XML

#include "SphInc/collateral/SphInitialMarginProxy.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Implementation of portfolio based initial margin via Sophis Misys Risk.
 * Parameterization is done based on Sophis.RM.DataAccess.VaRDefaultParameters.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL_MR CSRInitialMarginMisysRisk : public virtual CSRInitialMarginProxy
{
private:
	static const char* __CLASS__;

public:
	_STL::string fScenarioGroupName;
	long fScenarioGroupId; // See {@link Sophis.RM.DataAccess.VaRDefaultParameters.ScenarioGroupId}
	_STL::string fConfigurationName;
	long fConfigurationId; // See {@link Sophis.RM.DataAccess.VaRDefaultParameters.ConfigurationId}
	_STL::string fFigureMode; // See {@link Sophis.RM.DataAccess.VaRDefaultParameters.FigureMode}
	long fHoldingPeriod; // See {@link Sophis.RM.DataAccess.VaRDefaultParameters.HoldingPeriod}
	double fConfidence; // See {@link Sophis.RM.DataAccess.VaRDefaultParameters.Confidence}

public:
	/** Default constructor. */
	CSRInitialMarginMisysRisk();

	/** Destructor. */
	virtual ~CSRInitialMarginMisysRisk() {}

	/** Part of clone interface. */
	virtual void Initialise(const CSRInitialMarginProxy& copy);

	/** Clone interface. */
	virtual CSRInitialMarginProxy* Clone() const
	{
		CSRInitialMarginMisysRisk* c = new CSRInitialMarginMisysRisk();
		c->Initialise(*this);
		return c;
	}

	/** Returns the dialog relevant to the parameters for the model */
	virtual CSRInitialMarginParamDialog * new_Dialog() const;

	/** To use with Store(). See {@link ISRPackable} */
	virtual void* Pack(CSRLBAgreement& lba, void* buffer) const;

	/** To use with Load(). See {@link ISRPackable} */
	virtual const void* Unpack(const CSRLBAgreement& lba, const void* buffer);

	/** See {@link ISRPackable} */
	virtual int GetPackedSize() const;

	/** See {@link GetVar}. Implementation. */
 	virtual double GetVar(CSRCollateralLimitResult* reportRoot, long date) const;

	/** See {@link GetVar}. Implementation. */
 	virtual double GetVar(CSRCFDResult* reportRoot, long date) const;
};

	} // collateral
} // sophis

SPH_EPILOG
#endif // GCC_XML
#endif // _SphInitialMarginMisysRisk_H_
