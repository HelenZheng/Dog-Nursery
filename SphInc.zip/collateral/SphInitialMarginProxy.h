#pragma once
#ifndef _SphInitialMarginProxy_H_
#define _SphInitialMarginProxy_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialog.h"
#include "SphInc/tools/SphPackable.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

/**
 * Macros for handling initial margin proxy implementation and prototype.
 */
#define DECLARATION_INITIAL_MARGIN_PROXY(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRInitialMarginProxy)
#define	INITIALISE_INITIAL_MARGIN_PROXY(derivedClass,name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::collateral::CSRInitialMarginProxy*>(sophis::collateral::CSRInitialMarginProxy::GetPrototype().GetData(name))->SetName(name);

namespace sophis {
	namespace collateral {

class CSRLBAgreement;
class CSRCollateralLimitResult;
class CSRCFDResult;
class CSRInitialMarginParamDialog;

/**
 * Interface used to communicate with external systems providing Var/initial margin values.
 * Plus interface for custom (extra, additional) parameters.
 * These parameters are optional.
 * @version 7.1
 */
class SOPHIS_COLLATERAL CSRInitialMarginProxy
{
public:
	/** Default constructor. */
	CSRInitialMarginProxy() {}

	/** Destructor. */
	virtual ~CSRInitialMarginProxy() {}

	/** Part of clone interface. */
	virtual void Initialise(const CSRInitialMarginProxy& copy) { fName = copy.fName; }

	/** Clone interface. 
	 *
	 * Example:
	 *		CSRInitialMarginProxy* c = new CSRInitialMarginProxy();
	 *		c->Initialise(*this);
	 *		return c;
	 */
	virtual CSRInitialMarginProxy* Clone() const = 0;

#ifndef GCC_XML
	/** Returns the dialog relevant to the parameters for the model */
	virtual CSRInitialMarginParamDialog * new_Dialog() const{ return 0; }
#endif

	/* Saves the resources of the parameters dialog. Default implementation is to save inside resources. */
	virtual bool Store(CSRLBAgreement& lba) const;

	/* Loads the resources of the parameters dialog. Default implementation is to load from resources. */
	virtual bool Load(const CSRLBAgreement& lba);

	/** To use with Store(). See {@link ISRPackable} */
	virtual void* Pack(CSRLBAgreement& lba, void* buffer) const { return buffer; }

	/** To use with Load(). See {@link ISRPackable} */
	virtual const void* Unpack(const CSRLBAgreement& lba, const void* buffer) { return buffer; }

	/** See {@link ISRPackable} */
	virtual int GetPackedSize() const { return 0; }

	/** 
	 * This function will update the CSRCollateralLimitResult with the correct net exposure and initial margin values.
	 * It will call the GetVar function unless there is an agreed value.
	 * @param reportRoot The root element of a detailed limits report to be updated.
	 * @param date Reporting date
	 */
	void UpdateResult(CSRCollateralLimitResult* reportRoot, long date) const;

	/** 
	 * This function will update the CSRCFDResult with the correct net exposure and initial margin values.
	 * It will call the GetVar function unless there is an agreed value.
	 * @param reportRoot The root element of a detailed limits report to be updated.
	 * @param date Reporting date
	 */
	void UpdateResult(CSRCFDResult* reportRoot, long date) const;

	/**
	 * Requests the Var value for the given agreement triplet. 
	 * @param reportRoot The root element of a detailed limits report.
	 * @return Var value for agreement.
	 */
 	virtual double GetVar(CSRCollateralLimitResult* reportRoot, long date) const = 0;

	/**
	 * Requests the Var value for the given agreement triplet. 
	 * @param reportRoot The root element of a CFD report.
	 * @return Var value for agreement.
	 */
 	virtual double GetVar(CSRCFDResult* reportRoot, long date) const = 0;

	/** Typedef for the prototype (the key is a string). */
	typedef sophis::tools::CSRPrototype<CSRInitialMarginProxy, const char*, sophis::tools::less_char_star> prototype;

	/** 
	 * Return the prototype containing all the instances of the registered Initial margin proxies.
	 * @return the prototype containing all the instances of the registered Initial margin proxies.
	*/
	static prototype &	GetPrototype();

	/** Returns the name of the IM proxy implementation. */
	virtual _STL::string GetName() const { return fName; }

	/** Sets the name of the IM proxy implementation. */
	virtual void SetName(const char* name) { fName = name; }

protected:
	_STL::string fName;
};


#ifndef GCC_XML
/**
 * Interface for custom (extra, additional) parameters dialog for the portfolio based initial margin.
 * Extra parameters and the dialog are optional.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRInitialMarginParamDialog : public sophis::gui::CSRFitDialog
{
public:
	/** Constructor. */
	CSRInitialMarginParamDialog();
	/** Destructor. */
	virtual ~CSRInitialMarginParamDialog();

	/** 
	 * Fill given portfolio based initial margin parameters with the dialog data.
	 * This method is called when the parameters object needs to be updated from the displayed data.
	 * @param imProxy Parameters object being edited.
	 * @return A boolean that described the state of the update.
	 */
	virtual bool FillDataFromDialog(CSRInitialMarginProxy& imProxy) const = 0;

	/** 
	 * Fill the dialog data based on the given portfolio based initial margin parameters.
	 * This method is called when the dialog needs to be initialised (updated) from the parameters object.
 	 * @param imProxy Parameters object being edited.
	 * @return A boolean that described the state of the update.
	 */
	virtual bool FillDialogFromData(const CSRInitialMarginProxy& imProxy) = 0;
};

#endif // GCC_XML

	} // collateral
} // sophis

SPH_EPILOG
#endif // _SphInitialMarginProxy_H_
