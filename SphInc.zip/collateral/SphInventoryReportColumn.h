#ifndef _SphInventoryReportColumn_H_
#define _SphInventoryReportColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphSecuritiesReportCommon.h"

struct SSCellStyle;
union SSCellValue;
#define MAIN_PROJECTION 1
#define PROJECTION 2
#define MAIN_DELTA 3
#define MAIN_BOTH 4
#define MAIN_PROJECTION_COLLATERAL 5
#define MAIN_PROJECTION_SL 6
#define MAIN_PROJECTION_BOOK 7
#define MAIN_DELTA_COLLATERAL 8
#define MAIN_DELTA_SL 9
#define MAIN_DELTA_BOOK 10


SPH_PROLOG
namespace sophis {
	namespace collateral {

		/**
		* Macros for Global Projection Report column prototype implementation.
		* @since 6.2
		*/
#define DECLARATION_INVENTORY_REPORT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRInventoryReportColumn)
#define CONSTRUCTOR_INVENTORY_REPORT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_INVENTORY_REPORT_COLUMN(derivedClass)

		/** Installs column in main, explanation, and projection tabs of the report. */
#define	INITIALISE_INVENTORY_REPORT_COLUMN(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

		/** Installs column in the main tab in Projection, Delta and Both views */
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_PROJECTION);\
	sophis::collateral::install<derivedClass >(name, MAIN_DELTA);\
	sophis::collateral::install<derivedClass >(name, MAIN_BOTH);

		/** Installs column in the main tab in Projection and Both views */
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_PROJECTION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_PROJECTION);\
	sophis::collateral::install<derivedClass >(name, MAIN_BOTH);

		/** Installs column in the main tab in Delta and Both views */
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_DELTA(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_DELTA);\
	sophis::collateral::install<derivedClass >(name, MAIN_BOTH);


		/** Installs column only in the projection tab and not in main tab. */
#define	INITIALISE_INVENTORY_REPORT_COLUMN_PROJECTION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, PROJECTION);

#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_PROJECTION_COLLATERAL(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_PROJECTION_COLLATERAL);
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_PROJECTION_SL(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_PROJECTION_SL);
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_PROJECTION_BOOK(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_PROJECTION_BOOK);
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_DELTA_COLLATERAL(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_DELTA_COLLATERAL);
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_DELTA_SL(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_DELTA_SL);
#define	INITIALISE_INVENTORY_REPORT_COLUMN_MAIN_DELTA_BOOK(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, MAIN_DELTA_BOOK);

		class CSRSecuritiesReportResult;
		/**
		* Global Projection Report column and prototype.
		* 
		* To add a column, derive this class, using the macro DECLARATION_INVENTORY_REPORT_COLUMN in your header
		* and INITIALISE_INVENTORY_REPORT_COLUMN in UNIVERSAL_MAIN.
		*
		* @since 6.2
		*/
		class SOPHIS_COLLATERAL CSRInventoryReportColumn
		{
		public:
			/** Constructor. */
			CSRInventoryReportColumn() : fId(0) {}

			/** 
			* Main method to display the content.
			* Must be implemented in derived classes.
			* @param securities report line to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			virtual	void GetCell(const CSRSecuritiesReportResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

			/**
			* Clone method required by the prototype.
			* Use DECLARATION_INVENTORY_REPORT_COLUMN macro in the implementation of the derived class.
			*/
			virtual CSRInventoryReportColumn* Clone() const = 0;

			/** 
			* Returns the default cell size in pixels.
			*/
			virtual short GetDefaultWidth() const;

			/**
			* Returns icon that is displayed in tree view when grouped by this column
			*/
			virtual short GetIconId() const;

			/**
			* Returns the id.
			* The value is created at the end of the initialise because it must
			* be unique according to the table COLUMN_NAME.
			*/
			int GetId() const
			{
				return fId;
			}

			/**
			* Sets the id.
			* Used when building the columns by {@link CSUReorderColumns}.
			*/
			void SetId(long id)
			{
				fId = id;
			}

			/** 
			* Typedef for the prototype : the key is a const char*.
			*/
			typedef tools::CSRPrototypeWithId<CSRInventoryReportColumn, const char*, tools::less_char_star> prototype;

			/** 
			* Access to prototype singleton.
			*/
			static prototype& GetPrototype(long type = 0);

			/**
			* Fills cell value and style with given quantity in given currency.
			* Useful for GUI display.
			* @param x Amount in given currency to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the instrument for the amount.
			*/
			static void FillQuantity(double x, SSCellValue *value, SSCellStyle *style, long ccy);

			/**
			* Fills cell value and style with string representation of given currency.
			* Useful for GUI display.
			* @param ccy Currency to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillCurrency(long ccy, SSCellValue *value, SSCellStyle *style);

			/**
			* Fills cell value and style with given date.
			* Useful for GUI display.
			* @param date Date to be displayed.
			* @param value An output parameter, used to return the value to be displayed.
			* @param style An output parameter, used to describe the style and the data type.
			*/
			static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

			/**
			* Fills style for display of a double value.
			* Useful for GUI display.
			* @param style An output parameter, used to describe the style and the data type.
			* @param ccy Currency of the double value.
			* @param dec Number of decimals to be displayed.
			*/
			static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

			/** Find out if the instrument of given result is not fully loaded.
			* CSRSecuritiesReportResult::GetSecuritiesCode() is used on given result.
			* Meant to be called from GetCell().
			* @note If there is no instrument set in the result, false is returned.
			*/
			static bool InstrNotLoaded(const CSRSecuritiesReportResult& result);

			/** Fill a cell with "<Load Instrument>".
			* Meant to be called from GetCell().
			*/
			static void FillWithLoadInstr(SSCellValue* value, SSCellStyle* style);

			/** Internal. */
			static void RefreshPrototype();

			static void ChangeColumnNames(const _STL::map<int, long> &dates);

		protected:
			long	fId;
			static _STL::map<_STL::string, int> fProjectionMap;
			static _STL::map<_STL::string, int> fNewProjectionMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempProjectionMap;
			static char fDisplayName[30][30];
			static char fDisplayNameDelta[30][30];
			static _STL::map<_STL::string, int> fDeltaMap;
			static _STL::map<_STL::string, int> fNewDeltaMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempDeltaMap;

			//For Nominal Date fields
			static _STL::map<_STL::string, int> fProjectionNominalMap;
			static _STL::map<_STL::string, int> fNewProjectionNominalMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempProjectionNominalMap;
			static char fDisplayNameNominal[30][30];
			static char fDisplayNameNominalDelta[30][30];
			static _STL::map<_STL::string, int> fDeltaNominalMap;
			static _STL::map<_STL::string, int> fNewDeltaNominalMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempDeltaNominalMap;

			static _STL::map<_STL::string, int> fProjectionCollateralMap;
			static _STL::map<_STL::string, int> fNewProjectionCollateralMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempProjectionCollateralMap;
			static char fDisplayNameCollateral[30][30];

			static _STL::map<_STL::string, int> fProjectionSLMap;
			static _STL::map<_STL::string, int> fNewProjectionSLMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempProjectionSLMap;
			static char fDisplayNameSL[30][30];

			static _STL::map<_STL::string, int> fProjectionBookMap;
			static _STL::map<_STL::string, int> fNewProjectionBookMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempProjectionBookMap;
			static char fDisplayNameBook[30][30];

			static _STL::map<_STL::string, int> fDeltaCollateralMap;
			static _STL::map<_STL::string, int> fNewDeltaCollateralMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempDeltaCollateralMap;
			static char fDisplayNameDeltaCollateral[30][30];

			static _STL::map<_STL::string, int> fDeltaSLMap;
			static _STL::map<_STL::string, int> fNewDeltaSLMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempDeltaSLMap;
			static char fDisplayNameDeltaSL[30][30];

			static _STL::map<_STL::string, int> fDeltaBookMap;
			static _STL::map<_STL::string, int> fNewDeltaBookMap;
			static _STL::map<int, CSRInventoryReportColumn *> fTempDeltaBookMap;
			static char fDisplayNameDeltaBook[30][30];

			static void ChangeColumnNamesTotal(const _STL::map<int, long> &dates);
			static void ChangeColumnNamesCollateral(const _STL::map<int, long> &dates);
			static void ChangeColumnNamesSL(const _STL::map<int, long> &dates);
			static void ChangeColumnNamesBook(const _STL::map<int, long> &dates);
			static void ChangeNominalColumnNames(const _STL::map<int, long> &dates);

		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
