#ifndef _SphLBAgreementContextMenu_H_
#define _SphLBAgreementContextMenu_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(memory)

/**
 * Macro to install custom context menu option.
 * @param derivedClass Custom context menu implementation.
 */
#define	INITIALISE_LB_AGREEMENT_CONTEXT_MENU(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass, name);

SPH_PROLOG
namespace sophis {

	namespace collateral {

		class CSRLBAgreement;
		typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;

/**
 * Interface for adding context menu items to the Collateral Agreements list.
 * @since 5.3.3
 */
class SOPHIS_COLLATERAL_GUI CSRLBAgreementContextMenu
{
public:

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototype<CSRLBAgreementContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_LB_AGREEMENT_CONTEXT_MENU.
	 */
	static prototype& GetPrototype();

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsAuthorized returns true, the key of the prototype (that is its name) is added in the context menu.
	 * Must be overloaded and implemented in custom classes.
	 * @param lba The Collateral Agreement.
	 * @return true to include the prototype in the context menu, false to skip it.
	 */
	virtual bool IsAuthorized(const CSRLBAgreementPtr lba) const = 0;

	/**
	 * Perform some action (like open a specific dialog) on the given Collateral Agreement.
	 * Must be overloaded and implemented in custom classes.
	 * @param lba The Collateral Agreement.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoLBAgreementContextMenu(const CSRLBAgreementPtr lba) const = 0;

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }
};

	} // namespace collateral
} // namespace sophis

SPH_EPILOG
#endif // _SphLBAgreementContextMenu_H_
