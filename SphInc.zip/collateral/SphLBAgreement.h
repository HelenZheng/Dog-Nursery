/*
 	File:		SphLBAgreement.h

 	Contains:	Class for the handling of a CSA (Collateral Agreement).

 	Copyright:	� 1995-2011 Sophis.

*/

#ifndef _CSRLBAgreement_H_
#define _CSRLBAgreement_H_


#include "SphInc/Collateral/SphCollateralExceptions.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/collateral/SphCFDSpreads.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#include __STL_INCLUDE_PATH(memory)
#include __STL_INCLUDE_PATH(memory)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
struct TLib;
class CSUMenu;
typedef CSUMenu * MenuHandle;

namespace sophis {
	namespace static_data	{
		class CSRCalendar;
	}

	namespace gui { 
		class CSRDatabaseDialog; 
		class CSREditList;
		class CSRElement;
	}

	namespace event {
		class ISEvent;
	}

	namespace collateral {

class CSRCollateralIndicatorForex;
class CSRCollateralHaircut;
class CSRInitialMarginProxy;
class CSRCollateralAgreementCustomData;

enum eLBAgreementTabs 
{	
	ttGeneralTab = 0,
	ttCreditRisk,
	ttMarginCall,
	ttCollateral,
	ttPrincipal,
	ttFees,
	ttCollateralCall,
	ttCFD,
	ttThreshold,
	ttMax
};

enum eLBAgreementTab
{
	ttLBAgreement = 1
};

enum eMarketShiftOnStockLoan
{
	msFELI = 0,
	msFILE,
	msFILI,
	msFELE,
	msFELIM,
	msLAST,
	msLAST_ON_MENU	// Shift of 1 due to default
};

enum eCFDFreeCashRate
{
	eCFDFreeCashFloating = 1,
	eCFDFreeCashFixed
};

enum eCFDNotionalCalculationType
{
	eNone = 1,
	eNetFunding,
	eGrossFunding
};

enum eDefaultAcc
{
	eDefYes = 1,
	eDefNo = 2
};

/**
 * Enum indicating rules for partial return setting.
 * @version 5.3.6
 */
enum ePartialReturn
{
	/** Default based on spot and commission type. */
	eprDefault = 0,
	/** With initial values. */
	eprWithInitialValues = 1,
	/** Always in percentage. */
	eprInPercentage = 2,
};

/**
 * Enum indicating rules for swap type setting.
 * @version 7.1.3
 */
enum eSwapType
{
	/** Default  Single Name Swap type. */
	estSingleName = 0,
	/**Portfolio Swap type. */
	estPortfolio = 1,
};

/**
 * Enum indicating rules for taking accrued interest and accrued commission into collateral credit risk calculation.
 * @version 5.3.6
 */
enum eAccruedInterestCommission
{
	/** Neither accrued interest nor accrued commission are taken into account. */
	eaicNone = 0,
	/** Only accrued interest but not accrued commission. */
	eaicInterestOnly = 1,
	/** Only accrued commission but not accrued interest. */
	eaicCommissionOnly = 2,
	/** Both accrued interest and accrued commission. */
	eaicInterestAndCommission = 3,
};

/**
 * Enum indicating what value date to use for CFD dividend
 * @version
 */
enum eCfdDividendDate 
{
	eDividendAtTradeDate = 0,
	eDividendAtPaymentDate
};

/**
 * Type of threshold applied.
 * 
 * There are 2 cases.
 * 1) MtM Exposure only: the decrease of exposure due to "exposure threshold" is computed based on MtM Exposure.
 * 2) MtM Exposure + Over Exposure: the decrease of exposure due to "exposure threshold" is computed 
 * based on MtM Exposure + Over Exposure. This is how Sophis behaves before 6.2 (and thus the default setting).
 *
 * @version 6.2
 */
enum eThresholdType
{
	/** Default is Net Exposure. */
	eThresholdDefault = 0,
	/** Exposure = MtM Exposure + Initial Amount (Initial Margin). */
	eThresholdNetExposure = 1,
	/** MtM Exposure = Collateralisation of the MtM moves (Variation Margin). */
	eThresholdMtMExposure = 2,
};

enum eAllotmentType
{
	/** Collateral Allotment type. */
	eAllotmentCollateral = 0,
	/** Principal Allotment type. */
	eAllotmentPrincipal = 1,
	/** Principal Underlying Allotment type. */
	eAllotmentPrincipalUnderlying = 2
};


/*
*	Type of IM negotiation
*
*	1) Per Agreement: Independent amount should be fixed at agreement level
*	2) Per Position: Independent amount should be fixed at position level
*
*	@version 6.2
*/
enum eIMNegotiationType
{
	/** Default is Per Agreement. */
	eDefaultNegotiation = 0,
	/** Amount fixed at agreement level */
	ePerAgreementNegotiation = 1,
	/** Amount fixed at position level */
	ePerPositionNegotiation,
};

/*
*	Type of Fee Mark Currency
*
*	1) in Principal Currency
*	2) in Billing Currency
*
*	@version 7.1.3
*/
enum eFeeMarkCurrency
{
	eInPrincipalCurrency = 0,
	eInBillingCurrency = 1,
};

enum eSpecificCptyEntityPair
{
	/** Cash Margin Call */
	eCptyEntityCashMarginCall = 0,
	/** Securities Margin Call */
	eCptyEntitySecuritiesMarginCall,
	/** Free Cash */
	eCptyEntityFreeCash,
	/** Internal Collateral Transfer */
	eCptyEntityCollateralTransfer,
};

/**
 * Enum indicating rules for rehypothecation.
 * @version 7.1
 */
enum eRehypothecation
{
	/** Rehypothecation allowed, default value. */
	erhAllowed = 0,
	/** Rehypothecation not allowed. */
	erhNotAllowed = 1,
};

/**
 * Various types of rounding for the fees tab.
 * @version 7.1.1
 */
enum eFeesRoundingType
{
	efrtNone = 1,
	/** Only applicable to Lending and Borrowing (commission). */
	efrtLendingBorrowing = 2,
	/** Only applicable to Collateral Remuneration. */
	efrtCollateralRemuneration = 3,
	/** Applicable to both Lending and Borrowing (commission) and Collateral Remuneration. */
	efrtBoth = 4,
};

/**
 * How fees rounding is applied.
 * @version 7.1.1
 */
enum eFeesRoundingLevel
{
	/** No rounding. */
	efrlNone = 1,
	/** Daily. */
	efrlDaily = 2,
	/** Whole period. */
	efrlWholePeriod = 3,
};

/**
 * Suitable security collateral structure
 * @version 7.2
 */
struct SValidSecurity
{
	long fInstrument;
	double fHaircut;
	long fSign;

	SValidSecurity(long Instrument, double Haircut, long Sign) 
	{
		fInstrument = Instrument;
		fHaircut = Haircut;
		fSign = Sign;
	}
};
typedef _STL::vector<SValidSecurity> SValidSecuritiesList;

struct SOPHIS_FIT ThirdPartyPair
{
	long fCounterparty;
	long fEntity;
	ThirdPartyPair(long ctpy, long enty)
	{
		fCounterparty = ctpy;
		fEntity = enty;
	}
};

class CSRLBAgreement;
class CSRAgreementDetails;
typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;
typedef _STL::shared_ptr<CSRAgreementDetails> CSRLBAgreementDetailsPtr;

#define _DEBUG_COLLATERAL_AGREEMENT_DEPO_TO_CHANGE 0

/**
 * CSRLBAgreement
 * Notion of CSA (Collateral Agreement).
 * @version 5.0.0
 */
class SOPHIS_FIT CSRLBAgreement
{
protected:
	CSRLBAgreement();	
public:
	virtual ~CSRLBAgreement();

	virtual CSRLBAgreement* Clone(){return 0;};	

public:

	/**
	* @version 5.2.7 The pointer returned is to be used inside the same function only.
	* If there is a need to save a pointer to CSRLBAgreement, use GetCSRLBAgreementSafePtr instead
	*/
	static CSRLBAgreement* GetCSRLBAgreement(long ctpy, long entity, long convention, sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi);

	/**
	 * Get agreement from ident.
	 * @param agreementId Agreement identifier.
	 * @version 7.1.1
	 * @return The pointer returned to be used inside the same function only, otherwise use GetCSRLBAgreementSafePtr instead.
	*/
	static CSRLBAgreement* GetCSRLBAgreement(long agreementId, sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi);

	/**
	 * Get agreement from external identifier.
	 * @param agreementRef External agreement reference (identifier).
	 * @version 7.1.1
	 * @return The pointer returned to be used inside the same function only, otherwise use GetCSRLBAgreementSafePtr instead.
	*/
	static CSRLBAgreement* GetCSRLBAgreement(const _STL::string& agreementRef, sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi);

	/**
	 * Creates new Collateral Agreement object to be filled and saved in the API mode.
	 * @return Pointer to new Collateral Agreement to be filled (and saved) by the user.
	 * @version 5.3.4
	 */
	static CSRLBAgreement* new_CSRLBAgreement(long ctpy, long entity, long convention);

	/** INTERNAL. */
	static void ReInitLBAgreements(const sophis::event::ISEvent & event);

	/**
	 * @return the agreement between cpty and entity if unique, NULL otherwise (multiple agreements
	 *	or none)
	 * @version 5.2.7 The pointer returned is to be used locally only.
	 * If there is a need to save a pointer to CSRLBAgreement, use GetCSRLBAgreementSafePtr instead
	 */
	static CSRLBAgreement* GetUniqueAgreement(long ctpy, long entity);

	/**
	* @version 5.2.7 The same methods as GetCSRLBAgreement and GetUniqueAgreement, but 
	* the shared_ptr returned can be used after function exits.
	*/
	static CSRLBAgreementPtr GetCSRLBAgreementSafePtr(long ctpy, long entity, long convention ,backoffice_kernel::eSavingMode mode = backoffice_kernel::smApi);
	static CSRLBAgreementPtr GetUniqueAgreementSafePtr(long ctpy, long entity);

	/**
	 * Get agreement from ident.
	 * @param agreementId Agreement identifier.
	 * @version 7.1.1
	 * @return shared_ptr returned can be used after function exits.
	*/
	static CSRLBAgreementPtr GetCSRLBAgreementSafePtr(long agreementId, sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi);

	/**
	 * Get agreement from external identifier.
	 * @param agreementRef External agreement reference (identifier).
	 * @version 7.1.1
	 * @return shared_ptr returned can be used after function exits.
	*/
	static CSRLBAgreementPtr GetCSRLBAgreementSafePtr(const _STL::string& agreementRef, sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi);

	/** Returns name of the agreement (if exists) or empty string. */
	static _STL::string GetAgreementName(long cpty, long entity, long convention);

	/** Returns unique id of the agreement. */
	static long GetAgreementId(long cpty, long entity, long convention);

	/** Returns (external) reference of the agreement (if exists) or empty string. */
	static _STL::string GetAgreementExternalReference(long cpty, long entity, long convention);

	/** Returns list of counterparties or entities suitable for dealing Stock Loans or CFDs on given instrument.
	 * @param underlyingCode Instrument is (sicovam) of the underlying (equity).
	 * @param cpty Counterpary of the deal (optional, can be zero).
	 * @param entity Entity of the deal (optional, can be zero).
	 * @param convention Convention of the collateral agreement (optional, can be zero).
	 * @param lbaType If only agreements of certain type should be taken into account.
	 * @param quantity Only sign is taken into account.
	 * @param date Optional, defaults to today's date.
	 * @return List of agreements suitable.
	 * @version 6.2.2 
	 */
	static _STL::list<const CSRLBAgreement*> GetSuitableAsPrincipal(long underlyingCode, long cpty, long entity, long convention,
		eCacheLbaType lbaType = eCacheLbaTypeAny, double quantity = 0, long date = 0);

	/** Returns list of counterparties or entities suitable for margin calls.
	 * @param underlyingCode Instrument is (sicovam) of the underlying (equity).
	 * @param cpty Counterpary of the deal (optional, can be zero).
	 * @param entity Entity of the deal (optional, can be zero).
	 * @param convention Convention of the collateral agreement (optional, can be zero).
	 * @param lbaType If only agreements of certain type should be taken into account.
	 * @param quantity Only sign is taken into account.
	 * @param date Optional, defaults to today's date.
	 * @return List of agreements suitable.
	 * @version 6.2.2 
	 */
	static _STL::list<const CSRLBAgreement*> GetSuitableAsCollateral(long underlyingCode, long cpty, long entity, long convention,
		eCacheLbaType lbaType = eCacheLbaTypeAny, double quantity = 0, long date = 0);

	/** 
	 * Returns the unique agreement identifier.
	 * @version 7.1.1
	 */
	long GetId() const;

	/** Returns flag indicating if given agreement is a physical agreement (default) or a virtual one. */
	virtual bool IsVirtualAgreement() const { return false; }

	/** Returns reference to the master physical agreement in case of virtual agreement or to self if non-virtual (default). */
	virtual const CSRLBAgreement& GetMaster() const { return *this; }

	/** Get the list of agreements, including virtual, within master agreement family.
	 * Only the agreements referring to physical counterparties and entities are returned.
	 * For non-master agreements, returns list containing self.
	 * @return unique set (list) of agreements (counterparty and entity pairs) within family. */
	virtual void GetAgreementFamilyList(_STL::vector<ThirdPartyPair>& familyList) const = 0;

	/** Get the list of manual virtual agreements if the eAgreementThirdsType is eThirdsTypeManual.
	* @return unique set (list) of agreements (counterparty and entity pairs). */
	virtual void GetManualVirtualList(_STL::vector<ThirdPartyPair>& virtualList) const = 0;

	/** Returns counterparty ident. */
	virtual long GetCtpy() const = 0;

	/** Returns entity ident. */
	virtual long GetEntity() const = 0;
	
	/** Returns convention ident. */
	virtual long GetConvention() const = 0;

	/** Returns depositary ident. */
	virtual long GetDepositary() const = 0;

	/** Save changes made to a new or existing LB Agreement. This save
		is for use via the API, as it bypasses much of the UI functionality
		@param	mode specifies whether the save is being carried out by the API(default) or GUI
		@throw VoteException if one CSRLBAgreementAction rejects modifications. Note that in such a case
		no modification of the database has been done so that your previous save are still correct.
		@return - 'true' if associated dialog is to be closed, 'false' - otherwise
	 */
	virtual bool Save(sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi)
		throw (sophis::tools::VoteException) = 0;

	/** Save in a transaction mode.
		In this mode, you can save different data before commiting it to the database.
		It executes the insert or update query and fill the message.
		It is not commited or rolled back. You must do it when all your data are saved.
		It does not send messages to the other workstations. You must do it by ev.ExecuteAll().
		@param mode specifies whether the action is being carried out by the API or GUI.
		@param ev is the event vector which will record all the messages to be sent after commiting.
		@throw VoteException if one CSRLBAgreementAction rejects modifications. Note that in such a case
		no modification of the database has been done so that your previous save are still correct
		and can be commited.
		@throw ExceptionBase if there is one problem when saving. Here you have to roll back all the previous modification.
	*/
	virtual void MultiSave(sophis::backoffice_kernel::eSavingMode mode, sophis::tools::CSREventVector &ev)
		throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase) = 0;

	/** Delete in a transaction mode.
		In that mode, you can delete different data before commiting in the database
		It executes the delete queries and fill the message.
		It is not commited or rolled back. You must do it when all your data are saved
		It does not send messages to the other workstations. You must do it by ev.ExecuteAll()
		@param mode specifies whether the action is being carried out by the API or GUI.
		@param ev is the event vector which will record all the messages to send after commiting.
		@throw VoteException if one CSRLBAgreementAction rejects that modification. Note that in such a case
		no modification of the database has been done so that your previous save are still correct
		and can be committed
		@throw ExceptionBase if there is one problem when saving. Here you have to roll back all the previous modification.
	*/
	virtual void MultiDelete(sophis::backoffice_kernel::eSavingMode mode, sophis::tools::CSREventVector &ev) 
		throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase) = 0;

	/**
		General 
	*/

	/** Get the name of the agreement. */
	virtual _STL::string GetContractName() const = 0;
	
	/** Set new name for the agreement. */
	virtual void SetContractName(const _STL::string& str) = 0;

	/** Get the comment string from the agreement. */
	virtual _STL::string GetComments() const = 0;

	/** Set new comment string for the agreement. */
	virtual void SetComments(const _STL::string& str) = 0;

	/** Get the validity start of the agreement.
	 * @return - the date in the long format (e.g. number of days since 01/02/1904) */
	virtual long GetBeginDate() const = 0;

	/**	Set the validity start date for the agreement. */
	virtual void SetBeginDate(const long date) = 0;

	/** Get the validity end date of the agreement. */
	virtual long GetEndDate() const = 0;

	/** Set the validity end date for the agreement. */
	virtual void SetEndDate(const long date) = 0;

	/** Get TriParty, e.g. if there is an another external third party reference set for the agreement. */
	virtual long GetTriParty() const = 0;

	/** Set TriParty, e.g. another external third party reference for the agreement.
	*/
	virtual void SetTriParty(const long ident) = 0;

	/** Get TriParty Margin Call settings for Stock Loan and Repo Management GUI.
		Default is 'None' (0 or 1)
	*/
	virtual long GetTriPartyMarginCall() const = 0;

	/** Set TriParty Margin Call settings for Stock Loan and Repo Management GUI.
		@param ident - the margin call setting (1 = 'None')
	*/
	virtual void SetTriPartyMarginCall(const long ident) = 0;

	/** Returns external reference of the agreement. */
	virtual _STL::string GetExternalReference() const = 0;

	/** Sets external reference of the agreement. */
	virtual void SetExternalReference(const _STL::string& str) = 0;

	/** Get default counterparty and entity pair to be used for specificPair. */
	virtual void GetSpecificCounterpartyEntity(const eSpecificCptyEntityPair specificPair, long& counterparty, long& entity) const = 0;

	/** Set default counterparty and entity pair to be used for specificPair. */
	virtual void SetSpecificCounterpartyEntity(const eSpecificCptyEntityPair specificPair, const long counterparty, const long entity) = 0;

	/** Get how list of other thirds belonging to agreement are managed. */
	virtual eAgreementThirdsType GetThirdsType() const = 0;

	/** Set how list of other thirds belonging to agreement are managed. */
	virtual void SetThirdsType(const eAgreementThirdsType thirdsType) = 0;

	/** Returns the number of lines in the thirds list. */
	virtual long GetThirdsLinesNumber() const = 0;

	/**	Get the third (counterparty) of the corresponding line in agreement thirds list.
	 * @param numLine - is the number of line from list to deal with (starts with 0). */
	virtual long GetThirdsCounterparty(int numLine) const = 0;

	/**	Set the third (counterparty) in agreement thirds list.
	 * @param numLine - is the number of line of the list to deal with (starts with 0).
	 * @param thirdId - is the third party id OR 0 if has to be set to <empty> (e.g. no value) */
	virtual void SetThirdsCounterparty(int numLine, const long thirdId) = 0;

	/**	Get the third (entity) of the corresponding line in agreement thirds list.
	 * @param numLine - is the number of line from list to deal with (starts with 0). */
	virtual long GetThirdsEntity(int numLine) const = 0;

	/**	Set the third (entity) in agreement thirds list.
	 * @param numLine - is the number of line of the list to deal with (starts with 0).
	 * @param thirdId - is the third party id OR 0 if has to be set to <empty> (e.g. no value) */
	virtual void SetThirdsEntity(int numLine, const long thirdId) = 0;

	/** 
		Default LB Template list
	*/

	/** Get the number of lines in Default Template list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	virtual long GetDefaultTemplateLinesNumber() const = 0;

	/**	Get the template instrument reference (ident, sicovam) of the corresponding line in Default Template list.
		@param numLine - is the number of line from list to deal with (starts with 0).
	*/
	virtual long GetDefaultTemplateName(int numLine) const = 0;

	/**	Set the template instrument reference (ident, sicovam) for Default Template list.
		@param numLine - is the number of line of the list to deal with (starts with 0).
		@param sicovam - is the reference (ident, sicovam) of the instrument
		OR 0 if has to be set to <empty> (e.g. no value)
		Throws a CSRCollateralException if out of range i.e. if there is not an existing template at numLine.
	*/
	virtual void SetDefaultTemplateName(int numLine, const long sicovam) = 0;

	/** Adds a new template to the list of default templates. It adds the template to the back of the list.
		@param sicovam is the reference (ident, sicovam) of the instrument
		OR 0 if has to be set to <empty> (e.g. no value)
		@param str is the model of the default template line.
	*/
	virtual void AddNewDefaultTemplate(const long sicovam, const _STL::string& str) = 0;

	/** Get the value from the list of pre developed controls on the instrument/transaction definition screen 
		to be used with Template definition.
		The list of controls is defined through sophis toolkit. This control defines which field of the dialog 
		are editable.
		@param numLine - is the number of line of the Lending/Borrowing Template list to deal with (starts with 0).
	*/
	virtual _STL::string GetDefaultTemplateModel(int numLine) const = 0;

	/** Set the value from the list of pre developed controls on the instrument/transaction definition screen
		to be used with this Lending/Borrowing Template definision.
		The list of controls is defined through sophis toolkit. This control defines which field of the dialog 
		are editable.
		@param numLine - is the number of line of the Lending/Borrowing Template list to deal with (starts with 0).
		@param str - is the pointer to buffer containing the new value. It has to be like one of those defined
		through Toolkit. Or it could be an empty string to set to <empty>
		@throw - CSRCollateralException if there is an internal error 
		(e.g. new value is wrong or too long)
	*/
	virtual void SetDefaultTemplateModel(int numLine, const _STL::string& str) = 0;
	
	/** Get Collateral Folio Id defined with the Agreement.
		@return - collateral folio id if defined with the agreement, 
		or (if not defined) the one defined in the 'Conventions' (see CSRCollateralEnvironment::GetPerimeterFolio() {@link CSRCollateralEnvironment::GetPerimeterFolio} ) 
		@version 5.2.2
	*/
	virtual long GetCollateralFolio() const = 0;

	/** Set Collateral Folio Id to be defined with the Agreement. It should be 'child' id of Collat_Folio define in 
	RiskPrefs.
	@throw - CSRCollateralException if there is an internal error 
	(e.g. supplied value is not sutable)
	@version 5.2.2
	*/
	virtual void SetCollateralFolio(long folioId) = 0;
	
	/** 
	 * Returns whether collateral should be booked in principal folio.
	 * This only have effect on securities in contract or dedicated pool.
	 * @return true if the collateral should be booked in the principal folio
	 * @version 7.1.3
	 */
	virtual bool GetKeepCollatInPricipalFolio() const = 0;

	/** 
	* Sets whether collateral should be booked in principal folio.
	* This only have effect on securities in contract or dedicated pool.
	* @param collatInPrincipalFolder whether the collateral should be booked in the principal folio
	* @version 7.1.3
	*/
	virtual void SetKeepCollatInPricipalFolio(bool collatInPrincipalFolder) = 0;

	/**
	 * Returns Margin Call Folio Id defined with the Agreement.
	 * Introduced in 5.2.5, the Margin Call Folio is used for subsequent margin calls (both cash and security) while
	 * collateral folio is used for initial cash collateral in case of Security vs Cash Pool.
	 * Unlike the Collateral Folio, Margin Call Folio can be any folio in the system.
	 *
	 * @return Margin Call Folio Id if defined at the Agreement level; If undefined, the Collateral Folio is returned,
	 * see GetCollateralFolio() {@link GetCollateralFolio}.
	 *
	 * @version 5.2.5
	 */
	virtual long GetMarginCallFolio() const = 0;

	/**
	 * Set Margin Call Folio Id.
	 * Introduced in 5.2.5, the Margin Call Folio is used for subsequent margin calls (both cash and security) while
	 * collateral folio is used for initial cash collateral in case of Security vs Cash Pool.
	 * Unlike the Collateral Folio, Margin Call Folio can be any folio in the system.
	 *
	 * @param folioId Folio id (can be any folio in the system).
	 *
	 * @version 5.2.5
	 */
	virtual void SetMarginCallFolio(long folioId) = 0;

	/** Calendar used for various date and offset calculations related to the collateral agreement.
	* Collateral Agreement calendar is used in both securities lending borrowing (Advanced Stock Loan module)
	* and cash pool calculations. Some of the calculations relying on the calendar:
	* - cash pool interest (i.e. start and end periods are calculated according to the calendar and offset)
	* - automatic tickets and payment date for cash remuneration tickets during forecast
	* - automatic tickets and payment date for stock loan commission tickets during forecast
	* - accrued interest and accrued commission calculations
	* - next margin call date for collateral agreement
	* - position cash flows for cash collateral (including Nostro Mgmt report)
	* - position cash flows for stock loan and repos (including Nostro Mgmt report)
	* @param sicovam (Optional) Used to get calendar if no agreement setting are present.
	@version 5.1
	*/
	const static_data::CSRCalendar * GetCalendar(long sicovam=0) const;

	/**
		Credit Risk
	*/

	/** Get agreement model name. */
	virtual _STL::string GetModel() const = 0;

	/** Set new Model name. */
	virtual void SetModel(const _STL::string& str) = 0;

	/** Get the currency
		@return - CODE of the currency
	*/
	virtual long GetCurrency() const = 0;

	/** Set the currency
		@param ccy - the CODE for the new currency OR 0 to set to <empty>
	*/
	virtual void SetCurrency(const long ccy) = 0;

	/** Get the Place
		@return - the CODE of the place
	*/
	virtual long GetPlace() const = 0;

	/** Set the Place
		@param val - the CODE for the new place OR 0 to set to <empty>
	*/
	virtual void SetPlace(const long val) = 0;

	/** Get Default Credit Risk Spot type
	@return Spot type, like typeOPEN, typeLAST, etc -- see RTEvents.h;
	-1 if no value is set (<empty>).
	see CSRInstrument::GetFixing() {@link CSRInstrument::GetFixing}
	@throw - CSRCollateralException if there is an internal error 
	*/
	virtual int GetDefaultSpotForCreditRisk() const = 0;

	/** Set value for Default Credit Risk Spot type
	@param val - the new value, -1 if no value has to be set (<empty>)
	@throw - CSRCollateralException if there is an internal error 
	*/
	virtual void SetDefaultSpotForCreditRisk(const int tag) = 0;

	/** Get Default Credit Risk Spot timing
	@return - 1 for "Yesterday", 2 for "Today", 
	0 if no value is set (<empty>)
	@throw - CSRCollateralException if there is an internal error 
	*/
	virtual long GetDefaultSpotTimingForCreditRisk() const = 0;

	/** Set value for Default Credit Risk Spot timing
	@param val - the new value, one of the following: 
	1 for "Yesterday", 2 for "Today", 0 if no value has to be set (<empty>)
	@throw - CSRCollateralException if there is an internal error 
	(for example if val < 0 && > 2)
	*/
	virtual void SetDefaultSpotTimingForCreditRisk(const long val) = 0;

	/**
	 * Returns the Global Calculation flag value.
	 * If set, the Global Calculation flag indicates the cash pool and security pool margin calls
	 * must cover the whole agreement risk. By default (unset), the margin calls are covering
	 * only the current pool risk.
	 *
	 * @return true if flag is set; false (default) otherwise.
	 *
	 * @version 5.2.5
	 */
	virtual bool IsGlobalCalculation() const = 0;

	/**
	 * Sets the Global Calculation flag.
	 * If set, the Global Calculation flag indicates the cash pool and security pool margin calls
	 * must cover the whole agreement risk. By default (unset), the margin calls are covering
	 * only the current pool risk.
	 *
	 * @param gc New flag value.
	 *
	 * @version 5.2.5
	 */
	virtual void SetGlobalCalculation(bool gc) = 0;


	/**
	 * Sets the value to the Include Accrued Interest / Include Accrued Commission flag from the Credit Risk Calculation tab.
	 * The flag indicates if the accrued amount of interest / accrued amount of commission should be taken into account for credit
	 * risk calculation.
	 * @param val New flag value.
	 * @version 5.2.5
	 */
	virtual void SetAccruedInterestIncluded(eAccruedInterestCommission val) = 0;

	/**
	 * Returns agreement specific setting to be applied to inverse hedging and/or haircut.
	 * Using this preference it is possible to override the behavior of
	 * the INVERSE_HAIR_CUT global pref.
	 *
	 * @param useCachedValue True to return the cached value for performance reason; false
	 * to re-read the value.
	 * @return inverse hedging and/or haircut value for this agreement.
	 * 
	 * @version 5.2.5
	 */
	virtual eInverseHaircut GetInverseHaircut(bool useCachedValue = true) const = 0;

	/**
	* Sets agreement specific inverse hedging and/or haircut preference.
	* Using this preference it is possible to override the behavior of
	* the INVERSE_HAIR_CUT global pref.
	* 
	* @param val New pref value.
	* @version 5.2.5
	*/
	virtual void SetInverseHaircut(eInverseHaircut val) = 0;

	/**
	* Returns agreement specific setting for Rating Agency to use.
	* Using this preference it is possible to override the default
	* StockLoanRatingAgency global pref.
	*
	* @return rating agency.
	* 
	* @version 5.2.7
	*/
	virtual long GetRatingAgency() const = 0;

	/**
	* Sets agreement specific setting for Rating Agency to use.
	* Using this preference it is possible to override the default
	* StockLoanRatingAgency global pref.
	* 
	* @param val New pref value.
	* @version 5.2.7
	*/
	virtual void SetRatingAgency(long val) = 0;

	/**
	* Returns agreement specific indicator selector to use.
	*
	* @return indicator selector
	* @version 6.2.0
	*/
	virtual long GetIndicatorSelector() const = 0;

	/**
	* Sets agreement specific indicator selector to use.
	*
	* @param val New pref value
	* @version 6.2.0
	*/
	virtual void SetIndicatorSelector(long val) = 0;

	/**
	* Returns agreement specific IM Negotiation type to use.
	*
	* @return indicator selector
	* @version 6.2.0
	*/
	virtual eIMNegotiationType GetIMNegotiationType() const = 0;

	/**
	* Sets agreement specific IM Negotiation type to use.
	*
	* @param val New pref value
	* @version 6.2.0
	*/
	virtual void SetIMNegotiationType(long val) = 0;

	/**
	* Returns the prototype value selected for the Portfolio Based Initial Margin.
	*
	* @return prototype value.
	* @version 7.1
	*/
	virtual _STL::string GetPortfolioBasedIM() const = 0;

	/**
	* Sets the prototype value for the Portfolio Based Initial Margin.
	*
	* @param val New Portfolio Based Initial Margin value.
	* @version 7.1
	*/
	virtual void SetPortfolioBasedIM(_STL::string& val) = 0;

	/**
	 * Returns initial margin proxy object, if applicable.
	 * The returned object is parameterized according to the current settings.
	 * @version 7.1.1
	 */
	const CSRInitialMarginProxy* GetPortfolioBasedIMImpl() const;

	/**
	 * Set initial margin proxy implementation and corresponding parameters.
	 * @version 7.1.1
	 */
	void SetPortfolioBasedIMImpl(const CSRInitialMarginProxy* impl);

	/**
	 * Internal. Return the document id containing the settings for the Portfolio Based Initial Margin.
	 * See {@link CSRInitialMarginProxy}.
	 * @version 7.1.1
	 */
	virtual long GetPortfolioBasedIMSettings() const = 0;

	/**
	 * Internal. Set the document id containing settings for the Portfolio Based Initial Margin.
	 * See {@link CSRInitialMarginProxy}.
	 * @version 7.1.1
	 */
	virtual void SetPortfolioBasedIMSettings(long docId) = 0;

	/**
	* Returns the Portfolio Based Initial Margin Factor.
	*
	* @return initial margin factor.
	* @version 7.1
	*/
	virtual double GetPortfolioBasedIMFactor() const = 0;

	/**
	* Sets value for the Portfolio Based Initial Margin Factor.
	*
	* @param val New Initial Margin Factor value.
	* @version 7.1
	*/
	virtual void SetPortfolioBasedIMFactor(double val) = 0;

	/**
		Margin Call 
	*/

	/** Get the Margin Frequency. */
	virtual _STL::string GetMarginFrequency() const = 0;
	
	/** Set the Margin Frequency
		@param str - pointer to the new value string OR to the empty string to set to <empty>
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long or is not in the set of allowed values)
	*/
	virtual void SetMarginFrequency(const _STL::string& str) = 0;
	
	/** Get Cash Pool Remuneration Frequency. */
	virtual _STL::string GetRemunerationFrequency() const = 0;
	
	/** Set Cash Pool Remuneration Frequency
		@param str - pointer to the new value string OR to the empty string to set to <empty>
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long or is not in the set of allowed values)
	*/
	virtual void SetRemunerationFrequency(const _STL::string& str) = 0;

	/** Get Automatic Fee Mark (yes/no or <empty>)
		@return - 0 if no value is set (<empty>), 1 - if "yes", 2 - if "no"
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetAutomaticFeeMark() const = 0;
	
	/** Set Automatic Fee Mark (yes/no or <empty>)
		@param val - the new value: 0 if no value to be set (<empty>), 1 - for "yes", 2 - for "no"
		@throw - CSRCollateralException if there is an internal error
		(for example if value is < 0 && > 2)
	*/
	virtual void SetAutomaticFeeMark(const long val) = 0;

	/**
	 * Returns the value of the Rolling Interest flag specified on the Margin Call tab.
	 * The purpose of the Rolling Interest is to pay the accrual interest when doing
	 * a cash margin call, either per contract or pool.
	 * Default value is false.
	 * @return true if the flag is set; false (default) otherwise.
	 * @version 5.2.5
	 */
	virtual bool IsRollingInterest() const = 0;

	/**
	 * Sets the value of the Rolling Interest flag specified on the Margin Call tab.
	 * The purpose of the Rolling Interest is to pay the accrual interest when doing
	 * a cash margin call, either per contract or pool.
	 * @param val New flag value.
	 * @version 5.2.5
	 */
	virtual void SetRollingInterest(bool val) = 0;

	/**Get the sufficiency limit as required by Fidelity (RQv5.2.7)
		Returns the Sufficiency Limit value defined in the margin call tab
		@return - 0 means sufficiency check is not enabled
	*/
	virtual long GetSufficiencyLimit() const = 0;

	/**Set the sufficiency limit as required by Fidelity (RQv5.2.7)
	*/
	virtual void SetSufficiencyLimit(long limit) = 0;

	/**
	* Returns the value of the Don't Generate Alerts flag specified on the Margin Call tab.
	* The purpose of the this flag is allow users to switch off the generation of 'alerts' tickets
	* when a margin call has to be done.
	* Default value is false.
	* @return true if the flag is set; false (default) otherwise.
	* @version 5.3.5.1
	*/
	virtual bool IsDontGenerateAlerts() const = 0;

	/**
	* Sets the value of the Don't Generate Alerts flag specified on the Margin Call tab.
	* The purpose of the this flag is allow users to switch off the generation of 'alerts' tickets
	* when a margin call has to be done.
	* @param val New flag value.
	* @version 5.3.5.1
	*/
	virtual void SetDontGenerateAlerts(bool val) = 0;

	/**Get the cash sufficiency limit
		Returns the Cash Sufficiency Limit value defined in the margin call tab
		@return - 0 means sufficiency check is not enabled for cash margin calls
		@version 5.3.6
	*/
	virtual long GetCashSufficiencyLimit() const = 0;

	/**Set the cash sufficiency limit
		@version 5.3.6
	*/
	virtual void SetCashSufficiencyLimit(long limit) = 0;

	/**Get the time sufficiency limit
		Returns the Time Sufficiency Limit value defined in the margin call tab
		@return - 0 means the amount (cash or sec) sufficiency limit must always be satisfied regardless the time
		@version 5.3.6
	*/
	virtual long GetTimeSufficiencyLimit() const = 0;

	/**Set the time sufficiency limit
		@version 5.3.6
	*/
	virtual void SetTimeSufficiencyLimit(long limit) = 0;

	/**
	* Returns the value of the Mark Spot flag specified on the Margin Call tab.
	* @return true if the flag is set; false (default) otherwise.
	* @version 5.3.6
	*/
	virtual bool IsMarkSpot() const = 0;

	/**
	* Sets the value of the Mark Spot flag specified on the Margin Call tab.
	* @param val New flag value.
	* @version 5.3.6
	*/
	virtual void SetMarkSpot(bool val) = 0;

	/** Get Automatic Feeding
	@return - true if automatic feeding of Fee Mark should be done, false otherwise
	@version 5.3.6
	*/
	virtual bool IsAutomaticFeeding() const = 0;

	/** Set Automatic Feeding
	@param val - the new value
	@version 5.3.6
	*/
	virtual void SetAutomaticFeeding(const bool val) = 0;

	/** Get value for Internal transfer when possible.
	* @return - true if internal transfer should be done instead of margin call
	* @version 6.3
	*/
	virtual bool IsInternalTransfer() const = 0;

	/** Set the value for Internal transfer when possible
	* @param vall - the new value
	* @version 6.3
	*/
	virtual void SetInternalTransfer(bool val) = 0;

	/** 
		Cash Collateral Remuneration list
	*/

	/** Get the number of lines in Collateral Remuneration list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	virtual long GetCashRemunerationLinesNumber() const = 0;

	/** Get the Currency from the Cash Collateral Remuneration list
		@param numLine - the number of line to deal with (starts with 0)
		@return - the CODE of the Currency
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCcyCashRemuneration(int numLine) const = 0;

	/** Set the Currency for Cash Collateral Remuneration list
		@param numLine - the number of line to deal with (starts with 0)
		@param ccy - new Currency CODE to be set OR 0 to set to <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if the CODE is not found)
	*/
	virtual void SetCcyCashRemuneration(int numLine, const long ccy)  = 0;

	/** Get Rate for Cash Collateral Remuneration list (depends on the currency selected)
		@param numLine - the number of the line to deal with (starts with 0)
		@return - the Rate
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetRateCashRemuneration(int numLine) const = 0;

	/** Set the Rate for Cash Collateral Remuneration list (depends on the currency selected)
		@param numLine - the number of the line to deal with (starts with 0)
		@param rate - the new Rate to use (depends on the Currency selected) OR 0 to set to <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if the Rate is not found for the selected Currency)
	*/
	virtual void SetRateCashRemuneration(int numLine, const long rate) = 0;
	
	/** Get the Begin Margin Date for Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@return - the date in the long format (e.g. number of days since 01/02/1904)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetBeginMarginDate(int numLine) const = 0;
	
	/** Set the Begin Margin Date for Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@param date - the date in the long format (e.g. number of days since 01/02/1904)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetBeginMarginDate(int numLine, const long date) = 0;

	/** Get the default rate for a given currency. This returns the rate of the 
		default line if it is defined. If it is not defined, it returns the rate
		from the top most line with the specified ccy. If there is no such line, 
		it returns 0.
		@param date - the date for which to find the rate
		@param ccy - the ccy for which to find the rate
		@return - the rate as double
	*/
	virtual long GetMarginCallDefaultRateForCcy(long date, long ccy) const = 0;

	/** Get the Long Margin from Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@return - the Long Margin as double
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetLongMargin(int numLine) const = 0;
	
	/** Set Long Margin for the Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@param val - the new Long Margin to be set
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetLongMargin(int numLine, const double val) = 0;
	
	/** Get the Short Margin from Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@return - the Short Margin as double
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetShortMargin(int numLine) const = 0;
	
	/** Set Short Margin for the Cash Collateral Remuneration list
		@param numLine - the number of the line to deal with (starts with 0)
		@param val - the new Short Margin to be set
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetShortMargin(int numLine, const double val) = 0;

	/**
		Get the Currency of the default line in the Collateral Remuneration list.
        This is used as the currency for the default account when transfering cash between
		the Free Cash pool and the Collateral Cash pool.
		@return The Currency of the default line in the Collateral Remuneration list. 0 if not set.
	 */
	virtual long GetDefaultCollateralCashAccCurrency() const = 0;
	
	/**
		Get the Rate of the default line in the Collateral Remuneration list.
        This is used as the currency for the default account when transfering cash between
		the Free Cash pool and the Collateral Cash pool.
		@return The Rate of the default line in the Collateral Remuneration list. 0 if not set.
	 */
	virtual long GetDefaultCollateralCashAccRate() const = 0;

	/**
		Gets the line number of the default line in the Collateral Remuneration list.
		@return line number of the default line in the Collateral Remuneration list as a long. -1 if not set.
	 */
	virtual int GetDefaultCollateralCashLine() const = 0;

	/**
		Checks if the line is the default line.
		@param line - the line number
		@return eDefaultAcc which specifies if the line is default or not.
	 */
	virtual eDefaultAcc GetIsCollateralCashLineDefault(int line) const = 0;

	/**
	 * Returns CSA disc. spread value for given line.
	 * @version 7.1.2
	 */
	virtual double GetDiscountingSpread(int numLine) const = 0;

	/**
	 * Set CSA disc. spread value for given line.
	 * @version 7.1.2
	 */
	virtual void SetDiscountingSpread(int numLine, const double val) = 0;

	/**
	 * Returns default currency, rate, and spread for CSA discounting, data being fetched from the Margin Call tab.
	 * @version 7.1.2
	 */
	void GetDiscounting(long& currency, long& rate, double& spread) const;

	/** 
		Rounding Prefs list
	*/

	/** Get the rounded value of 'value' according to Margin Call Rounding Prefs.
	@param ccy - currency to be match on the list
	@param value - the value to be rounded
	@param rounding - optional. rounding precision is returned.
	@param type - optional. rounding type is returned.
	@return - the rounded value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetRoundedValue(long ccy, double value, double * rounding = 0, short * type = 0) const = 0;
	
	/** Get the rounded value of 'value' according to Collateralized Price Rounding Prefs
	@param allotment - allotment to be matched on this list
	@param ccy - currency to be matched on the list
	@param value - the value to be rounded
	@return - the rounded value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetCollateralizedPriceRoundedValue(long allotment, long ccy, double value) const = 0;

	/**
		Collateral Stocks (Allotment, Cash, Index/Basket)
	*/

#if 0
	/** Get the value for LoadFrom. This is the name of LB Agreement (by its name) to have been used to 
		fill values for GeneralRulesPerAllotment and Index/Basket lists, or <empty> if none have been
		selected.
		@param str - is the pointer to buffer allocated in the client space to put/copy the value.
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long)
	*/
	virtual void GetCollateralStocksLoadFrom(char* str, int size) const = 0;
	
	/** Set the value for LoadFrom. This is the name of LB Agreement (by its name) has to be used to 
		fill values for GeneralRulesPerAllotment and Index/Basket lists, if <empty> - none has to be
		selected.
		@param str - pointer to the new value string
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long or if no LB Agreement have been found with such a name)
	*/
	virtual void SetCollateralStocksLoadFrom(const char* val) = 0;
#endif

	/** 
		Allotment list [Collateral Stocks]
	*/

	/** Get the number of lines in Allotment list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	virtual long GetCollateralAllotmentLinesNumber() const = 0;

	/** Get the Allotment value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the allotment by its ID 
				or -2 if <Cash Collateral> 
				or -1 if <star> 
				or 0 if <emtpy> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCollateralAllotment(int numLine) const = 0;
	
	/** Set the Allotment value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new allotment value by its ID, 
				or -2 for <Cash Collateral>
				or -1 for <star>, 
				or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such allotment has not been found)
	*/
	virtual void SetCollateralAllotment(int numLine, const long val) = 0;	// -1 is <star>, 0 is <empty>

	/** Get the Currency value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the currency CODE OR 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCollateralAllotmentCcy(int numLine) const = 0;
	
	/** Set the Currency value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new currency CODE 
		OR 0 if has to set to <empty> (e.g. no value) OR -1 if has to be set to <star>
		@throw - CSRCollateralException if there is an internal error
		(e.g. if currency CODE is invaled)
	*/
	virtual void SetCollateralAllotmentCcy(int numLine, const long val) = 0;		// -1 is <star>, 0 is <reset>

	/** Get the Sign value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCollateralAllotmentSign(int numLine) const = 0;
	
	/** Set the Sign value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
		(for example if val is < -1 && > 3)
	*/
	virtual void SetCollateralAllotmentSign(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Haircut from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - haircut value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHaircutInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	virtual double GetCollateralAllotmentHaircutInProduct(int numLine, eHairCutType hairCutType) const = 0;

	double GetCollateralAllotmentHaircut(int numLine, eHairCutType hairCutType, double *valueInProduct=0) const;
	
	/** Set Haircut for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new haircut value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHaircutInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	virtual void SetCollateralAllotmentHaircutInProduct(int numLine, const double val) = 0;

	void SetCollateralAllotmentHaircut(int numLine, const double val);

	/**
	 * For Cash (i.e. currency) only, returns the value of the haircut for cash margin call.
	 * Unlike GetCashMarginCallHaircutInProduct(), this method does take into account the INVERSE_HAIR_CUT preference, 
	 * which results in inversion (1/x) of resulting value if such preference is set.
	 *
	 * @param numLine The line number in the Collateral Stocks Allotment list (starts with zero).
	 * @param valueInProduct Optional parameter to retrieve the original value specified by user, ignoring any haircut reversal settings.
	 * @version 5.2.5
	 */
	double GetCashMarginCallHaircut(int numLine, double *valueInProduct=0) const;

	/**
	 * For Cash (i.e. currency) only, returns the value of the haircut for cash margin call.
	 * Does not take the INVERSE_HAIR_CUT preference into the account.
	 *
	 * @param numLine The line number in the Collateral Stocks Allotment list (starts with zero).
	 * @version 5.2.5
	 */
	virtual double GetCashMarginCallHaircutInProduct(int numLine) const = 0;

	/**
	 * For cash (i.e. currency) only, sets the values of the cash margin calls haircut.
	 * Unlike SetCashMarginCallHaircutInProduct(), this method does take into account the INVERSE_HAIR_CUT preference, 
	 * which results in inversion (1/x) of saved value if such preference is set.
	 *
	 * @param numLine The line number in the Collateral Stocks Allotment list (starts with zero).
	 * @version 5.2.5
	 */
	void SetCashMarginCallHaircut(int numLine, const double val);

	/**
	 * For cash (i.e. currency) only, sets the values of the cash margin calls haircut.
	 * Does not take the INVERSE_HAIR_CUT preference into the account.
	 *
	 * @param numLine The line number in the Collateral Stocks Allotment list (starts with zero).
	 * @version 5.2.5
	 */
	virtual void SetCashMarginCallHaircutInProduct(int numLine, const double val) = 0;

	/** Get Collateral from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - collateral value
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetCollateralAllotmentCollateral(int numLine) const = 0;
	
	/** Set Collateral for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new collateral value
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCollateralAllotmentCollateral(int numLine, const double val) = 0;

	/** Get Index / Basket Ref from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the Referance code or -1 if <star>, or 0 if <empty> (e.g. is not set)
		@throw - CSRCollateralException if there is an internal error
	*/	
	virtual long GetCollateralAllotmentBasketRef(int numLine) const = 0;


	/** Set Index / Basket Ref from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new referance value by its <sicovam>, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such referance has not been found)
	*/	
	virtual void SetCollateralAllotmentBasketRef(int numLine, const long val) = 0;

	/** Get Condition1 from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/	
	virtual _STL::string GetCollateralAllotmentCondition1(int numLine) const = 0;

	/** Get Condition2 from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetCollateralAllotmentCondition2(int numLine) const = 0;

	/** Get Condition3 from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetCollateralAllotmentCondition3(int numLine) const = 0;

	/** Set Condition1 for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetCollateralAllotmentCondition1(int numLine, _STL::string& condition) = 0;

	/** Set Condition2 for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetCollateralAllotmentCondition2(int numLine, _STL::string& condition) = 0;

	/** Set Condition3 for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetCollateralAllotmentCondition3(int numLine, _STL::string& condition) = 0;

	/** Get Excluded from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - true if excluded, false otherwise
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual bool GetCollateralAllotmentExcluded(int numLine) const = 0;

	/** Set Excluded for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - new excluded value (true if excluded, false otherwise)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCollateralAllotmentExcluded(int numLine, bool val) = 0;

	/** Get Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCollateralAllotmentMarket(int numLine) const = 0;

	/** Set Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value (see CSRMarket::fMarketCode) or 0 for <empty/reset> or -1 for <*>
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCollateralAllotmentMarket(int numLine, long val) = 0;

	/** Get Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetCollateralAllotmentMaturity(int numLine) const = 0;

	/** Set Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetCollateralAllotmentMaturity(int numLine, long val) = 0;

	/** Get Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetCollateralAllotmentRating(int numLine) const = 0;

	/** Set Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty/reset
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetCollateralAllotmentRating(int numLine, long val) = 0;

	/** Get Industry associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.3.2
	*/
	virtual long GetCollateralAllotmentIndustry(int numLine) const = 0;

	/** Set Industry associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty/reset
	@throw - CSRCollateralException if there is an internal error
	@version 5.3.2
	*/
	virtual void SetCollateralAllotmentIndustry(int numLine, long val) = 0;

	/** Get Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCollateralAllotmentAutoTicketOffset(int numLine) const = 0;

	/** Set Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Offset (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCollateralAllotmentAutoTicketOffset(int numLine, long val) = 0;

	/** 
		Index/Basket list [Collateral Stocks]
	*/
	
	/** Get the number of lines in Index/Basket list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual long GetCollateralIndexBasketLinesNumber() const = 0;

	/** Get Referance code (sicovam) from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the Referance code or -1 if <star>, or 0 if <empty> (e.g. is not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetCollateralIndexBasket(int numLine) const = 0;
	
	/** Set the Referance value for Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new referance value by its <sicovam>, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such referance has not been found)
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasket(int numLine, const long val) = 0;

	/** Get the Sign value from Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetCollateralIndexBasketSign(int numLine) const = 0;
	
	/** Set the Sign value for Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
		(for example if val is < -1 && > 3)
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasketSign(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Haircut from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - haircut value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHaircutInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	// Obsolete - V 7.2
	//virtual double GetCollateralIndexBasketHaircutInProduct(int numLine, eHairCutType hairCutType) const = 0;

	// Obsolete - V 7.2
	//double GetCollateralIndexBasketHaircut(int numLine, eHairCutType hairCutType, double *valueInProduct=0) const;
	
	/** Set Haircut for Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new haircut value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHaircutInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasketHaircutInProduct(int numLine, const double val) = 0;

	// Obsolete - V 7.2
	//void SetCollateralIndexBasketHaircut(int numLine, const double val);

	/** Get Collateral from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - collateral value
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual double GetCollateralIndexBasketCollateral(int numLine) const = 0;
	
	/** Set Collateral for Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new collateral value
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasketCollateral(int numLine, const double val) = 0;

	/** Get Excluded from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - true if excluded, false otherwise
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual bool GetCollateralIndexBasketExcluded(int numLine) const = 0;

	/** Set Excluded for Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new excluded value (true if excluded, false otherwise)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasketExcluded(int numLine, bool val) = 0;

	/** Get Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetCollateralIndexBasketAutoTicketOffset(int numLine) const = 0;

	/** Set Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Offset (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetCollateralIndexBasketAutoTicketOffset(int numLine, long val) = 0;

	/** Check if the specified instrument is suitable to be used as Collateral.
		The instrument is suitable if it is listed in the Collateral parameters
		of the agreement, and the sign of the quantity matches.
		@param ident - id of the instrument to be checked
		@param quantity - quantity of securities to use for the margin call
		@return - true if the instrument is suitable, false otherwise
		see also - IsCurrencySuitableAsCollateral() {@link IsCurrencySuitableAsCollateral} + 
		GetListOfSuitableCollateralCurrencies() {@link GetListOfSuitableCollateralCurrencies}
		@param date Optional date used to calculate maturity (if relative), 0 means today. 
		@version 5.2.7
		*/
	bool IsInstrumentSuitableAsCollateral(long ident, double quantity = 0, long date = 0) const;

	/** Check if the specified instrument is suitable to be used as Principal
		The instrument is suitable if it is listed in the Principal parameters
		of the agreement, and the sign of the quantity matches.
		@param ident - id of the instrument to be checked
		@param quantity - quantity of securities to use for the margin call
		@return - true if the instrument is suitable, false otherwise
		see also - IsCurrencySuitableAsPrincipal() {@link IsCurrencySuitableAsPrincipal} + GetListOfSuitablePrincipalCurrencies() {@link GetListOfSuitablePrincipalCurrencies}
		@param date Optional date used to calculate maturity (if relative), 0 means today. 
		@version 5.2.7
	*/
	bool IsInstrumentSuitableAsPrincipal(long ident, double quantity = 0, TLib* ptr = 0, long date = 0) const;

 	/** Check if the specified currency is suitable to be used as Collateral.
		The currency is suitable if it is listed in the Collateral parameters
		of the agreement, and the sign of the quantity matches.
		@param ident - id of the currency to be checked
		@param quantity - quantity of cash to use for the margin call
		@return - true if the currency is suitable, false otherwise
		see also - IsInstrumentSuitableAsCollateral() {@link IsInstrumentSuitableAsCollateral}
		*/
	bool IsCurrencySuitableAsCollateral(long ident, double quantity = 0) const;
	
	/** Check if the specified currency is suitable to be used as Underlying principal
		The currency is suitable if it is listed in the principal parameters
		of the agreement, and the sign of the quantity matches.
		@param ident - id of the currency to be checked
		@param quantity - quantity of cash to use for the margin call
		@return - true if the currency is suitable, false otherwise
		see also - IsInstrumentSuitableAsPrincipal() {@link IsInstrumentSuitableAsPrincipal}
	*/
	bool IsCurrencySuitableAsPrincipal(long ident, double quantity = 0) const;

	/**
		Get information on what currencies are allowed as collateral for this LBA
		The map contains key as currency Id and value as whether it should be displayed or not
		The value star determines if all currencies should be displayed by default
		Use this in conjunction with the CSRCurrency method, CSRCurrency::CreateFilteredMenu
		@param suitableCurrencies - map of currencies vs whether they should be displayed
		@param star	- display all currencies by default.
		*/
    void GetListOfSuitableCollateralCurrencies(_STL::map<long, bool>& suitableCurrencies, bool& star) const;
	
	/**
		Get information on what currencies are allowed as underlying principal for this LBA
		The map contains key as currency Id and value as whether it should be displayed or not
		The value star determines if all currencies should be displayed by default
		Use this in conjunction with the CSRCurrency method, CSRCurrency::CreateFilteredMenu
		@param suitableCurrencies - map of currencies vs whether they should be displayed
		@param star	- display all currencies by default.
	*/
	void GetListOfSuitablePrincipalCurrencies(_STL::map<long, bool>& suitableCurrencies, bool& star) const;

	/** 
		Principal Stocks
	*/

#if 0
	/** Get the value for LoadFrom. This is the name of LB Agreement (by its name) to have been used to 
		fill values for GeneralRulesPerAllotment and Index/Basket lists, or <empty> if none have been
		selected.
		@param str - is the pointer to buffer allocated in the client space to put/copy the value.
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long)
	*/
	virtual void GetPrincipalStocksLoadFrom(char *str, int size) const = 0;
	
	/** Set the value for LoadFrom. This is the name of LB Agreement (by its name) has to be used to 
		fill values for GeneralRulesPerAllotment and Index/Basket lists, if <empty> - none has to be
		selected.
		@param str - pointer to the new value string
		@throw - CSRCollateralException if there is an internal error 
		(for example if the string provided is too long or if no LB Agreement have been found with such a name)
	*/
	virtual void SetPrincipalStocksLoadFrom(const char* val) = 0;
#endif

	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::AddPrincipalRulePerAllotment to 
		add a new Principal Allotment Rule		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void AddPrincipalRulePerAllotmentTK() { throw sophisTools::base::NotImplemented("AddPrincipalRulePerAllotment()"); };

	/**
		@version 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::AddPrincipalSpreadPerUnderlyingAllotment to 
		add a new Principal Underlying Allotment Rule		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void AddPrincipalSpreadPerUnderlyingAllotmentTK() { throw sophisTools::base::NotImplemented("AddPrincipalSpreadPerUnderlyingAllotment()"); };

	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::AddCollatRulePerAllotment to
		add a new Collateral Allotment Rule		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void AddCollatRulePerAllotmentTK()  { throw sophisTools::base::NotImplemented("AddCollatRulePerAllotment()"); };
			
	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::CSRAgreementDetails to add
		a new cash collateral remuneration to the Margin Call tab		
	*/
	virtual void AddCashCollateralRemunerationTK()  { throw sophisTools::base::NotImplemented("AddCashCollateralRemuneration()"); };		

	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::DeleteDefaultTemplate to delete 
		a template		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void DeleteDefaultTemplateTK(int numLine)  { throw sophisTools::base::NotImplemented("DeleteDefaultTemplate()"); };	
	
	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::DeleteCashCollateralRemuneration to
		delete a cash collateral remuneration to the Margin Call tab		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void DeleteCashCollateralRemunerationTK(int numLine)  { throw sophisTools::base::NotImplemented("DeleteCashCollateralRemuneration()"); };	

	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::DeleteCollatRulePerAllotment to
		delete a collateral allotment rule		
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void DeleteCollatRulePerAllotmentTK(int numLine)  { throw sophisTools::base::NotImplemented("DeleteCollatRulePerAllotment()"); };	

	/**
		@version 6.31 / 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::DeletePrincipalRulePerAllotment to 
		delete a principal allotment rule
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void DeletePrincipalRulePerAllotmentTK(int numLine)  { throw sophisTools::base::NotImplemented("DeletePrincipalRulePerAllotment()"); };	

	/**
		@version 7.11
		API use only, not to be called from the GUI
		Calls CSRAgreementDetails::DeleteSpreadPerUnderlyingAllotment to 
		delete a principal underlying allotment rule
		Throws NotImplemented exception if derived class anything but CSRAgreementDetails
	*/
	virtual void DeleteSpreadPerUnderlyingAllotmentTK(int numLine)  { throw sophisTools::base::NotImplemented("DeleteSpreadPerUnderlyingAllotment()"); };	
	
	/**
	 * @deprecated 5.3.6 Use GetReturnWithInitialValues() instead
	 * Returns value of Return With Initial Values flag.
	 * When set, Return With Initial Values flag indicates the spot of the partial return 
	 * should be same as of the initial ticket. The default value is false.
	 *
	 * @return false (default) or true if the Return With Initial Values flag is set.
	 *
	 * @version 5.2.5
	 */
	bool IsReturnWithInitialValues() const { return (GetReturnWithInitialValues() == eprWithInitialValues); }

	/**
	 * Returns value of Return With Initial Values setting.
	 * Return With Initial Values flag indicates the rules for collateral calculation for partial return.
	 * @return Setting applied to partial return.
	 *
	 * @version 5.3.6
	 */
	virtual ePartialReturn GetReturnWithInitialValues() const = 0;

	/**
	 * Sets the new value for the Return With Initial Values flag.
	 * When set, Return With Initial Values flag indicates the spot of the partial return 
	 * should be same as of the initial ticket. The default value is false.
	 *
	 * @param flag New value for the Return With Initial Values flag.
	 * 
	 * @version 5.2.5
	 */
	virtual void SetReturnWithInitialValues(ePartialReturn flag) = 0;

	/**
	 * Returns value of Swap Type setting.
	 * @return Setting applied to swap template type
	 *
	 * @version 7.1.3
	 */
	virtual eSwapType GetSwapType() const = 0;

	/**
	 * Sets the new value for the Swap Type flag.
	 * When set, Swap Type flag indicates the type of the swap template
	 * The default value is Portfolio Swap.
	 *
	 * @param flag New value for the Swap Type flag.
	 * 
	 * @version 7.1.3
	 */
	virtual void SetSwapType(eSwapType flag) = 0;

	/**
		General Rules Per Allotment list [Principal Stocks]
	*/

	/** Get the number of lines in Underlying Allotment list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	virtual long GetPrincipalAllotmentLinesNumber() const = 0;

	/** Get the Principal Allotment value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the underlying allotment by its ID or -1 if <star> or 0 if <emtpy> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotment(int numLine) const = 0;
	
	/** Set the Principal Allotment value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new underlying allotment value by its ID, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such allotment has not been found)
	*/
	virtual void SetPrincipalAllotment(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Index / Basket Ref value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the Referance code or -1 if <star>, or 0 if <empty> (e.g. is not set)
		@throw - CSRCollateralException if there is an internal error
	*/	
	virtual long GetPrincipalAllotmentBasketRef(int numLine) const = 0;
	
	/** Set the Index / Basket Ref value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new referance value by its <sicovam>, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such referance has not been found)
	*/	
	virtual void SetPrincipalAllotmentBasketRef(int numLine, const long val) = 0;

	/** Get the Currency value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the currency CODE OR 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotmentCcy(int numLine) const = 0;
	
	/** Set the Currency value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new currency CODE 
		OR 0 if has to set to <empty> (e.g. no value) OR -1 if has to be set to <star>
		@throw - CSRCollateralException if there is an internal error
		(e.g. if currency CODE is invaled)
	*/
	virtual void SetPrincipalAllotmentCcy(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get the Sign value from GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotmentSign(int numLine) const = 0;
	
	/** Set the Sign value for GeneralRulesPerAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
		(for example if val is < -1 && > 3)
	*/
	virtual void SetPrincipalAllotmentSign(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Hedging from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - hedging value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHedgingInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	virtual double GetPrincipalAllotmentHedgingInProduct(int numLine) const = 0;

	double GetPrincipalAllotmentHedging(int numLine, double *valueInProduct=0) const;
	
	/** Set Hedging for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new hedging value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHedgingInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	virtual void SetPrincipalAllotmentHedgingInProduct(int numLine, const double val) = 0;

	void SetPrincipalAllotmentHedging(int numLine, const double val);

	/** Get Condition1 from PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalAllotmentCondition1(int numLine) const = 0;

	/** Get Condition2 from PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalAllotmentCondition2(int numLine) const = 0;

	/** Get Condition3 from PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalAllotmentCondition3(int numLine) const = 0;

	/** Set Condition1 for PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalAllotmentCondition1(int numLine, _STL::string& condition) = 0;

	/** Set Condition2 for PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalAllotmentCondition2(int numLine, _STL::string& condition) = 0;

	/** Set Condition3 for PrincipalRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalAllotmentCondition3(int numLine, _STL::string& condition) = 0;	

	/** Get Excluded from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - true if excluded, false otherwise
		@throw - CSRCollateralException if there is an internal error
	*/	
	virtual bool GetPrincipalAllotmentExcluded(int numLine) const = 0;

	/** Set Excluded for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new excluded value (true if excluded, false otherwise)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentExcluded(int numLine, bool val) = 0;

	/** Get US counterparty payment offset from GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - US cpty payment offset value for this instrument
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotmentUSCptyPaymentOffset(int numLine) const = 0;
	
	/** Set US counterparty payment offset for GeneralRulesPerAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - value which to set as new US counterparty payment date offset
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentUSCptyPaymentOffset(int numLine, const long val) = 0;

	/** Get Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotmentMarket(int numLine) const = 0;

	/** Set Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value (see CSRMarket::fMarketCode) or 0 for <empty/reset> or -1 for <*>
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentMarket(int numLine, long val) = 0;

	/** Get Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetPrincipalAllotmentMaturity(int numLine) const = 0;

	/** Set Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetPrincipalAllotmentMaturity(int numLine, long val) = 0;

	/** Get Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetPrincipalAllotmentRating(int numLine) const = 0;

	/** Set Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty/reset
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetPrincipalAllotmentRating(int numLine, long val) = 0;

	/** Get Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalAllotmentAutoTicketOffset(int numLine) const = 0;

	/** Set Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Offset (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentAutoTicketOffset(int numLine, long val) = 0;

	/** Get CFD short associated with the line, e.g. renumeration rate for a short CFD (on the funding costs
		expected to be paid by the client)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetPrincipalAllotmentCFDShort(const int &numLine) const = 0;

	/** Get CFD long associated with the line, e.g. renumeration rate for a long CFD(on the collateral expected
		to be paid by the counterparty)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetPrincipalAllotmentCFDLong(const int &numLine) const = 0;

	/** Set CFD short associated with the line, e.g. renumeration rate for a short CFD (on the funding costs
		expected to be paid by the client)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for CFD Short (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentCFDShort(const int &numLine, const double &val) = 0;

	/** Set CFD long associated with the line, e.g. renumeration rate for a long CFD(on the collateral expected
		to be paid by the counterparty)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for CFD Long (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalAllotmentCFDLong(const int &numLine, const double &val) = 0;

	/** Get the initial margin accrued factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @throw - CSRCollateralException if there is an internal error
	 */
	virtual double GetPrincipalIMFactorAccrued(const int &numLine) const = 0;

	/** Set the initial margin accrued factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @param val - new value
	 * @throw - CSRCollateralException if there is an internal error
	 */
	virtual void SetPrincipalIMFactorAccrued(const int &numLine, const double &val) = 0;

	/** Get the initial margin parity factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @throw - CSRCollateralException if there is an internal error
	 */
	virtual double GetPrincipalIMFactorParity(const int &numLine) const = 0;

	/** Set the initial margin parity factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @param val - new value
	 * @throw - CSRCollateralException if there is an internal error
	 */
	virtual void SetPrincipalIMFactorParity(const int &numLine, const double &val) = 0;
	

	/**
		General Rules Per Underlying Allotment list [Principal Stocks]
	*/

	/** Get the number of lines in Underlying Allotment list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	virtual long GetPrincipalUnderlyingAllotmentLinesNumber() const = 0;

	/** Get the Principal Underlying Allotment value from SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the underlying allotment by its ID or -1 if <star> or 0 if <emtpy> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalUnderlyingAllotment(int numLine) const = 0;
	
	/** Set the Principal Underlying Allotment value for SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new underlying allotment value by its ID, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such allotment has not been found)
	*/
	virtual void SetPrincipalUnderlyingAllotment(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Index / Basket Ref value from SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the Referance code or -1 if <star>, or 0 if <empty> (e.g. is not set)
		@throw - CSRCollateralException if there is an internal error
	*/	
	virtual long GetPrincipalUnderlyingAllotmentBasketRef(int numLine) const = 0;
	
	/** Set the Index / Basket Ref value for SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new referance value by its <sicovam>, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such referance has not been found)
	*/	
	virtual void SetPrincipalUnderlyingAllotmentBasketRef(int numLine, const long val) = 0;

	/** Get the Currency value from SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the currency CODE OR 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalUnderlyingAllotmentCcy(int numLine) const = 0;
	
	/** Set the Currency value for SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new currency CODE 
		OR 0 if has to set to <empty> (e.g. no value) OR -1 if has to be set to <star>
		@throw - CSRCollateralException if there is an internal error
		(e.g. if currency CODE is invaled)
	*/
	virtual void SetPrincipalUnderlyingAllotmentCcy(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get the Sign value from SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalUnderlyingAllotmentSign(int numLine) const = 0;
	
	/** Set the Sign value for SpreadRulesPerUnderlyingAllotment list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
		(for example if val is < -1 && > 3)
	*/
	virtual void SetPrincipalUnderlyingAllotmentSign(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Condition1 from SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition1(int numLine) const = 0;

	/** Get Condition2 from SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition2(int numLine) const = 0;

	/** Get Condition3 from SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition3(int numLine) const = 0;

	/** Set Condition1 for SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalUnderlyingAllotmentCondition1(int numLine, _STL::string& condition) = 0;

	/** Set Condition2 for SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalUnderlyingAllotmentCondition2(int numLine, _STL::string& condition) = 0;

	/** Set Condition3 for SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).		
		@param condition - the condition
		@throw - CSRCollateralException if there is an internal error		
	*/
	virtual void SetPrincipalUnderlyingAllotmentCondition3(int numLine, _STL::string& condition) = 0;	

	/** Get Excluded from SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - true if excluded, false otherwise
		@throw - CSRCollateralException if there is an internal error
	*/	
	virtual bool GetPrincipalUnderlyingAllotmentExcluded(int numLine) const = 0;

	/** Set Excluded for SpreadRulesPerUnderlyingAllotment list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new excluded value (true if excluded, false otherwise)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalUnderlyingAllotmentExcluded(int numLine, bool val) = 0;

	/** Get Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetPrincipalUnderlyingAllotmentMarket(int numLine) const = 0;

	/** Set Market associated with the line.
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value (see CSRMarket::fMarketCode) or 0 for <empty/reset> or -1 for <*>
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalUnderlyingAllotmentMarket(int numLine, long val) = 0;

	/** Get Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetPrincipalUnderlyingAllotmentMaturity(int numLine) const = 0;

	/** Set Maturity associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetPrincipalUnderlyingAllotmentMaturity(int numLine, long val) = 0;

	/** Get Begin Date associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual long GetPrincipalUnderlyingAllotmentBeginDate(int numLine) const = 0;

	/** Set Begin Date associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual void SetPrincipalUnderlyingAllotmentBeginDate(int numLine, long val) = 0;

	/** Get Wrapper Swap Sicovam associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual long GetPrincipalUnderlyingAllotmentWrapper(int numLine) const = 0;

	/** Set Wrapper Swap Sicovam associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual void SetPrincipalUnderlyingAllotmentWrapper(int numLine, long val) = 0;

	/** Get Template Swap Sicovam associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual long GetPrincipalUnderlyingAllotmentTemplate(int numLine) const = 0;

	/** Set Template Swap Sicovam associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty
	@throw - CSRCollateralException if there is an internal error
	@version 7.1.3
	*/
	virtual void SetPrincipalUnderlyingAllotmentTemplate(int numLine, long val) = 0;

	/** Get Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetPrincipalUnderlyingAllotmentRating(int numLine) const = 0;

	/** Set Rating associated with the line.
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value or 0 for empty/reset
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetPrincipalUnderlyingAllotmentRating(int numLine, long val) = 0;


	/** Get Spread short associated with the line, e.g. renumeration rate for a short Spread (on the funding costs
		expected to be paid by the client)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetPrincipalUnderlyingAllotmentSpreadShort(const int &numLine) const = 0;

	/** Get Spread long associated with the line, e.g. renumeration rate for a long Spread(on the collateral expected
		to be paid by the counterparty)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetPrincipalUnderlyingAllotmentSpreadLong(const int &numLine) const = 0;

	/** Set Spread short associated with the line, e.g. renumeration rate for a short Spread (on the funding costs
		expected to be paid by the client)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Spread Short (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalUnderlyingAllotmentSpreadShort(const int &numLine, const double &val) = 0;

	/** Set Spread long associated with the line, e.g. renumeration rate for a long Spread(on the collateral expected
		to be paid by the counterparty)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Spread Long (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetPrincipalUnderlyingAllotmentSpreadLong(const int &numLine, const double &val) = 0;

	/**
	  * Returns the Underlying short spread that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>0.0</code> is returned. 	  
	  * @return Underlying short spread value specified in the agreement or <code>0.0</code> as the default.
	  * @version 7.2
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  */
	double GetPrincipalUnderlyingShortSpreadInProduct(long instrIdent, double quantity, long date =0) const;
	
	/**
	  * Returns the Underlying long spread that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>0.0</code> is returned. 	  
	  * @return Underlying long spread value specified in the agreement or <code>0.0</code> as the default.
	  * @version 7.2
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  */
	double GetPrincipalUnderlyingLongSpreadInProduct(long instrIdent, double quantity, long date =0) const;

	/**
	* Gets the Underlying long and short spreads that match given instrument and quantity. If no matching rule is 
	* found, the default of <code>0.0</code> is for each of the spreads. 
	* @version 7.2
	* @param date - required date to calculate maturity (if relative), 0 means today. 
	*/
	void GetPrincipalUnderlyingSpreadsInProduct(long instrIdent, double quantity, double& longSpread, double& shortSpread, long date) const;

	/** 
		Index/Basket list [Principal Stocks]
	*/

	/** Get the number of lines in Principal Index/Basket list.
		@return - the number of lines
		@throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual long GetPrincipalIndexBasketLinesNumber() const = 0;

	/** Get Referance code (sicovam) from Principal Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - the Referance code or -1 if <star>, or 0 if <empty> (e.g. is not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetPrincipalIndexBasket(int numLine) const = 0;
	
	/** Set the Referance value for Principal Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - the new referance value by its <sicovam>, or -1 for <star>, or 0 for <empty>
		@throw - CSRCollateralException if there is an internal error
		(for example if no such referance has not been found)
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasket(int numLine, const long val) = 0;

	/** Get the Sign value from Principal Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetPrincipalIndexBasketSign(int numLine) const = 0;
	
	/** Set the Sign value for Principal Index/Basket list.
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - 1 for '+', 2 for '0', 3 for '-', -1 for '*', 0 if <empty> (e.g. not set)
		@throw - CSRCollateralException if there is an internal error
		(for example if val is < -1 && > 3)
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketSign(int numLine, const long val) = 0;	// -1 is <star>, 0 is <reset>

	/** Get Hedging from Principal Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - hedging value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHedgingInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	// Obsolete - V 7.2
	//virtual double GetPrincipalIndexBasketHedgingInProduct(int numLine) const = 0;

	// Obsolete - V 7.2
	//double GetPrincipalIndexBasketHedging(int numLine, double *valueInProduct=0) const;

	/** Set Hedging for Principal Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new heding value
		@throw - CSRCollateralException if there is an internal error
	*/
	/** Get/SetHedgingInProduct methods have to be used instead of previous Get/SetHedgin methods version (before 5.2.6).
		New version of Get/SetHedging now takes into account INVERSE_HAIR_CUT preference, 
		which results to invertions (1/x) of resulting value if such preference is set.
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketHedgingInProduct(int numLine, const double val) = 0;

	// Obsolete - V 7.2
	//void SetPrincipalIndexBasketHedging(int numLine, const double val);

	/** Get Excluded from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - true if excluded, false otherwise
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual bool GetPrincipalIndexBasketExcluded(int numLine) const = 0;

	/** Set Excluded for Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param - new excluded value (true if excluded, false otherwise)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketExcluded(int numLine, bool val) = 0;

	/** Get US counterparty payment offset from Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@return - US cpty payment offset value for this instrument
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetPrincipalIndexBasketUSCptyPaymentOffset(int numLine) const = 0;

	/** Set US counterparty payment offset for Index/Basket list
		@param numLine - is the number of line from list to deal with (starts with 0).
		@param val - value which to set as new US counterparty payment date offset
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketUSCptyPaymentOffset(int numLine, const long val) = 0;

	/** Get Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual long GetPrincipalIndexBasketAutoTicketOffset(int numLine) const = 0;

	/** Set Offset associated with the line, e.g. number of days before an expire to generate AutoTickets
		(Commissions, Interest, Expire)
		@param numLine - is the number of line from list (starts with 0)
		@param val - new value for Offset (any integer value, including 0)
		@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketAutoTicketOffset(int numLine, long val) = 0;

	/** Get CFD short associated with the line, e.g. renumeration rate for a short CFD (on the funding costs
	expected to be paid by the client)
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual double GetPrincipalIndexBasketCFDShort(const int &numLine) const = 0;

	/** Get CFD long associated with the line, e.g. renumeration rate for a long CFD(on the collateral expected
	to be paid by the counterparty)
	@param numLine - is the number of line from list (starts with 0)
	@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual double GetPrincipalIndexBasketCFDLong(const int &numLine) const = 0;

	/** Set CFD short associated with the line, e.g. renumeration rate for a short CFD (on the funding costs
	expected to be paid by the client)
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value for CFD Short (any integer value, including 0)
	@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketCFDShort(const int &numLine, const double &val) = 0;

	/** Set CFD long associated with the line, e.g. renumeration rate for a long CFD(on the collateral expected
	to be paid by the counterparty)
	@param numLine - is the number of line from list (starts with 0)
	@param val - new value for CFD Long (any integer value, including 0)
	@throw - CSRCollateralException if there is an internal error
	*/
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketCFDLong(const int &numLine, const double &val) = 0;

	/** Get the initial margin accrued factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual double GetPrincipalIndexBasketIMFactorAccrued(const int &numLine) const = 0;

	/** Set the initial margin accrued factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @param val - new value
	 * @throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketIMFactorAccrued(const int &numLine, const double &val) = 0;

	/** Get the initial margin parity factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual double GetPrincipalIndexBasketIMFactorParity(const int &numLine) const = 0;

	/** Set the initial margin parity factor for CFD on bonds
	 * @param numline - is the number of line from list (starts with 0)
	 * @param val - new value
	 * @throw - CSRCollateralException if there is an internal error
	 */
	// Obsolete - V 7.2
	//virtual void SetPrincipalIndexBasketIMFactorParity(const int &numLine, const double &val) = 0;

	/** 
		Fees Billing
	*/

	/** Get Fee Mark Frequency. */
	virtual _STL::string GetFeeMarkFrequency() const = 0;

	/** Set new Fee Mark Frequency
		@param str - pointer to the new value string OR to the empty string if has to be set to <empty>
	*/
	virtual void SetFeeMarkFrequency(const _STL::string& str) = 0;

	/**
	 * Returns agreement specific Fee Mark Negotiation type to use.
	 * @version 5.3.6.21
	 * @version 6.3.2
	 */
	virtual eIMNegotiationType GetFeeMarkNegotiationType() const = 0;
	
	/**
	 * Returns agreement specific Fee Mark Currency type to use.
	 * @version 7.1.3
	 */
	virtual eFeeMarkCurrency GetFeeMarkCurrency() const = 0;

	/**
	 * Sets agreement specific Fee Mark Negotiation type to use.
	 * @param val New pref value
	 * @version 5.3.6.21
	 * @version 6.3.2
	 */
	virtual void SetFeeMarkNegotiationType(long val) = 0;
	
	/**
	 * Sets agreement specific Fee Mark Currency type to use.
	 * @param val New pref value
	 * @version 7.1.3
	 */
	virtual void SetFeeMarkCurrency(eFeeMarkCurrency val) = 0;

	/** Get Default Fees Billing Spot type
		@return Spot type, like typeOPEN, typeLAST, etc -- see RTEvents.h;
		-1 if no value is set (<empty>).
		see CSRInstrument::GetFixing() {@link CSRInstrument::GetFixing}
		@throw - CSRCollateralException if there is an internal error 
	*/
	virtual int GetDefaultSpotForFeesBilling() const = 0;

#if 0
	/**
	 * @deprecated Use GetDefaultSpotForFeesBilling().
	 * @version 5.1
	 */
	inline virtual long GetDefaultSpot() const
		throw (CSRCollateralException)
	{
		return (long)GetDefaultSpotForFeesBilling();
	}
#endif
	
	/** Set value for Default Fees Billing Spot type
		@param val - the new value, -1 if no value has to be set (<empty>)
		@throw - CSRCollateralException if there is an internal error 
	*/
	virtual void SetDefaultSpotForFeesBilling(const int val) = 0;

#if 0
	/**
	 * @deprecated Use SetDefaultSpotForFeesBilling().
	 * @version 5.1
	 */
	inline virtual void SetDefaultSpot(const long val)
		throw (CSRCollateralException)
	{
		return SetDefaultSpotForFeesBilling((int)val);
	}
#endif

	/** Get Default Fees Billing Spot timing
	@return - 1 for "Yesterday", 2 for "Today", 
	0 if no value is set (<empty>)
	@throw - CSRCollateralException if there is an internal error 
	*/
	virtual long GetDefaultSpotTimingForFeesBilling() const = 0;

#if 0
	/**
	 * @deprecated Use GetDefaultSpotTimingForFeesBilling().
	 * @version 5.1
	 */
	inline virtual long GetDefaultSpotTiming() const
		throw (CSRCollateralException)
	{
		return GetDefaultSpotTimingForFeesBilling();
	}
#endif

	/** Set value for Default Fees Billing Spot timing
	@param val - the new value, one of the following: 
	1 for "Yesterday", 2 for "Today", 0 if no value has to be set (<empty>)
	@throw - CSRCollateralException if there is an internal error 
	(for example if val < 0 && > 2)
	*/
	virtual void SetDefaultSpotTimingForFeesBilling(const long val) = 0;

#if 0
	/**
	 * @deprecated Use SetDefaultSpotTimingForFeesBilling().
	 * @version 5.1
	 */
	inline virtual void SetDefaultSpotTiming(const long val)
		throw (CSRCollateralException)
	{
		return SetDefaultSpotTimingForFeesBilling(val);
	}

	/** @deprecated 5.2.4 Use GetCommissionPaymentOffset().
	*/
	virtual long GetPaymentOffset() const = 0;
	
	/** @deprecated 5.2.4 Use SetCommissionPaymentOffset().
	*/
	virtual void SetPaymentOffset(const long val) = 0;
#endif

	/** Get Commission Payment Offset value
	@return - the offset value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCommissionPaymentOffset() const = 0;

	/** Set new Commission Payment Offset value
	@param val - the new value for offset
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCommissionPaymentOffset(const long val) = 0;

	/**
	 * Returns last spot of the given instrument to be used inside risk calculations,
	 * as defined in the &quot;Spot Schedule&quot; of the Credit Risk tab.
	 * The value is returned in the currency of the instrument.
	 * If the instrument is invalid, <code>0.0</code> is returned.
	 * If no specific record exists for the instrument, either <code>0.0</code> or
	 * last market value is returned, depending on the <code>useMarketValueByDefault</code> preference.
	 * @version 5.1
	 * @param date Optional reporting date. If zero than use gDateFinBase(). 
	 * @param spotDate Optional parameter spotDate returns the spot date. 
	 * @version 5.2.7 
	 */
	virtual double GetLastCreditRiskSpot(long sicovam, bool useMarketValueByDefault = true, long date = 0, long * spotDate = 0) const;

	/**
	 * Returns the last accrued value for the given instrument to be used in calculations or margin calls.
	 * The accrued is retrieved according to the &quot;Default Spot&quot; settings 
	 * specified in Credit Risk tab of the Agreement.
	 * The value is returned in the currency of the instrument.
	 * If the instrument has no accrued, , <code>0.0</code> is returned.
	 * @param sicovam Instrument id.
	 * @param date Optional calculation date.
	 * @version 5.2.2
	 */
	double GetLastAccruedCoupon(long sicovam, long date=0) const;

#if 0
	/**
	* @deprecated 5.2.4 Use either GetCommissionMarketShiftStockLoan() or GetCouponMarketShiftStockLoan().
	*/
	virtual eMarketShiftOnStockLoan GetLBAMarketShiftStockLoan() const;
#endif

	/**
	* Firstly checks the accrual calculation as defined in fees billing tab.
	* If default or nothing set then we use the global preference MarketShiftOnStockLoan which governs the 
	* way to calculate the commission accrual. (uses a cached value for speed)
	* FELI (First exclude, Last include)
	* FILE (First in Last exclude) (corresponds to MarketShiftOnStockLoan = 1)
	* 
	* @version 5.2.4
	*/
	eMarketShiftOnStockLoan GetCommissionMarketShiftStockLoan() const;

	/**
	* Returns the Accrual Calculation method as defined in the Fees Billing Tab of the LBA. 
	
	***NOTE : Use GetCommissionMarketShiftStockLoan() Method unless you just want the value from the UI***

	* If default or nothing set then we use the global preference MarketShiftOnStockLoan which governs the 
	* way to calculate the commission accrual.
	* Not Set = 0
	* Default = 1
	* FELI (First exclude, Last include) = 2
	* FILE (First in Last exclude) = 3
	* ...
	*/
	virtual long GetCommissionAccrualCalculationMethod() const = 0;

#if 0
	/**
	* @deprecated 5.2.4 Use GetCommissionAccrualCalculationMethod()
	*/
	virtual long GetAccrualCalculationMethod() const = 0;
#endif

	/**
	* Sets the AccrualCalculationMethod
	* Default = 1
	* FELI = 2
	* FILE = 3
	*/
	virtual void SetCommissionAccrualCalculationMethod(const long val) = 0;

#if 0
	/**
	* @deprecated 5.2.4 Use SetCommissionAccrualCalculationMethod()
	*/
	virtual void SetAccrualCalculationMethod(const long val) = 0;
#endif

	/** Get Commission Day After Offset value
	@return - the offset value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCommissionDayAfterOffset() const = 0;

	/** Set Commission Day After Offset value
	@param val - the new value for offset
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCommissionDayAfterOffset(const long val) = 0;

	/** Get Coupon Payment Offset value
	@return - the offset value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCouponPaymentOffset() const = 0;

	/** Set new Coupon Payment Offset value
	@param val - the new value for offset
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCouponPaymentOffset(const long val) = 0;

	/**
	* Firstly checks the accrual calculation as defined in margin call tab.
	* If default or nothing set then we use the commission accrual settings from the fees billing tab,
	* see GetCommissionMarketShiftStockLoan() for more info.
	*
	* FELI (First exclude, Last include)
	* FILE (First in Last exclude) (corresponds to MarketShiftOnStockLoan = 1)
	* 
	* @version 5.2.4
	*/
	eMarketShiftOnStockLoan GetCouponMarketShiftStockLoan() const;

	/** Get the cash pool acrrual method.
	It may be different of {@link GetCouponMarketShiftStockLoan} if ForceCashPoolAccrualMethod preference is set.
	@version 5.2.4.1
	*/
	eMarketShiftOnStockLoan GetCashPoolMarketShiftStockLoan(long interest_id) const;

	/**
	* Returns the Coupon Accrual Calculation method as defined in the Margin Call Tab of the LBA. 
	*
	** NOTE : Use GetCouponMarketShiftStockLoan() Method unless you just want the value from the UI***
	*
	* Not Set = 0
	* Default = 1
	* FELI (First exclude, Last include) = 2
	* FILE (First in Last exclude) = 3
	* ...
	*/
	virtual long GetCouponAccrualCalculationMethod() const = 0;
	/**
	* Sets the Coupon Accrual Calculation method.
	* Default = 1
	* FELI = 2
	* FILE = 3
	* ...
	*/
	virtual void SetCouponAccrualCalculationMethod(const long val) = 0;

	/** Get Coupon Day After Offset value
	@return - the offset value
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCouponDayAfterOffset() const = 0;

	/** Set Coupon Day After Offset value
	@param val - the new value for offset
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCouponDayAfterOffset(const long val) = 0;

	/** Get collateral call notice template value
	@return - the collateral call notice template id.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetCollateralCallTemplate() const = 0;

	/** Set collateral call notice template value
	@param val - the new value for collateral call notice template id.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetCollateralCallTemplate(const long val) = 0;

	/** Get collateral call notice currency value
	@return - the collateral call notice currency.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetCollateralCallCcy() const = 0;

	/** Set collateral call notice currency value
	@param val - the new value for collateral call notice currency.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetCollateralCallCcy(const long val) = 0;

	/** Get collateral substitution notice template value
	@return - the collateral substitution call notice template id.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetCollateralSubstitutionTemplate() const = 0;

	/** Set collateral substitution call notice template value
	@param val - the new value for collateral substitution call notice template id.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetCollateralSubstitutionTemplate(const long val) = 0;

	/** Get substituion notice period value
	@return - the substitution notice period value.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual long GetMakeSubstitutionNoticePeriod() const = 0;

	/** Set substituion notice period value
	@param val - the new value for the substitution period.
	@throw - CSRCollateralException if there is an internal error
	@version 5.2.7
	*/
	virtual void SetMakeSubstitutionNoticePeriod(const long period) = 0;

	/**Get Commission Amount type 
	*@return - could be 0 (not specified) 1 (normal) or 2 (collateralized)
	*@version 5.2.7
	*/
	virtual long GetCommissionAmountType() const = 0;

	/** Set Commission Amount type
	*@param val - could be 0 (not specified) 1 (normal) or 2 (collateralized)
	*@version 5.2.7
	*/
	virtual void SetCommissionAmountType(const long type) = 0;

	/**Get  Fees Partial return 
	*@return - could be 0 (not specified), 1 (none), 2 (in percent), or 3 (total amount)
	*@version 5.2.7
	*/
	virtual long GetFeesPartialReturn() const = 0;

	/** Set Fees Partial return 
	*@param type - could be 0 (not specified), 1 (none), 2 (in percent), or 3 (total amount)
	*@version 5.2.7
	*/
	virtual void SetFeesPartialReturn(const long type) = 0;

	/** Get Fees Repricing
	 * @return - 0 (not specified), 1 (none), 2 (delta cash only), or 3 (total + delta cash)
	 * @version 5.2.7
	 */
	virtual long GetFeesRepricing() const = 0;

	/** Set Fees Repricing
	 * @return - 0 (not specified), 1 (none), 2 (delta cash only), or 3 (total + delta cash)
	 * @version 5.2.7
	 */
	virtual void SetFeesRepricing(const long type) = 0;

	/** Get to which level (if any) the lending and borrowing (commission) fees rounding should apply.
	 * @version 7.1.1 */
	virtual eFeesRoundingLevel GetCommissionRoundingLevel(long ccy) const = 0;

	/** Get rounded value for lending and borrowing (commission) fees.
	 * @param roundingType Optional, store the type of rounding applied.
	 * @param roundingValue Optional, store the value of rounding applied.
	 * @version 7.1.1 */
	virtual double GetCommissionRoundedValue(long ccy, double val, short* roundingType = 0, double* roundingValue = 0) const = 0;

	/** Get to which level (if any) the collateral remuneration rounding should apply.
	 * @version 7.1.1 */
	virtual eFeesRoundingLevel GetCouponRoundingLevel(long ccy) const = 0;

	/** Get rounded value for collateral remuneration.
	 * @param roundingType Optional, store the type of rounding applied.
	 * @param roundingValue Optional, store the value of rounding applied.
	 * @version 7.1.1 */
	virtual double GetCouponRoundedValue(long ccy, double val, short* roundingType = 0, double* roundingValue = 0) const = 0;

	/**Get CFD Report 
	*@return - reporting type
	*@version 5.3.4
	*/
	virtual long GetCFDReportingType() const = 0;
	/**Set CFD Report 
	*@param val - reporting type
	*@version 5.3.4
	*/
	virtual void SetCFDReportingType(const long &val) = 0;

	/**Get CFD Buy/Sell Side value - describes whether we are buy or sell side
	*@return - buy/sell side
	*@version 5.3.4
	*/
	virtual long GetCFDBuySellSide() const  = 0;
	/**Set CFD Buy/Sell Side value - describes whether we are buy or sell side
	*@param val - buy/sell side - 1: buy, 2: sell
	*@version 5.3.4
	*/
	virtual void SetCFDBuySellSide(const long &val) = 0;

	/**Get CFD Dividend Date value - describes whether to use payment date or record date
	*@return - 0 (record date)
	*@return - 1 (payment date)
	*@version 6.2
	*/
	virtual long GetCFDDividendDateType() const = 0;

	/**Set CFD Dividend Date value - describes whether use payment date or record date
	*@param val - 0: record date, 1: payment date
	*@version 5.3.4
	*/
	virtual void SetCFDDividendDateType(const long &val) = 0;

	/**Get Country Id value for CFD
	*@param line - line in coutry,dividend rebate window in which country is obtained
	*@return - Country Id or -1 for '*' 
	*@version 5.3.4
	*/
	virtual long GetCFDDividendRebateCountryId(const int line) const  = 0;
	/**Set Country Id value for CFD
	*@param val - country Id to set as, or -1 for '*'
	*@param line - line in coutry,dividend rebate window in which country is to be set
	*@version 5.3.4
	*/
	virtual void SetCFDDividendRebateCountryId(const int numLine, const long val) = 0;

	/**Get short dividend rebate value for CFD (i.e. percentage of dividend paid to the client by the lender)
	*@return - percentage short dividend rebate
	*@param line - line in coutry,dividend rebate window in which short dividend rebate is obtained
	*@version 5.3.4
	*/
	virtual double GetCFDDividendRebateShort(const int line) const = 0;
	/**Set short dividend rebate value for CFD (i.e. percentage of dividend paid to the client by the lender)
	*@param val - obtained percentage short dividend rebate value
	*@param line - line in coutry,dividend rebate window in which short dividend rabate is obtained
	*@version 5.3.4
	*/
	virtual void SetCFDDividendRebateShort(const int numLine, const double val) = 0;

	/**Get long dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	*@return - percentage long dividend rebate
	*@param line - line in coutry,dividend rebate window in which long dividend rebate is obtained
	*@version 5.3.4
	*/
	virtual double GetCFDDividendRebateLong(const int line) const  = 0;
	/**Set long dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	*@param val - obtained percentage long dividend rebate value
	*@param line - line in coutry,dividend rebate window in which long dividend rabate is obtained
	*@version 5.3.4
	*/
	virtual void SetCFDDividendRebateLong(const int numLine, const double val)  = 0;

	// returns number of lines in the country,dividend rebate window
	virtual long GetCFDCountryAndDividentRebateNumber() const = 0;

	/**Get long dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	* It does not take the * line in consideration. See 
	*@return - percentage long dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateLongForSectorCodeNoStar(const long code) const;

	/**Get long dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)

	*@return - percentage long dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateLongForSectorCode(const long code) const;

	/**Get short dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	* It does not take the * line in consideration. See 
	*@return - percentage short dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector code Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateShortForSectorCodeNoStar(const long code) const;

	/**Get short dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)

	*@return - percentage short dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector code Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateShortForSectorCode(const long code) const;


	/**Get short dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)

	*@return - percentage dividend rebate (100% if no line matching any of the codes)
	*@param codes - the country/sector codes Id which will be used to select the line to return the value
	 @param isLong - indicates whether the position is short or long
	*@version 7.1.3
	*/
	double GetCFDDividendRebate(const std::set<long>& codes, bool isLong) const;


	/**Get long dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	* This function returns the value from the * line
	*@return - percentage long dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateLongForStarLine() const;

	/**Get short dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	* This function returns the value from the * line
	*@return - percentage short dividend rebate (-1 if no line matching the code)
	*@param code - the country/sector code Id which will be used to select the line to return the value
	*@version 5.3.4
	*/
	double GetCFDDividendRebateShortForStarLine() const;

	/** Get dividend rebate value for CFD (i.e. percentage of dividend paid by the client to the counterparty)
	*@return - percentage short dividend rebate (-1 if no line matching the code)
	*@param code - CFD underlying sicovam
	*@param isCfdShort - flag to indicate if CFD is short
	*@version 5.3.4
	*/
	double GetCFDDividendRebateFromUnderlying(long code, bool isCfdShort) const;
	
	/**
	 * Returns Free Cash Folio Id defined with the Agreement.
	 * The Free Cash Folio is used to store the tickets generated when
	 * transfering cash to/from the Free Cash Pool
	 * @return Free Cash Folio Id if defined at the Agreement level.
	 */
	virtual long GetCFDFreeCashFolio() const = 0;

	/**
	 * Sets Free Cash Folio Id defined with the Agreement.
	 * The Free Cash Folio is used to store the tickets generated when
	 * transfering cash to/from the Free Cash Pool
	 * @param folioId the Free Cash Folio Id.
	 */	
	virtual void SetCFDFreeCashFolio(long folioId) = 0;

	/** Get the Free Cash Frequency. */
	virtual _STL::string GetCFDFreeCashFrequency() const = 0;
	
	/** Set the Free Cash Frequency
		@param str - pointer to the new value string OR to the empty string to set to <empty>
	*/
	virtual void SetCFDFreeCashFrequency(const _STL::string& str) = 0;


	/**Gets the Free Cash Pool floating rate long spread
		Returns the Free Cash Pool floating rate spread value defined in the CFD tab
		@return - Free Cash Pool floating rate spread
	*/
	virtual double GetCFDFreeCashFloatRateSpreadLong() const = 0;

	/**Set the Free Cash Pool floating rate long spread
	 * @param spread - the Free Cash pool floating rate spread.
	 */
	virtual void SetCFDFreeCashFloatRateSpreadLong(double spread) = 0;

	/**Gets the Free Cash Pool floating rate short spread
		Returns the Free Cash Pool floating rate spread value defined in the CFD tab
		@return - Free Cash Pool floating rate spread
	*/
	virtual double GetCFDFreeCashFloatRateSpreadShort() const = 0;

	/**Set the Free Cash Pool floating rate short spread
	 * @param spread - the Free Cash pool floating rate spread.
	 */
	virtual void SetCFDFreeCashFloatRateSpreadShort(double spread) = 0;

	/**Gets the Free Cash Exposure threshold
		Returns the Free Cash Exposure threshold value defined in the CFD tab
		@return - Free Cash Exposure threshold
	*/
	virtual double GetCFDFreeCashExpThreshold() const = 0;

	/**Set the Free Cash Exposure threshold
     * @param exp - The Free Cash Exposure threshold 
	 */
	virtual void SetCFDFreeCashExpThreshold(double exp) = 0;

	/** Returns the Free Cash Pool interest type
	 * It can either be fixed or floating.
	 */
	virtual eCFDFreeCashRate GetCFDFreeCashRateType() const = 0;

	/** Sets the Free Cash Rate Type
	 * @param type - The free cash rate type
	 */
	virtual void SetCFDFreeCashRateType(eCFDFreeCashRate type) = 0;

	/** Gets the Free Cash fixed interest rate. Either fixed or floating interest rates 
	 *  can be applied to the Free Cash Pool. To find out which one is being used, call GetFreeCashRateType.
	 */
	virtual double GetCFDFreeCashFixedRate() const = 0;

	/** Sets the Free Cash fixed interest rate. 
	 * @param rate - The fixed rate for the Free Cash Pool
	 */
	virtual void SetCFDFreeCashFixedRate(double rate) = 0;

	/** Gets the Free Cash floating interest rate. Either fixed or floating interest rates 
	 *  can be applied to the Free Cash Pool. To find out which one is being used, call GetFreeCashRateType.
	 */
	virtual long GetCFDFreeCashFloatRate() const = 0;

	/** Sets the Free Cash floating interest rate. 
	 * @param rate - The floating rate for the Free Cash Pool
	 */
	virtual void SetCFDFreeCashFloatRate(long rate) = 0;

	/** Gets the CFD notional calculation type
     * @return the cfd notional calculation type.
	 */
	virtual eCFDNotionalCalculationType GetCFDNotionalCalculationType() const = 0;

	/** Sets the CFD notional calculation type
	 * @param type: the cfd notional calculation type.
	 */
	virtual void SetCFDNotionalCalculationType(eCFDNotionalCalculationType type) = 0;

	/** Get the number of lines in CFD Notional Spread list.
	@return - the number of lines
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCFDSpreadLinesNumber() const = 0;

	/** Get Rate for CFD Notional Spread list (depends on the currency selected)
	@param numLine - the number of the line to deal with (starts with 0)
	@return - the Rate
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetRateCFDSpread(int numLine) const = 0;

	/** Set the Rate for CFD Notional Spread list (depends on the currency selected)
	@param numLine - the number of the line to deal with (starts with 0)
	@param rate - the new Rate to use (depends on the Currency selected) OR 0 to set to <empty>
	@throw - CSRCollateralException if there is an internal error
	(for example if the Rate is not found for the selected Currency)
	*/
	virtual void SetRateCFDSpread(int numLine, const long rate) = 0;

	/** Get the Payment Frequency for the CFD Notional spread
	@param numLine - the number of the line to deal with (starts with 0)
	*/
	virtual _STL::string GetPayFrequencyCFDSpread(int numLine) const = 0;

	/** Set the Payment Frequency for the CFD Notional spread
	@param numLine - the number of the line to deal with (starts with 0)
	@param str - pointer to the new value string OR to the empty string to set to <empty>
	*/
	virtual void SetPayFrequencyCFDSpread(int numLine, const _STL::string& str) = 0;
	
	/** Get the Begin Date for CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@return - the date in the long format (e.g. number of days since 01/02/1904)
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetBeginDateCFDSpread(int numLine) const = 0;

	/** Set the Begin Date for CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@param date - the date in the long format (e.g. number of days since 01/02/1904)
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetBeginDateCFDSpread(int numLine, const long date) = 0;

	/** Get the Long Spread from CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@return - the Long Margin as double
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetLongCFDSpread(int numLine) const = 0;

	/** Set Long Spread for CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@param val - the new Long Margin to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetLongCFDSpread(int numLine, const double val) = 0;

	/** Get the Short Spread from CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@return - the Short Margin as double
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetShortCFDSpread(int numLine) const = 0;

	/** Set Short Spread for the CFD Notional Spread list
	@param numLine - the number of the line to deal with (starts with 0)
	@param val - the new Short Margin to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetShortCFDSpread(int numLine, const double val) = 0; 

	/** This function returns the CFD Notional spread to apply.
	@param ccy - the currency (of the CFD instrument)
	@param rate - the rate (of the CFD instrument)
	@param date - the date to compare with the begin date for the CFD notional spread.
	@param isShort - is the position long or short?
	 */
	double GetCFDNotionalSpread(long rate, long date, long paymentFreq, bool isShort) const;

	/** This function returns all of the matching funding spreads from the CFD tab.
	@param ccy - the currency (of the CFD instrument)
	@param rate - the rate (of the CFD instrument)
	@param paymentFreq - the payment frequency from the CFD template.
	*/
	double GetCFDNotionalSpreads(long rate, long paymentFreq, _STL::vector<CFDSpreads>& spreads) const;
	/** This option only affects the realized at reset (cash pool rate) option for CFD. If this is
	 *  set then there will be no spread applied to the interest on the performance before the ticket is
	 *  generated at the reset.
	 */
	virtual bool GetCFDCashpoolRateNoSpread() const = 0;

	/** Sets the CFD Cashpool Rate Without Spread.
	 *  @param val
	 *  To be made virtual in the next version!
	 */
	virtual void SetCFDCashpoolRateNoSpread(bool val) = 0;

public:

	/**
		Used internally. To load all LB Agreement parametrization dialog data. Used by GUI.
		@param mode GUI or API (default). In API mode there is no need to use this method as only 
		needed data are loaded (automatically).
	*/
#if 0
	void LoadAllTabs(/*eSavingMode mode = smApi*/);

	/**
		Used internally.
	*/
	sophis::gui::CSRFitDialog* GetDialog() const;
	void SetDialog(sophis::gui::CSRFitDialog* dlg);

	/** 
		Get the mode in which LBA have been opened.
	*/
	sophis::backoffice_kernel::eSavingMode GetMode() const { return fMode; }

	/** 
		Set the mode of LBA. If 1st opened by API (so goes to Cache in API-mode) then reopened in GUI
		(so read from Cache) it is reset to GUI-mode. But when GUI is closed, DTOR has to reset it back
		to API-mode.
	*/
	void SetMode(sophis::backoffice_kernel::eSavingMode mode) { fMode = mode; }

	/**
	 * Run-time utility to determine if given LBA already exists.
	 *
	 * @return true if the record already exists; false otherwise.
	 */
	virtual bool Exists() const = 0;

	/**
	 * Adjusts the size of the specified list to the new number.
	 * @param tab Tab of the collateral agreement.
	 * @param tabList Element id of the list in the tab.
	 * @param newNumber New list size.
	 * @version 6.2
	 */
	void AdjustListSize(eLBAgreementTabs tab, int tabList, int newNumber);

protected:
	/**
	* Used internally
	*/
	bool CreateDialogOnly() = 0;
	
	void LoadTab(eLBAgreementTabs type) const = 0;
	sophis::gui::CSRDatabaseDialog* GetTab(eLBAgreementTabs type) const;
	
	bool Load();
	void UnLoad();
	
	void SetTabModified(eLBAgreementTabs tab);
	void DestroyDialogue();

	bool IsTabLoaded(eLBAgreementTabs type) const;
	void SetTabLoaded(eLBAgreementTabs type, bool loaded = true);

	long GetKeyValue(const char *key, const int pos) const			// to get Ctpy, Entity, Convention = 0;



#endif
	virtual bool IsNew(long ctpy, long entity, long perimenter) const = 0;

	/** Checks if the given agreement exists in the list of agreements.
	 * Clients are still advised to call CSRLBAgreement::GetCSRLBAgreement() which caches the result instead
	 * of calling this method every time.
	 * @version 5.3.5
	 */
	static bool IsNewAgreement(long ctpy, long entity, long perimenter);

#if 0
	long GetListLinesNumber(eLBAgreementTabs tabType, int tabListType) const;
#endif

protected:
	short fCommissionMarketShiftStockLoanCache; //cache the market shift value as it's used in reporting
	short fCouponMarketShiftStockLoanCache; //cache the market shift value as it's used in reporting
	short fInverseHaircutCache; // cache the inverse haircut value as it is used in reporting (like limits calc)
	mutable CSRInitialMarginProxy* fInitialMarginProxy; // cache the initial margin proxy implementation
#if 0
	sophis::backoffice_kernel::eSavingMode fMode;
	bool fNew;
	
	int fLoadedTabs[ttMax];

	_STL::vector<sophis::gui::CSRElement*> fQueryKey;
protected:
	// friends
	template<class T> 
		static T* GetTabElement(const CSRLBAgreement* lba, eLBAgreementTabs tabType, int tabElemType)
			throw (CSRCollateralException);
	template<class T>
		static T* GetTabListElement(const CSRLBAgreement* lba, eLBAgreementTabs tabType, int tabListType, 
										   int numLine, int tabElemType)
			throw (CSRCollateralException);
	
	sophis::gui::CSRFitDialog *fLBAgreementTabs;
#endif

	friend class _STL::auto_ptr<CSRLBAgreement>;	//as DTOR is private

	friend class CSRDialogLBAgreementTabs;

protected:
	long GetAllotmentLinesNumber(eAllotmentType allotmentType) const;

	long GetAllotment(eAllotmentType allotmentType, int numLine) const;
	void SetAllotment(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentCcy(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentCcy(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentBeginDate(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentBeginDate(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentSign(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentSign(eAllotmentType allotmentType, int numLine, const long val);

	_STL::string GetAllotmentCondition1(eAllotmentType allotmentType, int numLine) const;
	_STL::string GetAllotmentCondition2(eAllotmentType allotmentType, int numLine) const;
	_STL::string GetAllotmentCondition3(eAllotmentType allotmentType, int numLine) const;

	void SetAllotmentCondition1(eAllotmentType allotmentType, int numLine, _STL::string& condition);
	void SetAllotmentCondition2(eAllotmentType allotmentType, int numLine, _STL::string& condition);
	void SetAllotmentCondition3(eAllotmentType allotmentType, int numLine, _STL::string& condition);

	bool GetAllotmentExcluded(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentExcluded(eAllotmentType allotmentType, int numLine, bool val);

	long GetAllotmentMarket(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentMarket(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentMaturity(eAllotmentType allotmentType, int numLine) const;
	long GetAllotmentMaturityAbsolute(eAllotmentType allotmentType, int listIndex, long date) const;
	void SetAllotmentMaturity(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentRating(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentRating(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentIndustry(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentIndustry(eAllotmentType allotmentType, int numLine, const long val);

	long GetAllotmentAutoTicketOffset(eAllotmentType allotmentType, int numLine) const;
	void SetAllotmentAutoTicketOffset(eAllotmentType allotmentType, int numLine, const long val);

	// Index/Basket
	long GetAllotmentBasketRef(eAllotmentType allotmentType, int numLine) const;		
	void SetAllotmentBasketRef(eAllotmentType allotmentType, int numLine, const long val);	

/* Obsolete V 7.3
	long GetIndexBasketLinesNumber(bool isCollateral) const;

	long GetIndexBasket(bool isCollateral, int numLine) const;
	void SetIndexBasket(bool isCollateral, int numLine, const long val);

	long GetIndexBasketSign(bool isCollateral, int numLine) const;
	void SetIndexBasketSign(bool isCollateral, int numLine, const long val);

	bool GetIndexBasketExcluded(bool isCollateral, int numLine) const;
	void SetIndexBasketExcluded(bool isCollateral, int numLine, bool val);

	long GetIndexBasketAutoTicketOffset(bool isCollateral, int numLine) const;
	void SetIndexBasketAutoTicketOffset(bool isCollateral, int numLine, const long val);
*/
	void SetCommissionMarketShiftStockLoanCache(long val);
	void SetCouponMarketShiftStockLoanCache(long val);
	void SetInverseHaircutCache(long val);

	/**
	* Utility function with logic for checking allotment rules for given currency/quantity.
	* @param allotmentType - Is it Collateral, Principal or principal underlying stocks
	* @return - vector of Indexes (+1) to each rule that is suitable, as with the GetInstrumentSuitable function
	*/
	/*long*/ _STL::vector<long> GetCurrencySuitable(eAllotmentType allotmentType, long ccyIdent, double quantity) const;

	/**
	 * Utility function with logic for checking index/basket and allotment rules for given instrument/quantity.
	 * @param allotmentType - Is it Collateral, Principal or principal underlying stocks
	 * @return vector of indexes. 0 - no suitable record found, 1..X = index+1 of allotment list
	 * @version 5.2.7 date is required to check the maturity (if set as relative). 0 means today.	 
	 */
	_STL::vector<long> GetInstrumentSuitable(eAllotmentType allotmentType, long instrIdent, double quantity, TLib* ptr = 0, long date = 0, bool noBasket = false) const;

public:
	// Should be cleaned when merged in a patch
	long GetFirstRelevantTemplateHF(long underlyingSicovam, double numberOfSecurities) const;

	

	/**
	* Returns the first relevant template whose underlying criteria match that of underlyingSicovam
	* @Version 7.1.3
	*/
	long GetFirstRelevantTemplate(long underlyingSicovam) const;

	/**
	* Gets a list of suitable securities for the agreement.
	* Uses IsSuitableSecurity() check to filter out unsupported instrument types.
	* Returns a Vector of SValidSecurity structs which contain the 
	* Instrument id, Haircut, and Sign
	* @Version 7.2
	*/
	SValidSecuritiesList GetSuitableSecurities(long date = 0) const;

	/**
	 * Checks if type of given instrument is supported by collateral management module, and
	 * can be used within GetSuitableSecurities().
	 * @version 7.2
	 */
	static bool IsSuitableSecurity(TLib*& ph);

	/**
	 * Checks if type of given instrument is supported by collateral management module, and
	 * can be used within GetSuitableSecurities().
	 * @version 7.2
	 */
	static bool IsSuitableSecurity(long sicovam);

	/**
	  * Returns hedging ratio (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is always greater or equal to <code>100.0</code>.
	  * @param valueInProduct Optional parameter to retrieve the original value specified by user, ignoring any haircut reversal settings.
	  * @return Matching hedging value specified in the agreement or <code>100.0</code> as the default.
	  * see GetPrincipalHedgingInProduct() {@link GetPrincipalHedgingInProduct}
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  * @param isCFD - in case the deal is a CFD (true) and principal is a basket instrument, the "General Rules per Allotment" table is used to get the hedging (Margin Rate).
	  @version 5.2.7
	  */
	double GetPrincipalHedging(long instrIdent, double quantity, double *valueInProduct=0, long date = 0, bool isCFD = false) const;

	/**
	  * Returns hedging ratio to apply to the accrued (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is the one defined in the lba
	  * @return Matching hedging value to apply to the accrued specified in the agreement or <code>100.0</code> as the default.
	  @version 6.2
	  */
	double GetPrincipalIMFactorAccrued(long instrIdent, double quantity, double *valueInProduct=0, long date = 0) const;

	/**
	  * Returns hedging ratio to apply to the bond parity (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is the one defined in the lba
	  * @return Matching hedging value to apply to the bond parity specified in the agreement or <code>100.0</code> as the default.
	  @version 6.2
	  */
	double GetPrincipalIMFactorParity(long instrIdent, double quantity, double *valueInProduct=0, long date = 0) const;

	/**
	  * Returns the line where the hedging ratio (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity is taken from. If no matching 
	  * rule is found, the default of <code>-10000.0</code> is returned. 
	  * If the value is found in the &quot;Underlying Basket&quot; list, the line number is returned as its
	  * negative value.
	  * Note that hedging ratio is the one defined in the lba
	  * @param noBasket - specifies if a basket instrument should use the "Index/Basket" table (when false) or the "General Rules per Allotment" (when true).
	  * @return Line on which the hedging is taken (see above).
	  @version 6.2
	  */
	long GetPrincipalHedgingLineInProduct(long instrIdent, double quantity, long date = 0, bool noBasket =false) const;

	/**
	  * Returns hedging ratio to apply to the accrued (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is the one defined in the lba
	  * @return Matching hedging value to apply to the accrued specified in the agreement or <code>100.0</code> as the default.
	  @version 6.2
	  */
	double GetPrincipalIMFactorAccruedInProduct(long instrIdent, double quantity, long date = 0) const;

	/**
	  * Returns hedging ratio to apply to the bond parity (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is the one defined in the lba
	  * @return Matching hedging value to apply to the bond parity specified in the agreement or <code>100.0</code> as the default.
	  @version 6.2
	  */
	double GetPrincipalIMFactorParityInProduct(long instrIdent, double quantity, long date = 0) const;

	/**
	  * Returns hedging ratio (specified within the &quot;Principal&quot; 
	  * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>100.0</code> is returned. 
	  * Note that hedging ratio is the one defined in the lba
	  * @return Matching hedging value specified in the agreement or <code>100.0</code> as the default.
	  * @version 5.2.4
	  * see GetPrincipalHedging() {@link GetPrincipalHedging}
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  * @param noBasket - specifies if a basket instrument should use the "Index/Basket" table (when false) or the "General Rules per Allotment" (when true).
	  @version 5.2.7
	  */
	double GetPrincipalHedgingInProduct(long instrIdent, double quantity, long date = 0, bool noBasket = false) const;

	/**
	  * Returns the CFD short spread that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>0.0</code> is returned. 
	  * Note that the CFD short spread is the one defined in the lba
	  * @return CFD short spread value specified in the agreement or <code>0.0</code> as the default.
	  * @version 5.3.4
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  */
	double GetPrincipalCfdShortSpreadInProduct(long instrIdent, double quantity, long date =0) const;
	
	/**
	  * Returns the CFD long spread that matches given instrument and quantity. If no matching rule is 
	  * found, the default of <code>0.0</code> is returned. 
	  * Note that the CFD long spread is the one defined in the lba
	  * @return CFD long spread value specified in the agreement or <code>0.0</code> as the default.
	  * @version 5.3.4
	  * @param date - required date to calculate maturity (if relative), 0 means today. 
	  */
	double GetPrincipalCfdLongSpreadInProduct(long instrIdent, double quantity, long date =0) const;

	/**
	* Gets the CFD long and short spreads that match given instrument and quantity. If no matching rule is 
	* found, the default of <code>0.0</code> is for each of the spreads. 
	* @version 5.3.4
	* @param date - required date to calculate maturity (if relative), 0 means today. 
	*/
	void GetPrincipalCfdSpreadsInProduct(long instrIdent, double quantity, double& longSpread, double& shortSpread, long date) const;

	/**
	 * Returns hedging ratio (specified within the &quot;Principal&quot; 
	 * tab of the agreement) that matches given currency and amount. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned.
	 * Note that hedging ratio is always greater or equal to <code>100.0</code>.
	 *
	 * @param valueInProduct Optional parameter to retrieve the original value specified by user, ignoring any haircut reversal settings.
	 * @return Matching hedging value specified in the agreement or <code>100.0</code> as the default.
	 * @version 5.1
	 * see GetCurrencyHedgingInProduct() {@link GetCurrencyHedgingInProduct}
	 */
	double GetCurrencyHedging(long ccyIdent, double quantity, double *valueInProduct=0) const;

	/**
	 * Returns hedging ratio (specified within the &quot;Principal&quot; 
	 * tab of the agreement) that matches given currency and amount. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned.
	 * Note that hedging ratio is the one defined in the lba
	 * @return Matching hedging value specified in the agreement or <code>100.0</code> as the default.
	 *
	 * @version 5.2.4
	 * see GetCurrencyHedging() {@link GetCurrencyHedging}
	 */
	double GetCurrencyHedgingInProduct(long ccyIdent, double quantity) const;

	/**
	 * Returns the expiryDate minus the freeze shift specified for the given instrument in the Principal tab.
	 * If no freeze shift is parametrised, the default market shift can be used, according to the flag.
	 * The return date is calculated using both instrument and agreement calendars.
	 *
	 * @param instrIdent Instrument id (sicovam).
	 * @param quantity Instrument quantity.
	 * @param expiryDate Date to which the shift is applied to.
	 * @param useMarketShift Flag to indicate if default market shift should be used in case no shift has been parametrised.
	 *
	 * @return expiryDate minus the freeze shift, according to the calendars.
	 *
	 * @version 5.2.4
	 * @param date Optional date used to calculate maturity (if relative), 0 means today. 
	 * @version 5.2.7
	 */
	long GetPrincipalFreezeDate(long instrIdent, double quantity, long expiryDate, bool useMarketShift = true, long date = 0) const;

	/**
	 * Returns the expiryDate minus the freeze shift specified for the given currency in the Principal tab.
	 * If no freeze shift is parametrised, the default market shift can be used, according to the flag.
	 * The return date is calculated using both instrument and agreement calendars.
	 *
	 * @param ccyIdent Currency id (sicovam).
	 * @param quantity Currency amount.
	 * @param expiryDate Date to which the shift is applied to.
	 * @param useMarketShift Flag to indicate if default market shift should be used in case no shift has been parametrised.
	 *
	 * @return expiryDate minus the freeze shift, according to the calendars.
	 *
	 * @version 5.2.4
	 */
	long GetCurrencyFreezeDate(long ccyIdent, double quantity, long expiryDate, bool useMarketShift = true) const;

	/**
	 * Returns collateral haircut ratio (specified within the &quot;Collateral&quot; 
	 * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned. 
	 * Note that haircut ratio is always greater that <code>0.0</code> and 
	 * less or equal to <code>100.0</code>.
	 * @param valueInProduct Optional parameter to retrieve the original value specified by user, ignoring any haircut reversal settings.
	 * @return Matching haircut value specified in the agreement or <code>100.0</code> as the default.
	 * see GetCollateralHaircutInProduct() {@link GetCollateralHaircutInProduct}
	 * @param date - required date to calculate maturity (if relative), 0 means today. 
	 * @version 5.2.7
	 */
	double GetCollateralHaircut(long instrIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0, long date = 0) const;

	/**
	 * Returns currency haircut ratio (specified within the &quot;Collateral&quot; 
	 * tab of the agreement) that matches given currency and amount. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned. 
	 * Note that haircut ratio is always greater that <code>0.0</code> and 
	 * less or equal to <code>100.0</code>.
	 * @param valueInProduct Optional parameter to retrieve the original value specified by user, ignoring any haircut reversal settings.
	 * @return Matching haircut value specified in the agreement or <code>100.0</code> as the default.
	 * see GetCurrencyHaircutInProduct() {@link GetCurrencyHaircutInProduct}
	 */
	double GetCurrencyHaircut(long ccyIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0) const;

	/*Gets selected Collateral Haircut method name
	* Since 7.1*/
	virtual _STL::string GetCollateralHaircutMethod() const = 0;

	/*Sets Collateral Haircut method name
	* Since 7.1*/
	virtual void SetCollateralHaircutMethod(const _STL::string& implName) = 0;

	/**
	 * Default implementation of GetCollateralHaircut.
	 */
	double GetDefaultCollateralHaircutImpl(long instrIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0, long date = 0) const;

	/**
	 * Default implementation of GetCurrencyHaircut. 
	 */
	double GetDefaultCurrencyHaircutImpl(long ccyIdent, double quantity, eHairCutType hairCutType, double *valueInProduct=0) const;

	/**
	 * Return the pointer to the current implementation of Collateral haircut calculation.
	 * @version 7.1
	 */
	const CSRCollateralHaircut& GetHaircutMethodImpl() const;

	/**
	 * Returns the expiryDate minus the freeze shift specified for the given instrument in the Collateral tab.
	 * If no freeze shift is parametrised, the default market shift can be used, according to the flag.
	 * The return date is calculated using both instrument and agreement calendars.
	 *
	 * @param instrIdent Instrument id (sicovam).
	 * @param quantity Instrument quantity.
	 * @param expiryDate Date to which the shift is applied to.
	 * @param useMarketShift Flag to indicate if default market shift should be used in case no shift has been parametrised.
	 *
	 * @return expiryDate minus the freeze shift, according to the calendars.
	 *
	 * @version 5.2.4
	 * @param date Optional date used to calculate maturity (if relative), 0 means today. 
	 * @version 5.2.7
	 */
	long GetCollateralFreezeDate(long instrIdent, double quantity, long expiryDate, bool useMarketShift = true, long date = 0) const;

	/**
	 * Returns the expiryDate minus the freeze shift specified for the given currency in the Collateral tab.
	 * If no freeze shift is parametrised, the default market shift can be used, according to the flag.
	 * The return date is calculated using both instrument and agreement calendars.
	 *
	 * @param ccyIdent Currency id (sicovam).
	 * @param quantity Currency amount.
	 * @param expiryDate Date to which the shift is applied to.
	 * @param useMarketShift Flag to indicate if default market shift should be used in case no shift has been parametrised.
	 *
	 * @return expiryDate minus the freeze shift, according to the calendars.
	 *
	 * @version 5.2.4
	 */
	long GetMarginCallFreezeDate(long ccyIdent, double quantity, long expiryDate, bool useMarketShift = true) const;

	/**
	 * Returns flag indicating if given agreement is valid for a given date.
	 * Valid agreement implies it has been parametrized with mandatory data,
	 * plus the current system date lies within begin and end dates of the
	 * agreement.
	 */
	bool IsValid( long date = 0 ) const;

	/**
	 * Returns next valid interest payment date for the given instrument, taking
	 * the calendar of the agreement into the account.
	 *
	 * @param date (Optional) The date to look froml; by default from today.
	 * @param sicovam (Optional) if next interest payment date is calculated for given instrument.
	 * @version 5.1
	 */
	long GetNextInterestPaymentDate(long date=0, long sicovam=0) const;

	/**
	 * Returns next valid billing date for the given instrument, taking
	 * into the account both the instrument (in case of CSRLoanAndRepo)
	 * and agreement setting into the account.
	 *
	 * @param date (Optional) The date to look from; by default from today.
	 * @param sicovam (Optional) if next billing date is calculated for given instrument.
	 * @version 5.1
	 */
	long GetNextBillingDate(long date=0, long sicovam=0) const;

	/**
	 * Returns the LAST Fee Mark Spot for the given instrument,
	 * as defined by the spot schedule. The value is returned
	 * in given currency.
	 *
	 * @param sicovam Instrument.
	 * @param currency (Optional) Currency to return the value; by default currency of the instrument;
	 *                 if different from the instrument currency, the agreement's forex is used.
	 * @param date (Optional) the last date to use; by default today.
	 * @version 5.1
	 */
	double GetLastFeeMarkSpot(long sicovam, long currency=0, long date=0) const;

	/**
	 * see CSRCollateralIndicatorForex::GetForex() {@link CSRCollateralIndicatorForex::GetForex}
	 * @version 5.2.7 Optional parameter spotDate returns the spot date.
	 */
    double GetForex(long currency1, long currency2, long date=0, long * forexDate = 0) const;

	/**
	 * Must provide implementation of CSRCollateralIndicatorForex interface.
	 */
	virtual const CSRCollateralIndicatorForex& GetCollateralIndicatorForex() const = 0;

	/***
	* Returns a list of rates that are allowed according to the LBA as defined
	* in the Margin Call Tab.
	* @param currency id
	* @param a list of rates for currency passed in (out parameter)
	* @version 5.1.1
	*/
	void GetValidInterestRates(long currency, _STL::set<long>& rates) const;
	
	/**
	*Returns a menu containing only the rates allowed for this currency param
	* as per the Margin Call Tab
	* @param currency id
	* @return interest rates menu
	*/
	MenuHandle	GetInterestRatesMenu(long currency) const;

	/**
	*Returns a menu containing only the rates allowed for this currency param
	* This function does not filter based on the Cash Remuneration lines. It returns all valid 
	* rates for the currency.
	* @param currency id
	* @return interest rates menu
	*/
	MenuHandle	GetInterestRatesMenuNoFilter(long currency) const;
	/**
	* Returns US Counterparty payment offset for the given instrument
	*
	* @param sicovam 
	* @param quantity (so we can match with the sign in principal allotment list)
	* @version 5.2
	* @param date - required date to calculate maturity (if relative), 0 means today. 
	* @version 5.2.7
	*/
	long GetUSCptyPaymentOffset(long instrIdent, double quantity, long date = 0) const;

	/**
	* Returns settlement lag (former us counterparty offset) for the given currency
	*
	* @param currency 
	* @param quantity (so we can match with the sign in principal allotment list)
	* version 7.1
	*/
	long GetCurrencySettlementLag(long ccyIdent, double quantity) const;

	/**
	 * Returns haircut ratio (specified within the &quot;Collateral&quot; 
	 * tab of the agreement) that matches given instrument and quantity. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned. 
	 * Note that haircut is the one entered in the lba.
	 * @return Matching haircut value specified in the agreement or <code>100.0</code> as the default.
	 * see GetCollateralHaircut() {@link GetCollateralHaircut}
	 * @version 5.2.4
	 * @param date - required date to calculate maturity (if relative), 0 means today. 
	 * @version 5.2.7
	 */
	double GetCollateralHaircutInProduct(long instrIdent, double quantity, eHairCutType hairCutType, long date = 0) const;

	/**
	 * Returns haircut ratio (specified within the &quot;Collateral&quot; 
	 * tab of the agreement) that matches given currency and amount. If no matching rule is 
	 * found, the default of <code>100.0</code> is returned. 
	 * Note that haircut is the one entered in the lba.
	 * @return Matching haircut value specified in the agreement or <code>100.0</code> as the default.
	 * see GetCurrencyHaircut() {@link GetCurrencyHaircut}
	 * @version 5.2.5 Add the hair cut type
	 * @version 5.2.4
	 */
	double GetCurrencyHaircutInProduct(long ccyIdent, double quantity, eHairCutType hairCutType) const;

	/**
	 * @deprecated 5.3.6 Use GetAccruedInterestIncluded() instead.
	 * Returns the value of the Include Accrued Interest flag from the Credit Risk Calculation tab.
	 * The flag indicates if the accrued amount of interest should be taken into account for credit
	 * risk calculation.
	 * The default value is false;
	 * @return true if the flag is set; false (default) otherwise.
	 * @version 5.2.5
	 */
	bool IsAccruedInterestIncluded() const { return (GetAccruedInterestIncluded() == eaicInterestOnly || GetAccruedInterestIncluded() == eaicInterestAndCommission); }

	/**
	 * @deprecated 5.3.6 Use GetAccruedInterestIncluded() instead.
	 * Returns the value of the Include Accrued Commission flag from the Credit Risk Calculation tab.
	 * The flag indicates if the accrued amount of commission should be taken into account for credit
	 * risk calculation.
	 * The default value is false;
	 * @return true if the flag is set; false (default) otherwise.
	 */
	bool IsAccruedCommissionIncluded() const { return (GetAccruedInterestIncluded() == eaicCommissionOnly || GetAccruedInterestIncluded() == eaicInterestAndCommission); }

	/**
	 * Returns the value of the Include Accrued Interest flag from the Credit Risk Calculation tab.
	 * The flag indicates if the accrued amount of interest should be taken into account for credit
	 * risk calculation.
	 * The default value is false;
	 * @return true if the flag is set; false (default) otherwise.
	 * @version 5.2.5
	 * @version 5.3.6 The signature has changed to return enum eAccruedInterestCommission
	 */
	virtual eAccruedInterestCommission GetAccruedInterestIncluded() const = 0;

	/**
	 * INTERNAL.
	 */
	virtual bool ChangeQueryKey(long cpty, long entity, long convention){return false;};

	/** Get the Minimum Limit from the Entity Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@return - the value of the limit
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetEntityMinLimit(int numLine) const = 0;

	/** Set the Minimum Limit for Entity Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@param ccy - new Minimum Limit to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetEntityMinLimit(int numLine, const long val) = 0;

	/** Get the Minimum Limit from the Counterparty Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@return - the value of the limit
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual long GetCounterpartyMinLimit(int numLine) const = 0;
	
	/** Set the Minimum Limit for Counterparty Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@param ccy - new Minimum Limit to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCounterpartyMinLimit(int numLine, const long val) = 0;

	/** Get the Threshold value from the Entity Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@return - the value of the threshold
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetEntityThreshold(int numLine) const = 0;
	
	
	/** Set the Threshold value for Entity Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@param ccy - new Threshold value to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetEntityThreshold(int numLine, const double val) = 0;

	/** Get the Threshold value from the Counterparty Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@return - the value of the threshold
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual double GetCounterpartyThreshold(int numLine) const = 0;

	/** Set the Threshold value for Counterparty Threshold list
	@param numLine - the number of line to deal with (starts with 0)
	@param ccy - new Threshold value to be set
	@throw - CSRCollateralException if there is an internal error
	*/
	virtual void SetCounterpartyThreshold(int numLine, const double val) = 0;

	/** Get the configured threshold value according to the net exposure and mtm exposure values.
	@param netExposure - exposure value from which threshold is calculated, Exposure = MtM Exposure + Initial Amount (Initial Margin)
	@param mtmExposure - collateralisation of the MtM moves (Variation Margin)
	@return the threshold value
	@throw CSRCollateralException if there is an internal error
	@version 5.3.5
	@version 6.2 MtM Exposure
	*/
	virtual double GetThreshold(double netExposure, double mtmExposure) const = 0;

	/** 
	 * Get the actual threshold value (in reference currency) to be applied according to the net exposure value and mtm exposure values.
	 * This value can be applied to risk value.
	 * @param exposure Exposure value in reference currency from which threshold is calculated, Exposure = MtM Exposure + Initial Amount (Initial Margin)
	 * @param mtmExposure Collateralisation of the MtM moves (Variation Margin), in reference currency.
	 * @param threshold Threshold from configuration or 0 (optional) to fetch from the agreement.
	 * @return Threshold value to be applied to risk value.
	 * @version 6.2
	 */
	double GetThresholdApplied(double exposure, double mtmExposure, double threshold = 0) const;

	/** 
	 * Get the type of threshold to be applied.
	 * @version 6.2
	 */
	virtual eThresholdType GetThresholdType() const = 0;

	/**
	 * Set the type of threshold to be applied.
	 * @version 6.2
	 */
	virtual void SetThresholdType(const eThresholdType val) = 0;

	/** 
	 * Get the rating agency selected for the threshold.
	 * @version 6.3.2
	 */
	virtual long GetThresholdRatingAgency() const = 0;

	/**
	 * Set the rating agency selected for the threshold.
	 * @version 6.3.2
	 */
	virtual void SetThresholdRatingAgency(const long val) = 0;

	/** 
	 * Get the rating seniority selected for the threshold.
	 * @version 6.3.2
	 */
	virtual long GetThresholdRatingSeniority() const = 0;

	/**
	 * Set the rating seniority selected for the threshold.
	 * @version 6.3.2
	 */
	virtual void SetThresholdRatingSeniority(const long val) = 0;

	/** 
		Agreement Properties List
	*/

	/** Get the number of lines in Agreement Properties list.
	 * @version 6.2.2
	 */
	virtual long GetAgreementPropertiesLinesNumber() const = 0;

	/**	Get the property name of the corresponding line in Agreement Properties list.
	 * @param numLine - is the number of line from list to deal with (starts with 0).
	 * @version 6.2.2
	 */
	virtual _STL::string GetAgreementPropertiesName(int numLine) const = 0;

	/** Set the property name of the corresponding line in Agreement Properties list.
	 * @param numLine - is the number of line from list to deal with (starts with 0).
	 * @param propertyName - is the property name.
	 * @version 6.2.2
	 */
	virtual void SetAgreementPropertiesName(int numLine, const _STL::string& propertyName) = 0;

	/** Get the value from the property of the corresponding line in Agreement Properties list.
	 * @param numLine - is the number of line from list to deal with (starts with 0).
	 * @version 6.2.2
	 */
	virtual _STL::string GetAgreementPropertiesValue(int numLine) const = 0;

	/** Set the property value of the corresponding line in Agreement Properties list.
	 * @param numLine - is the number of line from list to deal with (starts with 0).
	 * @param propertyValue - is the property value.
	 * @version 6.2.2
	 */
	virtual void SetAgreementPropertiesValue(int numLine, const _STL::string& propertyValue) = 0;

	/** Get tri party type of the agreement. */
	virtual eAgreementTriPartyType GetTriPartyType() const = 0;

	/** Get the value of the collateral rehypothecation rules.
	 * @version 7.1
	 */
	virtual eRehypothecation GetRehypothecation() const = 0;

	/** Set the value for collateral rehypothecation rules.
	 * @param val - index value of the rule to be used in order to rehypothecate collateral.
	 * @version 7.1
	 */
	virtual void SetRehypothecation(const eRehypothecation val) = 0;

	/** Returns access to custom (toolkit) data if applicable.
	 * @version 7.1.1 */
	virtual const CSRCollateralAgreementCustomData* GetCustomData() const = 0;


    /**
    * MarginCall Rounding Prefs had to be exposed to the api in 7.2 in order for serialization to work correctly
    */
	struct MarginCallRoundingPref{
		long fCcy;
		short fRoundType;
		long fSign;
		double fRoundValue;
	};

    /** Get the Margin Call Rounding Preferences
     *  @param list - vector of MarginCallRoundingPref to fill with data
    */
	virtual void GetMarginCallRoundingPrefList(_STL::vector<MarginCallRoundingPref>& list) const = 0;

    /** Set the Margin Call Rounding Preferences
     *  @param list - vector of MarginCallRoundingPref
    */
	virtual void SetMarginCallRoundingPrefList(const _STL::vector<CSRLBAgreement::MarginCallRoundingPref>& list) = 0;


#if 0
public:
	char fModel[40 + 1];
#endif
};

#if 0
template<class T>
T* CSRLBAgreement::GetTabElement(const CSRLBAgreement* lba, eLBAgreementTabs tabType, int tabElemType)
	throw (CSRCollateralException)
{
	lba->LoadTab(tabType);
	
	sophis::gui::CSRDatabaseDialog *tab = dynamic_cast<sophis::gui::CSRDatabaseDialog*>(lba->GetTab(tabType));
	if (!tab)
		throw CSRCollateralException("Exception while GetTabElement(). Can't get element by provided ID.");

	T* elem = dynamic_cast<T*>(tab->GetElementByRelativeId(tabElemType));
	if (!elem)
		throw CSRCollateralException("Exception while GetTabElement(). Can't get element by provided ID.");

	return elem;
}

template<class T>
T* CSRLBAgreement::GetTabListElement(const CSRLBAgreement* lba, eLBAgreementTabs tabType, int tabListType, 
							int numLine, int tabElemType)
	throw (CSRCollateralException)
{
	lba->LoadTab(tabType);
	
	sophis::gui::CSRDatabaseDialog *tab = dynamic_cast<sophis::gui::CSRDatabaseDialog*>(lba->GetTab(tabType));
	if (!tab)
		throw CSRCollateralException("Exception while GetTabListElement(). Can't get element by provided ID.");

	sophis::gui::CSREditList	*list = dynamic_cast<sophis::gui::CSREditList*>(tab->GetElementByRelativeId(tabListType));
	if (!list)
		throw CSRCollateralException("Exception while GetTabListElement(). Can't get element by provided ID.");

	int nbLines = list->GetLineCount();
	if (0 == nbLines)
	{
		_STL::ostringstream msg;
		msg << "Exception while GetTabListElement(). EditList for this LBA not found [specified triplet: " \
			<< "conuterparty = " << lba->GetCtpy() << ", " \
			<< "entity = " << lba->GetEntity() << ", " \
			<< "convention = " << lba->GetConvention() \
			<< "]" << _STL::ends;
		throw CSRCollateralException(msg.str().c_str());
	}

	if ( numLine >= nbLines)
		throw CSRCollateralException("Exception while GetTabListElement(). <numLine> is bigger then lines number.");;

	list->LoadLine(numLine);
	list->SetCurrentLine(numLine);
	
	T* elem = 
		dynamic_cast<T*>(list->GetElementByRelativeId(tabElemType));
	if (!elem)
		throw CSRCollateralException("Exception while GetTabListElement(). Can't get element by provdied ID.");

	if (!elem->GetEditList())
		throw CSRCollateralException("Exception while GetTabListElement(). Can't get EditList of Element.");

	return elem;
}
#endif

/**
 * Interface for custom data attached to the custom Collateral Agreement tab. 
 * @version 7.1.1
 */
class SOPHIS_FIT CSRCollateralAgreementCustomData
{
public:
	virtual ~CSRCollateralAgreementCustomData();
	virtual CSRCollateralAgreementCustomData* Clone() const = 0;
};

	}
}


SPH_EPILOG

#endif //_CSRLBAgreement_H_
