/*
 	File:		SphLBAgreementAction.h
 
 	Contains:	Class to generate action on a Loan & Borrowing Agreement when saved.
 
 	Copyright:	� 2004 Sophis.
 
*/


#pragma once

#ifndef _SphLBAgreementAction_H_
#define _SphLBAgreementAction_H_

#ifndef _SphPrototype_H_
	#include "SphTools/SphPrototype.h"
#endif
#ifndef _SphAlgorthm_H_
	#include "SphInc/tools/SphAlgorithm.h"
#endif

#ifndef _SphValidation_H_
	#include "SphInc/tools/SphValidation.h"
#endif

#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"

SPH_PROLOG
namespace sophis {
   namespace collateral {

	   class CSRLBAgreement;

#define DECLARATION_LBAGREEMENT_ACTION(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, CSRLBAgreementAction)
#define CONSTRUCTOR_LBAGREEMENT_ACTION(derivedClass)			
#define WITHOUT_LBAGREEMENT_ACTION(derivedClass)	
#define	INITIALISE_LBAGREEMENT_ACTION(derivedClass, order,  name) \
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

#define DECLARATION_LBAGREEMENT_EVENT(derivedClass)	\
	DECLARATION_PROTOTYPE(derivedClass, CSRLBAgreementEvent)
#define CONSTRUCTOR_LBAGREEMENT_EVENT(derivedClass)			
#define WITHOUT_CONSTRUCTOR_LBAGREEMENT_EVENT(derivedClass)	
#define	INITIALISE_LBAGREEMENT_EVENT(derivedClass, order,  name) \
	INITIALISE_ORDERED_PROTOTYPE(derivedClass, order, name)

enum eTCPMessageType
{
   tp_modified,
   tp_new,
   tp_deleted,
   tp_delete_fe,
   tp_transferred,
   tp_transferred_fe
};

/** Interface to trigger some actions when saving LB Agreement.
You can overload this class and insert your own triggers.
@since 5.0.0
*/
class SOPHIS_COLLATERAL CSRLBAgreementAction
{
public:

	/** Specify the order of the triggers.
	*/
	enum	eOrder	{
		/** Before saving the data
		*/
		oBefore,
		
		/** Used internally : the code for saving is actually a trigger ordered by this enum
		*/
		oSave,

		/** After saving the data
		*/
		oAfter
	};

	/** Trivial constructor
	*/
	CSRLBAgreementAction();

	/** Trivial destructor
	*/
	virtual ~CSRLBAgreementAction();

	/** Ask for a creation of a lB Agreement.
	When creating, first all the triggers will be called via VoteForCreation to check if they accept the
	creation in the order eOrder + lexicographical order.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to be created. It is a non const object so that you can
	modify it.
	@throws VoteException if you reject that creation.
	*/
	virtual void VoteForCreation(sophis::backoffice_kernel::eSavingMode mode, CSRLBAgreement &lba)
		throw (sophis::tools::VoteException);

	/** Ask for accepting a modification
	When saving, first all the triggers will be called via VoteForModification to check if they accept the
	modification in the order eOrder + lexicographical order.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to save. It is a non const object so that you can
	modify it.
	@throws VoteException if you reject that modification.
	*/
	virtual void VoteForModification(sophis::backoffice_kernel::eSavingMode mode, CSRLBAgreement &lba)
		throw (sophis::tools::VoteException);

	/** Ask for deletion of a LB Agreement.
	When deleting, first all the triggers will be called via VoteForDeletion to check if they accept the
	deletion in the order eOrder + lexicographical order.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to delete.
	@throws VoteException if you reject that deletion.
	*/
	virtual void VoteForDeletion(sophis::backoffice_kernel::eSavingMode mode, const CSRLBAgreement &lba)
		throw (sophis::tools::VoteException);

	/** Ask what to notify when creating.
	When saving, after that all the triggers have accepted the creation, they are called again 
	in the order eOrder + lexicographical order via
	NotifyCreated to check if they have something to save in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to create. It is a const object so that you cannot
	modify it. 
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that creation. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyCreated(sophis::backoffice_kernel::eSavingMode mode, 
							   const CSRLBAgreement &lba, 
							   sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** Ask what to notify when modifying.
	When saving, after that all the triggers have accepted the modification, they are called again 
	in the order eOrder + lexicographical order via
	NotifyModified to check if they have something to save in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to save. It is a const object so that you cannot
	modify it.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyModified(sophis::backoffice_kernel::eSavingMode mode, 
								const CSRLBAgreement &lba, 
								sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** Ask what to notify when deleting.
	When deleting, after that all the triggers have accepted the creation, they are called again 
	in the order eOrder + lexicographical order via
	NotifyDeleted to check if they have something to delete in the database or send to other servers.
	@param mode specifies whether the action is being carried out by the API or GUI.
	@param lba is the LB Agreement to delete.
	@param message is an event vector to put your messages to send after the data are commited.
	Indeed, if you need to send a data, you cannot do it immediately because you must be sure that the
	message is in concordance with the database which will be the case after commiting. Moreover, if there
	is an exception in another trigger, the message must not be sent.
	@throws ExceptionBase if you reject that modification. Do not send a VoteException. This can cause
	some trouble, as in case of multi saving it will assume that no data or message is done. Do not commit, nor Rollback either,
	it is done elsewhere.
	*/
	virtual void NotifyDeleted(sophis::backoffice_kernel::eSavingMode mode, 
							   const CSRLBAgreement &lba, 
							   sophis::tools::CSREventVector & message)
		throw (sophisTools::base::ExceptionBase); 

	/** key for the prototype is eOrder + lexicographical 
	*/
	typedef sophis::tools::ordered_name<eOrder> ordered_name;
	
	/** typedef for the prototype
	*/
	typedef sophis::tools::CSRPrototype<CSRLBAgreementAction, ordered_name> prototype;

	/** access to the prototype singleton
	To add a trigger to this singleton, use INITIALISE_LBAGREEMENT_ACTION
	@see tools::CSRPrototype
	*/
	static prototype & GetPrototype();

	/** Clone method needed by the prototype
	Usually, it is done automaticly by the macro DECLARATION_LBAGREEMENT_ACTION
	@see tools::CSRPrototype
	*/
	virtual CSRLBAgreementAction * Clone() const = 0;

private:
    void Vote(CSRLBAgreement* lba)
         throw (sophis::tools::VoteException);

    void Notify(CSRLBAgreement &lba, sophis::tools::CSREventVector & mess)
	     throw (sophisTools::base::ExceptionBase);
};

/** Interface triggered when another workstation has modified the LB Agreement
You can overload this class and insert your own triggers
@version 5.0.0
*/
class SOPHIS_COLLATERAL CSRLBAgreementEvent
{
public:

	/*
	/** Specify the order of the triggers.
	*/
	enum	eOrder	{
		/** Before updating the data
		*/
		oBefore,
		
		/** Used internally : the code for updating is actually a trigger ordered by this enum
		*/
		oUpdate,

		/** After updating the data
		*/
		oAfter
	};

	/** Trivial constructor
	*/
	CSRLBAgreementEvent();

	/** Trivial Destructor
	*/
	virtual ~CSRLBAgreementEvent();

	/** Called when a LB Agreement has been created in another workstation.
	When receiving a creation event for portfolio, all the triggers are called by this method
	 in the order eOrder + lexicographical order.
	@param lba is a LB Agreement instance with the new data; note that this instance is not
	the one given by CSRPortfolio::GetCSRPortfolio and will be deleted soon; you can modify it in 
	listenner of type oBefore but it is not recommanded.
	@return false to bypass this event; In that case the other triggers are not executed
	and the windows are not updated; Use it with moderation, only in the case oBefore.
	*/
	virtual bool HasBeenCreated(const CSRLBAgreement &lba, long selection);

	/** Called when a LB Agreement has been updated in another workstation.
	When receiving an update event for portfolio, all the triggers are called by this method
	in the order eOrder + lexicographical order.
	@param lba is a LB Agreement instance with the new data; note that this instance is not
	the one given by CSRPortfolio::GetCSRPortfolio and will be deleted soon; you can modify it in 
	listenner of type oBefore but it is not recommanded.
	*/
	virtual void HasBeenModified(const CSRLBAgreement &lba, long selection);

	/** Called when a LB Agreement has been created in another workstation.
	When receiving a delete event for LB Agreement, all the triggers are called by this method
	in the order eOrder + lexicographical order.
	@param ctpy is the IDENT of the Counterparty.
	@param entity is the IDENT of the Entity.
	@param perimeter is the ID of the Perimeter (Convention).
	This triplet is used to uniquely indentify the LB Agreement.
	*/
	virtual void HasBeenDeleted(long ctpy, long entity, long perimeter);

	/** key for the prototype is eOrder + lexicographical 
	*/
	typedef sophis::tools::ordered_name<eOrder> ordered_name;
	
	/** typedef for the prototype
	*/
	typedef sophis::tools::CSRPrototype<CSRLBAgreementEvent, ordered_name> prototype;

	/** access to the prototype singleton
	To add a trigger to this singleton, use INITIALISE_LBAGREEMENT_EVENT
	@see CSRPrototype
	*/
	static prototype & GetPrototype();

	/** Clone method needed by the prototype
	Usually, it is done automatically by the macro DECLARATION_LBAGREEMENT_EVENT
	@see CSRPrototype
	*/
	virtual CSRLBAgreementEvent * Clone() const = 0;
};

   }
}
SPH_EPILOG
#endif	//_SphLBAgreementAction_H_