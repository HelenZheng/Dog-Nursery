#pragma once
#ifndef _CSRLBAgreementProxy_H_
#define _CSRLBAgreementProxy_H_

#include "SphInc/collateral/SphLBAgreement.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Proxy base implementation of CSRLBAgreement interface.
 * Calls are directed to proxy instance.
 * No Set() methods are allowed, @throws NotImplemented.
 * @version 7.0
 */
class SOPHIS_FIT CSRLBAgreementProxy : public virtual CSRLBAgreement
{
protected:
	CSRLBAgreementProxy();
	CSRLBAgreementProxy(const CSRLBAgreementProxy& clone);
	/** @throws NotImplemented exception. */
	bool NotImplemented();
	/** To be implemented in derived classes. Must return proxy object. */
	virtual const CSRLBAgreement& GetProxy() const = 0;

public:
	virtual ~CSRLBAgreementProxy();
	virtual CSRLBAgreement* Clone() { return 0; }

	virtual bool Save(sophis::backoffice_kernel::eSavingMode mode = sophis::backoffice_kernel::smApi)
		throw (sophis::tools::VoteException) { return NotImplemented(); }
	virtual void MultiSave(sophis::backoffice_kernel::eSavingMode mode, sophis::tools::CSREventVector &ev)
		throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase) { NotImplemented(); }
	virtual void MultiDelete(sophis::backoffice_kernel::eSavingMode mode, sophis::tools::CSREventVector &ev) 
		throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase) { NotImplemented(); }

	virtual bool ChangeQueryKey(long cpty, long entity, long convention) { return false; }
	virtual bool IsNew(long ctpy, long entity, long convention) const { return GetProxy().IsNew(ctpy, entity, convention); }
	virtual const CSRCollateralIndicatorForex& GetCollateralIndicatorForex() const
	{ return GetProxy().GetCollateralIndicatorForex(); }

	// Virtual Agreement
	virtual void GetAgreementFamilyList(_STL::vector<ThirdPartyPair>& familyList) const
	{ return GetProxy().GetAgreementFamilyList(familyList);	}

	/// Triplet
	virtual long GetCtpy() const { return GetProxy().GetCtpy(); }
	virtual long GetEntity() const { return GetProxy().GetEntity(); }
	virtual long GetConvention() const { return GetProxy().GetConvention(); }

	/// General getters
	virtual _STL::string GetContractName()const { return GetProxy().GetContractName(); }
	virtual long GetBeginDate()const { return GetProxy().GetBeginDate(); }
	virtual long GetEndDate()const { return GetProxy().GetEndDate(); }
	virtual long GetTriParty()const { return GetProxy().GetTriParty(); }
	virtual long GetTriPartyMarginCall() const { return GetProxy().GetTriPartyMarginCall(); }
	virtual _STL::string GetComments()const { return GetProxy().GetComments(); }
	virtual long GetCollateralFolio()const { return GetProxy().GetCollateralFolio(); }
	virtual bool GetKeepCollatInPricipalFolio()const { return GetProxy().GetKeepCollatInPricipalFolio(); }
	virtual long GetDefaultTemplateLinesNumber()const { return GetProxy().GetDefaultTemplateLinesNumber(); }
	virtual long GetDefaultTemplateName(int line)const { return GetProxy().GetDefaultTemplateName(line); }
	virtual _STL::string GetDefaultTemplateModel(int numLine)const { return GetProxy().GetDefaultTemplateModel(numLine); }
	virtual long GetMarginCallFolio() const { return GetProxy().GetMarginCallFolio(); }
	virtual _STL::string GetExternalReference() const { return GetProxy().GetExternalReference(); }
	virtual void GetSpecificCounterpartyEntity(const eSpecificCptyEntityPair specificPair, long& counterparty, long& entity) const { GetProxy().GetSpecificCounterpartyEntity(specificPair, counterparty, entity); }
	virtual eAgreementThirdsType GetThirdsType() const { return GetProxy().GetThirdsType(); }
	virtual long GetThirdsLinesNumber() const { return GetProxy().GetThirdsLinesNumber(); }
	virtual long GetThirdsCounterparty(int numLine) const { return GetProxy().GetThirdsCounterparty(numLine); }
	virtual long GetThirdsEntity(int numLine) const { return GetProxy().GetThirdsEntity(numLine); }
	virtual eAgreementTriPartyType GetTriPartyType() const { return GetProxy().GetTriPartyType(); }

	/// General setters
	virtual void SetContractName(const _STL::string& val) { NotImplemented(); }
	virtual void SetBeginDate(const long date) { NotImplemented(); }
	virtual void SetEndDate(const long date) { NotImplemented(); }
	virtual void SetTriParty(const long ident) { NotImplemented(); }
	virtual void SetTriPartyMarginCall(const long ident) { NotImplemented(); }
	virtual void SetComments(const _STL::string& str) { NotImplemented(); }
	virtual void SetCollateralFolio(long folioId) { NotImplemented(); }
	virtual void SetKeepCollatInPricipalFolio(bool collatInPrincipalFolder) { NotImplemented(); }
	virtual void SetDefaultTemplateName(int numLine, const long sicovam) { NotImplemented(); }
	virtual void SetDefaultTemplateModel(int numLine, const _STL::string& str) { NotImplemented(); }
	virtual void SetMarginCallFolio(long folioId) { NotImplemented(); }
	virtual void SetExternalReference(const _STL::string& str) { NotImplemented(); }
	virtual void SetSpecificCounterpartyEntity(const eSpecificCptyEntityPair specificPair, const long counterparty, const long entity) { NotImplemented(); }
	virtual void SetThirdsType(const eAgreementThirdsType thirdsType) { NotImplemented(); }
	virtual void SetThirdsCounterparty(int numLine, const long thirdId) { NotImplemented(); }
	virtual void SetThirdsEntity(int numLine, const long thirdId) { NotImplemented(); }
	virtual void AddNewDefaultTemplate(const long sicovam, const _STL::string& str){ NotImplemented(); }
	virtual void SetTriPartyType(const eAgreementTriPartyType triPartyType) { NotImplemented(); }

	/// Credit Risk getters
	virtual _STL::string GetModel() const { return GetProxy().GetModel(); }
	virtual long GetCurrency() const { return GetProxy().GetCurrency(); }
	virtual long GetPlace() const { return GetProxy().GetPlace(); }
	virtual int GetDefaultSpotForCreditRisk()const { return GetProxy().GetDefaultSpotForCreditRisk(); }
	virtual long GetDefaultSpotTimingForCreditRisk() const { return GetProxy().GetDefaultSpotTimingForCreditRisk(); }
	virtual bool IsGlobalCalculation() const { return GetProxy().IsGlobalCalculation(); }
	virtual eAccruedInterestCommission GetAccruedInterestIncluded() const { return GetProxy().GetAccruedInterestIncluded(); }
	virtual eInverseHaircut GetInverseHaircut(bool useCachedValue = true)const { return GetProxy().GetInverseHaircut(useCachedValue); }
	virtual long GetRatingAgency() const { return GetProxy().GetRatingAgency(); }
	virtual long GetIndicatorSelector() const { return GetProxy().GetIndicatorSelector(); }
	virtual eIMNegotiationType GetIMNegotiationType() const { return GetProxy().GetIMNegotiationType(); }
	virtual _STL::string GetPortfolioBasedIM() const {return GetProxy().GetPortfolioBasedIM(); }
	virtual long GetPortfolioBasedIMSettings() const { return GetProxy().GetPortfolioBasedIMSettings(); }
	virtual double GetPortfolioBasedIMFactor() const {return GetProxy().GetPortfolioBasedIMFactor(); }

	/// Credit Risk setters
	virtual void SetModel(const _STL::string& str) { NotImplemented(); }
	virtual void SetCurrency(const long ccy) { NotImplemented(); }
	virtual void SetPlace(const long val) { NotImplemented(); }
	virtual void SetDefaultSpotForCreditRisk(const int tag) { NotImplemented(); }
	virtual void SetDefaultSpotTimingForCreditRisk(const long val) { NotImplemented(); }
	virtual void SetGlobalCalculation(bool gc) { NotImplemented(); }
	virtual void SetAccruedInterestIncluded(eAccruedInterestCommission val) { NotImplemented(); }
	virtual void SetInverseHaircut(eInverseHaircut val) { NotImplemented(); }
	virtual void SetRatingAgency(long val) { NotImplemented(); }
	virtual void SetIndicatorSelector(long val) { NotImplemented(); }
	virtual void SetIMNegotiationType(long val) { NotImplemented(); }
	virtual void SetPortfolioBasedIM(_STL::string& val) { NotImplemented(); }
	virtual void SetPortfolioBasedIMSettings(long docId) { NotImplemented(); }
	virtual void SetPortfolioBasedIMFactor(double val) { NotImplemented(); }

	/// Margin Call getters
	virtual long GetCashRemunerationLinesNumber() const { return GetProxy().GetCashRemunerationLinesNumber(); }
	virtual long GetCcyCashRemuneration(int numLine) const { return GetProxy().GetCcyCashRemuneration(numLine); }
	virtual long GetRateCashRemuneration(int numLine )const { return GetProxy().GetRateCashRemuneration(numLine); }
	virtual long GetBeginMarginDate(int numLine) const { return GetProxy().GetBeginMarginDate(numLine); }
	virtual double GetShortMargin(int numLine) const { return GetProxy().GetShortMargin(numLine); }
	virtual double GetLongMargin(int numLine) const { return GetProxy().GetLongMargin(numLine); }
	virtual double GetDiscountingSpread(int numLine) const { return GetProxy().GetDiscountingSpread(numLine); }
	virtual double GetRoundedValue(long ccy, double value, double * rounding_ret = NULL, short * type_ret = NULL) const
	{ return GetProxy().GetRoundedValue(ccy, value, rounding_ret, type_ret); }
	virtual double GetCollateralizedPriceRoundedValue(long allotment, long ccy, double value) const
	{ return GetProxy().GetCollateralizedPriceRoundedValue(allotment, ccy, value); }
	virtual _STL::string GetMarginFrequency() const { return GetProxy().GetMarginFrequency(); }
	virtual _STL::string GetRemunerationFrequency() const { return GetProxy().GetRemunerationFrequency(); }
	virtual long GetAutomaticFeeMark() const { return GetProxy().GetAutomaticFeeMark(); }
	virtual bool IsRollingInterest() const { return GetProxy().IsRollingInterest(); }
	virtual long GetSufficiencyLimit() const { return GetProxy().GetSufficiencyLimit(); }
	virtual bool IsDontGenerateAlerts() const { return GetProxy().IsDontGenerateAlerts(); }
	virtual long GetCashSufficiencyLimit() const { return GetProxy().GetCashSufficiencyLimit(); }
	virtual long GetTimeSufficiencyLimit() const { return GetProxy().GetTimeSufficiencyLimit(); }
	virtual bool IsMarkSpot() const { return GetProxy().IsMarkSpot(); }
	virtual long GetDefaultCollateralCashAccCurrency() const { return GetProxy().GetDefaultCollateralCashAccCurrency(); }
	virtual long GetDefaultCollateralCashAccRate() const { return GetProxy().GetDefaultCollateralCashAccRate(); }
	virtual int GetDefaultCollateralCashLine() const { return GetProxy().GetDefaultCollateralCashLine(); }
	virtual long GetMarginCallDefaultRateForCcy(long date, long ccy) const
	{ return GetProxy().GetMarginCallDefaultRateForCcy(date, ccy); }
	virtual eDefaultAcc GetIsCollateralCashLineDefault(int line) const
	{ return GetProxy().GetIsCollateralCashLineDefault(line); }
	virtual bool IsAutomaticFeeding() const { return GetProxy().IsAutomaticFeeding(); }
	virtual bool IsInternalTransfer() const { return GetProxy().IsInternalTransfer(); }
    virtual void GetMarginCallRoundingPrefList(_STL::vector<MarginCallRoundingPref>& list) const {return GetProxy().GetMarginCallRoundingPrefList(list); }

	/// Margin Call setters
	virtual void SetCcyCashRemuneration(int numLine, const long ccy) { NotImplemented(); }
	virtual void SetRateCashRemuneration(int numLine, const long rate) { NotImplemented(); }
	virtual void SetBeginMarginDate(int numLine, const long date) { NotImplemented(); }
	virtual void SetShortMargin(int numLine, const double val) { NotImplemented(); }
	virtual void SetLongMargin(int numLine, const double val) { NotImplemented(); }
	virtual void SetDiscountingSpread(int numLine, const double val) { NotImplemented(); }
	virtual void SetMarginFrequency(const _STL::string& str) { NotImplemented(); }
	virtual void SetRemunerationFrequency(const _STL::string& str) { NotImplemented(); }
	virtual void SetAutomaticFeeMark(const long val) { NotImplemented(); }
	virtual void SetRollingInterest(bool val) { NotImplemented(); }
	virtual void SetSufficiencyLimit(long limit) { NotImplemented(); }
	virtual void SetDontGenerateAlerts(bool val) { NotImplemented(); }
	virtual void SetCashSufficiencyLimit(long limit) { NotImplemented(); }
	virtual void SetTimeSufficiencyLimit(long limit) { NotImplemented(); }
	virtual void SetMarkSpot(bool val) { NotImplemented(); }
	virtual void SetAutomaticFeeding(const bool val) { NotImplemented(); }
	virtual void SetInternalTransfer(bool internalTransfer) { NotImplemented(); }
    virtual void SetMarginCallRoundingPrefList(const _STL::vector<CSRLBAgreement::MarginCallRoundingPref>& list) { NotImplemented(); }

	/// Collateral Stocks getters
	virtual long GetCollateralAllotmentLinesNumber() const { return GetProxy().GetCollateralAllotmentLinesNumber(); }
	virtual long GetCollateralAllotment(int numLine)const { return GetProxy().GetCollateralAllotment(numLine); }
	virtual long GetCollateralAllotmentAutoTicketOffset(int numLine)const
	{ return GetProxy().GetCollateralAllotmentAutoTicketOffset(numLine); }
	virtual long GetCollateralAllotmentCcy(int numLine)const { return GetProxy().GetCollateralAllotmentCcy(numLine); }
	virtual double GetCollateralAllotmentCollateral(int numLine)const
	{ return GetProxy().GetCollateralAllotmentCollateral(numLine); }
	virtual bool GetCollateralAllotmentExcluded(int numLine)const { return GetProxy().GetCollateralAllotmentExcluded(numLine); }
	virtual _STL::string GetCollateralAllotmentCondition1(int numLine) const { return GetProxy().GetCollateralAllotmentCondition1(numLine); }
	virtual _STL::string GetCollateralAllotmentCondition2(int numLine) const { return GetProxy().GetCollateralAllotmentCondition2(numLine); }
	virtual _STL::string GetCollateralAllotmentCondition3(int numLine) const { return GetProxy().GetCollateralAllotmentCondition3(numLine); }
	virtual double GetCollateralAllotmentHaircutInProduct(int numLine, eHairCutType hairCutType)const
	{ return GetProxy().GetCollateralAllotmentHaircutInProduct(numLine, hairCutType); }
	virtual long GetCollateralAllotmentMarket(int numLine)const { return GetProxy().GetCollateralAllotmentMarket(numLine); }
	virtual long GetCollateralAllotmentMaturity(int numLine)const { return GetProxy().GetCollateralAllotmentMaturity(numLine); }
	virtual double GetCashMarginCallHaircutInProduct(int numLine)const
	{ return GetProxy().GetCashMarginCallHaircutInProduct(numLine); }
	virtual long GetCollateralAllotmentSign(int numLine)const { return GetProxy().GetCollateralAllotmentSign(numLine); }
	virtual long GetCollateralAllotmentRating(int numLine)const { return GetProxy().GetCollateralAllotmentRating(numLine); }

	virtual long GetCollateralAllotmentBasketRef(int numLine)const { return GetProxy().GetCollateralAllotmentBasketRef(numLine); }

	/*virtual long GetCollateralIndexBasket(int numLine)const { return GetProxy().GetCollateralIndexBasket(numLine); }
	virtual long GetCollateralIndexBasketLinesNumber() const { return GetProxy().GetCollateralIndexBasketLinesNumber(); }
	virtual long GetCollateralIndexBasketAutoTicketOffset(int numLine) const
	{ return GetProxy().GetCollateralIndexBasketAutoTicketOffset(numLine); } 
	virtual double GetCollateralIndexBasketCollateral(int numLine) const
	{ return GetProxy().GetCollateralIndexBasketCollateral(numLine); } 
	virtual bool GetCollateralIndexBasketExcluded(int numLine) const
	{ return GetProxy().GetCollateralIndexBasketExcluded(numLine); } 
	virtual double GetCollateralIndexBasketHaircutInProduct(int numLine, eHairCutType hairCutType) const
	{ return GetProxy().GetCollateralIndexBasketHaircutInProduct(numLine, hairCutType); } 
	virtual long GetCollateralIndexBasketSign(int numLine) const { return GetProxy().GetCollateralIndexBasketSign(numLine); }*/
	virtual long GetCollateralAllotmentIndustry(int numLine) const { return GetProxy().GetCollateralAllotmentIndustry(numLine); }
	virtual eRehypothecation GetRehypothecation() const { return GetProxy().GetRehypothecation(); }
	virtual _STL::string GetCollateralHaircutMethod() const{return GetProxy().GetCollateralHaircutMethod();}

	/// Collateral Stocks setters
	virtual void SetCollateralAllotment(int numLine, const long val) { NotImplemented(); }
	virtual void SetCollateralAllotmentAutoTicketOffset(int numLine, long val) { NotImplemented(); }
	virtual void SetCollateralAllotmentCcy(int numLine, const long val) { NotImplemented(); }
	virtual void SetCollateralAllotmentCollateral(int numLine, const double val) { NotImplemented(); }
	virtual void SetCollateralAllotmentExcluded(int numLine, bool val) { NotImplemented(); }
	virtual void SetCollateralAllotmentCondition1(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetCollateralAllotmentCondition2(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetCollateralAllotmentCondition3(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetCollateralAllotmentHaircutInProduct(int numLine, const double val) { NotImplemented(); }
	virtual void SetCollateralAllotmentMarket(int numLine, long val) { NotImplemented(); }
	virtual void SetCollateralAllotmentMaturity(int numLine, long val) { NotImplemented(); }
	virtual void SetCashMarginCallHaircutInProduct(int numLine, const double val) { NotImplemented(); }
	virtual void SetCollateralAllotmentSign(int numLine, const long val) { NotImplemented(); }
	virtual void SetCollateralAllotmentRating(int numLine, long val) { NotImplemented(); }

	virtual void SetCollateralAllotmentBasketRef(int numLine, const long val) { NotImplemented(); }

	/*virtual void SetCollateralIndexBasket(int numLine, const long val) { NotImplemented(); }
	virtual void SetCollateralIndexBasketAutoTicketOffset(int numLine, long val) { NotImplemented(); }
	virtual void SetCollateralIndexBasketCollateral(int numLine, const double val) { NotImplemented(); }
	virtual void SetCollateralIndexBasketExcluded(int numLine, bool val) { NotImplemented(); }
	virtual void SetCollateralIndexBasketHaircutInProduct(int numLine, const double val) { NotImplemented(); }
	virtual void SetCollateralIndexBasketSign(int numLine, const long val) { NotImplemented(); }*/
	virtual void SetCollateralAllotmentIndustry(int numLine, long val) { NotImplemented(); }
	virtual void SetRehypothecation(const eRehypothecation val) { NotImplemented(); }
	virtual void SetCollateralHaircutMethod(const _STL::string& implName){ NotImplemented(); }

	/// Principal Stocks getters
	virtual long GetPrincipalAllotmentLinesNumber() const { return GetProxy().GetPrincipalAllotmentLinesNumber(); }
	virtual long GetPrincipalAllotment(int numLine)const { return GetProxy().GetPrincipalAllotment(numLine); };
	virtual long GetPrincipalAllotmentAutoTicketOffset(int numLine)const
	{ return GetProxy().GetPrincipalAllotmentAutoTicketOffset(numLine); };
	virtual long GetPrincipalAllotmentCcy(int numLine)const { return GetProxy().GetPrincipalAllotmentCcy(numLine); }
	virtual bool GetPrincipalAllotmentExcluded(int numLine)const { return GetProxy().GetPrincipalAllotmentExcluded(numLine); }
	virtual _STL::string GetPrincipalAllotmentCondition1(int numLine) const { return GetProxy().GetPrincipalAllotmentCondition1(numLine); }
	virtual _STL::string GetPrincipalAllotmentCondition2(int numLine) const { return GetProxy().GetPrincipalAllotmentCondition2(numLine); }
	virtual _STL::string GetPrincipalAllotmentCondition3(int numLine) const { return GetProxy().GetPrincipalAllotmentCondition3(numLine); }
	virtual long GetPrincipalAllotmentMarket(int numLine)const { return GetProxy().GetPrincipalAllotmentMarket(numLine); }
	virtual double GetPrincipalAllotmentHedgingInProduct(int numLine)const
	{ return GetProxy().GetPrincipalAllotmentHedgingInProduct(numLine); }
	virtual long GetPrincipalAllotmentMaturity(int numLine)const { return GetProxy().GetPrincipalAllotmentMaturity(numLine); }
	virtual long GetPrincipalAllotmentRating(int numLine)const { return GetProxy().GetPrincipalAllotmentRating(numLine); }
	virtual long GetPrincipalAllotmentSign(int numLine)const { return GetProxy().GetPrincipalAllotmentSign(numLine); }
	virtual long GetPrincipalAllotmentUSCptyPaymentOffset(int numLine)const
	{ return GetProxy().GetPrincipalAllotmentUSCptyPaymentOffset(numLine); }

	virtual long GetPrincipalAllotmentBasketRef(int numLine) const { return GetProxy().GetPrincipalAllotmentBasketRef(numLine); }

	/*virtual long GetPrincipalIndexBasket(int numLine) const { return GetProxy().GetPrincipalIndexBasket(numLine); }
	virtual long GetPrincipalIndexBasketLinesNumber()const { return GetProxy().GetPrincipalIndexBasketLinesNumber(); }
	virtual long GetPrincipalIndexBasketAutoTicketOffset(int numLine)const
	{ return GetProxy().GetPrincipalIndexBasketAutoTicketOffset(numLine); }
	virtual bool GetPrincipalIndexBasketExcluded(int numLine)const
	{ return GetProxy().GetPrincipalIndexBasketExcluded(numLine); }
	virtual double GetPrincipalIndexBasketHedgingInProduct(int numLine)const
	{ return GetProxy().GetPrincipalIndexBasketHedgingInProduct(numLine); }
	virtual long GetPrincipalIndexBasketSign(int numLine)const { return GetProxy().GetPrincipalIndexBasketSign(numLine); }
	virtual long GetPrincipalIndexBasketUSCptyPaymentOffset(int numLine)const
	{ return GetProxy().GetPrincipalIndexBasketUSCptyPaymentOffset(numLine); }*/
	virtual double GetPrincipalAllotmentCFDShort(const int &numLine) const
	{ return GetProxy().GetPrincipalAllotmentCFDShort(numLine); }
	virtual double GetPrincipalAllotmentCFDLong(const int &numLine) const
	{ return GetProxy().GetPrincipalAllotmentCFDLong(numLine); }
	virtual double GetPrincipalIMFactorAccrued(const int &numLine) const
	{ return GetProxy().GetPrincipalIMFactorAccrued(numLine); }
	virtual double GetPrincipalIMFactorParity(const int &numLine) const
	{ return GetProxy().GetPrincipalIMFactorParity(numLine); }
	/*virtual double GetPrincipalIndexBasketCFDShort(const int &numLine) const
	{ return GetProxy().GetPrincipalIndexBasketCFDShort(numLine); }
	virtual double GetPrincipalIndexBasketCFDLong(const int &numLine) const
	{ return GetProxy().GetPrincipalIndexBasketCFDLong(numLine); }
	virtual double GetPrincipalIndexBasketIMFactorAccrued(const int &numLine) const
	{ return GetProxy().GetPrincipalIndexBasketIMFactorAccrued(numLine); }
	virtual double GetPrincipalIndexBasketIMFactorParity(const int &numLine) const
	{ return GetProxy().GetPrincipalIndexBasketIMFactorParity(numLine); }*/
	virtual ePartialReturn GetReturnWithInitialValues() const { return GetProxy().GetReturnWithInitialValues(); }
	virtual eSwapType GetSwapType() const { return GetProxy().GetSwapType(); }

	/// Principal Stocks setters
	virtual void SetPrincipalAllotment(int numLine, const long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentAutoTicketOffset(int numLine, long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentCcy(int numLine, const long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentExcluded(int numLine, bool val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentCondition1(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetPrincipalAllotmentCondition2(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetPrincipalAllotmentCondition3(int numLine, _STL::string& condition) { NotImplemented(); }
	virtual void SetPrincipalAllotmentMarket(int numLine, long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentHedgingInProduct(int numLine, const double val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentMaturity(int numLine, long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentRating(int numLine, long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentSign(int numLine, const long val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentUSCptyPaymentOffset(int numLine, const long val) { NotImplemented(); }

	virtual void SetPrincipalAllotmentBasketRef(int numLine, const long val) { NotImplemented(); }

	/*virtual void SetPrincipalIndexBasket(int numLine, const long val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketAutoTicketOffset(int numLine, long val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketExcluded(int numLine, bool val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketHedgingInProduct(int numLine, const double val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketSign(int numLine, const long val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketUSCptyPaymentOffset(int numLine, const long val) { NotImplemented(); }*/
	virtual void SetPrincipalAllotmentCFDShort(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalAllotmentCFDLong(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalIMFactorAccrued(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalIMFactorParity(const int &numLine, const double &val) { NotImplemented(); }
	/*virtual void SetPrincipalIndexBasketCFDShort(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketCFDLong(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketIMFactorAccrued(const int &numLine, const double &val) { NotImplemented(); }
	virtual void SetPrincipalIndexBasketIMFactorParity(const int &numLine, const double &val) { NotImplemented(); }*/
	virtual void SetReturnWithInitialValues(ePartialReturn flag) { NotImplemented(); }
	virtual void SetSwapType(eSwapType flag) { NotImplemented(); }


	//Principal Stock Underlying Allotment Spread Getters

	virtual long GetPrincipalUnderlyingAllotmentLinesNumber() const {return GetProxy().GetPrincipalUnderlyingAllotmentLinesNumber(); }
	virtual long GetPrincipalUnderlyingAllotment(int numLine) const {return GetProxy().GetPrincipalUnderlyingAllotment(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentBasketRef(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentBasketRef(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentCcy(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentCcy(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentSign(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentSign(numLine); }
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition1(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentCondition1(numLine); }
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition2(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentCondition2(numLine); }
	virtual _STL::string GetPrincipalUnderlyingAllotmentCondition3(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentCondition3(numLine); }			
	virtual bool GetPrincipalUnderlyingAllotmentExcluded(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentExcluded(numLine); }	
	virtual long GetPrincipalUnderlyingAllotmentMarket(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentMarket(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentMaturity(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentMaturity(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentRating(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentRating(numLine); }	
	virtual double GetPrincipalUnderlyingAllotmentSpreadShort(const int &numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentSpreadShort(numLine); }
	virtual double GetPrincipalUnderlyingAllotmentSpreadLong(const int &numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentSpreadLong(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentBeginDate(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentBeginDate(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentWrapper(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentWrapper(numLine); }
	virtual long GetPrincipalUnderlyingAllotmentTemplate(int numLine) const{return GetProxy().GetPrincipalUnderlyingAllotmentTemplate(numLine); }

	//Principal Stock Underlying Allotment Spread Setters

	virtual void SetPrincipalUnderlyingAllotment(int numLine, const long val) { NotImplemented(); }	// -1 is <star>, 0 is <reset>
	virtual void SetPrincipalUnderlyingAllotmentBasketRef(int numLine, const long val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentCcy(int numLine, const long val){ NotImplemented(); }	// -1 is <star>, 0 is <reset>
	virtual void SetPrincipalUnderlyingAllotmentSign(int numLine, const long val){ NotImplemented(); }	// -1 is <star>, 0 is <reset>
	virtual void SetPrincipalUnderlyingAllotmentCondition1(int numLine, _STL::string& condition){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentCondition2(int numLine, _STL::string& condition){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentCondition3(int numLine, _STL::string& condition){ NotImplemented(); }	
	virtual void SetPrincipalUnderlyingAllotmentExcluded(int numLine, bool val){ NotImplemented(); }	
	virtual void SetPrincipalUnderlyingAllotmentMarket(int numLine, long val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentMaturity(int numLine, long val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentRating(int numLine, long val){ NotImplemented(); }	
	virtual void SetPrincipalUnderlyingAllotmentSpreadShort(const int &numLine, const double &val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentSpreadLong(const int &numLine, const double &val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentBeginDate(int numLine, long val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentWrapper(int numLine, long val){ NotImplemented(); }
	virtual void SetPrincipalUnderlyingAllotmentTemplate(int numLine, long val){ NotImplemented(); }

	/// Fees And Interest getters
	virtual long  GetCommissionPaymentOffset() const { return GetProxy().GetCommissionPaymentOffset(); }
	virtual _STL::string GetFeeMarkFrequency() const { return GetProxy().GetFeeMarkFrequency(); }
	virtual eIMNegotiationType GetFeeMarkNegotiationType() const { return GetProxy().GetFeeMarkNegotiationType(); }
	virtual eFeeMarkCurrency GetFeeMarkCurrency() const { return GetProxy().GetFeeMarkCurrency(); }
	virtual int GetDefaultSpotForFeesBilling() const { return GetProxy().GetDefaultSpotForFeesBilling(); }
	virtual long  GetDefaultSpotTimingForFeesBilling() const { return GetProxy().GetDefaultSpotTimingForFeesBilling(); }
	virtual long  GetCommissionAccrualCalculationMethod() const { return GetProxy().GetCommissionAccrualCalculationMethod(); }
	virtual long  GetCommissionDayAfterOffset() const { return GetProxy().GetCommissionDayAfterOffset(); }
	virtual long  GetCouponPaymentOffset() const { return GetProxy().GetCouponPaymentOffset(); }
	virtual long  GetCouponAccrualCalculationMethod() const { return GetProxy().GetCouponAccrualCalculationMethod(); }
	virtual long  GetCouponDayAfterOffset() const { return GetProxy().GetCouponDayAfterOffset(); }
	virtual long GetFeesPartialReturn() const { return GetProxy().GetFeesPartialReturn(); }
	virtual long GetCommissionAmountType() const { return GetProxy().GetCommissionAmountType(); }
	virtual long GetFeesRepricing() const { return GetProxy().GetFeesRepricing(); }
	virtual eFeesRoundingLevel GetCommissionRoundingLevel(long ccy) const { return GetProxy().GetCommissionRoundingLevel(ccy); }
	virtual double GetCommissionRoundedValue(long ccy, double val, short* roundingType = 0, double* roundingValue = 0) const { return GetProxy().GetCommissionRoundedValue(ccy, val, roundingType, roundingValue); }
	virtual eFeesRoundingLevel GetCouponRoundingLevel(long ccy) const { return GetProxy().GetCouponRoundingLevel(ccy); }
	virtual double GetCouponRoundedValue(long ccy, double val, short* roundingType = 0, double* roundingValue = 0) const { return GetProxy().GetCouponRoundedValue(ccy, val, roundingType, roundingValue); }

	/// Fees And Interest setters
	virtual void SetCommissionPaymentOffset(const long val) { NotImplemented(); }
	virtual void SetFeeMarkFrequency(const _STL::string& str) { NotImplemented(); }
	virtual void SetFeeMarkNegotiationType(long val) { NotImplemented(); }
	virtual void SetFeeMarkCurrency(eFeeMarkCurrency val) { NotImplemented(); }
	virtual void SetDefaultSpotForFeesBilling(const int tag) { NotImplemented(); }
	virtual void SetDefaultSpotTimingForFeesBilling(const long val) { NotImplemented(); }
	virtual void SetCommissionAccrualCalculationMethod(const long val) { NotImplemented(); }
	virtual void SetCommissionDayAfterOffset(const long val) { NotImplemented(); }
	virtual void SetCouponPaymentOffset(const long val) { NotImplemented(); }
	virtual void SetCouponAccrualCalculationMethod(const long val) { NotImplemented(); }
	virtual void SetCouponDayAfterOffset(const long val) { NotImplemented(); }
	virtual void SetFeesPartialReturn(const long type) { NotImplemented(); }
	virtual void SetCommissionAmountType(const long type) { NotImplemented(); }
	virtual void SetFeesRepricing(const long type) { NotImplemented(); }

	/// Collateral Call getters
	virtual long GetCollateralCallTemplate() const { return GetProxy().GetCollateralCallTemplate(); }
	virtual long GetCollateralCallCcy() const { return GetProxy().GetCollateralCallCcy(); }
	virtual long GetCollateralSubstitutionTemplate() const { return GetProxy().GetCollateralSubstitutionTemplate(); }
	virtual long GetMakeSubstitutionNoticePeriod() const { return GetProxy().GetMakeSubstitutionNoticePeriod(); }

	/// Collateral Call setters
	virtual void SetCollateralCallTemplate(const long val) { NotImplemented(); }
	virtual void SetCollateralCallCcy(const long val) { NotImplemented(); }
	virtual void SetCollateralSubstitutionTemplate(const long val) { NotImplemented(); }
	virtual void SetMakeSubstitutionNoticePeriod(const long period) { NotImplemented(); }

	/// CFD getters
	virtual long GetCFDReportingType() const { return GetProxy().GetCFDReportingType(); }
	virtual long GetCFDBuySellSide() const { return GetProxy().GetCFDBuySellSide(); }
	virtual long GetCFDDividendDateType() const { return GetProxy().GetCFDDividendDateType(); }
	virtual long GetCFDDividendRebateCountryId(const int line) const
	{ return GetProxy().GetCFDDividendRebateCountryId(line); }
	virtual double GetCFDDividendRebateShort(const int line) const { return GetProxy().GetCFDDividendRebateShort(line); }
	virtual double GetCFDDividendRebateLong(const int line) const { return GetProxy().GetCFDDividendRebateLong(line); }
	virtual long GetCFDCountryAndDividentRebateNumber()const { return GetProxy().GetCFDCountryAndDividentRebateNumber(); }
	virtual long GetCFDFreeCashFolio() const { return GetProxy().GetCFDFreeCashFolio(); }
	virtual _STL::string GetCFDFreeCashFrequency() const { return GetProxy().GetCFDFreeCashFrequency(); }
	virtual double GetCFDFreeCashFloatRateSpreadLong() const { return GetProxy().GetCFDFreeCashFloatRateSpreadLong(); }
	virtual double GetCFDFreeCashFloatRateSpreadShort() const { return GetProxy().GetCFDFreeCashFloatRateSpreadShort(); }
	virtual double GetCFDFreeCashExpThreshold() const { return GetProxy().GetCFDFreeCashExpThreshold(); }
	virtual eCFDFreeCashRate GetCFDFreeCashRateType() const { return GetProxy().GetCFDFreeCashRateType(); }
	virtual double GetCFDFreeCashFixedRate() const { return GetProxy().GetCFDFreeCashFixedRate(); }
	virtual long GetCFDFreeCashFloatRate() const { return GetProxy().GetCFDFreeCashFloatRate(); }
	virtual bool GetCFDCashpoolRateNoSpread() const { return GetProxy().GetCFDCashpoolRateNoSpread(); }
	virtual eCFDNotionalCalculationType GetCFDNotionalCalculationType() const { return GetProxy().GetCFDNotionalCalculationType(); }
	virtual long GetCFDSpreadLinesNumber() const { return GetProxy().GetCFDSpreadLinesNumber(); }
	virtual long GetRateCFDSpread(int numLine) const { return GetProxy().GetRateCFDSpread(numLine); }
	virtual _STL::string GetPayFrequencyCFDSpread(int numLine) const { return GetProxy().GetPayFrequencyCFDSpread(numLine); }
	virtual long GetBeginDateCFDSpread(int numLine) const { return GetProxy().GetBeginDateCFDSpread(numLine); }
	virtual double GetLongCFDSpread(int numLine) const { return GetProxy().GetLongCFDSpread(numLine); }
	virtual double GetShortCFDSpread(int numLine) const { return GetProxy().GetShortCFDSpread(numLine); }

	/// CFD setters
	virtual void SetCFDReportingType(const long &val) { NotImplemented(); }
	virtual void SetCFDBuySellSide(const long &val) { NotImplemented(); }
	virtual void SetCFDDividendDateType(const long &val) { NotImplemented(); }
	virtual void SetCFDDividendRebateCountryId(const int numLine, const long val) { NotImplemented(); }
	virtual void SetCFDDividendRebateShort(const int numLine, const double val) { NotImplemented(); }
	virtual void SetCFDDividendRebateLong(const int numLine, const double val) { NotImplemented(); }
	virtual void SetCFDFreeCashFolio(long folioId) { NotImplemented(); }
	virtual void SetCFDFreeCashFrequency(const _STL::string& str) { NotImplemented(); }
	virtual void SetCFDFreeCashFloatRateSpreadLong(double limit) { NotImplemented(); }
	virtual void SetCFDFreeCashFloatRateSpreadShort(double limit) { NotImplemented(); }
	virtual void SetCFDFreeCashExpThreshold(double exp) { NotImplemented(); }
	virtual void SetCFDFreeCashRateType(eCFDFreeCashRate type) { NotImplemented(); }
	virtual void SetCFDFreeCashFixedRate(double rate) { NotImplemented(); }
	virtual void SetCFDFreeCashFloatRate(long rate) { NotImplemented(); }
	virtual void SetCFDCashpoolRateNoSpread(bool val) { NotImplemented(); }
	virtual void SetCFDNotionalCalculationType(eCFDNotionalCalculationType type) { NotImplemented(); }
	virtual void SetRateCFDSpread(int numLine, const long rate) { NotImplemented(); }
	virtual void SetPayFrequencyCFDSpread(int numLine, const _STL::string& str) { NotImplemented(); }
	virtual void SetBeginDateCFDSpread(int numLine, const long date) { NotImplemented(); }
	virtual void SetLongCFDSpread(int numLine, const double val) { NotImplemented(); }
	virtual void SetShortCFDSpread(int numLine, const double val) { NotImplemented(); }

	/// Threshold getters
	virtual double GetThreshold(double netExposure, double mtmExposure) const
	{ return GetProxy().GetThreshold(netExposure, mtmExposure); }
	virtual eThresholdType GetThresholdType() const { return GetProxy().GetThresholdType(); }
	virtual long GetEntityMinLimit(int numLine) const { return GetProxy().GetEntityMinLimit(numLine); }
	virtual long GetCounterpartyMinLimit(int numLine) const { return GetProxy().GetCounterpartyMinLimit(numLine); }
	virtual double GetEntityThreshold(int numLine) const { return GetProxy().GetEntityThreshold(numLine); }
	virtual double GetCounterpartyThreshold(int numLine) const { return GetProxy().GetCounterpartyThreshold(numLine); }
	virtual long GetThresholdRatingAgency() const { return GetProxy().GetThresholdRatingAgency(); }
	virtual long GetThresholdRatingSeniority() const { return GetProxy().GetThresholdRatingSeniority(); }

	/// Threshold setters
	virtual void SetThresholdType(const eThresholdType val) { NotImplemented(); }
	virtual void SetEntityMinLimit(int numLine, const long val) { NotImplemented(); }
	virtual void SetCounterpartyMinLimit(int numLine, const long val) { NotImplemented(); }
	virtual void SetEntityThreshold(int numLine, const double val) { NotImplemented(); }
	virtual void SetCounterpartyThreshold(int numLine, const double val) { NotImplemented(); }
	virtual void SetThresholdRatingAgency(const long val) { NotImplemented(); }
	virtual void SetThresholdRatingSeniority(const long val) { NotImplemented(); }

	/// Agreement Properties
	virtual long GetAgreementPropertiesLinesNumber() const { return GetProxy().GetAgreementPropertiesLinesNumber(); }
	virtual _STL::string GetAgreementPropertiesName(int numLine) const { return GetProxy().GetAgreementPropertiesName(numLine); }
	virtual void SetAgreementPropertiesName(int numLine, const _STL::string& propertyName) { NotImplemented(); }
	virtual _STL::string GetAgreementPropertiesValue(int numLine) const { return GetProxy().GetAgreementPropertiesValue(numLine); }
	virtual void SetAgreementPropertiesValue(int numLine, const _STL::string& propertyValue) { NotImplemented(); }

	virtual const CSRCollateralAgreementCustomData* GetCustomData() const { return GetProxy().GetCustomData(); }
};

	} // collateral
} // sophis

SPH_EPILOG
#endif // _CSRLBAgreementProxyProxy_H_
