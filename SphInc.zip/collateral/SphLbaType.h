#ifndef _SPH_LBA_TYPE_H_
#define _SPH_LBA_TYPE_H_

struct TSaveData; // internal

#include "SphInc/SphMacros.h"
#include "SphInc/instrument/SphLoanAndRepo.h"

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRLoanAndRepo;
	}

	namespace collateral {

		/**
		 * Defines valid stock loan types supported by advanced stock loan module.
		 * @since 5.1
		 */
		class CSRLbaType
		{
		public:

			/**
			 * Stock loan types supported by advanced stock loan module.
			 * Please note that eSecMarginCall is not a contract, but rather a special type.
			 */
			enum eLbaType
			{
				eUndefined,
				eSecVsCashContract,
				eCashVsSecContract,
				eCashVsNoCollateralContract,
				eSecVsSecContract,
				eSecVsCashPool,
				eCashVsSecPool,
				eSecVsSecPool,
				eSecNoCollateral,
				eSecMarginCall,
				eSecVsTriParty,
				eCashVsTriParty,
				/** @version 5.3.6.5, to support Cash vs Dedicated Security Pool */
				eCashVsSecPoolContract,
				eStockVsSecPoolContract,
				eMaxLbaType,
			};

			/**
			 * Returns stock loan contract type for given stock loan instrument id.
			 * @return stock loan type or <code>eUndefined</code> if stock loan
			 * information is incorrect/missing.
			 * @param stockLoanId Code (sicovam) of the stock loan instrument.
			 */
			static SOPHIS_FIT eLbaType GetLbaType(long stockLoanId);

			/**
			 * Returns stock loan contract type for given stock loan instrument.
			 * @return stock loan type or <code>eUndefined</code> if stock loan
			 * information is incorrect/missing.
			 * @param loan Stock Loan instrument.
			 */
			static SOPHIS_FIT eLbaType GetLbaType(const instrument::CSRLoanAndRepo *loan);

			/**
			 * Checks to see if given type is a Repo Cash type.
			 * @version 5.3
			 */
			static SOPHIS_FIT bool IsRepoCash(int type);

			/**
			 * Internal.
			 * @version 5.3
			 */
			static SOPHIS_FIT eLbaType GetLbaType(const TSaveData *pe);

			/**
			 * Internal.
			 * @version 6.2
			 */
			static SOPHIS_FIT eLbaType GetLbaType(char type, instrument::eStockLoanPricingType stockLoanPricingType, instrument::eCollateralType collateralType, const char* model);

			/**
			 * Checks to see if given type is a Contract Type.
			 * For the moment, all valid types except eSecMarginCall are considered Contract Types.
			 * @version 5.3
			 */
			static SOPHIS_FIT bool IsAContract(int type);

			/**
			 * Checks to see if given type involves cash transfer.
			 * All "repo cash" and stock loans with cash collateral (including eSecVsSecContract).
			 * @version 5.3.4
			 */
			static SOPHIS_FIT bool HasCash(int type);

			/**
			 * Returns string representation of given stock loan contract type
			 * or empty string if it is not a valid type.
			 * @version 5.3.6
			 */
			static SOPHIS_FIT const char * ToString(int type);

		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
