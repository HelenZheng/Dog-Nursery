#ifndef _SphCollateralLimitReportingAPI_H_
#define _SphCollateralLimitReportingAPI_H_

#include "SphInc/collateral/SphCollateralReportingAPI.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis {

	namespace collateral {
		class CSRLBAgreement;
		class CSRCollateralLimitResult;

		/**
		 * Bit flags used to control the behavior and output of detailed collateral limit calculation API.
		 * Custom (user-defined) flags should start from 0x10000.
		 * @version 5.2.7
		 */
		enum eLimitReportingAPIFlags
		{
			/**
			 * Minimum reporting results, no explanations.
			 */
			eLRFMinimum = 0x00,

			/**
			 * Compute cash interest explanation for cash collateral.
			 */
			eLRFComputeCashInterest = 0x01,

			/**
			 * To include empty cash and securities collateral section even if 
			 * there is no collateral.
			 * Useful if using this API for data display in GUI mode.
			 */
			eLRFAllowEmptyPools = 0x02,

			/**
			 * All settings required for common GUI display of the API results.
			 */
			eLRFCommonGui = (eLRFComputeCashInterest | eLRFAllowEmptyPools),

		};

		/**
		 * API for building and handling detailed collateral limit calculation results.
		 * @version 5.2.7
		 */
		class SOPHIS_COLLATERAL CSRCollateralLimitReportingAPI : public virtual ISRCollateralReportingAPI
		{
		public:

			/**
			 * Creates an API.
			 */
			CSRCollateralLimitReportingAPI();

			/**
			 * Destructor.
			 * Deletes all internal results.
			 */
			virtual ~CSRCollateralLimitReportingAPI();

			/**
			 * Builds a complete result hierarchy of all relevant contracts and collateral
			 * related to the given collateral agreement.
			 * @param lba Collateral Agreement to which deals must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeAll(const CSRLBAgreement *lba, long calculationDate, long crfFlags);

			/**
			 * Builds a complete result hierarchy of all relevant contracts and collateral
			 * related to the given collateral agreement specified as cpty/entity/convention.
			 * The values of cpty/entity/convention MUST point to a valid Collateral Agreement.
			 * @param cpty Counterparty of Collateral Agreement to which deals must belong (map) to.
			 * @param entity Entity of Collateral Agreement to which deals must belong (map) to.
			 * @param convention Convention of Collateral Agreement to which deal's instrument must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param extraParams Pointer to structure containing extra reporting parameters.
			 * @version 5.3.2
			 */
			virtual void ComputeAll(long cpty, long entity, long convention, long calculationDate, SReportingParameters *extraParams = 0);

			/**
			 * Builds a result for a given position.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param mvtident Position Id (mvtident).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeOne(const CSRLBAgreement *lba, long calculationDate, sophis::portfolio::PositionIdent mvtident, long crfFlags);

			/**
			 * {@link ISRCollateralReportingAPI::GetResult}.
			 * Calls GetLimitResult().
			 */
			virtual const CSRCollateralResult* GetResult() const;

			/**
			 * Builds a dummy (blank) result tree that can be used to generate an XSD description.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeDummy(const CSRLBAgreement *lba, long crfFlags = eLRFCommonGui);

			/**
			 * Returns the result pointer which must not be deleted.
			 */
			const CSRCollateralLimitResult* GetCollateralLimitResult() const;

			/**
			 * Returns calculation date as used for the result computation.
			 */
			long GetCalculationDate() const
			{
				return fCalculationDate;
			}

			typedef _STL::list<CSRCollateralResult *> LimitResultList;
			/**
			 * Returns Flat results
			*/
			LimitResultList& GetFlatResults(){return fList; }

		protected:
			CSRCollateralLimitResult *fResult;
			long fCalculationDate;
			LimitResultList fList;

		private:
			static const char *__CLASS__;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphCollateralLimitReportingAPI_H_
