#ifndef _SphCollateralLimitResultColumn_H_
#define _SphCollateralLimitResultColumn_H_

#include "SphInc/Collateral/SphCollateralResultColumn.h"

#define DECLARATION_LIMIT_RESULT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralResultColumn)
#define CONSTRUCTOR_LIMIT_RESULT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_LIMIT_RESULT_COLUMN(derivedClass)
#define	INITIALISE_LIMIT_RESULT_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRCollateralLimitResult;

/**
 * Interface to handle columns in Detailed Collateral Limits Calculation GUI.
 * To add a column, derive this class, using the macro DECLARATION_LIMIT_RESULT_COLUMN in your header
 * and INITIALISE_LIMIT_RESULT_COLUMN in UNIVERSAL_MAIN.
 *
 * @version 5.2.7
 */
class SOPHIS_COLLATERAL CSRCollateralLimitResultColumn : public virtual CSRCollateralResultColumn
{
public:
	CSRCollateralLimitResultColumn();

	/**
	 * {@link CSRCollateralResultColumn::GetCell}
	 * Invokes GetCollateralLimitCell().
	 */
	virtual	void GetCell(const CSRCollateralReportContext &ctx, const CSRCollateralResult &result, SSCellValue *value, SSCellStyle *style) const;

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param result Detailed Collateral Limits Calculation result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCollateralLimitCell(const CSRCollateralReportContext &ctx, const CSRCollateralLimitResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_LIMIT_RESULT_COLUMN
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
