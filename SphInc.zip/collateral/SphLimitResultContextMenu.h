#ifndef _SphLimitResultContextMenu_H_
#define _SphLimitResultContextMenu_H_

#include "SphInc/Collateral/SphCollateralResultContextMenu.h"

SPH_PROLOG
namespace sophis {

	namespace collateral {

		class CSRCollateralLimitResult;
		class CSRLBAgreement;

/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_LIMIT_RESULT_CONTEXT_MENU(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRLimitResultContextMenu)
#define CONSTRUCTOR_LIMIT_RESULT_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_LIMIT_RESULT_CONTEXT_MENU(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRLimitResultContextMenu::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_LIMIT_RESULT_CONTEXT_MENU(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass, name); \
	derivedClass::GetPrototype().GetData(name)->SetId(++sophis::collateral::CSRLimitResultContextMenu::fCount);


/**
 * Interface for creating custom context menu (explanation) dialogs in Detailed Collateral Limits Calculation GUI.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 5.2.7
 */
class SOPHIS_COLLATERAL_GUI CSRLimitResultContextMenu : public virtual CSRCollateralResultContextMenu
{
public:
	/** 
	 * {@link CSRCollateralResultContextMenu::IsAuthorized}
	 */
	virtual bool IsCollateralLimitResultAuthorized(const CSRCollateralReportContext &ctx, const CSRCollateralLimitResult& line) const = 0;

	/**
	 * {@link CSRCollateralResultContextMenu::DoCollateralResultContextMenu}
	 */
	virtual bool DoCollateralLimitResultContextMenu(const CSRCollateralReportContext &ctx, const CSRCollateralLimitResult& line) const = 0;

	/** 
	* {@link CSRCollateralResultContextMenu::IsEnabled}
	*/
	virtual bool IsCollateralLimitResultEnabled(const CSRCollateralReportContext &ctx, const CSRCollateralLimitResult& line) const { return true; }

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_LIMIT_RESULT_CONTEXT_MENU.
	 * {@link tools::CSRPrototype}
	 */
	static prototype& GetPrototype();

	/**
	 * Counts the number of prototypes installed and assigns each prototype a number in sequence.
	 * For internal use.
	 */
	static long fCount;

	/**
	 * Invokes IsCollateralLimitResultAuthorized().
	 */
	virtual bool IsAuthorized(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;

	/**
	 * Invokes DoCollateralLimitResultContextMenu().
	 */
	virtual bool DoCollateralResultContextMenu(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;

	/**
	* Invokes IsCollateralLimitResultEnabled().
	*/
	virtual bool IsEnabled(const CSRCollateralReportContext &ctx, const CSRCollateralResult& line) const;

};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphLimitResultContextMenu_H_
