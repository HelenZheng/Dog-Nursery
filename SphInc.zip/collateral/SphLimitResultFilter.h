#pragma once

#ifndef _SphLimitResultFilter_H_
#define _SphLimitResultFilter_H_

#include "SphInc/SphMacros.h"
#include "SphInc/Collateral/SphCollateralResultFilter.h"


SPH_PROLOG
namespace sophis {

	namespace collateral {

// forward declaration
class CSRCollateralLimitResult;

/**
 * Macros for handling Detailed Collateral Limits GUI filtering implementation and prototype.
 * @version 5.3.6
 * @version 6.2.2
 */
#define DECLARATION_LIMIT_RESULT_FILTER(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRLimitResultFilter)
#define CONSTRUCTOR_LIMIT_RESULT_FILTER(derivedClass)
#define WITHOUT_CONSTRUCTOR_LIMIT_RESULT_FILTER(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRLimitResultFilter::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_LIMIT_RESULT_FILTER(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass, name) \
	derivedClass::GetPrototype().GetData(name)->SetId(++sophis::collateral::CSRLimitResultFilter::fCount)

/**
 * Interface for creating custom filters in the Detailed Collateral Limits GUI.
 * The key string of the derived element is displayed in the menu.
 *
 * Derived classes must implement IsLimitResultExcluded()
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 *
 * @version 5.3.6
 * @version 6.2.2
 */
class SOPHIS_COLLATERAL_GUI CSRLimitResultFilter : public virtual CSRCollateralResultFilter
{
public:

	/** 
	 * Check if given result object should be displayed or not.
	 * Must be implemented in derived classes.
	 * @param mgr Window manager.
	 * @param result Result object to be or not to be displayed on the ui.
	 * @return true to hide from display; false to do nothing (keep).
	 */
	virtual bool IsLimitResultExcluded(const ISRCollateralResultFilterManager& mgr, const CSRCollateralLimitResult & result) const = 0;

	/// See {@link CSRCollateralResultFilter::IsExcluded}, redirects calls to IsLimitResultExcluded
	virtual bool IsExcluded(const ISRCollateralResultFilterManager& mgr, const CSRCollateralResult & result) const;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_LIMIT_RESULT_FILTER.
	 * {@link tools::CSRPrototype}
	 */
	static prototype& GetPrototype();

	/**
	 * Counts the number of prototypes installed and assigns each prototype a number in sequence.
	 * For internal use.
	 */
	static long fCount;
};

	} // namespace collateral
} // namespace sophis


SPH_EPILOG

#endif // _SphLimitResultFilter_H_
