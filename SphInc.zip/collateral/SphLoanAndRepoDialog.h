/*
File:		SphLoanAndRepoDialog.h

Contains:	Handle a dialog for purchasing of loan or repo.
Copyright:	� 1995-2006 Sophis.

*/

/*! \file SphLoanAndRepoDialog.h
\brief Handle a dialog for purchasing of loan or repo.
*/

#pragma once

#ifndef _SphLoanAndRepoDialog_H_
#define _SphLoanAndRepoDialog_H_

#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphTransactionDialog.h"
#include "SphInc/collateral/SphStockOnLoanEnums.h"
#include "SphInc/instrument/SphLoanAndRepo.h"

SPH_PROLOG

struct TSaveData;
struct TDataMvts;
class TPETitre;
struct TAchatPE;

namespace sophis {
	namespace instrument	{
		class CSRLoanAndRepo;
	}
	namespace portfolio	{
		class CSRTransaction;
	}
	namespace tools {
		class CSREventVector;
	}

	
	
	const int	kAdvancedLoanAndRepoDialogId=189;

	

	namespace collateral {
		/** 
		@since 5.1.1
		*/
		enum eDealDirection
		{
			eLend	=1,
			eBorrow
		};

		/** Dialog to book a stock loan.
		Overload that class to modify this dialog using INITIALISE_DIALOG macro.
		@since 5.1.1
		*/
		class  SOPHIS_COLLATERAL CSRLoanAndRepoDialog : public sophis::gui::CSRTransactionDialog
		{
		public:

			CSRLoanAndRepoDialog();

			/** Get the stock loan instrument. The low level structure (DInfosPret) is not duplicated. 
			The returned instrument gives access to the dialog data, so a set methode will modify the data. 
			It is not exactly the instrument that will be saved. 
			If one want to modify the saved instrument it can be done in 'OnCreateInstrument'.
			@return a pointer which must be deleted.
			*/
			instrument::CSRLoanAndRepo	*new_CSRInstrument() const;

			/** Get a copy of the collateral instrument. The low level structure (DInfosPret) is duplicated. 
			This method DOES NOT give access to the dialog data, 
			so a set methode will not modify the collateral instrument. 
			If one want to modify the saved collateral instrument,
			it can be done in 'OnCreateCollateralInstrument'.
			@return a pointer which may be null if there is no repo per contract and which must be deleted. 
		    */
			instrument::CSRLoanAndRepo	*new_CSRCollateralInstrument() const;

			/** Get the transaction. Low level structure (TMvt) is not duplicated. 
			The returned instrument gives access to the dialog data, 
			so a set method will not modify the data. 
			It is not exactly the transaction that will be saved. 
			If one want to modify the saved transaction it can be done in 'OnCreateTransaction'.
			@return a pointer which must be deleted.
			*/
			portfolio::CSRTransaction	*new_CSRTransaction() const;

			/** Get the collateral transaction. Low level structure (TMvt)is duplicated. 
			This method DOES NOT give access to the dialog data, 
			so a set method will not modify it. 
			If one want to modify the saved collateral transaction,
			it can be done in 'OnCreateCollateralTransaction'.
			@return a pointer which may be null if no repo per contract and which must be deleted.
			*/
			portfolio::CSRTransaction	*new_CSRCollateralTransaction() const;

			/** Called to find if an instrument like.
			@return an instrument id ; 0 if not found.
			*/
			virtual long CheckForExistingInstrument() const;

			/** Called to find if an instrument like for collateral.
			@return an instrument id ; 0 if not found.
			*/
			virtual long CheckForExistingCollateralInstrument() const;

			/** Called before the instrument is created.
			@param loan the instrument created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateLoanAndRepo(sophis::instrument::CSRLoanAndRepo& loan, sophis::tools::CSREventVector &messages);

			/** Called before the collateral instrument is created.
			@param collateral the collateral instrument created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateCollateral(sophis::instrument::CSRLoanAndRepo& collateral, sophis::tools::CSREventVector &messages);

			/** Called before the transaction is created.
			@param transaction the transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateTransaction(portfolio::CSRTransaction& transaction, sophis::tools::CSREventVector &messages);

			/** Called before the collateral transaction is created.
			@param collateral_transaction the collateral transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnCreateCollateralTransaction(portfolio::CSRTransaction& collateral_transaction, sophis::tools::CSREventVector &messages);
			
			/** Called before the transaction is created.
			@param transaction the transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnModifyTransaction(portfolio::CSRTransaction& transaction, sophis::tools::CSREventVector &messages);

			/** Called before the collateral transaction is created.
			@param collateral_transaction the collateral transaction created.
			@param messages is a list of events to add your own messages.
			*/
			virtual void OnModifyCollateralTransaction(portfolio::CSRTransaction& collateral_transaction, sophis::tools::CSREventVector &messages);

			/** Returns type of modification (creation, modification) for which dialog is open.
			 * @version 5.3.6
			 */
			eModifiedStockLoanTemplate GetModificationType() const;

		protected:
			/** Modify the instrument type of the dialog.
			@param loanType is the type of the instrument.
			*/
			void SetType(instrument::eLoanAndRepoType loanType);
			
			/** Modify the instrument type of the dialog.
			@param loanType is the type of the instrument.
			*/
			eDealDirection GetDealDirection();

			/** Modify the instrument type of the dialog.
			@param loanType is the type of the instrument.
			*/
			void SetDealDirection(eDealDirection achatType);

		private:

			// for log purpose
			static const char * __CLASS__;

			/** For internal use.
			@return the TPETitre contained by the dialog that must not be deleted.
			*/
			TPETitre* GetInstrumentData() const;

			/** For internal use.
			@return the TDataMvts contained by the dialog that must not be deleted..
			*/
			TDataMvts* GetTransactionData() const;

			/** For internal use.
			@return the TAchatPE contained by the dialog that must not be deleted..
			*/
			TAchatPE* GetData() const;

			/** For internal use.
			Get cloned data that represent the collateral instrument.
			@param collatData: data filled by cloned data from the GUI.
			@return false if collatData does not exist. 
			*/
			bool GetCollateralInstrumentData(TSaveData& collatData) const;

			/** For internal use.
			Check if the transaction is a double booking transaction (i.e. with a collateral).
			@return true if the deal contains a double booking.
			*/
			bool IsDoubleBooking() const;

		};

		/**
		 * Utility class used for obtaining the list of modifiable elements of the Stock Loan/Repo instrument dialog.
		 * @version 7.1.2
		 */
		class SOPHIS_COLLATERAL CSRStockLoanModifiableFields
		{
		public:

			/**
			 * Registers the list of modifiable elements in the Stock Loan/Repo instrument dialog.
			 * Note that the vector content will have the default elements by default.
			 * If all elements shall be disabled, an empty vector should be registered.
			 * @param modifiableFields list of elements id which are modifiable to be registered.
			 * @version 7.1.2
			 */
			static void SetModifiableFields(const _STL::vector<int>& modifiableFields);

			/**
			 * Returns the list of modifiable elements in the Stock Loan/Repo instrument dialog.
			 * If nothing has been registered, it will return the default list of elements.
			 * Note if use desires to disable all elements, an empty vector is necessary to be registered (see SetModifiableFields).
			 * @param modifiableFields output copy of the modifiable fields.
			 * @version 7.1.2
			 */
			static void GetModifiableFields(_STL::vector<int>& modifiableFields);
		};

		/** Enumeration of the elements contained in the dialog "AdvancedLoanAndRepoDialog". 
		See SphStockOnLoanEnums.h
		*/
		/*
		enum ePEItem{
			ePECours			= 6,
			ePEQuantite,
			ePEFolio			= 31,
			ePENegociation		= 43,
			ePECommentaire,
			ePEHeure,
			ePEInfosBack,
			ePEFraisMarche,
			ePEFraisCourtier	= 53,
			ePEFictif			= 96,
			ePESMDT,
			ePEMontantMinimum	= 63,
			ePECourtier			= 66,
			ePEBackOffice,
			ePEOperateur,
			ePEMontantColLib	= 71,
			ePEContrepartie,
			ePEMontantLib,
			ePEValeur,
			ePEDepositaire,
			ePEAnnuler,
			ePETypeOperation	= 89,
			ePEEntite			= 162,
			ePEContrepartie2Lib,
			ePEEntiteLib,
			ePEContrepartie2,
			ePEKernelEvent1		= 166,
			ePEKernelEvent2,
			ePEKernelEvent3,
			ePEKernelEvent4,
			ePEUndCcyPriceLib	= 180,
			ePECollCcyPriceLib,
			ePEKernelWFName		= 204,
			ePEFraisCounterparty,
		};

		enum ePEItem2{
			ePEReference		= 1,
			ePELibelle,
			ePEReferenceSJ,
			ePECoursSJ,
			ePELibelleSJ,
			ePESurcharge		= 8,
			//ePEAppelMarge,
			ePETypeBaseLib,
			ePETypeLivraison,       //10
			ePETypeCommission,
			ePEValeurCommission,
			ePETypeBase,
			ePEMontantMin,
			ePETypePreavis,
			ePENbJours,
			ePEExercice,
			ePETypeCollateral,
			ePEReferenceAction,
			ePEHedging,			// 20
			ePETaux,
			ePEValeurTaux,
			ePEDevise,
			ePEReferenceActionLib,
			ePEDebut,
			ePEFin,
			ePETypePret,
			ePETauxDistribue,
			ePEPaye,
			ePEValeurTheo		= 32,
			ePECommissionLib,
			ePEMontantMinLib,
			ePENbJoursLib,
			ePEExerciceLib,			
			ePEHedgingLib,
			ePETauxLib,		
			ePEDeviseLib,
			ePECoursSJLib,
			ePETypePaiement,
			ePEModele,
			ePEDateDivid		= 48,
			ePEReescompte,
			ePEPayeLib,		
			ePETauxDistribLib,
			ePEValeurDivid,
			ePEValeurDividLib	= 54,
			ePERemarque,
			ePEDateDividLib,
			ePECallableTypeLib = 58,
			ePEDeliveryLib = 63,
			ePEUnderlyingNameLib,
			ePENumberOfSecurities = 69,
			ePEConvention		= 85,
			ePENumberOfShares	= 98,
			ePEBillingCurrencyLib,
			ePEHairCut,
			//ePEBasket,
			ePEInterestRateLib = 101,
			ePENumberOfSharesLib =102,
			ePEQuantityLibObsolete,
			ePEHairCutLib,
			//ePEBasketLib,
			ePEBasketName = 106,
			ePEBoutonComposition,	// uniquement sur achat
			ePECoursAction,
			ePEReferenceActionText	= 150,
			ePECoursActionText,
			ePENominal,
			ePENominalText,
			ePECouponCouru,
			ePECouponCouruText,
			ePEForexValue,
			ePEForexValueText,
			ePEForexOrder,
			ePEBoxCommission = 300,
			ePEBoxCollateral,
			ePEBoxCallable,
			ePEBillingCurrency,
			ePEAllotment,
			ePEAllInRate,           //305
			ePEStockLoanPricingType,
			ePEStockLoanPricingTypeLib,
			ePEUnderlyingRefRadio,  
			ePEUnderlyingCcyRadio,
			ePEUnderlyingCcy,       //310
			ePEAllInRateLib,
			ePETypePaiementLib,
			ePECommissionRate,

		};*/
	}
}

SPH_EPILOG
#endif	//_SphLoanAndRepoDialog_H_

