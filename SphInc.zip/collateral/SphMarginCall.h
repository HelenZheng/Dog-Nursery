#pragma once
#ifndef __SPHCOLLATERALMARGINCALL_H__
#define __SPHCOLLATERALMARGINCALL_H__

/* ---------------------------------------------------------------------- */

#include "SphInc/tools/SphClonable.h"
#include "SphInc/Collateral/SphCollateralExceptions.h"
#include "SphInc/Collateral/SphLbaType.h"
#include "SphInc/collateral/SphStockLoanPosition.h"
#include __STL_INCLUDE_PATH(memory)

/* ---------------------------------------------------------------------- */
SPH_PROLOG
namespace sophis {

	namespace portfolio {
		class CSRTransaction;
	}

	namespace instrument {
		class CSRInstrument;
	}

	namespace collateral {
		class CSRLBAgreement;
		typedef _STL::shared_ptr<CSRLBAgreement> CSRLBAgreementPtr;
		class CSRCollateralException;
		class CSRLbaType;
	}

	namespace tools {
		class CSREventVector;
	}
}

/* ---------------------------------------------------------------------- */

namespace sophis {
	namespace collateral {

#define MARGINCALL_HARDCODED_MODEL		"Collateral"
#define PER_CONTRACT_CASH_MARGINCALL_MODEL	"PerContractCashMarginCall"
#define PER_CONTRACT_STOCK_MARGINCALL_MODEL	"PerContractCashMarginCall"

/* ---------------------------------------------------------------------- */

/**
 * Base class to create and perform margin call, cash or securities.
 * @version 
 */
class SOPHIS_COLLATERAL CSRMarginCall
{
public:
	CSRMarginCall(void);
	CSRMarginCall(const sophis::portfolio::CSRTransaction& trans, bool readOnly);
	virtual ~CSRMarginCall(void);
	void Initialize(const sophis::portfolio::CSRTransaction& trans, bool readOnly);
	virtual CSRMarginCall* Clone() const=0;

	static CSRMarginCall *NewMarginCall(bool isCash);
	static CSRMarginCall *NewMarginCall(bool isCash, long sicovam);
	static CSRMarginCall *NewMarginCall(bool isCash, CSRLbaType::eLbaType lbaType);

	inline const CSRLBAgreementPtr& GetAgreement() const { return fAgreement; }
	virtual void SetAgreement(const CSRLBAgreementPtr& agreement, long folioId = 0);
	void SetQuantity(double quantity);
	double GetQuantity(){return fQuantity;}
	void SetSpot(double spot);
	void SetAccruedCoupon(double coupon);
	void SetUnderlyingId(long underlyingId);

	void PrepareInstrument(void);
	void PrepareTransaction(void);
	void Save(long event_id);
	
	/**
	 * Saves transaction in the database.
	 * @param messages Messages vector (can be <code>null</code>). If not present, the transaction save
	 * is immediately committed to the database. Otherwise, multi-save is performed and save events are saved
	 * into the messages vector.
	 * @param eventID  parameter to indicate if a specific event action needs to be applied to
	 * the transaction instead of simply saving it. Only valid if messages are present and invokes
	 * <code>CSRTransaction::DoAction(eventID,messages)</code>.
	 * @param afterEventApplied is a boolean to know if we have to do a DoAction or a SaveMultiInstertion
	 * Any exceptions arising during transaction save are re-thrown as <code>CSRCollateralException</code>.
	 *
	 @ version 5.3 new parameter afterEventApplied and no more optional eventID
	 *
	 */
	void SaveMultiInsertion(sophis::tools::CSREventVector *messages, long eventID , bool afterEventApplied);

	sophis::portfolio::CSRTransaction *GetTransaction(void);
	sophis::instrument::CSRInstrument *GetInstrument(void);

	virtual bool NeedCollateralMatrixValidation();

	/* For margin calls created from the new collateral management screen*/
	CSRLbaType::eLbaType GetSourceLineType();

	/**
	 * Returns the instrument model used.
	 */
	virtual const char* GetModel() const { return fModel; }

	virtual void SetModel(const char* model){strcpy(fModel, model);}
	/**
	 * Initialises all values based on the given Margin Call object, except for the transaction data.
	 * Used by <code>ISRClonable</code> interface.
	 */
	virtual void Initialize(const CSRMarginCall* mc);

	/**
	 * Used to set depositary, sm/dt, and payment method values of the new margin call transaction
	 * to match the given values from the initial lending/borrowing deal, or initial margin call deal.
	 * @version 5.2.4
	 */
	void SetInitialDealInfo(const SInitialDealInfo &initDeal) { fInitDeal = initDeal; }

	bool GetIsNewInstrument();
//protected:
	virtual void GetMCInstrumentName(char *mcInstrumentName, size_t size);

	virtual sophis::instrument::CSRInstrument *FindInstrument(void) = 0;

	virtual sophis::instrument::CSRInstrument *MakeInstrument(void) = 0;

	virtual void MakeTransaction(void) = 0;

	void ClearInstrument(void);

	void SetInstrument(long inst);
	/* For margin calls created from the new collateral management screen*/
	void SetSourceLineType(CSRLbaType::eLbaType eType);

	void SetReadOnly(bool val);

//protected:
	CSRLBAgreementPtr fAgreement;
	sophis::portfolio::CSRTransaction *fTransaction;
	sophis::instrument::CSRInstrument *fInstrument;
	bool   fIsNewInstrument;
	double fQuantity;
	double fSpot;
	double fAccruedCoupon;
	long   fUnderlyingId;
	CSRLbaType::eLbaType fEType;
	bool	fReadOnly;
	char fModel[40];
	SInitialDealInfo fInitDeal;
//	friend class CSRMarginCallGui;
//	friend class CSRGlobalMarginCallDialog;
//	friend class CLBACommonPoolMarginCallDlog;
//	friend class CSRSecuritiesCollateralSubstitution;
};

/* ---------------------------------------------------------------------- */

	}	// namespace collateral
}	// namespace sophis
SPH_EPILOG
/* ---------------------------------------------------------------------- */

#endif /* __SPHCOLLATERALMARGINCALL_H__ */
