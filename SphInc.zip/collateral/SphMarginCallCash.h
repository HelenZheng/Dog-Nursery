#pragma once
#ifndef _SPHCOLLATERAL_MARGIN_CALL_CASH_H_
#define _SPHCOLLATERAL_MARGIN_CALL_CASH_H_

#include "SphInc/collateral/SphMarginCall.h"

/* ---------------------------------------------------------------------- */
SPH_PROLOG
namespace sophis {
	namespace collateral {

/* ---------------------------------------------------------------------- */
struct InsertForecastQueryParam{
		double spot;				// 1
		long   folio;				// 2
		sophis::portfolio::PositionIdent positionId;			// 3
		double quantity;			// 4
		long   instrumentId;		// 5
		long   instrumentType;		// 6
		long   backOffice;			// 7
		long   date_val;			// 8
		long   type;				// 9
		double netAmount;			// 10
		long   conterparty;			// 11
		long   date_neg;			// 12
		long   depositary;			// 13
		long   settlementMethod;	// 14
		long   deliveryType;		// 15
		long   paymentMethod;		// 16
		long   depoOfTheCpty;		// 17
		long   entity;				// 18
		long   time_neg;			// 19
		long   ccyPay;				// 20
		sophis::portfolio::TransactionIdent   reference;			// 21
};

struct SOPHIS_COLLATERAL CFDAutoInsertForecastQueryParam : InsertForecastQueryParam
{
	CFDAutoInsertForecastQueryParam();
	long   reportHistoryID;			// 22
	sophis::portfolio::TransactionIdent   mirrorRef;               // 23
	char   boRemark[255];			// 24
};

class SOPHIS_COLLATERAL CSRCashMarginCall: public virtual CSRMarginCall
{
public:
	CSRCashMarginCall(void);
	CSRCashMarginCall(CSRLbaType::eLbaType eType, const char *model = 0);
	CSRCashMarginCall(const sophis::portfolio::CSRTransaction& trans, bool readOnly);
	void Initialize(CSRLbaType::eLbaType eType, const char *model = 0);
	void Initialize(const sophis::portfolio::CSRTransaction& trans, bool readOnly);

	virtual void SetRate(long rate);
	virtual void SetPrincipalQuantity(double quantity);
	virtual void SetCashAmount(double quantity);
	virtual void SetCollateralizedSpot(double collatSpot);
	virtual double GetCashAmount(){return fCashAmount;}
	virtual long GetRate() const {return fRate;}

	virtual void Initialize(const CSRMarginCall* mc);
	virtual CSRMarginCall* Clone() const;
	
	virtual void SetAgreement(const CSRLBAgreementPtr& agreement, long folioId = 0);

	//Checks for commission instrument with values as passed in. If found return its sicovam
	//otherwise create and return sicovam. return 0 if not created.
	static long FindOrCreateInstrument(long conv, long ccy, long rate, const char *instrModel = 0);
	// The find part of FindOrCreateInstrument(), returns 0 if not found.
	static long FindExistingInstrument(long conv, long ccy, long rate, const char *instrModel = 0);
	
	//A static method accessible from SophisColle to create a CashMarginCall with a value in reference to link with explanations...
	static bool CreateCashMarginCallTicketForCFD(long ccy, 
	                                             long rate, 
	                                             long entity, 
	                                             long cpty, 
	                                             long convention, 
	                                             double amount, 
	                                             sophis::portfolio::TransactionIdent reference, 
	                                             long dateVal, 
	                                             long dateNeg, 
	                                             sophis::portfolio::PositionIdent& positionId, 
	                                             long& instrumentId, 
	                                             long reportHistoryID, 
	                                             _STL::string table, 
	                                             char* boRemark = NULL);

	//A static method accessible from SophisColle to create a CashMarginCall which takes the BE from the stock loan "General / Pool Cash Margin Call" parameter
	static bool CreateExposureReminderTicketForCFD(long ccy, 
	                                               long rate, 
	                                               long entity, 
	                                               long cpty, 
	                                               long convention, 
	                                               double amount, 
	                                               sophis::portfolio::TransactionIdent reference, 
	                                               long dateVal, 
	                                               long dateNeg, 
	                                               sophis::portfolio::PositionIdent& positionId, 
	                                               long& instrumentId, 
	                                               long reportHistoryID, 
	                                               _STL::string table);

	//A static method to create a CashMarginCall with a value in reference to link with explanations...
	static bool CreateCashMarginCallTicketForCFDWithBE(long ccy, 
	                                                   long rate, 
	                                                   long entity, 
	                                                   long cpty, 
	                                                   long convention, 
	                                                   double amount, 
	                                                   sophis::portfolio::TransactionIdent reference, 
	                                                   long dateVal, 
	                                                   long dateNeg, 
	                                                   sophis::portfolio::PositionIdent& positionId, 
	                                                   long& instrumentId, 
	                                                   long reportHistoryID, 
	                                                   _STL::string table, 
	                                                   short businessEvent, 
	                                                   char* boRemark = NULL);

	// Static function that can be used to insert a deal into a specified table. It is used by CreateCashMarginCallTicketForCFD.
	static bool InsertCashMarginCallTicketForCFD(CFDAutoInsertForecastQueryParam &param, _STL::string table);
	// [2/3/2007 yshmarygo] #14745 returns the default cash margin call allotment 
	// from CollateralCashAllotment riskpref
	static long GetCollateralCashAllotment();
	// Returns preference if we should use the most recent instrument for a MC
	static long UseMostRecentMCInstr();
	static const char *__CLASS__;

//protected:
	virtual sophis::instrument::CSRInstrument *FindInstrument(void);

	virtual sophis::instrument::CSRInstrument *MakeInstrument(void);

	virtual void MakeTransaction(void);

//	friend class CSRCashMarginCallGui;

//private:
	double fCashAmount;
	bool fCashAmountSet;
	long fRate;
};

class SOPHIS_COLLATERAL CSRCashMarginCallSecVsCashPerCtC : public virtual CSRCashMarginCall
{
public:
	CSRCashMarginCallSecVsCashPerCtC();
	CSRCashMarginCallSecVsCashPerCtC(CSRLbaType::eLbaType eType);
	void Initialize(CSRLbaType::eLbaType eType);
	virtual void SetRate(long rate);
	virtual void SetPrincipalQuantity(double quantity);
	virtual void SetCashAmount(double quantity);
	virtual void SetCollateralizedSpot(double collatSpot);

	virtual void Initialize(const CSRMarginCall* mc);
	virtual CSRMarginCall* Clone() const;
//protected:
	virtual sophis::instrument::CSRInstrument *MakeInstrument(void);
	virtual sophis::instrument::CSRInstrument *FindInstrument(void);
	virtual void MakeTransaction();
//private:
	double fPrincipalQuantity;
	double fCollateralizedSpot;// Collateralized Price Value (Spot) in collateral (margin call) currency.
};

/* ---------------------------------------------------------------------- */

	}	// namespace collateral
}	// namespace sophis
SPH_EPILOG
#endif //_SPHCOLLATERAL_MARGIN_CALL_CASH_H_