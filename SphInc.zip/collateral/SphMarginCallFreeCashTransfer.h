#pragma once
#ifndef _SPHCOLLATERAL_MARGIN_CALL_FREE_CASH_TRANSFER_H_
#define _SPHCOLLATERAL_MARGIN_CALL_FREE_CASH_TRANSFER_H_

#include "SphInc/collateral/SphMarginCallCash.h"
#include "SphInc/collateral/SphCollateralEnums.h"
/* ---------------------------------------------------------------------- */
SPH_PROLOG
namespace sophis {
	namespace collateral {

/* ---------------------------------------------------------------------- */

class SOPHIS_COLLATERAL CSRFreeCashTransfer: public virtual CSRCashMarginCall
{
protected:
	CSRFreeCashTransfer();
public:
	CSRFreeCashTransfer(eFreeCashMovementType mType);
	void Initialize(eFreeCashMovementType mType);
	CSRFreeCashTransfer(const sophis::portfolio::CSRTransaction& trans, bool readOnly);
	void Initialize(const sophis::portfolio::CSRTransaction& trans, bool readOnly);
	virtual void Initialize(const CSRMarginCall* mc);
	virtual CSRMarginCall* Clone() const;
	virtual void SetAgreement(const CSRLBAgreementPtr& agreement, long folioId = 0);
	virtual void SetFreeCashRate(long rate);
	virtual long GetFreeCashRate() const;
	virtual void SetFreeCashCcy(long ccy);
	virtual long GetFreeCashCcy() const;
	virtual eFreeCashMovementType GetMovementType(){return fcMovementType;}

	//A static method accessible from SophisColle to create a CashMarginCall with a value in reference to link with explanations...
	static bool CreateFreeCashTicketForCFD(eFreeCashMovementType type, 
	                                       long freeCashCcy, 
	                                       long freeCashRate, 
	                                       long collCashCcy, 
	                                       long collCashRate, 
	                                       long entity, 
	                                       long cpty, 
	                                       long convention, 
	                                       double amount, 
	                                       sophis::portfolio::TransactionIdent reference, 
	                                       long dateVal, 
	                                       long dateNeg, 
	                                       sophis::portfolio::PositionIdent& positionId, 
	                                       long& instrumentId, 
	                                       long reportHistoryID, 
	                                       _STL::string table);
	static const char *__CLASS__;
//protected:
	virtual sophis::instrument::CSRInstrument *FindInstrument(void);

	virtual sophis::instrument::CSRInstrument *MakeInstrument(void);

private:
	static bool CreateFreeCashTicketForCFD(CSRCashMarginCall* fMc, 
	                                       long fCcy, 
	                                       long fRate, 
	                                       long entity, 
	                                       long cpty, 
	                                       long convention, 
	                                       double amount, 
	                                       sophis::portfolio::TransactionIdent  reference, 
	                                       long dateVal, 
	                                       long dateNeg, 
	                                       sophis::portfolio::PositionIdent& positionId, 
	                                       long& instrumentId, 
	                                       _STL::string table, 
	                                       sophis::portfolio::TransactionIdent  mirrorRef, 
	                                       long reportHistoryID);
	eFreeCashMovementType fcMovementType;
};

/* ---------------------------------------------------------------------- */
	}	// namespace collateral
}	// namespace sophis
SOPHIS_COLLATERAL long GetFreeCashTransferMirrorRuleId(); //throws(GeneralException)
SPH_EPILOG
#endif //_SPHCOLLATERAL_MARGIN_CALL_FREE_CASH_TRANSFER_H_
