#pragma once
#ifndef _SPHCOLLATERAL_MARGIN_CALL_SECURITIES_H_
#define _SPHCOLLATERAL_MARGIN_CALL_SECURITIES_H_

#include "SphInc/collateral/SphMarginCall.h"
#include "SphInc/instrument/SphLoanAndRepo.h"

/* ---------------------------------------------------------------------- */
SPH_PROLOG
namespace sophis {
	namespace collateral {

/* ---------------------------------------------------------------------- */

class SOPHIS_COLLATERAL CSRSecuritiesMarginCall: public virtual CSRMarginCall
{
public:
	CSRSecuritiesMarginCall(void);
	CSRSecuritiesMarginCall(CSRLbaType::eLbaType eType);
	void Initialize(CSRLbaType::eLbaType eType);

	virtual void Initialize(const CSRMarginCall* mc);
	virtual CSRMarginCall* Clone() const;

	virtual void SetAgreement(const CSRLBAgreementPtr& agreement, long folioId = 0);

//protected:
	virtual sophis::instrument::CSRInstrument *FindInstrument(void);

	virtual sophis::instrument::CSRInstrument *MakeInstrument(void);

	sophis::instrument::eStockLoanCreationMethod fCreationMethod;
//	double fSpot; // SPOT value to be put into the transaction
	double fHaircut; // For calculations (where applicable)

//	friend class CSRSecuritiesMarginCallGui;
//	friend class CSRSecuritiesMarginCallPerContractGui;

	long	fTemplateID;
public:
	virtual void MakeTransaction(void);
};

/* ---------------------------------------------------------------------- */

	}	// namespace collateral
}	// namespace sophis
SPH_EPILOG
#endif //_SPHCOLLATERAL_MARGIN_CALL_SECURITIES_H_