#pragma once
#ifndef _SPHCOLLATERAL_SECURITIES_COLLATERAL_SUBSTITUTION_H_
#define _SPHCOLLATERAL_SECURITIES_COLLATERAL_SUBSTITUTION_H_

#include "SphInc/collateral/SphMarginCallSecurities.h"
SPH_PROLOG
namespace sophis {
	namespace collateral {

		/**
		* Handles securities collateral substitution transaction management.
		* @since 5.1
		*/
		class SOPHIS_COLLATERAL CSRSecuritiesCollateralSubstitution : public virtual CSRSecuritiesMarginCall
		{
			static const char* __CLASS__;
		public:
			CSRSecuritiesCollateralSubstitution();

			/**
			 * Returns pointer to current securities margin call data to be substituted.
			 */
			CSRSecuritiesMarginCall* GetCurrentData() { return fCurrentMc; }

			/**
			 * Returns pointer to new securities margin call data, the one
			 * that substitutes the current data.
			 */
			CSRSecuritiesMarginCall* GetNewData() { return this; }

			/**
			 * Saves all instruments and transactions.
			 *
			 * @param eventID1 Optional event id to be applied to the current securities margin call transaction.
			 * @param eventID2 Optional event id to be applied to the new securities margin call transaction.
			 *
			 * If event id is not present for the current transaction (<code>eventID1</code>), 
			 * the current transaction gets the same back office final status as the new securities 
			 * margin call transaction. 
			 *
			 * When present, event id is passed down to the <code>CSRMarginCall::SaveMultiInsertion()</code> method
			 * of the corresponding transaction.
			 */
			void SaveAll(long eventID1 = 0, long eventID2 = 0);
			virtual bool NeedCollateralMatrixValidation();
		


//		protected:

			/**
			 *
			 */
			virtual void MakeTransaction(void);


			/**
			 * Method used to create fCurrentMc object that derived classes can override.
			 */
			virtual CSRSecuritiesMarginCall* new_CSRMarginCall();

//		protected:

			/**
			 * Contains information about current margin call collateral (the one to be substituted).
			 */
			CSRSecuritiesMarginCall *fCurrentMc;

			// Elements relevant to collateral substitution transaction management
			sophis::portfolio::PositionIdent fMvtident; // MVTIDENT of the stock loan position

//		private:
			bool fCurrentMcInitialised; // if fCurrentMc has been initialised.
			short fIsCreation;

//			friend class CSRSecuritiesCollateralSubstitutionGUI;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SPHCOLLATERAL_SECURITIES_COLLATERAL_SUBSTITUTION_H_
