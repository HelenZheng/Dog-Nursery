#ifndef _Sph_Perimeter_Group_Selector_Condition_H_
#define _Sph_Perimeter_Group_Selector_Condition_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG

struct TLib;

namespace sophis {
	namespace instrument {
		class CSRInstrument;
	}
	namespace collateral {

/**
 * Macros for handling convention group selector condition prototype implementation.
 * @version 5.3.1
 */
#define DECLARATION_PERIMETER_GROUP_SELECTOR_CONDITION(derivedClass) \
		DECLARATION_PROTOTYPE(derivedClass, CSRPerimeterGroupSelectorCondition)
#define CONSTRUCTOR_PERIMETER_GROUP_SELECTOR_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_PERIMETER_GROUP_SELECTOR_CONDITION(derivedClass)

		
#define	INITIALISE_PERIMETER_GROUP_SELECTOR_CONDITION(derivedClass, name)	\
		INITIALISE_PROTOTYPE(derivedClass,  name)

/**
 * Convention group selector.
 *
 * To add new condition, derive this class, using the macro DECLARATION_PERIMETER_GROUP_SELECTOR_CONDITION in your header
 * and INITIALISE_PERIMETER_GROUP_SELECTOR_CONDITION in UNIVERSAL_MAIN.
 * 
 * @version 5.3.1
 */
class SOPHIS_COLLATERAL CSRPerimeterGroupSelectorCondition 
{
public:

	/** Trivial destructor.
		*/
	virtual ~CSRPerimeterGroupSelectorCondition() {}

	/**
	 * Clone method required by the prototype.
	 * Use DECLARATION_PERIMETER_GROUP_SELECTOR_CONDITION macro in the implementation of the derived class.
	 */
	virtual CSRPerimeterGroupSelectorCondition* Clone() const = 0;
	
	/**
	 * Must be implemented in derived classes.
	 * @return true if condition is matched, false if condition is invalid.
	 */
	virtual bool GetCondition (const instrument::CSRInstrument& instr) const = 0;

	/**
	 * INTERNAL.
	 */
	virtual bool GetCondition(TLib*& ph) const;
	
	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef sophis::tools::CSRPrototype<CSRPerimeterGroupSelectorCondition, 
										const char *, 
										sophis::tools::less_char_star> prototype;

	/** 
	 * Access to prototype singleton.
	 */
	static prototype& GetPrototype();
};

	}	// collateral
}		// sophis


SPH_EPILOG

#endif // _Sph_Perimeter_Group_Selector_Condition_H_