#ifndef _Sph_Perimeter_Selector_Condition_H_
#define _Sph_Perimeter_Selector_Condition_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG


struct TLib;

namespace sophis {
	namespace collateral {

/**
 	Macro to be used instead of the Clone() method in the clients derived classes.
 	Prototype framework will be responsible to instantiate clients objects.
 	
 	@param derivedClass is the name of the client derived class.
	*/
#define DECLARATION_PERIMETER_SELECTOR_CONDITION(derivedClass) \
		DECLARATION_PROTOTYPE(derivedClass, CSRPerimeterSelectorCondition)
#define CONSTRUCTOR_PERIMETER_SELECTOR_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_PERIMETER_SELECTOR_CONDITION(derivedClass)
/**
 	Macro to be placed in the clients <main>.cpp to register derived client classes
 	with the prototype framework.
 	
 	@param derivedClass is the name of the client derived class.
 	@param name is the unique string to be used as a key to indentify registrated class in the framework.
 	It is also what will appear in the Condition1, Condition2, Condition3 drop down menu of
 	Convention Selector window.
 	Clients have to use this name in CSRPerimeterSelectorCondition::GetPrototype().GetData(condName) 
 	method to instantiate the clients class objects.
	*/
#define	INITIALISE_PERIMETER_SELECTOR_CONDITION(derivedClass, name)	\
		INITIALISE_PROTOTYPE(derivedClass,  name)

/**
 * Convention selector condition.
 * @version 5.0
 */
class SOPHIS_COLLATERAL CSRPerimeterSelectorCondition 
{
public:

	/** Trivial destructor.
		*/
	virtual ~CSRPerimeterSelectorCondition() {}

	/** Clone method needed by the prototype.
		Usually, it is done automatically by the macro DECLARATION_PERIMETER_SELECTOR_CONDITION.
		@see tools::CSRPrototype
		*/
	virtual CSRPerimeterSelectorCondition* Clone() const = 0;

	/**
	 	Pure virtual method.
	 	Used by the framework while selecting the rule from Convention Selector rules set.
	 	Method is called for Condition1, Condition2, Condition3 columns. Here we check the 
		type of instrument to be 'Stock Loan' OR 'Repo' OR 'Contract For Differencies'
	 	to make decision if to select the matching rule. The result has to be TRUE to make the rule selected.
	 	@instr is the reference to the instrument;
	 	@return is the boolean and is calculated by the client code.
		*/
	virtual bool GetCondition (const instrument::CSRInstrument& instr) const = 0;

	/**
	 * INTERNAL.
	 */
	virtual bool GetCondition(TLib*& ph) const;

	/** typedef for the prototype : the key is a string
		*/
	typedef sophis::tools::CSRPrototype<CSRPerimeterSelectorCondition, 
										const char *, 
										sophis::tools::less_char_star> prototype;

	/** Access to the prototype singleton.
		To add a trigger to this singleton, use INITIALISE_PERIMETER_SELECTOR_CONDITION.
		@see tools::CSRPrototype
		*/
	static prototype& GetPrototype();
};

	}	// collateral
}		// sophis

SPH_EPILOG

#endif // _Sph_Perimeter_Selector_Condition_H_