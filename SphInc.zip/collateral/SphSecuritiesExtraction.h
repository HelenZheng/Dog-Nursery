#ifndef _SphSecuritiesExtraction_H_
#define _SphSecuritiesExtraction_H_



#include "SphInc/SphMacros.h"
#include "SphInc/SphEnums.h"
#include "SphInc/tools/SphPacketVector.h"
#include "SphInc/collateral/SphSecuritiesReportParam.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG


struct Tdescribe;

namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace collateral {

class CSRSecuritiesReportQuantities;
class CSRLBAgreement;

/**
 * Basic structure of securities extraction data fetched from database.
 * @since 5.3.6
 */
struct SOPHIS_COLLATERAL SSSecuritiesExtractionTrade
{

	/** Instrument id (from database). */
	long fSicovam;

	/** Portfolio id. */
	long fPortfolioId;

	/** Position id (mvtident). */
	sophis::portfolio::PositionIdent fPositionId;

	/** Refmvtback (reference to main position id). */
	sophis::portfolio::PositionIdent fRefmvtback;

	/** Quantity. */
	double fQuantity;

	/** Counterparty. */
	long fCpty;

	/** Entity. */
	long fEntity;

	/** Date of the trade, only filled in the projection mode. */
	long fDate;

	/** Depositary of the trade.  Since 7.1*/
	long fDepositary;

	/** Storage Place for commodities.  Since 6.2.3*/
	long fStoragePlace;

	/** Book quantity. */
	double fBookQuantity;

	/** Stock Loan quantity. */
	double fSLQuantity;

	/** Collateral pool quantity. */
	double fCollatQuantityPool;

	/** Collateral contract quantity. */
	double fCollatQuantityContract;

	/** Hedged Quantity by Par Asset Swaps*/
	double fHedgedQuantity;

	/** Instrument id of the position, like equity, or stock loan template, or securities collateral, etc. */
	long fPositionInstrumentCode;

	/** Position type, it's used to distinguish virtual and simulated positions. */
	short fSicoType;

	// constructor, added to initialise fSicoType as it's only used in cache.
	SSSecuritiesExtractionTrade () :
	fSicoType(0)
	{
	}
};

SOPHIS_COLLATERAL SSSecuritiesExtractionTrade& operator += (SSSecuritiesExtractionTrade& lhs, const SSSecuritiesExtractionTrade& rhs);

/** List of trades extracted from database. */
typedef tools::CSRPacketVector<SSSecuritiesExtractionTrade> SecuritiesExtractionTradeList;

/**
 * Wrapper interface around SSSecuritiesExtractionTrade structure.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesExtractionTrade
{
public:
	virtual ~CSRSecuritiesExtractionTrade() {};
	virtual SSSecuritiesExtractionTrade& operator*() = 0;
	virtual CSRSecuritiesExtractionTrade* Clone() const = 0;

	/** Implements a += operation on a pair of SSSecuritiesExtractionTrade structures.
	 * @note Both #result and #op should refer to structures of the same actual type, one that corresponds to the Securities Report model used.
	 */
	virtual void AddLowLevelTradeValuesExternal(SSSecuritiesExtractionTrade& result, const SSSecuritiesExtractionTrade& op) const = 0;

	//! Implements a += operation on *this and rhs. Will typically call AddLowLevelTradeValuesExternal(**this,*rhs).
	virtual void AddTradeValues(const CSRSecuritiesExtractionTrade& rhs) = 0;

	// deliberately non-virtual, provided for convenience (no need to const_cast)
	SSSecuritiesExtractionTrade* operator->()				{ return &**this; }
	const SSSecuritiesExtractionTrade& operator*() const	{ return const_cast<CSRSecuritiesExtractionTrade*>(this)->operator*(); }
	const SSSecuritiesExtractionTrade* operator->() const	{ return const_cast<CSRSecuritiesExtractionTrade*>(this)->operator->(); }

protected:
	CSRSecuritiesExtractionTrade() {}
};

/**
 * Wrapper class template around any struct derived from SSSecuritiesExtractionTrade (or itself).
 * @param T struct/class derived from SSSecuritiesExtractionTrade, must be copy-constructible, 'T += T' must be a valid expression.
 * @since 5.3.6
 * @note Since this is a template, it is deliberately not tagged SOPHIS_COLLATERAL.
 */
template<typename T>
class CSRSecuritiesExtractionTradeImpl : public CSRSecuritiesExtractionTrade
{
public:
	/** Passed trade must actually a reference to T. */
	CSRSecuritiesExtractionTradeImpl(const SSSecuritiesExtractionTrade& trade) : fTrade(static_cast<const T&>(trade)) { }
	virtual ~CSRSecuritiesExtractionTradeImpl() {}
	virtual T& operator*() { return fTrade; }
	virtual CSRSecuritiesExtractionTradeImpl* Clone() const { return new CSRSecuritiesExtractionTradeImpl(*this); }

	virtual void AddLowLevelTradeValuesExternal(SSSecuritiesExtractionTrade& result, const SSSecuritiesExtractionTrade& op) const
		{ static_cast<T&>(result) += static_cast<const T&>(op); }
	virtual void AddTradeValues(const CSRSecuritiesExtractionTrade& rhs)	{ return AddLowLevelTradeValuesExternal(**this, *rhs); }

	// deliberately non-virtual, ones from base class are hidden
	T* operator->()				{ return &**this; }
	const T& operator*() const	{ return const_cast<CSRSecuritiesExtractionTradeImpl*>(this)->operator*(); }
	const T* operator->() const	{ return const_cast<CSRSecuritiesExtractionTradeImpl*>(this)->operator->(); }

protected:
	CSRSecuritiesExtractionTradeImpl(const CSRSecuritiesExtractionTradeImpl &copy) : fTrade(copy.fTrade) {}
	T fTrade;
};

/** Type of securities report.
 * Determines the date used for calculating the quantities.
 * @since 5.3.6
 */
enum eSecuritiesExtractionType {
	se__First = 1,	//< start at one to ease integration with the GUI

	seTradeDate = se__First,
	seValueDate,
	seEstimatedValueDate,
	seRealSettlementDate,

	se__Last = seRealSettlementDate
};

/** Flags for Securities Extraction, give toolkit models more control over the extraction details.
 * @see CSRSecuritiesExtraction::GetFlags()
 */
enum eSecuritiesExtractionFlags {
	sefOuterJoinWithInstructions	= 0x1,	//!< Only used in #seEstimatedValieDate and #seRealSettlementDate. Makes the join with instructions data to be a LEFT join, with instructions on the right side. If this flag is not set, the join is inner.
	sefAlwaysIncludeZeroQuantities	= 0x2,	//!< Never filter out rows that have zero total quantities, ie. do not put the HAVING clause at the end of the query.

	sefNoFlags = 0
};

/** Type of securities report.
* Determines the trade type.
* @since 7.1
*/
enum eSecuritiesExtractionTradeType {
	se_trade_all,
	se_trade_book,
	se_trade_sl,
	se_trade_coll_pool,
	se_trade_coll_contract,
};

/**
 * Securities report extraction.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesExtraction
{
public:
	/** Constructor. */
	CSRSecuritiesExtraction();

	/** Destructor. */
	virtual ~CSRSecuritiesExtraction();

	/** Structure used to describe information about additional field to be extracted
	 * during securities report extraction. */
	struct SExtraFieldInfo
	{
		/** Type of field, accepted types are limited to dNullTerminatedString, dLong, and dDouble. */
		NSREnums::eDataType fType;
		/** Offset in the structure of the field. */
		long fOffset;
		/** Size of the field. */
		short fSize;
	};

	//! Vector of #SExtraFieldInfo structures, see ExtraFieldsForReporting().
	typedef _STL::vector<SExtraFieldInfo> VecSExtraFieldInfo;

	/** Called at the end DoSecuritiesExtraction() but before AllDeals() to get data from other reporting sources.
	 * @param list Where to add trades from other reporting sources.
	 * See CSRReportingInput.
	 * @version 7.1.2 */
	virtual void DoOtherReportingSources(SecuritiesExtractionTradeList& list,
		const CSRSecuritiesReportParam& param,
		eSecuritiesExtractionType extrType, long date, const _STL::string& prefilter, long projectionEndDate);

	/** Called from DoSecuritiesExtraction() after reading the deals but before processing.
	 * An implementation may choose to push_back to the list.
	 * To exclude a deal set its fPortfolioId field to -1 (as the list type does not support removal).
	 */
	virtual	void AllDeals(SecuritiesExtractionTradeList &list, 
		const CSRSecuritiesReportParam& param,
		eSecuritiesExtractionType extrType, long date, long projectionEndDate);

	/** Called from DoSecuritiesExtraction() after reading the deals, after the AllDeals(),
	 * but before the main processing. Performs filtering specific to given collateral agreement,
	 * if specified in the report parameters. 
	 * To exclude a deal set its fPortfolioId field to -1 (as the list type does not support removal). */
	virtual void AllDealsCollateralAgreement(SecuritiesExtractionTradeList &list, 
		const CSRLBAgreement& lba, const CSRSecuritiesReportParam& param,
		eSecuritiesExtractionType extrType, long date, long projectionEndDate);

	/** Get the supplementary fields required.
	 * @param extrType the extraction type
	 * @note overriding function should always "append" to what the function in the base class returns
	 */
	virtual _STL::string GetFieldDetailedReporting(eSecuritiesExtractionType extrType) const;

	/** Get the fields for the "middle level" of the query.
	 * The middle level of the query is mostly useful in Estimated Value Date and Real Settlement Date modes
	 * where the joined instruction data can be accessed under the alias "I".
	 * @param extrType the extraction type
	 * @note overriding function should always "append" to what the function in the base class returns
	 */
	virtual _STL::string GetMiddleLevelFieldReporting(eSecuritiesExtractionType extrType) const;

	/** Get the supplementary fields required.
	 * Number and types of the fields must correspond to ExtraFieldsForReporting().
	 * Naturally, the expressions selected here should be good when
	 * the rows are grouped by GetGroupByReporting().
	 * @param extrType the extraction type
	 * @note overriding function should always "append" to what the function in the base class returns
	 */
	virtual _STL::string GetFieldGroupReporting(eSecuritiesExtractionType extrType) const;

	/** Get the "group by" part of the query needed for the supplementary fields.
	 * @param extrType the extraction type
	 * @note overriding function should always "append" to what the function in the base class returns
	 */
	virtual _STL::string GetGroupByReporting(eSecuritiesExtractionType extrType) const;

	/** Get the information about n-th extra field.
	 * @param extrType the extraction type
	 * @param outExtraFields vector onto which to push_back the information about the extra fields
	 * @see GetFieldGroupReporting()
	 * @note An overriding function must always call the function in the base class first before appending its own fields.
	 */
	virtual void ExtraFieldsForReporting(eSecuritiesExtractionType extrType, VecSExtraFieldInfo& outExtraFields) const;

	/** Get the SQL filter for underlying types.
	 * Returned string must be a valid SQL condition and will be the sole filter used for underlyings.
	 * The default implementation returns a condition that only lets shares, bonds, and convertible bonds through.
	 * The condition must use table alias "T2" which will refer to the TITRES table with
	 * the underlying (in case of stock loan deals) or with the booked instrument (in the book case).
	 * @param extrType the extraction type
	 */
	virtual _STL::string GetUnderlyingCondition(eSecuritiesExtractionType extrType) const;

	/** Get flags of the extraction, gives toolkit control over some properties of the extraction (query).
	 *
	 * @param extrType the extraction type
	 * @return Or'd values from eSecuritiesExtractionFlags.
	 *
	 * For the various extraction types, implementation in this class returns:
	 *  - seTradeDate: sefNoFlags
	 *  - seValueDate: sefNoFlags
	 *  - seEstimatedValueDate: sefOuterJoinWithInstructions
	 *  - seRealSettlementDate: sefNoFlags
	 *
	 * @note An overriding function should call the function in the base class first, then only tamper with the bits
	 *		it is aware of. This way additional flags can be added in the future without breaking existing derived classes.
	 */
	virtual unsigned long GetFlags(eSecuritiesExtractionType extrType) const;

	enum eDateDetailsFlags {
		ddfProjection	= 0x1,	//!< If present, data for a projection query is requested. Otherwise it is main/explanation query.
		ddfNoFlags = 0
	};

	/** Return the where clause for the outside query. The clause filters the deals by date.
	 *
	 * To refer to the date value computed by the inner query, the returned string can use "THE_DATE". Note that "THE_DATE"
	 * is already converted from DATE to a number TYPE so if you are using expressions of DATE types (eg. "DATEVAL"), be
	 * sure to subtract "TO_DATE('01/01/1904','DD/MM/YYYY')" from them.
	 *
	 * To refer to the date parameters of the extraction, which are passed DoSecuritiesExtraction(), the returned
	 * string can use ":report_date" for main/explanation queries, ":start_date" & ":end_date" for projection queries.
	 *
	 * @param extrType the extraction type
	 * @param dateFlags or'd values from eDateDetailsFlags
	 *
	 * Implementation in this class only uses the ddfProjection flag from #dateFlags and, regardless of #extrType,
	 * returns the following:
	 *  - ddfProjection not set (0): "THE_DATE <= :report_date"
	 *  - ddfProjection is set (1): "THE_DATE BETWEEN :start_date AND :end_date"
	 */
	virtual _STL::string GetDateClause(eSecuritiesExtractionType extrType, unsigned long dateFlags) const;

	/** Run the extraction.
	 * @param param Report parameters
	 * @param extrType Type of extraction, see eSecuritiesExtractionType.
	 * @param date Optional reporting date; if not specicied, default date is used. Can be relative (to gDateFinBase()).
	 * @param prefilter SQL condition, will be inserted into the WHERE clause on histomvts
	 * @param projectionEndDate Optional projection end date; if not specified, the normal (non-projection) query is used.
	 *             Can be relative (to #date). Will be forced to be greater than #date.
	 */
	void DoSecuritiesExtraction(const CSRSecuritiesReportParam& param,
		eSecuritiesExtractionType extrType, long date = 0,
		const _STL::string& prefilter = _STL::string(), long projectionEndDate = 0);

	/** Makes a copy of the given result and wraps it in appropriate class object. */
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const SSSecuritiesExtractionTrade& trade) const;

	/** Build trade object from given transaction, if applicable. See also TransactionToTrade(). */
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const portfolio::CSRTransaction& transaction,
		eSecuritiesExtractionType dateType,
		long securitiesCode, bool invertQuantities) const;

	/** Populates low level trade data from given transaction. */
	virtual void TransactionToTrade(const portfolio::CSRTransaction& transaction, SSSecuritiesExtractionTrade& trade,
		eSecuritiesExtractionType dateType,
		long securitiesCode, bool invertQuantities) const;

	/** Generates quantities structure holder specific to given extraction. */
	virtual CSRSecuritiesReportQuantities* new_SecuritiesReportQuantities() const;

	/** Test whether there are any results. Takes constant time unlike size(). */
	inline bool empty() const { return fDealList ? fDealList->empty() : true; }

	/** Returns number of results. */
	inline size_t size() const { return fDealList ? fDealList->size() : 0; }

	/** Shortcut to deal list iterator. See begin() and end(). */
	typedef SecuritiesExtractionTradeList::iterator iterator;

	/** Returns iterator to the start of the result container. */
	inline iterator begin() { return fDealList->begin(); }

	/** Returns iterator to the end of the result container. */
	inline iterator end() { return fDealList->end(); }

	/** returns true if RealSettlementDate type is to be used in the extraction*/
	virtual bool UseRealSettlementDate() const;

	/** uses the trade type in the where clause **/
	virtual _STL::string GetTradeTypeClause(eSecuritiesExtractionTradeType extrTradeType) const;

	/** defines a temporary table used to optimize the FieldDetailedReporting part **/
	_STL::string CSRSecuritiesExtraction::GetFieldDetailedReportingTempTable(eSecuritiesExtractionType extrType) const;

private:
	static const char* __CLASS__;
	/** Result list. */
	SecuritiesExtractionTradeList* fDealList;
};

	} // collateral
} // sophis

SPH_EPILOG

#endif _SphSecuritiesExtraction_H_
