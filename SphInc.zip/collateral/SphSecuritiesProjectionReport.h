#ifndef _SphSecuritiesProjectionReport_H_
#define _SphSecuritiesProjectionReport_H_

#include "SphInc/collateral/SphSecuritiesReport.h"
#include "SphInc/collateral/SphSecuritiesReportResult.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRExpiryData;

/**
 * Projection Securities report.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesProjectionReport : public virtual CSRSecuritiesReport
{
public:
	/** Constructor.
	 * @param factory Factory (model).
	 * @param param Report parameters (become owned by the report).
	 * @param date Report date.
	 * @param dateType Report date type.
	 */
	CSRSecuritiesProjectionReport(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long date, eSecuritiesExtractionType dateType);

	/** Constructor.
	 * @param fullReport Report containing current values (without projection).
	 */
	CSRSecuritiesProjectionReport(const CSRSecuritiesReport& fullReport);

	/** Destructor. */
	~CSRSecuritiesProjectionReport();

	void RefreshProjectionForInventory(const CSRSecuritiesReportParam& param, bool global, long projectionEndDate, const _STL::set<long>& sicovamList, bool loadInstrument);
	
	/** Regenerate the projection report. */
	void RefreshProjection(long date);

	/** Regenerate the projection report for given instrument. */
	void RefreshInstrumentProjection(long date, long sicovam);

	/** Regenerate the projection for specific list of instruments. */
	void RefreshInstrumentListProjection(long date, const _STL::set<long>& sicovamList);

	/** Build projection view specific to given criteria.
	 * @param criteriaKey Criteria key.
	 * @param sicovam Instrument. */
	const CSRSecuritiesReportResultHier* BuildProjectionResult(const CSRSecuritiesReportCriteriaKey& criteriaKey, long sicovam,
		const CSRSecuritiesReportFilter * flatFilter = 0, bool useCache = true) const;

protected:
	static void CollectExpiry(CSRExpiryData & expiryData, const CSRSecuritiesReport & report, long sicovam);
	static void CollectExpiry(CSRExpiryData & expiryData, const CSRSecuritiesReport & report, const _STL::set<long>& sicovamList);
// these do not get wrapped well, for unknown reason
#ifndef GCC_XML
	static const CSRSecuritiesReportResult* GetPrincipalResult(const CSRSecuritiesReport & report, sophis::portfolio::PositionIdent positionId, long cpty, long entity);
	static const CSRSecuritiesReportResult* GetCollateralResult(const CSRSecuritiesReport & report, sophis::portfolio::PositionIdent positionId, long cpty, long entity, long sicovam);
#endif
	const CSRSecuritiesReportResult* GetPrincipalResult(sophis::portfolio::PositionIdent positionId, long cpty, long entity) const;
	const CSRSecuritiesReportResult* GetCollateralResult(sophis::portfolio::PositionIdent positionId, long cpty, long entity, long sicovam) const;
	void AddExpiry(CSRExpiryData & expiryData, long endDate, long startDate);
//	void AddExpiry(CSRSecuritiesReportResultList &resultList, long endDate, const CSRSecuritiesReport * fullReport);
	void RefreshProjection(const CSRSecuritiesReportParam& param, bool global, long projectionEndDate);
//	bool ResultExists(CSRSecuritiesReportResultList &resultList,const CSRSecuritiesReportResult* resultToCheck);

	CSRSecuritiesProjectionReport();
	void Initialize(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long date, eSecuritiesExtractionType dateType);
	void Initialize(const CSRSecuritiesReport& fullReport);
	void FillPositionQuantityByDate(bool loadInstrument);

private:
	const CSRSecuritiesReport *fFullReport;
	_STL::auto_ptr<CSRSecuritiesReportQuantities> fQuantity;

	static const char* __CLASS__;
};


	} // collateral
} // sophis
SPH_EPILOG
#endif _SphSecuritiesProjectionReport_H_