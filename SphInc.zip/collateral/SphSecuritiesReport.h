#pragma once

#ifndef _SphSecuritiesReport_H_
#define _SphSecuritiesReport_H_

#include "SphInc/SphMacros.h"
#include "SphInc/collateral/SphSecuritiesExtraction.h"
#include "SphInc/collateral/SphSecuritiesReportSource.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(memory)

SPH_PROLOG
namespace sophis {
	namespace gridcache {
		namespace MGC {
			class JMSSecurityInventoryPublisher;
			class MGCPortfolioSessionLoaderTask;
		}
	}
	namespace collateral {

class CSRSecuritiesReportParam;
class CSRSecuritiesReportFactory;
class CSRSecuritiesReportResult;
typedef _STL::list<CSRSecuritiesReportResult*> CSRSecuritiesReportResultList;
class CSRSecuritiesReportResultHier;
class CSRSecuritiesReportCriteriaKey;
class CSRSecuritiesReportCriteria;
class CSRSecuritiesReportCache;
class CSRSecuritiesReportExplanationColumn;
class CSRSecuritiesReportTagMetadataColumn;
class CSRSecuritiesReportDialog;
class CSRSecuritiesReportDeltaListener;
class CSRSecuritiesReportSourceMgr;
class CSRSecuritiesReportFilter;

/**
 * Interface for notifying about updates to the securities report.
 * @since 5.3.6
 */
class ISecuritiesReportUpdateListener
{
public:
	/** Called to notify about securities report update. */
	virtual void Updated() = 0;
	/** Called to notify that report is about to be updated. */
	virtual void BeforeUpdate() {}
	/** Called when report is being destroyed. */
	virtual void Closed() {}
};

/**
 * Securities report.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReport
{
public:
	/** Bit flags, see the constructor. */
	enum FlagsEnum {
		efLoadAllInstruments	= 0x01,	//<! Force all the reported instruments to be fully loaded. Especially useful in XML reporting.
		efProjection	= 0x02, //Make inventory projection available

		efNoFlags = 0	//< keep this one last
	};

	/** Constructor.
	 * @param factory Factory (model).
	 * @param param Report parameters (become owned by the report).
	 * @param date Report date, must be absolute.
	 * @param dateType Report date type.
	 * @param flags Additional flags. Combination of values from #FlagsEnum.
	 * @param refresh Specifies if report should be immediately calculated or not. 
	 */
	CSRSecuritiesReport(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long date, eSecuritiesExtractionType dateType, unsigned long flags, bool refresh = true);

	/** Destructor.
		must have a virtual to build the dotnettoolkit (dynamic_cast)
	*/	
	virtual ~CSRSecuritiesReport();

	/** Reload the complete report. */
	void Refresh();

	/** Reload specific instrument. */
	void RefreshInstrument(long sicovam);

	/** Reload specific list of instruments. */
	void RefreshInstrumentList(const _STL::set<long>& sicovamList);

	/** Reload specific position. */
	void RefreshPosition(sophis::portfolio::PositionIdent mvtident);

	/** Reload specific list of positions. */
	void RefreshPositionList(const _STL::set<long>& mvtidentList);

	/** Returns statistics on the latest refresh. */
	inline double GetRefreshTime() const { return fRefreshTime; }

	/** Returns the date and time when the report was generated. */
	inline long GetGenerationDate() const { return fGenerationDate; }

	/** Returns statistics on the view generation. */
	double GetViewBuildTime(const CSRSecuritiesReportResultHier& root) const;

	/** Build view specific to given criteria.
	 * @param criteriaKey Criteria key.
	 * @param sicovam Optional instrument code if building result for a particular instrument.
	 * @param flatFilter Optional filter to apply to flat result list before building the hierarchy.
	 * NOTE: if flatFilter is specified, the hierarchical result is not cached inside report.
	 * @param useCache Optional. Use the previously computed values if they exist. Default is to use the cache.
	 */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** Build view specific to given criteria over given result data.
	 * @version 7.1.1 */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey,
		CSRSecuritiesReportResultList::const_iterator resultBegin, CSRSecuritiesReportResultList::const_iterator resultEnd,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** Sorts the result of the view as per the passed field and direction.
	* @since 5.3.6.5
	*/
	const CSRSecuritiesReportResultHier* SortResult(const CSRSecuritiesReportCriteriaKey& criteriaKey, long sicovam, int field, bool reverse) const;

	/** Build flat view result. 
	 * @param flatFilter Optional filter to apply to flat result list before building the hierarchy.
	 * NOTE: if flatFilter is specified, the hierarchical result is not cached inside report.
	 */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** Build flat view result over given result data.
	 * @version 7.1.1 */
	const CSRSecuritiesReportResultHier* BuildResult(CSRSecuritiesReportResultList::const_iterator resultBegin, CSRSecuritiesReportResultList::const_iterator resultEnd,
		const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** Drop given view from the cache. */
	void ClearView(const CSRSecuritiesReportResultHier& root) const;

	/** Drop all views from the cache. */
	void ClearAllViews() const;

	/** Mark given view as dirty. */
	void InvalidateView(const CSRSecuritiesReportResultHier& root) const;

	/** Mark all views relevant to given instrument as dirty. */
	void InvalidateAllViews(long sicovam) const;

	/** Drop all or relevant to the given instrument dirty views from the cache. 
	  * @param sicovam Optional instrument, only dirty views relevant to this instrument will be cleared. */
	void ClearDirtyViews(long sicovam) const;

	/** Adds listener to the result updates. */
	void AddListener(ISecuritiesReportUpdateListener * listener);

	/** Removes listener to the result updates. */
	void RemoveListener(ISecuritiesReportUpdateListener * listener);

	/** Adds delta listener to the transaction delta updates. */
	void AddDeltaListener(CSRSecuritiesReportDeltaListener * listener);

	/** Removes delta listener to the transaction delta updates. */
	void RemoveDeltaListener(CSRSecuritiesReportDeltaListener * listener);

	/** Get list of registered delta listeners. */
	_STL::vector<CSRSecuritiesReportDeltaListener *> GetDeltaListenerList() const { return fDeltaListeners; }

	/** Internal, used by the view map. */
	struct SOPHIS_COLLATERAL SCriteriaKey
	{
		SCriteriaKey();
		SCriteriaKey(const SCriteriaKey& copy);
		SCriteriaKey(const CSRSecuritiesReportFilter* flatFilter);
		SCriteriaKey(const CSRSecuritiesReportCriteriaKey& key, long sicovam, const CSRSecuritiesReportFilter* flatFilter);
		~SCriteriaKey();
		friend bool operator < (const SCriteriaKey& key1, const SCriteriaKey& key2);
		CSRSecuritiesReportCriteriaKey *fKey;
		long fSicovam;
		long fFlatFilter;
	};

	typedef _STL::map<_STL::pair<CSRSecuritiesReportResultHier*, long>, CSRSecuritiesReportResultHier*> HierCache;
	//typedef _STL::map<long, CSRSecuritiesReportResultHier*> ResultCache;

	struct SOPHIS_COLLATERAL SSecuritiesReportView
	{
		SSecuritiesReportView(CSRSecuritiesReportResultHier * root, const CSRSecuritiesReportFilter * flatFilter);
		~SSecuritiesReportView();
		CSRSecuritiesReportResultHier * fRoot;
		HierCache fHierCache;
		//ResultCache fParentCache;
		double fBuildTime;
		_STL::set<long> fSicovamList;//used in the partial refresh
		int fSortField;
		bool fSortDirection;
		CSRSecuritiesReportFilter * fFlatFilter;
		bool fIsDirty;
	};	
	
	/** Internal, maps criteria key into hierarchical view. */
	typedef _STL::map<SCriteriaKey, SSecuritiesReportView*> MCriteriaView;

	/** Refresh Date. */
	void RefreshDate(long date);

	/** Returns report date. */
	inline long GetReportDate() const {	return fDate; }
	/** Returns date type as specified for this report. */
	inline eSecuritiesExtractionType GetDateType() const { return fDateType; }
	/** Returns parameters as specified for this report. */
	inline const CSRSecuritiesReportParam * GetParam() const { return fParam; }
	/** Returns factory used to build this report. */
	inline const CSRSecuritiesReportFactory & GetFactory() const { return *fFactory; }
	/** Returns model (of the factory) used to build this report or 0 (null) if not applicable, if invoked with non-registered factory. */
	const char* GetModel() const;

	/** Call CSRInstrument::GetInstance() for all instruments mentioned in #fResult.
	 */
	void LoadAllInstrumentsInformation() const;
	void SetInventory(bool inventory);
	bool IsInventory(){ return fInventory;}
	void SetProjectionDate(long date){ fProjectionDate = date;}
	/** Returns Projection date. */
	inline long GetProjectionDate() const {	return fProjectionDate; }
	_STL::string GetCurrentCriteria(){ return currentCriteria;}
	void SetCurrentCriteria(const _STL::string &criteria){currentCriteria = criteria;}
	_STL::map<int, long> & GetDateMap(){ return fDatesMap;}
	inline void SetReportDate(long date) {	fDate = date; }

	/** Access to flat list results by index. */
	typedef _STL::multimap<long, CSRSecuritiesReportResult*> IndexResultMap;
	typedef _STL::pair<IndexResultMap::const_iterator,IndexResultMap::const_iterator> IndexResultRange;
	/** Range from the instrument index corresponding to the given instrument. */
	IndexResultRange IndexSicovam(long sicovam) const;
	/** Full instrument index range, begin to end. */
	IndexResultRange IndexSicovam() const;
	/** Range from the position id index corresponding to the given position id. */
	IndexResultRange IndexPositionId(sophis::portfolio::PositionIdent positionId) const;
	/** Full position id index range, begin to end. */
	IndexResultRange IndexPositionId() const;
	/** Range from the virtual position id index corresponding to the given virtual position id. */
	IndexResultRange IndexVirtualPositionId(sophis::portfolio::PositionIdent positionId) const;
	/** Full virtual position id index range, begin to end. */
	IndexResultRange IndexVirtualPositionId() const;
	/** Result iterator pointing to the beginning of results. */
	CSRSecuritiesReportResultList::const_iterator GetResultListBegin() const { return fResult.begin(); }
	/** Result iterator pointing to the end of results. */
	CSRSecuritiesReportResultList::const_iterator GetResultListEnd() const { return fResult.end(); }

	/** View (cache) iterator pointing to the end. */
	MCriteriaView::const_iterator GetViewEnd() const;
	/** Get access to the cached view object, if exists. */
	MCriteriaView::const_iterator FindView(const CSRSecuritiesReportResultHier& root) const;

	friend class gridcache::MGC::JMSSecurityInventoryPublisher;
	friend class gridcache::MGC::MGCPortfolioSessionLoaderTask;

protected:
	/** INTERNAL. */
	CSRSecuritiesReportCache *fCache;

	friend class CSRSecuritiesReportResult;
	friend class CSRSecuritiesReportExplanationColumn;
	friend class CSRSecuritiesReportTagMetadataColumn;
	friend class CSRSecuritiesProjectionReport;
	friend class CSRSecuritiesReportDialog;
	friend class CSRSecuritiesReportSourceMgr;
	friend class CSRInventoryReportExplanationColumn;
	friend class CSRInventoryReportDialog;
	friend class CSRSecuritiesReportFlat;
	friend class CSRSecuritiesReportParam;

	CSRSecuritiesReport();
	void Initialize(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long date, eSecuritiesExtractionType dateType, unsigned long flags, bool refresh = true);
	void UpdateDates();

private:

	/** Internal, used for building the result. */
	CSRSecuritiesReportResultHier * GetNode(const CSRSecuritiesReportCriteria * criteria, long code, CSRSecuritiesReportResultHier * parent, const CSRSecuritiesReportCriteriaKey * criteriakey, _STL::vector<long> & codeSequence, HierCache & hiercache) const;

	/** Internal.
	 * This function expects #fResult to be already free from the data
	 * that will be produced by calling the extraction with given param.
	 * @param projectionEndDate if non-zero, a projection starting after #fDate and ending at projectionEndDate is calculated
	 */
	void Refresh(const CSRSecuritiesReportParam& param, bool global, long projectionEndDate = 0);

	void RefreshForInventory(const CSRSecuritiesReportParam& param, bool global);

	/** Clear existing results. */
	void Clear();

	/** Notifies listeners about update. */
	void UpdateListeners();

	/** Notifies listeners about forthcoming update, but before the actual update has been performed. */
	void BeforeUpdateListeners();

	/** Views owned by the report. */
	mutable MCriteriaView fView;

	const void BuildResult(const SCriteriaKey& criteriaKey,
		CSRSecuritiesReportResultList::const_iterator resBegin, CSRSecuritiesReportResultList::const_iterator resEnd,
		SSecuritiesReportView & view, const SSecuritiesReportSourceData* source = 0) const;
	/** Remove results for the instruments in partial update. */
	const void RemoveResults() const;
	/** Add results for the instruments in partial update. */
	const void AddResultsExtra(const SCriteriaKey& criteriaKey, SSecuritiesReportView * view) const;

	/** Flat result list. */
	CSRSecuritiesReportResultList fResult;
	
	/** Factory for handling extractions etc. */
	const CSRSecuritiesReportFactory* fFactory;

	/** Parameters with which the report has been run. */
	CSRSecuritiesReportParam* fParam;

	/** Report date. */
	long fDate;

	/** Report date type. */
	eSecuritiesExtractionType fDateType;

	/** List of listeners. */
	_STL::vector<ISecuritiesReportUpdateListener *> fListeners;

	/** List of transaction delta listeners. */
	_STL::vector<CSRSecuritiesReportDeltaListener *> fDeltaListeners;

	/** Statistics. */
	double fRefreshTime;

	/** Report generation date and time. */
	long fGenerationDate;

	/** Flags, see #FlagsEnum. */
	unsigned long fFlags;

	/** Store the instruments the results of which are updated in partial update. */
	mutable _STL::set<long> fSicovamList;

	bool fInventory;

	/** Report date. */
	long fProjectionDate;

	_STL::string currentCriteria;

	_STL::map<int, long> fDatesMap; 

	/** External data sources manager. */
	CSRSecuritiesReportSourceMgr* fSourceMgr;

	/** Quick access by key = {sicovam}, {positionId}. */
	_STL::multimap<long, CSRSecuritiesReportResult*> fSicovamMap;
	_STL::multimap<long, CSRSecuritiesReportResult*> fPositionIdMap;
	/** Quick access by key = {virtual positionId}. In the case of collateral the position id of the collateral used */
	_STL::multimap<long, CSRSecuritiesReportResult*> fVirtualPositionIdMap;

	/** used as the key for Google Protocol Buffer purpose */
	mutable unsigned long fRowMaximumKey;

	mutable unsigned long fRowMaxRealTimeKey;

	static const char* __CLASS__;
};


	} // collateral
} // sophis
SPH_EPILOG
#endif _SphSecuritiesReport_H_