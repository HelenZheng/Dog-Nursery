#ifndef _SphSecuritiesReportColumn_H_
#define _SphSecuritiesReportColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphSecuritiesReportCommon.h"
#include "SphInc/SphEnums.h"
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG


struct SSCellStyle;
union SSCellValue;
namespace sophis {
	namespace collateral {

/**
 * Macros for handling securities report (position monitor) column prototype implementation.
 * @since 5.3.6
 */
#define DECLARATION_SECURITIES_REPORT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRSecuritiesReportColumn)
#define CONSTRUCTOR_SECURITIES_REPORT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_COLUMN(derivedClass)

/** Installs column in main, explanation, and projectiontabs of the report. */
#define	INITIALISE_SECURITIES_REPORT_COLUMN(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

/** Installs column only in the main tab and not in explanation tab. */
#define	INITIALISE_SECURITIES_REPORT_COLUMN_MAIN(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 1);

/** Installs column only in the explanation tab and not in main tab. */
#define	INITIALISE_SECURITIES_REPORT_COLUMN_EXPLANATION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 2);

/** Installs column only in the projection tab and not in main tab. */
#define	INITIALISE_SECURITIES_REPORT_COLUMN_PROJECTION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 3);

class CSRSecuritiesReportResult;
typedef _STL::list<CSRSecuritiesReportResult*> CSRSecuritiesReportResultList;

/**
 * Securities report (position monitor) column and prototype.
 * 
 * To add a column, derive this class, using the macro DECLARATION_SECURITIES_REPORT_COLUMN in your header
 * and INITIALISE_SECURITIES_REPORT_COLUMN in UNIVERSAL_MAIN.
 *
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportColumn
{
protected:
	/** 
	 * Constructor for inherited classes.
	 * @param group is the name of the group the column belongs to.
	 * @version 6.3
	 */
	CSRSecuritiesReportColumn(const _STL::string& columnGroup) : fId(0), fGroup(columnGroup) {}

public:
	/** Constructor. */
	CSRSecuritiesReportColumn() : fId(0), fGroup("Default") {}

	/** Destructor. */
	virtual ~CSRSecuritiesReportColumn() {}

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param securities report line to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCell(const CSRSecuritiesReportResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/**
	 * Clone method required by the prototype.
	 * Use DECLARATION_SECURITIES_REPORT_COLUMN macro in the implementation of the derived class.
	 */
	virtual CSRSecuritiesReportColumn* Clone() const = 0;

	/** 
	 * Returns the default cell size in pixels.
	 */
	virtual short GetDefaultWidth() const;

	/**
	 * Returns icon that is displayed in tree view when grouped by this column
	 */
	virtual short GetIconId() const;

	/**
	 * Indicates if given column can be used as a criteria for grouping (not applicable to all reports).
	 * @version 6.3.2
	 */
	virtual bool CanGroup() const;

	/**
	 * Checks if GetAggregatedCell() is applicable for this column (not applicable to all reports).
	 * @version 6.3.2
	 */
	virtual bool CanAggregate() const;

	/**
	 * Custom aggregated cell.
	 * @param resultList Flat list of all elements in the node.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @version 6.3.2
	 */
	virtual void GetAggregatedCell(const CSRSecuritiesReportResultList& resultList, SSCellValue *value, SSCellStyle *style) const;

	/**
	 * For use with grouping.
	 * Columns of certain cell types can be used as criteria.
	 * @return Cell data type; NSREnums::dSmallIcon means the cell type is undefined, not applicable.
	 */ 
	virtual NSREnums::eDataType GetCellType() const;

	/**
	 * Returns the id.
	 * The value is created at the end of the initialise because it must
	 * be unique according to the table COLUMN_NAME.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * Used when building the columns by {@link CSUReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

	/**
	 * Returns the name of the column group for the given column.
	 * @version 6.3
	 */
	const _STL::string& GetColumnGroup() const
	{
		return fGroup;
	}

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototypeWithId<CSRSecuritiesReportColumn, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to prototype singleton.
	 */
	static prototype& GetPrototype(long type = 0);

	/**
	 * Fills cell value and style with given quantity in given currency.
	 * Useful for GUI display.
	 * @param x Amount in given currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the instrument for the amount.
	 */
	static void FillQuantity(double x, SSCellValue *value, SSCellStyle *style, long ccy);

	/**
	 * Fills cell value and style with string representation of given currency.
	 * Useful for GUI display.
	 * @param ccy Currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillCurrency(long ccy, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills cell value and style with given date.
	 * Useful for GUI display.
	 * @param date Date to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills style for display of a double value.
	 * Useful for GUI display.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the double value.
	 * @param dec Number of decimals to be displayed.
	 */
	static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

	/** Find out if the instrument of given result is not fully loaded.
	 * CSRSecuritiesReportResult::GetSecuritiesCode() is used on given result.
	 * Meant to be called from GetCell().
	 * @note If there is no instrument set in the result, false is returned.
	 */
	static bool InstrNotLoaded(const CSRSecuritiesReportResult& result);

	/** Fill a cell with "<Load Instrument>".
	 * Meant to be called from GetCell().
	 */
	static void FillWithLoadInstr(SSCellValue* value, SSCellStyle* style);

	/** Fills aggregated cell as sum of flat list values.
	 * @version 6.3.2
	 */
	static void AggregatedCellSum(const CSRSecuritiesReportColumn& column, const CSRSecuritiesReportResultList& resultList, SSCellValue *value, SSCellStyle *style);

	/** Fills aggregated cell if all the cells have the same value.
	 * @version 6.3.2
	 */
	static void AggregatedCellSame(const CSRSecuritiesReportColumn& column, const CSRSecuritiesReportResultList& resultList, SSCellValue *value, SSCellStyle *style);

	/** Internal. */
	static void RefreshPrototype();

	/** Internal */
	static void CleanUpPrototypes();

protected:
	long	fId;
	_STL::string fGroup;
};

	} // namespace collateral
} // namespace sophis


SPH_EPILOG
#endif
