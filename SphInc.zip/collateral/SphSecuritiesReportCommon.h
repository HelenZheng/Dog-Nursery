#ifndef _SphSecuritiesReportCommon_H_
#define _SphSecuritiesReportCommon_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

template  <class _Derivate>
struct install
{
	install(const typename _Derivate::prototype::key_type & k, long type)
	{
		_Derivate *clone = new _Derivate;
		_Derivate::GetPrototype(type).insert(k,clone);
	}
};

	} // namespace collateral
} // namespace sophis

SPH_EPILOG
#endif
