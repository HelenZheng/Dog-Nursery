#ifndef _SphSecuritiesReportContextMenu_H_
#define _SphSecuritiesReportContextMenu_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphSecuritiesReportCommon.h"
#include "SphInc/gui/SphTabButton.h"
#include __STL_INCLUDE_PATH(list)

SPH_PROLOG
namespace sophis {

	namespace collateral {

class CSRSecuritiesReportResult;
typedef _STL::list<CSRSecuritiesReportResult*> CSRSecuritiesReportResultList;

/**
 * Macros for handling securities report (position monitor) context menu prototype implementation.
 * @param derivedClass is the name of the client custom context menu class.
 * @version 5.3.6
 */
#define DECLARATION_SECURITIES_REPORT_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRSecuritiesReportContextMenu)
#define CONSTRUCTOR_SECURITIES_REPORT_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_CONTEXT_MENU(derivedClass)

/** Installs context menu both main and explanation tabs of the report. */
#define	INITIALISE_SECURITIES_REPORT_CONTEXT_MENU(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 1);\
	derivedClass::GetPrototype(1).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);\
	sophis::collateral::install<derivedClass >(name, 2);\
	derivedClass::GetPrototype(2).GetData(name)->SetId(sophis::collateral::CSRSecuritiesReportContextMenu::fCount);

/** Installs context menu only in the main tab and not in explanation tab. */
#define	INITIALISE_SECURITIES_REPORT_CONTEXT_MENU_MAIN(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 1);\
	derivedClass::GetPrototype(1).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);

/** Installs context menu only in the explanation tab and not in main tab. */
#define	INITIALISE_SECURITIES_REPORT_CONTEXT_MENU_EXPLANATION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 2);\
	derivedClass::GetPrototype(2).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);

/** Installs context menu for all the tabs(main, explanation & projection. */
#define	INITIALISE_SECURITIES_REPORT_CONTEXT_MENU_ALL(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 1);\
	derivedClass::GetPrototype(1).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);\
	sophis::collateral::install<derivedClass >(name, 2);\
	derivedClass::GetPrototype(2).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);\
	sophis::collateral::install<derivedClass >(name, 3);\
	derivedClass::GetPrototype(3).GetData(name)->SetId(++sophis::collateral::CSRSecuritiesReportContextMenu::fCount);



/**
 * Interface for the window context passed to various methods,
 * Used for communication between C# and C++ dialogs
 * @version 7.1
 */
class SOPHIS_COLLATERAL_GUI ISecuritiesReportWindowContext
{
public:
	/* Identifies the type of window */
	virtual bool IsLegacyWindow(){ return true;}

	/* Redraws the window using the context*/
	virtual void Redraw(){}

	virtual ~ISecuritiesReportWindowContext(){}
};

/**
 * Interface for creating custom context menu in Securities Report window.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRSecuritiesReportContextMenu
{
public:

	/**
	 * Returns the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	void SetId(long id) const
	{
		(const_cast<CSRSecuritiesReportContextMenu*>(this))->fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototypeWithId<CSRSecuritiesReportContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
	 */
	static prototype& CSRSecuritiesReportContextMenu::GetPrototype(long type = 0);

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsAuthorized returns true, the key of the prototype (that is its name) is added in the context menu.
	 * Must be overloaded and implemented in custom classes.
	 * @param account The securities report line on which the context menu is called.
	 * @return true to include the prototype in the context menu, false to skip it.
	 */
	virtual bool IsAuthorized(ISecuritiesReportWindowContext &windowContext, const CSRSecuritiesReportResultList& resultList) const = 0;

	/** 
	* This function is called when opening the dynamic context menu. 
	* If IsEnabled returns true, the key of the prototype (that is its name) is enabled in the context menu.
	* User should generally override IsEnabled().
	* @param account The securities report line on which the context menu is called.
	* @return true to enabled the prototype in the context menu, false to disable it.
	*/
	virtual bool IsEnabled(ISecuritiesReportWindowContext &windowContext, const CSRSecuritiesReportResultList& resultList) const { return true; }

	/**
	 * Perform some action (like open a specific dialog) using the given results line.
	 * Must be overloaded and implemented in custom classes.
	 * @param account The treasury account line on which the context menu is called.
	 * @param menuLabel The actual context menu label that was selected.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoSecuritiesReportContextMenu(ISecuritiesReportWindowContext &windowContext, const CSRSecuritiesReportResultList& resultList, _STL::string& menuLabel) const = 0;

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }

	/**
	* Counts the number of prototypes installed and assigns each prototype a number in sequence.
	* For internal use.
	*/
	static long fCount;

protected:
	long fId;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphSecuritiesReportContextMenu_H_
