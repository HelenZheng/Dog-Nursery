#ifndef _SphSecuritiesReportCriteria_H_
#define _SphSecuritiesReportCriteria_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

struct SSCellStyle;
union SSCellValue;

namespace sophis {
	namespace collateral {

/**
 * Macros for handling securities report (position monitor) derived
 * classes and prototype.
 * @version 5.3.6
 */
#define DECLARATION_SECURITIES_REPORT_CRITERIA(derivedClass)\
	public:\
		derivedClass();\
		virtual  sophis::collateral::CSRSecuritiesReportCriteria* Clone() const { derivedClass* c = new derivedClass(); c->Initialise(*this); return c; }
#define CONSTRUCTOR_SECURITIES_REPORT_CRITERIA(derivedClass)\
	derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_CRITERIA(derivedClass)
#define	INITIALISE_SECURITIES_REPORT_CRITERIA(derivedClass,name)\
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::collateral::CSRSecuritiesReportCriteria*>(sophis::collateral::CSRSecuritiesReportCriteria::GetPrototype().GetData(name))->SetName(name);

/**
 * Macros for installing a chained criteria.
 * @version 6.3
 */
#define	INITIALISE_SECURITIES_REPORT_CHAIN_CRITERIA(derivedClass,name)\
	sophis::collateral::CSRSecuritiesReportCriteria::InstallChainCriteria(new derivedClass(), name);\
	const_cast<sophis::collateral::CSRSecuritiesReportCriteria*>(sophis::collateral::CSRSecuritiesReportCriteria::GetPrototype().GetData(name))->SetName(name);


class CSRSecuritiesReportResult;

/**
 * Criteria for controlling securities report (position monitor) view and aggregation.
 * 
 * To add a criteria, derive this class, using the macro
 * DECLARATION_SECURITIES_REPORT_CRITERIA in your header and
 * INITIALISE_SECURITIES_REPORT_CRITERIA in UNIVERSAL_MAIN.
 *
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteria
{
public:

	/** Constructor. */
	CSRSecuritiesReportCriteria();

	/** Destructor. */
	virtual ~CSRSecuritiesReportCriteria();

	/** Clone interface. */
	virtual CSRSecuritiesReportCriteria* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRSecuritiesReportCriteria& criteria);

	enum esrCriteria
	{
		/** Value to specify that a criteria is undefined for given result. */
		kUndefined = -1,
	};

	/** Get the criteria code corresponding to a given result. */
	virtual long GetCode(const CSRSecuritiesReportResult& result) const = 0;

	/** Get the criteria parent code if it is part of the criteria.
	 * @param code Criteria code. */
	virtual long GetParentCode(long code) const { return 0;	}

	/** Create a vector with all the parents of a criteria.
	 * @param code Criteria code. */
	_STL::vector<long> GetCodeSequence(long code) const;

	/** Get the name of the criteria.
	 * @param code Criteria code.
	 * @param name Output string (name of the criteria). */
	virtual void GetName(long code, _STL::string& name) const = 0;

	/** Get the icon id for the criteria. */
	virtual long GetIcone() const { return 200; }

	/** Get the portfolio code of the criteria.
	 * @param code Criteria code.
	 * @return Portfolio code (id) or 0 if this is not a portfolio. */
	virtual long GetPortfolioId(long code) const { return 0; }

	/** Get the instrument code of the criteria.
	 * @param code Criteria code.
	 * @return Instrument code or 0 if this is not an instrument criteria. */
	virtual long GetInstrumentCode(long code) const { return 0; }

	/** Compare two criteria codes.
	 * This method is used to sort the results.
	 * @param code1 First criteria code.
	 * @param code2 Second criteria code.
	 * @return true if the criteria code1 is less than the
	 * criteria code2. */
	virtual bool less(long code1, long code2) const;

#ifndef GCC_XML
	/** Compare function definition. */
	typedef short (*NameComparator)(const char*, const char*);

	/** Return function to perform name comparison. */
	virtual NameComparator GetNameComparator() const;
#endif

	/** Flag indicating if node corresponding to given criteria is expandable or not.
	 * Default is false, which means the node is expandable.
	 * @return true if the node for this criteria is not expandable (children are hidden/unavailable); false for normal node (default). */
	virtual bool IsNotExpandable() const { return false; }

	/** Flag indicating if criteria should be available for use in the 'custom' criteria set.
	 * Default is true, which means it will show up in the custom criteria options list.
	 * @param model Model of the report.
	 * @return true (default) for this criteria to be present in the custom criteria options list. */
	virtual bool UseInCustomCriteria(const char* model) const { return true; }

	/**
	 * A way of displaying criteria value in a cell.
	 * Default implementation assumes the result is a string and calls GetName(long code, _STL::string& name).
	 * @version 6.3
	 */
	virtual void GetCell(long code, SSCellValue *value, SSCellStyle *style) const;

	/** Returns the name of the criteria. */
	const char* GetName() const { return fName.c_str(); }

	/** Sets the name of the criteria. */
	void SetName(const char* name) { fName = name; }

	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRSecuritiesReportCriteria, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();

	/** Get the nth criteria of the prototype.
	 * @param index Starts from zero.
	 * @return Criteria object or 0 if out of bounds. */
	static const CSRSecuritiesReportCriteria* GetCriteria(int index);

	/** Get the criteria from the prototype by name.
	 * @param name Criteria name.
	 * @return Criteria object or 0 if out of bounds. */
	static const CSRSecuritiesReportCriteria* GetCriteria(_STL::string& name);

	/** Get the index of given criteria in the prototype by name.
	 * @param name Criteria name.
	 * @return Index in the prototype or -1 if does not exist. */
	static int GetCriteriaIndex(_STL::string& name);

	/** Get the nth criteria name from the prototype.
	 * @param index Starts from zero.
	 * @return Criteria name or empty string if does not exist. */
	static _STL::string GetCriteriaName(int index);

	/**
	 * Installs "chain" criteria which allows same criteria name to be shared between multiple sources.
	 * @version 6.3
	 */
	static void InstallChainCriteria(CSRSecuritiesReportCriteria* criteria, const char* name);

protected:
	_STL::string fName;
};

	} // namespace collateral
} // namespace sophis

SPH_EPILOG
#endif
