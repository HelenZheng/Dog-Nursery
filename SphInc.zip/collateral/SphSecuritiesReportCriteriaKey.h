#ifndef _SphSecuritiesReportCriteriaKey_H_
#define _SphSecuritiesReportCriteriaKey_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReportCriteria;
class CSRSecuritiesReportResult;

typedef _STL::vector<CSRSecuritiesReportCriteria*> CSRSecuritiesReportCriteriaList;

/**
 * Criteria key for handling grouping and aggregation in securities report (position monitor).
 *
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaKey
{
public:
	/** Constructor. */
	CSRSecuritiesReportCriteriaKey();

	/** Constructor. */
	CSRSecuritiesReportCriteriaKey(const CSRSecuritiesReportCriteriaList& criteriaList);

	/** Destructor. */
	~CSRSecuritiesReportCriteriaKey();

	/** Clone interface. */
	CSRSecuritiesReportCriteriaKey* Clone() const;

	/** Destructor. */
	void Initialise(const CSRSecuritiesReportCriteriaList& criteriaList);

	/** Check if the object is included in the key.
	 * @param key Key. */
	bool In(const CSRSecuritiesReportCriteriaKey& key) const;

	/** Compare this value to key.
	 * @param key Key. */
	bool Equal(const CSRSecuritiesReportCriteriaKey& key) const;

	/** Criteria list. */
	CSRSecuritiesReportCriteriaList fCriteriaList;

	/** Value for each criteria.
	 * kUndefined means the criteria is undefined; 0 means there is no value. */
	_STL::vector<long> fCriteriaCode;

};

/**
 * Collection of views (criteria keys) for the securities report.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportView : public tools::CSRPrototype<CSRSecuritiesReportCriteriaKey, const char*, tools::less_char_star>
{
protected:
	CSRSecuritiesReportView() {}
public:
	/** Adds given criteria key to the prototype. 
	 * @param name view name
	 * @param criteriaKey view details (list of criteria)
	 * @param model If set, only registers view for particular report model (default is all models). */
	virtual void InitialisePrototype(const char* name, const CSRSecuritiesReportCriteriaKey& criteriaKey, const char* model = 0) = 0;

	/** Internal. For use with custom criteria. */
	void ReplaceItem(const char* name, const CSRSecuritiesReportCriteriaKey& criteriaKey);
	void DeleteItem(const char* name);

	/** Internal. */
	static void RefreshPrototype();
};

/**
 * Prototype containing all views for main tab of securities report.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportViewMain : public virtual CSRSecuritiesReportView
{
protected:
	CSRSecuritiesReportViewMain() {}

public:
	/** Access to the prototype singleton. 
	 * @param model If present, only returns views suitable for given model (default is return all). */
	static CSRSecuritiesReportViewMain& GetPrototype(const char* model = 0);

	/** Adds given criteria key to the prototype. */
	virtual void InitialisePrototype(const char* name, const CSRSecuritiesReportCriteriaKey& criteriaKey, const char* model = 0);
};

/**
 * Prototype containing all views for explanation tab of securities report.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportViewExplanation : public virtual CSRSecuritiesReportView
{
protected:
	CSRSecuritiesReportViewExplanation() {}

public:
	/** Access to the prototype singleton.
	 * @param model If present, only returns views suitable for given model (default is return all). */
	static CSRSecuritiesReportViewExplanation& GetPrototype(const char* model = 0);

	/** Adds given criteria key to the prototype. */
	virtual void InitialisePrototype(const char* name, const CSRSecuritiesReportCriteriaKey& criteriaKey, const char* model = 0);
};


/**
* Prototype containing all views for projection tab of securities report.
* @version 5.3.6
*/
class SOPHIS_COLLATERAL CSRSecuritiesReportViewProjection : public virtual CSRSecuritiesReportView
{
protected:
	CSRSecuritiesReportViewProjection() {}

public:
	/** Access to the prototype singleton.
	 * @param model If present, only returns views suitable for given model (default is return all). */
	static CSRSecuritiesReportViewProjection& GetPrototype(const char* model = 0);

	/** Adds given criteria key to the prototype. */
	virtual void InitialisePrototype(const char* name, const CSRSecuritiesReportCriteriaKey& criteriaKey, const char* model = 0);
};

#ifndef GCC_XML

/// INTERNAL.
class CSRSecuritiesReportCriteriaKeyBuilder;

/**
 * Utility class to build "views" (criteria keys) from the specified criteria list.
 * 
 * Example of usage:
 * const char *criteria[] = { "Instrument", "Portfolio", 0 };
 * CSRSecuritiesReportCriteriaKeyBuilderUtil builderUtil;
 * CSRSecuritiesReportViewMain::GetPrototype().InitialisePrototype("My View", builderUtil.GetCriteriaKey(criteria));
 * 
 * @version 7.0
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaKeyBuilderUtil
{
public:
	CSRSecuritiesReportCriteriaKeyBuilderUtil();
	~CSRSecuritiesReportCriteriaKeyBuilderUtil();
	/** Generates criteria key based on the list of criteria. */
	const CSRSecuritiesReportCriteriaKey& GetCriteriaKey(const char *criteriaList[]);
private:
	CSRSecuritiesReportCriteriaKeyBuilder *fBuilder;
};

#endif

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif
