#pragma once

#ifndef _SphSecuritiesReportDeltaListener_H_
#define _SphSecuritiesReportDeltaListener_H_

#include "SphInc/SphMacros.h"

namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace collateral {

class CSRSecuritiesReport;
class CSRSecuritiesReportResult;

/**
 * Listener framework for Securities Report to help manage information in real-time.
 * Acts as a bridge between CSRTransactionEvent and Securities Report.
 * @version 6.2.2
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportDeltaListener
{
public:
	/** Trivial Constructor. */
	CSRSecuritiesReportDeltaListener();
	/** Trivial Destructor. */
	virtual ~CSRSecuritiesReportDeltaListener();

	/**
	 * Invoked to provide information of what will be the delta change (new transaction) to the given securities report.
	 * @param report Securities report, it has not been updated.
	 * @param newResult Representation of newly created transaction record for the securities report.
	 * @param transaction Newly created transaction.
	 */
	virtual bool HasBeenCreated(CSRSecuritiesReport& report,
		const CSRSecuritiesReportResult* newResult,
		const portfolio::CSRTransaction& transaction
		) = 0;

	/**
	 * Invoked to provide information of what will be the delta change (new transaction) to the given securities report.
	 * @param report Securities report, it has not been updated.
	 * @param oldInvertedResult Old (original, inverted) representation of updated transaction report for the securities report.
	 * @param oldResult Old (original) representation of updated transaction report for the securities report.
	 * @param newResult New (modified) representation of updated transaction record for the securities report.
	 * @param original Original transaction being modified.
	 * @param transaction Updated transaction.
	 */
	virtual bool HasBeenModified(CSRSecuritiesReport& report,
		const CSRSecuritiesReportResult* oldInvertedResult,
		const CSRSecuritiesReportResult* oldResult,
		const CSRSecuritiesReportResult* newResult,
		const portfolio::CSRTransaction& original,
		const portfolio::CSRTransaction& transaction
		) = 0;

	/**
	 * Invoked to provide information of what will be the delta change (DELETED transaction) to the given securities report.
	 * @param report Securities report, it has not been updated.
	 * @param oldInvertedResult Old (original, inverted) representation of updated transaction report for the securities report.
	 * @param oldResult Representation of deleted transaction record for the securities report.
	 * @param transaction Deleted transaction.
	 */
	virtual bool HasBeenDeleted(CSRSecuritiesReport& report,
		const CSRSecuritiesReportResult* oldInvertedResult,
		const CSRSecuritiesReportResult* oldResult,
		const portfolio::CSRTransaction& transaction
		) = 0;
};

	} // collateral
} // sophis

SPH_EPILOG

#endif _SphSecuritiesReportDeltaListener_H_