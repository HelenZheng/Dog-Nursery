#pragma once
#ifndef _SphSecuritiesReportExtraParamDialog_H_
#define _SphSecuritiesReportExtraParamDialog_H_

#ifndef GCC_XML

#include "SphInc/gui/SphDialog.h"
#include "SphInc/collateral/SphSecuritiesReportParam.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Interface for custom (extra, additional) parameters dialog for the securities report.
 * Extra parameters and the dialog are optional.
 * They come as addition to the main report parameters.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportExtraParamDialog : public sophis::gui::CSRFitDialog
{
public:
	/** Constructor. */
	CSRSecuritiesReportExtraParamDialog();
	/** Destructor. */
	virtual ~CSRSecuritiesReportExtraParamDialog();

	/** 
	 * Fill given securities report extra parameters with the dialog data.
	 * This method is called when the parameters object needs to be updated from the displayed data.
	 * @param extraParam Parameters object being edited.
	 * @return A boolean that described the state of the update.
	 */
	virtual bool FillDataFromDialog(CSRSecuritiesReportExtraParam& extraParam) = 0;

	/** 
	 * Fill the dialog data based on the given securities report extra parameters.
	 * This method is called when the dialog needs to be initialised (updated) from the parameters object.
 	 * @param extraParam Parameters object being edited.
	 * @return A boolean that described the state of the update.
	 */
	virtual bool FillDialogFromData(const CSRSecuritiesReportExtraParam& extraParam) = 0;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // GCC_XML
#endif // _SphSecuritiesReportExtraParamDialog_H_