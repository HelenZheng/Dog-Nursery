#ifndef _SphSecuritiesReportFactory_H_
#define _SphSecuritiesReportFactory_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphSecuritiesExtraction.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace collateral {

class CSRSecuritiesExtraction;
class CSRSecuritiesReportParam;
class CSRSecuritiesReportResult;
class CSRSecuritiesReportResultHier;
class CSRSecuritiesExtractionTrade;
class CSRSecuritiesReportCriteria;
class CSRSecuritiesReportCriteriaKey;
class CSRSecuritiesReportStatusAvailability;

/**
 * Macro to be used instead of the Clone() method in the clients classes derived from CSRSecuritiesReportFactory.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_SECURITIES_REPORT_FACTORY(derivedClass) \
	public: \
		derivedClass(); \
		virtual sophis::collateral::CSRSecuritiesReportFactory* Clone() const { derivedClass* c = new derivedClass(); c->Initialise(*this); return c; }
#define CONSTRUCTOR_SECURITIES_REPORT_FACTORY(derivedClass) \
	derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_FACTORY(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 */
#define	INITIALISE_SECURITIES_REPORT_FACTORY(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass, name)\
	const_cast<sophis::collateral::CSRSecuritiesReportFactory*>(sophis::collateral::CSRSecuritiesReportFactory::GetPrototype().GetData(name))->SetName(name);

/**
 * Securities report factory.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportFactory
{
public:
	/** Constructor. */
	CSRSecuritiesReportFactory() {}

	/** Destructor. */
	virtual ~CSRSecuritiesReportFactory() {}

	/** Clone interface. */
	virtual CSRSecuritiesReportFactory* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRSecuritiesReportFactory& factory);

	/** 
	 * Typedef for the prototype; the key is a const char*.
	 */
	typedef tools::CSRPrototype<CSRSecuritiesReportFactory, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_SECURITIES_REPORT_FACTORY
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/** Extraction. */
	virtual CSRSecuritiesExtraction* new_SecuritiesExtraction() const = 0;

	/** Result (calculation). */
	virtual CSRSecuritiesReportResult* new_SecuritiesReportResult(CSRSecuritiesExtractionTrade * trade = 0) const = 0;
	virtual CSRSecuritiesReportResultHier * new_SecuritiesReportResultHier(CSRSecuritiesReportResultHier * parent = 0, const CSRSecuritiesReportCriteriaKey * criteriaKey = 0, const CSRSecuritiesReportCriteria * criteria = 0, long code = 0) const = 0;

	/** Parameters and dialog for their input. */
	virtual CSRSecuritiesReportParam* new_SecuritiesReportParam() const = 0;

	/** Status and availability. */
	virtual CSRSecuritiesReportStatusAvailability* new_SecuritiesReportStatusAvailability() const;

	/** Return set of supported extraction types (eSecuritiesExtractionType). By default support all. */
	virtual void GetSecuritiesExtractionTypes(_STL::vector<int>& extractionTypes) const;

	/** Build result from given transaction, if applicable. 
	 * By default, uses extraction's new_SecuritiesExtractionTrade() and then calls new_SecuritiesReportResult(trade).
	 * Caller is responsible for the returned pointer (can be NULL).
	 * @param transaction Transaction to be converted to result object.
	 * @param dateType Which quantities to use.
	 * @param securitiesCode Optional, equity (or underlying in case of Stock Loan) code to use; if not specified, fetch from transaction.
	 * @param invertQuantities If quantities of result object should be straight or inverted.
	 */
	virtual CSRSecuritiesReportResult* new_SecuritiesReportResult(const portfolio::CSRTransaction& transaction,
		eSecuritiesExtractionType dateType,
		long securitiesCode, bool invertQuantities) const;

	/** Returns the name of the factory model. */
	const char* GetName() const { return fName.c_str(); }

	/** Sets the name of the factory model. */
	void SetName(const char* name) { fName = name; }

protected:
	_STL::string fName;

};

	}
}
SPH_EPILOG
#endif _SphSecuritiesReportFactory_H_