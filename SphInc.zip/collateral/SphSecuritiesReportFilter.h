#ifndef _SphSecuritiesReportFilter_H_
#define _SphSecuritiesReportFilter_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphSecuritiesReportCommon.h"

/**
 * Macros for handling securities report (position monitor) user interface level filtering 
 * implementation and prototype.
 * @since 5.3.6
 */
#define DECLARATION_SECURITIES_REPORT_FILTER(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRSecuritiesReportFilter)
#define CONSTRUCTOR_SECURITIES_REPORT_FILTER(derivedClass)
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_FILTER(derivedClass)

/** Installs filter in all tabs of the report. */
#define	INITIALISE_SECURITIES_REPORT_FILTER(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

/** Installs filter only in the main tab and not in explanation tab. */
#define	INITIALISE_SECURITIES_REPORT_FILTER_MAIN(derivedClass, name)\
	sophis::collateral::install<derivedClass>(name, 1);

/** Installs filter only in the explanation tab and not in main tab. */
#define	INITIALISE_SECURITIES_REPORT_FILTER_EXPLANATION(derivedClass, name)\
	sophis::collateral::install<derivedClass>(name, 2);

/** Installs column only in the projection tab and not in main tab. */
#define	INITIALISE_SECURITIES_REPORT_FILTER_PROJECTION(derivedClass, name)\
	sophis::collateral::install<derivedClass >(name, 3);

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReportResult;
class CSRSecuritiesReportResultHier;

/**
 * Securities report (position monitor) user interface result filtering.
 * 
 * To add a criteria, derive this class, using the macro DECLARATION_SECURITIES_REPORT_FILTER in your header
 * and INITIALISE_SECURITIES_REPORT_FILTER in UNIVERSAL_MAIN.
 *
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportFilter
{
public:
	virtual ~CSRSecuritiesReportFilter();

	/** 
	 * Check if given result object should be displayed or not.
	 * Must be implemented in derived classes.
	 * @param result Result object to be or not to be displayed on the ui.
	 * @return true to hide from display; false to do nothing (keep).
	 */
	virtual bool IsExcluded(const CSRSecuritiesReportResult & result) const = 0;

	/**
	 * Clone method required by the prototype.
	 * Use DECLARATION_SECURITIES_REPORT_FILTER macro in the implementation of the derived class.
	 */
	virtual CSRSecuritiesReportFilter* Clone() const = 0;

	/**
	 * Checks if all the children of the given hierarchical result are also excluded by the filter.
	 * @return true if node is non-hierarchical node; otherwise check through all the children.
	 */
	virtual bool AreChildrenExcluded(const CSRSecuritiesReportResult & result) const;

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototype<CSRSecuritiesReportFilter, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to prototype singleton.
	 */
	static prototype& GetPrototype(long type = 0);

	/**
	 * Returns default filter for each tab type.
	 */
	static const CSRSecuritiesReportFilter& GetDefaultFilter(long type);

	/** Internal. */
	static void RefreshPrototype();

	/** Internal */
	static void CleanUpPrototypes();
};

/**
 * Interface for securities report (position monitor) filter that filters out the leaf (position) nodes.
 * Only hierarchical nodes are to be checked.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportPositionFilter : public virtual CSRSecuritiesReportFilter
{
public:
	/** Returns true for non-hierarchical (position) result and calls IsHierExcluded() for hierarchical nodes. */
	virtual bool IsExcluded(const CSRSecuritiesReportResult & result) const;

	/** Check if given hierarchical result object should be displayed or not.
	 * Must be implemented in derived classes.
	 * @param result Hierarchical result object to be or not to be displayed on the ui.
	 * @return true to hide from display; false to do nothing (keep).
	 */
	virtual bool IsHierExcluded(const CSRSecuritiesReportResultHier & result) const = 0;
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphSecuritiesReportFilter_H_