#ifndef _SphSecuritiesReportFlat_H_
#define _SphSecuritiesReportFlat_H_

#include "SphInc/collateral/SphSecuritiesReport.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Flat representation of securities inventory report for use with real-time and simulation.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportFlat : public virtual CSRSecuritiesReport
{
public:
	/** Constructor.
	 * @param factory Factory (model).
	 * @param param Report parameters (become owned by the report).
	 * @param reportingDate Report date.
	 * @param endDate Collection information until which date.
	 * @param dateType Report date type.
	 * @param flags Flags to pass to the report.
	 * @param realTime If the report should subscribe to real-time updates.
	 */
	CSRSecuritiesReportFlat(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long reportingDate, long endDate, eSecuritiesExtractionType dateType, unsigned long flags, bool realTime);

	/** Destructor. */
	virtual ~CSRSecuritiesReportFlat();

	/** Reload the complete report. */
	void Refresh();

	/** Append given result to list of results. The report becomes owner of the result object. */
	void AppendResult(CSRSecuritiesReportResult* result);

	/** Clear existing results. */
	void Clear();

	/** Returns timestamp of last call to Refresh(). */
	long GetLastRefresh() const { return fLastRefresh; }

	/** Returns timestamp of last call to AppendResult(). */
	long GetLastAppend() const { return fLastAppend; }

	/** Remove given result from the list of results. */
	void RemoveResult(CSRSecuritiesReportResult* result);

protected:
	/** INTERNAL. */
	CSRSecuritiesReportFlat();
	void Initialize(const CSRSecuritiesReportFactory& factory, CSRSecuritiesReportParam * param,
		long reportingDate, long endDate, eSecuritiesExtractionType dateType, unsigned long flags, bool realTime);

	/// Timestamp of when full refresh was performed
	long fLastRefresh;
	/// Timestamp of when last append result was done
	long fLastAppend;

private:
	static const char* __CLASS__;
};

	} // collateral
} // sophis

SPH_EPILOG
#endif // _SphSecuritiesReportFlat_H_