#ifndef _SphSecuritiesReportGenericCriteria_H_
#define _SphSecuritiesReportGenericCriteria_H_

#include "SphInc/collateral/SphSecuritiesReportCriteria.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReport;

/**
 * Instrument criteria for securities report (position monitor).
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaInstrument : public virtual CSRSecuritiesReportCriteria
{
public:
	DECLARATION_SECURITIES_REPORT_CRITERIA(CSRSecuritiesReportCriteriaInstrument)

	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual long GetIcone() const;
	virtual long GetInstrumentCode(long code) const { return code; }
	virtual bool less(long code1, long code2) const;
};

/**
 * Portfolio criteria for securities report (position monitor).
 * Can be extended to provide customised portfolio view.
 *
 * Example showing only top two folio levels:
 * <code>
 * long CSRSecuritiesReportCriteriaFolio2::GetCode(const CSRSecuritiesReportResult& result) const
 * {
 *   long code = CSRSecuritiesReportCriteriaFolio::GetCode(result);
 *   if (code == kUndefined)
 *     return code;
 *   _STL::vector<long> seq;
 *   _STL::vector<long>::iterator it = seq.insert(seq.begin(), code);
 *   while (code=CSRSecuritiesReportCriteriaFolio::GetParentCode(code))
 *     it = seq.insert(it, code);
 *   return seq.size() >= 2 ? seq[1] : seq[0];
 * }
 * </code>
 *
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaFolio : public virtual CSRSecuritiesReportCriteria
{
public:
	DECLARATION_SECURITIES_REPORT_CRITERIA(CSRSecuritiesReportCriteriaFolio)

	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual long GetParentCode(long code) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual long GetIcone() const;
	virtual long GetPortfolioId(long code) const { return code; }
};

/**
 * Date criteria for securities report (position monitor).
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaDate : public virtual CSRSecuritiesReportCriteria
{
public:
	DECLARATION_SECURITIES_REPORT_CRITERIA(CSRSecuritiesReportCriteriaDate)

	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual long GetIcone() const;
	virtual bool UseInCustomCriteria(const char* model) const;

	/** Indicates if projection quantities need to be calculated and applied for given report.
	 * @version 7.1.1 */
	virtual bool AddProjectionQuantities(const CSRSecuritiesReport& report) const { return false; }
	/** Indicates the start date from which quantities from different dates must not be aggregated.
	 * @version 7.1.1 */
	virtual long GetProjectionStartDate() const { return 0; }
};


/**
* Currency criteria for securities report (position monitor).
* @since 5.3.6.13
*/
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaCurrency : public virtual CSRSecuritiesReportCriteria
{
public:
	DECLARATION_SECURITIES_REPORT_CRITERIA(CSRSecuritiesReportCriteriaCurrency)

	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual long GetIcone() const;
	virtual bool less(long code1, long code2) const;
};

/**
 * Utility class to provide easy way of building criteria which are string based.
 * To avail of this functionality the criteria must be registered using INITIALISE_SECURITIES_REPORT_CRITERIA.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaString : public virtual CSRSecuritiesReportCriteria
{
public:
	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual void GetName(long code, _STL::string& name) const;
	virtual bool less(long code1, long code2) const;

	/** Get the criteria string corresponding to a given result. */
	virtual _STL::string GetStringCode(const CSRSecuritiesReportResult& result) const = 0;

	/** Get the name of the criteria. By default returns the criteria string.
	 * @param str Criteria string.
	 * @param name Output string (name of the criteria). */
	virtual void GetStringName(_STL::string& str, _STL::string& name) const;

	/** Use this to return undefined criteria string. */
	static _STL::string kUndefinedString;
};

/**
 * Utility class to provide easy way of building criteria which are string based.
 * It extends CSRSecuritiesReportCriteriaString by allowing to provide 'N/A' result
 * which is always displayed in the hierarchy.
 * To avail of this functionality the criteria must be registered using INITIALISE_SECURITIES_REPORT_CRITERIA.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportCriteriaStringWithNA : public virtual CSRSecuritiesReportCriteriaString
{
public:
	virtual long GetCode(const CSRSecuritiesReportResult& result) const;
	virtual void GetName(long code, _STL::string& name) const;

	/** Get the criteria string corresponding to a given result. */
	virtual _STL::string GetStringCode(const CSRSecuritiesReportResult& result) const = 0;

	/** Use this to return 'N/A' criteria string. */
	static _STL::string kNAString;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphSecuritiesReportGenericCriteria_H_