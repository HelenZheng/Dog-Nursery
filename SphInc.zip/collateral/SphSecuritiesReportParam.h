#ifndef _SphSecuritiesReportParam_H_
#define _SphSecuritiesReportParam_H_

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphPackable.h"
#include "SphInc/tools/SphDescribable.h"
#include "SphInc/collateral/SphSecuritiesReportSource.h"

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(iterator)


SPH_PROLOG
namespace sophis {

	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}

	namespace collateral {

class CSRSecuritiesReportExtraParam;
class CSRSecuritiesReportExtraParamDialog;
class CSRLBAgreement;
class CSRSecuritiesReport;
class CSRSecuritiesReportResult;

/**
 * Defines a set of parameters for securities report.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportParam
{
public:
	/** Default set of parameters, no restrictions. */
	CSRSecuritiesReportParam();

	/** Copy constructor. */
	CSRSecuritiesReportParam(const CSRSecuritiesReportParam& copy);

	/** Destructor. */
	virtual ~CSRSecuritiesReportParam();

	/** Clone interface. */
	virtual CSRSecuritiesReportParam* Clone() const { return new CSRSecuritiesReportParam(*this); }

	/** Report only for given instrument.
	 * @param sicovam Instrument id for which the report must be generated. */
	void SetInstrument(long sicovam);

	/** Report only for given instruments list.
	* @param sicovamList List containing instrument ids for which the report must be generated. */
	void SetInstrumentList(const _STL::set<long>& sicovamList);

	/** Returns first instrument from the instrument list if set and zero if not applicable. */
	long GetFirstInstrument() const;

	/** Report only for given entity. 
	 * @param entity Entity id for which the report must be generated. */
	void SetEntity(long entity);

	/** Return the entity code if the report is only for given entity. 
	 */
	long GetEntity() const;

	/** Report only for given position. 
	 * @param mvtident Position id for which the report must be generated. */
	void SetPositionId(sophis::portfolio::PositionIdent mvtident);

	/** Report only for given positions list. 
	* @param mvtidentList List containing position ids for which the report must be generated. */
	void SetPositionIdList(const _STL::set<sophis::portfolio::PositionIdent>& mvtidentList);

	/** Restrict report to given portfolios. 
	 * @param folioList List of portfolio ids for which the report must be generated.
	 * @warning Not implemented. You can call this function but it will not make any difference at the moment.
	 */
	void SetPortfolioList(const _STL::set<long>& folioList);

	/** Restrict report with given filter. 
	* @param filter */
	void SetFilter(const _STL::string & filter);

	/** Report only for given allotment list. 
	* @param allotmentList List containing allotment ids for which the report must be generated. */
	void SetAllotmentList(const _STL::set<long>& allotmentList);

	/** Returns SQL query string representing the report parameters. */
	virtual _STL::string ToQueryString() const;

	/** Returns number of additional (external) data sources specified. */
	virtual long GetExternalSourceCount() const;

#ifndef GCC_XML
	/** Returns Nth external source. */
	virtual SSecuritiesReportSourceData GetNthExternalSource(long n) const;

	/** Returns extra parameters for the source. */
	CSRSecuritiesReportExtraParam *GetExtraParam() { return fExtraParam; }
#endif

	/** Returns extra parameters for the source. */
	inline const CSRSecuritiesReportExtraParam *GetExtraParam() const { return fExtraParam; }

	/** Returns the instrument list. */
	inline const _STL::set<long> & GetInstrumentList() const { return fInstrumentList;}

	/** Returns the entity list. */
	inline const _STL::set<long> & GetEntityList() const { return fEntityList;}

	/** Returns the allotment list. */
	inline const _STL::set<long> & GetAllotmentList() const { return fAllotmentList;}

	/** Report only for given counterparty. 
	 * @param cpty Counterparty id for which the report must be generated. */
	void SetCpty(long cpty);

	/** Return the counterparty code if the report is only for given counterparty. 
	 */
	long GetCpty() const;

	/** Returns the counterparty list. */
	inline const _STL::set<long> & GetCptyList() const { return fCptyList;}

	/** Report only for given Depositary. 
	* @param depositary Depositary id for which the report must be generated. */
	void SetDepositary(long depositary);

	/** Return the Depositary code if the report is only for given Depositary. 
	*/
	long GetDepositary() const; 

	/** Report only for given Allotment. 
	* @param allotment Allotment id for which the report must be generated. */
	void SetAllotment(long allotment);

	/** Return the Allotment code if the report is only for given Allotment. 
	*/
	long GetAllotment() const; 

	/** Return the query to filter by allotment. 
	*/
	_STL::string GetAllotmentQuery()const;

	/** Returns the Depositary list. */
	inline const _STL::set<long> & GetDepositaryList() const { return fDepositaryList;}

	/** Report only for the trade type. 
	* @param tradeType trade Type for which the report must be generated. */
	inline void SetTradeType(short tradeType) { fTradeType = tradeType;}

	/** Return the Trade Type. 
	*/
	inline short GetTradeType() const { return fTradeType;}

	/** Report specific to given collateral agreement. */
	inline void SetCollateralAgreement(long collateralAgreementId) { fCollateralAgreementId = collateralAgreementId; }

	/** Report specific to given collateral agreement. */
	void SetCollateralAgreement(const CSRLBAgreement* lba);

	/** Return id of collateral agreement filter. */
	inline long GetCollateralAgreement() const { return fCollateralAgreementId; }

	/** Set the name of the table to fetch the trades from, if alternative to HISTOMVTS is required.
	 * @version 7.1.1 */
	inline void SetHistomvtsName(const _STL::string& histomvtsName) { fHistomvtsName = histomvtsName; }

	/** Return name of the table to fetch the trades from, default being HISTOMVTS.
	 * @version 7.1.1 */
	inline _STL::string GetHistomvtsName() const { return fHistomvtsName; }

	/** Checks if given result object is excluded or not by the current parameters set.
	 * This check is normally reserved for real-time notifications.
	 * To force all results created via Refresh() to pass through this filter, set fIsExcludedOnRefresh flag.
	 * NOTE: this filter is not supported in case of manual SQL or complex rules
	 * NOTE: this filter has no effect on external sources (XXX-SecuritiesReportSource-YYY)
	 * @param report Report context.
	 * @param result Result object to be excluded or not from the report.
	 * @version 7.1.1 */
	virtual bool IsExcluded(const CSRSecuritiesReport& report, const CSRSecuritiesReportResult& result) const;

	/** Set the value of fIsExcludedOnRefresh flag.
	 * @version 7.1.1 */
	inline void SetIsExcludedOnRefresh(bool isExcludedOnRefresh) { fIsExcludedOnRefresh = isExcludedOnRefresh; }

	/** Returns the value of fIsExcludedOnRefresh flag.
	 * @version 7.1.1 */
	inline bool IsExcludedOnRefresh() const { return fIsExcludedOnRefresh; }

protected:
	_STL::set<long> fInstrumentList;
	_STL::set<sophis::portfolio::PositionIdent> fMvtidentList;
	_STL::set<long> fEntityList;
	_STL::set<long> fFolioList;
	_STL::string	fFilter;
	_STL::set<long> fCptyList;
	_STL::set<long> fDepositaryList;
	_STL::set<long> fAllotmentList;
	short fTradeType;
	long fCollateralAgreementId;
	CSRSecuritiesReportExtraParam *fExtraParam;
	_STL::string	fHistomvtsName;
	bool			fIsExcludedOnRefresh;
};

/**
 * Interface for custom (extra, additional) parameters for the securities report.
 * These parameters are optional.
 * They come as addition to the main report parameters and are serialized separately.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportExtraParam : public sophis::tools::ISRPackable
{
public:
	/** Default set of parameters, no restrictions. */
	CSRSecuritiesReportExtraParam(){}

	/** Destructor. */
	virtual ~CSRSecuritiesReportExtraParam(){}

	/** Part of clone interface. */
	virtual void Initialise(const CSRSecuritiesReportExtraParam& copy) {}

	/** Clone interface. */
	virtual CSRSecuritiesReportExtraParam* Clone() const
	{
		CSRSecuritiesReportExtraParam* c = new CSRSecuritiesReportExtraParam();
		c->Initialise(*this);
		return c;
	}

	/** Returns SQL query string representing the report parameters.
	 * The SQL query is relevant to main extraction query on HISTOMVTS and Back Office tables.
	 * See {@link CSRSecuritiesReportParam::ToQueryString}.
	 * See {@link CSRSecuritiesExtraction::DoSecuritiesExtraction}.
	 */
	virtual _STL::string ToQueryString() const { return _STL::string("");}

#ifndef GCC_XML
	/** Returns the dialog relevant to the extra parameters for the model */
	virtual CSRSecuritiesReportExtraParamDialog * new_Dialog() const{ return 0; }
#endif

	/* Saves the resources of the extra parameters dialog */
	virtual void Store(){}

	/* Loads the resources of the extra parameters dialog */
	virtual void Load(){}

	/** See {@link ISRPackable} */
	virtual void* Pack(void* buffer) const{return buffer;}

	/** See {@link ISRPackable} */
	virtual const void* Unpack(const void* buffer){return buffer;}

	/** See {@link ISRPackable} */
	virtual int GetPackedSize() const{return 0;}

	/** Updates the data fields of the extra param from the xmlBuffer passed.
	 * Used in the XML Source handling */
	virtual void FromXml(const _STL::string& xmlBuffer) {}

	/** Serializes extra parameters into XML.
	 * Used in the XML Source handling.
	 */
	virtual _STL::string ToXml() const { return _STL::string(""); }
};

/**
 * Structure containing report display parameters.
 * @version 5.3.6
 */
struct SOPHIS_COLLATERAL SSecuritiesReportingParameters : public tools::ISRDescribable
{
	SSecuritiesReportingParameters();
	SSecuritiesReportingParameters(const SSecuritiesReportingParameters& copy);
	virtual ~SSecuritiesReportingParameters() {}

	void SetTab(_STL::string& tab);
	void SetViewName(_STL::string& tab);
	void SetFilter(_STL::string& filter);
	
	long fEndDate;
	char fTab[20];
	char fViewName[20];
	char fFilter[20];
	bool fEnableInventory;
	short fColumnViewType;
	long fProjectedColumns;
	mutable _STL::vector<_STL::string> fCustomCriteria;
	enum
	{
		CRITERIA_LENGTH = 400,
	};
	char fCustomCriteriaArray[CRITERIA_LENGTH];

	void SetCustomCriteria(_STL::vector<_STL::string> & criteria);


	/// See {@link ISRDescribable}
	virtual int GetFieldCount() const;
	/// See {@link ISRDescribable}
	virtual void GetField(int i, Field& field) const
		throw (InvalidRangeException);
	/// See {@link SReportingParameters::Clone}
	virtual SSecuritiesReportingParameters* Clone() const { return new SSecuritiesReportingParameters(*this); }
	void SetReportParams(const SSecuritiesReportingParameters * params);
	const SSecuritiesReportingParameters GetReportParams() const;

};

	} // collateral
} // sophis
SPH_EPILOG

#endif _SphSecuritiesReportParam_H_
