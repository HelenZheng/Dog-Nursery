#pragma once
#ifndef _SphSecuritiesReportPortfolioColumn_H_
#define _SphSecuritiesReportPortfolioColumn_H_

#include "SphInc/portfolio/SphPortfolioColumn.h"
#include "SphInc/collateral/SphSecuritiesReportCriteriaKey.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReportFlat;
class CSRSecuritiesReportResult;
class CSRSecuritiesReportResultHier;
class CSRSecuritiesReportColumn;
class CSRSecuritiesReportSimulation;

/**
 * Portfolio column linked to securities inventory.
 * The flat list will have data either computed for given date, or across a specified date range.
 * For optimisation purposes, the date range can be further narrowed down.
 * 
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportPortfolioColumn : public virtual portfolio::CSRPortfolioColumn
{
public:
	CSRSecuritiesReportPortfolioColumn();
	CSRSecuritiesReportPortfolioColumn(long sicovam, long date, long startDate, long endDate);
	void Initialize(long sicovam, long date, long startDate, long endDate);

	/** Instrument for which the data is to be computed. */
	inline void SetInstrument(long sicovam) { fSicovam = sicovam; }
	inline long GetInstrument() const { return fSicovam; }

	/** Date for which the data is to be computed. The range remains unchanged. */
	inline void SetDate(long date) { fDate = date; }
	inline long GetDate() const { return fDate; }
	/** Date for which the data is to be computed and the range of dates for hierarchy building. */
	virtual void SetDate(long date, long startDate, long endDate);

	/** Allows to pass data retrieval from the CSRSecuritiesReportResult* object to the given securities report column. */
	inline void SetSecuritiesReportColumn(const CSRSecuritiesReportColumn* securitiesReportColumn) { fSecuritiesReportColumn = securitiesReportColumn; }
	inline const CSRSecuritiesReportColumn* GetSecuritiesReportColumn() const { return fSecuritiesReportColumn; }

	/** Returns securities report result node corresponding to given instrument. */
	const CSRSecuritiesReportResult* GetSecuritiesReportResult(long sicovam) const;

	/** Returns securities report result node corresponding to given instrument and given date. 
	 * This call is more expensive as it also builds a hierarchy by date. */
	const CSRSecuritiesReportResult* GetSecuritiesReportResult(long sicovam, long date) const;

	/** To be implemented in derived classes. Must provide the result hierarchy from the underlying source. */
	virtual const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey, long sicovam) const = 0;

	/** Fetches the quantity (or custom data) from the given node. */
	virtual void GetCell(const CSRSecuritiesReportResult& result, SSCellValue* cellValue, SSCellStyle* cellStyle, bool onlyTheValue) const;

	/// See {@link CSRPortfolioColumn::GetDefaultWidth}
	virtual short GetDefaultWidth() const;

	/// See {@link CSRPortfolioColumn::GetUnderlyingCell}
	virtual	void GetUnderlyingCell(long activePortfolioCode,
		long				portfolioCode,
		portfolio::PSRExtraction extraction,
		long				underlyingCode,
		SSCellValue			*cellValue,
		SSCellStyle			*cellStyle,
		bool				onlyTheValue) const;

	/// See {@link CSRPortfolioColumn::GetPositionCell}
	virtual	void GetPositionCell(const portfolio::CSRPosition& position,
		long				activePortfolioCode,
		long				portfolioCode,
		portfolio::PSRExtraction extraction,
		long				underlyingCode,
		long				instrumentCode,
		SSCellValue			*cellValue,
		SSCellStyle			*cellStyle,
		bool				onlyTheValue) const;

protected:
	const CSRSecuritiesReportColumn* fSecuritiesReportColumn;
	long fSicovam;
	long fDate;

	void BuildInstrumentCriteriaKey(long startDate, long endDate);
	void BuildInstrumentDateCriteriaKey(long startDate, long endDate);
	CSRSecuritiesReportCriteriaKey fInstrumentCriteriaKey;
	CSRSecuritiesReportCriteriaKey fInstrumentDateCriteriaKey;

private:
	static const char* __CLASS__;
};

/**
 * Portfolio column utilising CSRSecuritiesReportFlat.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportFlatPortfolioColumn : public virtual CSRSecuritiesReportPortfolioColumn
{
public:
	DECLARATION_PORTFOLIO_COLUMN(CSRSecuritiesReportFlatPortfolioColumn);
	CSRSecuritiesReportFlatPortfolioColumn(CSRSecuritiesReportFlat* securitiesReportFlat, long sicovam, long date, long startDate, long endDate);
	void Initialize(CSRSecuritiesReportFlat* securitiesReportFlat, long sicovam, long date, long startDate, long endDate);

	/** Set the instance of the report from where the data will be built. Also resets the date range. */
	void SetSecuritiesReportFlat(CSRSecuritiesReportFlat* securitiesReportFlat);
	inline CSRSecuritiesReportFlat* GetSecuritiesReportFlat() const { return fSecuritiesReportFlat; }

	/** See {@link CSRSecuritiesReportPortfolioColumn::SetDate} */
	virtual void SetDate(long date, long startDate, long endDate);

	/** See {@link CSRSecuritiesReportPortfolioColumn::BuildResult} */
	virtual const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey, long sicovam) const;

	/** Allows to perform additional actions on the report object before calling GetSecuritiesReportResult(). */
	virtual const CSRSecuritiesReportFlat* GetReport(long sicovam) const;

protected:
	CSRSecuritiesReportFlat* fSecuritiesReportFlat;

};

/**
 * Portfolio column utilising CSRSecuritiesReportSimulation.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSimulationPortfolioColumn : public virtual CSRSecuritiesReportPortfolioColumn
{
public:
	DECLARATION_PORTFOLIO_COLUMN(CSRSecuritiesReportSimulationPortfolioColumn);
	CSRSecuritiesReportSimulationPortfolioColumn(const CSRSecuritiesReportSimulation* securitiesReportFlat, long sicovam, long date, long startDate, long endDate);
	void Initialize(const CSRSecuritiesReportSimulation* securitiesReportSimulation, long sicovam, long date, long startDate, long endDate);

	/** Set the instance of the report from where the data will be built. Also resets the date range. */
	void SetSecuritiesReportSimulation(const CSRSecuritiesReportSimulation* securitiesReportSimulation);
	inline const CSRSecuritiesReportSimulation* GetSecuritiesReportSimulation() const { return fSecuritiesReportSimulation; }

	/** See {@link CSRSecuritiesReportPortfolioColumn::SetDate} */
	virtual void SetDate(long date, long startDate, long endDate);

	/** See {@link CSRSecuritiesReportPortfolioColumn::BuildResult} */
	virtual const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey, long sicovam) const;

	/** Allows to perform additional actions on the report object before calling GetSecuritiesReportResult(). */
	virtual const CSRSecuritiesReportSimulation* GetSimulation(long sicovam) const;

protected:
	const CSRSecuritiesReportSimulation* fSecuritiesReportSimulation;
};

	} // collateral
} // sophis
SPH_EPILOG

#endif // _SphSecuritiesReportPortfolioColumn_H_