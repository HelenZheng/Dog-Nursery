#ifndef _SphSecuritiesReportResult_H_
#define _SphSecuritiesReportResult_H_

#include "SphInc/collateral/SphSecuritiesExtraction.h"
#include "SphInc/collateral/SphCollateralEnums.h"
#include "SphInc/collateral/SphSecuritiesReportSource.h"
#include "SphTools/SphPrototype.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(memory)

SPH_PROLOG

struct SSCellStyle;

/**
 * Macros for handling Securities Report Unavailable Quantities.
 * To be used instead of the Clone() method in the derived classes.
 * @version 7.1
 */
#define DECLARATION_SECREPORT_UNAVAILABLE_QTY(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRSecReportUnavailableQuantity)
#define CONSTRUCTOR_SECREPORT_UNAVAILABLE_QTY(derivedClass)
#define WITHOUT_CONSTRUCTOR_SECREPORT_UNAVAILABLE_QTY(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * @version 7.1
 */
#define	INITIALISE_SECREPORT_UNAVAILABLE_QTY(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)


namespace sophis {
	namespace collateral {

class CSRSecuritiesReportCriteria;
class CSRSecuritiesReportCriteriaKey;
class CSRSecuritiesReport;
class CSRSecuritiesReportQuantities;
class CSRSecuritiesReportStatusAvailability;

/**
 * Flags indicating source (type) for quantity field.
 * Multiple source quantities can appear in the aggregated nodes, or if using external sources.
 * @version 5.3.6
 */
enum eQuantityFlags {
	eqfBook			= 0x1,
	eqfSL			= 0x2,
	eqfPool			= 0x4,
	eqfContract		= 0x8,

	eqfExternal		= 0x1000,
	eqfNoFlag		= 0
};

/**
 * Flags indicating status of the result.
 * Multiple flags can appear in the aggregated nodes, or if using external sources.
 * First byte of the flags is reserved by Sophis.
 * Users can extend the flags with custom values.
 * @version 6.3
 */
enum eStatusFlags {
	/** No status. */
	esfNoFlag		= 0x0,
	/** Normal status. */
	esfNormal		= 0x1,
	/** Warning status. */
	esfWarning		= 0x2,
	/** Error (breach) status. */
	esfBreach		= 0x4,
};

/**
 * Securities report result object.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportResult
{
public:
	/** Allows to split total number of securities between different sources. */
	enum eQuantityType
	{
		eqtTotal = 0,
		eqtBook,
		eqtSL,
		eqtContractCollateral,
		eqtPoolCollateral,
		eqtLast,
	};

	/** Helps identify quantity source. */
	enum ePositionType
	{
		eptUnknown = 0,
		eptBook,
		eptSL,
		eptContractCollateral,
		eptPoolCollateral,
		/** Aggregated position. */
		eptHier,
		/** External source. */
		eptExternal,
	};

public:
	/** Constructor. */
	CSRSecuritiesReportResult();
	/** Constructor.
	 * @param qf Quantities flag. */
	CSRSecuritiesReportResult(eQuantityFlags qf);
	/** Constructor. Sets the values according to the db result.
	 * @param trade DB result, becomes owned by the result. */
	CSRSecuritiesReportResult(CSRSecuritiesExtractionTrade * trade);
	/** Constructor. Sets the values according to the db result.
	 * @param trade DB result, becomes owned by the result. 
	 * @param qf Quantities flag. */
	CSRSecuritiesReportResult(CSRSecuritiesExtractionTrade * trade, eQuantityFlags qf);
	/** Copy Constructor. */
	CSRSecuritiesReportResult(const CSRSecuritiesReportResult& copy);
	/** Destructor. */
	virtual ~CSRSecuritiesReportResult();
	/** Performs a deep copy (duplicates) the given result including all child
	 * results and details. The caller takes ownership of the result object and
	 * is responsible for its destruction. The call is NOT equivalent to add_ref_count(),
	 * it creates a new object with fRefCount set to 1. */
	virtual CSRSecuritiesReportResult* Clone() const;

	void init_ref_count() const { fRefCount = 1; }
	void add_ref_count() const { ++fRefCount; }
	void sub_ref_count() const { if(--fRefCount == 0) delete this; }

	/** Compares two results. */
	virtual bool IsLower(const CSRSecuritiesReportResult& result1, const CSRSecuritiesReportResult& result2) const;

	/** Returns instrument code (sicovam) of the security to which this result belongs to.
	 * The code may different from the actual instrument code of the position. */
	virtual long GetSecuritiesCode() const;

	/** Returns portfolio id to which the result belongs to. */
	virtual long GetPortfolioId() const;

	/** Returns counterparty id to which result belongs to. */
	virtual long GetCounterParty() const;

	/** Returns entity id to which result belongs to. */
	virtual long GetEntity() const;

	/** Returns depositary to which result belongs to. */
	virtual long GetDepositary() const;

	/** Returns storage place to which result belongs to. */
	virtual long GetStoragePlace() const;

	/** Returns number of available securities for given date. */
	virtual double GetQuantityTotal() const;

	/** Returns number of available securities of given source type for given date. */
	virtual double GetQuantity(eQuantityType eqt) const;

	/** Sets the quantities depending on the Quantity Type */
	virtual void SetQuantity(eQuantityType eqt, double quantity);

	/** Set (apply) given quantities to the result. 
	 * Will typically call quantities.SetTradeQuantities(fTrade) and update quantity flags. */
	virtual void SetQuantities(const CSRSecuritiesReportQuantities& quantities);

	/** Sums trade and given quantities and sets them as projected ones (where applicable). */
	virtual void AddProjectedQuantities(const CSRSecuritiesReportQuantities& quantities, CSRSecuritiesReportQuantities& resultQuantities);

	/** Sets given quantities as projected quantities (where applicable). */
	virtual void SetProjectedQuantities(const CSRSecuritiesReportQuantities& quantities) {}

	/** Returns projected quantities, if applicable. @return NULL if the result has no projected quantities. */
	virtual const CSRSecuritiesReportQuantities* GetProjectedQuantities() const { return 0; }

	/** Returns position id corresponding to given result, when applicable.
	 * For stock loan securities collateral, it returns position id of main deal,
	 * instead of the virtual (collateral) id. */
	virtual sophis::portfolio::PositionIdent GetPositionId() const;

	/** Returns instrument code corresponding to the position returned by GetPositionId().
	 * @see {@link GetPositionId} */
	virtual long GetPositionInstrumentCode() const;

	/** Returns type of quantities source for the position representing given result. */
	virtual ePositionType GetPositionType() const;

	/** Returns name of the result (folio or position) to be displayed. 
	 * @version 7.1.1 It is possible to define custom display name by calling SetDisplayName(). */
	virtual _STL::string GetName() const;

	/** Returns the icon for the given result (for ui display). */
	virtual long GetIcone() const;

	/** Populates the style of the result. By default redirects call to status and availability object. */
	virtual void GetStyle(SSCellStyle *style) const;

	/** Returns currency of the line. */
	virtual long GetCurrency() const;

	/** Returns allotment of the instrument to which this position belongs to or 
	 * allotment of the parent instrument.
	 * @return 0 if instrument has not been loaded;	-1 if does not exist; >0 the allotment.
	 */
	virtual long GetAllotment() const;

	/** Returns convention of the instrument to which this position belongs to.
	 * Only valid for the lines belonging to the position.
	 * @return 0 if instrument has not been loaded; -1 if no match in convention selector; -2 if does not exist, >0 the convention.
	 */
	virtual long GetConvention() const;

	/** Populates the lending opportunity indicator specified by type. 
	 * In case it shouldn't be displayed will false, otherwise true. 
	 * @param type of indicator to fill.
	 */
	bool GetIndicator(eLOIndicators type, double& res) const;

	/** Returns date to which the result values correspond. May be zero for lines
	 * that do not correspond to any particular date. */
	long GetDate() const;


	/** Returns sico Type of this position.
	*It's used for compliance report to distinguish virtual and simulated positions.*/
	short CSRSecuritiesReportResult::GetSicoType() const;

	/** Returns underlying database extraction information. */
	inline const CSRSecuritiesExtractionTrade * GetTrade() const { return fTrade; }
	/** Sets the owner (report) of given result. */
	inline void SetReport(CSRSecuritiesReport* report) { fReport = report; }
	/** Returns the owner (report) of given result. */
	inline CSRSecuritiesReport* GetReport() const { return fReport; }

	/** Returns external (or simulation) source id, if applicable. */
	inline long GetSourceId() const { return fSourceId; }
	/** Sets external (or simulation) source id to given value. */
	inline void SetSourceId(long sourceId) { fSourceId = sourceId; }

	/** Define custom display name. See {@link GetName()}.
	 * @version 7.1.1 */
	inline void SetDisplayName(const _STL::string& displayName) { fDisplayName = displayName; }

	/** Compares two results based on field and in ascending or descending order.
	* @since 5.3.6.5
	*/
	bool IsLowerField(const CSRSecuritiesReportResult& result1, const CSRSecuritiesReportResult& result2, int fieldId, bool reverse) const;
	void SetProjectionDate(long date);
	
	/** Returns refrence of the instrument. */
	_STL::string GetReference() const;

	/** Return the quantity flags. See #fQuantityFlags. */
	unsigned long GetQuantityFlags() const { return fQuantityFlags; }

	/** Return the status flags. See #fStatusFlags. */
	unsigned long GetStatusFlags() const;

	/** Return the status and availability if present. */
	const CSRSecuritiesReportStatusAvailability* GetStatusAvailability() const { return fStatusAvailability; }

	/** Initialises status and availability based on the given model. */
	virtual bool InitialiseStatusAvailability(const CSRSecuritiesReportStatusAvailability* model);

	/** Returns the quantity hedged by Par Asset Swaps. */
	virtual double GetQtyParAssetSwap() const;

	typedef _STL::map<long, double,_STL::less<long> > DateQuantity;
	mutable DateQuantity dateQuantity;
	mutable DateQuantity dateCollateralQuantity;
	mutable DateQuantity dateSLQuantity;
	mutable DateQuantity dateBookQuantity;
	mutable DateQuantity dateQuantityDelta;
	mutable DateQuantity dateCollateralQuantityDelta;
	mutable DateQuantity dateSLQuantityDelta;
	mutable DateQuantity dateBookQuantityDelta;
	mutable DateQuantity dateAvailableQuantity;
	mutable DateQuantity dateAvailableQuantityDelta;

	virtual double GetProjectedAvailableQuantitiesByDate(int counter) const;
	virtual double GetProjectedQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetProjectedCollateralQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetProjectedSLQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetProjectedBookQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetDeltaQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetDeltaCollateralQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetDeltaSLQuantitiesByDate(int counter) const {return 0.0;}
	virtual double GetDeltaBookQuantitiesByDate(int counter) const {return 0.0;}

	virtual void UpdateProjectionQuantities(long maturityDate);

	/** Returns position id corresponding to given result, when applicable.
	* For stock loan securities collateral, it returns position id of the collateral
	 * @see {@link GetPositionId} */
	virtual portfolio::PositionIdent GetVirtualPositionId() const;

protected:
	/** Compares two trades. */
	virtual bool IsTradeLower(const CSRSecuritiesExtractionTrade& trade1, const CSRSecuritiesExtractionTrade& trade2) const;

	/** Copy interesting values from #result to this.
	 * Implementation in this class clones #result's #fTrade (and calls UpdateNonTradeData()), and copies #fQuantityFlags.
	 * @note Any overriding function *must* call the function from its base class.
	 */
	virtual void CopyResultValues(const CSRSecuritiesReportResult& result);

	/** Called whenever #fTrade is modified so that data stored directly in a result instance can be updated.
	 * Implementation in this class updates #fQuantityFlags.
	 * @note Any overriding function *must* call the function from its base class.
	 */
	virtual void UpdateNonTradeData();

	/** Initialization. */
	void Initialize();
	/** Initialization. Sets the values according to the db result.
	* @param trade DB result, becomes owned by the result. */
	void Initialize(CSRSecuritiesExtractionTrade * trade);
	/** Initialization. Sets the values according to the db result.
	* @param trade DB result, becomes owned by the result. */
	void Initialize(CSRSecuritiesExtractionTrade * trade, eQuantityFlags qf);
	/** Initialization. */
	void Initialize(const CSRSecuritiesReportResult& copy);

	/** Reference count. */
	mutable long fRefCount;

	/** Information about the trade.
	 * @warning Whenever code outside of constructors modifies this member, it must call UpdateNonTradeData() immediately afterwards.
	 */
	CSRSecuritiesExtractionTrade *fTrade;

	/** Owner (report). */
	CSRSecuritiesReport* fReport;

public:
	/** Has the instrument of this result been loaded? 
	 * For internal use by CSRSecuritiesReportColumn::InstrNotLoaded().
	 * Is only flipped from false to true and never back.
	 */
	mutable bool fInstrLoaded;
	mutable bool fExtraResult;
	friend class CompareField;

protected:
	/** Identifies the "origins" of the quantities stored in the result. Contains combined flags from #eQuantityFlags. See GetQuantityFlags(). */
	unsigned long fQuantityFlags;
	/** External source id, if applicable. For simulation, source ids are typically negative. */
	long fSourceId;
	/** Status and availability. */
	CSRSecuritiesReportStatusAvailability* fStatusAvailability;

	/** Allows to specify custom name for GetName(). */
	_STL::string fDisplayName;
};

/**
 * Aggregated result based on criteria.
 * Used to build hierarchical views.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportResultHier : public virtual CSRSecuritiesReportResult
{
public:
	/** Constructor. */
	CSRSecuritiesReportResultHier();
	/** Constructor using criteria when building hierarchical view.
	 * @param parent Parent result.
	 * @param criteriaKey Complete criteria key used to build hierarchical view.
	 * @param criteria Criteria specific to the node being built.
	 * @param code Criteria code specific to the node being built.
	 */
	CSRSecuritiesReportResultHier(CSRSecuritiesReportResultHier * parent, const CSRSecuritiesReportCriteriaKey * criteriaKey,
		const CSRSecuritiesReportCriteria * criteria, long code);
	/** Destructor. */
	virtual ~CSRSecuritiesReportResultHier();

	/** Adds given result to the node. If result is a node (hierarchical) then the current node
	 * becomes the parent of the result.
	 * The result is added to the end of the list.
	 */
	void AddResult(const CSRSecuritiesReportResult& result);
	/** Removes given result from the list. */
	void RemoveResult(const CSRSecuritiesReportResult& result);
	/** Performs aggregation of the values. */
	void Aggregate(bool force = false);
	/** Sorts the results in the hierarchy. */
	void Sort();
	/** Updates the status and availability for the hierarchy and child nodes. */
	virtual bool InitialiseStatusAvailability(const CSRSecuritiesReportStatusAvailability* model);

	virtual sophis::portfolio::PositionIdent GetPositionId() const;
	/** Returns parent node (if present). */
	const CSRSecuritiesReportResultHier* GetParent() const { return fParent; }

	/** Returns code value corresponding to given node. */
	inline long GetCode() const { return fCode; }

	/** Returns if the hierarchical node is a "not expandable" node, built using "not expandable" criteria.
	 * @see {@link CSRSecuritiesReportCriteria::IsNotExpandable}
	 */
	bool IsNotExpandable() const;

	/** Fills given key with values corresponding to the current node. 
	 * The results are in order, i.e. the first one is the top criteria, and so on.
	 * Only one code per criteria. */
	void GetCriteriaKey(CSRSecuritiesReportCriteriaKey& criteriaKey) const;

	friend class CompareField;
	/** Sorts the results in the hierarchy as per the field and in ascending or descending order.
	* @since 5.3.6.5
	*/
	void SortField(int fieldId, bool reverse = false);
#ifndef GCC_XML
	/** Populates flat list of given result and all child results. */
	void GetFlatList(_STL::list<const CSRSecuritiesReportResult*>& flatList) const;
#endif

	typedef _STL::list<CSRSecuritiesReportResult*> SecuritiesReportResultList;
	/** Shortcut to deal list iterator. See begin() and end(). */
	typedef SecuritiesReportResultList::const_iterator const_iterator;

	/** Test whether there are any results in the list. */
	bool empty() const;
	/** Returns number of results in the list. */
	size_t size() const;
	/** Returns iterator to the start of the result container. */
	const_iterator begin() const;
	/** Returns iterator to the end of the result container. */
	const_iterator end() const;
	/** Returns first element of the result container. */
	const CSRSecuritiesReportResult* front() const;

	/** @see {@link CSRSecuritiesReportResult::Clone} */
	virtual CSRSecuritiesReportResult* Clone() const;
	/** @see {@link CSRSecuritiesReportResult::IsLower} */
	virtual bool IsLower(const CSRSecuritiesReportResult& result1, const CSRSecuritiesReportResult& result2) const;
	/** @see {@link CSRSecuritiesReportResult::GetPortfolioId} */
	virtual long GetPortfolioId() const;
	/** @see {@link CSRSecuritiesReportResult::GetPositionId}.
	 * Hierarchical node does not map to a position since it is hierarchical (aggregated). */
	/** @see {@link CSRSecuritiesReportResult::GetCounterParty}.
	 * Hierarchical node does not map to a counterparty (position) since it is hierarchical (aggregated). */
	virtual long GetCounterParty() const;
	/** @see {@link CSRSecuritiesReportResult::GetPGetEntityositionId}.
	 * Hierarchical node does not map to an entity (position) since it is hierarchical (aggregated). */
	virtual long GetEntity() const;
	/** @see {@link CSRSecuritiesReportResult::GetPositionType} */
	virtual ePositionType GetPositionType() const { return eptHier; }
	/** @see {@link CSRSecuritiesReportResult::GetName}
	 * @see {@link CSRSecuritiesReportCriteria::GetName} */
	virtual _STL::string GetName() const;
	/** @see {@link CSRSecuritiesReportResult::GetIcone}
	 * @see {@link CSRSecuritiesReportCriteria::GetIcone}*/
	virtual long GetIcone() const;
	/** @see {@link CSRSecuritiesReportResult::GetAllotment} */
	virtual long GetAllotment() const;

	/** @see {@link CSRSecuritiesReportResult::AddProjectedQuantities} */
	virtual void AddProjectedQuantities(const CSRSecuritiesReportQuantities& quantities, CSRSecuritiesReportQuantities& resultQuantities);
	/** @see {@link CSRSecuritiesReportResult::SetProjectedQuantities} */
	virtual void SetProjectedQuantities(const CSRSecuritiesReportQuantities& quantities);
	/** @see {@link CSRSecuritiesReportResult::GetProjectedQuantities} */
	virtual const CSRSecuritiesReportQuantities* GetProjectedQuantities() const;
	virtual double GetProjectedQuantitiesByDate(int counter) const;
	virtual double GetDeltaQuantitiesByDate(int counter) const;
	virtual double GetProjectedCollateralQuantitiesByDate(int counter) const;
	virtual double GetProjectedSLQuantitiesByDate(int counter) const;
	virtual double GetProjectedBookQuantitiesByDate(int counter) const;
	virtual double GetDeltaCollateralQuantitiesByDate(int counter) const;
	virtual double GetDeltaSLQuantitiesByDate(int counter) const;
	virtual double GetDeltaBookQuantitiesByDate(int counter) const;
	virtual double GetProjectedAvailableQuantitiesByDate(int counter) const {return 0.0;}

	/** Maps external source data to aggregated node for external data */
	typedef _STL::map<SSecuritiesReportSourceData, CSRSecuritiesReportResultHier*> MExternalResult;
	/** Test whether there are any results in the external result. */
	bool external_empty() const;
	/** Returns number of results in the external result. */
	size_t external_size() const;
	/** Returns iterator to the start of the external result container. */
	MExternalResult::const_iterator external_begin() const;
	/** Returns iterator to the end of the external result container. */
	MExternalResult::const_iterator external_end() const;
	/** Returns the flat result list.
	 * @version since 7.1
	 */
	SecuritiesReportResultList& GetFlatResults(){return fList; }
	virtual sophis::portfolio::PositionIdent GetVirtualPositionId() const;

protected:
	/** Implementation in this class calls the base class. #fList is *not* copied. */
	virtual void CopyResultValues(const CSRSecuritiesReportResult& result);
	virtual void AddResultValues(const CSRSecuritiesReportResult& result);
	virtual void RemoveResultValues(const CSRSecuritiesReportResult& result);
	/** To create shallow copies. */
	virtual CSRSecuritiesReportResultHier* new_SecuritiesReportResultHier(CSRSecuritiesReportResultHier * parent = 0, const CSRSecuritiesReportCriteriaKey * criteriaKey = 0, const CSRSecuritiesReportCriteria * criteria = 0, long code = 0) const;

	virtual bool IsHierLower(const CSRSecuritiesReportResultHier& result1, const CSRSecuritiesReportResultHier& result2) const;

	/** Implementation in this class just calls the base class. */
	virtual void UpdateNonTradeData();

	/** Initialization using criteria when building hierarchical view.
	* @param parent Parent result.
	* @param criteriaKey Complete criteria key used to build hierarchical view.
	* @param criteria Criteria specific to the node being built.
	* @param code Criteria code specific to the node being built.
	*/
	void Initialize(CSRSecuritiesReportResultHier * parent, const CSRSecuritiesReportCriteriaKey * criteriaKey,
		const CSRSecuritiesReportCriteria * criteria, long code);

	void AddQuantityValues(CSRSecuritiesReportResult *result) const;

//public:
	SecuritiesReportResultList fList;
	CSRSecuritiesReportResultHier* fParent;
	const CSRSecuritiesReportCriteria* fCriteria;
	long fCode;
	_STL::auto_ptr<CSRSecuritiesReportQuantities> fProjectedQuantities;

	MExternalResult fExternal;

	friend class CSRSecuritiesReportSourceMgr;
};

/**
 * Class for comparing securities result.
 * @version 5.3.6.5
 */
class SOPHIS_COLLATERAL CompareField
{
public:
	CompareField(int field, bool reverse):fReverse(reverse),fField(field){}
	bool compare( const CSRSecuritiesReportResult* a, const CSRSecuritiesReportResult* b) const ;
	bool	operator()( const CSRSecuritiesReportResult * a, const CSRSecuritiesReportResult * b ) const	{ return compare( a, b ); }
private:
	bool fReverse;
	int fField;
};

/**
 * Used in conjunction with projection.
 * Basic class/structure for holding quantities of securities report.
 * It is useful if you need to extract/add quantities from/to trade or result.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportQuantities
{
public:
	/** Constructor, all zero quantities. */
	CSRSecuritiesReportQuantities();
	/** Destructor. */
	virtual ~CSRSecuritiesReportQuantities();
	/** Clone. */
	virtual CSRSecuritiesReportQuantities* Clone() const;
	/** Part of the clone interface. */
	virtual void Initialise(const CSRSecuritiesReportQuantities& copy);
	/** Reset quantities. */
	virtual void Clear();

	/** Add quantities from the given SSSecuritiesExtractionTrade structure. */
	virtual void AddLowLevelQuantities(const SSSecuritiesExtractionTrade& rhs,
		const CSRSecuritiesReportStatusAvailability* rhsSA);
	/** Add quantities from the trade. Will typically call this->AddLowLevelQuantities(*rhs) */
	virtual void AddQuantities(const CSRSecuritiesExtractionTrade& rhs,
		const CSRSecuritiesReportStatusAvailability* rhsSA) { return this->AddLowLevelQuantities(*rhs, rhsSA); }
	/** Add quantities from the trade. Will typically call this->AddLowLevelQuantities(*rhs) */
	virtual void AddQuantities(const CSRSecuritiesReportResult& result);
	/** Add quantities from another quantities object. @version 7.1.1 */
	virtual void AddQuantities(const CSRSecuritiesReportQuantities& rhs);

	/** This is the case where we calculate in-memory projected for certain quantities change for the future.
	 * If additional fields should be updated, it should be done here. */
	virtual void SetProjectedQuantity(CSRSecuritiesReportResult::eQuantityType eqt, double quantity);

	/** Sets quantities from self into low level trade information. */
	virtual void SetTradeQuantities(CSRSecuritiesExtractionTrade& trade) const;

	/** Quantities vector. */
	double fQuantities[CSRSecuritiesReportResult::eqtLast];

	/** Status and availability. */
	CSRSecuritiesReportStatusAvailability *fStatusAvailability;
};

/**
 * Status and availability.
 * For standard report, status and availability is invoked for each node (leaf or hierarchical) at report build time.
 * The hierarchical nodes accumulate all children's status and availability.
 * It is also used for projection quantities, where accumulation is used to calculate projected status and availability.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportStatusAvailability
{
public:
	/** Constructor. */
	CSRSecuritiesReportStatusAvailability();
	/** Destructor. */
	virtual ~CSRSecuritiesReportStatusAvailability();
	/** Clone interface. */
	virtual CSRSecuritiesReportStatusAvailability* Clone() const;
	/** Part of the clone interface. */
	virtual void Initialise(const CSRSecuritiesReportStatusAvailability& copy);

	/** Updates status and availability based on the given node. Should be implemented in derived classes. */
	virtual void Initialise(const CSRSecuritiesReportResult& result);

	/** Updates status and availability based on the given hierarchical node.
	 * Normally runs through accumulation process. */
	virtual void Initialise(const CSRSecuritiesReportResultHier& hier);

	/** Invoked to start the accumulation of children's status and availability. */
	virtual void BeginAccumulation();
	/** Accumulate given child's status and availability into self. */
	virtual void Accumulate(const CSRSecuritiesReportStatusAvailability& childStatusAvailability);
	/** Invoked to end the accumulation of children's status and availability. */
	virtual void EndAccumulation();

	/** Return the status flags. See #fStatusFlags. */
	virtual unsigned long GetStatusFlags() const { return fStatusFlags; }

	/** Return the available (unblocked) quantity. */
	virtual double GetAvailableQuantity() const { return fAvailableQuantity; }

	/** Populates the style corresponding to given status and availability. */
	virtual void GetStyle(SSCellStyle *style) const;

	/** Default style implementation for the #eStatusFlags. */
	static void GetDefaultStyle(unsigned long statusFlags, SSCellStyle *style);

protected:
	/** Status flag. See #eStatusFlags. */
	unsigned long fStatusFlags;
	/** Available (unblocked) quantity. */
	double fAvailableQuantity;
};

class SOPHIS_COLLATERAL CSRSecReportUnavailableQuantity
{
public:

	/** Destructor. */
	virtual ~CSRSecReportUnavailableQuantity() {}


	/** 
	 * Clone method needed by the prototype. To be implemented by derived classes.
	 * Usually, it is done automatically by the macro DECLARATION_SECREPORT_UNAVAILABLE_QTY.
	 * @see tools::CSRPrototype
	 */
	virtual CSRSecReportUnavailableQuantity* Clone() const = 0;

	/** 
	 * Typedef for the prototype, the key is a const char*.
	 */
	typedef tools::CSRPrototype<CSRSecReportUnavailableQuantity, const char*, tools::less_char_star> prototype;

	/**
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_SWAP_PAYMENT_RULE.
	 * @see tools::CSRPrototype 
	 */
	static prototype& GetPrototype();

	/**
	 * Returns the unavailable quantity to be subtracted from the total quantity.
	 * @param result is the line in the Securities Report from which the unavailable quantity will be calculated.
	 * @return double unavailable quantity.
	 */
	virtual double GetUnavailableQty(const CSRSecuritiesReportResult &result) const = 0;
};

	}
}

SPH_EPILOG

#endif // _SphSecuritiesReportResult_H_
