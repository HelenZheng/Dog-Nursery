#pragma once
#ifndef _SphSecuritiesReportSimulation_H_
#define _SphSecuritiesReportSimulation_H_

#include "SphInc/SphMacros.h"
#include "SphInc/collateral/SphSecuritiesReport.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/// INTERNAL
class CSRSecuritiesReportSimulatedResultList;

/**
 * Data interface for securities report simulation.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSimulationData
{
public:
	/** Constructor. */
	CSRSecuritiesReportSimulationData() {}
	/** Destructor. */
	virtual ~CSRSecuritiesReportSimulationData() {}

	/** Result iterator pointing to the beginning of simulated results. */
	virtual CSRSecuritiesReportResultList::const_iterator GetSimulatedListBegin() const = 0;
	/** Result iterator pointing to the end of simulated results. */
	virtual CSRSecuritiesReportResultList::const_iterator GetSimulatedListEnd() const = 0;
};

/**
 * Simulate securities inventory with non-existent deals.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSimulation
{
private:
	const CSRSecuritiesReport* fReport;
	mutable CSRSecuritiesReportSimulatedResultList* fSimulatedResultList;
	mutable CSRSecuritiesReport::MCriteriaView fSimulatedView;
	CSRSecuritiesReportSimulationData* fSimulationData;

public:
	/** Constructor. Empty report. */
	CSRSecuritiesReportSimulation();
	/** Constructor. Takes existing report as parameter. */
	CSRSecuritiesReportSimulation(const CSRSecuritiesReport& report);
	/** Destructor. */
	virtual ~CSRSecuritiesReportSimulation();

	/** Sets the simulation context (data). Any previous results are cleared. */
	void SetSimulationData(CSRSecuritiesReportSimulationData* simulationData);

	/** Build flat view result. */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** Build view specific to given criteria. */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true) const;

	/** View (cache) iterator pointing to the end of the simulated cache. */
	CSRSecuritiesReport::MCriteriaView::const_iterator GetViewEnd() const;

	/** Get access to the simulated cached view object, if exists. */
	CSRSecuritiesReport::MCriteriaView::const_iterator FindView(const CSRSecuritiesReportResultHier& root) const;

	/** Drop given view from the simulated cache. */
	void ClearView(const CSRSecuritiesReportResultHier& root);

	/** Drop all views from the simulated cache. */
	void ClearAllViews();

	/** Access to the report source. */
	const CSRSecuritiesReport& GetReport() const { return *fReport; }
};


	} // collateral
} // sophis

SPH_EPILOG
#endif // _SphSecuritiesReportSimulation_H_
