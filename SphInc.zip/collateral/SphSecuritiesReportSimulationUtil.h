#pragma once
#ifndef _SphSecuritiesReportSimulationUtil_H_
#define _SphSecuritiesReportSimulationUtil_H_

#include "SphInc/collateral/SphSecuritiesReportSimulation.h"
#include "SphInc/collateral/SphSecuritiesExtraction.h"
#include "SphInc/collateral/SphSecuritiesReportResult.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
		class CSRTransactionVector;
	}
	namespace collateral {

class CSRSecuritiesReportFilter;
class CSRSecuritiesReportCriteria;

/**
 * Utility class to help perform simple simulation over securities inventory.
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSimulationUtil
{
protected:
	CSRSecuritiesReportSimulation *fImpl;
	CSRSecuritiesReportSimulationData *fData;
	CSRSecuritiesReportFilter *fFilter;
	CSRSecuritiesReportCriteria *fCriteria;

public:
	/** Constructor. Empty report. */
	CSRSecuritiesReportSimulationUtil();
	/** Constructor. Latest available report of given type. */
	CSRSecuritiesReportSimulationUtil(sophis::collateral::eSecuritiesExtractionType extractionType);
	/** Constructor. Takes existing report as parameter. */
	CSRSecuritiesReportSimulationUtil(const CSRSecuritiesReport& report);
	/** Destructor. */
	virtual ~CSRSecuritiesReportSimulationUtil();

	/** Sets the simulation context (data) from given transaction input. Any previous results are cleared. */
	void SetSimulationData(const portfolio::CSRTransaction& tr);
	void SetSimulationData(const _STL::vector<const portfolio::CSRTransaction*>& trVector);
	void SetSimulationData(const portfolio::CSRTransactionVector& trVector);
	/** Resets simulation data to no simulation. */
	void SetSimulationData();
	/** Add data to the current simulation context (data). Any previous results are cleared. */
	void AddSimulationData(const portfolio::CSRTransaction& tr);

	/** Allows to further customise the actual result. */
	virtual void OverloadSimulationData(const portfolio::CSRTransaction& tr, CSRSecuritiesReportResult& result);

	/** Set the date(s) range for the result. */
	void SetResultDate(long date);
	void SetResultDate(long startDate, long endDate);

	/** Build flat view result. */
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true);

	/** Build view specific to given criteria. */
	const CSRSecuritiesReportResultHier* BuildResult(const _STL::vector<_STL::string>& criteriaList,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true);
	const CSRSecuritiesReportResultHier* BuildResult(const CSRSecuritiesReportCriteriaKey& criteriaKey,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true);
#ifndef GCC_XML
	const CSRSecuritiesReportResultHier* BuildResult(const _STL::vector<const CSRSecuritiesReportCriteria*>& criteriaList,
		long sicovam = 0, const CSRSecuritiesReportFilter* flatFilter = 0, bool useCache = true);
#endif

	/** Find corresponding node in the result tree.
	 * @param sicovam Can be 0 if root has been computed for an instrument.
	 * @param date Date for which the projected quantities are sought. Can be 0 if root has been computed without projections.
	 * @return node of NULL if such node could not be located.
	 */
	const CSRSecuritiesReportResultHier* GetResultNode(const CSRSecuritiesReportResultHier& root,
		long sicovam, long date, const _STL::vector<long>& values) const;

	/** Find corresponding node in the result tree and return projected quantities (if applicable) or actual quantities.
	 * @param sicovam Can be 0 if root has been computed for an instrument.
	 * @param date Date for which the projected quantities are sought. Can be 0 if root has been computed without projections.
	 * @param eqt Quantity type sought.
	 */
	double GetProjectedQuantity(const CSRSecuritiesReportResultHier& root,
		long sicovam, long date,
		const _STL::vector<long>& values,
		CSRSecuritiesReportResult::eQuantityType eqt) const;

	/** Drop given view from the simulated cache. */
	void ClearView(const CSRSecuritiesReportResultHier& root);

	/** Drop all views from the simulated cache. */
	void ClearAllViews();
};

	} // collateral
} // sophis
SPH_EPILOG

#endif // _SphSecuritiesReportSimulationUtil_H_
