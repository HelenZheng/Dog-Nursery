#ifndef _SphSecuritiesReportSource_H_
#define _SphSecuritiesReportSource_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphPacketVector.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReportParam;
struct SSSecuritiesExtractionTrade;
class CSRSecuritiesExtractionTrade;
class CSRSecuritiesReportResult;
typedef _STL::list<CSRSecuritiesReportResult*> CSRSecuritiesReportResultList;
class CSRSecuritiesReportResultHier;

/** List of trades (records) extracted from database (source). */
typedef tools::CSRPacketVector<SSSecuritiesExtractionTrade> SecuritiesExtractionTradeList;

class CSRSecuritiesReportSource;
class CSRSecuritiesReportSourceData;

/**
 * Structure for holding securities report external source parameterization.
 * @version 6.3
 */
struct SOPHIS_COLLATERAL SSecuritiesReportSourceData
{
	/** Dummy Constructor. */
	SSecuritiesReportSourceData();
	/** Constructor. Links source and source data to given values. Shallow copy, no values are cloned. */
	SSecuritiesReportSourceData(const CSRSecuritiesReportSource& source, const CSRSecuritiesReportSourceData* sourceData);
	/** Comparison operator. */
	friend bool operator < (const SSecuritiesReportSourceData& s1, const SSecuritiesReportSourceData& s2);

	/** Reference to external source factory (inside corresponding prototype). */
	const CSRSecuritiesReportSource* fSource;
	/** Custom external data source (data feed), can be null. */
	const CSRSecuritiesReportSourceData* fSourceData;
};

/**
 * Data feed for external data source in securities report.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSourceData
{
public:
	/** Constructor. */
	CSRSecuritiesReportSourceData();

	/** Destructor. */
	virtual ~CSRSecuritiesReportSourceData();

	/** Clone interface. */
	virtual CSRSecuritiesReportSourceData* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRSecuritiesReportSourceData& source);

	/** Run the extraction.
	* @param param Report parameters
	* @param date Optional reporting date; if not specicied, default date is used. Can be relative (to DateFinBase).
	*/
	virtual void DoSecuritiesExtraction(const CSRSecuritiesReportParam& param, long date) = 0;

	/** Makes a copy of the given result and wraps it in appropriate class object. */
	virtual CSRSecuritiesExtractionTrade* new_SecuritiesExtractionTrade(const SSSecuritiesExtractionTrade& trade) const = 0;

	/** Test whether there are any results. Takes constant time unlike size(). */
	virtual bool empty() const = 0;

	/** Returns number of results. */
	virtual unsigned long size() const = 0;

	/** Shortcut to deal list iterator. See begin() and end(). */
	typedef SecuritiesExtractionTradeList::iterator iterator;

	/** Returns iterator to the start of the result container. */
	virtual iterator begin() = 0;

	/** Returns iterator to the end of the result container. */
	virtual iterator end() = 0;
};


/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_SECURITIES_REPORT_SOURCE(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRSecuritiesReportSource)
#define CONSTRUCTOR_SECURITIES_REPORT_SOURCE(derivedClass)
#define WITHOUT_CONSTRUCTOR_SECURITIES_REPORT_SOURCE(derivedClass)

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRSecuritiesReportSource::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_SECURITIES_REPORT_SOURCE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * External data source factory for securities report.
 * Responsible for treating data feed correctly.
 * @version 6.3
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportSource
{
public:
	/** Constructor. */
	CSRSecuritiesReportSource();

	/** Destructor. */
	virtual ~CSRSecuritiesReportSource();

	/** Clone interface. */
	virtual CSRSecuritiesReportSource* Clone() const = 0;

	/** Part of clone interface. */
	virtual void Initialise(const CSRSecuritiesReportSource& source);

	/** Typedef for the prototype : the key is a const char*. */
	typedef tools::CSRPrototype<CSRSecuritiesReportSource, const char*, tools::less_char_star> prototype;

	/** Access to the prototype singleton. */
	static prototype& GetPrototype();

	/** Allows to provide custom data feed interface (in case where no parameterization is required, like DB fetching). */
	virtual const CSRSecuritiesReportSourceData* GetSourceData() const { return 0; }

	/** Result (calculation). */
	virtual CSRSecuritiesReportResult* new_SecuritiesReportResult(CSRSecuritiesExtractionTrade * trade = 0) const = 0;
	virtual CSRSecuritiesReportResultHier * new_SecuritiesReportResultHier(CSRSecuritiesReportResultHier & node) const = 0;
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphSecuritiesReportSource_H_