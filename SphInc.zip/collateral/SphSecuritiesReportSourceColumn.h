#ifndef _SphSecuritiesReportSourceColum_H_
#define _SphSecuritiesReportSourceColum_H_

#include "SphInc/collateral/SphSecuritiesReportSource.h"
#include "SphInc/collateral/SphSecuritiesReportColumn.h"
#include "SphInc/collateral/SphSecuritiesReportResult.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

/**
 * Adapter class template for columns specific to given external source.
 * @param X CSRSecuritiesReportSource derived class.
 * @version 6.3
 */
template<class X>
class CSRSecuritiesReportExternalSourceColumn : public CSRSecuritiesReportColumn
{
protected:
	CSRSecuritiesReportExternalSourceColumn(const _STL::string& columnGroup)
		: CSRSecuritiesReportColumn(columnGroup) {}
public:
	virtual	void GetCell(const CSRSecuritiesReportResult &result, SSCellValue *value, SSCellStyle *style) const
	{
		const CSRSecuritiesReportResultHier* node = dynamic_cast<const CSRSecuritiesReportResultHier*>(&result);
		if (!node || node && node->external_empty())
			return;
		CSRSecuritiesReportResultHier::MExternalResult::const_iterator ite;
		for (ite=node->external_begin(); ite!=node->external_end(); ++ite)
		{
			const SSecuritiesReportSourceData& eSource = ite->first;
			const CSRSecuritiesReportResultHier* eHier = ite->second;
			const X* x = eHier ? dynamic_cast<const X*>(eSource.fSource) : 0;
			if (x)
			{
				GetExternalSourceCell(result, eSource, *eHier, value, style);
				return;
			}
		}
	}

	/** To be implemented in derived classes. */
	virtual void GetExternalSourceCell(const CSRSecuritiesReportResult &result,
		const SSecuritiesReportSourceData& source, const CSRSecuritiesReportResultHier& externalResult,
		SSCellValue *value, SSCellStyle *style) const = 0;
};

	}
}
SPH_EPILOG
#endif  // _SphSecuritiesReportSourceColum_H_

