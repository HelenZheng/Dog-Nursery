#pragma once
#ifndef _SphSecuritiesReportTransactionEvent_H_
#define _SphSecuritiesReportTransactionEvent_H_

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRSecuritiesReport;

/**
 * Interface for notifications of instrument and position updates of the Securities Inventory report.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL ISecuritiesReportTransactionUpdateListener
{
public:
	/** Trivial Destructor. */
	virtual ~ISecuritiesReportTransactionUpdateListener();
	/** Called to notify about securities report update. */
	virtual void OnSecuritiesEvent(long underlying, sophis::portfolio::PositionIdent mvtident) = 0;
};

/**
 * Manager class for handling Securities Inventory report and listeners.
 * @version 5.3.6
 * @version 7.1.1
 */
class SOPHIS_COLLATERAL CSRSecuritiesReportTransactionEvent
{
public:
	/** Trivial Constructor. */
	CSRSecuritiesReportTransactionEvent();
	/** Trivial Destructor. */
	~CSRSecuritiesReportTransactionEvent();

	/** Returns singleton instance of the manager, the instance must not be deleted. */
	static CSRSecuritiesReportTransactionEvent& GetInstance();

	/// Allocate the instance object
	static void AllocateInstance();

	/// Delete the instance object
	static void DeleteInstance();

	/** Add registered listener. */
	void AddListener(ISecuritiesReportTransactionUpdateListener * listener);

	/** Remove listener. */
	void RemoveListener(ISecuritiesReportTransactionUpdateListener * listener);
	
	/** Notifies listeners about update. */
	void UpdateListeners(long underlying, sophis::portfolio::PositionIdent mvtident);

	/** List of listeners. */
	_STL::vector<ISecuritiesReportTransactionUpdateListener *> fListeners;

	/** Add report which contains delta listener to the subscribers. */
	void AddDeltaListenerReport(CSRSecuritiesReport* report);

	/** Remove report from delta listener subscribers. */
	void RemoveDeltaListenerReport(CSRSecuritiesReport* report);

	/** List of reports that have delta listeners. */
	_STL::vector<CSRSecuritiesReport *> fReports;

protected:
	static _STL::unique_ptr<CSRSecuritiesReportTransactionEvent> fInstance;
};

	} 
} // sophis
SPH_EPILOG

#endif