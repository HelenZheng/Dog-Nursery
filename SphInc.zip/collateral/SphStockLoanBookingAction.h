#pragma once
#ifndef _SphStockLoanBookingAction_H_
#define _SphStockLoanBookingAction_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/tools/SphValidation.h"

#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRLoanAndRepo;
		class CSRCommission;
	}
	namespace portfolio {
		class CSRTransaction;
		class CSRPosition;
		typedef SOPHIS_FIT _STL::vector<const CSRPosition*> CSRPositionVector;	
	}
	namespace collateral {

/**
 * Macros for handling stock loan and repo booking action implementation and prototype.
 * @version 5.3.6
 */
#define DECLARATION_SL_BOOKING_ACTION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::collateral::CSRStockLoanBookingAction)
#define CONSTRUCTOR_SL_BOOKING_ACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_SL_BOOKING_ACTION(derivedClass)
#define	INITIALISE_SL_BOOKING_ACTION(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Interface for triggering user actions during Stock Loan and Repo booking.
 * The callbacks are done before the transaction save and before any back office workflow status is determined.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL CSRStockLoanBookingAction
{
public:
	/** Trivial constructor. */
	CSRStockLoanBookingAction();
	/** Trivial destructor. */
	virtual ~CSRStockLoanBookingAction();

	/**
	 * Invoked by Stock Loan and Repo creation framework to allow to modify transaction information.
	 * Called for single stock loan and repo booking, for main (principal) transaction.
	 * None of the information has been saved or committed yet.
	 * To be implemented in the derived classes.
	 * @param loanRepo Instrument similar to the one being created during the booking.
	 * @param transaction Transaction being created, to be modified if required.
	 * @param messages Event vector.
	 * @param eventId Kernel event id used for creation.
	 */
	virtual void OnStockLoanCreate(const instrument::CSRLoanAndRepo& loanRepo, 
		portfolio::CSRTransaction& transaction,
		tools::CSREventVector& messages,
		long eventId) const = 0;

	/**
	 * Invoked by Stock Loan and Repo creation framework to allow to modify transaction information.
	 * Called for single stock loan and repo booking, for collateral transaction,
	 * when it is present for the Cash vs Security Per Contract and Security vs Security Per Contract.
	 * None of the information has been saved or committed yet.
	 * By default invokes OnStockLoanCreate().
	 * @param loanRepo The securities collateral instrument, the one being used or created during the booking.
	 * @param transaction Collateral transaction being created, to be modified if required.
	 * @param messages Event vector.
	 * @param eventId Kernel event id used for creation.
	 */
	virtual void OnStockLoanCollateralCreate(const instrument::CSRLoanAndRepo& loanRepo, 
		portfolio::CSRTransaction& transaction,
		tools::CSREventVector& messages,
		long eventId) const;

	/**
	 * Invoked by Stock Loan and Repo creation framework to allow to modify any transaction information.
	 * Called for multiple (basket) stock loan booking.
	 * None of the information has been saved or committed yet.
	 * By default invokes OnStockLoanCreate().
	 * @param loanRepo Instrument similar to the one being created during the booking.
	 * @param transaction Transaction being created, to be modified if required.
	 * @param messages Event vector.
	 * @param eventId Kernel event id used for creation.
	 * @param nb Current index in the list of multiple (basket) booking.
	 */
	virtual void OnStockLoanBasketCreate(const instrument::CSRLoanAndRepo& loanRepo, 
		portfolio::CSRTransaction& transaction,
		tools::CSREventVector& messages,
		long eventId,
		int nb) const;

	/**
	 * Invoked by Stock Loan and Repo creation framework to allow after the multiple (basket) booking creation
	 * but before the created positions have been linked together through the position link.
	 * Invoked prior to CSRPositionLinker::CreateNewPositionLinkID.
	 * @see {@link CSRPositionLinker::CreateNewPositionLinkID}
	 * By default does nothing.
	 * @param positionList List of stock loan positions created (but not yet linked), can be modified.
	 * @param basketBookingName Name of the link, can be modified.
	 */
	virtual void OnStockLoanBasketLink(portfolio::CSRPositionVector& positionList,
		_STL::string& basketBookingName) const;

	/**
	 * Invoked by Stock Loan and Repo expiry processing framework to allow to modify expiry transaction information.
	 * Called for any stock loan and repo, for main (principal) expiry transaction.
	 * None of the information has been saved or committed yet.
	 * To be implemented in the derived classes.
	 * @param loanRepo Stock Loan or Repo instrument.
	 * @param transaction Expiry transaction being created, to be modified if required.
	 * @version 6.3.1.8
	 */
	virtual void OnStockLoanExpiry(const instrument::CSRLoanAndRepo& loanRepo, 
		portfolio::CSRTransaction& transaction) const;

	/**
	 * Invoked by Stock Loan and Repo forecast and expiry processing framework 
	 * to allow to modify commission and interest transactions.
	 * Called for any stock loan and repo, for commission and interest tickets.
	 * None of the information has been saved or committed yet.
	 * To be implemented in the derived classes.
	 * @param loanRepo Stock Loan or Repo instrument.
	 * @param transaction Commission or interest transaction being created, to be modified if required.
	 * @version 6.3.1.8
	 */
	virtual void OnStockLoanCommissionInterest(const instrument::CSRLoanAndRepo& loanRepo, 
		portfolio::CSRTransaction& transaction) const;

	/**
	 * Invoked by Stock Loan and Repo expiry processing framework to allow to modify expiry transaction information.
	 * Called for contract per contract stock loan and repo, for securities collateral expiry transaction.
	 * None of the information has been saved or committed yet.
	 * To be implemented in the derived classes.
	 * @param secCollateral Securities collateral instrument.
	 * @param transaction Expiry transaction being created, to be modified if required.
	 * @version 6.3.1.8
	 */
	virtual void OnStockLoanCollateralExpiry(const instrument::CSRLoanAndRepo& secCollateral, 
		portfolio::CSRTransaction& transaction) const;

	/**
	 * Invoked by Stock Loan and Repo expiry processing framework to allow to modify expiry transaction information.
	 * Called for contract per contract stock loan and repo, for cash collateral expiry transaction.
	 * None of the information has been saved or committed yet.
	 * To be implemented in the derived classes.
	 * @param cashCollateral Cash collateral instrument.
	 * @param transaction Expiry transaction being created, to be modified if required.
	 * @version 6.3.1.8
	 */
	virtual void OnStockLoanCollateralExpiry(const instrument::CSRCommission& cashCollateral, 
		portfolio::CSRTransaction& transaction) const;

	/** Prototype definition. */
	typedef tools::CSRPrototype<CSRStockLoanBookingAction, const char *, tools::less_char_star> prototype;

	/** Access to the prototype singleton.
	 * To add a trigger to this singleton, use INITIALISE_SL_BOOKING_ACTION.
	 * @see {@link tools::CSRPrototype}
	 */
	static prototype& GetPrototype();
};

	} // collateral
} // sophis
SPH_EPILOG
#endif // _SphStockLoanBookingAction_H_