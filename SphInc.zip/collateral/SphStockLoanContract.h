#ifndef _SphStockContract_H_
#define _SphStockContract_H_

#include "SphInc/SphMacros.h" // For SOPHIS_COLLATERAL
#include "SphTools/SphCommon.h"
#include "SphInc/Collateral/SphLbaType.h"
#include "SphInc/instrument/SphForexSpot.h"
#include "SphInc/portfolio/SphExtraction.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {

	namespace instrument {
		class CSRLoanAndRepo;
	}

	namespace collateral {

		class CSRCashInterestExplanationList;
		class CSRCommissionExplanationList;
		class CSRStockLoanResult;

/**
 * Structure representing securities collateral (margin call) information in the contract.
 * @version 6.2.2
 */
struct SOPHIS_COLLATERAL SMarginCallsData
{
	/// Instrument id (sicovam)
	long fReference;
	/// Instrument reference
	_STL::string fInstrumentReference;
	/// Instrument name
	_STL::string fInstrumentName;
	/// Haircut
	double fHairCutInProduct;
	/// Quantity
	double fQuantity;
	/// Nominal where instrument is bond
	double fNominal;
	/// Spot (dirty for bonds)
	double fSpot;
	/// Collateral Value
	double fCollateralValue;
};

/**
 * High level interface for obtaining information on specific stock loan contract position.
 * Only available in advanced stock loan module.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRStockLoanContract
{
public:

	/** Creates new instance. Will make a DB query to retrieve the list of all counterparty/entity pairs.
	 * @param mvtident Stock Loan or Repo position identifier.
	 * @return new object containing the data or null of position does not exist or it is not a principal stock loan (repo) position. */
	static CSRStockLoanContract* new_CSRStockLoanContract(sophis::portfolio::PositionIdent mvtident);

	/** Creates new instance. The counterparty/entity pair is fixed and no DB query is made.
	 * @param mvtident Stock Loan or Repo position identifier.
	 * @param cpty Counterparty of the position.
	 * @param entity Entity of the position.
	 * @return new object containing the data or null of position does not exist or it is not a principal stock loan (repo) position. */
	static CSRStockLoanContract* new_CSRStockLoanContract(sophis::portfolio::PositionIdent mvtident, long cpty, long entity);

	/** Creates new instance. The result is not computed but the current result computation is used.
	 * The counterparty/entity pair is fixed according to the given result.
	 * @param result Result object containing Stock Loan (Repo) calculations.
	 * @param calculationDate Calculation date of the result.
	 * @return new object containing the data or null of position does not exist or it is not a principal stock loan (repo) position. */
	static CSRStockLoanContract* new_CSRStockLoanContract(const CSRStockLoanResult& result, long calculationDate);

	/** Dummy Constructor. */
	CSRStockLoanContract() {}

	/** Dummy Destructor. */
	virtual ~CSRStockLoanContract() {}

	/** Structure representing cpty/entity combinations for this positon. */
	typedef _STL::vector< _STL::pair<long,long> > CptyEntityList;

	/** Returns list of cpty/entity combinations for this position. 
	 * @param mvtident Stock Loan or Repo position identifier. */
	static CptyEntityList GetCptyEntityList(sophis::portfolio::PositionIdent mvtident);

	/** Returns convention of the instrument, corresponding to given position.
	* @param mvtident Stock Loan or Repo position identifier. */
	static long GetConvention(sophis::portfolio::PositionIdent mvtident);

	/** Returns list of cpty/entity combinations for this position. */
	virtual CptyEntityList GetCptyEntityList() const = 0;

	/** Calculates the data for position for given counterparty, entity, and reporting date.
	 * @param cpty Counterparty of the position. 
	 * @param entity Entity of the position. 
	 * @param date Optional, calculation date, default is today.
	 * @param pref Date type of reporting.*/
	virtual void Update(long cpty, long entity, long date = 0,
		portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate) = 0;

	/** Calculates the data for position using given reporting date.
	 * Counterparty and entity are taken from the initial parameters.
	 * @param date Optional, calculation date, default is today. 
	 * @param pref Date type of reporting. */
	virtual void Update(long date = 0,
		portfolio::CSRExtraction::eReportDatePref pref = portfolio::CSRExtraction::eDefaultDate) = 0;

	/** Returns calculation date as used for the result computation. */
	virtual long GetCalculationDate() const = 0;

	/** Returns counterparty used for the result computation. */
	virtual long GetCounterparty() const = 0;

	/** Returns entity used for the result computation. */
	virtual long GetEntity() const = 0;

	/** Clones the current result. */
	virtual CSRStockLoanContract* Clone() const = 0;

	/** Returns reference to the stock loan and repo instrument defining the position. */
	virtual const instrument::CSRLoanAndRepo& GetLoanAndRepo() const = 0;

	/** Returns name of the stock loan position. */
	virtual _STL::string GetDisplayName() const = 0;

	/** Returns stock loan (repo) type of the contract. */
	virtual CSRLbaType::eLbaType GetLbaType() const = 0;

	/** Returns position id (mvtident) of this stock loan contract. */
	virtual sophis::portfolio::PositionIdent GetPositionId() const = 0;

	/** Returns portfolio code where this stock loan contract is located. */
	virtual long GetPortfolioCode() const = 0;

	/** Returns transaction id (refcon) of the inital trade. */
	virtual portfolio::TransactionIdent GetInitialTradeId() const = 0;

	/** Returns Start Date of the contract. */
	virtual long GetStartDate() const = 0;

	/** Returns Last Margin Call Date on the contract. */
	virtual long GetLastMarginDate() const = 0;

	/** Returns Maturity Date (Expiry) of the stock loan (repo) contract where applicable. */
	virtual long GetMaturityDate() const = 0;

	/** Returns Instrument Id (sicovam) of the principal part of the stock loan (repo). */
	virtual long GetPrincipalCode() const = 0;

	/** Returns Quantity (or Amount) of the principal part of the stock loan (repo). */
	virtual double GetPrincipalQuantity() const = 0;

	/** Returns the Nominal of the Principal. */
	virtual double GetPrincipalNominal() const = 0;

	/** Returns Last Adjusted Spot of the Principal.
	 * Depending on the type of the contract, the Spot can be adjusted manually (via Spot Modification, 
	 * Cash Margin Call, etc.) or automatically (via Fee Mark, Open Basis, etc.). */
	virtual double GetLastFeeMark() const = 0;

	/** Returns Next Interest Payment Date for cash collateral. */
	virtual long GetNextInterestDate() const = 0;
	
	/** Returns Next Billing Date for commission. */
	virtual long GetNextBillingDate() const = 0;

	/** Returns Billing Currency used for commission billing. */
	virtual long GetBillingCurrency() const = 0;

	/** Returns last specified commission rate used for commission billing. */
	virtual double GetCommissionRate() const = 0;

	/** Returns current commission amount on principal (based on calculation date).
	 * @return Amount in billing currency. */
	virtual double GetEstimatedBilling() const = 0;

	/** Returns yesterday's commission (based on calculation date - 1). 
	 * @return Amount in billing currency. */
	virtual double GetYesterdayCommission() const = 0;

	/** Returns commission paid today (based on calculation date). */
	virtual double GetCommissionPaidToday() const = 0;

	/** Returns Hedging Ratio applied to the principal. This value is used for calculations.
	 * @param valueInProduct Optional, used for display.
	 * @return hedging value used for calculations. */
	virtual double GetPrincipalHedging(double *valueInProduct=0) const = 0;

	/** Returns Principal Spot used to calculate principal value. */
	virtual double GetPrincipalSpot() const = 0;

	/** Returns Accrued value calculated for the principal. */
	virtual double GetPrincipalAccrued() const = 0;

	/** Returns Collateralised Spot value in Collateralised Spot currency. */
	virtual double GetCollateralisedSpot() const = 0;

	/** Returns Collateralised Spot value in Collateralised Spot currency using given fx rules. */
	virtual double GetCollateralisedSpot(double fxValue, instrument::eForexOrder fxOrder) const = 0;

	/** Returns Collateralised Spot currency. */
	virtual long GetCollateralisedSpotCurrency() const = 0;

	/** Returns Securities Collateral Haircut Ratio. This value is used for calculations.
	 * @param valueInProduct Optional, used for display.
	 * @return haircut value used for calculations. */
	virtual double GetSecuritiesCollateralHaircut(double *valueInProduct=0) const = 0;

	/** Returns Securities Collateral Spot used to calculate securities collateral value. */
	virtual double GetSecuritiesCollateralSpot() const = 0;

	/** Returns Quantity of the securities collateral part of the stock loan (repo). */
	virtual double GetSecuritiesCollateralQuantity() const = 0;

	/** Returns the Nominal of the Collateral. */
	virtual double GetSecuritiesCollateralNominal() const = 0;

	/** Returns Instrument Id (sicovam) of the securities collateral part of the stock loan. */
	virtual long GetSecuritiesCollateralCode() const = 0;

	/** Returns Accrued value calculated for the securities collateral. */
	virtual double GetSecuritiesCollateralAccrued() const = 0;

	/** Returns maturity of the securities collateral (if applicable). */
	virtual long GetSecuritiesCollateralMaturityDate() const = 0;

	/** Position Id (mvtident) of the securities collateral movement (if applicable). */
	virtual long GetSecuritiesCollateralPositionId() const = 0;

	/** Collateral folio containing the securities collateral movement (if applicable). */
	virtual long GetSecuritiesCollateralPortfolioCode() const = 0;

	/** The latest deal id (refcon) from the securities collateral movement (if applicabl). */
	virtual sophis::portfolio::TransactionIdent GetSecuritiesCollateralMaxTradeId() const = 0;

	/** Returns Currency Id (sicovam) of the cash collateral part of the stock loan (repo).
	 * The method returns a value if and only if there is only one cash collateral present.	*/
	virtual long GetCashCollateralCurrency() const = 0;

	/** Returns Interest Rate Id of the cash collateral part of the stock loan (repo).
	 * The method returns a value if and only if there is only one cash collateral present.	*/
	virtual long GetCashCollateralInterestRate() const = 0;

	/** Returns last specified spread for cash collateral par of the stock loan (repo). */
	virtual double GetCashCollateralSpread() const = 0;

	/** Returns Amount of the cash collateral part of the stock loan.
	 * The Amount is the sum of initial cash collateral amount (also known as initial deposit)
	 * and cash margin call collateral amount.
	 * @return Amount in cash collateral currency.
	 * The method returns a value if and only if there is only one
	 * cash collateral present.	*/
	virtual double GetTotalCashCollateralAmount() const = 0;

	/** Returns Amount of the initial deposit (cash amount in the initial ticket)
	 * for Security versus Cash Per Contract deals.
	 * @return Amount in cash collateral currency. */
	virtual double GetInitialDepositAmount() const = 0;

	/** Returns Amount of the cash collateral excluding the initial cash collateral amount.
	 * For Contract Per Contract deals, it returns the sum of all cash margin calls.
	 * @return Amount in cash collateral currency. */
	virtual double GetMarginCashCollateralAmount() const = 0;

	/** Returns current amount of interest on cash collateral (based on calculation date).
	 * The method returns a value if and only if there is only one cash collateral present.
	 * @return Amount in cash collateral currency. */
	virtual double GetCashCollateralInterest() const = 0;
	
	/** Returns current amount of interest on cash collateral (based on calculation date - 1).
	 * The method returns a value if and only if there is only one cash collateral present.
	 * @return Amount in cash collateral currency.*/
	virtual double GetCashCollateralYesterdayInterest() const = 0;

	/** Returns interest paid today (based on calculation date).
	 * The method returns a value if and only if there is only one cash collateral present.
	 * @return Amount in cash collateral currency. */
	virtual double GetCashCollateralInterestPaidToday() const = 0;

	/** Returns Cash Collateral Haircut Ratio. This value is used for calculations.
	 * The method may not return a value for Security versus Cash Per Contract deals
	 * where only initial deposit is present, without cash margin calls.
	 * The method returns a value if and only if there is only one cash collateral present.
	 * @param valueInProduct Optional, used for display.
	 * @return haircut value used for calculations.	*/
	virtual double GetMarginCashCollateralHaircut(double *valueInProduct=0) const = 0;

	/** Returns Haircut Ratio of Initial Deposit. This value is used for calculations.
	 * The method returns a value only for Security versus Cash Per Contract deals
	 * where the notion of initial deposit (cash amount in the initial ticket) is present.
	 * The reason being the haircuts for initial deposit and subsequent cash
	 * margin calls can differ.
	 * @param valueInProduct Optional, used for display.
	 * @return haircut value used for calculations. */
	virtual double GetInitialDepositHaircut(double *valueInProduct=0) const = 0;

	/** Position Id (mvtident) of the cash collateral movement for X vs Sec Per Contract. */
	virtual long GetCashCollateralPositionId() const = 0;

	/** Collateral folio containing the cash collateral movement for X vs Sec Per Contract. */
	virtual long GetCashCollateralPortfolioCode() const = 0;

	/** The latest deal id (refcon) from the cash collateral movement for X vs Sec Per Contract. */
	virtual sophis::portfolio::TransactionIdent GetCashCollateralMaxTradeId() const = 0;

	/** Returns collateral cash interest explanation list or null if there is either no cash explanation.
	 * Under normal circumstances, there should be maximum of one cash collateral present.
	 * The pointer must not be deleted. */
	virtual const CSRCashInterestExplanationList* GetCollateralCashInterestExplanationList() const = 0;

	/** Returns principal (repo) cash interest explanation list or null if no cash explanation is available.
	 * The pointer must not be deleted. */
	virtual const CSRCashInterestExplanationList* GetRepoCashInterestExplanationList() const = 0;

	/** Returns commission explanation list or null if no commission explanation is available.
	 * The pointer must not be deleted. */
	virtual const CSRCommissionExplanationList* GetCommissionExplanationList() const = 0;

	/** Returns list of securities collateral, if applicable.
	 * @version 6.2.2 */
	virtual _STL::vector<SMarginCallsData> GetMarginCalls() const = 0;

};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphStockContract_H_
