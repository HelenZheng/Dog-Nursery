#ifndef _SphStockContractColumn_H_
#define _SphStockContractColumn_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG

struct SSCellStyle;
union SSCellValue;

namespace sophis {
	namespace collateral {

class CSRStockLoanContract;
class CSRCollateralReportContext;

/**
 * Macros for handling stock loan contract column prototype implementation.
 * @version 5.3.6
 */
#define DECLARATION_STOCKLOAN_CONTRACT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRStockLoanContractColumn)
#define CONSTRUCTOR_STOCKLOAN_CONTRACT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_STOCKLOAN_CONTRACT_COLUMN(derivedClass)
#define	INITIALISE_STOCKLOAN_CONTRACT_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Stock loan contract column and prototype.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRStockLoanContractColumn
{
public:
	/** Destructor. */
	virtual ~CSRStockLoanContractColumn() {}

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param line Stock loan contract.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	virtual	void GetCell(const CSRCollateralReportContext &ctx, const CSRStockLoanContract &line, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Returns the default cell size in pixels.
	 */
	virtual short GetDefaultWidth() const;

	/**
	 * Returns the id.
	 * The value is created at the end of the initialise because it must be unique according to the table COLUMN_NAME.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * Used when building the columns by {@link CSUReorderColumns}.
	 */
	void SetId(long id)
	{
		fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a const char*.
	 */
	typedef tools::CSRPrototypeWithId<CSRStockLoanContractColumn, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_STOCKLOAN_CONTRACT_COLUMN.
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

	/**
	 * Fills cell value and style with given amount in given currency.
	 * Useful for GUI display.
	 * @param x Amount in given currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the instrument for the amount.
	 */
	static void FillMoney(double x, SSCellValue *value, SSCellStyle *style, long ccy);

	/**
	 * Fills cell value and style with string representation of given currency.
	 * Useful for GUI display.
	 * @param ccy Currency to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillCurrency(long ccy, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills cell value and style with given date.
	 * Useful for GUI display.
	 * @param date Date to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 */
	static void FillDate(long date, SSCellValue *value, SSCellStyle *style);

	/**
	 * Fills style for display of a double value.
	 * Useful for GUI display.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param ccy Currency of the double value.
	 * @param dec Number of decimals to be displayed.
	 */
	static void FillStyleDouble(SSCellStyle *style, long ccy, int dec);

	/** Internal. */
	static void RefreshPrototype();

protected:
	long	fId;
};

	} // collateral
} // sophis

SPH_EPILOG
#endif // _SphStockContractColumn_H_
