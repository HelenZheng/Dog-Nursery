#pragma once
#ifndef _SphStockLoanContractEventDialog_H_
#define _SphStockLoanContractEventDialog_H_

#ifndef GCC_XML

#include "SphInc/gui/SphColumnExplDialog.h"
#include "SphInc/gui/SphButton.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/collateral/SphCollateralResultColumn.h"
#include __STL_INCLUDE_PATH(set)

SPH_PROLOG
namespace sophis {
	namespace collateral {

class CSRStockLoanContract;
class CSRStockLoanEventContextMenu;
class CSRStockLoanContractExplDialog;

/**
 * Listener to notify of the update to the specified contracts.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL_GUI ISRStockLoanContractModificationListener
{
public:
	/**
	 * @param contractList List of contracts which must be reloaded.
	 */
	virtual void OnChange(_STL::set<const CSRStockLoanContract*>& updatedContracts) = 0;
};

/**
 * Stock loan contract explanation list.
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRStockLoanContractExplList : public gui::CSRLineDataExplList
{
private:
	ISRStockLoanContractModificationListener *fListener;
	CSRCollateralReportContext &fCtx;

public:
	CSRStockLoanContractExplList(CSRStockLoanContractExplDialog *dialog, int ERId_List);
	virtual ~CSRStockLoanContractExplList();

	/// See {@link CSREditList::CanSort}
	virtual bool CanSort(void) {return true;}
	/// See {@link CSREditList::Sort}
	virtual void Sort(int NRC_Colonne, Boolean croissant);
	/// See {@link CSREditList::GetContextMenu}
	virtual CSCtxMenu* GetContextMenu(void);

	/// See {@link CSRLineDataExplList::GetCell}
	virtual void GetCell(int line, int col, SSCellValue *value, SSCellStyle *style) const;

	// Context menu implementation based on CSRStockLoanEventContextMenu prototype
	bool OnContextMenuConstruct();
	bool OnContextMenuInit(int line, int menuItem);
	bool OnContextMenu(int line, int menuItem);

	/// See {@link CSRElement::CanSort}
	virtual bool PasteFromHier(const CSWindHier* windHier, long nbelem, const long* elem);
	/// See {@link CSRElement::CanSort}
	virtual bool CanDropFromHier(const CSWindHier* windHier, long nbelem, const long* elem) const;

protected:
	/// See {@link CSRColumnExplList::GetColumnAlignment}
	virtual gui::eAlignmentType GetColumnAlignment(int elemId) const;

	// Implementation based on class objects
	void AddStockLoanContract(const CSRStockLoanContract *slContract);
	void AddStockLoanContracts(_STL::vector<const CSRStockLoanContract*>& slContractList);

private:
	bool GetSelectedContracts(_STL::set<const CSRStockLoanContract*>& contractList) const;
	const sophis::collateral::CSRStockLoanEventContextMenu *GetMenu(int line, int menuItem);
	static _STL::vector<int>& GetDefaultColumns();
	int fContextMenuCount;
	_STL::map<int,int> fContextMenuMap;

	friend class CSRStockLoanContractExplDialog;
};

/**
 * Stock loan and repo contract management dialog.
 * Displays stock loan and repo contracts in the list.
 * Allows contract management via context menu.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRStockLoanContractExplDialog : public gui::CSRColumnExplDialog, public ISRStockLoanContractModificationListener, public CSRCollateralReportContext
{
public:
	/** Adds given contract to the list of currently managed contracts.
	 * If the dialog does not exist it is created. */
	static void AddStockLoanContract(long position, long cpty = 0, long entity = 0);
	/** Adds given contract list to the list of currently managed contracts.
	 * If the dialog does not exist it is created. */
	static void AddStockLoanContracts(_STL::set<long>& positionList);

	/** enum for gui ids on the dialog */
	enum {
		eDlogExplList = 1,
		eRefreshButton,
	};

	virtual ~CSRStockLoanContractExplDialog();

	virtual gui::CSRColumnExplList* new_ColumnExplList() { return new CSRStockLoanContractExplList(this, eDlogExplList); }
	virtual _STL::string GetColumnExplTitle();
	virtual bool RemoveLine(int lineNumber, const void *ptr = 0);
	virtual void DoubleClick(int lineNumber, const void *ptr = 0);

	virtual void Init(gui::ISRColumnExplCreator& creator);
	virtual void InitAlreadyOpen(gui::ISRColumnExplCreator& creator);
	virtual void Open();
	virtual void OpenAfterInit();
	
	/// ISRStockLoanContractModificationListener interface
	virtual void OnChange(_STL::set<const CSRStockLoanContract*>& updatedContracts);

	void UpdateContracts();

	/** Refresh button to refresh the selected contract(s) in the dialog. */
	class CSRRefreshButton : public sophis::gui::CSRButton
	{
		CSRStockLoanContractExplDialog* fDlg;
	public:
		CSRRefreshButton(CSRStockLoanContractExplDialog *dialog, int ERId_Element)
			:CSRButton(dialog, ERId_Element)
			,fDlg(dialog) {}
		virtual	void Action() {	fDlg->UpdateContracts(); }
	};

protected:
	CSRStockLoanContractExplDialog();
	void AddPosition(long position, long cpty, long entity);
	void AddPositionList(_STL::set<long>& positionList);
	bool GetSelectionPreference(_STL::set<const CSRStockLoanContract*>& selectedContracts);
	CSRStockLoanContractExplList* GetExplanationList();
	void SortContracts(void** orderedList, int size);

	bool fOnlySelectedContracts;
	_STL::vector<const CSRStockLoanContract*> fContractList;

	friend class CSRStockLoanContractExplCreator;
	friend class CSRStockLoanContractExplList;
};

/**
 * Utility class to create desired implementation of the stock loan and repo contract management dialog.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRStockLoanContractExplCreator : public gui::ISRColumnExplCreator
{
public:
	CSRStockLoanContractExplCreator() : fPosition(0), fCpty(0), fEntity(0) {}
	CSRStockLoanContractExplCreator(_STL::set<long>& positionList) : fPositionList(positionList), fPosition(0), fCpty(0), fEntity(0) {}
	CSRStockLoanContractExplCreator(long position, long cpty, long entity) : fPosition(position), fCpty(cpty), fEntity(entity) {}
	virtual gui::CSRColumnExplDialog* new_ColumnExplDialog();
	virtual CSRUserEditInfo* new_UserEditInfo();

public:
	long fPosition, fCpty, fEntity;
	_STL::set<long> fPositionList;
};

/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 * @version 5.3.6
 */
#define DECLARATION_SL_EVENT_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRStockLoanEventContextMenu)
#define CONSTRUCTOR_SL_EVENT_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_SL_EVENT_CONTEXT_MENU(derivedClass)
#define	INITIALISE_SL_EVENT_CONTEXT_MENU(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name); derivedClass::GetPrototype().GetData(name)->SetId(++sophis::collateral::CSRStockLoanEventContextMenu::fCount)

/**
 * Interface for creating custom context menu in Stock Loan and Repo contract management window.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @since 5.3.6
 */
class SOPHIS_COLLATERAL_GUI CSRStockLoanEventContextMenu
{
public:

	/**
	 * Returns the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	int GetId() const
	{
		return fId;
	}

	/**
	 * Sets the id.
	 * The value is automatically created at the initialisation because it must be unique.
	 * For internal use.
	 */
	void SetId(long id) const
	{
		(const_cast<CSRStockLoanEventContextMenu*>(this))->fId = id;
	}

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototypeWithId<CSRStockLoanEventContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_SL_EVENT_CONTEXT_MENU.
	 */
	static prototype& GetPrototype();

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsEnabled returns true, the key of the prototype (that is its name) is enabled in the context menu.
	 * User should generally override IsEnabled() or IsDisplayed() or both.
	 * @param contract Current selected stock loan or repo contract.
	 * @param contractList List containing all selected contracts.
	 * @return true to enabled the prototype in the context menu, false to disable it.
	 */
	virtual bool IsEnabled(const CSRStockLoanContract& contract,
		_STL::set<const CSRStockLoanContract*>& contractList) const { return true; }

	/**
	 * This function is called when opening the dynamic context menu.
	 * If IsDisplayed returns true, the key of the prototype (that is its name) is displayed in the context menu,
	 * either enabled or disabled, based on IsEnabled() method.
	 * By default the menu item should always appear, but it can be overridden.
	 * User should generally override IsEnabled() or IsDisplayed() or both.
	 * @param contract Current selected stock loan or repo contract.
	 * @param contractList List containing all selected contracts.
	 * @return true to display the prototype in the context menu, false not to show it.
	 */
	virtual bool IsDisplayed(const CSRStockLoanContract& contract,
		_STL::set<const CSRStockLoanContract*>& contractList) const { return true; }

	/**
	 * Perform some action (like open a specific dialog) using the given third party information.
	 * Must be overloaded and implemented in custom classes.
	 * @param menuLabel The actual context menu label that was selected.
	 * @param contract Current selected stock loan or repo contract.
	 * @param contractList List containing all selected contracts.
	 * @param updatedContracts Must be filled with the contracts that have been updated.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoStockLoanEventContextMenu(_STL::string& menuLabel,
		const CSRStockLoanContract& contract, _STL::set<const CSRStockLoanContract*>& contractList,
		_STL::set<const CSRStockLoanContract*>& updatedContracts) const = 0;

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }
	
	/**
	 * Counts the number of prototypes installed and assigns each prototype a number in sequence.
	 * For internal use.
	 */
	static long fCount;

protected:
	long fId;
};


	} // collateral
} // sophis

SPH_EPILOG
#endif // GCC_XML
#endif // _SphStockLoanContractEventDialog_H_
