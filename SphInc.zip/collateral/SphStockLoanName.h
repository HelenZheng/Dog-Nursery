#pragma once
#ifndef _SphStockLoanName_H_
#define _SphStockLoanName_H_

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(string)
#include "SphInc/Portfolio/SphPortfolioIdentifiers.h"


SPH_PROLOG
namespace sophis {
	namespace instrument {
		class CSRLoanAndRepo;
		class CSRContractForDifference;
	}
	namespace portfolio {
		class CSRTransaction;
	}
	namespace collateral {

/**
 * Interface to allow via toolkit a custom name for stock loan and repo instrument.
 * Also supports contract for differences instrument.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL ISRStockLoanInstrumentName
{
public:
	/**
	 * Creates a name for stock loan and repo instrument.
	 * @param loanRepo Stock loan and repo instrument.
	 * @return Instrument name.
	 */
	virtual _STL::string CreateStockLoanInstrumentName(const instrument::CSRLoanAndRepo& loanRepo) const = 0;

	/**
	 * Creates a name for CFD instrument.
	 * @param cfd Contract For Difference instrument.
	 * @return Instrument name.
	 */
	virtual _STL::string CreateCFDInstrumentName(const instrument::CSRContractForDifference& cfd) const = 0;
};

/**
 * Interface to allow via toolkit a custom contract (operation) name for stock loan and repo contract.
 * Also supports contract for differences contract.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL ISRStockLoanContractName
{
public:
	/**
	 * Creates a name for stock loan and repo contract (operation).
	 * @param loanRepo Stock loan and repo instrument.
	 * @param transaction Transaction (stock loan or repo) being created.
	 * @return Contract name.
	 */
	virtual _STL::string CreateStockLoanContractName(const instrument::CSRLoanAndRepo& loanRepo,
		const portfolio::CSRTransaction& transaction) const = 0;

	/**
	 * Creates a name for CFD contract (operation).
	 * @param cfd Contract For Difference instrument.
	 * @param transaction Transaction being created.
	 * @return Contract name.
	 */
	virtual _STL::string CreateCFDContractName(const instrument::CSRContractForDifference& cfd,
		const portfolio::CSRTransaction& transaction) const = 0;
};

/**
 * Utility class used for obtaining display name for stock loans.
 * Also supports contract for differences.
 * @version 5.2.4
 * @version 5.3.6 In the toolkit.
 */
class SOPHIS_COLLATERAL CSRStockLoanName
{
public:
	/**
	 * Copies the display name of the stock loan into the given string.
	 *
	 * @param name Where the name is copied.
	 * @param length Max number of characters to copy into the name.
	 * @param stockLoanId Stock Loan instrument code (sicovam), can be null.
	 * @param mvtident Position id, can be be null.
	 */
	static void GetDisplayName(char *name, int length, long stockLoanId, sophis::portfolio::PositionIdent mvtident);

	/**
	 * Copies the display name of the stock loan or margin call into the given string.
	 * Unlike original GetDisplayName() it also takes care of both cash and securities
	 * margin call instruments. For non margin call the call is passed to GetDisplayName().
	 *
	 * @param name Where the name is copied.
	 * @param length Max number of characters to copy into the name.
	 * @param instrumentId Instrument code (sicovam), can be null.
	 * @param mvtident Position id, can be be null.
	 * @version 5.3.5
	 */
	static void GetMarginCallDisplayName(char *name, int length, long instrumentId, sophis::portfolio::PositionIdent mvtident);

	/**
	 * Registers the provided implementation of the stock loan and repo instrument name creation.
	 * Note the provided reference is used and therefore must not be destroyed.
	 * @param instrumentNameImpl Implementation class.
	 * @version 5.3.6
	 */
	static void SetStockLoanInstrumentNameImpl(const ISRStockLoanInstrumentName* instrumentNameImpl);

	/**
	 * Returns the registered implementation of the stock loan and repo instrument name creation,
	 * or null pointer if nothing has been registered.
	 * @version 5.3.6
	 */
	static const ISRStockLoanInstrumentName* GetStockLoanInstrumentNameImpl();

	/**
	 * Registers the provided implementation of the stock loan and repo contract (operation) name creation.
	 * Note the provided reference is used and therefore must not be destroyed.
	 * @param contractNameImpl Implementation class.
	 * @version 5.3.6
	 */
	static void SetStockLoanContractNameImpl(const ISRStockLoanContractName* contractNameImpl);

	/**
	 * Returns the registered implementation of the stock loan and repo contract (operation) name creation,
	 * or null pointer if nothing has been registered.
	 * @version 5.3.6
	 */
	static const ISRStockLoanContractName* GetStockLoanContractNameImpl();
};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphStockLoanName_H_