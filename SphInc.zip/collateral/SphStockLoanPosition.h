#pragma once
#ifndef _StockLoanPosition_H_
#define _StockLoanPosition_H_

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace collateral {

class CSRLBAgreement;

/**
 * Contains information about collateral position and instrument.
 *
 * @version 5.1
 */
struct PositionAndInstrumentId
{
	/**
	 * Position Id (mvtident) of the collateral movement.
	 */
	portfolio::PositionIdent fPositionId;

	/**
	 * Collateral instrument (stock loan or commission).
	 */
	long fInstrumentId;

	/**
	 * Collateral folio containing the collateral position.
	 */
	long fPortfolioCode;

	/**
	 * The latest deal from the collateral position.
	 */
	sophis::portfolio::TransactionIdent fMaxRefcon;
};

/**
 * Contains depositary, sm/dt, and payment method information of the stock loan deal from given position.
 * @version 5.2.4
 */
struct SInitialDealInfo
{
	/**
	 * Unique id of the deal from which the information is retrieved.
	 */
	portfolio::TransactionIdent fRefcon;

	/**
	 * Depositary of the deal.
	 */
	long fDepositary;

	/**
	 * Settlement method of the deal.
	 */
	long fSettlementMethod;

	/**
	 * Delivery type of the deal.
	 */
	long fDeliveryType;

	/**
	 * Payment method of the deal.
	 */
	long fPaymentMethod;

	/**
	 * Depositary of Counterparty.
	 * @version 5.3
	 */
	long fDepositaryOfCounterparty;

	/**
	 * Broker.
	 * @version 5.3.4.18
	 */
	long fBroker;

	/**
	 * Nostro physical account id.
	 * @version 7.0
	 */
	long fNostroPhysicalId;

	/**
	 * Nostro cash account id.
	 * @version 7.0
	 */
	long fNostroCashId;

	/**
	 * Lostro physical account id.
	 * @version 7.0
	 */
	long fLostroPhysicalId;

	/**
	 * Lostro cash account id.
	 * @version 7.0
	 */
	long fLostroCashId;

	// NOTE: when you add more elements don't forget to update in StockLoanPosition.cpp
	// method CSRStockLoanPosition::GetInitialDealInfo

	/**
	 * Dummy constructor, initialises everything to zeros.
	 */
	SInitialDealInfo() 
		: fRefcon(0)
		, fDepositary(0)
		, fSettlementMethod(0)
		, fDeliveryType(0)
		, fPaymentMethod(0)
		, fDepositaryOfCounterparty(0)
		, fBroker(0)
		, fNostroPhysicalId(0)
		, fNostroCashId(0)
		, fLostroPhysicalId(0)
		, fLostroCashId(0)
	{}

	/**
	 * Constructor, initialises values based on given transaction.
	 */
	SInitialDealInfo(const portfolio::CSRTransaction& tr)
		: fRefcon(0)
		, fDepositary(0)
		, fSettlementMethod(0)
		, fDeliveryType(0)
		, fPaymentMethod(0)
		, fDepositaryOfCounterparty(0)
		, fBroker(0)
		, fNostroPhysicalId(0)
		, fNostroCashId(0)
		, fLostroPhysicalId(0)
		, fLostroCashId(0)
	{
		FromTransaction(tr);
	}

	/**
	 * Initialises values based on given transaction.
	 */
	void SOPHIS_PORTFOLIO FromTransaction(const portfolio::CSRTransaction& trans);
};

/**
 * A collection of various utilities related to handling of different
 * types of stock loan positions and margin calls.
 *
 * Some of the utilities existed before in separate files such as OverloadStockLoanMarginCall.h and others.
 *
 * @version 5.2.4
 */
class SOPHIS_COLLATERAL CSRStockLoanPosition
{
public:
	/**
	 * Tries to find securities collateral margin call instrument and position information for a given 
	 * mvtident (main position) and underline stock loan instrument.
	 *
	 * It tries to find first matching securities margin call position 
	 * referring to the given main position via HISTOMVTS.REFMVTBACK and is not bound
	 * to checking the HISTOMVTS.REFERENCE field as in double-booking.
	 *
	 * @param mvtident MVTIDENT of the MAIN position.
	 * @param collatSJ Optional, Underline (sicovam) of the desired collateral instrument.
	 * @param lba Optional, Agreement deals belong to.
	 *
	 * @return PositionAndInstrumentId structure, where fPositionId represents MVTIDENT of the collateral
	 * movement and fInstrumentId represents the collateral instrument itself. If no data is found,
	 * PositionAndInstrumentId structure contains zeros.
	 */
	static PositionAndInstrumentId GetSecuritiesMarginCallPositionAndInstrumentId(portfolio::PositionIdent mvtident,
		long collatSJ=0,
		const CSRLBAgreement* lba=0);

	/**
	 * Tries to find cash collateral margin call instrument and position information for a given 
	 * mvtident (main position), cash collateral currency and rate.
	 *
	 * It tries to find first matching cash margin call position 
	 * referring to the given main position via HISTOMVTS.REFMVTBACK.
	 *
	 * @param mvtident MVTIDENT of the MAIN position.
	 * @param ccy Optional, Currency id of the desired cash collateral instrument.
	 * @param rate Optional, Rate id of the desired cash collateral instrument.
	 * @param lba Optional, Agreement deals belong to.
	 *
	 * @return PositionAndInstrumentId structure, where fPositionId represents MVTIDENT of the collateral
	 * movement and fInstrumentId represents the collateral instrument itself. If no data is found,
	 * PositionAndInstrumentId structure contains zeros.
	 */
	static PositionAndInstrumentId GetCashMarginCallPositionAndInstrumentId(portfolio::PositionIdent mvtident,
		long ccy=0,
		long rate=0,
		const CSRLBAgreement* lba=0);

	/**
	 * Tries to find a matching stock loan initial deal and retrieve depositary, 
	 * sm/dt and other information from the deal.
	 * 
	 * It is useful where the automatic (or other) tickets need to
	 * have initial values like sm/dt to map the ones of, say, the initial ticket.
	 *
	 * @param mvtident MVTIDENT of the position.
	 * @param depositary Optional, The depositary that must be matched.
	 * @param ctpy Optional, Counterparty that must be matched.
	 * @param entity Optional, Entity that must be matched.
	 *
	 * @return SInitialDealInfo structure. If no data is found, SInitialDealInfo structure contains zeros.
	 */
	static SInitialDealInfo GetInitialDealInfo(portfolio::PositionIdent mvtident,
		long depositary=0,
		long ctpy=0,
		long entity=0);

private:
	CSRStockLoanPosition() {}
};

	}
}
SPH_EPILOG
#endif // _StockLoanPosition_H_