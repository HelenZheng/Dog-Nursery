#ifndef _SphStockLoanReportingAPI_H_
#define _SphStockLoanReportingAPI_H_

#include "SphInc/collateral/SphCollateralReportingAPI.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {

	namespace collateral {
		class CSRLBAgreement;
		class CSRStockLoanResult;
		class CSRStockLoanContract;

		/**
		* Bit flags used to control the behavior and output of Stock Loan Reporting API.
		* Custom (user-defined) flags should start from 0x10000.
		* @version 5.3.
		*/
		enum eStockLoanReportingAPIFlags
		{
			/**
			* Minimum reporting results, no explanations.
			*/
			eCRFMinimum = 0x00,

			/**
			* Compute cash interest and commission explanations for results.
			*/
			eCRFComputeExplanations = 0x01,

			/**
			* Group all Contract Per Contract deals by collateral currency.
			*/
			eCRFGroupSecVsCashPerContractByCcy = 0x02,

			/**
			* To include empty pools section even if no contracts fall there. 
			* Useful if using this API for data display in GUI mode.
			*/
			eCRFAllowEmptyPools = 0x04,

			/**
			* All settings required for common GUI display of the API results.
			*/
			eCRFCommonGui = (eCRFComputeExplanations | eCRFGroupSecVsCashPerContractByCcy | eCRFAllowEmptyPools),

			/**
			* To keep expired (empty) positions in the result list. Default is remove those from result.
			* @version 5.3.6
			*/
			eCRFKeepExpiredPositions = 0x08,

		};

		/**
		* API for building and handling collateral reporting results.
		* @version 5.3.
		*/
		class SOPHIS_COLLATERAL CSRStockLoanReportingAPI : public virtual ISRCollateralReportingAPI
		{
		public:

			/**
			 * Creates an API which is going to use collateral reporting results defined by resultName.
			 * @param resultName Name of the collateral reporting result implementation to use.
			 * If not specified, the default collateral result reporting implementation is used.
			 * {@link CSRStockLoanResult::GetInstance}.
			 */
			CSRStockLoanReportingAPI();
			CSRStockLoanReportingAPI(const char *resultName);

			/**
			 * Destructor.
			 * Deletes all internal results.
			 */
			virtual ~CSRStockLoanReportingAPI();

			/**
			 * Builds a complete result hierarchy of all stock loan and commission deals
			 * related to the given collateral agreement.
			 * @param lba Collateral Agreement to which deals must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeAll(const CSRLBAgreement *lba, long calculationDate, long crfFlags);

			/**
			 * Builds a complete result hierarchy of all stock loan and commission deals
			 * related to the given collateral agreement specified as cpty/entity/convention.
			 * The values of cpty/entity/convention MUST point to a valid Collateral Agreement.
			 * @param cpty Counterparty of Collateral Agreement to which deals must belong (map) to.
			 * @param entity Entity of Collateral Agreement to which deals must belong (map) to.
			 * @param convention Convention of Collateral Agreement to which deal's instrument must belong (map) to.
			 * @param lba Collateral Agreement to which deals must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param extraParams Pointer to structure containing extra reporting parameters.
			 * @version 5.3.2
			 */
			virtual void ComputeAll(long cpty, long entity, long convention, long calculationDate, SReportingParameters *extraParams = 0);

			/**
			 * Builds a result for a given per contract stock loan position.
			 * Please note that for Pool deals, such as, for example, Sec vs Cash Pool
			 * or Sec vs Sec Pool, or Cash vs Sec Pool, only information about
			 * the principal part is returned.
			 * For Contract Per Contract deals, all information, including all collateral,
			 * is returned.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param calculationDate Reporting date (can be zero which means use the system date).
			 * @param mvtident Position Id (mvtident).
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeOne(const CSRLBAgreement *lba, long calculationDate, sophis::portfolio::PositionIdent mvtident, long crfFlags);

			/**
			 * {@link ISRCollateralReportingAPI::GetResult}.
			 * Calls GetStockLoanResult().
			 */
			virtual const CSRCollateralResult* GetResult() const;

			/**
			 * Builds a dummy (blank) result tree that can be used to generate an XSD description.
			 * @param lba Collateral Agreement to which deal must belong (map) to.
			 * @param crfFlags Flags indicating desired output.
			 */
			virtual void ComputeDummy(const CSRLBAgreement *lba, long crfFlags = eCRFCommonGui);

			/**
			 * Returns the result pointer which must not be deleted.
			 */
			const CSRStockLoanResult* GetStockLoanResult() const;

			/**
			 * Returns calculation date as used for the result computation.
			 */
			long GetCalculationDate() const
			{
				return fCalculationDate;
			}

			/**
			 * Returns model name used to build collateral reporting results.
			 */
			const _STL::string& GetModelName() const
			{
				return fResultName;
			}

			/**
			 * Returns CSRStockLoanContract object with details of the contract based on the result object
			 * or NULL if the object does not map to the individual Stock Loan or Repo contract.
			 * The method can be used in conjunction with ComputeOne() or when browsing individual results.
			 * @version 5.3.6
			 */
			CSRStockLoanContract* new_CSRStockLoanContract() const;

		protected:
			void Initialize(const char *resultName = 0);

			_STL::string fResultName;
			CSRStockLoanResult *fResult;
			long fCalculationDate;

		private:
			static const char *__CLASS__;
		};

	} // namespace collateral
} // namespace sophis
SPH_EPILOG
#endif // _SphStockLoanReportingAPI_H_
