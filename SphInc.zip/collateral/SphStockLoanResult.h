#ifndef _SphStockLoanResult_H_
#define _SphStockLoanResult_H_

#include "SphInc/Collateral/SphCollateralResult.h"
#include "SphInc/Collateral/SphCollateralEnums.h"
#include "SphInc/Collateral/SphLbaType.h"
#include "SphInc/Collateral/SphCreditRiskCalcModel.h"
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis {

	namespace instrument {
		class CSRLoanAndRepo;
	}
	namespace portfolio	{
		class CSRExtraPosition;
	}
	namespace collateral {

		class CSRLBAgreement;
		class CSRStockLoanReportingAPI;
		class CSRCashInterestExplanationList;
		class CSRCommissionExplanationList;
		union FredReportingData;
		class CSRStockLoanContract;

/**
 * Macro to be used instead of the Clone() method in the clients derived classes.
 * Prototype framework will be responsible to instantiate clients objects.
 * @param derivedClass is the name of the client derived class.
 */
#define DECLARATION_STOCK_LOAN_RESULT(derivedClass) \
	public: virtual CSRStockLoanResult* CloneSL() const { return new derivedClass(*this); }

/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes
 * with the prototype framework.
 * 
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * Clients have to use this name in CSRCollateralReportingResult::GetPrototype().GetInstance(name) 
 * method to instantiate the clients class objects.
 */
#define	INITIALISE_COLLATERAL_REPORTING_RESULT(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass,  name)

/**
 * Represents detailed information of stock loan position obtained via collateral reporting.
 * @version 5.3.
 */

#define LBA_MODEL_LENDING_BORROWING "Lending Borrowing Model"

class SOPHIS_COLLATERAL CSRStockLoanResult : public virtual CSRCollateralResult, public virtual CSRCreditRiskCalcModel
{
public:
	/**
	 * Get a particular collateral management result singleton.
	 * @param name The name of the collateral management result sought.
	 * @return A pointer which must not be deleted.
	 */
	static CSRStockLoanResult* GetInstance(const char *name);

	/**
	 * Returns new instance of collateral cash or repo cash interest explanation list.
	 * @param repoCash True to specify repo cash interest explanation is sought; False (default)
	 * to specify cash collateral interest explanation.
	 *
	 * @return New object to be filled or null if no cash interest explanation is required.
	 */
	virtual CSRCashInterestExplanationList* new_CSRCashInterestExplanationList(bool repoCash=false) const;

	/**
	 * Returns new instance of commission explanation list.
	 *
	 * @return New object to be filled or null if no commission explanation is required.
	 */
	virtual CSRCommissionExplanationList* new_CSRCommissionExplanationList() const;

	/**
	 * Constructor.
	 * You can initialise the agreement and line type later by calling Initialise().
	 * Model name set to LBA_MODEL_LENDING_BORROWING.
	 */
	CSRStockLoanResult();

	/**
	* Constructor.
	* You can initialise the agreement and line type later by calling Initialise().
	* @param modelName Model name.
	* @param lba Collateral Agreement this result line references to.
	* @param lineType Line type.
	*/
	CSRStockLoanResult(_STL::string modelName, const CSRLBAgreement *lba = 0, int lineType = CSRLbaType::eUndefined);

	/**
	 * Copy constructor.
	 * Performs a deep copy of all the data, including the children.
	 * Note that the parent is not copied.
	 */
	CSRStockLoanResult(const CSRStockLoanResult& src);

	/**
	 * Deletes all resources linked to the result and all child results if present.
	 */
	virtual ~CSRStockLoanResult();

	DECLARATION_STOCK_LOAN_RESULT(CSRStockLoanResult)

	virtual CSRCreditRiskCalcModel* Clone() const OVERRIDE { return CloneSL(); }
	virtual CSRCollateralResult* CloneCollat() const OVERRIDE { return CloneSL(); }

	/**
	 * Initialises some of the results values required for correct computations.
	 * Must be called BEFORE any calls to Compute().
	 */
	virtual void Initialise(const CSRLBAgreement* lba, int lineType = CSRLbaType::eUndefined);

	/**
	* Returns the master (top of the tree).
	*/
	const CSRStockLoanResult& GetStockLoanMaster() const;

	/**
	 * In case of hierarchical result, searches through the hierarchy in an attempt to locate
	 * result of given type.
	 * @return Result matching the line type or null.
	 */
	const CSRStockLoanResult* FindStockLoanChildByType(eStockLoanReportingResultType lineType) const;

	/**
	 * In case of hierarchical result, searches through the hierarchy in an attempt to locate
	 * contract result that describes stock loan with given position id (mvtident).
	 * @return Result that belongs to the contract with matching position id (mvtident) or null if it is not found.
	 */
	const CSRStockLoanResult* FindChildByPositionId(sophis::portfolio::PositionIdent mvtident) const;

	/**
	 *	Copies the name of hierarchy into the name parameter. Name parameter must point to preallocated area of memory.
	 */
	virtual void GetLineTypeName(char *name) const;

	/**
	 * Returns stock loan type of the children.
	 * Similar to GetChildrenLineType() but specific to stock loan tree.
	 */
	CSRLbaType::eLbaType GetStockLoanChildrenType() const;

	/**
	 * Populates the given vector with its direct children.
	 */
	void GetStockLoanChildren(_STL::vector<const CSRStockLoanResult*>& children) const;

	/**
	 * Populates the given vector with flat list.
	 */
	void GetStockLoanFlatListView(_STL::vector<const CSRStockLoanResult*>& flatList) const;

	/**
	 * @see {@link CSRCollateralResult::IsLower}
	 */
	virtual bool IsLower(const CSRCollateralResult& result1, const CSRCollateralResult& result2) const;

	/**
	 * @see {@link CSRCollateralResult::GetInstrumentInformationCode}
	 */
	virtual long GetInstrumentInformationCode() const;

public:
	//
	// Correspond to Columns
	//

	/**
	 * Returns position id (mvtident) to which this stock loan result belongs to.
	 */
	sophis::portfolio::PositionIdent GetPositionId() const;

	/**
	 * Returns transaction id (refcon) of the inital trade.
	 */
	sophis::portfolio::TransactionIdent GetInitialTradeId() const;

	/**
	 * Returns portfolio id (opcvm) for the margin calls.
	 */
	long GetPortfolioCode() const;

	/**
	 * Returns Start Date of the stock loan where applicable.
	 */
	long GetStartDate() const;

	/**
	 * Returns Last Margin Date of the stock loan where applicable.
	 * Last Margin Date is when the last adjustments (like Margin Call) were made
	 * on the stock loan.
	 */
	long GetLastMarginDate() const;

	/**
	 * Returns Maturity Date (Expiry) of the stock loan where applicable.
	 */
	long GetMaturityDate() const;

	/**
	 * Returns Instrument Id (sicovam) of the principal part of the stock loan.
	 */
	long GetPrincipalCode() const;

	/**
	 * Returns Quantity (or Amount) of the principal part of the stock loan.
	 */
	double GetPrincipalQuantity() const;

	/**
	 * Returns Last Adjusted Spot of the Principal.
	 * Depending on the type of the contract, the Spot can be adjusted manually (via Spot Modification, 
	 * Cash Margin Call, etc.) or automatically (via Fee Mark, Open Basis, etc.).
	 */
	double GetLastFeeMark() const;

	/**
	 * Returns Next Interest Payment Date for cash collateral.
	 */
	long GetNextInterestDate() const;
	
	/**
	 * Returns Next Billing Date for commission.
	 */
	long GetNextBillingDate() const;

	/**
	 * Returns Billing Currency used for commission billing.
	 */
	long GetBillingCurrency() const;

	/**
	 * Returns current commission amount on principal (based on calculation date).
	 * @return Amount in billing currency.
	 */
	double GetEstimatedBilling() const;

	/**
	 * Returns forex between billing currency and reference currency.
	 */
	double GetBillingCurrencyForex() const;

	/**
	 * Returns reference currency in which all risk is calculated.
	 */
	long GetReferenceCurrency() const;

	/**
	 * Returns risk value in reference currency.
	 */
	double GetRiskValueInReferenceCurrency() const;

	/**
	* Returns principal value in reference currency.
	*/
	double GetPrincipalValueInReferenceCurrency() const;

	/**
	 * Returns collateral value in reference currency.
	 */
	double GetCollateralValueInReferenceCurrency() const;

	/**
	* Returns Hedging Ratio applied to the principal.
	* This value is used for calculations.
	* @return hedging value used for calculations.
	*/
	double GetPrincipalHedging() const;

	/**
	* Returns Hedging Ratio applied to the principal, as specified by the user
	* in the Stock Loan Instrument or Collateral Agreement configuration.
	* This value is used for display/information purposes and not for calculations.
	* @return hedging value for display purposes.
	*/
	double GetPrincipalHedgingInProduct() const;

	/**
	 * Returns Fx Rate between principal currency and reference currency.
	 */
	double GetPrincipalForex() const;

	/**
	 * Returns Principal Spot used to calculate principal value.
	 */
	double GetPrincipalSpot() const;

	/**
	 * Returns Accrued value calculated for the principal.
	 */
	double GetPrincipalAccrued() const;

	//
	// Securities Collateral Data
	//

	/**
	* Returns Securities Collateral Haircut Ratio, as specified by the user
	* in the Stock Loan Instrument or Collateral Agreement configuration.
	* This value is used for display/information purposes and not for calculations.
	* @return haircut value for display purposes.
	*/
	double GetSecuritiesCollateralHaircutInProduct() const;

	/**
	* Returns Securities Collateral Haircut Ratio.
	* This value is used for calculations.
	* @return haircut value used for calculations.
	*/
	double GetSecuritiesCollateralHaircut() const;

	/**
	* Returns Fx Rate between securities collateral currency and reference currency.
	*/
	double GetSecuritiesCollateralForex() const;

	/**
	* Returns Securities Collateral Spot used to calculate securities collateral value.
	*/
	double GetSecuritiesCollateralSpot() const;

	/**
	* Returns Quantity of the securities collateral part of the stock loan.
	*/
	double GetSecuritiesCollateralQuantity() const;

	/**
	* Returns Instrument Id (sicovam) of the securities collateral part of the stock loan.
	*/
	long GetSecuritiesCollateralCode() const;

	/**
	 * Returns Accrued value calculated for the securities collateral.
	 */
	double GetSecuritiesCollateralAccrued() const;

	//
	// Cash Collateral Data
	//

	/**
	* Returns Currency Id (sicovam) of the cash collateral part of the stock loan.
	* The method returns a value if and only if there is only one
	* cash collateral present.
	*/
	long GetCashCollateralCurrency() const;


	/**
	* Returns Interest Rate Id of the cash collateral part of the stock loan.
	* The method returns a value if and only if there is only one
	* cash collateral present.
	*/
	long GetCashCollateralInterestRate() const;

	/**
	* Returns Amount of the cash collateral part of the stock loan.
	* The Amount is the sum of initial cash collateral amount (also known as initial deposit)
	* and cash margin call collateral amount.
	* @return Amount in cash collateral currency.
	*
	* The method returns a value if and only if there is only one
	* cash collateral present.
	*/
	double GetTotalCashCollateralAmount() const;

	/**
	* Returns Amount of the initial deposit (cash amount in the initial ticket)
	* for Security versus Cash Per Contract deals.
	* @return Amount in cash collateral currency.
	*/
	double GetInitialDepositAmount() const;

	/**
	* Returns Amount of the cash collateral excluding the initial cash collateral amount.
	* For Contract Per Contract deals, it returns the sum of all cash margin calls.
	* For Cash Pool, it returns the cash pool amount.
	* @return Amount in cash collateral currency.
	*/
	double GetMarginCashCollateralAmount() const;

	/**
	* Returns current amount of interest on cash collateral (based on calculation date).
	* The method returns a value if and only if there is only one
	* cash collateral present.
	* @return Amount in cash collateral currency.
	*/
	double GetCashCollateralInterest() const;
	
	/**
	* Returns Fx Rate between cash collateral currency and reference currency.
	* The method returns a value if and only if there is only one
	* cash collateral present.
	*/
	double GetCashCollateralForex() const;

	/**
	* Returns Cash Collateral Haircut Ratio.
	* This value is used for calculations.
	* The method may not return a value for Security versus Cash Per Contract deals
	* where only initial deposit is present, without cash margin calls.
	* The method returns a value if and only if there is only one
	* cash collateral present.
	* @return haircut value used for calculations.
	*/
	double GetMarginCashCollateralHaircut() const;

	/**
	* Returns Cash Collateral Haircut Ratio, as specified by the user
	* in the Stock Loan Instrument or Collateral Agreement configuration.
	* This value is used for display/information purposes and not for calculations.
	* The method may not return a value for Security versus Cash Per Contract deals
	* where only initial deposit is present, without cash margin calls.
	* The method returns a value if and only if there is only one
	* cash collateral present.
	* @return haircut value for display purposes.
	*/
	double GetMarginCashCollateralHaircutInProduct() const;

	/**
	* Returns Haircut Ratio of Initial Deposit.
	* This value is used for calculations.
	* The method returns a value only for Security versus Cash Per Contract deals
	* where the notion of initial deposit (cash amount in the initial ticket) is present.
	* The reason being the haircuts for initial deposit and subsequent cash
	* margin calls can differ.
	* @return haircut value used for calculations.
	*/
	double GetInitialDepositHaircut() const;

	/**
	* Returns Haircut Ratio of Initial Deposit, as specified by the user
	* in the Stock Loan Instrument or Collateral Agreement configuration.
	* This value is used for display/information purposes and not for calculations.
	* The method returns a value only for Security versus Cash Per Contract deals
	* where the notion of initial deposit (cash amount in the initial ticket) is present.
	* The reason being the haircuts for initial deposit and subsequent cash
	* margin calls can differ.
	* @return haircut value for display purposes.
	*/
	double GetInitialDepositHaircutInProduct() const;

	/**
	*Returns yesterday's commission
	*@version 532
	*/
	double GetYesterdayCommission() const;
	
	/**
	*Returns commission paid today
	*@version 532
	*/
	double GetCommissionPaidToday() const;

	double GetTotalCommissionPaid() const;

#if 0
	/**
	 * Returns instrument id defining the position.
	 * Where position is represented by more than one instrument,
	 * the instrument defining the main (principal) part is returned.
	 */
	long GetLoanAndRepoCode() const;
#endif

	/**
	 * Returns the instrument defining the position.
	 * Where position is represented by more than one instrument,
	 * the instrument defininf the main (principal) part is returned.
	 */
	const instrument::CSRLoanAndRepo* GetLoanAndRepo() const;

	/**
	 * Returns first collateral cash interest explanation list or null if there is either no cash explanation lists
	 * or more than one list is available.
	 *
	 * Under normal circumstances, there should be maximum of one cash collateral present.
	 * The pointer must not be deleted.
	 */
	const CSRCashInterestExplanationList* GetCollateralCashInterestExplanationList() const;

	/**
	 * Returns principal (repo) cash interest explanation list or null if no cash explanation is available.
	 * The pointer must not be deleted.
	 */
	const CSRCashInterestExplanationList* GetRepoCashInterestExplanationList() const;

	/**
	 * Returns commission explanation list or null if no commission explanation is available.
	 * The pointer must not be deleted.
	 */
	const CSRCommissionExplanationList* GetCommissionExplanationList() const;

	/**
	* Returns current amount of interest on cash collateral (based on calculation date - 1).
	* The method returns a value if and only if there is only one
	* cash collateral present.
	* @return Amount in cash collateral currency.
	*/
	double GetCashCollateralYesterdayInterest() const;

	/**
	* Returns interest paid today (based on calculation date).
	* The method returns a value if and only if there is only one
	* cash collateral present.
	* @return Amount in cash collateral currency.
	*/
	double GetCashCollateralInterestPaidToday() const;

	/**
	 * Returns the Nominal of the Principal                                                                       
	 */
	double GetPrincipalNominal() const;

	/**
	 *	Returns the Nominal of the Collateral                                                                       
	 */
	double GetSecuritiesCollateralNominal() const;

	/**
	 * Returns maturity of the securities collateral (if applicable).
	 */
	long GetSecuritiesCollateralMaturityDate() const;

	/**
	 * Returns the exposure produced by all results.
	 * @since 5.3.5
	 */
	double GetExposure() const;

	/**
	 * Returns the threshold specific to exposure of the given agreement.
	 * @since 5.3.5
	 */
	double GetThreshold() const;

	/**
	 * Returns the extra position. Can be NULL.
	 * @since 5.3.6
	 */
	const sophis::portfolio::CSRExtraPosition * GetExtraPosition() const;

	/**
	* Sets the extra position.
	* @since 5.3.6
	*/
	void ResetExtraPosition(const sophis::portfolio::CSRExtraPosition * extraPos = NULL);

	/**
	* Returns the list storing the virtual Mvts included in the Cash Pool
	* @since 5.3.6
	*/
	const _STL::set<long>& GetVirtualCashPoolMvts() const { return fVirtualCashPoolMvts;}

	/**
	* Inserts in the list new virtual Mvts
	* @since 5.3.6
	*/
	void InsertVirtualCashPoolMvts(const _STL::set<long>& ids) {fVirtualCashPoolMvts.insert(ids.begin(), ids.end());}

	/**
	* Returns the list of Mvts per InstrumentId for Exchange Repo deals
	* @since 7.1
	*/
	const _STL::set<long>& GetInstrumentMvts() const { return fInstrumentMvts;}

	/**
	* Inserts in the list Mvts of Exchange Repo deals
	* @since 7.1
	*/
	void InsertInstrumentMvts(const _STL::set<long>& ids) {fInstrumentMvts.insert(ids.begin(), ids.end());}

	/**
	* Returns the Payment Date of the contract
	* @since 7.1
	*/
	long GetContractPaymentDate() const {return fContractPaymentDate;}

	/**
	* Returns the Principal Price of the contract
	* @since 7.1
	*/
	double GetPrincipalPrice() const {return fPrincipalPrice;}

	/**
	* Returns the Pre-Paid Quantity
	* @since 7.1
	*/
	double GetPrePaidQuantity() const {return fPrePaidQuantity;}

	/**
	* Returns the Post-Paid Amount
	* @since 7.1
	*/
	double GetPostPaidAmount() const {return fPostPaidAmount;}

protected:

	/** FOR INTERNAL USE ONLY.
	 * Computes custom values for the result based on given reporting data.
	 * @param reportingData Low-level reporting data.
	 * @param lba Collateral Management Agreement.
	 * @param calcualtionDate Reporting date.
	 * @param ccy Reference currency, if not specified, reference currency of the collateral agreement is used.
	 */
	void Compute(const FredReportingData &reportingData, 
		const CSRLBAgreement *lba, long calculationDate, long ccy = 0);

	/** FOR INTERNAL USE ONLY.
	 * Computes cash interest and commission explanations for the result based on given reporting data.
	 * @param reportingData Low-level reporting data.
	 * @param lba Collateral Management Agreement.
	 * @param calcualtionDate Reporting date.
	 */
	void ComputeExplanations(const FredReportingData &reportingData, 
		const CSRLBAgreement *lba, long calculationDate);

	/**
	 * Adds risk (and other) values of the given child to the node.
	 * @param child Report which values should be integrated.
	 */
	virtual void AddChildValues(const CSRCollateralResult *child);

	/**
	 * returns the Notional if the given instrument is a bond, 0 otherwise
	 */	 
	double GetNotional(long instrumentID) const;

	void Initialize(_STL::string modelName = LBA_MODEL_LENDING_BORROWING, const CSRLBAgreement *lba=0, int lineType = CSRLbaType::eUndefined);
	void Initialize(const CSRStockLoanResult& src);
	/**
	 * Returns CSRStockLoanContract object with details of the contract or NULL if the object
	 * does not map to the Stock Loan or Repo contract.
	 * @param calculationDate Date for which the report has been computed (required to pass to CSRStockLoanContract).
	 * @return New object for which the caller takes ownership, or NULL.
	 * @version 5.3.6
	 */
	virtual CSRStockLoanContract* new_CSRStockLoanContract(long calculationDate) const;

protected:
	long fCurrency;

	CSRCashInterestExplanationList *fCollateralCashInterestExplanationList;
	CSRCashInterestExplanationList *fRepoCashInterestExplanationList;
	CSRCommissionExplanationList *fCommissionExplanationList;

	double	fPrincipal;
	double	fCollateral;

	double	fPrincipalHedging;
	double	fPrincipalHedgingInProduct;
	double	fPrincipalFx;
	double	fPrincipalSpot;
	double	fPrincipalAccrued;
	double	fSecuritiesCollateralHaircut;
	double	fSecuritiesCollateralHaircutInProduct;
	double	fSecuritiesCollateralFx;
	double	fSecuritiesCollateralSpot;
	double	fSecuritiesCollateralAccrued;

	double	fCashCollateralMarginCallAmount;
	double  fCashCollateralMarginCallHaircut;
	double  fCashCollateralMarginCallHaircutInProduct;

	double	fCashCollateralInitialDepositAmount;
	double  fCashCollateralInitialDepositHaircut;
	double  fCashCollateralInitialDepositHaircutInProduct;

	long	fLastMarginDate;
	double	fCashCollateralFx;
	long	fCashCollateralCurrency;
	long	fCashCollateralInterestRate;
	double	fCashCollateralInterest;
	long	fStartDate;
	long	fMaturityDate;
	long	fPrincipalCode;
	double	fPrincipalQuantity;
	long	fLoanAndRepoCode;
	long	fSecuritiesCollateralCode;
	double	fSecuritiesCollateralQuantity;
	double	fLastFeeMark;
	long	fNextBillingDate;
	double	fEstimatedBilling;
	long	fBillingCurrency;
	long	fNextInterestDate;
	sophis::portfolio::PositionIdent fPositionId;
	long	fPortfolioCode;
	sophis::portfolio::TransactionIdent	fInitialDealRefcon;
	double	fYesterdayInterest;
	double	fInterestPaidToday;
	long	fSecuritiesCollateralMaturityDate;
	double	fBillingCurrencyForex;
	double	fYesterdayCommission;
	double	fCommissionPaidToday;
	double  fExposure;
	double	fThreshold;
	const sophis::portfolio::CSRExtraPosition * fExtraPosition;

	_STL::set<long> fVirtualCashPoolMvts;
	double	fTotalCommissionPaid;
	_STL::set<long> fInstrumentMvts;

	long fContractPaymentDate;
	double fPrincipalPrice;
	double fPrePaidQuantity;
	double fPostPaidAmount;

private:

	static const char *__CLASS__;

	friend class CSRStockLoanReportingAPI;
	friend class CSRCFDReportingAPI;
};

	} // namespace collateral
} // namespace sophis


SPH_EPILOG
#endif // _SphStockLoanResult_H_
