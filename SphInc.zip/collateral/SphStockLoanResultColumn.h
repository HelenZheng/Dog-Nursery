#ifndef _SphStockLoanResultColumn_H_
#define _SphStockLoanResultColumn_H_

#include "SphInc/collateral/SphCollateralResultColumn.h"

#define DECLARATION_STOCK_LOAN_RESULT_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::collateral::CSRCollateralResultColumn)
#define CONSTRUCTOR_STOCK_LOAN_RESULT_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_STOCK_LOAN_RESULT_COLUMN(derivedClass)
#define	INITIALISE_STOCK_LOAN_RESULT_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis {
	namespace collateral {

		class CSRStockLoanResult;
		class CSRStockLoanReportingAPI;

/**
 * Interface to handle columns in Stock Loan Management GUI.
 * To add a column, derive this class, using the macro DECLARATION_STOCK_LOAN_RESULT_COLUMN in your header
 * and INITIALISE_STOCK_LOAN_RESULT_COLUMN in UNIVERSAL_MAIN.
 *
 * @version 5.3
 */
class SOPHIS_COLLATERAL CSRStockLoanResultColumn : public virtual CSRCollateralResultColumn
{
public:
	CSRStockLoanResultColumn();

	/**
	 * {@link CSRCollateralResultColumn::GetCell}
	 * Invokes DoGetCell().
	 */
	virtual	void GetCell(const CSRCollateralReportContext &ctx, const CSRCollateralResult &result, SSCellValue *value, SSCellStyle *style) const;

	/** 
	 * Main method to display the content.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param result Collateral Management Reporting result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	*/
	virtual	void GetStockLoanCell(const CSRCollateralReportContext &ctx, const CSRStockLoanResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Access to the prototype singleton
	 * To add a trigger to this singleton, use INITIALISE_STOCK_LOAN_RESULT_COLUMN
	 * @see tools::CSRPrototype
	 */
	static prototype & GetPrototype();

};

/** 
 * Utility class to allow interaction between GUI dialog of Stock Loan and Repo management report and the individual columns.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL ISRStockLoanResultExtra
{
public:
	/** Trivial constructor. */
	ISRStockLoanResultExtra() {}
	/** Trivial destructor. */
	virtual ~ISRStockLoanResultExtra() {}

	/** Returns the API object. */
	virtual const CSRStockLoanReportingAPI* GetStockLoanReportingAPI() const = 0;
	/** Returns reference currency. */
	virtual long GetReferenceCurrency() const = 0;
	/** Returns global risk in reference currency. */
	virtual double GetGlobalRisk() const = 0;
	/** Returns pool risk in reference currency. */
	virtual double GetPoolRisk() const = 0;
	/** Returns threshold value. */
	virtual double GetThreshold() const = 0;
	/** Returns exposure in reference currency. */
	virtual double GetExposure() const = 0;
	/** Report generation date. */
	virtual long GetGenerationDate() const = 0;
	/** Report generation time. */
	virtual long GetGenerationTime() const = 0;
	/** Reporting date of the report. */
	virtual long GetReportDate() const = 0;
	/** Report date type. */
	virtual long GetReportDateType() const = 0;
};

/**
 * Special column that requires information from the GUI dialog of Stock Loan and Repo management report.
 * The dialog (extra) information is only available in the GUI mode.
 * @version 5.3.6
 */
class SOPHIS_COLLATERAL CSRStockLoanResultColumnExtra : public CSRStockLoanResultColumn
{
public:
	/** 
	 * Main method to display the content. Called when no extra information is available.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param result Collateral Management Reporting result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @see {@link CSRStockLoanResultColumn::GetStockLoanCell}
	*/
	virtual	void GetStockLoanCell(const CSRCollateralReportContext &ctx, const CSRStockLoanResult &result, SSCellValue *value, SSCellStyle *style) const = 0;

	/** 
	 * Main method to display the content. Called when extra information (such as GUI dialog) is available.
	 * Must be implemented in derived classes.
	 * @param ctx Report context from where GetCell() is being called.
	 * @param result Collateral Management Reporting result to be displayed.
	 * @param value An output parameter, used to return the value to be displayed.
	 * @param style An output parameter, used to describe the style and the data type.
	 * @param extra Extra information about the report.
	 * @version 5.3.6
	*/
	virtual	void GetStockLoanCellExtra(const CSRCollateralReportContext &ctx, const CSRStockLoanResult &result, SSCellValue *value, SSCellStyle *style,
		const ISRStockLoanResultExtra& extra) const = 0;
};

	} // namespace collateral
} // namespace sophis


SPH_EPILOG
#endif
