/*
 	File:		SphTransactionDoubleBooking.h

 	Contains:	Class to handle transactions that are split in two deals.
 	Copyright:	2011 Sophis.

*/

/*! \file SphTransactionDoubleBooking.h
	\brief Class to handle transactions that are split in two deals.
*/

#pragma once

#ifndef _Sph_Transaction_Double_Booking_H_
#define _Sph_Transaction_Double_Booking_H_

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphTransaction.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

SPH_PROLOG
namespace sophis
{
	namespace collateral
	{
		
		class SOPHIS_COLLATERAL CSRTransactionDoubleBooking : public sophis::portfolio::CSRTransaction
		{
		protected:
			const sophis::portfolio::CSRTransaction* fTr2;

		public:
			CSRTransactionDoubleBooking();
			CSRTransactionDoubleBooking(sophis::portfolio::TransactionIdent refcon);
			CSRTransactionDoubleBooking(sophis::portfolio::CSRTransaction& tr);

			const sophis::portfolio::CSRTransaction* Get2ndTransaction() const;
			void Set2ndTransaction(const sophis::portfolio::CSRTransaction* tr);
		};
	}
}

SPH_EPILOG
#endif //_Sph_Transaction_Double_Booking_H_