#ifndef __SPHCSRBUFFERCODE_H__
#define __SPHCSRBUFFERCODE_H__

#include "SphInc/SphMacros.h"

#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)

/**
 * The classes below are used in Commodity to store the existing future sicovams attached to a LME commodity
 * We also store in there the interpolated values attached to a LME commodity
 */
SPH_PROLOG
namespace sophis {
	namespace commodity {

		/* 
		 * ==== ==== ============================== ==== ====
		 * ==== ==== ==== CSRBufferCodeElement ==== ==== ====
		 * ==== ==== ============================== ==== ====
		 *
		 * This Template class stores pairs (d,T), where d is a date key (using long) and T a value type
		 *
		 * This class uses both an STL vector and a map and is efficient to:
		 *    - store T values with dates before and after today (where today is CSRDay::GetSystemDate())
		 *      see Add(...)
		 *    - get the values by exact date (default value of T is not found)
		 *      see Get(...)
		 *    - for a given date, finds the closest dates before and after it
		 *      see GetBoundaries(...)
		 *    - for a given date, finds the first date that is before it or equal to it
		 *      see GetLowerDate(...)
		 *
		 */

		template <class T>
		class CSRBufferCodeElement
		{
		public:
			
			/* CSRBufferCodeElement()
			 * 
			 * Constructor
			 *
			 */
			
			CSRBufferCodeElement();
			
			/*  void Reset(const T& defaultValue);
			 *
			 *  Allocates some space (10x365 days before and 10x365 days after today)
			 *  and fills it with the default value
			 */

			void Reset(const T& defaultValue);

			/*  void Add(long date, const T& value, const T& defaultValue);
			 *
			 *  Adds a value for the given date
			 *  If the date has already been added, the value if overwritten.
			 *  If it is necessary to extend the existing buffers, they are with using the default value
			 */
			
			void Add(long date, const T& value, const T& defaultValue);
			
			/*  T Get(long date, const T& defaultValue) const;
			 *
			 *  Find the value for the given date (must be exactly equal)
			 *  If not found, returns the default value
			 */
			
			const T & Get(long date, const T& defaultValue) const;

			/*  void GetBoundaries(long date, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const;
			 *
			 *  Find the dates keyLeft and keyRight and their values T1 and T2
			 *  such that keyLeft <= date < keyRight
			 *
			 *  If keyLeft is equal to dateTest, then T2 is set to the default value
			 *  If no such keyLeft (resp. keyRight) exists, their value is set to 0, and T1 (resp. T2) to the default value
			 *
			 */
			
			void GetBoundaries(long date, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const;

			/*  long GetLowerDate(long date) const;
			 *
			 *  For a given date, finds the closest date that is before it or equal to it
			 *  This method uses the lower_bound() method of the STL map
			 *  
			 */

			long GetLowerDate(long date) const;

			/*  void Equalize(const CSRBufferCodeElement<T>& classToEqualize)
			 *
			 *  This methods set the value (this) to the same value as the input parameter
			 */
			
			void Equalize(const CSRBufferCodeElement<T>& classToEqualize)
			{
				fVector			=classToEqualize.fVector;
				fVectorPast		=classToEqualize.fVectorPast;
				fInvertVector	=classToEqualize.fInvertVector;
				fToday			=classToEqualize.fToday;
			};

			/*  int GetElementCount() const
			 *
			 *  returns the number of date+value pairs that are currently stored
			 *
			 *  this number does not include space filled with default values, it includes dates set using Add()
			 */
			
			int	GetElementCount() const
			{
				return SIZE_T_TO_LONG(fInvertVector.size());
			};

			const _STL::map<const long,T>* GetInvertMap() const
			{
				return &fInvertVector;
			};

		public:
			_STL::vector<T>			fVector;
			_STL::vector<T>			fVectorPast;
			_STL::map<const long,T>	fInvertVector;
			long					fToday;
		};


		/*
		 * ==== ==== ============================== ==== ====
		 * ==== ==== ====    CSRBufferCode     ==== ==== ====
		 * ==== ==== ============================== ==== ====
		 *
		 * This Template class use CSRBufferCodeElement to store value of type T with two distinct date keys.
		 * The two distinct keys are Maturity date and Delivery date.
		 *
		 * See CSRBufferCodeElement for details on each method
		 *
		 */
		
		
		template <class T>
		class CSRBufferCode
		{
			public:
				CSRBufferCode();
				void Reset(const T& defaultValue);

				void Add(long expiryDate, long deliveryDate, long paymentDate, const T& value, const T& defaultValue);
				T	 GetByMaturity(long expiryDate, const T& defaultValue) const;
				T	 GetByDelivery(long deliveryDate, const T& defaultValue) const;
				T	 GetByPayment(long paymentDate, const T& defaultValue) const;
				
				void GetBoundariesByMaturity(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const;
				void GetBoundariesByDelivery(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const;
				void GetBoundariesByPayment(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const;
				
				void Equalize(const CSRBufferCode<T>& classToEqualize);
				
				int	GetElementCount() const;
				
				const _STL::map<const long,T>* GetInvertMapByMaturity() const;
				const _STL::map<const long,T>* GetInvertMapByDelivery() const;
				const _STL::map<const long,T>* GetInvertMapByPayment() const;

			public:
				CSRBufferCodeElement<T> fElementByMaturity;
				CSRBufferCodeElement<T> fElementByDelivery;
				CSRBufferCodeElement<T> fElementByPayment;
		};
	
	};
};
SPH_EPILOG
#endif
