#ifndef __SPHCSRBUFFERCODE_IMPL_H__
#define __SPHCSRBUFFERCODE_IMPL_H__

#include "SphInc/commodity/SphBufferCode.h"
#include "SphTools/SphDay.h"

SPH_PROLOG
namespace sophis {
	namespace commodity {

		template <class T>
		const _STL::map<const long,T>* CSRBufferCode<T>::GetInvertMapByMaturity() const
		{
			return fElementByMaturity.GetInvertMap();
		}

		template <class T>
		const _STL::map<const long,T>* CSRBufferCode<T>::GetInvertMapByDelivery() const
		{
			return fElementByDelivery.GetInvertMap();
		}

		template <class T>
			const _STL::map<const long,T>* CSRBufferCode<T>::GetInvertMapByPayment() const
		{
			return fElementByPayment.GetInvertMap();
		}

		template <class T>
		void CSRBufferCode<T>::Reset(const T& defaultValue)
		{
			fElementByMaturity.Reset(defaultValue);
			fElementByDelivery.Reset(defaultValue);
			fElementByPayment.Reset(defaultValue);
		}
		
		template <class T>
		CSRBufferCode<T>::CSRBufferCode()
		{
		};

		template <class T>
		void CSRBufferCode<T>::Add(long expiryDate, long deliveryDate, long paymentDate, const T& value, const T& defaultValue)
		{
			fElementByMaturity.Add(expiryDate,value,defaultValue);
			fElementByDelivery.Add(deliveryDate,value,defaultValue);
			fElementByPayment.Add(paymentDate,value,defaultValue);
		}

		template <class T>
		T	 CSRBufferCode<T>::GetByMaturity(long expiryDate, const T& defaultValue) const
		{
			return fElementByMaturity.Get(expiryDate, defaultValue);
		}

		template <class T>
		T	 CSRBufferCode<T>::GetByDelivery(long deliveryDate, const T& defaultValue) const
		{
			return fElementByDelivery.Get(deliveryDate, defaultValue);
		}

		template <class T>
			T	 CSRBufferCode<T>::GetByPayment(long paymentDate, const T& defaultValue) const
		{
			return fElementByPayment.Get(paymentDate, defaultValue);
		}

		template <class T>
		void CSRBufferCode<T>::GetBoundariesByMaturity(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const
		{
			fElementByMaturity.GetBoundaries(dateTest, t1, t2, keyLeft, keyRight, defaultValues);
		}

		template <class T>
		void CSRBufferCode<T>::GetBoundariesByDelivery(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const
		{
			fElementByDelivery.GetBoundaries(dateTest, t1, t2, keyLeft, keyRight, defaultValues);
		}

		template <class T>
			void CSRBufferCode<T>::GetBoundariesByPayment(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValues) const
		{
			fElementByPayment.GetBoundaries(dateTest, t1, t2, keyLeft, keyRight, defaultValues);
		}

		template <class T>
		void CSRBufferCode<T>::Equalize(const CSRBufferCode<T>& classToEqualize)
		{
			fElementByMaturity.Equalize(classToEqualize.fElementByMaturity);
			fElementByDelivery.Equalize(classToEqualize.fElementByDelivery);
			fElementByPayment.Equalize(classToEqualize.fElementByPayment);
		}

		template <class T>
		int	CSRBufferCode<T>::GetElementCount() const
		{
			return fElementByMaturity.GetElementCount();
		}
		// ----------------------------------------------------------------------------------------
		// class CSRBufferCodeElement
		// ----------------------------------------------------------------------------------------
		template <class T>
		CSRBufferCodeElement<T>::CSRBufferCodeElement()
		{
			fToday = sophisTools::CSRDay::GetSystemDate();
		}

		template <class T>
		const T & CSRBufferCodeElement<T>::Get(long expiryDate, const T& defaultValue) const
		{
			if (!fVector.size())
				((CSRBufferCodeElement<T>*)this)->Reset(defaultValue);

			if ((expiryDate -= fToday)<0)
			{
				if (-expiryDate>= (int)fVectorPast.size())
					return defaultValue;

				return fVectorPast[-expiryDate];
			}

			if (expiryDate>= (int)fVector.size())
				return defaultValue;

			return fVector[expiryDate];
		}

		template <class T>
		void CSRBufferCodeElement<T>::Add(long expiryDate, const T& value, const T& defaultValue)
		{
			if (!fVector.size())
				Reset(defaultValue);

			if ((expiryDate -= fToday)<0)
			{
				if (-expiryDate>= (int)fVectorPast.size())
				{
					size_t newSize = -expiryDate+1;
					size_t newSize2 = 2 * fVectorPast.size();
					if(newSize < newSize2)
						newSize = newSize2;
					fVectorPast.reserve(newSize);
				
					for (size_t i = fVectorPast.size() ; i<newSize ; i++)
						fVectorPast.push_back(defaultValue);
				}
				
				fVectorPast[-expiryDate] = value;
			}
			else
			{
				if (expiryDate>=(int)fVector.size())
				{
					size_t newSize = expiryDate+1;
					size_t newSize2 = 2 * fVector.size();
					if(newSize < newSize2)
						newSize = newSize2;
					fVector.reserve(newSize);
				
					for (size_t i = fVector.size() ; i<newSize ; i++)
						fVector.push_back(defaultValue);
				}
				
				fVector[expiryDate] = value;
			}

			fInvertVector[expiryDate+fToday] = value;
		}

		// (i) Returns keyLeft and keyRight such as keyLeft < dateTest < keyRight
		//        where keyLeft is the greatest possible, and keyRight the smallest possible
		// (ii)  if no such keyLeft exists, keyLeft is defaultValue
		// (iii) if no such keyRight exists, keyRight is default value
		//
		// (iv) Note : if some date is exactly dateTest, keyLeft is set dateTest and keyRight is set to defaultValue
		// (v)  Unreachable code : by definition of "upper_bound()" it should not happen that keyRight is exactly dateTest...

		template <class T>
		void CSRBufferCodeElement<T>::GetBoundaries(long dateTest, T& t1, T& t2, long& keyLeft, long& keyRight, const T& defaultValue) const
		{
			if (!fVector.size())
				((CSRBufferCodeElement<T>*)this)->Reset(defaultValue);
			
			// upper_bound returns the furthermost iterator i in [first, last) such that, for every iterator j in [first, i), value < *j is false.
			//
			// if existing dates are 1,2,3, then upper_bound(2) is 3.
			// to simplify, consider that, with most comparison operators,
			// upper_bound(x) returns the first value to be strictly greater than x
			_STL::map<const long,T>::const_iterator iter = fInvertVector.upper_bound(dateTest);

			keyLeft = keyRight = 0;

			if (iter!=fInvertVector.end())
			{
				t2		 = iter->second;
				keyRight = iter->first;

				if (iter!=fInvertVector.begin())
				{
					t1		= (--iter)->second;
					keyLeft = iter->first; // see case (i)
				} 
				else
					t1 = defaultValue; // see case (ii)
			}
			else if (fInvertVector.size())
			{
				t1		= (--iter)->second;
				keyLeft = iter->first;
				t2		= defaultValue; // see case (iii)
			}
			else
			{
				t1 = defaultValue;
				t2 = defaultValue;
			}
			if (keyLeft==dateTest)
				t2 = defaultValue; // see case (iv)
			if (keyRight==dateTest)
				t1 = defaultValue; // see case (v)

		}

		template <class T>
		void CSRBufferCodeElement<T>::Reset(const T& defaultValue)
		{
			fInvertVector.clear();
			fVector.clear();
			fVector.reserve(3650);
			fVectorPast.clear();
			fVectorPast.reserve(3650);

			for (int i = 0; i<3650 ; i++)
			{
				fVector.push_back(defaultValue);
				fVectorPast.push_back(defaultValue);
			}
		}

		template <class T>
		long CSRBufferCodeElement<T>::GetLowerDate(long date) const
		{
			_STL::map<const long,T>::const_iterator iter = fInvertVector.lower_bound(date);
			if (iter != fInvertVector.end())
				return iter->first;
			else
				return 0;
		}

	};
};
SPH_EPILOG
#endif
