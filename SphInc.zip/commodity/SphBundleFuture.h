/*
 	File:		SphBundleMarketData.h
 
 	Contains:	Class for the handling of instrument bundles
 
 	Copyright:	� 2001-2002 Sophis.
 
*/
#pragma once
 
#ifndef _SphBundleFuture_H_
#define _SphBundleFuture_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"

#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_BUNDLE_FUTURE(derivedClass)				DECLARATION_PROTOTYPE(derivedClass,sophis::commodity::CSRBundleFuture)
#define CONSTRUCTOR_BUNDLE_FUTURE(derivedClass)				
#define WITHOUT_CONSTRUCTOR_BUNDLE_FUTURE(derivedClass)		
#define	INITIALISE_BUNDLE_FUTURE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

#define DECLARATION_ROLLING_GRID(derivedClass)			DECLARATION_PROTOTYPE(derivedClass,sophis::commodity::CSRRollingGrid)
#define CONSTRUCTOR_ROLLING_GRID(derivedClass)				
#define WITHOUT_CONSTRUCTOR_ROLLING_GRID(derivedClass)		
#define	INITIALISE_ROLLING_GRID(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

SPH_PROLOG
namespace sophis	{
	namespace commodity {

		class SOPHIS_COMMODITY CSRBundleFuture 
		{
		public:
			CSRBundleFuture();
			virtual ~CSRBundleFuture();

			struct	BreakDown;

			virtual void	GetBreakDown(long portfolio_underlying, long underlying_id, int month, int year, BreakDown * list, long aggregation_profile_id) const {list->fCount = 0;};
			virtual void	GetModifiedBreakDown(long portfolio_underlying, long underlying_id, int month, int year, BreakDown * list, long aggregation_profile_id) const {GetBreakDown(portfolio_underlying,underlying_id,month,year,list,aggregation_profile_id);};

			static CSRBundleFuture* gDeltaGamma;
			static CSRBundleFuture* gVega;

			typedef tools::CSRPrototype<CSRBundleFuture, const char *, tools::less_char_star> prototype;

			static prototype & GetPrototype();

			virtual CSRBundleFuture * Clone() const = 0;

		public:	//  associated struture
			enum	eBundleFuture{
				MAX_BREAK_DOWN = 10
			};
			struct BreakDown	{
				int		fCount;
				struct	future	{
					long	fUnderlying_id;
					int		fMonth;
					int		fYear;
					double	fCoefficient;
				} fList[MAX_BREAK_DOWN];
			};
		};

		class SOPHIS_COMMODITY CSRRollingGrid
		{
		public:
			CSRRollingGrid();
			virtual ~CSRRollingGrid();

			virtual void GetRollingGrid(_STL::vector<long> &dates, _STL::vector<_STL::string> &names) const = 0;
			virtual bool IsWithNames() const = 0;

			typedef tools::CSRPrototype<CSRRollingGrid, const char *, tools::less_char_star> prototype;

			static prototype & GetPrototype();
		};
	}
}
SPH_EPILOG
#endif
