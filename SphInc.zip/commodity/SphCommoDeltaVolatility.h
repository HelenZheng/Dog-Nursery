#ifndef __SPHCOMMODELTAVOLATILITY_H__
#define __SPHCOMMODELTAVOLATILITY_H__

#include "SphInc/commodity/SphCommodityLME.h"

SPH_PROLOG
namespace sophis {
	namespace market_data{
		class SOPHIS_FINANCE CSRFXCubicVolatilite : public virtual CSRVolatility
		{
			DECLARATION_VOLATILITY(CSRFXCubicVolatilite)

		protected:
			virtual CSRSmile *new_Smile(eVolatilityCurveType volatilityCurveType, const TsmileInfos &infos) const;
			virtual CSRSmileList		*new_SmileList(eVolatilityCurveType volatilityCurveType) const;

		public:
			virtual bool ConstructAgain() const;
			virtual bool isVegaMarketAvailable() const;

			virtual double	GetVolInDelta(	double					maturity,
											double					delta,
											const CSRMarketData&	context,
											eVolatilityCurveType	volatType) const;

		private:
			short fIsWithExtrapolate;
		};

	}
	namespace commodity {

		class SOPHIS_COMMODITY CSRCommoDeltaVolatility :  public virtual market_data::CSRFXCubicVolatilite
		{
			DECLARATION_VOLATILITY(CSRCommoDeltaVolatility)
		};

		class SOPHIS_COMMODITY CSRLMEDeltaVolatility :  public virtual CSRVolatilityLME
		{
			DECLARATION_VOLATILITY(CSRLMEDeltaVolatility)
		protected:
			virtual market_data::CSRSmile *new_Smile(market_data::eVolatilityCurveType volatilityCurveType, const market_data::TsmileInfos &infos) const;
			virtual market_data::CSRSmileList *new_SmileList(market_data::eVolatilityCurveType volatilityCurveType) const;

		public:
			virtual bool ConstructAgain() const;
			virtual bool isVegaMarketAvailable() const;
			virtual double GetOptionMaturity() const;
			virtual void SetOptionMaturity(double maturity) const;
			virtual double	GetVolInDelta(	double								maturity,
											double								delta,
											const market_data::CSRMarketData&	context,
											market_data::eVolatilityCurveType	volatType) const;

		private:
			short fIsWithExtrapolate;
			mutable double 	fOptionMaturity;

		};
	}
}
SPH_EPILOG
#endif