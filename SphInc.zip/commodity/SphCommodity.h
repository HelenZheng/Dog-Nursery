/*
 	File:		SphCommodity.h
 
 	Contains:	Class for the handling of a commodity.
 
 	Copyright:	� 2001-2004 Sophis.
*/


#pragma once

#ifndef __SPHCOMMODITY_H__
#define __SPHCOMMODITY_H__

#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/instrument/SphFuture.h"
#include "SphInc/market_data/SphVolatility.h"
#include "SphInc/static_data/SphCalendar.h"
#include "SphInc/commodity/SphBufferCode.h"
#include "SphInc/commodity/SphBufferCode_impl.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/static_data/SphCalendar.h"
#include "SphInc/finance/SphProductTypeSubject.h"



#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)


#include <math.h>



#define DECLARATION_COMMODITY(derivedClass)			DECLARATION_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define CONSTRUCTOR_COMMODITY(derivedClass, parent)	CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, parent, const DTitrePlus)
#define WITHOUT_CONSTRUCTOR_COMMODITY(derivedClass)	SANS_CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define	INITIALISE_COMMODITY(derivedClass, name)	INITIALISE_INSTRUMENT(derivedClass, CSRCommodity, name)

SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace	sophis	{
	namespace instrument	{
		class CSRFuture;
		class CSROption;
	}

	namespace gui
	{
		inline int SurchargeIDRes(int resID) { return resID%1000; };
	}

	namespace commodity	{

		void DescribeUnit(sophis::tools::dataModel::DataSet &dataSet, long unit, const char *field_name);
		void UpdateUnit(const sophis::tools::dataModel::DataSet &dataSet, instrument::CSRInstrument &inst);
		void UpdateDelivery(const sophis::tools::dataModel::DataSet &dataSet, instrument::CSRInstrument &inst);

		typedef _STL::set <_STL::string, _STL::less<_STL::string> >				STRING_SET;
		typedef _STL::pair<int,int>												TKeyMY;
		typedef _STL::map<TKeyMY, int>											TMapMY;
		typedef _STL::vector<_STL::pair<long, double> >							TVectLongDouble;
		typedef _STL::map<long, _STL::map<long, double > >						TUndMatDelta;
		typedef _STL::map<long, _STL::map<long, _STL::map<long, double > > >	TComUndMatDelta;
		typedef _STL::map<long, _STL::vector<long> >							TMapPairingUnderlying;


		/** Error list encounting when building an instrument which uses the futures..
		STR#12205
		@since 4.6
		*/
		enum	eFutureListError
		{
			eNoError  = 0,
			eNoUnderlying,
			eNoFutureList,
			eEmptyFutureList,
			eNoCalendarForUnderlying,
			eDeliveryDateNotInDays,
			eNoFutureWithGoodDeliveryDate,
			eNotACommodity,
			eDeferredFixingDateNotInDays
		};

		//Natural Gas flow generation
		enum engPeriodType
		{
			engUndefined,
			engTRef,
			engTRefMinus,
			engEndDate
		};

		/** Commodity dialog id
		*/
		const int	kCommodityDialog = 208;
		const int	kCommodityBasketDialog = 207;

		struct SSCommodityInstrument;
		class  CSRFixingType;

		struct SSFutureCode
		{
			long	code;
			long	expiryDate;
			long	deliveryDate;
			long	paymentDate;
			long	deferredFixingDate;
			long	currency;
			long	deliveryPeriodId;
			long	deliveryLoadId;
		};

		struct SSDefaultValues
		{
			SSDefaultValues()
			{
				memset(this, 0, sizeof(SSDefaultValues));
			}
			
			double	contractSize;
			char	unitname[100];
			char	modelname[100];
			long	expiryDate;
			long	deliveryDate;
			long	settlementDate;
			long	currency;
			char    deliveryPeriod[100]; // For Power&Gas only
			char    deliveryLoad[100];   // For Power only
			long	rollingDate;
			long	marketCode;
			long	deferredFixingDate;
		};

		struct SSLocalDouble
		{
			SSLocalDouble(){fValue = 0.;}
			double fValue;
		};
		/*
		 *
		 */
		class  ISRCorrelationFormulaException : public sophisTools::base::ExceptionBase
		{
		public:
			ISRCorrelationFormulaException(const char * msg = "Correlation Formula wrong")
				: ExceptionBase("ISRCorrelationFormulaException", msg)
			{
			}
		};

		class  SOPHIS_COMMODITY ISRCorrelationFormula
		{
		public: 
			virtual ~ISRCorrelationFormula();
			virtual double GetComputedCorrelation(long sico1,long sico2,double absoluteOrRelativeValue,market_data::eVolatilityPointType pointType,bool& isExact) const throw (ISRCorrelationFormulaException) = 0;			
		};

		void SOPHIS_COMMODITY ReloadWorksheets(bool forceRefresh);

		/*
		 * Hold data for correlations computation (see CSRCommodity::new_CorrelationFormula)
		 * fBaseCorrelations and fMaturities fields have to be filled.
		 */
		class SOPHIS_COMMODITY CSRCommodityCorrelationFormulaParams
		{
		public:

			CSRCommodityCorrelationFormulaParams(const _STL::map<long,unsigned int>& maturitiesCommo1,
												 const _STL::map<long,unsigned int>& maturitiesCommo2,
												 const _STL::vector< _STL::vector<double> >& baseCorrelations,
												 double lambdaSelfCorrel,
												 double minSelfCorrel,
												 double maxSelfCorrel);

			/*
			 * Returns by reference, for a given expiry (@exp) and commodity (@index, = 0 for commo1, = 1 for commo2),
			   the upper (@outLowMat) and lower (@outUpMat) availabe maturities in the maturities tabs.
			   Also returns the indexes to locate the correlation values in fBaseCorrelations (@outPosLow, @outPosUp)
			 */
			virtual void GetUpperAndLowerBound(long exp,unsigned int index,unsigned int& outPosLow,unsigned int& outPosUp,long& outLowMat,long& outUpMat) const;			
			/*
			* Check that inputed data tabs are correctly sized
			*/	
			virtual bool CheckInputDataSize() const;
			/*
			* Returns the last available index of the correlations matrix (@side = 0 for commo1 side, = 1 for commo2 side)
			*/	
			virtual unsigned int GetLastCorrelationMatrixIndex(unsigned int side) const;



			/*
			* Store the inputed correlations, by sorted maturities. First index is commodity 1 side, second index is commo 2
			*/
			_STL::vector< _STL::vector<double> > fBaseCorrelations;
			/*
			* Sorted maturities list, stored as absolute dates, for commodity 1 (fMaturities[0]) && 2 (fMaturities[1])
			*/
			_STL::map<long,unsigned int>			 fMaturities[2];

			double fLambda;
			double fMinCorrel;
			double fMaxCorrel;

		};


		/*
		 *
		 * ==== ==== ============================== ==== ====
		 * ==== ==== ====    CSRCommodity      ==== ==== ====
		 * ==== ==== ============================== ==== ====
		 *
		 */


		class SOPHIS_COMMODITY CSRCommodity : public virtual instrument::CSRInstrument,
		                                      public sophis::finance::ISRProductTypeSubject
		{
		public:
			CSRCommodity(const DTitrePlus *titre);
			CSRCommodity(const DTitrePlus *titre, bool doInitRecomputeAll);
			virtual ~CSRCommodity();

		protected :
			CSRCommodity();

			/** Used by a constructor to initialize an object.
			This is for internal use only.
			*/
			void Initialize(const DTitrePlus *instrument);

			/** Used by a constructor to initialize an object.
			This is for internal use only.
			*/
			void Initialize(const DTitrePlus *instrument, bool doInitRecomputeAll);

		public :

			/* Returns true when the module corresponding to the commodity has been loaded.
			 * This method is used for licensing of the Commodity module and is called by ::CanBePurchased() before booking commodity derivatives
			 */
			bool IsLoaded(void) const;

			virtual const char * GetXMLRootName() const;

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			virtual void DescribeFutureExpiryConvention(eFutureConventionName index, sophis::tools::dataModel::DataSet & data_set) const;
			virtual void UpdateFutureExpiryConvention(const sophis::tools::dataModel::DataSet & data_set, SSCommodityInstrument *p);

			virtual void UpdateInstrumentListType(const sophis::tools::dataModel::DataSet &dataSet, SSCommodityInstrument *p);

			/**
			 * returns the default delivery, settlement and deferred fixing dates from a maturity date.
			 */

			virtual long	GetDefaultFutureSettlementDate(long expiryDate, long currency) const;
			virtual long	GetDefaultFutureDeliveryDate(long expiryDate, long currency) const;
			virtual long	GetDefaultFutureDeferredFixingDate(long expiryDate, long currency) const;
			virtual long	GetDefaultFutureExpiryDate(long deliveryDate, long currency) const;


			virtual const CSRFixingType* GetFixingType(int fixingOfLeg, int fixingOfOtherLeg) const;

			//virtual bool	GetInterpolationValuesForDeltaGamma(long codeOrDate, SSInterpolationValues& value1, SSInterpolationValues& value2) const;
			//virtual bool	GetInterpolationValuesForVega(long codeOrDate, SSInterpolationValues& value1, SSInterpolationValues& value2) const;

			//useful for spread volatility model
			virtual double GetSwapVolatility(double volatility1, double volatility2, double weight1,double weight2, double correlation) const;

			virtual bool	GetCommodityData(sophis::tools::CSRArchive & archive) const;
			virtual void	SetCommodityData(const sophis::tools::CSRArchive & archive);

			short GetRoundingAvg(void) const;
			void SetRoundingAvg(short val) const;
			double RoundCommoAvg(double x) const;
			
			virtual long GetWorksheetId() const;
			virtual void SetWorksheetId(long aWorksheetId);

			virtual bool ReloadWorksheet() const; 

			enum eCommodityType
			{
				eStandardCommodity		= 0,
				eLMECommodity			= 1,
				eGasCommodity			= 2,
				ePowerCommodity			= 3,
				eCommodityBasket		= 4,
				eHourlyGasCommodity		= 5,
				ePreciousMetalCommodity	= 6,
				eGSCISpot				= 7,
				eGSCIER					= 8,
				eGSCITR					= 9,
				ePhysicalCommodity      = 10,
				eUSERCOMMODITY			= 1000
			};

			virtual eCommodityType GetCommodityType() const = 0;

			virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;
			
			static void RetrieveCommodityCodesFromInstrument(long lInstrumentCode, _STL::set<long> &outCommoCodes, bool bWithInstrumentLoading = true);
			
			/* Monthly Average Future (used for TAPOs) */

			virtual int	GetMASPFixing() const;
			virtual void GetMASPInstrumentDefaultName(const SSDefaultValues& defaultValues, char *reference, char* name) const;
			
			virtual CSRBufferCode<long> & GetMASPFuturesContainer() const;
			//virtual CSRBufferCode<long> & GetFuturesForTAPOsContainer() const;
			/**
			* retrieve the TAPO internal-Future code by expiry from the list of all known TAPO's futures
			*/
			virtual long GetMASPFutureCodeByExpiry(long expiryDate) const;

			virtual void RefreshTapoFuture(SSFutureCode& futureCode) const;
			
			virtual void	FillFutureList() = 0;

			virtual double  GetPriceQuotationFactor() const; // Used for Commodities Quoted in Cents (0.01) or in the Hundred of Cents (0.0001)

			virtual bool MatchMarkPnLRule(char* instrType, char* instrFeature1, char* instrFeature2) const;

			/**
			*	ISRProductTypeSubject interface implementation.
			**/
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;

			/**
			*	ISRProductTypeSubject interface implementation.
			**/
			virtual bool HasFeature(const sophis::finance::CSRProductFeature &feature, const _STL::string &featureName) const;

			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

		protected:

			void ReadMASPFuturesList();
			mutable CSRBufferCode<long> fMASPFutureCodeByExpiryDate; // filled by ReadMASPFuturesList() from DB

			mutable CSRBufferCode<long> fFutureForTapoCodeByExpiryDate; // filled from Worksheet


			/* End Monthly Average Future */


		public:
			DECLARATION_CASTAGE_CHILD
				
			struct	ListedFuture
			{
				// no possible destructor (sql)
				ListedFuture(){fExpiry = 0; fFuture_id = 0; fIndex = 0;}
				long	fExpiry;
				long	fRolling_Date;
				long	fFuture_id;
				int		fIndex; //tells if i-th number in the same month

				bool operator== (const ListedFuture& src) const; 
			};

			/** Future list for listed swap pricing.
			@since 4.3
			*/
			struct SOPHIS_COMMODITY ListedFutureList
			{
				ListedFutureList();
				~ListedFutureList();

				/** Roll over to calculate the future to use.
				*/
				int							fRollOver;

				/** Structure of futures supposed to be sorted by date (expiry, delivery, payment).
				*/
				CSRBufferCode<ListedFuture>	fList;

				/** this function assumes that the list fList is sorted by increasing order on fExpiry
				// take into account the RollOver !
				*/
				virtual const ListedFuture* GetNearBy(long	date) const;	

				/* this method does *not* take into account any kind of RollOver */
				virtual const ListedFuture* GetNextFutureExpiryFrom(long date) const;
			
				/* this method takes into account Roll-Over AND Future's Rolling dates AND Swap's Rolling Gap */
				// Since v5.2.8 GetNearByForSwap(...) replace GetNearBy()
				// This function is similarly to GetNearBy, plus it take in account future's RollingDate,  RollingGap and RollingGap Calendar
				// for new developments GetNearByForSwap(...) must be used
				// GetNearBy(...) is used for listed marked only 
				virtual const ListedFuture* GetNearByForSwap(long date, long nRollingGap =0, const static_data::CSRCalendar* pCalendar=NULL) const;
			};

			/** Sources of risk for that commodity.
			Must be use for derivative on that commodity to know what are the risk sources.
			This is a map whose key is the expiry and the data is the future id.
			@since 4.6 as the risk sources are different as listed sources for commodity.
			*/
			struct FuturesRiskSources : public	_STL::map<long,long>
			{
				/** Fill the list with all the expiry dates
				* @param a list of expiry dates to fill
				*/
				SOPHIS_COMMODITY void GetExpiryDateList(_STL::list<long>& expiryDatesList);

				/** Fill the list with all the future ids
				* @param a list of future ids to fill
				*/
				SOPHIS_COMMODITY void GetFutureIdList(_STL::list<long>& futureIdsList);

				/** Find a future id with an expiry date
				* @param expiryDate is the expiry date
				* @returns the future id or 0 if not found.
				*/
				SOPHIS_COMMODITY long FindFutureId(long expiryDate);

				/** Allows to equalize the risk sources and the listed sources.
				*/
				SOPHIS_COMMODITY FuturesRiskSources & operator = (const ListedFutureList &);
			};

			/** Get the list of futures for listed swap evaluation.
			@return a ListedFutureList structure which must not be deleted.
			@since 4.5
			@see ListedFutureList
			*/
			//virtual const ListedFutureList * GetFutureList() const;

			/** Get the futures risk sources.
			 * For LME, the risk sources are different from the future list for swap.
			 * @return a FuturesRiskSources .
			 * By default, call GetFutureList in case of an update to do and return fRiskCode which is initialized as GetFutureList().
			 * @since 4.6
			 */
			virtual const FuturesRiskSources* GetFutureRiskSources() const;
			
			//gives the roll over necessary to compute Future swap on commodity
			virtual long GetRollOver() const;
			
			/** enum describing the kind of term structure of contracts indentifying the commodity prices. **/
			enum eCommodityListType
			{
				/** term structure of future contracts **/
				FutureDelivery,
				/** term structure of monthly swap rate **/
				PhysicalDelivery
			};

			virtual eCommodityListType GetInstrumentListType() const;
			virtual long	GetParentID() const;

			virtual long GetUnit() const;
			virtual eFutureConventionName	GetFutureExpiryConvention() const;

			/** Get the day ahead definition			
			 * @return a short that corresponds to the day ahead definition.			
			 * @since 6.2
			 */
			virtual short GetDayAheadDefinition() const;
			virtual bool IsACommodityBasket() const;
			virtual static_data::CSRCalendar* NewCSRCalendar() const;
			virtual void GetQuotationTick(double spot, double *delta, int *digits) const;
			virtual bool IsAPhysicalCommodity() const;

			int		GetDeliveryLag() const;
			//int		GetPaymentLag() const;
			
			/** deprecated.
			since 4.6 because there is more than two unit types. Use GetTransition
			*/
			//double	GetDensity() const;	

			double	GetTransition(long unit1, long unit2) const;
			double	GetDefaultQuotity() const;
			long	GetDeltaUnit() const;
			double	GetDeltaQuotity() const;
			double	GetGammaTick() const;
	
			static const CSRCommodity::ListedFuture* GetLastFutureSameExpiryConvention(long date, const CSRCommodity::ListedFutureList * list);

			/* Access to future model*/
			instrument::CSRFuture* GetFutureModel(void) const;

			void SetFutureModel(const DTitrePlus *titre);

			/** Check the two different arrays and increase the commodity future version and replace the future list
			**/
			//void	SetFutureList(_STL::vector<ListedFuture> &futureList, int nbFuture);

			/**
			 * To generated futures with default values
			 */
			virtual void GetFutureDefaultValues(long date, SSDefaultValues& defaultValues, long currency, bool byExpiry=true) const;

			/**
			 * To give back the name of Futures
			 */
			virtual void GetFutureDefaultNames(const SSDefaultValues& defaultValues, char* reference, char* name) const;

			/**
			 * To finalize the reference name of a Future (if the reference is already existing).
			 */
			virtual void GetFinalReference(char* reference, STRING_SET& setRef, bool isCurrency) const;

			/**
			 * Create a future in Database and send message.
			 */
			virtual long CreateFuture(const SSDefaultValues& defaultValues, const char* name, const char* reference) const;
						
			/**
			 * look if reference already exists or if in the set and if not put this one in the set.
			 */
			virtual bool CheckReference(char* reference, STRING_SET& setRef) const;

			/**
			 * send message to refresh the commodity from the list.
			 */
			virtual void RefreshFutureList(_STL::vector<SSFutureCode>& futureVector) const;

			/**
			 * send message when creating a daily future with a given expiry.
			 * this method assumes the commodity is not changed in its parameterisation
			 */
			virtual void RefreshOneFuture(SSFutureCode& futureCode) const;

			/**
			 * in the worksheet called by commodity before reading any zones of prices
			 */
			virtual void BeginWorksheetComputations(int whichPairing);

			/**
			 * callback function called at the end of update of the commodity by the worksheet.
			 */
			virtual void EndWorksheetComputations();
		
			/**
			 * store the results from the worksheet.
			 */
			virtual void StoreWorksheetResults(long code, double value, int whichPairing) const;

			/**
			 * gives the name of the first zone in the worksheet to read from the commodity zone.
			 */
			virtual void GetDefaultWorksheetPairing(_STL::string& columnName) const;

			/**
			 * gives the number of paired zone to read and to pair
			 */
			virtual int GetWorksheetPairingCount() const;

			/**
			 * gives the name of the supplementary zone to read and to pair
			 * @param which ranges from 1 to GetOtherWorksheetPairingCount()-1
			 */
			virtual void GetWorksheetPairingName(_STL::string& columnName1, _STL::string& columnName2, int which) const;

			enum eWorksheetType
			{
				ewstUndefined,
				ewstExpiry,
				ewstDelivery,
				ewstTAPO,
				ewstPower,
				ewstPowerProfile,
				ewstListedOption
			};
			/**
			 * tells if the dates are to be taken like expiry or delivery dates 
			 * or if the future is directly identified by its code (ewstPower)
			 */
			virtual eWorksheetType GetWorksheetType(int whichPairing) const = 0;

			/**
			 * checks that the worksheetlist table is a valid worksheet table.
			 */
			static bool IsValidWorksheetListTableName(const char* tableName);

			/** 
			 * sets the data corresponding to a given pairing.
			 * the dates (first element of each element of data are dates with SOPHIS format
			 * @param tableName name of the table of worksheet list to be updated
			 * @param which		pairing number (between 0 and GetWorksheetPairingCount()-1)
			 * @param data		data corresponding to the chosen pairing 
			 * @param idents	set that contains the ident of the worksheet that is modified
			 * @param onlyDates	if set to false the dates are overwritten, if set to true, the dates are compared but not overwritten.
			 * @param createFutures if set to false the dates passed do not create the corresponding Futures, if set to true, the corresponding Futures are created.
			 * @return true if everything goes well.
			 * @see GetWorksheetPairingCount(), SaveDataToTable()
			 */
			/*virtual bool SetWorksheetValues(const char*				tableName, 
											int						which, 
											const TVectLongDouble	&data, 
											bool					onlyDates, 
											bool					createFutures, 
											_STL::set<long>			&idents);*/

			/** 
			 * once all the modifications have been made on the worksheets, save the worksheets
			 * that correspond to the idents. To be used with SetWorksheetValues().
			 * To be saved, a worksheet must be activated. 
			 * @param tableName name of the table of worksheet list to be updated
			 * @param idents set that contains the idents of the worksheets that must be saved.
			 * @return true if everything goes well.
			 * @see SetWorksheetValues()
			 * @deprecated 5.3.4
			 */
			virtual bool SaveDataToTable(const char* tableName, _STL::set<long> &idents);

			virtual bool	ReportingBySettlementDate() const;
			virtual instrument::CSRInstrument * CreateFutureInstance(long future_code, long settlement_date, instrument::eForwardContractType forwardContractType) const;

			/** 
			 * this method tells if the future type is available.
			 */
			virtual bool IsFutureAvailable(_STL::string &errorMessage) const;

			virtual sophis::instrument::CSROption* new_SwaptionSplitter(sophis::instrument::CSROption* option) const;
			
			/** 
			 * this method tells if the commodity future may be automatically generated at the date @param date.
			 */
			virtual bool IsDateToGenerate(long date) const;

			/** 
			 * this method generates from a string data a date.
			 * It is a virtual method which permits to handle 3m rolling contracts for instance.
			 */
			virtual long GetRollingDate(const _STL::string& str) const;

			// Gives future list of this commodity

			
			/** Duplicates the satellite of DTitre.
			This method is for internal use when cloning.
			@since 4.6
			*/
			virtual void	DuplicateData(const instrument::CSRInstrument &instrument);	// internal

			static	int		GetCommodityCount();
			static	long	GetNthCommodity(int i);

			virtual bool	HasWorksheetChanged();

			void			Log(_STL::string log) const;
			void			ClearLogs() const;
			_STL::vector<_STL::string> GetLogs() const;
			
			ISRCorrelationFormula * new_CorrelationFormula(long againstCommodity,const CSRCommodityCorrelationFormulaParams & formulaParams) const;

			virtual double GetComputedCorrelation(long againstCommodity,long futCode1,long futCode2, double startDate, double endDate) const; 			const _STL::map< double, long >& GetWorksheetListedOptions() const;
			/**
			* Return future code associated to listed option by option expiry date
			* Return 0 if option on expiryDate not found
			*/
			virtual long GetFutureCodeForListedOption(long expiryDate) const;

			//MASP futures for TAPOs options
			virtual long GetFutureCodeForListedMarket(int month, int year, int index) const;
			virtual long GetNearByFutureCodeForListedMarket( long date) const;


			/*
			 * Gives a container with the option expiry dates and their future codes for listed markets
			 * By default (CSRCommodity), uses the data from worksheet zones Listed_Dates_xxx and Futures_Codes_xxx
			 * Other implementations exist for Oil and LME
			 */

			virtual const CSRBufferCode<long>* GetListedOptionExpiry() const;
			virtual void  SetWorksheetLastReleaseLoaded(bool aIsWorksheetLastReleaseLoaded) const;
			virtual bool  GetWorksheetLastReleaseLoaded() const {return fIsWorksheetLastReleaseLoaded;};

		protected:
			mutable bool fIsWorksheetLastReleaseLoaded; // "True" if The Last Release of WS is loaded else "false". "True" meant that WS is updated.
			mutable long fWorksheetId;

			/*
			 * Pair of (option expiry date, future code) that is read from worksheet zones Listed_Dates_xxx and Futures_Codes_xxx
			 * Empty when the zones are not defined (or incorrectly)
			 */

			mutable _STL::map< double, long > fWorksheetListedOptions;

			/**
			 * This is computed by GetListedOptionExpiry()
			 * Container containing only Future underlying of listed options
			 * key (expiry date of the listed option), value(future code)
			 */
			
			mutable CSRBufferCode<long>		fBasicOptionExpiry;

		protected:
			/**
			Clones an existing commodity to allow modification.
			@return	a pointer to the cloned instance.
			*/
			virtual instrument::CSRInstrument * Clone() const = 0;

		protected:
			mutable FuturesRiskSources		fRiskCode;

			/**
			* Container containing the future implied spot
			* key (future code), value(future value)
			*/
			mutable _STL::map<long, double> fBufferImpliedSpot;

		protected :
			mutable TMapMY					fMapAlreadyFilled;
			mutable bool					fUseMapAlreadyFilled;
			instrument::CSRFuture*			fFutureModel;
			mutable TMapPairingUnderlying	fNewUnderlyingMap;
			mutable	TMapPairingUnderlying	fUnderlyingMap;
			mutable long					fLastPricesDate;

			mutable _STL::vector<_STL::string>		fLogs;

			const SSCommodityInstrument *GetSSCommodity() const
				{return (const SSCommodityInstrument *)GetDTitre(); }

			friend class CSRCommoditySave;

			//
			// ======== ========
			//
			// These method below are inherited from CSRInstrument
			//
			// Only specific issues are documented here.
			// Please see SphInc/instrument/SphIntrument.h for common documentation

		protected:
			/** Get the default meta model.
			This is called by all basic methods invoking calculations to get the default model.
			@return a pointer which may be null and must not be deleted.
			By default, return Cox or B&S according the model or sophis calculation.
			@since 5.0
			@see GetSophisComputationType.
			*/
			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;
		public:

			//virtual int		GetUnderlyingCount() const;
			//virtual long	GetUnderlying(int whichUnderlying) const;
			//virtual int		GetRhoCount() const;
			//virtual long	GetRhoCurrency(int which) const;

			/** Return 0.
			*/
			virtual	double			GetGlobalEpsilon(const sophis::CSRComputationResults& results) const OVERRIDE;

			virtual bool			GetUseWorksheetValues() const;


			virtual	double	GetQuotity(bool withTaxes=false) const;
			virtual	Boolean IsAPossibleSettlementType(instrument::eSettlementType settlementType) const;
			
			virtual void	GetWindowName(char *name) const;

			double	GetQuotationTick() const;

			long BO_FlowSettlementDate(long settlementDate, long minDate) const;

			void SetCommodityDataWithReset(const sophis::tools::CSRArchive & archive);

			static const CSRFixingType* GetFixingType(long fixingTypeThisLeg, long fixingTypeOtherLeg, long undCodeThisLeg, const CSRCommodity** outCommoPtr=NULL);

		private :
			static const char* __CLASS__;
		};

		class SOPHIS_COMMODITY ISROilOrLMEInterface
		{
		public:

			virtual void	GetVegaValues(long expiryDate, SSInterpolationValues &value1, SSInterpolationValues &value2) const = 0;
			/*
			* Returns the Volatility of a Future that is identified by its expiry date
			*
			* expiryDate          : identifies the Future.
			*                       If no Future has the exact expiryDate, 0 is returned.
			* currency            : the currency in which we want the volatility
			*                       If the Future currency is different, the Forex volatility will be included in the computation
			* sensitivity         : Sensitivity of the result with respect to the Future volatility
			*                       note it is always 1.0 if currency is the currency of the Future
			*
			* (...)               : See CSRMarketData::GetVolat(...) for details about other parameters which are not specific to Commodities
			*
			*
			*
			* RETURN : the volatility of the Future, in the currency given as argument
			*          0.0 if no Future has been found with the expiry date given as argument
			*/

			virtual double GetFutureVolatility(double						expiryDate,
												long							currency,
												double 						startDate,
												double						endDate,		
												double 						strike,
												NSREnums::eVolatilityType	volatilityType,
												Boolean 						put,
												const market_data::CSRMarketData			&context,
												double						*sensitivity = 0) const = 0;
			/**
			* retrieve the future code for a given delivery date and a given currency 
			* from the future containers.
			*/
			virtual long GetFutureCodeByDelivery(long deliveryDate, long currency) const = 0;
			/**
			* retrieve in the worksheet the code of the future reading a zone of price
			*/
			virtual long GetFutureCodeByExpiry(long expiryDate, long currency) const = 0;

			/**
			* tells if the date represented by gApplicationContext->GetDate() is fixed
			*/
			virtual bool GetClosedValue(double& value,const market_data::CSRMarketData &context, long fixingTag) const = 0;

			/**
			* Checks if futures may be created from the worksheet.
			*/
			virtual bool CanCreateDailyFuture() const = 0;

			/**
			 * Similar to GetFutureVolatility() method above. The future is identified by the internal 'futureCode'.
			 */
			virtual double GetFutureVolatility(
													const market_data::CSRMarketData			&context,
													long							futureCode,
													long							currency,
													double 						startDate,
													double						endDate,		
													double 						strike,
													NSREnums::eVolatilityType	volatilityType,
													Boolean 						put,
													double						*sensitivity = 0) const = 0;
		};

	}
}

template <class T>
sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::commodity::CSRBufferCodeElement<T> & bufferElement);
template <class T>
const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::commodity::CSRBufferCodeElement<T> & bufferElement);

template <class T>
sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::commodity::CSRBufferCode<T> & buffer);
template <class T>
const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::commodity::CSRBufferCode<T> & buffer);

SPH_END_NOWARN_EXPORT
SPH_EPILOG


#endif