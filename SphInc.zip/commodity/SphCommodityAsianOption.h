/*
 	File:		SphCommodityAsianOption.h
 
 	Contains:	Class for the handling of an AsianOption for Commodity.
 
 	Copyright:	� 2001-2008 Sophis.
*/


#pragma once

#ifndef __SPHCOMMODITYASIANOPTION_H__
#define __SPHCOMMODITYASIANOPTION_H__

#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/instrument/SphFuture.h"
#include "SphInc/market_data/SphVolatility.h"
#include "SphInc/static_data/SphCalendar.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/static_data/SphCalendar.h" 
#include "SphInc/finance/SphMetaModel.h"



#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)

#include <math.h>

#define DECLARATION_COMMODITY(derivedClass)			DECLARATION_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define CONSTRUCTOR_COMMODITY(derivedClass, parent)	CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, parent, const DTitrePlus)
#define WITHOUT_CONSTRUCTOR_COMMODITY(derivedClass)	SANS_CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define	INITIALISE_COMMODITY(derivedClass, name)	INITIALISE_INSTRUMENT(derivedClass, CSRCommodity, name)

SPH_PROLOG
namespace	sophis	{
	namespace instrument	{
		class CSRFuture;
		class CSROption;
	}

	namespace commodity	{

		class  SOPHIS_COMMODITY CSRCommodityAsianOption : public virtual sophis::finance::CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRCommodityAsianOption)

		public:
			static _STL::string		MetaModelName;

			static instrument::CSROption*  CreateOption(const instrument::CSRSwap* aSwap);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData & param,int lequel) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual double	GetVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int whichUnderlying) const OVERRIDE;
			virtual double	GetRho(const instrument::CSRInstrument & instrument,const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;
			virtual bool	ValidInstrument(const instrument::CSRInstrument & instrument) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};
	}
}
SPH_EPILOG


#endif