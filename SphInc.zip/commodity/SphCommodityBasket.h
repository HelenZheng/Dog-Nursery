/*
File:		SphCommodityBasket.h

Contains:	Class for the handling of a commodity.

Copyright:	� 2005 Sophis.
*/


#ifndef __SPHCOMMODITYBASKET_H__
#define __SPHCOMMODITYBASKET_H__

#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/Commodity/SphCommodityOil.h"

SPH_PROLOG
namespace sophis {
	namespace commodity {

		struct SSBasketCommodityComponent
		{
			long	sicovam;
			double	quantity;
			long	m;
			long	n;
			long	p;
			long	p_dateref;
			long	m_type;
			long	n_type;
			long	mnp_avg;
			long	fx_m;
			long	fx_n;
			long	fx_p;
			long	fx_p_dateref;
			long	fx_m_type;
			long	fx_n_type;
			long	fx_mnp_avg;
			long	fx_rule;
			double	fx_spread;
			long	mean_start;
			long	fx_mean_start;
			long	component_type;
			double	fx_guaranteed;
			long	fixing_column;
			long	fx_fixing_column;
			long	user_id;
			double	date_save;
			long	fx_average_way;
			long	lme_fixing;			//LME component only. Value is CSRFixingType::eStandard ::eLME or ::eLME3m only.
		};

		/** 
		*
		*/
		class  SOPHIS_COMMODITY CSRCommodityBasketInfo
		{
		public:
			/** Constructor to load data from the database.
			@param commodity_code is the commodity id.
			*/
			CSRCommodityBasketInfo(long commodity_code, bool bIsAttachedBasket, bool loadFromDB=true, double dateHisto=0., long swapCode=0,long mainSico=0);

			/** Trivial constructor.
			*/
			CSRCommodityBasketInfo();

			virtual ~CSRCommodityBasketInfo() {}

			virtual CSRCommodityBasketInfo*  Clone() const;

			//add some Get for the CSRCommodity information functions
			long GetBasketCode() const;

			//to get the basket spread
			double GetBasketSpread() const;

			static const char * MODEL_NAME ;

			unsigned int GetBasketElementCount() const;

			const SSBasketCommodityComponent & GetNthBasketElement(unsigned int i) const;

			void ClearBasket();
			void AddBasketElement(const SSBasketCommodityComponent & item);
			void SetBasketElement(unsigned int i, const SSBasketCommodityComponent & item);

			/** Load data from Oracle (table COMMODITY_BASKET).
			@param commodity_code is the commodity id.
			*/
			virtual int	Load(long commodity_code, bool isHisto=false, long oldSwapCode=0);

			//deprecated
			int	LoadOldVersion(long commodity_code, bool isHisto=false, long oldSwapCode=0);

			/** Save data from Oracle (table COMMODITY_BASKET).
			In charge of commit or Rollback in case of Oracle error
			@param commodity_code is the commodity id.
			@return 0 if ok, else the Oracle error.
			*/
			virtual int Save(long commodity_code) const;

			virtual const sophis::instrument::CSRInstrument* GetInstrument() const;

			virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet,const sophis::instrument::CSRSwap* pSwap, int iLeg);
			virtual void GetDescription(tools::dataModel::DataSet& dataSet, const sophis::instrument::CSRSwap* pSwap, int iLeg) const;

		protected:
			/** Commodity Id.
			*/
			long fCode;

			long fBasketSico;

			/** Basket Spread Value
			*/
			double fBasketSpread;
			_STL::vector<SSBasketCommodityComponent>	fBasketList;
			friend class CSRCommodityBasketDialog; //internal
			friend class CSDialogSwapCommoBasket;
		};

		class SOPHIS_COMMODITY CSRCommodityBasket : public virtual CSRCommodity	
		{

		public:
			DECLARATION_COMMODITY(CSRCommodityBasket)

		public:
			virtual bool IsACommodityBasket() const;

			virtual ~CSRCommodityBasket();

			void GetDescription(tools::dataModel::DataSet& dataSet) const;

			/** Access to the commodity basket informations.
			@return a pointer which must not be deleted. Return 0 if it is not a commodity basket.
			*/
			const CSRCommodityBasketInfo* GetCSRCommodityBasketInfo(bool isSimul=false, double dateHisto=0., long swapCode=0) const;

			/** Access to the number of basket components.
			@return the number of basket components. return 0 if it not a commodity basket.
			*/
			int	GetBasketElementCount() const;

			/** Access to one basket components.
			@param i is an index between 0 includes and GetBasketElementCount() excluded.
			@param component is valid pointer to receive the component information.
			@return true if succeed else return false (index outside bonds, not a commodity basket).
			*/
			bool GetNthBasketElement(int i, SSBasketCommodityComponent* component) const;

			/** Reset basket data with another ptr.
			@param commodity_basketis a new basket commodity
			*/
			void ResetBasketInfo(const CSRCommodityBasketInfo *commodity_basket); 

			/** Duplicates the satellite of DTitre.
			This method is for internal use when cloning.
			@since 4.6
			*/
			virtual void DuplicateData(const instrument::CSRInstrument &instrument);	// internal

			virtual instrument::CSRInstrument * Clone() const;

			virtual eCommodityType GetCommodityType() const;

			/**
			* tells if the dates are to be taken like expiry or delivery dates 
			* or if the future is directly identified by its code (ewstPower)
			*/
			virtual eWorksheetType GetWorksheetType(int whichPairing) const;

			virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;

			/* Returns a pointer to the commodity basket identified by the reference (see CSRInstrument::GetInstance())
			 * Creates the basket (object+save in DB) if it does not exist. In this case, the currency parameter is needed to set the currency of the basket.
			 *
			 * @param basketReference : reference of the basket to load or create
			 * @param currencyForCreation : currency code to be used if the baskets needs to be created
			 */

			static const CSRCommodityBasket *GetCommodityBasket(_STL::string basketReference, long currencyForCreation=0);
			static void FormatNameForSwap(long swapCode,int inLeg,_STL::string& outName);
			static bool IsAttachedBasket(const char *name);
			//CSRCommodityBasketInfo *GetBasketInfoSimulation();
			void ResetBasketInfoSimulation();

			/** Creates the right type of Instrument, depending on the field t->titre->model. */
			static sophis::commodity::CSRCommodity* CreateCSRCommodityBasket(const DTitrePlus* t);

			virtual void FillFutureList();

		private:
			mutable const CSRCommodityBasketInfo*	fBasketInfo;
			//used only for simulation in the swap dialog (when the basket is modified without being saved)
			mutable const CSRCommodityBasketInfo*	fBasketInfoSimul;
			mutable const CSRCommodityBasketInfo*	fAuditInfo;
			mutable double							fLastAuditDate;
			mutable double							fLastAuditSwapCode;
		};
	}
}
SPH_EPILOG
#endif
