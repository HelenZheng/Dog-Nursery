/*
 	File:		SphCommodityOil.h
 
 	Contains:	Class for the handling of a commodity oil.
 
 	Copyright:	� 2001-2004 Sophis.
*/

#ifndef __SPHCOMMODITY_CARBONCO2_H__
#define __SPHCOMMODITY_CARBONCO2_H__

#include "SphCommodityOil.h"

SPH_PROLOG
namespace sophis
{
	namespace commodity
	{
		class SOPHIS_COMMODITY CSRCommodityCarbonCO2 : public virtual CSRCommodityStandard
		{

		public:
			DECLARATION_COMMODITY(CSRCommodityCarbonCO2)

			virtual ~CSRCommodityCarbonCO2();

			virtual const finance::CSRMetaModel * GetDefaultMetaModel() const OVERRIDE;

			// These method below are inherited from CSRCommodity
            //virtual bool UseForwardCalculation() const;
			virtual sophis::instrument::eUnrealizedMethodType GetUnrealizedMethod() const;

			virtual bool HasFairValue() const;
			virtual const CSRFixingType* GetFixingType(int fixingOfLeg, int fixingOfOtherLeg) const;

			double GetDerivativeSpot(const sophis::market_data::CSRMarketData& context) const;

			static const char * MODEL_NAME;

			virtual sophis::instrument::CSROption* new_Splitter(sophis::instrument::CSROption* option, bool optionInPortfolio) const;

		protected:
		};
	}
}
SPH_EPILOG
#endif