/*
 	File:		SphCommodityDialogDialog.h
 
 	Contains:	Class for the handling commodity elements
 
 	Copyright:	� 2001-2002 Sophis.
 
*/

#pragma once

#ifndef	__SphCommodityDialog_H__
#define	__SphCommodityDialog_H__

#include "SphInc/gui/SphElement.h"

SPH_PROLOG
namespace	sophis	{
	namespace commodity	{

		class CSRSelectMeasureUnit : public gui::CSRElement {
		public:
			CSRSelectMeasureUnit(	gui::CSRFitDialog 	*dialog, 
								int 			 ERId_Unit, 
								long			 value=0, 
						  const char 			*columnName = kUndefinedField);
			CSRSelectMeasureUnit(	gui::CSREditList		*list, 
								int 			 CNb_Unit, 
								long			 value=0, 
						  const char 			*columnName = kUndefinedField);

			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			virtual void	ValueToString(char *dest, int line) const;
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			virtual void operator = (const gui::CSRElement&);
					void operator = (const CSRSelectMeasureUnit&);
			virtual int		Compare(const gui::CSRElement&) const;

			virtual void	GetValue(void *value) const;
			virtual void	SetValue(const void *value);
			
			long	*GetValue(void) { return &fValue; };

		protected:
			long	fValue;
			int		fERId_Unit;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual USMenu	*DonneMenu(void) const;				// internal
			virtual short	GetListValue(void) const;			// internal
			virtual void	SetListValue(short value);			// internal
			virtual Boolean	IsASharedMenu() const;				// internal

			ELEM_COMMON_INTERNALS

		};

	}
}
SPH_EPILOG
#endif

