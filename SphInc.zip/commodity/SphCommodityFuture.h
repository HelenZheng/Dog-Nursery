/*
 	File:		SphCommodityFuture.h
 
 	Contains:	Class for the handling of a future on commodity
 
 	Copyright:	� 1995-2002 Sophis.
 
*/
#pragma once

#ifndef __SPH_COMMODITY_FUTURE_H
#define __SPH_COMMODITY_FUTURE_H

#include "SphInc/instrument/SphFuture.h"


SPH_PROLOG
namespace sophis	{
	namespace commodity	{

struct SSWorksheetValue
{
	long underlying_code;
	long code;
	double value;
};

struct SSInterpolationValues;

class SOPHIS_COMMODITY CSRCommodityFuture : public virtual instrument::CSRFuture	{
public:
	DECLARATION_FUTURE(CSRCommodityFuture)

public:

	static const char * MODEL_NAME;

	virtual bool CanBePurchased(_STL::string & reason) const;
	
	virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

	virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& data_set);

	virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

	//virtual void				InitialiseRecomputeAll();

	virtual	double				GetEquityGlobalDelta(const sophis::CSRComputationResults& results) const OVERRIDE;
	virtual	double				GetEquityGlobalDelta(const market_data::CSRMarketData& context) const;
	virtual	double				GetEquityGlobalGamma(const market_data::CSRMarketData& context) const;
	virtual bool				ThetaIncludedInOptionTheta() const;

	virtual	double		GetDelta(const sophis::CSRComputationResults& results, long *instrumentCode)	const OVERRIDE;
	virtual double		GetDeltaPnL(const sophis::CSRComputationResults& results, int whichUnderlying) const OVERRIDE;

	virtual	double		GetGamma(const sophis::CSRComputationResults& results, long *instrumentCode)	const OVERRIDE;
	virtual	double		GetDerivativeSpot(const market_data::CSRMarketData& context) const;
	virtual	double		GetImpliedSpot(const market_data::CSRMarketData& context) const;
	virtual double		GetFirstDerivativeUndiscounted(const market_data::CSRMarketData &context, int whichUnderlying) const;

	/** Return 0.
	*/
	virtual	double			GetGlobalEpsilon(const sophis::CSRComputationResults& results) const OVERRIDE;

	virtual bool	ConstructAgain() const;

	virtual bool	GetClosedValue(double& value,const market_data::CSRMarketData &context) const;

	virtual sophis::market_data::CSRVolatilityComputation*	new_CSRVolatilityComputation() const;

	virtual double	GetVolatility(			double 						startDate,
											double						endDate,		
											double 						strike,
											NSREnums::eVolatilityType	volatilityType,
											Boolean 					put,
											const market_data::CSRMarketData			&context) const;

	virtual	double	GetCorrelation(	const market_data::CSRMarketData&	context,
									long 					currency1,
									long 					currency2,
									double 					startDate,
									double 					endDate) const;

	//virtual market_data::CSRMarketData* new_ComputationContext(const market_data::CSRMarketData 	&context,	double basketValue, bool smile) const;
	virtual void SetModifiedDates(bool plug, long start = 0, long end = 0);

	virtual bool GetSplit(long* code1, long* code2, double* weight1, double* weight2, bool with_unit = false, long aggregation_profile_id = 0, long swapBeginDate = 0, long swapEndDate = 0, short parentExpiredContract = 0) const;

	/**
	 * This method gives the underlying (for delta of an option of this instrument is an underlying)
	 */
	//virtual void GetDeltaUnderlying(const sophis::instrument::CSROption& option, _STL::set<long>& codeList, int whichUnderlying) const;

	virtual	sophis::instrument::CSROption* new_Splitter(sophis::instrument::CSROption* option, bool optionInPortfolio) const;

	//worksheet for futures
	static	int					GetWorksheetValuesCount();
	static	bool				GetNthWorksheetValue(int i, SSWorksheetValue* value);
	static	void				StoreWorksheetValues() { }; // DEPRECATED
	static	void				StoreWorksheetValues(_STL::map<long, bool> &commoditiesList, long fixingCode);

	/** Computes the bumped value of the spot according to bump parameters.
		@param spot_folio_index	spot of the portfolio underlying index
		@param beta_folio_index	beta of the portfolio underlying index
		@param spot_initial		initial spot to be bumped
		@param bump				bump magnitude (in cash)
		@param pivot			pivot value
		@param in_percent		tells if the bump has to be expressed in cash or in percent
		@return the bumped value of the initial spot.
		This method is called, for instance, by the risk matrix to compute the bumped values.
	*/
	virtual double				ComputeBumpedSpotValue(	double  spot_folio_index, 
														double  beta_folio_index,
														double  spot_initial,
														double  bump,
														double  pivot, 
														bool	in_percent) const;


	/** Return flags indicating if the model associated to this class is meaningful for the IR Futures dialog
	  * For flags : see AVAIL_FOR_GUI... defines
	@since 6.1
	*/
	virtual short ModelAvailabilityForIRFutureDialog() const;

	virtual long GetFutureCodeForListedMarket( int month, int year, int index) const;

protected:
	double			GetVolatilityForVega(	double 						startDate,
											double						endDate,		
											double 						strike,
											NSREnums::eVolatilityType	volatilityType,
											Boolean 					put,
											const market_data::CSRMarketData			&context,
											const market_data::CSRMarketData			&contextStrike) const;


	int		fVersionCommodityFuture;
	
	_STL::vector<int> fIndexArray;
	_STL::vector<long> fCodeList;
	
	bool fPlug;
	long fStart;
	long fEnd;

public:
	/** This method pulls out the values coming from this worksheet
	 * and push them back in the pivot value for the corresponding volatility surface.
	 */
	static	void				StoreWorksheetValuesAsPivot();

	/** This method pulls out the values coming from the history table of Futures
	 * and push them back in the pivot value for the corresponding volatility surface.
	 */
	static	void				StoreDBValuesAsPivot();
};
	}
}
SPH_EPILOG

#endif
