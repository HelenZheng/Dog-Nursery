/*
 	File:		SphCommodityGas.h
 
 	Contains:	Class for the handling of a Gas commodity
 
 	Copyright:	� 2005 Sophis.
*/

#ifndef __SPHCOMMODITYGAS_H__
#define __SPHCOMMODITYGAS_H__

#include "SphInc/commodity/SphCommodityPower.h"
#include "SphInc/market_data/SphHistoric.h"

SPH_PROLOG
namespace sophis {
	namespace commodity {

		class SOPHIS_COMMODITY CSRCommodityGas : public virtual CSRCommodityPower
		{

		public:
			DECLARATION_COMMODITY(CSRCommodityGas)

			//virtual const CSRDeliveryPeriod* GetPeriod	(const char* periodName, struct SwapInfosForNonStandardProfile *swapInfos=NULL)	const;
			//virtual const CSRDeliveryLoad*   GetLoad	(const char* loadName)		const;
			virtual void DuplicateData(const sophis::instrument::CSRInstrument &instrument);

			virtual int GetWorksheetPairingCount() const;
			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;
			//virtual double GetTheoreticalValue(const market_data::CSRMarketData &context) const;
			//virtual double GetDerivativeSpot(const market_data::CSRMarketData& context) const;
			//virtual CSRInstrument* CreateFutureInstance(long future_code, long settlement_date) const;

			virtual long GetLastDayOfTrade(long delivery_date) const
			{ return delivery_date; }

			virtual eCommodityType GetCommodityType() const;
			virtual int GetGranularity() const;
			virtual bool IsFutureAvailable(_STL::string &errorMessage) const;
			virtual const char* GetBulkloadModelName(const char *period, const char *load) const;

			virtual void DeletePeriod(const char *periodName);
			static void ClearPeriodCache(void);
			//static void ClearLoadCache(void);
			virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;

		protected :
			/**
			Clones an existing commodity to allow modification.
			@return	a pointer to the cloned instance.
			*/
			virtual instrument::CSRInstrument * Clone() const;

		public:
			virtual CSRDeliveryPeriod * CreatePeriodInstance(const char* periodId,
															 const SwapInfosForNonStandardProfile *swapInfos=NULL, 
															 const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL) const;
			virtual CSRDeliveryLoad * CreateLoadInstance(const char* loadName) const;

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);			
			virtual void DescribeContractDayAheadDefinition(short index, sophis::tools::dataModel::DataSet & data_set) const;
			virtual void UpdateContractDayAheadDefinition(const sophis::tools::dataModel::DataSet & datSet, SSCommodityInstrument *p);
		protected:
		};
		class CSRGasHistoricList : public sophis::market_data::CSRHistoricList 
		{
		public:
			CSRGasHistoricList(PInfoHisto infos);
			virtual static_data::CSRCalendar* NewCalendar() const;
		};

		class SOPHIS_COMMODITY CSRCommodityGasHourly : public virtual CSRCommodityGas
		{

		public:
			DECLARATION_COMMODITY(CSRCommodityGasHourly)

			virtual eCommodityType GetCommodityType() const;
			virtual int GetGranularity() const;
			virtual bool IsFutureAvailable(_STL::string &errorMessage) const;
		protected :
			virtual CSRDeliveryLoad * CreateLoadInstance(const char* loadName) const;
		};

	};
};
SPH_EPILOG
#endif
