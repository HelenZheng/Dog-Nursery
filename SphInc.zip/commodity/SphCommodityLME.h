/*
 	File:		SphCommodityLME.h
 
 	Contains:	Class for the handling of a commodity in LME
 
 	Copyright:	� 2001-2004 Sophis.
*/

#ifndef __SPHCOMMODITYLME_H__
#define __SPHCOMMODITYLME_H__

#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/static_data/SphListOfCalendars.h"


SPH_PROLOG
namespace sophis {
	namespace commodity {

		/*
		 *
		 * ==== ==== ============================== ==== ====
		 * ==== ==== ====    CSRCommodityLME  ==== ==== ====
		 * ==== ==== ============================== ==== ====
		 *
		 */

		class SOPHIS_COMMODITY CSRCommodityLME : public virtual CSRCommodity, public virtual ISROilOrLMEInterface	
		{
		
		public:
			DECLARATION_COMMODITY(CSRCommodityLME)

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			//virtual bool UseForwardCalculation() const;
			virtual sophis::instrument::eUnrealizedMethodType GetUnrealizedMethod() const;

			virtual bool HasFairValue() const;

			/** Get the fair value of the future
			  * If the Future does not really exists, we interpolate the theoretical value of two Futures
			  * which have the clostest delivery dates before and after the input argument
			  * @param quotationDate : a forward date for which we want the Future value. Has only impact for multicurrency Futures (fx forward).
			  *                        default value is 0, which means the FX will be CSRMultiCurrencyFuture::GetSettlementForex()
			  * @param useSpotForVolatility : method will internally call 'GetSpotForVolatility' method of the context instead of GetTheoreticalValue()
			  */

			struct SSLMETheoreticalValueExplanation
			{
				long	nFutureCode1;
				double	dFactor1;
				double  dFutPrice1;
				long	nFutureCode2;
				double	dFactor2;
				double  dFutPrice2;
				double	dForwardForex;
				SSLMETheoreticalValueExplanation()
				{ 
					memset(this,0,sizeof(SSLMETheoreticalValueExplanation));
				};
			};
	
			virtual double	GetFutureTheoreticalValue(const market_data::CSRMarketData	&context,	
													  double				deliveryDate, 
													  long					currency,
													  bool					useSpotForVolatility,
													  double				quotationDate,
													  SSLMETheoreticalValueExplanation* aExplanation = NULL) const;

			/**
			 * returns the actual expiry, delivery and deferred fixing dates of the Future, for a given currency.
			 *
			 * If the Future does not exists, returns dates according to the default date rule
			 * which is implemented in GetDefaultFutureDeliveryDate() and others.
			 *
			 */
			virtual long	GetFutureExpiryDate(long deliveryDate, long currency) const;
			virtual long	GetFutureSettlementDate(long expiryDate, long currency) const;
			virtual long	GetFutureDeliveryDate(long expiryDate, long currency) const;
			virtual long	GetFutureDeferredFixingDate(long expiryDate, long currency) const;

			virtual long	GetDefaultFutureExpiryDate(long deliveryDate, long currency) const;

			/**
			 * returns true when the future retrieved from gApplicationContext needs to be refreshed.
			 */
			virtual bool IsToBeRebuilt() const;


			/**
			 * returns at date dateRef the available prompt dates on the market between
			 * startDate and endDate.
			 */
			virtual void GetAvailableDates(long dateRef, long startDate, long endDate, _STL::vector<long>& availableDates) const;

			
			/**
			 * returns all the possible prompt dates on the market between
			 * startDate and endDate. Overloaded the function if needed but call GetBufferisedPromptDates
			 * for optimizing purposes (GetBufferisedPromptDates bufferises the results).
			 */
			virtual void GetPromptDates(long startDate, long endDate, _STL::vector<long>& promptDates, long currency) const;

			/**
			 * returns all the possible quotation dates on the market between
			 * startDate and endDate.Overloaded the function if needed but call GetBufferisedQuotationDates
			 * for optimizing purposes (GetBufferisedQuotationDates bufferises the results).
			 */
			virtual void GetQuotationDates(long startDate, long endDate, _STL::vector<long>& quotationDates) const;

			/**
			 * calls GetPromptDates (if the result not in the buffer) and bufferizes the results
			 * this function is virtual only for link purposes. Overload GetPromptDates
			 * and use GetBufferisedPromptDates. 
			 */
			virtual void GetBufferisedPromptDates(long startDate, long endDate, _STL::vector<long>& promptDates, long currency) const;

			/**
			 * calls GetQuotationDates (if the result not in the buffer) and bufferizes the results
			 * this function is virtual only for link purposes. Overload GetQuotationDates
			 * and use GetBufferisedQuotationDates. 
			 */
			virtual void GetBufferisedQuotationDates(long startDate, long endDate, _STL::vector<long>& quotationDates) const;

			/**
			 * returns the prompt date corresponding to a sliding maturity.
			 * This method is implemented by default for "n days" and "3 month".
			 * Outside of this implementation it returns false.
			 */
			virtual bool GetFixedMaturity(long dateRef, const static_data::SSMaturity& mat, long& fixedMat, long currency, static_data::eHolidayAdjustmentType adjustment) const;

			/*
			 * Sets substitution date to first prompt date equal or after "date"
			 * returns false if no replacement was found.
			 *
			 * Default implementation is to return falso if no prompt date was found 60 days after "date".
			 * It uses GetBufferisedPromptDates to have the list of prompt dates starting at "date".
			 */
			virtual bool GetSubstitutionDate(long date, long& substitutionDate, long currency) const;


			/**
			 * Checks if a future exists for the given expiry date and currency.
			 */
			bool IsExistingMaturity(long expiryDate, long currency) const;


			/**
			 * Checks if a future exists for the given delivery date and currency.
			 */
			bool IsExistingDelivery(long deliveryDate, long currency) const;
			/**
			 * Gives back fFutureCode as a constant pointer (must not be deleted).
			 * This container gathers the whole range of Futures in the database whose expiry>today-preference.
			 */
			const CSRBufferCode<long>* GetContainerAllFutures(long currency) const;

			/**
			 * Gives back fInterpolationCode as a constant pointer (must not be deleted).
			 * This container gathers the whole range of Futures for interpolation 
			 * (columns (Dates_commodity_reference,commodity_reference)).
			 */
			const CSRBufferCode<_STL::pair<long,double> >* GetContainerInterpolationFuture() const;
			
			/**
			 * Gives back fVegaCode as a constant pointer (must not be deleted).
			 * This container gathers the whole range of Futures for interpolation 
			 * (columns (Vega_Dates_commodity_reference)).
			 */
			const CSRBufferCode<long>* GetContainerVegaFuture() const;

			/**
			 * Gives back fVegaCode as a constant pointer (must not be deleted).
			 * This container gathers the whole range of Futures for interpolation 
			 * (columns (Risk_Dates_commodity_reference)).
			 */
			const CSRBufferCode<long>* GetContainerDeltaGammaFuture() const;
			
			/**
			 * Gives the interpolation value from a delivery date.
			 */
			double GetInterpolationValue(long deliveryDate) const;

			/**
			 * Gives the interpolation values from a delivery date.
			 * Called by CSRCommodityLME::GetInterpolationValue.
			 */
			virtual void GetInterpolationValues(long deliveryDate, SSInterpolationValues &value1, SSInterpolationValues &value2) const;


			/**
			 * Gives the Risk values from an expiry date.
			 */
			virtual void GetRiskValues(long expiryDate, SSInterpolationValues &value1, SSInterpolationValues &value2) const;

			/**
			 * Gives the Risk values from an expiry date and future risk sources.
			 * Called by CSRCommodityLME::GetRiskValues.
			 */
			virtual void GetStandardRiskValues(	const CSRBufferCode<long>*, 
												long expiryDate, 
												bool onExpiry,
												SSInterpolationValues &value1, 
												SSInterpolationValues &value2) const;

			/**
			 * returns the code of the two Futures whose expiry dates are before and after the input parameter date
			 * 
			 * the date of the two futures are such that expiry_date(code1) <= date < expiry_date(code2)
			 * if the first Future expires exactly at 'date', then code2 is set to NULL.
			 * if no Future is found which expires before (resp. after) date, then code1 (resp. code2) is set to NULL
			 *
			 */

			void GetBoundaries(double date, long& code1, long& code2) const;

			/*
			 * returns the correlation between the Future expiring at 'expiryDate'
			 * and the Forex 'currency1/currency2' during the period between start date and end date
			 *
			 * This method works for all expiry dates.
			 * If the Future at expiry date does not exist or is not a Vega Future (the list of Vega Futures is defined in the Worksheet),
			 * we obtain the result by interpolation of the closest Vega Futures.
			 */
			virtual double GetFutureCorrelation(double					expiryDate,
												const market_data::CSRMarketData&	context,
												long 					currency1,
												long 					currency2,
												double 					startDate, 
												double 					endDate) const;

			/**
			*
			*/

			// This method, when use with GetCommodityLMECount() can be used to iterate over all known LME commodities
			static	long	GetNthCommodityLME(int i);

			// This method is used during Worksheet scenario
			// It set, for all Vega Futures of LME commodities, the Pivot value to the fixing value (past spot) of the Future
			static	void	StoreDBValuesAsPivot() { }; // DEPRECATED
			static	void	StoreDBValuesAsPivot(_STL::map<long, bool> &commoditiesList, long fixingCode);

			


			
			
			
			
			
			//
			// ======== ========
			//
			// These method below are inherited from CSRCommodity
			//
			// Only specific issues are documented here.
			// Please see SphInc/commodity/SphCommodity.h for common documentation

			virtual void	FillFutureList();
			virtual void	ResetFutureList();
			virtual long	GetFutureCode(int month, int year, int index) const;
			virtual long	GetFutureCodeDeltaGamma(int month, int year, int index) const;
			virtual long	GetFutureCodeVega(int month, int year, int index) const;
			virtual eCommodityListType GetInstrumentListType() const;
			virtual static_data::CSRCalendar* NewCSRCalendar() const;
			/**
			 * returns the default expiry, delivery, settlement and deferred fixing dates from a maturity date.
			 */
			virtual long	GetDefaultFutureSettlementDate(long expiryDate, long currency) const;
			virtual long	GetDefaultFutureDeliveryDate(long expiryDate, long currency) const;
			virtual long	GetDefaultFutureDeferredFixingDate(long expiryDate, long currency) const;

			/**
			 * finds the expiry of the 'current' future for this commodity
			 */
			virtual long GetFutureExpiryByQuotationDate(long quotationDate, const static_data::SSMaturity &maturity, long currency, static_data::eHolidayAdjustmentType adjustement) const;

			/**
			 * To give back the name of Futures.
			 */
			virtual void GetFutureDefaultNames(const SSDefaultValues& defaultValues, char* reference, char* name) const;

			/**
			 * To finalize the reference name of a Future (if the reference is already existing).
			 */
			virtual void GetFinalReference(char* reference, STRING_SET& setRef, bool isCurrency) const;

			/**
			 * Checks if futures may be created from the worksheet.
			 */
			virtual bool CanCreateDailyFuture() const;

			/**
			 * in the worksheet called by commodity before reading any zones of prices
			 */
			virtual void BeginWorksheetComputations(int whichPairing);

			/**
			 * callback function called at the end of update of the commodity by the worksheet.
			 */
			virtual void EndWorksheetComputations();

			/**
			 * retrieve the future code for a given expiry date and a given currency 
			 * from the future containers.
			 */
			virtual long GetFutureCodeByExpiry(long expiryDate, long currency) const;

			/**
			 * retrieve the future code for a given delivery date and a given currency 
			 * from the future containers.
			 */
			virtual long GetFutureCodeByDelivery(long deliveryDate, long currency) const;

			virtual CSRCommodity::eWorksheetType GetWorksheetType(int whichPairing) const;

			/**
			 * store the results from the worksheet.
			 */
			virtual void StoreWorksheetResults(long code, double value, int whichPairing) const;

			/**
			 * gives the number of paired zone to read and to pair
			 */
			virtual int GetWorksheetPairingCount() const;

			/**
			 * gives the name of the supplementary zone to read and to pair
			 * @param which ranges from 1 to GetOtherWorksheetPairingCount()-1
			 */
			virtual void GetWorksheetPairingName(_STL::string& columnName1, _STL::string& columnName2, int which) const;

			/** 
			 * this method tells if the future type is available.
			 */
			virtual bool IsFutureAvailable(_STL::string &errorMessage) const;	

			/**
			 * send message to refresh the commodity from the list.
			 */
			virtual void RefreshFutureList(_STL::vector<SSFutureCode>& futureVector) const;

			/**
			 * send message when creating a daily future with a given expiry.
			 * this method assumes the commodity is not changed in its parameterisation
			 */
			virtual void RefreshOneFuture(SSFutureCode& futureCode) const;

			virtual bool GetInterpolationValuesForDeltaGamma(long deliveryDate, SSInterpolationValues& value1, SSInterpolationValues& value2) const;
			virtual bool GetInterpolationValuesForVega(long deliveryDate, SSInterpolationValues& value1, SSInterpolationValues& value2) const;

			/**
			 * Gives back the expiry for listed market underlyings.
			 */
			virtual const CSRBufferCode<long>* GetListedOptionExpiry() const;

			/**
			 * Gives the Vega values from an expiry date.
			 */
			void GetVegaValues(long expiryDate, SSInterpolationValues &value1, SSInterpolationValues &value2) const;

			/*
			* Returns the Volatility of a Future that is identified by its expiry date
			*
			* expiryDate          : identifies the Future.
			*                       If no Future has the exact expiryDate, 0 is returned.
			* currency            : the currency in which we want the volatility
			*                       If the Future currency is different, the Forex volatility will be included in the computation
			* sensitivity         : Sensitivity of the result with respect to the Future volatility
			*                       note it is always 1.0 if currency is the currency of the Future
			*
			* (...)               : See CSRMarketData::GetVolat(...) for details about other parameters which are not specific to Commodities
			*
			*
			*
			* RETURN : the volatility of the Future, in the currency given as argument
			*          0.0 if no Future has been found with the expiry date given as argument
			*/
			virtual double GetFutureVolatility(double						expiryDate,
											   long							currency,
											   double 						startDate,
											   double						endDate,		
											   double 						strike,
											   NSREnums::eVolatilityType	volatilityType,
											   Boolean 						put,
											   const market_data::CSRMarketData			&context,
											   double						*sensitivity = 0) const;


			static	int		GetCommodityLMECount();

			virtual bool	GetCommodityData(sophis::tools::CSRArchive & archive) const;
			virtual void	SetCommodityData(const sophis::tools::CSRArchive & archive);
			virtual void	ResetAfterFixingModification() const;
			virtual bool	GetClosedValue(double& value,const market_data::CSRMarketData &context, long fixingTag) const;


			//
			// ======== ========
			//
			// These method below are inherited from CSRInstrument
			//
			// Only specific issues are documented here.
			// Please see SphInc/instrument/SphIntrument.h for common documentation

			virtual double	GetDerivativeSpot(const market_data::CSRMarketData &context) const;
			virtual instrument::CSRInstrument * CreateFutureInstance(long future_code, long settlement_date, instrument::eForwardContractType forwardContractType) const;

			/** Duplates the satellite of DTitre.
			This method is for internal use when cloning.
			@since 4.6
			*/
			virtual void	DuplicateData(const instrument::CSRInstrument &instrument);	// internal

			virtual eCommodityType GetCommodityType() const;

			virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;

			//===since 5.3.6================================================
			// LME without WS
			//==============================================================
			bool IsEmbeddedLMERulesUsed() const;
			long GetYesterdayFixingDate() const;

			struct SSFutureCreationParameter : public SSDefaultValues
			{
				char sReferenceFuture[256];
				char sNameFuture[256];
			};

			virtual short GetMaxMaturityInMonths() const;
			virtual bool IsExceptionDate(long inDate, long &outReplacementDate) const;

			virtual void GetDailyDeliveryDates(_STL::set<long> &outLMEDailyDeliveryDates) const;
			virtual void GetWeeklyDeliveryDates(_STL::set<long> &outLMEWeeklyDeliveryDates) const;
			virtual void GetMonthlyDeliveryDates(_STL::set<long> &outLMEMonthlyDeliveryDates) const;

			/* Future Prices */
			virtual void GetInterpolationDates(_STL::set<long> &outInterpolationDates) const;

			/* Delta/Gamma Risk Sources */
			virtual void GetDeltaGammaDeliveryDates(_STL::set<long> &outDeltaGammaDeliveryDates) const;

			/* Vega Risk Sources */
			virtual void GetVegaDeliveryDates(_STL::set<long> &outVegaDeliveryDates) const;

			/* TAPO Maturities */
			virtual void GetTAPOsDeliveryDates(_STL::set<long> &outTAPOsDeliveryDates) const;

			virtual void GetDatesForLMECards(_STL::set<long> &outLMECardsDates) const;

			virtual long GetGoodFridayDate(long nYear) const;
			virtual void GetLMEDeliveryCalendar(sophis::static_data::CSRListOfCalendars& outLMECalendar, long nCurrency=0) const;
			virtual void GenerateFutures() const; 
			virtual void LoadEmbeddedRules() const;
			virtual void StoreTheoreticalValues(const _STL::map<long/*Future Code*/,double/*Theoretical Value*/>& mapTheoByFuture) const; 
			virtual long GetCodeOfInstrumentForSpreadCurve() const;
			virtual void SetCodeOfInstrumentForSpreadCurve(long nInstrumentCode) const;
			virtual bool GetUseSpreadCurve() const;
			virtual void SetUseSpreadCurve(bool bUseSpreadCurve) const;
			virtual long GetFixingTypeForPriceCurve() const;
			virtual void SetFixingTypeForPriceCurve(long nFixingType) const;
			virtual bool IsFuturesAutogenerationEnabled() const;

			double GetMasterAdjustementSpread() const;
			void SetMasterAdjustementSpread(double dMasterAdjustmentSpread) const;
			virtual static_data::CSRCalendar* GetLMEFixingCalendar() const;
			//====================================================================
			// End of LME without WS
			//====================================================================
		protected:

			/* Create Future */
			virtual void CreateFutures(const _STL::vector<SSFutureCreationParameter> &creationList /* returns results ? */);

			/**
			Clones an existing LME commodity to allow modification.
			@return	a pointer to the cloned instance.
			*/
			virtual instrument::CSRInstrument * Clone() const;
			
			double	GetVolatilityForVega(double						expiryDate,
										 double 					startDate,
										 double						endDate,		
										 double 					strike,
										 NSREnums::eVolatilityType	volatilityType,
										 Boolean 					put,
										 const market_data::CSRMarketData		&context) const;

			double	GetCorrelationForCrossedVega(double					expiryDate,
												 const market_data::CSRMarketData&	context,
												 long 					currency1,
												 long 					currency2,
												 double 				startDate, 
												 double 				endDate) const;

			void	FlushCommodityDeltaGamma();

		    /**
		    * This list of codes of all the futures available in all the currencies
		    * on the commodity (with dates greater or equal to today-preference)
			* the currency is the key of the map.
		    * key (expiry date), value(future code)
		    */
			mutable _STL::map<long, CSRBufferCode<long> >	fFutureCode;
			/**
			* Container containing only quoted Future Prices (column "Commodity_Reference").
			* key (expiry date), value.first(future code), value.second (future value).
			*/
			mutable CSRBufferCode<_STL::pair<long,double> >	fInterpolationCode;
			
			/**
			* Container containing only Future Vega (column "Vega_Dates_Commodity_Reference").
			* key (expiry date), value(future code)
			*/
			mutable CSRBufferCode<long>						fVegaCode;

			/**
			* Container containing only Future Delta/Gamma (column "Risk_Dates_Commodity_Reference").
			* key (expiry date), value(future code)
			*/
			mutable CSRBufferCode<long>						fDeltaGammaCode;

			/**
			* Container containing only Future underlying of listed options
			* key (expiry date), value(future code)
			*/
			mutable CSRBufferCode<long>						fListeOptionExpiry;

			mutable bool									fToBeRebuilt;
			mutable	bool									fFillRiskCode;
		private:
			mutable double									fMasterAdjustmentSpread;

			mutable _STL::map<long, CSRBufferCodeElement<long> > fBufferPromptDates;
			mutable CSRBufferCodeElement<long>				fBufferQuotationDates;

			long	GetFutureCode (	CSRInstrument::eFutureConventionName	type,
									const CSRBufferCode<long>*				buffer,
									int										month, 
									int										year, 
									int										index) const;
			mutable CSRBufferCode<long> fLMECardDeliveryDate;
			mutable long				fLME3mDate;

		public:
			const CSRBufferCode<long>* GetContainerLMECard() const;

			/*
			 * GetLME3mDate
			 * Return the 3m date
			 * By default it returns the 3m date for today
			 * But the method can also be used to return the 3m date corresponding to any starting date
			 *
			 */
			long	GetLME3mDate(long customTodayDate = 0) const;



		public:
			virtual double GetFutureVolatility(
													const market_data::CSRMarketData			&context,
													long							futureCode,
													long							currency,
													double 						startDate,
													double						endDate,		
													double 						strike,
													NSREnums::eVolatilityType	volatilityType,
													Boolean 						put,
													double						*sensitivity = 0) const;

			void ResetPromptAndQuotationDateBuffers() const;
		protected:
			mutable double fMasterReferenceYesterday;
		};

		/*
		 *
		 * ==== ==== ============================== ==== ====
		 * ==== ==== ====    CSRVolatilityLME  ==== ==== ====
		 * ==== ==== ============================== ==== ====
		 *
		 */

		class SOPHIS_COMMODITY CSRVolatilityLME : public virtual sophis::market_data::CSRVolatility
		{
			DECLARATION_VOLATILITY(CSRVolatilityLME)
			
		public:
			virtual double	GetMoneynessLevel(double maturity) const;
			void			SetMarketDataForMoneyness(market_data::CSRMarketData* marketData) const;
			void			ReleaseMarketDataForMoneyness() const;
			static double	GetPivotPriceForFuture(long code, const market_data::CSRMarketData& context);

		protected:
			const market_data::CSRMarketData* GetMarketDataForMoneyness() const;

		private:
			mutable market_data::CSRMarketData*	fMarketDataForMoneyness;
			bool			fValidVolatility;
			mutable int		fMarketDataCount;

		};
	};
};

SPH_EPILOG



#endif
