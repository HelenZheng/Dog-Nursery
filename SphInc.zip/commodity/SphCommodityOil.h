/*
 	File:		SphCommodityOil.h
 
 	Contains:	Class for the handling of a commodity oil.
 
 	Copyright:	� 2001-2004 Sophis.
*/

#ifndef __SPHCOMMODITY_OIL_H__
#define __SPHCOMMODITY_OIL_H__


#include "SphCommodity.h"

SPH_PROLOG
namespace	sophis	
{
	namespace instrument
	{
		class CSROption;
	}

	namespace commodity	
	{

		class SOPHIS_COMMODITY CSRCommodityStandard : public virtual CSRCommodity, public virtual ISROilOrLMEInterface	
		{
			
		public:
			DECLARATION_COMMODITY(CSRCommodityStandard)			

			protected :

				/** Used by a constructor to initialize an object.
				This is for internal use only.
				*/
				void Initialize(const DTitrePlus *instrument, bool doInitRecomputeAll);

			public:
				CSRCommodityStandard(const DTitrePlus *titre, bool doInitRecomputeAll);
				virtual ~CSRCommodityStandard();

				virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const OVERRIDE;

				virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
				virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);
				virtual void FillFutureList();
				virtual const CSRCommodity::ListedFutureList* GetFutureList() const;
				virtual void DuplicateData(const instrument::CSRInstrument &instrument);
				virtual const CSRBufferCode<long>* GetListedOptionExpiry() const;
				virtual long GetFutureCode(int month, int year, int index) const;
				virtual double	GetDerivativeSpot(const market_data::CSRMarketData&context) const;
				virtual instrument::CSRInstrument * Clone() const;

				/**
				* This method gives the underlying (for delta of an option of this instrument is an underlying)
				*/
				//virtual void	GetDeltaUnderlying(const instrument::CSROption& option, _STL::set<long>& codeList, int whichUnderlying) const;

				/**
				* This method gives the underlying (for rho of an option of this instrument is an underlying)
				*/
				//virtual void	GetRhoUnderlying(const instrument::CSROption& option, _STL::set<long>& codeList, int whichUnderlying) const;


				/** Get the futures risk sources.
				* For LME, the risk sources are different from the future list for swap.
				* @return a FuturesRiskSources .
				* By default, call GetFutureList in case of an update to do and return fRiskCode which is initialized as GetFutureList().
				* @since 4.6
				 */
				virtual const FuturesRiskSources* GetFutureRiskSources() const;
				const CSRCommodity::ListedFuture* GetFuture(int month, int year, int index) const;
				const CSRCommodity::ListedFuture* GetLastFutureOfMonth(int month, int year) const;

				/**
				* tells if the dates are to be taken like expiry or delivery dates 
				* or if the future is directly identified by its code (ewstPower)
				*/
				virtual CSRCommodity::eWorksheetType GetWorksheetType(int whichPairing) const;
				virtual void	GetVegaValues(long expiryDate, SSInterpolationValues &value1, SSInterpolationValues &value2) const;
				virtual double GetFutureVolatility(
													const market_data::CSRMarketData			&context,
													long							futureCode,
													long							currency,
													double 						startDate,
													double						endDate,		
													double 						strike,
													NSREnums::eVolatilityType	volatilityType,
													Boolean 						put,
													double						*sensitivity = 0) const;
				virtual double GetFutureVolatility(double						expiryDate,
													long							currency,
													double 						startDate,
													double						endDate,		
													double 						strike,
													NSREnums::eVolatilityType	volatilityType,
													Boolean 						put,
													const market_data::CSRMarketData			&context,
													double						*sensitivity = 0) const;

				virtual long GetFutureCodeByDelivery(long deliveryDate, long currency) const;
				virtual long GetFutureCodeByExpiry(long expiryDate, long currency) const;
				virtual bool GetClosedValue(double& value,const market_data::CSRMarketData &context, long fixingTag) const;

				/**
				* Checks if futures may be created from the worksheet.
				*/

				virtual bool CanCreateDailyFuture() const;

				virtual eCommodityType GetCommodityType() const;		

				virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;

				long	GetNearByFutureCode(long date) const;
				long	GetNearByFutureCodeForListedMarket(long date) const;

				virtual void RefreshFutureList(_STL::vector<SSFutureCode>& futureVector) const;
				void ResetFutureList() const { fFillIndexFutureList = true; };
				virtual bool HasAFormulaForSpot() const;

			private:
				mutable bool				fFillIndexFutureList;	//mutable to fill the index with Future instrument definition
				mutable ListedFutureList	fFutureList;			//mutable to fill the index with Future instrument definition
		};

	}
}

SPH_EPILOG


#endif