/*
File:		SphCommodityPower.h

Contains:	Class for the handling of a Power commodity

Copyright:	� 2005 Sophis.
*/

#ifndef __SPHCOMMODITYPOWER_H__
#define __SPHCOMMODITYPOWER_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"

#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/misc/SphGlobalFunctions.h"
#include "SphInc/commodity/SphCommoditySwapLeg.h"
#include "SphInc/instrument/SphSwap.h" 
#include "SphInc\commodity\SphPowerDaylightSavingTime.h"

#include __STL_INCLUDE_PATH(set)


SPH_PROLOG

#define NB_OF_PERIODS_IN_A_DAY 25

struct SOPHIS_COMMODITY SSDailyFixingInfo {
	long							fDate;
	_STL::map<_STL::string, double>	fData;
	_STL::map<_STL::string, double>	fDataWeight;
	double							fCouponValue;
	bool							bHasScheduling;
	SSDailyFixingInfo();
};

namespace sophis {
	namespace instrument
	{
		class CSRSwap;
	}
	namespace commodity {

		/*
		*
		* ==== ==== ============================== ==== ====
		* ==== ==== ====    CSRCommodityPower  ==== ==== ====
		* ==== ==== ============================== ==== ====
		*
		*/

		class CSRDeliveryPeriod;
		class CSRDeliveryLoad;
		class CSRNonStandardDeliveryPeriod;
		class CSRNonStandardDeliveryProfile;
		class CSRHourlyDeliveryPeriod;
		class CSRPowerFuture;

		/* Class HourlyDataFrequency
		 *
		 * This call contains an enum and static method to manipulate the different type of "hourly" periods in Power deliveries.
		 * The "hourly" period may represent 1 hour, 30 minutes, 15 minutes, 10 minutes
		 *
		 */

		class SOPHIS_COMMODITY HourlyDataFrequency
		{
		public :
			enum eHDGFreq
			{		
				HDG_Undefined		= 0,
				HDG_EachHour		= 1,
				HDG_EachHalfHour    = 2,
				HDG_EachQuarterHour = 3,
				HDG_EachTenMinutes	= 4
			};

			static eHDGFreq FreqIntegerToFreqEnum(int freqint)
			{
				if(freqint == 2)
					return HDG_EachHalfHour;
				else if(freqint == 4)
					return HDG_EachQuarterHour;
				else if(freqint == 6)
					return HDG_EachTenMinutes;
				else
					return HDG_EachHour;
			}

			static int FreqEnumToFreqInteger(eHDGFreq freq)
			{
				if(freq == HDG_EachHalfHour)
					return 2;
				else if(freq == HDG_EachQuarterHour)
					return 4;
				else if(freq == HDG_EachTenMinutes)
					return 6;
				else
					return 1;
			}

			static const bool IsFreqIntegerAndFreqIndexValid(int freqint,int freqindex)
			{
				if( freqindex <= freqint && (freqint == 2 || freqint == 4 || freqint == 6) &&  freqindex > 0)
					return true;
				return false;
			}		

			static const int MaxFreqInt = 6;
		};

		/* SSPowerHourlyProfile
		* An hourly profile is a set of coefficients which can be used to compute the unit price of a specific hour given the average price for that day
		* Consider:
		*   'h' some hour of the day
		*   'Loads' the list of possible delivery loads for the day 'h'
		* Then,
		*   HOUR_PRICE(h) = Sum[forall 'L' in 'Loads] ( COEF[h,l] * DAILY_AVG_PRICE[d,L] )
		*
		*/

		struct SOPHIS_COMMODITY SSPowerHourlyProfileCoefficient
		{
			_STL::vector<double>	fValues;
			double GetValue(size_t h) { if (h<fValues.size()) return fValues[h]; else return 0.; };
		};

		struct SOPHIS_COMMODITY SSPowerHourlyProfile
		{
			_STL::map<_STL::string, SSPowerHourlyProfileCoefficient>	fCoefficients;
		};
		/* SSPowerFutureHourlyProfileList
		 * The list contains hourly profiles for different type of day (e.g. working days, saturdays, sundays, ...)
		 * The types of day a identified by the index (from 0 to fList.size()) and the mapping between name<=>index is defined in the worksheet for each commodity
		 *
		 */
		struct SOPHIS_COMMODITY SSPowerFutureHourlyProfileList
		{
			_STL::vector<SSPowerHourlyProfile>	fList;
		};

		/* SSAllPowerFutureCurves
		 * Contains
		 *    - fNames             : the mapping between day types index (see above) and their name (e.g. "Saturdays")
		 *    - fCurves            : the mapping between a power instrument (CSRFuture) representing a standard contract and the set of curves that is associated to it (the hourly profiles for the different types of days)
		 *    - fCurveNamesRefZone : (internal use) when loading worksheets, the different zones for set of curves should use the same names for day types. This string store the name of one of the zones, which will be the reference for day type names.
		 */
		struct SOPHIS_COMMODITY SSAllPowerFutureCurves
		{
			_STL::vector<_STL::string>						fNames;
			_STL::map<long, SSPowerFutureHourlyProfileList> fCurves;
			_STL::string									fCurveNamesRefZone;
		};

		struct SOPHIS_COMMODITY SSPeriodsByDayAheadId
		{
			short fDayAheadId;
			_STL::string fPeriodName;

			SSPeriodsByDayAheadId(short aDayAheadId, _STL::string sPeriodName): fDayAheadId(aDayAheadId), fPeriodName(sPeriodName)
			{

			}

			bool operator < (const SSPeriodsByDayAheadId& X) const 
			{
				if(fDayAheadId < X.fDayAheadId)
					return true;

				if(fDayAheadId > X.fDayAheadId)
					return false;

				return (fPeriodName.compare(X.fPeriodName)<0 );
			}
		};


		struct SOPHIS_COMMODITY SSPeriodsByOldSwapId
		{
			long fSwapId;
			_STL::string fPeriodName;

			SSPeriodsByOldSwapId(long aOldSwapId, _STL::string sPeriodName): fSwapId(aOldSwapId), fPeriodName(sPeriodName)
			{

			}

			bool operator < (const SSPeriodsByOldSwapId& X) const 
			{
				if(fSwapId < X.fSwapId)
					return true;

				if(fSwapId > X.fSwapId)
					return false;

				return (fPeriodName.compare(X.fPeriodName)<0 );  // A.compare(B) return -1 if A < B 
			}
		};


		struct SOPHIS_COMMODITY SSPeriodAndLoad
		{
			long	fPeriodIdent;			
			long	fLoadIdent;
			SSPeriodAndLoad(): fPeriodIdent(0), fLoadIdent(0)
			{

			}
			SSPeriodAndLoad(long periodIdent, long loadIdent): fPeriodIdent(periodIdent), fLoadIdent(loadIdent)
			{

			}					
			bool operator == (const SSPeriodAndLoad& X) const 
			{
				return (fPeriodIdent == X.fPeriodIdent && fLoadIdent == X.fLoadIdent); 					
			}			
		};
		class SOPHIS_COMMODITY CSRCommodityPower : public virtual CSRCommodity	
		{
			enum eWorksheetPairing
			{
				ewpPowerPrice	= 0,
				ewpPowerListedOption,
				ewpPowerProfile,
				ewpPowerTAPOs,
			};

		public:
			DECLARATION_COMMODITY(CSRCommodityPower)

		public:

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			virtual void DescribeGranularity(sophis::tools::dataModel::DataSet & data_set) const;
			virtual void UpdateGranularity(const sophis::tools::dataModel::DataSet &dataSet, SSCommodityInstrument *p);

			/* Create a future on the commodity
			*  representing a standard contract (CSRFuture) for delivering the commodity
			*  according to the delivery period and delivery load parameters
			*  If the future already exists, the creation is skipped, the existing future code is returned, and bAlreadyExists is true.
			*  parameter defaultValues is the default values of the future when created from the GUI
			*  parameter futureName is the name of the future when created from the GUI
			*  parameter futureReference is the reference of the future when created from the GUI
			*  If you create future from the worksheet, these three later parameters are NULL
			*  Return true if succeed, otherwise false.
			*/
			virtual bool createFuture(const char *modelName, const CSRDeliveryPeriod *dPeriod, const CSRDeliveryLoad *dLoad,long& outFutureCode, bool& bAlreadyExists, SSDefaultValues* defaultValues = NULL, const char* futureName = NULL, const char* futureReference = NULL) const;

			/*	Finds the instrument code of the instrument
			 *  representing a standard contract (CSRFuture) for delivering the commodity
			 *  according to the delivery period and delivery load parameters
			 *  Returns 0 when not found
			 */
			virtual long findFuture(const CSRDeliveryPeriod *dPeriod, const CSRDeliveryLoad *dLoad) const;

			/* Finds the instrument code of the instrument representing a standard contract for delivering the specified month/year according to the input delivery load
			 */
			long GetGoverningMonthlyFuture(int year, int month, const CSRDeliveryLoad& dLoad)const;

			static const CSRDeliveryPeriod* GetPeriod(long commoCode, const char* periodName, const struct SwapInfosForNonStandardProfile *swapInfos=NULL, const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL);
			static const CSRDeliveryPeriod* GetPeriod(const CSRCommodityPower *pow, const char* periodName, const struct SwapInfosForNonStandardProfile *swapInfos=NULL, const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL);

			virtual void DeletePeriod(const char *periodName);

			/* Gives a pointer to the object representing a delivery load, identified by it's name
			 */
			virtual const CSRDeliveryLoad*   GetLoad(const char* loadName) const;
			static const CSRDeliveryLoad*    GetLoad(long commoCode, const char* loadName);
			static const CSRDeliveryLoad*    GetLoad(const CSRCommodityPower *pow, const char* loadName);


			/* Returns the monthly period containing a given day depending on the commodity calendar
			 * For example, the monthly period for 1/1/2005 is in general "Jan 2005", but it is "Dec 2004" according to PowerUK calendar
			 * @param day
			 * @return the monthly period containing the day
			 */

			virtual const CSRDeliveryPeriod* GetMonthPeriod(long day) const;

			/* This method returns the last day of trade for the input delivery date
			 * This is used to obtain the exercise date each flow of a strip of options according to the first delivery day of the flow
			 */
			virtual long GetLastDayOfTrade(long delivery_date) const
			{ return delivery_date-1; }

			/* Returns the type of hourly granularity that is defined for the commodity
			 * (hourly, 30min, 15min, ...)
			 */
			virtual HourlyDataFrequency::eHDGFreq GetHourlyProfileFrequency() const;

			/* Returns the number of periods within 1 hour according to the granularity in GetHourlyProfileFrequency()
			 * For example GetGranularity() returns 4.0 when the granularity is 15min.
			 */
			virtual int GetGranularity() const;

			/* Returns the time zone, which is the offset with respect to GMT
			*/
			virtual short GetTimeZone(void) const;


			/* --- The method below are used for management of instruments and data related to the Power&Gas commodities ---
			 * --- This includes creation of instruments from worksheets, DB and RT management of instrument lists
			 */

			/* Returns the number of Power&Gas instruments which have a price in worksheet and hence are the delta risk sources
			 */
			int GetNumberOfRiskSources() const {return (int)fPowerPrices.size();}

			/* (internal use)
			 * Returns the string that is internally used to uniquely identify a Power&Gas CSRFuture instrument
			 */
			static _STL::string FutureString(const CSRDeliveryPeriod *dPeriod, const CSRDeliveryLoad *dLoad);
			
			/* Should be used to attach a CSRFuture instrument is should be attached to the commodity
			 */
			virtual void addFuture(long code, const CSRDeliveryPeriod *dPeriod, const CSRDeliveryLoad *dLoad);
			virtual const _STL::map<_STL::string, long>& getAllFuture() const {return fAllFutures;}

			/* Prepares a name/reference for creating a new instrument representing a standard contract
			 * This method is used by worksheet functions CREATEPOWERFUT and CREATEGASFUT
			 */
			virtual void GetFutureDefaultName(char* reference, char* name, const SSDefaultValues& defaultValues) const;
			virtual long GetDefaultFutureSettlementDate(long expiryDate, long currency) const;

			virtual void DuplicateData(const sophis::instrument::CSRInstrument &instrument);	// internal

			virtual void FillFutureList();

            virtual bool IsFutureAvailable(_STL::string &errorMessage) const;

			virtual const char* GetBulkloadModelName(const char *period, const char *load) const;

			struct SSLocalDouble
			{
				SSLocalDouble(){fValue = 0.;}
				double fValue;
			};

			bool	GetWorkSheetFutureValue(const market_data::CSRMarketData				&context,
				const CSRDeliveryPeriod			&dPeriod, 
				const CSRDeliveryLoad			&dLoad, 
				double							&outValue, 
				_STL::map<long, SSLocalDouble>	&outWeightedDecomposition) const;

			bool	GetFutureProfileDecomposition(	const market_data::CSRMarketData				&context, 
				const CSRDeliveryPeriod			&dPeriod, 
				const CSRDeliveryLoad			&dLoad, 
				_STL::map<long, SSLocalDouble>	&outWeightedDecomposition,
				_STL::vector<SSPeriodAndLoad>	&periodTrack,
				long							beginDecompositionAt = 0,
				long							endDecompositionAt   = 0 ) const;

			/* Used by worksheet processor to store the hourly profile curves
			 */
			virtual void StoreHourlyProfile(long futureCode, const SSPowerFutureHourlyProfileList & hourlyProfile, int whichPairing, const char *zoneName);

			/* Used by worksheet function CHECKNBOFHOURLYCURVES()
			 */
			unsigned int GetNumberOfHourlyProfiles(long futureId) const;

			/**
			* gives the name of the first zone in the worksheet to read from the commodity zone.
			*/
			virtual void GetDefaultWorksheetPairing(_STL::string& columnName) const;
			virtual int GetWorksheetPairingCount() const;
			virtual void BeginWorksheetComputations(int whichPairing);
			virtual CSRCommodity::eWorksheetType GetWorksheetType(int whichPairing) const;
			virtual void GetWorksheetPairingName(_STL::string& columnName1, _STL::string& columnName2, int which) const;
			virtual void StoreWorksheetResults(long code, double value, int whichPairing) const;
			virtual void StoreBulkWorksheetFuture(long code);

			const _STL::map<long, double>& GetPowerFuturePrices() const;
			virtual double GetFutureTheoreticalValue(	const market_data::CSRMarketData	&context, 
				long				futureCode) const;

			virtual void GetHourlyProfileNames(_STL::vector<_STL::string>& outNames) const;
			virtual sophis::instrument::CSROption* new_SwaptionSplitter(sophis::instrument::CSROption* option) const;
			enum eCommoPowerOptionType
			{
				eCommoPowerOptAsian,
				eCommoPowerOptSwaption,
				eCommoPowerOptStrip,
				eCommoPowerOptUnknown
			};

			static eCommoPowerOptionType GetOptionType(const sophis::instrument::CSRSwap* swap,long exerciseDate);
			virtual long ConvertFlowBeginDateToStripOptionExerciseDate(short versementType,const SSPhysicalFutureFlow& flow) const;

			virtual const CSRFixingType* GetFixingType(int fixingOfLeg, int fixingOfOtherLeg) const;
			virtual bool CheckCurveNames(const _STL::vector<_STL::string> &names, const _STL::string &zoneName);


			virtual eCommodityType GetCommodityType() const;

			virtual void GetFutureWindowName(long sicoFuture, char *windowName) const;

			bool	GetProfileDecompositionByWorksheetChildren(	const market_data::CSRMarketData				&context, 
				const CSRDeliveryPeriod			&dPeriod, 
				const CSRDeliveryLoad			&dLoad, 
				_STL::map<long, SSLocalDouble>	&outWeightedDecomposition,
				_STL::vector<SSPeriodAndLoad>	&periodTrack,
				bool							ignoreDPlusZeroIfNotFound = false) const;

			bool WorksheetOnlyUsesMonths(int mm, int yy) const;
			bool CanOptimizeNonStandardProfile(int mm, int yy) const;
			bool CanOptimizeNonStandardProfile(long startDate, long endDate) const;

			static void ClearPeriodCache(void);
			//static void ClearLoadCache(void);

			/** Get the decomposition of the period by the load.
			The decomposition can be made with only the worksheet children.
			
			@param context
			The computation context.
			@param dPeriod
			The delivery period to decompose.
			@param dLoad
			The delivery load used to decompose the delivery period.
			@param outWeightedDecomposition
			Output structure which contains the decomposition.
			@param useOnlyWorksheet
			If true the method uses only the worksheet children periods in the decomposition. Otherwise the decomposition can use parent's periods.
			{ @link CSRPowerFuture::GetProfileDecompositionByWorksheetChildren }

			@return
			True if the period is successfully decomposed. False otherwise.
			
			@see GetFutureProfileDecompositionNoCache

			@version 5.2.2.1
			*/
			virtual bool GetLoadDecomposition(	const market_data::CSRMarketData	&context, 
												const CSRDeliveryPeriod				&dPeriod, 
												const CSRDeliveryLoad				&dLoad, 
												_STL::map<long, SSLocalDouble>		&outWeightedDecomposition,
												bool								useOnlyWorksheetChildren) const;

			virtual long GetDaylightSavingTimeId() const;

			/* Gives a pointer to the object representing a delivery period, identified by it's name
			* The optional parameters are internally used when creating new non-standard delivery profiles attached to CSRSwap instruments
			*/
			virtual const CSRDeliveryPeriod* GetPeriod	(const char* periodName, const struct SwapInfosForNonStandardProfile *swapInfos=NULL, const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL) const;
			/**
			Clones an existing commodity to allow modification.
			@return	a pointer to the cloned instance.
			*/
			virtual instrument::CSRInstrument * Clone() const;

			/*
			First, call the base method EndWorksheetComputations.
			Second, check if the non standard delivery profile computation can be optimized i.e. CanOptimizeNonStandardProfile(...);
			*/
			virtual void EndWorksheetComputations();


			bool	GetFutureProfileDecompositionNoCache(	const market_data::CSRMarketData				&context, 
				const CSRDeliveryPeriod			&dPeriod, 
				const CSRDeliveryLoad			&dLoad, 
				_STL::map<long, SSLocalDouble>	&outWeightedDecomposition,
				_STL::vector<SSPeriodAndLoad>		&periodTrack) const;

			bool	DecomposeNonStandardPeriod(	const market_data::CSRMarketData					&context, 
				const CSRNonStandardDeliveryPeriod	&dPeriod,
				const CSRDeliveryLoad				&dLoad, 
				_STL::map<long, SSLocalDouble>		&outWeightedDecomposition,
				long								beginDecompositionAt,
				long								endDecompositionAt) const;

			bool	DecomposeNonStandardProfile(	const market_data::CSRMarketData					&context, 
				const CSRNonStandardDeliveryProfile	&dPeriod, 
				const CSRDeliveryLoad				&dLoad, 
				_STL::map<long, SSLocalDouble>		&outWeightedDecomposition,
				long								beginDecompositionAt,
				long								endDecompositionAt) const;

			bool GetPeriodCoefficients(	const CSRDeliveryLoad &futureLoad,
										long					day,
										const CSRHourlyDeliveryPeriod * period,
										unsigned int			profileId,
										_STL::map<_STL::string, double>	&outCoefficient) const;

			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;
	protected:
			virtual long GetAncestorWithHourlyCurve(	const CSRDeliveryPeriod				&dPeriod, 
				const CSRDeliveryLoad				&dLoad, _STL::vector<SSPeriodAndLoad>	&periodTrack) const;

		public:	
			virtual CSRDeliveryPeriod * CreatePeriodInstance(const char* periodId,
															 const SwapInfosForNonStandardProfile *swapInfos=NULL,
															 const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL) const;
			virtual CSRDeliveryLoad * CreateLoadInstance(const char* loadName) const;
		protected:

			static _STL::map<SSPeriodsByDayAheadId, CSRDeliveryPeriod*> powerDeliveryPeriodsByIdent;
			//static _STL::map<long, CSRDeliveryPeriod*> powerDeliveryPeriodsByOldSwapId;
			static _STL::map<SSPeriodsByOldSwapId, CSRDeliveryPeriod*> powerDeliveryPeriodsByOldSwapId;

			static _STL::map<SSPeriodsByDayAheadId, CSRDeliveryPeriod*> gasDeliveryPeriodsByIdent;
			//static _STL::map<long, CSRDeliveryPeriod*> gasDeliveryPeriodsByOldSwapId;
			static _STL::map<SSPeriodsByOldSwapId, CSRDeliveryPeriod*> gasDeliveryPeriodsByOldSwapId;

			static _STL::map<SSPeriodsByDayAheadId, CSRDeliveryPeriod*> deliveryPeriodsByIdentUK;
//			static _STL::map<long, CSRDeliveryPeriod*> deliveryPeriodsByOldSwapIdUK;
			static _STL::map<SSPeriodsByOldSwapId, CSRDeliveryPeriod*> deliveryPeriodsByOldSwapIdUK;

			mutable _STL::map<_STL::string, CSRDeliveryLoad*> powerDeliveryLoadsByIdent;
			mutable _STL::map<_STL::string, CSRDeliveryLoad*> gasDeliveryLoadsByIdent;
						

		protected:

			_STL::map<_STL::string, long> fAllFutures;

			bool fNeedFillFutureList;
			_STL::map<long, double> fPowerPrices; // Instruments with prices in worksheet. key = future code, value = future value
			_STL::set<long> fBulkEnabledPrice; // CSRFuture instrument which have been enabled by "bulk-worksheet"
			SSAllPowerFutureCurves fWorksheetHourlyProfile; // key=future code, value=hourly profile
			_STL::set<long> fMonthsWithMonthPrice; // months which have a price and which are not decomposed with sub periods.
			mutable _STL::map< _STL::pair<long, long>, long > fCacheAncestorWithHourlyCurve; // key<period id, load id> ; value : ancestor fut code or 0
			mutable _STL::map< _STL::pair<long, long>, long > fCacheFindFuture; // key: <deliv period string ident, deliv load string ident>; value => long Future code or 0

		public:		
			inline bool IsBulkEnabledPrice(long code) const { return fBulkEnabledPrice.find(code)!=fBulkEnabledPrice.end(); };
		};

		// Multiplies the values of all the elements of a map by a quantity
		void Multiply(_STL::map<long, CSRCommodityPower::SSLocalDouble> &inoutMap, double x);
		// Adds the values of corresponding elements of two maps
		void Add(_STL::map<long, CSRCommodityPower::SSLocalDouble> &inoutMap, const _STL::map<long, CSRCommodityPower::SSLocalDouble> &mapToAdd);
	};
};

SPH_EPILOG

#endif
