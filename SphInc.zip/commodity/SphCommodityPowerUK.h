/*
File:		SphCommodityPower.h

Contains:	Class for the handling of a Power commodity

Copyright:	� 2005 Sophis.
*/

#ifndef __SPHCOMMODITYPOWERUK_H__
#define __SPHCOMMODITYPOWERUK_H__

#include "SphInc/commodity/SphCommodityPower.h"
SPH_PROLOG
namespace sophis {
	namespace commodity {

		/*
		*
		* ==== ==== ================================ ==== ====
		* ==== ==== ====    CSRCommodityPowerUK ==== ==== ====
		* ==== ==== ================================ ==== ====
		*
		*/

  	    class SOPHIS_COMMODITY CSRCommodityPowerUK : public virtual CSRCommodityPower	
		{
			
		public:
			DECLARATION_COMMODITY(CSRCommodityPowerUK)

			//virtual const CSRDeliveryPeriod* GetPeriod	(const char* periodName, struct SwapInfosForNonStandardProfile *swapInfos=NULL) const;
			virtual CSRDeliveryPeriod* CreatePeriodInstance(const char* periodId,
													  const SwapInfosForNonStandardProfile *swapInfos=NULL,
													  const CSRDeliveryPeriod * pSourceDeliveryPeriod=NULL) const;
			const CSRDeliveryPeriod* GetMonthPeriod(long day) const;
			static const char * MODEL_NAME;
		};
	};
};
SPH_EPILOG
#endif
