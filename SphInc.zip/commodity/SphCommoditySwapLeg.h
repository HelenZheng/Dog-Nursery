/*
 	File:		SphCommoditySwapLeg.h
 
 	Contains:	Class for the handling of commodity swap legs
 
 	Copyright:	� 1995-2002 Sophis.
 
*/

#pragma once

#ifndef _SphCommoditySwapLeg_H__
#define _SphCommoditySwapLeg_H__

#include "SphInc/instrument/SphCommodityLeg.h"
SPH_PROLOG
namespace sophis	{
	namespace instrument	{
		class CSRSwap;
		class CSROption;
	}

	namespace commodity	{

		class  SOPHIS_COMMODITY CSRPhysicalFutureLeg : public virtual instrument::CSRLeg
		{
		private:
			CSRPhysicalFutureLeg(jambe *jb, SW_Donne *sw, const sophis::instrument::CSRSwap *swap);
			CSRPhysicalFutureLeg();
			void Initialize(jambe *jb, SW_Donne *sw, const sophis::instrument::CSRSwap *swap);
			friend class instrument::CSRDerivedLegFactory<CSRPhysicalFutureLeg>;

		public:
			/**
			 *	Destructor.
			 */
			 ~CSRPhysicalFutureLeg();

			 const char *GetXMLRootName() const;

			 void GetDescription(sophis::tools::dataModel::DataSet& legDataSet, const sophis::instrument::CSRSwap* pSwap, int iLeg) const;

			 void UpdateFromDescription(const sophis::tools::dataModel::DataSet& legDataSet, sophis::instrument::CSRSwap* pSwap, int iLeg);
			 
			 void UpdateNotionalUnit(const sophis::tools::dataModel::DataSet& legDataSet);
		
			 /**
			 *	Get the commodity fixing
			 *	@since 5.1
			 */
			 virtual long GetCommodityFixing() const;
			 /**
			 *	Set the commodity fixing
			 *	@since 5.1
			 */
			 virtual void SetCommodityFixing(const long value);
			 /**
			 *	Set the commodity fixing
			 *	@param value is the string corresponding to the fixing (i.e: "Last", "Open",...)
			 *	@since 5.1
			 */
			 void SetCommodityFixing(const char *value);

			 /**
			 *	Get the forex fixing
			 *	@since 5.1
			 */
			 virtual long GetForexFixing() const;
			 /**
			 *	Set the forex fixing
			 *	@since 5.1
			 */
			 virtual void SetForexFixing(const long value);

			 /**
			 *	Set the commodity fixing
			 *	@param value is the string corresponding to the fixing (i.e: "Last", "Open",...)
			 *	@since 5.1
			 */
			 void SetForexFixing(const char *value);

			/**
			*	@returns the second start date
			*	@since 5.1
			*/
			virtual long GetSecondStartDate() const;
			/**
			*	Set the second start date
			*	@since 5.1
			*/
			virtual void SetSecondStartDate(const long value);
			/**
			*	@returns the second end date
			*	@since 5.1
			*/
			virtual long GetSecondEndDate() const;
			/**
			*	Set the second end date
			*	@since 5.1
			*/
			virtual void SetSecondEndDate(const long value);

			/**
			*	Accessing method for swap legs.
			*	@return	The payment frequency of the leg.
			*	@see	eSwapPeriodicityType
			*/
			virtual sophis::instrument::eSwapPeriodicityType GetPeriodicityType() const;
			virtual bool GetPeriodicityType(sophis::instrument::eSwapPeriodicityType &value) const;
			/**
			*	Set the payment frequency.
			*	@throws InvalidArgument if type does not belong to eSwapPeriodicityType. 
			*			The following type is not accepted: spIMM
			*	@see	eSwapPeriodicityType
			*	@since 5.1
			*/
			virtual void SetPeriodicityType(sophis::instrument::eSwapPeriodicityType type);

			/**
			* @returns the commodity internal code
			*/
			virtual long GetCommodityCode() const;

			/**
			 *  Set the commodity
			 *	@param value is the commodity internal code
			 *	@throw InvalidArgument if the instrument does not exist
			 *	@since 5.1
			 */
			virtual void SetCommodityCode(const long value);

			/**
			*	Returns the delivery period of the swap, including optional star '*' when non-standard profile is modified.
			*	@returns the delivery period
			*	@since 5.1
			*/
			virtual const char* GetDeliveryPeriodForSimulation() const;
			/**
			*   Returns the delivery period of the swap. This is the persistent value which can be saved.
			*   In simulation mode (GUI, ...), above method might be preferred.
			*	@since 5.1
			*/
			const char* GetDeliveryPeriod(_STL::string &str) const;

			/**
			*	Set the delivery period
			*	@param newPeriod must have at least 33 characters (end of string included)
			*	@throws NullPointerException if newPeriod is NULL
			*	@since 5.1
			*/
			virtual void SetDeliveryPeriod(const char * newPeriod);

			/**
			*	@since 5.1
			*/
			virtual bool IsNonStandardProfile() const;
			/**
			*	@since 5.1
			*/
			virtual void SetNonStandardProfile(bool value);

			/**
			*	@returns the month offset
			*	@since 5.1
			*/
			virtual long GetMonthOffset() const;

			/**
			*	Set the month offset
			*	@param value must be between 0 and 100 included
			*	@since 5.1
			*/
			virtual void SetMonthOffset(const long value);

			/**
			*	@returns the day offset
			*	@since 5.1
			*/
			virtual long GetDayOffset() const;
			/**
			*	Set the day offset
			*	@param value must be between 0 and 50 included
			*	@since 5.1
			*/
			virtual void SetDayOffset(const long value);

			/**
			*	@returns the delivery load
			*	@param canUseSimulation
			*	@since 5.1
			*/
			const char* GetDeliveryLoad(bool canUseSimulation = true) const;

			/**
			*	Set the delivery load
			*	@param newPeriod must have at least 33 characters (end of string included)
			*	@throws NullPointerException if newLoad is NULL
			*	@since 5.1
			*/
			virtual void SetDeliveryLoad(const char * newLoad);

			/**
			*	@since 5.1
			*/
			virtual double GetSpread() const;
			/**
			*	@since 5.1
			*/
			virtual void SetSpread(double value);

			/**
			*	@since 5.1
			*/
			virtual double GetNotional() const;
			/**
			*	@since 5.1
			*/
			virtual void SetNotional(double value);

			/**
			*	@since 5.1
			*/
			virtual long GetMeasureUnit() const;
			/**
			*	@since 5.1
			*/
			virtual void SetMeasureUnit(const long value);

			/** Get the Fixing type ident for the swap leg
			@return the fixing type ident
			@since 4.6
			*/
			virtual long  GetFixingTypeCode() const;	
			/**
			*  Set the fixing type 
			*	@param value is the fixing type internal code
			*	@since 5.1
			*/
			virtual void SetFixingTypeCode(const long value);

			/**
			*	Accessing method for physical or future swap legs.
			*	@param	which	index of the flow to be selected.
			*	@param	flow	structure containing the fixed interest rate swap leg flow specific parameters.
			*	@return	true if the index "which" is between 0 and CSRLeg::GetFlowCount().
			*	@see	CSRLeg and SSCashLegFlow
			*/
			virtual Boolean	GetNthFlow(int which, SSPhysicalFutureFlow *flow) const;

			/** Set the nth flow.
			@param i is an integer which must be between 0 included and GetFlowCount excluded.
			@param	flow	structure containing the fixed interest rate flow specific parameters.
			@throw IndexOutOfBoundsException if the index is not good.
			@since 5.1
			*/
			virtual Boolean	SetNthFlow(int which, const SSPhysicalFutureFlow *flow);


			/**
			 * Adds a flow.
			 * @param  position  position where to add the flow. If position = -1, the
			 *                   flow is added at the end of the list.
			 * @param  flow	     flow to add.
			 * @throw IndexOutOfBoundsException if the index is not good.
			 * @since 5.2
			 */
			void AddFlow( int position , const SSPhysicalFutureFlow &flow );

			/**
			 * Adds a list of flows.
			 * @param  position  position where to add the flows. If position = -1, the
			 *                   flows are added at the end of the list.
			 * @param  flow	     the list of flow to add.
			 * @throw IndexOutOfBoundsException if the index is not good.
			 * @since 5.2
			 */
			void AddFlow( int position , const _STL::vector<SSPhysicalFutureFlow>& flow );

			/**
			 * Sets the list of flows.
			 * Same behavior as calling "Clear()" then "AddFlow( -1 , flow )".
			 * @param  flow  the list of flow to set.
			 * @since 5.2
			 */
			void SetFlow( const _STL::vector<SSPhysicalFutureFlow>& flow );

			friend class instrument::CSRSwap;
			friend class instrument::CSROption;
	
		};

		class  SOPHIS_COMMODITY CSRCashLeg : public virtual instrument::CSRLeg
		{
		private:
			CSRCashLeg(jambe *jb, SW_Donne *sw, const sophis::instrument::CSRSwap * swap);
			CSRCashLeg();
			void Initialize(jambe *jb, SW_Donne *sw, const sophis::instrument::CSRSwap * swap);
			friend class instrument::CSRDerivedLegFactory<CSRCashLeg>;
		public:
			/**
			 *	Destructor.
			 */
			 ~CSRCashLeg();

			 const char *GetXMLRootName() const;

			 void GetDescription(sophis::tools::dataModel::DataSet& legDataSet, const sophis::instrument::CSRSwap* pSwap, int iLeg) const;

			 void UpdateFromDescription(const sophis::tools::dataModel::DataSet& legDataSet, sophis::instrument::CSRSwap* pSwap, int iLeg);

			 void UpdateCashUnit(const sophis::tools::dataModel::DataSet& legDataSet, sophis::instrument::CSRSwap *pSwap);


			 /**
			 *	Accessing method for swap legs.
			 *	@return	The payment frequency of the leg.
			 *	@see	eSwapPeriodicityType
			 *	@since 5.1
			 */
			 virtual sophis::instrument::eSwapPeriodicityType GetPeriodicityType() const;
			 virtual bool GetPeriodicityType(sophis::instrument::eSwapPeriodicityType &value) const;
			 /**
			 *	Accessing method for swap legs.
			 *	Set the payment frequency.
			 *	@throws InvalidArgument if type does not belong to eSwapPeriodicityType. 
			 *			The following type is not accepted: spIMM
			 *	@see	eSwapPeriodicityType
			 *	@since 5.1
			 */
			 virtual void SetPeriodicityType(sophis::instrument::eSwapPeriodicityType type);

			 /**
			 *	Accessing method for swap legs.
			 *	@returns the cash amount.
			 *	@since 5.1
			 */
			 virtual double GetCashAmount() const;
			 /**
			 *	Accessing method for swap legs.
			 *	Set the cash amount.
			 *	@since 5.1
			 */
			 virtual void SetCashAmount(const double value);

			/**
			*	Accessing method for cash swap legs.
			*	@param	which	index of the flow to be selected.
			*	@param	flow	structure containing the fixed interest rate swap leg flow specific parameters.
			*	@return	true if the index "which" is between 0 and CSRLeg::GetFlowCount().
			*	@see	CSRLeg and SSCashLegFlow
			*/
			virtual Boolean	GetNthFlow(int which, SSCashLegFlow *flow) const;

			/** Set the nth flow.
			@param i is an integer which must be between 0 included and GetFlowCount excluded.
			@param	flow	structure containing the fixed interest rate flow specific parameters.
			@throw IndexOutOfBoundsException if the index is not good.
			@since 5.1
			*/
			virtual Boolean	SetNthFlow(int which, const SSCashLegFlow *flow);

			/**
			 * Adds a flow.
			 * @param  position  position where to add the flow. If position = -1, the
			 *                   flow is added at the end of the list.
			 * @param  flow	     flow to add.
			 * @throw IndexOutOfBoundsException if the index is not good.
			 * @since 5.2
			 */
			void AddFlow( int position , const SSCashLegFlow &flow );

			/**
			 * Adds a list of flows.
			 * @param  position  position where to add the flows. If position = -1, the
			 *                   flows are added at the end of the list.
			 * @param  flow	     the list of flow to add.
			 * @throw IndexOutOfBoundsException if the index is not good.
			 * @since 5.2
			 */
			void AddFlow( int position , const _STL::vector<SSCashLegFlow>& flow );

			/**
			 * Sets the list of flows.
			 * Same behavior as calling "Clear()" then "AddFlow( -1 , flow )".
			 * @param  flow  the list of flow to set.
			 * @since 5.2
			 */
			void SetFlow( const _STL::vector<SSCashLegFlow>& flow );

		friend class instrument::CSRSwap;
		friend class instrument::CSROption;
		};

	}
}
SPH_EPILOG

#endif
