/*
 	File:		SphDefaultMetaModelCommodityFuture.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelCommodityFuture_H_
#define _SphDefaultMetaModelCommodityFuture_H_

#include "SphInc/finance/SphDefaultMetaModelFuture.h"
#include "SphInc/instrument/SphFuture.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {
		
		class SOPHIS_COMMODITY CSRDefaultMetaModelCommodityFuture : public virtual CSRDefaultMetaModelFuture
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelCommodityFuture)

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual market_data::CSRMarketData* new_ComputationContext(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context, 
																		const sophis::CSRComputationResults& riskSources,
																		double basketValue, 
																		bool smile) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which1, int which2) const OVERRIDE;
			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;
			virtual double	GetEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual	double GetGlobalEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double	GetVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results)  const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelFutureTapo : public virtual CSRDefaultMetaModelCommodityFuture
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelFutureTapo)

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;

			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelLMEFuture : public virtual CSRDefaultMetaModelCommodityFuture
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelLMEFuture)

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelPowerFuture : public virtual CSRDefaultMetaModelCommodityFuture
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelPowerFuture)

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const OVERRIDE;

			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelPowerForward : public virtual sophis::finance::CSRDefaultMetaModelPowerFuture
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelPowerForward);
			virtual ~CSRDefaultMetaModelPowerForward();
			virtual double	GetFirstDerivative(const instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;
		};

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelCommodityFuture_H_
