#ifndef _SphDeliveryLoadImpl_H__
#define _SphDeliveryLoadImpl_H__

#include "SphInc/commodity/SphCommodityPower.h"
#include "SphInc/commodity/SphPowerGasDeliveryLoad.h"

#include __STL_INCLUDE_PATH(vector)
#ifndef _SphMacros_H_
	#include "SphMacros.h"
#endif

#include "SphInc/static_data/SphCalendar.h"
SPH_PROLOG
namespace sophis {
	namespace commodity {

		class SOPHIS_COMMODITY CSRBaseload : public virtual CSRDeliveryLoad
		{
		public:
			CSRBaseload(long commoCode);
			CSRBaseload() {};
			static CSRBaseload * CreateInstance(const char *s, long commoCode);
			long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual int DaysInWeek() const { return 7; };
			virtual double GetHourCount(long startDate, long endDate, long commoCode) const;
			virtual double SplitIntoBlocks(_STL::vector<SSWeightedPeriods>& children, long date, long commodity) const;
			virtual int GetFirstDeliveryBlock(long day) const;
			virtual int GetLastDeliveryBlock(long commodity, long day) const;
			virtual bool CanBeUsedInWorksheets() const { return true;};
			virtual const char *ShortName() const { return "ba"; } ;

			static const char * NAME;
		protected:
			void Initialize(long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSRPeakload : public virtual CSRDeliveryLoad
		{
		public:
			CSRPeakload(int startHour, int endHour, long commoCode);
			static CSRPeakload * CreateInstance(const char *s, long commoCode);
			long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual int DaysInWeek() const { return 5; };
			virtual double GetHourCount(long startDate, long endDate, long commoCode) const;
			virtual double SplitIntoBlocks(_STL::vector<SSWeightedPeriods>& children, long date, long commodity) const;
			virtual int GetFirstDeliveryBlock(long day) const;
			virtual int GetLastDeliveryBlock(long commodity, long day) const;
			virtual bool CanBeUsedInWorksheets() const { return true;};
			virtual const char *ShortName() const { return "pk"; } ;

			static const char * NAME;

		protected:
			int	fStartHour, fEndHour;
		protected:
			CSRPeakload();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSRPeakloadN : public virtual CSRPeakload
		{
		public:
			CSRPeakloadN(int startHour, int endHour, long commoCode);
			static CSRPeakloadN * CreateInstance(const char *s, long commoCode);
			virtual const char *ShortName() const { return "pkn"; } ;

			static const char * NAME;

		protected:
			CSRPeakloadN();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSROffpeak : public virtual CSRDeliveryLoad
		{
		public:
			CSROffpeak(int startHour, int endHour, long commoCode);
			static CSROffpeak * CreateInstance(const char *s, long commoCode);
			long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual int DaysInWeek() const { return 7; };
			virtual double GetHourCount(long startDate, long endDate, long commoCode) const;
			virtual double SplitIntoBlocks(_STL::vector<SSWeightedPeriods>& children, long date, long commodity) const;
			virtual int GetFirstDeliveryBlock(long day) const;
			virtual int GetLastDeliveryBlock(long commodity, long day) const;
			virtual bool CanBeUsedInWorksheets() const { return false;};
			virtual void GetLoadDecompositionForDay(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode) const;
			virtual void GetLoadDecompositionForMonth(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode, const CSRDeliveryPeriod* period) const;
			virtual bool IsFullDay(sophisTools::eWeekdayType dayOfWeek) const;
			virtual const char *ShortName() const { return "of"; } ;

			static const char * NAME;

		protected:
			int	fStartHour, fEndHour;
		protected:
			CSROffpeak();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSROffpeakN : public virtual CSROffpeak
		{
		public:
			CSROffpeakN(int startHour, int endHour, long commoCode);
			static CSROffpeakN * CreateInstance(const char *s, long commoCode);
			virtual void GetLoadDecompositionForDay(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode) const;
			virtual const char *ShortName() const { return "ofn"; } ;

			static const char * NAME;
		protected:
			virtual _STL::string _internal_toString() const;
			CSROffpeakN();
			void Initialize(int startHour, int endHour, long commoCode);
		};

		class SOPHIS_COMMODITY CSRWestPeak : public virtual CSRPeakload
		{
		public:
			CSRWestPeak(int startHour, int endHour, long commoCode);
			static CSRWestPeak * CreateInstance(const char *s, long commoCode);
			virtual long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			virtual long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual int DaysInWeek() const { return 6; };
			virtual const char *ShortName() const { return "wpk"; } ;

			static const char * NAME;
		protected:
			CSRWestPeak();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSRWestOffpeak : public virtual CSROffpeak
		{
		public:
			CSRWestOffpeak(int startHour, int endHour, long commoCode);
			static CSRWestOffpeak * CreateInstance(const char *s, long commoCode);
			virtual long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			virtual long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual int DaysInWeek() const { return 7; };
			virtual void GetLoadDecompositionForDay(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode) const;
			virtual bool IsFullDay(sophisTools::eWeekdayType dayOfWeek) const;
			virtual const char *ShortName() const { return "ofw"; } ;

			static const char * NAME;
		protected:
			CSRWestOffpeak();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};

		class SOPHIS_COMMODITY CSRCalPeakload : public virtual CSRPeakload
		{
		public:
			CSRCalPeakload(int startHour, int endHour, long commoCode);
			static CSRCalPeakload * CreateInstance(const char *s, long commoCode);
			virtual long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
			virtual long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
			virtual const char *ShortName() const { return "cpk"; } ;

			static const char * NAME;
		protected:
			CSRCalPeakload();
			void Initialize(int startHour, int endHour, long commoCode);
			virtual _STL::string _internal_toString() const;
		};


		class SOPHIS_COMMODITY CSRGasBaseload : public virtual CSRGasDeliveryLoad
		{
			public :
				CSRGasBaseload(long commoCode);
				CSRGasBaseload() {};
				virtual long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const;
				virtual long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const;
				virtual int DaysInWeek() const;
				virtual double GetHourCount(long startDate, long endDate, long commoCode) const;
				virtual int GetFirstDeliveryBlock(long day) const;
				virtual int GetLastDeliveryBlock(long commodity, long day) const;
				virtual bool CanBeUsedInWorksheets() const { return true;};

				static CSRDeliveryLoad* CreateInstance(const char* loadId, long commoCode);
								
				static const char * NAME;

				virtual const char *ShortName() const { return "daily"; } ;

		protected:
				void Initialize(long commoCode);
				virtual _STL::string _internal_toString() const;
		};

	};
};
SPH_EPILOG

#endif
