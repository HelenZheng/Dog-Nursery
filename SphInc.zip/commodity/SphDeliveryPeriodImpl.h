#ifndef _SphDeliveryPeriodImpl_H__
#define _SphDeliveryPeriodImpl_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"

#include "SphInc/commodity/SphPowerGasDeliveryPeriod.h"
#include "SphInc/static_data/SphCalendar.h"

#ifdef GCC_XML
#define	ASSERT(a) 
#endif

#define DECLARATION_DAY_AHEAD_DEFINITION(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::commodity::CSRDayAheadDefinition)
#define	INITIALISE_DAY_AHEAD_DEFINITION(derivedClass,ident)	INITIALISE_PROTOTYPE(derivedClass,ident)

SPH_PROLOG
namespace sophis {
	namespace commodity {

		inline const CSRCommodityPower* GetCommodityPtr(long commoCode)
		{
			bool fastPath = false;
			if (fastPath)
				return (dynamic_cast<const CSRCommodityPower*>(sophis::instrument::CSRInstrument::GetInstance(commoCode)));
			else
			{
				const sophis::instrument::CSRInstrument* inst = sophis::instrument::CSRInstrument::GetInstance(commoCode);
				const CSRCommodityPower * commo = dynamic_cast<const CSRCommodityPower*>(inst);
				ASSERT(commo);
				return commo;
			}
		}

		class SOPHIS_COMMODITY CSRQuarterlyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRQuarterlyDeliveryPeriod(short year, short quarter, long commoCode);
			static CSRQuarterlyDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRQuarterlyDeliveryPeriod* p = dynamic_cast<const CSRQuarterlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}

		protected:
			short fYear;
			short fQuarter;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRQuarterlyDeliveryPeriod();
			void Initialize(short year, short quarter, long commoCode);
		}; 

		class SOPHIS_COMMODITY CSRYearlyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRYearlyDeliveryPeriod(short year, long commoCode);
			static CSRYearlyDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRYearlyDeliveryPeriod* p = dynamic_cast<const CSRYearlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}
			virtual bool MustComputePriceByChildrenPrices() const;			
		protected:
			short fYear;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRYearlyDeliveryPeriod();
			void Initialize(short year, long commoCode);
		};

		class SOPHIS_COMMODITY CSRMonthlyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRMonthlyDeliveryPeriod(); 
			CSRMonthlyDeliveryPeriod(short year, short month, long commoCode);

			static CSRMonthlyDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRMonthlyDeliveryPeriod* p = dynamic_cast<const CSRMonthlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();			
			}

		protected:
			short fYear;
			short fMonth;
		protected:
			virtual _STL::string _internal_toString() const;
			void Initialize(short year, short month, long commoCode);
		};

		class SOPHIS_COMMODITY CSRBalanceOfMonthPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRBalanceOfMonthPeriod(long commodity, short month, short year);
			static CSRBalanceOfMonthPeriod * CreateInstance(const char *s, long commodity);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool isRollingPeriod() const
			{ return true; }

		protected:
			short fMonth;
			short	fYear;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRBalanceOfMonthPeriod();
			void Initialize(long commodity, short month, short year);

		};

		class SOPHIS_COMMODITY CSRGasBalanceOfMonthPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRGasBalanceOfMonthPeriod(long commodity);
			static CSRGasBalanceOfMonthPeriod * CreateInstance(const char *s, long commodity);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			//virtual bool MustBeInWorksheet() {return true;}
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool isRollingPeriod() const
			{ return true; }

			static const char * MODEL_NAME;

		protected:
			virtual _STL::string _internal_toString() const;
			CSRGasBalanceOfMonthPeriod();
			void Initialize(long commodity);
		private:
		};

		class SOPHIS_COMMODITY CSRWeeklyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRWeeklyDeliveryPeriod(short year, short week, long commodity);

			static CSRWeeklyDeliveryPeriod * CreateInstance(const char *s, long commodity);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const; // toujours le lundi donc le first day
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const; // ....week...
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRWeeklyDeliveryPeriod* p = dynamic_cast<const CSRWeeklyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();			
			}

			static void GetWeeksForInterval(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long start, long end, long today, long commodity);

		protected :
			short fYear;
			short fWeek;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRWeeklyDeliveryPeriod();
			void Initialize(short year, short week, long commodity);
		};

		class SOPHIS_COMMODITY CSRBalanceOfWeekPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRBalanceOfWeekPeriod(long commodity);
			static CSRBalanceOfWeekPeriod * CreateInstance(const char *s, long commodity);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool MustBeInWorksheet() {return true;}
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;

			virtual bool isRollingPeriod() const
			{ return true; }

		protected:
			virtual _STL::string _internal_toString() const;
			CSRBalanceOfWeekPeriod();
			void Initialize(long commodity);
		private:
		};


		class SOPHIS_COMMODITY CSRGasBalanceOfWeekPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRGasBalanceOfWeekPeriod(long commodity);
			static CSRGasBalanceOfWeekPeriod * CreateInstance(const char *s, long commodity);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;

			virtual bool isRollingPeriod() const
			{ return true; }

			static const char * MODEL_NAME;

		protected:
			virtual _STL::string _internal_toString() const;
			CSRGasBalanceOfWeekPeriod();
			void Initialize(long commodity);
		private:
		};


		class SOPHIS_COMMODITY CSRDailyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRDailyDeliveryPeriod(short year, short month, short day, long commodity);
			static CSRDailyDeliveryPeriod * CreateInstance(const char *s, long commodity);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			bool IsSameDayAs(const CSRDailyDeliveryPeriod* deliveryPeriod) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetParentWeeks(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			/*parameter end is the end day that the return delivery period should not exceed.
			* parameter today is the today reference date
			* parameter dailyPeriods when set to true indicates that the delivery period to return should be only a D+i one 
			* else (if set to false), the delivery period to return can be a Within-Day, a Day-Ahead, a Week-End, a WDNW or a D+i one.
			*/
			static const CSRDailyDeliveryPeriod* GetSpecializedDailyPeriodInstance(short day, short month, short year, const CSRDeliveryLoad &dLoad, long commodity, long end, long today, bool dailyPeriods);
			/*parameter dailyPeriods when set to true indicates that children in the interval [start,end] should contain only D+i periods
			* else (if set to false), children in the interval [start,end] can contain Within-Day, Day-Ahead, Week-End, WDNW or a D+i periods.
			*/
			static void GetChildrenOfInterval(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long start, long end, long today, bool useSpecializedDaily, long commodity=0, bool dailyPeriods = false);
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			static bool IsDayInLongWeekend (long day, const sophis::static_data::CSRCalendar *cal);
			virtual long GetExpiryDate(const sophis::static_data::CSRCalendar* calendar, const CSRDeliveryLoad* dLoad) const;

			int GetYear() const
			{return fYear;};
			int GetMonth() const
			{return fMonth;};
			int GetDayOfMonth() const
			{return fDay;};

		protected:
			short fYear;
			short fMonth;
			short fDay;

			bool GetDayForRollingTemplate(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today=0) const;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRDailyDeliveryPeriod();
			void Initialize(short year, short month, short day, long commodity);
		};

		class SOPHIS_COMMODITY CSRDaysIntervalDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRDaysIntervalDeliveryPeriod(long firstDeliveryDay, long lastDeliveryDay, long commodity);
			static CSRDaysIntervalDeliveryPeriod * CreateInstance(const char *s, long commodity);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;

			virtual bool MustComputePriceByChildrenPrices() const
			{ return true; }

		protected:
			long fFirstDeliveryDay;
			long fLastDeliveryDay;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRDaysIntervalDeliveryPeriod();
			void Initialize(long firstDeliveryDay, long lastDeliveryDay, long commodity);
		};


		class SOPHIS_COMMODITY CSRDayPlusKDeliveryPeriod : public virtual CSRDailyDeliveryPeriod
		{
		public:
			CSRDayPlusKDeliveryPeriod(long commodity, short day, short month, short year, int k);
			static CSRDayPlusKDeliveryPeriod * CreateInstance(const char *s, long commodity);
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity,_STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool isRollingPeriod() const
			{ return true; }
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			long GetCalDaysShift() const
			{ return fK; }
		protected:
			long	fK; // fDay/fMonth/fYear is equal to today+K calendar days;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRDayPlusKDeliveryPeriod();
			void Initialize(long commodity, short day, short month, short year, int k);
		};
		class SOPHIS_COMMODITY CSRWorkingDaysNextWeekDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRWorkingDaysNextWeekDeliveryPeriod(long commodity);
			static CSRWorkingDaysNextWeekDeliveryPeriod * CreateInstance(const char *s, long commodity);		
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;			
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual bool isRollingPeriod() const { return true; }	
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRWorkingDaysNextWeekDeliveryPeriod();
			void Initialize(long commodity);
		};
		class SOPHIS_COMMODITY CSRWeekendDeliveryPeriod : public virtual CSRDailyDeliveryPeriod
		{
		public:
			CSRWeekendDeliveryPeriod(long commodity);
			static CSRWeekendDeliveryPeriod * CreateInstance(const char *s, long commodity);		
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const
			{ parents.clear(); };
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual bool isRollingPeriod() const
			{ return true; }
			virtual bool MustComputePriceByChildrenPrices() const
			{ return true; }
		protected:
			virtual _STL::string _internal_toString() const;
			CSRWeekendDeliveryPeriod();
			void Initialize(long commodity);			
		};
		class SOPHIS_COMMODITY CSRDayAheadDeliveryPeriod : public virtual CSRDailyDeliveryPeriod
		{
		public:
			CSRDayAheadDeliveryPeriod(long commodity);
			static CSRDayAheadDeliveryPeriod * CreateInstance(const char *s, long commodity);
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;				
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;				
			virtual bool isRollingPeriod() const { return true; }
// 			virtual bool MustComputePriceByChildrenPrices() const
// 			{ return true; }
		protected:
			virtual _STL::string _internal_toString() const;
			CSRDayAheadDeliveryPeriod();
			void Initialize(long commodity);
		};
		class SOPHIS_COMMODITY CSRWithinDayDeliveryPeriod : public virtual CSRDailyDeliveryPeriod
		{
		public:
			CSRWithinDayDeliveryPeriod(long commodity);
			static CSRWithinDayDeliveryPeriod * CreateInstance(const char *s, long commodity);
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;					
			virtual bool isRollingPeriod() const { return true; }
		protected:
			virtual _STL::string _internal_toString() const;
			CSRWithinDayDeliveryPeriod();	
			void Initialize(long commodity);
		};
		class SOPHIS_COMMODITY CSRHourlyDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRHourlyDeliveryPeriod(int hour, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour,int freqindex = 1);
			static CSRHourlyDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity,_STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual long GetExpiryDate(const static_data::CSRCalendar* calendar, const CSRDeliveryLoad* dLoad) const;

			double GetPeriodHourCount(const CSRDeliveryLoad &dLoad, long startDate, long endDate) const;			
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const
			{ deliveries.clear(); };

			virtual bool isRollingPeriod() const
			{ return true; }

			bool IsFractionOfHour() const;

			virtual bool IsValidForCommodity(long commodity) const;

			int GetHour() const
			{	return fHour; }

			int GetHourlyFreqIndex() const
			{	return fFreqIndex; }

			HourlyDataFrequency::eHDGFreq GetHourlyFreqType() const
			{ return fFreqType; }

			virtual bool MustBeInWorksheet() {return true;}

			static const char * CSRHourlyDeliveryPeriod::POWER_SAVING_HOUR_NAME;

			//static const int HOURLY_PROFILE_EQUIVALENT_FOR_25th_HOUR = 3;

			// GetArrayIndex()
			//     @return the index of the hourly period considering that all hourly periods are listed in a vector.
			// For example H1-1/4 returns 0 and H24-4/4 returns 95
			// freqInteger is the granularity. 0 (default values) means the granularity of the commodity.
			// Another value might be used when, for instance, the displayed granularity is different from the commodity granularity.
			// This occurs when 1/2h and 1h commodities are mixed in "Scheduling" display.

			unsigned int GetArrayIndex(int freqInteger=0) const
			{
				if (freqInteger==0)
					freqInteger=HourlyDataFrequency::FreqEnumToFreqInteger(this->fFreqType);
				unsigned int hourExpIndex = freqInteger*(this->GetHour()-1) + (this->GetHourlyFreqIndex()-1)%freqInteger;
				return hourExpIndex;
			}

		protected:
			virtual _STL::string _internal_toString() const;
			CSRHourlyDeliveryPeriod();
			void Initialize(int hour, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour,int freqindex = 1);
		private:
			int fHour;
			int fFreqIndex;
			HourlyDataFrequency::eHDGFreq fFreqType;
		};
		
		class SOPHIS_COMMODITY CSRUnavailableHourlyDeliveryPeriod : public virtual CSRHourlyDeliveryPeriod
		{
		public:
			CSRUnavailableHourlyDeliveryPeriod(int hour, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour, int freqindex = 1)
			{ CSRUnavailableHourlyDeliveryPeriod::Initialize(hour, commoCode, freqtype, freqindex); }

			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const
			{ ASSERT(false); return 0; }
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const
			{ ASSERT(false); return 0; }
			
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const
			{ return eDPTUnavailableHourly; }
			
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const
			{ ASSERT(false); parents.clear(); };
			
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const
			{ ASSERT(false); children.clear(); return false; };

			virtual long GetExpiryDate(const static_data::CSRCalendar* calendar, const CSRDeliveryLoad* dLoad) const
			{ ASSERT(false); return 0; }

			virtual double GetDiscountedFactor(const CSRDeliveryLoad *dLoad, long currency, long evaluationDate, long commodityCode, const market_data::CSRMarketData &context) const
			{ ASSERT(false); return 0; }

			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const
			{ ASSERT(false); deliveries.clear(); };
		
		protected:
			CSRUnavailableHourlyDeliveryPeriod()
			{}

			void Initialize(int hour, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour, int freqindex = 1)
			{ CSRHourlyDeliveryPeriod::Initialize(hour, commoCode, freqtype, freqindex); }

		};

		class SOPHIS_COMMODITY CSRSeasonalDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRSeasonalDeliveryPeriod(short year, int season, long commoCode);
			static CSRSeasonalDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today,long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRSeasonalDeliveryPeriod* p = dynamic_cast<const CSRSeasonalDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}

			virtual bool MustComputePriceByChildrenPrices() const;			

		protected:
			short fYear;
			int fSeason;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRSeasonalDeliveryPeriod();
			void Initialize(short year, int season, long commoCode);
		};
		
		
		class SOPHIS_COMMODITY CSRGasYearDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			CSRGasYearDeliveryPeriod(short year, long commoCode);
			static CSRGasYearDeliveryPeriod * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today,long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRGasYearDeliveryPeriod* p = dynamic_cast<const CSRGasYearDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}

			virtual bool MustComputePriceByChildrenPrices() const;			

		protected:
			virtual _STL::string _internal_toString() const;
			CSRGasYearDeliveryPeriod();
			void Initialize(short year, long commoCode);
		private:
			short fYear;
		};
        //==================================================================================
		//==== UK Periods =================================================================
        //==================================================================================

		// Tools for UK calendar
		class SOPHIS_COMMODITY CSRDeliveryPeriodUK: public virtual CSRDeliveryPeriod
		{
		public:
			static long GetFirstMondayOfYear(short year);
			static CSRDeliveryPeriod::eFlattendInto FlattenToMonths(const CSRDeliveryPeriod *thisPeriod, _STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load,  long commodityCode);

			virtual CSRDeliveryPeriod::eFlattendInto FlattenToMonths(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load, long commodityCode) const;
			virtual long GetExpiryDate(const sophis::static_data::CSRCalendar* calendar, const CSRDeliveryLoad* dLoad) const;

		protected:
			CSRDeliveryPeriodUK();
		};		

		class SOPHIS_COMMODITY CSRQuarterlyDeliveryPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRQuarterlyDeliveryPeriodUK(short year, short quarter, long commoCode);
			static CSRQuarterlyDeliveryPeriodUK * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
		    virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRQuarterlyDeliveryPeriod* p = dynamic_cast<const CSRQuarterlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}

			static const char * MODEL_NAME;
		protected:
			short fYear;
			short fQuarter;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRQuarterlyDeliveryPeriodUK();
			void Initialize(short year, short quarter, long commoCode);
		}; 


		class SOPHIS_COMMODITY CSRYearlyDeliveryPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRYearlyDeliveryPeriodUK(short year, long commoCode);
			static CSRYearlyDeliveryPeriodUK * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRYearlyDeliveryPeriod* p = dynamic_cast<const CSRYearlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}
			static const char * MODEL_NAME;
		protected:
			short fYear;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRYearlyDeliveryPeriodUK();
			void Initialize(short year, long commoCode);
		};



		class SOPHIS_COMMODITY CSRMonthlyDeliveryPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRMonthlyDeliveryPeriodUK(); 
			CSRMonthlyDeliveryPeriodUK(short year, short month, long commoCode);

			static CSRMonthlyDeliveryPeriodUK * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;

			static long GetFirstMonthDay(short year, short month);
			static long GetLastMonthDay(short year, short month);
			static void GetUKMonthAndYearByDate(long lDate, int* pYear, int* pMonth);
			static void GetUKWeekByDate(long lDate, int* pWeek);

			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRMonthlyDeliveryPeriod* p = dynamic_cast<const CSRMonthlyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();			
			}
			static const char * MODEL_NAME;			
		protected:
			short fYear;
			short fMonth;
		protected:
			virtual _STL::string _internal_toString() const;
			void Initialize(short year, short month, long commoCode);
		};
/*
		class SOPHIS_COMMODITY CSRBalanceOfMonthPeriodUK : public CSRDeliveryPeriod
		{
		public:
			CSRBalanceOfMonthPeriodUK(long commodity);
			static CSRBalanceOfMonthPeriodUK * CreateInstance(const char *s, long commodity);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool isRollingPeriod() const
			{ return true; }
			static const char * MODEL_NAME;

			virtual CSRDeliveryPeriod::eFlattendInto FlattenToMonths(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load) const
			{
				return CSRDeliveryPeriodUK::FlattenToMonths(this, outFlattened, load);
			}
		protected:
			long	fCommodity;
		};
*/
		class SOPHIS_COMMODITY CSRBalanceOfWeekPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRBalanceOfWeekPeriodUK(long commodity);
			static CSRBalanceOfWeekPeriodUK * CreateInstance(const char *s, long commodity);
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool MustBeInWorksheet() {return true;}
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;

			virtual bool isRollingPeriod() const
			{ return true; }

			static const char * MODEL_NAME;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRBalanceOfWeekPeriodUK();
			void Initialize(long commodity);
		private:
			long	fCommodity;
		};

		class SOPHIS_COMMODITY CSRWeeklyDeliveryPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRWeeklyDeliveryPeriodUK(short year, int week, long commodity);
			static CSRWeeklyDeliveryPeriodUK * CreateInstance(const char *s, long commodity);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const; // toujours le lundi donc le first day
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const; // ....week...
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRWeeklyDeliveryPeriod* p = dynamic_cast<const CSRWeeklyDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();			
			}

			static void GetWeeksForInterval(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long start, long end, long today, long commodity);
			static const char * MODEL_NAME;
		protected :
			short fYear;
			int fWeek;
			long fCommodity;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRWeeklyDeliveryPeriodUK();
			void Initialize(short year, int week, long commodity);
		};

		class SOPHIS_COMMODITY CSRSeasonalDeliveryPeriodUK : public virtual CSRDeliveryPeriodUK
		{
		public:
			CSRSeasonalDeliveryPeriodUK(short year, int season, long commoCode);
			static CSRSeasonalDeliveryPeriodUK * CreateInstance(const char *s, long commoCode);
			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today,long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				const CSRSeasonalDeliveryPeriod* p = dynamic_cast<const CSRSeasonalDeliveryPeriod*>(&period);
				return p==0 ?  true : toStringIdent()!=p->toStringIdent();
			}

			virtual bool MustComputePriceByChildrenPrices() const
			{ return true; } // is possible because no standard period has CSRSeasonalDeliveryPeriod parents

			static const char * MODEL_NAME;
			//virtual CSRDeliveryPeriod::eFlattendInto FlattenToMonths(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load) const;
			
		protected:
			short fYear;
			int fSeason;
		protected:
			virtual _STL::string _internal_toString() const;
			CSRSeasonalDeliveryPeriodUK();
			void Initialize(short year, int season, long commoCode);
		};

		class SOPHIS_COMMODITY CSRDailyDeliveryPeriodUK : public virtual CSRDailyDeliveryPeriod
		{
		public:
			CSRDailyDeliveryPeriodUK(short year, short month, short day, long commodity);
			static CSRDailyDeliveryPeriodUK * CreateInstance(const char *s, long commodity);
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual void GetParentWeeks(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents) const;
		protected:
			CSRDailyDeliveryPeriodUK();
			void Initialize(short year, short month, short day, long commodity);

		};

		//==================================================================================
		//====End of UK Periods ============================================================
		//==================================================================================

		class SOPHIS_COMMODITY CSRNonStandardDeliveryPeriod : public virtual CSRDeliveryPeriod
		{
		public:
			struct SSLocalDouble
			{
				SSLocalDouble(){fValue = 0.;}
				double fValue;
			};

			static CSRNonStandardDeliveryPeriod* CreateInstance(const char *s, long commoCode);

			long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const;
			
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const;
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today,long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const;

			virtual void DecompositionInTargetPeriod(eDeliveryPeriodType targetPeriodType, const CSRDeliveryLoad &dLoad, const CSRCommodityPower *commo, _STL::set<const CSRDeliveryPeriod *> &outResult) const;

			static void ParseStartEndDate(const char *parameters, long &outStartDate, long &outEndDate);
			virtual void LoadDailyQuantities();

			virtual double GetPeriodHourCount(const CSRDeliveryLoad &dLoad, long startDate, long endDate) const;
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual const CSRDeliveryPeriod* GetFlowDeliveryPeriod(const CSRDeliveryLoad& load, const CSRCommodityPower* commodity, const long startDate, const long endDate) const {return this;};
			
			double GetDailyQuantity(const CSRDeliveryLoad &dLoad, long date) const;
			long	GetIdent() const;

			static CSRNonStandardDeliveryPeriod *	CreateSimulationInstance(const char* ident,
				SwapInfosForNonStandardProfile *swapInfos = NULL,const char* sIdentOriginalProfile=NULL);
			static const CSRNonStandardDeliveryPeriod *		FindSimulationInstance(const char* ident);
			static const CSRNonStandardDeliveryPeriod *		FindSimulationInstanceByIdent(long ident);
			static const char* FindSimulationNameByIdent(long ident);
			static void									RemoveSimulationInstance(const char* ident);
			

			static const char * MODEL_NAME;
		protected:
			CSRNonStandardDeliveryPeriod();
			CSRNonStandardDeliveryPeriod(long profileIdent, long startDate, long endDate, long commoCode);
			void Initialize(long profileIdent, long startDate, long endDate, long commoCode);

			long						fStartDate;
			long						fEndDate;			
			long						fIdent;

			static _STL::map<_STL::string, CSRNonStandardDeliveryPeriod*> simulatedDeliveryPeriodsByIdent;

		protected:
			virtual _STL::string _internal_toString() const;
		private:
			_STL::vector<SSLocalDouble> fDailyQuantities;
		};

		struct SOPHIS_COMMODITY SwapInfosForNonStandardProfile {
			SwapInfosForNonStandardProfile(long issueDate, long endDate, long commoCode, double dateHisto, long oldSwapCode, short schedulingGranularity = 0);

			long fIssueDate;
			long fEndDate;
			long fCommoCode;
			double fDateHisto;
			long fOldSwapCode;
			long fSwapCode;
			short fSchedulingGranularity;
		};

		class SOPHIS_COMMODITY CSRNonStandardDeliveryProfile : public virtual CSRNonStandardDeliveryPeriod
		{
		public:

			static CSRNonStandardDeliveryProfile* CreateInstance(const char *s, long commoCode, const SwapInfosForNonStandardProfile *swapInfos=NULL,const CSRNonStandardDeliveryProfile * pSourceDeliveryPeriod = NULL);

			static CSRNonStandardDeliveryProfile* CreateInstanceForStandaloneProfile(const char *s, long commoCode, const SwapInfosForNonStandardProfile *swapInfos); //DEPRECATED
			static bool DecodeParameters(const char *s,long& outBegin,long &outEnd,HourlyDataFrequency::eHDGFreq& outFreq);
			static CSRNonStandardDeliveryProfile* CreateInstanceForSwap(const char *s, const SwapInfosForNonStandardProfile *swapInfos=NULL);
			static CSRNonStandardDeliveryProfile* CreateInstanceByCopy(const char *s, const CSRNonStandardDeliveryProfile * pSourceDeliveryPeriod = NULL);


			static bool CreateNewProfileEntry(const char *s, long commoCode);

			static void FormatNameForSwap(long swapCode,int inLeg, _STL::string& outName);
			static void FormatNameForScheduling(long swapCode, int whichLeg, _STL::string& outName);
			static bool IsAttachedProfile(const char *name);
			static bool GetParentSwapCodeAndLeg(const char *s, long *outSwCode, int *outLeg);
						
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const;
			
			virtual void LoadDailyQuantities(long commoCode, const SwapInfosForNonStandardProfile *swapInfos);
			virtual sql::errorCode  SaveDailyQuantities() const;
			virtual void CopyNonStandardDeliveryProfile(const CSRNonStandardDeliveryProfile* pSourceProfile);

			virtual double GetPeriodHourCount(const CSRDeliveryLoad &dLoad, long startDate, long endDate) const;

			virtual HourlyDataFrequency::eHDGFreq GetHourlyFrequencyType(void) const
			{ return fFreqType; }	

			virtual int GetPeriodWithinHourCount() const;			

			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const;
			virtual long GetIntradayCoefficientsProfileId(long day) const;
			virtual void SetIntradayCoefficientsProfileId(long day, long id);
			virtual void ClearIntradayCoefficientsProfileId();
			virtual void SetDeliveryQuantities(long day, const CSRHourlyDeliveryPeriod &hour, double qty);
			virtual double GetDeliveryQuantity(long day, const CSRHourlyDeliveryPeriod &hour);
			virtual void SetDeliveryQuantitiesToOne();
			virtual void CopyHourlyFlux(long nDate, const SSWeightedPeriods & sourceHourlyPeriod);

			virtual bool IsValidForCommodity(long commodity) const;

			virtual void Clear(){
				fDeliveries.clear(); fDeliveriesCoeffId.clear(); fStartDate = 0; fEndDate = 0;
			}

			virtual void Clean();

			void GetDescription(sophis::tools::dataModel::DataSet& profDataSet, const sophis::instrument::CSRSwap* pSwap, int iLeg) const;
			void UpdateFromDescription(const sophis::tools::dataModel::DataSet& profDataSet, sophis::instrument::CSRSwap* pSwap, int iLeg);

			static const char * MODEL_NAME;
			static const int SCHEDULING_CURVETYPE_MINSET; // The "curve type" in the non std profile must be at least this value for the scheduling data to be used in Scheduling scenario
			static const int SCHEDULING_CURVETYPE_MINSET_NOTVALIDATED; // there is some scheduling data to be used, but it is not "validated" (VPP not yet nominated) so we should not take it into account for scheduling & powernext nomination
			static const int SCHEDULING_CURVETYPE_CASH;

			void ResetDeliveryQuantities(long day);
		protected:
			HourlyDataFrequency::eHDGFreq fFreqType;			

			CSRNonStandardDeliveryProfile();
			CSRNonStandardDeliveryProfile(long profileIdent, long startDate, long endDate, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour);
			void Initialize(long profileIdent, long startDate, long endDate, long commoCode, HourlyDataFrequency::eHDGFreq freqtype = HourlyDataFrequency::HDG_EachHour);

		private:
			//static bool AttachToSwap(SW_Donne* swap);
			_STL::map< long , _STL::vector<SSWeightedPeriods> > fDeliveries;	// For each day, gives the vector of quantities
			_STL::map< long , long > fDeliveriesCoeffId; // For each day, give the profile id
		
		friend class DLGNonStandardPowerProfile;
		friend class CSRNonStandardPowerProfileList;
		//friend class CSRPowerDeliveryPeriod;
		friend class CSRNonStandardDeliveryPeriod;
		};

		/**
		* Prototyped class for the Day Ahead definition popup menu.
		*/
		class SOPHIS_COMMODITY CSRDayAheadDefinition
		{
		public:

			/* For Toolkit, use DayAheadDefinition ID greater than 'dadUserGreaterThan' */
			enum eDayAheadDefinition	
			{
				dadXXX,
				dadNextBusDayOnly,
				dadAllDaysTillNextBusDay,
				dadNextCalendarDay,
				dadUserGreaterThan = 1000
			};
			CSRDayAheadDefinition() {}
			virtual ~CSRDayAheadDefinition() {}

			/** Clone function used by prototype
			It is generally created by the macro DECLARATION_DAY_AHEAD_DEFINITION
			*/
			virtual	CSRDayAheadDefinition* Clone() const = 0;

			/** The key for the prototype is a short 
			@see CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRDayAheadDefinition, short> prototype;
			
			/** Access to the singleton containing all the derived class of CSRDayAheadDefinition
			It is filled when using the macro INITIALISE_DAY_AHEAD_DEFINITION
			*/
			static prototype & GetPrototype();			
			
			/*Name of the DayAheadDefinition menu*/
			virtual const char * GetName() const = 0;
			
			/*Gets the corresponding eDayAheadDefinition enum*/
			virtual eDayAheadDefinition GetType() const = 0;

			static CSRDayAheadDefinition*	GetDayAheadDefinition(eDayAheadDefinition ident);

			virtual long GetDayAheadFirstDeliveryDay(long date, const static_data::CSRCalendar * calendar) = 0;
			virtual long GetDayAheadLastDeliveryDay(long date, const static_data::CSRCalendar * calendar) = 0;

			virtual long GetBoMFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long date, const static_data::CSRCalendar * calendar, long commodity = 0) = 0;
			virtual long GetBoMLastDeliveryDay(const CSRDeliveryLoad &dLoad, long date, const static_data::CSRCalendar * calendar, long commodity = 0) = 0;
		};

	};
};
SPH_EPILOG


#endif
