/*
 	File:		SphInstrument.h
 
 	Contains:	Class for the handling of fixing type for listed swap
 
 	Copyright:	� 2003 Sophis.
 
*/

#pragma once

#ifndef __SPH_FIXING_TYPE_H__
#define __SPH_FIXING_TYPE_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/gui/SphMenu.h"
#include "SphInc/instrument/SphSwapExplanation.h"
#include "SphInc/instrument/SphSwap.h"
#include "SphInc/instrument/SphLeg.h"
#include "SphInc/static_data/SphHistoricalData.h"
#include "SphInc/SphComputationResultsImpl.h"

	
#include __STL_INCLUDE_PATH(vector)




#define DECLARATION_FIXING_TYPE(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,sophis::commodity::CSRFixingType)
#define CONSTRUCTOR_FIXING_TYPE(derivedClass)			
#define WITHOUT_CONSTRUCTOR_FIXING_TYPE(derivedClass)	
#define	INITIALISE_FIXING_TYPE(derivedClass,  id)	sophis::tools::install<derivedClass>(id);
//#define	INITIALISE_FIXING_TYPE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, sophis::commodity::CSRFixingType, name)
//#define	INITIALISE_FIXING_TYPE(derivedClass, name)		sophis::tools::install<derivedClass, derivedClass, char*>(name);

SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace sophis	{
	namespace static_data {
		class CSRCalendar;
	}
	namespace commodity	{

		struct SSPhysicalFutureFlow;

		struct FixingOutput
		{
			FixingOutput() { Clear(); }
			void Clear(void) { memset(this, 0, sizeof(FixingOutput)); }
			double	fResult;
			bool	fMissingFixing;
			double	fDeliveryQuantity;
		};

		/** Class to handle the way of calculating the futures in a future commodity swap.
		This is saved in the database in the table TITRES in the field FIXING_TYPE 1/2 as a
		long which is defined when instanciating the class.
		@since 4.6
		*/
		struct SSPairOfCodes 
		{
			SSPairOfCodes(long code1, long code2)
			{
				fCode1 = code1;
				fCode2 = code2;
			}
			
			bool operator<(const SSPairOfCodes& pair) const
			{
				if( fCode1 < pair.fCode1 )
					return true;
				else if( (fCode1 <= pair.fCode1) && (fCode2 < pair.fCode2) ) 
					return true;
				else
					return false;
			}			
			long fCode1;
			long fCode2;
		};

		struct SSVegaCrossedVega 
		{
			_STL::map<long, SSLocalDouble>			fVega;
			_STL::map<SSPairOfCodes, SSLocalDouble>	fCrossedVega;
		};

		struct SSDeltaGamma 
		{
			instrument::DeltaGamma					deltaFuture;
			_STL::map<long,	SSLocalDouble>			deltaForex;
			_STL::map<SSPairOfCodes, SSLocalDouble> gammaForexFuture;
			instrument::DeltaGamma					undiscountedDeltaFuture;
			_STL::map<SSPairOfCodes, SSLocalDouble> undiscountedGammaForexFuture;
            instrument::DeltaGamma					deltaFutureTotal; /* Term 1 to compute the total optimized total commo delta for Commo baskets - This term is the left part of partial_d(U^2 sigma^2)/partial_d(F_i) */
			instrument::DeltaGamma					deltaFutureVega; /* Term 2 to compute the total optimized total commo delta for Commo baskets - This term is the right part of partial_d(U^2 sigma^2)/partial_d(F_i) */
			instrument::DeltaGamma					dsi2dfi; /* contains partial_d(sigma^2)/partial_d(F_i)*/
			_STL::map<long,	SSLocalDouble>			deltaForexTotal; /* Term to compute the total optimized total fx delta for Commo baskets - This term is partial_d(U^2 sigma^2)/partial_d(F_i) */
			_STL::map<long, SSLocalDouble>			dsi2dchi; /* contains partial_d(sigma^2)/partial_d(chi)*/
			double									sumU; /* Value of U, the non-fixed part of the coupon, for commodity baskets */
			double									smileEffect; /* For total delta of commodity baskets - To document when the doc-fi has been updated */
			_STL::map<SSPairOfCodes, SSLocalDouble> gammaFutureFuture; /*for GSCI performance swap, future gammas and crossed gammas may be different from 0*/
			_STL::map<SSPairOfCodes, SSLocalDouble> gammaForexForex; /*for GSCI performance swap, forex gammas and crossed gammas may be different from 0 */

			void ClearAll();
		};

		class SOPHIS_COMMODITY CSRFixingType
		{
		public:
			enum	eID	{
				eStandard,
				eLME					= 6,
				eBulletLME				= 7,
				eLME3m					= 8,
				eBulletStandard			= 9,
				eBasketMNP				= 10,
				ePower                  = 11,
				eStripBulletStandard	= 12,
				eStripBulletLME			= 13,
				eStripBulletLME3m		= 14,
				eNatGasLastDate			= 15,
				eNatGasPenultimate		= 16,
				eNatGasEndOfMonth		= 17,
				eNatGasBeginningOfMonth	= 18,
				eStandardCoal           = 19,
				eFreight                = 20,
				eCarbonCO2              = 21,
				eIndexPerformance		= 22,
				eGSCI_ER_TR				= 23,
				eGSCI_ER_TR_Perf		= 24,
				ePowerGRD				= 25,
				ePowerVPP				= 26,
				ePowerSwing				= 27,
				eStdFutureAverage		= 28,
				eFwdCarbonCO2			= 29,
				ePowernextSpot          = 30,
				eMondayWeekly			= 31,
				eUserGreaterThan		= 1000
			};

			/** Structure used in {@link CSRBreakDown} as a vector giving 
			the open fixing per future.
			*/
			struct OneFixing
			{

				/** Date to take the fixing
				*/
				long	fDate;
				
				/** Id of the futures or the delivery date of the futures
				*/
				long	fCode;

				/** Id of the commodity.
				*/
				long	fCodeCommodity;

				/** Factor to multiply the fixing (take into account the swap unit).
				*/
				double	fFactor;

				/** spread on the future values.
				*/
				double	fSpread;

				/** currency of the futures (for multi currency futures)
				*/
				long	fCurrency;

				/** payment date of the corresponding flow (useful for discounted delta gamma)
				 */
				long	fPaymentDate;
			};

			/*
			 * structure used to gather the information relative the quotation dates of a swap
			 * when computing the volatilities or the vegas of commodity asian options and swaptions
			 * @see CSRSwap::GetCommodityVolatilityAndVegaData
			 */
			struct SSVolVegaData
			{
				long	fVolatilityDate;
				long	fFutureExpiryDate;
				double	fFutureVolValue;
				double	fFutureSensitivity;
				double	fDiscountedFactor;
				bool	fIsFixed;
			};

			/* this structure used in GetFixingDates : day is a quotation date, weight is the weight of this date
			*/
			struct DateWeight
			{
				DateWeight()
				{
					day = 0;
					weight = 0.;
				};
				long	day;
				double	weight;
			};

			/**
			*
			*/

			class CSRFixingTypeImpl;
			/** Vector ordererd per date to give the fixing.
			*/

			class SOPHIS_COMMODITY CSRBreakDown : public _STL::vector<OneFixing> 
			{
			public:


				CSRBreakDown(const CSRFixingTypeImpl* fixingTypeImpl);
				virtual ~CSRBreakDown();

				/** Calculate the value without discounting of a leg once the break down is done.
				@param tag_fixing	is a fixing used for the future defined in the swap definition.
				@param context		is a market data.
				*/
				virtual double	GetTheoreticalValue(long								 tag_fixing,
													long								 forexTagFixing, 
													const market_data::CSRMarketData	&context,
													FixingOutput						*fixedValue) const = 0;
				/** Calculate the delta without discounting of a leg once the break down is done.
				@param tag_fixing	is a fixing used for the future defined in the swap definition.
				@param context		is a market data
				@param price		theoretical value without discounting
				@param delta_gamma	is the delta/gamma per underlying.
				*/
				virtual void	GetPriceDeltaGamma(	long								 tag_fixing,
													long								 forexTagFixing, 
													const market_data::CSRMarketData	&context,
													FixingOutput						*price,
													instrument::DeltaGamma				*delta_gamma) const = 0;

				/** Calculate the weight on each underlying without discounting.
					Compute the dates until which each underlying is involved .
				@param tag_fixing	is a fixing used for the future defined in the swap definition.
				@param context		is a market data
				@param price		theoretical value without discounting
				@param weight_date	is the weight/date per underlying.
				*/
				virtual void	GetPriceWeightDate(	long							  tag_fixing,
													long							  forexTagFixing, 
													const market_data::CSRMarketData &context,
													FixingOutput					 *price,
													instrument::DeltaGamma			 *weight_date) const = 0;

				virtual double GetBreakDownTheoreticalValue(long								 tag_fixing,
															long								 forexTagFixing, 
															const market_data::CSRMarketData	&context, 
															FixingOutput						*fixedValue	   = NULL,
															sophis::commodity::SSDeltaGamma		*outDeltaGamma = NULL) const = 0;

				const CSRFixingTypeImpl* GetFixingTypeImpl() const {return fFixingTypeImpl;}
			protected:
				struct FixedValueOutput
				{
					FixedValueOutput() { memset(this, 0, sizeof(FixedValueOutput)); }
					FixedValueOutput(size_t a) : fNextBreakdownIndex(a), fMissingFixing(false){}

					size_t	fNextBreakdownIndex;
					bool	fMissingFixing;
				};

				/* Calculate mean of prices between 2 dates, using the fixings between these dates as given by the "this"<OneFixing> vector.
				*  If no forex fixing is found for today, use forex spot. 
				*  @param basicInstrument: the instrument being priced
				*  @param endDate: the day up to which the mean is performed
				*  @param tag_fixing: The fixing to use for the instrument : "Open", "Last", "Highest", ... 
				*  @param forex_fixing: The fixing to use for the forex : "Open", "Last", "Highest", ...
				*  @param context: market data
				*  @param fixedValueOutput.fNextBreakdownIndex The first OneFixing to use and becomes the the last which was used
				*  @param fixedValueOutput.fMissingFixing: Set to true in case a missing fixing is found.
				*  @return Mean of fixing prices between (*this)[fixedValueOutput.fNextBreakdownIndex]->fDate and endDate
				*/
				double GetFixedValue(const instrument::CSRInstrument	*basicInstrument,
									 long								endDate,
									 long								tag_fixing,
									 long								forex_fixing,
									 const sophis::market_data::CSRMarketData &context,
									 FixedValueOutput					&fixedValueOutput) const;
				const CSRFixingTypeImpl* fFixingTypeImpl;
			};

			class SOPHIS_COMMODITY CSRFixingTypeImpl
			{
			public:
				CSRFixingTypeImpl(const instrument::CSRSwap *parentSwap, int whichLeg);
				virtual ~CSRFixingTypeImpl();

			protected:
				CSRFixingTypeImpl();
				void Initialize(const instrument::CSRSwap *parentSwap, int whichLeg);

			public:
				const CSRBreakDown * GetBreakDown() const;
				const instrument::CSRSwap* GetParentSwap() const{return fParentSwap;}
				int GetParentWhichLeg() const{return fParentWhichLeg;}

				/** Computes the break down of a flow in futures terms.
				@param flow is an input cash flow of a listed future swap.
				@param swap_calendar is the calendar used for the swap; it must be not null.
				@param commodity is the commodity used for the swap; it must be not null.
				@param swap_unit is the unit of the swap.
				@param break_down is the output break down of the cash flow at this date.
				@throws violation exception if swap_calendar is null or commodity is null.
				It is extensively used by the pricing of a commodity swap.
				*/
				virtual bool	ComputeBreakDown(long						today,
												const instrument::SSFlow	&flow,
												const static_data::CSRCalendar			*swap_calendar,
												const CSRCommodity			*commodity,
												long						swap_unit,
												long						strike_unit,
												bool						forceCalendarCheck,
												const static_data::CSRHistoricalData &histoData) = 0;

				/**
				 * Automatic coupon management function. If the swap should be closed before the last coupon payment date 
				 * this function should return true and the swap will be closed at date closureDate.
				 */
				virtual bool	GetSwapClosure(long& closureDate) const
				{
					return false;
				}

				/**
				 * This method gives the characteristics of the physical coupon to be generated for the n-th flow of the leg.
				 * @param physicalCoupon	characteristics of the physical coupon
				 * @return false if no coupon is to be generated.
				 */
				virtual bool	GetPhysicalCoupon(	int													whichFlow,
													_STL::vector<instrument::CSRSwap::SSPhysicalCoupon>	&physicalCoupon,
													_STL::vector<_STL::string>							&outFOComments,
													_STL::vector<_STL::string>								&outBOComments,
													const static_data::CSRHistoricalData &histoData) const
				{
					return false;
				}

				/* This method modifies the flow that is given as parameter
				 * A typical use of this method is the management of commodity Bullet swaps.
				 * The "normal" leg flow settlement date is modified according to the bullet leg dates.
				 */

				virtual bool	ModifyFlow(instrument::SSFlow			&flow) const
				{
					return false;
				}

				virtual bool	IsValidCommoditySwap(const market_data::CSRMarketData &param, _STL::string &errorMessage) const {return true;};

				virtual bool	 GetRollingDate(long commodity, static_data::SSMaturity& maturity) const;

				/*
				 * This method find for some quotation date the expiry date of the Future
				 * corresponding to the rolling convention
				 *
				 * Examples (informal)
				 * CASH convention : the future is the one delivering two days after quotation date
				 * LME3m convention: the future is the future delivering at quotation date plus 3 month
				 * ...
				 */

				virtual long	GetFutureExpiryByQuotationDate(long commodity, double quotationDate, long currency, static_data::eHolidayAdjustmentType adjustement) const;

				/**
				 * This method gives the date of coupon generation for the n-th flow of the leg
				 * @return false if no date is found for the parameters.
				 */
				virtual bool	GetCouponGenerationDate(int							whichFlow, 
														long&						generationDate, 
														long&						paymentDate) const;

				/**
				 * This method gives the risk sources of the leg
				 * @return false if sommthing went wrong
				 */
				virtual bool	GetRiskSourceStructures(	_STL::set<long>&				inoutDeltaGammaForSwapFutureArray,
															_STL::set<long>&				inoutVegaForSwapFutureArray,
															_STL::set<long>&				inoutVegaForSwaptionFutureArray,
															_STL::set<long>&				inoutCurrencyCodeArray,
															_STL::vector<SSInstVersion>&	outVersionInfos) const;
				/**
				 * This method gives the value of the coupon to be generated for the n-th flow of the leg
				 * @return false if no date is found for the parameters.
				 * @param coupon
				 * @param unit quotity of the coupon
				 * @param histoData is the container for real and simulated historical data
				 */
				virtual bool GetCouponGenerationValue(	int		whichFlow, 
														long&	paymentCurrency,
														double& cashUnitCoupon, 
														double& unitQuotity,
														const static_data::CSRHistoricalData &histoData) const;

				/** For the functionality see CSRBreakdown just an adaptator virtual for link purposes*/
				virtual double	GetTheoreticalValue(long								 tag_fixing,
													long								 forexTagFixing, 
													const market_data::CSRMarketData	&context,
													FixingOutput						*fixedValue) const;

				/** Tells if one must use the modified price used for pricing Asian option with a modifed strike method.
				* The modifed price is the price corrected by the fixed value, which will be included in the strike when evaluating the option price:
				* \f[ P_m = P - P_{Fixed} \f].
				*/
				virtual bool IsTheoreticalWithoutFixedValue() const;

				/** For the functionality see CSRBreakdown just an adaptator virtual for link purposes*/
				virtual void	GetPriceDeltaGamma(	long									 tag_fixing,
													long									 forexTagFixing, 
													const market_data::CSRMarketData		&context,
													FixingOutput							*price,
													instrument::DeltaGamma					*delta_gamma) const;

				/** For the functionality see CSRBreakdown just an adaptator virtual for link purposes*/
				virtual void	GetPriceWeightDate(	long								 tag_fixing,
													long								 forexTagFixing, 
													const market_data::CSRMarketData	&context,
													FixingOutput						*price,
													instrument::DeltaGamma				*weight_date) const;

				virtual bool GetFactorForDelta(double swapNominal, double tx, double& factorForDelta)				const;
				virtual void GetFactorForVolatility(double swapNominal, double tx, double& factorForVolatility)	const;

				/** Computes the volatility of the flow*/
				virtual double GetVolatility(	int							isolateNthFlow,
												double 						startDate,
												double						endDate,		
												double 						strike,
												NSREnums::eVolatilityType	volatilityType,
												Boolean 					put,
												const market_data::CSRMarketData			&context) const;
				void InitDeltaGammaOptimization(std::vector<std::map<sophis::CSRRiskSourceDelta, double> >	&deltaFlows,
												long								endDate,
												const market_data::CSRMarketData					&context) const;
				virtual void InitVegaOptimization(	_STL::vector<SSVegaCrossedVega>&	vegaFlows,
											double 									startDate,
											long									endDate,
											double 									strike,
											NSREnums::eVolatilityType				volatilityType,
											Boolean 								put,
											const market_data::CSRMarketData		&context) const;

				virtual void InitDeltaVegaOptimization(	_STL::vector<SSVegaCrossedVega>	&outVegaFlow,
											double 									startDate,
											long									endDate,
											double 									strike,
											NSREnums::eVolatilityType				volatilityType,
											Boolean 								put,
											const market_data::CSRMarketData		&context,
											_STL::vector<SSDeltaGamma>				&vectSwapDeltaGamma,
											const _STL::vector<double>				&flowVolatilities) const;

				virtual void AggregateFxVegas(SSVegaCrossedVega					&outfinalVega) const;

				virtual double GetCurranPrice(	double 							startDate,
												long							endDate,
												double 							strike,
												NSREnums::eVolatilityType		volatilityType,
												const market_data::CSRMarketData				&context) const;

				virtual double GetCurranFlowPrice(	int								isolateNthFlow,
													double 							startDate,
													long							endDate,
													double 							strike,
													int								numberOfPoint,
													NSREnums::eVolatilityType		volatilityType,
													const market_data::CSRMarketData				&context) const;

				static void GetOilRiskSources(	long						startDate,
												long						endDate,
												const CSRCommodity			*commodity,
												long						rollingGap,
												const static_data::CSRCalendar * rollingGapCalendar,
												_STL::set<long>&			inoutRiskFutureCodeArray);

				static bool GetLMERiskSources(	long					startDate,
												long					endDate,
												const CSRCommodity		*commo,
												long					currency,
												static_data::SSMaturity				&rollingMaturity,
												_STL::set<long>&		inoutRiskFutureCodeArray,
												_STL::set<long>&		inoutVegaForSwaptionFutureArray);
				// fills a vector of quotation dates and their weights
				virtual void GetFixingDates(long startDate, long endDate, const static_data::CSRCalendar *calendar, const CSRCommodity *commodity, _STL::vector<DateWeight> &date_list) const{};

				/* The fixed cash amount is the part that corresponds to the "fixedValue" returned by GetTheoreticalValue() on the float leg
				 * It is computed using cash amount, the float leg breakdown factors and the same fixed days as the physical/future leg
				 */
				virtual double GetFixedCashPart(long tag_fixing, const market_data::CSRMarketData &context) const;

				virtual double GetCouponAmountsDeltaGammas(long									tag_fixing,
															long								forexTagFixing, 
															const market_data::CSRMarketData	&context, 
															FixingOutput						*fixedValue    = NULL,
															sophis::commodity::SSDeltaGamma		*outDeltaGamma = NULL) const;

			protected:

				/*
				 * Fills a vector of SSVolVegaData
				 * - if isolateNthFlow is -1 we consider that the swap is used in a swaption and the vector outVolVegaData
				 *		contains all the flows quotation dates of the swap that are greater than today
				 * - otherwise we consider that the swap is used in an asian option and we only fill quotation dates of the flow isolateNthFlow
				 *		 that are greater than today
				 */
				void GetCommodityVolatilityAndVegaData(	int							isolateNthFlow,
														_STL::vector<SSVolVegaData>	&outVolVegaData,
														double 						startDate,
														double						endDate,
														double 						strike,
														NSREnums::eVolatilityType	volatilityType,
														Boolean 					put,
														const market_data::CSRMarketData	&context) const;
				virtual void InitVegaOptimizationFlow(	int										nthFlow,				
												SSVegaCrossedVega&						vegaFlow,
												double 									startDate,
												long									endDate,
												double 									strike,
												NSREnums::eVolatilityType				volatilityType,
												Boolean 								put,
												const market_data::CSRMarketData		&context) const;
				void InitDeltaGammaOptimizationFlow(int									nthFlow,	
													/*out*/ std::map<sophis::CSRRiskSourceDelta, double>& deltaFlow,
													const market_data::CSRMarketData	&context) const;
				/*
				 * this method takes a vector of (future expiry dates, Vega value) as an argument and  
				 * splits the Vega on the Vega futures according to the interpolation weights. It fills a map of (Vega future Code, Vega value)
				 */
				virtual void GetCommodityVega(	long											commodityCode, 
												const _STL::vector<_STL::pair<long, double> >	&inVega, 
												SSVegaCrossedVega								&outVegaMap) const;

			protected:
				CSRBreakDown *fBreakDownPtr ;
				const instrument::CSRSwap *fParentSwap;
				int                       fParentWhichLeg;
			};

			/** Destructor
			*/
			virtual ~CSRFixingType();

			/** Allows one to overload the breakdown generation & valuation
			*/
			virtual CSRFixingTypeImpl* new_Fixing(const instrument::CSRSwap *parentSwap, int whichLeg) const = 0;

			/** Name of the fixing type.
			This will be used in the commodity swap to show the fixing used.
			*/
			virtual const char * GetName() const = 0;

			/** The key for the prototype is a long 
			@see CSRPrototype
			*/
			static _STL::map<eID, int> gFixingTypeMenuPosition;
			struct lessFixingTypePosition
			{
				bool operator()(long x, long y) const
				{
					eID _x = (eID)x;
					eID _y = (eID)y;
					return (gFixingTypeMenuPosition[_x]<gFixingTypeMenuPosition[_y]);
				}
			};

			typedef tools::CSRPrototype<CSRFixingType, long, lessFixingTypePosition> prototype;

			/** Access to the singleton containing all the derived class of CSRFixingType
			It is filled when using the macro INITIALISE_FIXING_TYPE
			*/
			static prototype & GetPrototype();

			/** Clone function used by prototype
			It is generally created by the macro DECLARATION_FIXING_TYPE
			*/
			virtual CSRFixingType * Clone() const = 0;

			/* Get a pointer to the prototype instance corresponding to 'ident'
			 * @param ident : identifies the prototype instance according to eID enumeration
			 * @return a pointer to the prototype instance
			 */

			static const CSRFixingType* GetFixingType(eID ident);

			/* Detects wether the underlying (commodity) is supported by the fixing type
			 * @param code : underlying code (in general commodity code)
			 * @return false when the underlying not supported or true otherwise (true is default, not a garantuee)
			 */

			virtual bool AllowUnderlyingCode(long code) const = 0;

			/* Determines which fixing types can be used in a GSCI bsket
			* returns false by default
			*/
			virtual bool canBeUsedInBasket() const {return false;};

			/* Determines if the B&S pricing should do strike adjustement for the flow
			*/
			virtual bool ModifiedStrikeAdjustment(long today, long flowStartDate, long flowEndDate) const;

			/* When 'true' do not use specific Splitter (option model) in option GUI
			 */
			virtual bool UseInnerOptionModelForGUI() const { return true; }
			
			/* Sophis Macro (internal) */

			DECLARATION_CASTAGE2		
		};

		class SOPHIS_COMMODITY CSRFixingTypeMenu : public gui::CSRPopupMenu
		{
		public:
			CSRFixingTypeMenu(gui::CSRFitDialog	*dialog, 
								int 				ERId_Menu, 
								short 				value=0, 
								const char 				*columnName = kUndefinedField,
								bool isGSCICompoMenu = false);
			CSRFixingTypeMenu(gui::CSREditList	*list, 
								int 		CNb_Menu, 
								short 		value=0, 
								const char 	*columnName = kUndefinedField,
								bool isGSCICompoMenu = false,
								const CSRElement *elemCodeToCheck = NULL);

			void Init();

			virtual USMenu	*DonneMenu(void) const;	// internal
			//virtual void	ValueToString(char *dest, int line) const;
			virtual void	SetValue(const void *value);
			virtual void	GetValue(void *value) const;
			virtual void	SetListValue(short value);

			typedef long value_type;

		protected:
			bool fIsGSCICompoMenu;
			const CSRElement *fElemCommoCode;
			_STL::vector<CSRFixingType::eID> fListFixings;
		};

		SOPHIS_COMMODITY CSRFixingTypeMenu* newCSRFixingTypeMenu(sophis::gui::CSRGenericForm* pForm, int referenceInForm, sophis::gui::CSRElement* pElement = NULL);
	}
}

SPH_END_NOWARN_EXPORT
SPH_EPILOG


#endif
