/*
File:		SphGSCIIndex.h

Contains:	Class for the handling of a GSCI index type.

Copyright:	� 2005 Sophis.
*/


#ifndef __SPHGSCIINDEX_H__
#define __SPHGSCIINDEX_H__


#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/commodity/SphGSCIRollRule.h"

#include "SphInc/commodity/SphDefaultMetaModelCommodity.h"

SPH_PROLOG
namespace sophis {
	namespace commodity {		

		/** Structure to pass parameters for the creation of a GSCI component. */
		struct SOPHIS_COMMODITY SSGSCIComponentCreation
		{
			SSGSCIComponentCreation();

			SSGSCIComponentCreation(const SSGSCIComponentCreation& refComponent);
			SSGSCIComponentCreation& operator =(const SSGSCIComponentCreation& refComponent);			
			bool operator !=(const SSGSCIComponentCreation& refComponent) const;
			bool operator ==(const SSGSCIComponentCreation& refComponent) const;
			bool IsValid(_STL::string*val = NULL) const;
			void Clear();

			long   fSico; /**< Sicovam of the commodity.*/
			long fRank; /**< Rank of the component in the composition.*/
			double fWeight; /**< Weight in the GSCI instrument for current year.*/
			long fCommoFixingColumn; /**< Fixing column for commodity.*/
			long fFxFixingColumn; /**< Fixing column for FX.*/
			long fCommoFixingType; /**< Fixing type for component (ex: for LME -> 3month, ...).*/
			long fShiftMonth;	
			long fDateOfValidity;

			/** Monthly rolling month.
			* It is defined as a char[13] (i.e. a string of 12 characters), representing the month for which the rolling rule 
			* defined in the GSCI Instrument must be applied. Character number i (i.e. at position i-1) is:
			* <ul>
			* <li> equal to 1 if rolling rule apply to month number i (month 1= january, month 2= february, etc ...);</li>
			* <li> equal to 0 otherwise.</li>
			* </ul>
			*/
			char fRollMonth[13];			

			/** Tells if the roll rule applies on month i.
			Calls the static method IsRollMonth with fRollMonth.
			*/
			bool IsRollMonth(unsigned int i) const;

			bool IsRollMonthWellDefined() const;

			/** Set/unset the i-th month as a roll month.

			@param i Month
			@param isRoll If true then the i-th month will be a roll month.
			*/
			void SetRollMonth(unsigned int i, bool isRoll = true);

			//These two functions are used to pass from a set<int> representation of rolling month to its char[13]
			static bool RollMonthDecode(const char* strChars,_STL::set<int>& rollMonth);
			static bool RollMonthEncode(const _STL::set<int>& rollMonth,_STL::string& strChars);

		protected:
			/** Tells if the roll rule applies on month i.*/
			static bool IsRollMonth(unsigned int i, const _STL::set<int>& rollMonth);
			static bool IsRollMonth(unsigned int i, const char* rollMonth);
		};
		
		/** Base class for GSCI indexes's components.
		*
		* A component is defined by:
		* - the sicovam of the commodity
		* - the weights of the commodity in the GSCI index
		* - for LME commodities, a fixing type must be set (LME Cash, LME 3 month)
		*/
		class SOPHIS_COMMODITY CSRGSCIComponent
		{
		protected:
			CSRGSCIComponent(const SSGSCIComponentCreation& component);
			void Initialize(const SSGSCIComponentCreation& component);
			
		public:			
					
			/** Factory to create instances of CSRGSCIComponent.*/
			static CSRGSCIComponent* CreateInstance(const SSGSCIComponentCreation& newComponent, long dateofvalidity = 0, _STL::string *error = NULL);

			CSRGSCIComponent(); // internal
			virtual ~CSRGSCIComponent();
 
			/** Constructor by copy.*/
			CSRGSCIComponent(const CSRGSCIComponent& component);
		protected:
			void Initialize(const CSRGSCIComponent& component);
				
		public:
			const SSGSCIComponentCreation& GetSSGSCIComponentCreation() const;
			bool SetSSGSCIComponentCreation(const SSGSCIComponentCreation& componentStructure, _STL::string *error = NULL);
			
			//Access methods to protected members

			/** Gives the component's sicovam.			
			@return the component's sicovam.
			*/
			long GetSicovam() const;

			/** Gives the component's rank			
			@return the component's rank.
			*/
			long GetRank() const;

			double GetWeight() const;
			void SetWeight(double value);			
			long GetCommoFixingColumn() const;
			long GetFxFixingColumn() const;			
			long GetCommoFixingType() const;			
			long GetShiftMonth() const;
			long GetDateOfValidity() const;	
			void SetDateOfValidity(long date);
			//const _STL::set<int>& GetRollMonth() const;

			/** Tells if the roll rule applies on month i.*/
			bool IsRollMonth(unsigned int i) const;

			/** Validate all the component's defintions.
			
			@param[out] error A string in which will be stored the error description if any occurs.
			@return true if the component is valid, false otherwise.
			*/
			virtual bool Validate(_STL::string *error) const;

		protected:

			SSGSCIComponentCreation fSSComponent;
			//_STL::set<int> fRollMonth;

		public:
			virtual CSRGSCIComponent* Clone() const;

			/** Comparison operator.*/			
			bool operator<(const CSRGSCIComponent& refComponent )const;
			bool operator==(const CSRGSCIComponent& refComponent )const;
			bool operator!=(const CSRGSCIComponent& refComponent )const;

			//void GetSSGSCIComponentCreation(SSGSCIComponentCreation& componentStructure) const;

		};


		class SOPHIS_COMMODITY CSRGSCIComponentOil : public virtual CSRGSCIComponent
		{
			friend class CSRGSCIComponent;
			CSRGSCIComponentOil(const SSGSCIComponentCreation& component);
		public:
			/** Constructor by copy.*/
			CSRGSCIComponentOil(const CSRGSCIComponentOil& component);
		protected:
			CSRGSCIComponentOil();
			void Initialize(const SSGSCIComponentCreation& component);
			void Initialize(const CSRGSCIComponentOil& component);
		public:
			virtual CSRGSCIComponent* Clone() const;

		};

		class SOPHIS_COMMODITY CSRGSCIComponentCur : public virtual CSRGSCIComponent
		{			
		protected:
			friend class CSRGSCIComponent;
			CSRGSCIComponentCur(const SSGSCIComponentCreation& component);
			CSRGSCIComponentCur();
			void Initialize(const SSGSCIComponentCreation& component);
			void Initialize(const CSRGSCIComponentCur& component);
		public:
			/** Constructor by copy.*/
			CSRGSCIComponentCur(const CSRGSCIComponentCur& component);
			virtual CSRGSCIComponent* Clone() const;
		};

		class SOPHIS_COMMODITY CSRGSCIComponentLME : public virtual CSRGSCIComponent
		{
		protected:
			friend class CSRGSCIComponent;
			CSRGSCIComponentLME(const SSGSCIComponentCreation& component);
			CSRGSCIComponentLME();
			void Initialize(const SSGSCIComponentCreation& component);
			void Initialize(const CSRGSCIComponentLME& component);
		public:				
			/** Constructor by copy.*/
			CSRGSCIComponentLME(const CSRGSCIComponentLME& component);
			virtual CSRGSCIComponent* Clone() const;
		};		

		/** Class to manage Commodity indexes's compositions.

		This class essentially wrap a map of composition definitions (instances of {@link CSRCommodityIndexCompositionDefinition}), indexed by their date of validity.
		It enable to define a scheduling for the evolution of the index's composition.
		*/		
		class CSRGSCIIndex;			
		class  SOPHIS_COMMODITY CSRGSCIComposition
		{
		protected:
			CSRGSCIComposition();
			CSRGSCIComposition(const CSRGSCIComposition& refCompo);
			CSRGSCIComposition(long lIndexCode, long dateofvalidity=0);
			void Initialize(const CSRGSCIComposition& refCompo);
			void Initialize(long lIndexCode, long dateofvalidity=0);
			CSRGSCIComposition& operator=(const CSRGSCIComposition& refCompo);
		public:

			class SOPHIS_COMMODITY CompositionDependancyException : public sophisTools::base::GeneralException
			{
			public: 
				CompositionDependancyException(const char *msg, long indexCode, const _STL::set<long> & sicos);
				_STL::set<long>		fSicos;
				long				fIndexCode;
			};			

			static CSRGSCIComposition* CreateInstance(long lIndexCode, long lParentCode, long dateofvalidity);

			//Constructors						
			virtual CSRGSCIComposition*  Clone() const;
			virtual CSRGSCIComposition*  Duplicate() const;

			//Desctructor
			virtual ~CSRGSCIComposition();

			/** Returns a reference to the GSCI index object associated to the composition, as a const reference on a {@link CSRInstrument}.*/
			const CSRGSCIIndex* GetInstrument() const;

			/** Returns a reference to the GSCI index object of the parent Index, as a const reference on a {@link CSRInstrument}.
			* Returns NULL if the index has no parent.
			*/
			virtual const CSRGSCIIndex* GetParentInstrument() const;
			virtual const CSRGSCIComposition* GetParentComposition() const; 

			virtual bool Validate(_STL::string &error) const
				throw (CompositionDependancyException);

			//Acccess Methods
			/** Returns/set the SICOVAM code of the GSCI index. */
			long GetIndexCode() const;
			void SetIndexCode(long code);

			/** Returns/set the SICOVAM code of the Parent index. */
			virtual long GetParentIndexCode() const;
			virtual void SetParentIndexCode(long code);
			
			long GetDateOfValidity() const;
			void SetDateOfValidity(long date);

			double GetNormalizationConstant() const;
			void SetNormalizationConstant(double value);

			/** Returns the number of Components (= number of commodity) in the composition. */
			unsigned int GetComponentsCount() const;

			/** Tells if a commodity is in the composition. */
			bool IsPartOfComposition(long commoditySico, int rank = 0, int *outPos = NULL) const;		
			bool IsPartOfComposition(const SSGSCIComponentCreation& component, int *outPos = NULL) const;
			bool IsPartOfComposition(const CSRGSCIComponent& refComponent, int *outPos = NULL) const;

			/** Tells if a given component definition is different from its version stored in the composition.
			The component's definitions are compared using the == operator defined on the SSGSCIComponentCreation structure.

			@param sComponent Component definition structure of the component to compare.
			@param iPos Index of the component to compare. The default value is -1. If iPos is negative, then
					the method will try to find the component in the composition using the IsPartOfComposition method.
			@return TRUE if the component belongs to the composition AND is different from the definition given in parameter, FALSE otherwise.
			*/
			virtual bool ComponentDefinitionChanged(const SSGSCIComponentCreation& sComponent, int iPos = -1) const;
		
			/** Returns the i-th component of the composition. */
			virtual const CSRGSCIComponent & GetComponent(unsigned int i) const
					throw (sophisTools::base::IndexOutOfBoundsException);

			virtual CSRGSCIComponent* GetComponent(unsigned int i);
			
			/** Returns the component of sico {@var sico} of the composition. */
			virtual const CSRGSCIComponent* GetComponentBySico(long sico, int* outPos = NULL) const;

			/** Clears the whole composition. */
			virtual void Clear(bool all = false);

			/** Comparison operator.*/
			virtual bool operator==(const CSRGSCIComposition& refComposition )const;
			virtual bool operator!=(const CSRGSCIComposition& refComposition )const;
			
			const CSRGSCIComponent& AddComponent(const SSGSCIComponentCreation& newComponent)
				throw(sophisTools::base::InvalidParameter);

			void EraseComponent(const CSRGSCIComponent& refComponent);
			virtual void EraseComponent(const SSGSCIComponentCreation& refComponent);
			CSRGSCIComponent* SetComponent(const CSRGSCIComponent& refComponent, bool &created, _STL::string *error = NULL);
			virtual CSRGSCIComponent* SetComponent(const SSGSCIComponentCreation& newComponent, bool &created, _STL::string *error = NULL);
			virtual void LinkComponent(CSRGSCIComponent* pComponentNew, const CSRGSCIComponent* pComponentOld = NULL);	
	
			void SetParentInstrumentHisto(const CSRGSCIIndex* pIndex);
		protected:

			long fIndexCode; /**< Sicovam of the GSCI Index. */			
			_STL::vector<CSRGSCIComponent*> fComponents;

			double fNormalizationConstant;			
			long fDateOfValidity;

			//History management
			const CSRGSCIIndex* fParentInstrumentHisto;
		};		

		class  SOPHIS_COMMODITY CSRGSCICompositionSubIndex : public virtual CSRGSCIComposition
		{
			friend class CSRGSCIComposition;
		protected:
			CSRGSCICompositionSubIndex();
			CSRGSCICompositionSubIndex(long lIndexCode, long lParentCode, long dateofvalidity=0);
			CSRGSCICompositionSubIndex(const CSRGSCICompositionSubIndex& refCompo);
			void Initialize(long lIndexCode, long lParentCode, long dateofvalidity=0);
			void Initialize(const CSRGSCICompositionSubIndex& refCompo);

		public:			
			virtual CSRGSCIComposition* Clone() const;
			virtual ~CSRGSCICompositionSubIndex();

			/** Returns/set the SICOVAM code of the Parent index. */
			virtual long GetParentIndexCode() const;
			virtual void SetParentIndexCode(long code);

			/** Tells if a given component definition is different from its version stored in the composition.
			The component's definitions comparison is only based on the sico's comparison. This means that subindexes compositions are static, 
			and do not depend on time.

			@param sComponent Component definition structure of the component to compare.
			@param iPos Index of the component to compare. The default value is -1. If iPos is negative, then
			the method will try to find the component in the composition using the IsPartOfComposition method.
			@return TRUE if the component belongs to the composition AND is different from the definition given in parameter, FALSE otherwise.
			*/
			virtual bool ComponentDefinitionChanged(const SSGSCIComponentCreation& sComponent, int iPos = -1) const;

			/** 

			This method adds some subindex specific checks before setting/adding the component calling the {@link CSRGSCIComposition::SetComponent} method.
			*/
			CSRGSCIComponent* SetComponent(const SSGSCIComponentCreation& newComponent, bool &created, _STL::string *error = NULL);

			/** Returns the i-th component of the composition. */
			virtual const CSRGSCIComponent & GetComponent(unsigned int i) const
				throw (sophisTools::base::IndexOutOfBoundsException);			

		protected:
			long fParentIndexCode; /**< Sicovam of the Parent Index. */
		};
		
		class SOPHIS_COMMODITY CSRCommodityIndexCompositionSchedule
		{
		public:
			CSRCommodityIndexCompositionSchedule();
			CSRCommodityIndexCompositionSchedule(const CSRCommodityIndexCompositionSchedule& refCompo);
			CSRCommodityIndexCompositionSchedule& operator=(const CSRCommodityIndexCompositionSchedule& refCompo);			
			virtual bool operator==(const CSRCommodityIndexCompositionSchedule& refCompo) const;
			virtual bool operator!=(const CSRCommodityIndexCompositionSchedule& refCompo) const;

			/** Parameter for search of re-weighting date: first date after (eNext) or last date after (ePrevious).*/
			enum eSearchDirection
			{
				ePrevious,
				eNext
			};

			/** Destructor.
			This will clear the schedule, deleting all the CSRGSCIComposition instances in the map fCompositionDefinitions.
			*/
			virtual ~CSRCommodityIndexCompositionSchedule();

			/** Clone a whole composition schedule.
			This method clone every pointer involved in the schedule (i.e. pointer on CSRGSCIComposition or CSRGSCIcomponent instances).
			The calling object is first cleared.

			@param[out] refCompoSchedule The composition schedule which will receive the duplicated data.			
			*/
			virtual void Clone(CSRCommodityIndexCompositionSchedule& refCompoSchedule) const;

			/** Clear the composition schedule.
			If the parameter {@var all} is TRUE then one will fully clear the schedule: delete composition definitions AND erase definitions dates.
			If {@var all} is FALSE, then only the composition definitions will be deleted and set to NULL, the dates will be kept unchanged.
			The default behavior is to fully clear the schedule ({@var all}=TRUE).
			@param all Boolean to specify if one has to fully clear the schedule.
			*/
			virtual void Clear(bool all = true);

			/** Loads data from database.

			@param sico Commodity Index's sico.
			@param parentsico Parent index's sico.
			@param sicoIsHisto Flag to specify if the index's sico (@var sico) is to be read in the main or histo table.
			@return TRUE if data were correctly loaded, FALSE otherwise.
			*/
			bool LoadDataFromDB(const CSRGSCIIndex* pIndex);

			/** Sets the normalization constant at date {@var date}.
			The date must be one of the schedule's date of validity, otherwise nothing is done.

			@param date Date at which the normalization constant must be set.
			@param value Normalization constant at data {@var date}.
			*/
			void SetNormalizationConstant(long date, double value);
			
			/** Gives the historical date until which the schedule's definition is valid.
			This date is set when data is loaded from database. It comes from the Commodity Index used to load data.
			@return the historical date.
			*/
			double GetDateHisto() const { return fDateHisto; };

			/** Gives the main SICO of the owning Commodity Index.
			@return the main SICO.
			*/
			long GetIndexCode() const;

			/** Set the main SICO of the owning Commodity Index.
			@param sico Main SICO of the Commodity Index.
			*/
			void SetIndexCode(long sico);

			/** Give the main SICO of the owning Commodity Index's parent.
			The SICO is the original one. It is never historical, even if the owning Commodity Index or it's parent is historical.
			To retrieve the right version of the parent, use the {@link GetParentInstrument} method.

			@return the main SICO of the owning Commodity Index's parent.
			*/
			long GetParentIndexCode() const;

			/** Set the main SICO of the owning Commodity Index's parent.
			The parameter {@var sico} must be the original SICO, even if the owning Commodity Index or it's parent is historical.
			After setting the main sico, use the {@link GetParentInstrument} method to retrieve the right version of the parent.

			@param sico Main sico of the owning Commodity Index's parent.
			*/
			void SetParentIndexCode(long sico);				

			/** Returns an instance of the owning Commodity Index's parent.
			The instance returned is the right version of the parent, so that it may be an historical instrument, valid at some historical date.
			@return a const pointer on the Commodity Index's parent.
			*/
			const sophis::commodity::CSRGSCIIndex* GetParentInstrument() const;

			/** Updates/Adds a component definition to the composition schedule.

			@param sComponentToSet The component to be updated/added.
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).
			*/
			virtual bool SetComponent(const SSGSCIComponentCreation& sComponentToSet, _STL::string *error = NULL);

			/** Tells the number of definitions dates where a given component is null weighted.

			@param sComponent The defining structure of the component.
			@return The number of dates where the component is null weighted.
			*/
			int ComponentNonNullWeightedCount(const SSGSCIComponentCreation& sComponent, long *dateOne = NULL) const;

			/** Tells if a given component is null weighted on the whole composition schedule.

			@param sComponent The defining structure of the component.
			@return True if the component is null weighted in the whole composition schedule, false otherwise.
			*/
			bool ComponentIsNullWeighted(const SSGSCIComponentCreation& sComponent) const;

			/** Cleans the composition schedule, leaving it free from useless null weighted components.
			@return True if everything went well, false otherwise.
			*/
			void CleanCompositionSchedule();

			/** Add a composition definition date.
			If some composition definition already exists, then 

			@param date The defintion's date of validity.
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).
			*/
			virtual bool AddCompositionDefinition(long date, _STL::string *error = NULL);

			/** Add a composition definition date, associated with a normalization constant.
			If some composition definition already exists, then 

			@param date The defintion's date of validity.
			@param value The value of the definition's normalization constant.
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).
			*/
			bool AddCompositionDefinition(long date, double value, _STL::string *error = NULL);			

			/** Add a whole composition definition.

			@param pCompo A pointer on a {@link CSRGSCIComposition} instance.			
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).

			@uses CSRGSCIIndex::SetComponent
			*/
			virtual bool AddCompositionDefinition(long date, const CSRGSCIComposition* pCompo, _STL::string *error = NULL);

			/** Removes a component form the composition schedule.
			After this, you should called the {@see CleanCompositionSchedule} method, to clean the schedule from useless null weighted components.

			@param refComponent The component to be removed.
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).
			*/
			bool RemoveComponent(const SSGSCIComponentCreation &sComponentToDelete, _STL::string *error = NULL);			

			/** Removes a composition definition at a given date.
			This will remove the whole definition at date {@var date}, keeping consistency of the whole composition schedule.

			@param date Date of validity of the composition to be removed. It mus be the exact date of validity.
			@param[out] error A pointer on a string that will contain errors that may occur.
			@return True if everything went well, false otherwise (then {@var error} will contain the error).
			*/			
			bool RemoveCompositionDefinition(long date, _STL::string *error = NULL);

			/** Give the set of re-weighting dates of the whole composition.*/
			void GetDefinitionDatesAndConstants(_STL::map<long, double> &outDefinitionDates) const;

			/** Gives the number of changes in the composition.
			@return the number of dates when occurs changes in composition.
			*/
			unsigned int GetDefinitionDatesCount() const;

			/** Get the date when composition changes.

			@param date The search starting date.
			@param searchDirection Which way the search is performed.
			@return the changing date.
			*/
			virtual long GetNearByDefinitionDate(long date = 0, eSearchDirection searchDirection = ePrevious) const;

			/** Returns the composition valid at a given date. */
			const CSRGSCIComposition* GetNearByDefinition(long date = 0, long *dateDefinition = NULL, eSearchDirection searchDirection = ePrevious) const;

			const _STL::map<long, CSRGSCIComposition*>& GetCompositionList() const;
			_STL::map<long, CSRGSCIComposition*>& GetCompositionList(){return fCompositionDefinitions;}
			/** Returns the composition defined at a given date. */
			virtual const CSRGSCIComposition* GetDefinition(long date = 0, long *dateNext = NULL) const;

			/** Flag the composition schedule as modified.
			@param state The new state.
			*/
			void SetModified(bool state);

			/** Tells if the composition schedule has been modified.
			@return TRUE if the composition has been modified.
			*/
			bool IsModified() const;

			/* access to internal data structure */
			const _STL::map<long, CSRGSCIComposition*> & GetCompositionDefinitions() const;

		protected:
			/** 
			@param date Date of validity at which one wants to retrieve the composition.
			@param[out] nextDate Next date of validity.
			*/
			virtual CSRGSCIComposition* GetDefinition(long date = 0, long *nextDate = NULL);
			virtual CSRGSCIComposition* GetNewDefinition(long date) const;

			bool IsHistorical() const;

		private:			

			long fSicoIndex;
			long fSicoParentIndex;
			_STL::map<long, CSRGSCIComposition*> fCompositionDefinitions;

			//History management			
			double fDateHisto;
			void SetDateHisto(double value);

			/** Temporary variable (cache for performance of CSRCommodityIndexCompositionSchedule::GetParentInstrument)
			*/
			const CSRGSCIIndex* fParentInstrumentHisto;

			/** Flag that tells if the composition was modified.*/
			bool fIsModified;
		};



		/* Container for the contracts list*/
		class SOPHIS_COMMODITY CSRGSCI_Contracts
		{
		public:
			long GetID(long component, long firstOfMonth) const;

			void SetID(long component, long firstOfMonth, long code);

			bool IsEmpty(long component) const;

			_STL::map<long, _STL::map<long, long> > futuresList;
		};


		struct OneFixingWithValue;
		struct SSCommodityIndexCalculationDetails
		{
			//SSCommodityIndexCalculationDetails();			
			//void Clear();

			long fDateOfCalculation;
			long fFixingFutureShift;
			int fNbFutures;
			int fNbComponents;			
			bool fInRollPeriod;
			long fNextRollPeriodBegin;
			long fNextRollPeriodEnd;
			bool fInReweightingPeriod;
			long fLastReweightingDate;
			_STL::map<long, _STL::vector<OneFixingWithValue> > fDetailFuture;
			double fPrice;
			double fPriceHisto;
			double fTheoreticalValue;
		};


		class SOPHIS_COMMODITY CSRDefaultMetaModelGSCIIndex : public virtual finance::CSRDefaultMetaModelCommodity
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelGSCIIndex);

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const;

		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelGSCIIndexSpot : public virtual CSRDefaultMetaModelGSCIIndex
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelGSCIIndexSpot);

		public:
			virtual	void	GetLinearValue(	const instrument::CSRInstrument & instr,
											double computationDate,
											long   futureDate,
											sophis::instrument::eSettlementType settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 			*a,
											double 			*b,
											double 			*rate,
											const market_data::CSRMarketData& context) const; 

		};

		/** Abstract base class for all GSCI indexes: SPOT, ER, TR. 
		The class is abstract because it doesn't define the {@link CSRCommodity::GetCommodityType()} method.
		*/
		class SOPHIS_COMMODITY CSRGSCIIndex : public virtual CSRCommodity
		{						
			
		public:
			//MACRO for declaration of automatic constructor CSRGSCIIndex(const DTitrePlus *titre)
			DECLARATION_COMMODITY(CSRGSCIIndex)		
		
		protected:
			/** Get the default meta model.
			This is called by all basic methods invoking calculations to get the default model.
			@return a pointer which must not be deleted.
			By default, return a pointer on a CSRDefaultMetaModelGSCIIndex.
			@since 7.0
			*/
			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;

		public:		
			/** Destructor.
			*/
			virtual ~CSRGSCIIndex();			

			const char *GetXMLRootName() const;

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			void ResetComposition();

			/** Get the internal structure specific to CSRCommodity objects.
			@return A const pointer on the internal structure ({@link CSRCommodity::SSCommodityInstrument}).
			*/
			virtual const SSCommodityInstrument* GetSSCommodity() const;

			/** Get the instance of the current parent index.
			@return A const pointer on the parent calling the {@link CSRInstrument::GetInstance} method (NULL if parent is not defined).
			*/
			const CSRGSCIIndex* GetParentInstance() const;

			virtual CSRCommodity::eWorksheetType GetWorksheetType(int whichPairing) const;

			/** Set the sico of index's parent instrument.
			@param sico The sico of the index's parent instrument.
			*/
			void SetParentCode(long sico);

			const CSRCommodityIndexCompositionSchedule& GetCompositionSchedule() const;

			/**Set the index's whole schedule.
			This method copy the schedule passed in parameter.

			@param refCompo The schedule to be copied.
			@return TRUE if the index's schedule was modified by the copy, FALSE other wise.
			*/
			bool SetCompositionSchedule(const CSRCommodityIndexCompositionSchedule& refCompo)
				throw(sophisTools::base::InvalidParameter);

			/** Get the index's composition definition at a given date.
			@return A const pointer on the {@link CSRGSCIComposition} instance of the index's composition.
			*/
			virtual const CSRGSCIComposition* GetComposition(long date = 0, long* defDate = NULL, CSRCommodityIndexCompositionSchedule::eSearchDirection searchDirection = CSRCommodityIndexCompositionSchedule::ePrevious) const;

			/** Get the number of components in the index.
			NB: if the composition has not been loaded yet, this method will return 0.
			@return Number of components in the index.
			*/
			virtual unsigned int GetComponentsCount(long date = 0) const;

			/** Returns a pointer on an Index composition as a {@link CSRGSCIComposition} instance.
			The returned composition will be associated to the index and can be loaded on demand via the {@var loadNow} parameter.
			To make the composition returned be the actual index's composition, you need to attach it to the index using the
			{@link AdoptComposition} method.

			@param loadNow A boolean specifying if the composition must be loaded before returning the pointer.
			*/
			virtual CSRGSCIComposition* GetNewComposition( long date ) const;
			
			/** Tells if the component with sico {@var sicoCommo} is part of the composition of any sub-index of the GSCI index.
			@param sicoCommo The sico of the commodity to test.
			@param vOutSicoSubindex[out] A pointer on a vector which will be filled with the sicos of the index's sub-indexes that use the commodity.
			@return Number of the index's sub-index using the commodity in its composition.
			*/
			unsigned int ComponentIsUsedBySubIndex(long sicoCommo, long date, _STL::set<long>* setOutSicoSubindex = NULL) const;			

			/** Give all the sicovam of the index's sub-indexes.
			@param vOutSicoSubindex[out] A pointer on a vector which will be filled with the sicos of the index's sub-indexes.
			@return Number of the index's sub-index.
			*/
			unsigned int GetAllSubIndexes(_STL::set<long>* setOutSicoSubindex = NULL) const;


			/** Tells if the GSCI index is a sub-index of the instrument of code {@var sico} (if sico is zero it tells if its is a sub-index).
			@param sico The sico of the index to test.
			@return TRUE or FALSE.
			*/
			bool IsSubIndexOf(long sico = 0) const;


			/** Creates a new CSRGCSIIndex instance according to the model field contained in {@var titre} and returns a pointer on it.
			Model field in {@var titre} can be: Commodity Index.
			The pointer returned needs to be deleted when work is done.
			@param titre A pointer on a DTitrePlus.
			@return A pointer on a CSRGSCIIndex instance (NULL if the field titre->titre->model is not a GSCI model).
			@version 5.2.4
			*/
			static CSRGSCIIndex* CreateInstance(const DTitrePlus *titre);

			/** Creates a new CSRGCSIIndex instance as valid at a given date.			
			The pointer returned needs to be deleted when work is done.

			@param sico Main sico of some Commodity Index.
			@param date Date at which the index definition is valid.
			@return A pointer on a CSRGSCIIndex instance (NULL if the field titre->titre->model is not a GSCI model).
			@version 5.2.4
			*/
			static const CSRGSCIIndex* CreateInstance(long sico, double date = 0, const char* model = NULL);

			//Model name: will be set to "GSCI"
			static const char * MODEL_NAME;			

			/** Get the current valid normalization constant (used for pricing the index AFTER the re-weighting date {@link CSRGSCIIndex::GetWeightChangeDate}).
			@return the normalization constant.
			*/
			virtual double GetNormalizationConstant(long date = 0,  long *dateDefinition = NULL, CSRCommodityIndexCompositionSchedule::eSearchDirection searchDirection = CSRCommodityIndexCompositionSchedule::ePrevious ) const;
						
			/** Get the re-weighting date, i.e. the date when weights of composition change.
			@return the re-weighting date.
			*/
			virtual long GetWeightChangeDate() const;
			
			/** Get the GSCI roll rule ID used in the monthly roll period.
			The possible values for this ID are described by the {@link CSRGSCIRollRule::eRollRuleIDRange} enum.
			@return the GSCI roll rule ID.
			*/
			virtual long GetRollRuleId() const;			

			/** Add a normalization constant definition, with its date of validity.

			@param date Date of validity of the constant. This constant value will be used for pricing after {@var date}.
			@param value Normalization constant.
			*/
			virtual void SetNormalizationConstant(double value, long date = 0);

			/** Set the re-weighting date, i.e. the date when weights of composition change.
			@param date The re-weighting date to set.
			*/
			//virtual void SetWeightChangeDate(long date);

			/** Set the GSCI roll rule ID used in the monthly roll period.
			The possible values for this ID are described by the {@link CSRGSCIRollRule::eRollRuleIDRange} enum.
			@param id The id of the roll rule to set.
			*/
			virtual void SetRollRuleId(long id);

			/** Get the GSCI roll rule.			
			The roll rule is search for the roll rule id in the static roll rule list {@link CSRGSCIRollRule::fRulesList}.
			@return the GSCI roll rule, NULL if the roll rule was not found.
			*/
			virtual const CSRGSCIRollRule* GetRollRule() const;

			/** Get the roll weight to apply to future F1 at date {@var date}.
			It calls the {@use CSRGSCIRollRule::GetWeight} method of the index's roll rule.
			@param date The date the roll weight is to be retrieved.
			@return the weight of F1.
			*/
			virtual double GetRollWeight(long date) const;

			/** Get the begin and end dates of the next/last roll period.

			@param date Start date for the search.
			@param[out] startDate Begin date of the roll period.
			@param[out] endDate End date of the roll period.
			@param searchDirection Direction for the search.
			*/
			void GetNearByRollPeriod(long date, long *startDate, long *endDate = NULL, CSRGSCIRollRule::eSearchDirection searchDirection = CSRGSCIRollRule::eNext) const;			

			virtual void DeleteCompositionInDB() const
				throw(sophisTools::base::InvalidInvocationState, sophisTools::base::DatabaseException);
			virtual void SaveCompositionInDB(long sico_histo) const
				throw(sophisTools::base::InvalidInvocationState, sophisTools::base::DatabaseException);

			virtual void	FillFutureList();
		protected:

			/** Load the data of the GSCI index (instrument data, composition).*/
			virtual bool LoadSpecificData();

			CSRCommodityIndexCompositionSchedule& InnerGetCompositionSchedule();

		public:
			
			virtual bool IsACommodityBasket() const { return true; };

			/** Tells if the index is historical.
			@return TRUE if the index was loaded for audit view or past prices date, FALSE otherwise.
			*/
			virtual bool IsHistorical() const;

			/** Tells if the sico to load is a main sico or an historical sico.*/
			virtual bool SicoToLoadIsHisto() const;

			virtual bool CanModify() const { return !IsHistorical(); }

			/** Get the historical date at which the index was loaded.
			@return The historical date (a null date means the object is the current version of the index).
			*/
			virtual double GetDateHisto() const { return fDateHisto; }

			//static methods
			/** Tells if a model is relative to a GSCI instrument.
			@param modelName The name of the model to be tested.
			@return true if the model is relative to a GSCI instrument (GSCI Spot, GSCI ER, GSCI TR).
			*/
			static bool IsGSCIModel(const char* modelName);

			/** Tells if a titre has a model relative to a GSCI instrument.
			@param titre A DTitre.
			@return true if the model field in {@var titre} is relative to a GSCI instrument (GSCI Spot, GSCI ER, GSCI TR).
			*/
			static bool IsGSCIModel(const DTitre* titre);

			/** Get the static list of models' names relative to GSCI instruments.
			@return a vector of _STL::string containing the models' names.
			*/
			static const _STL::vector<_STL::string>& GetModelsList();

			/** Add a new model to the static list of models relative to GSCI instruments.
			@param newModel : the name of the model to be added.
			*/
			static void AddModel(const _STL::string& newModel);


			//Inherited method from CSRInstrument

			/** Get the market ID.
			@return the market ID (of the quotation currency). For subindex, it returns the parent's market ID.						
			*/
			virtual long GetMarketCode() const;

			/** Reset the index sico.
			This method calls {@link CSRInstrument::SetCode} and update the index's sico stored in the index's composition associated object.
			@param code is the sico to set.
			*/
			virtual void SetCode(long code);

			/** Duplicate specific data of a GSCI index (composition).
			*/
			virtual void DuplicateData(const CSRInstrument &instrument);

			virtual double GetTheoreticalValue(const market_data::CSRMarketData& context, long dayCalculation) const;						
			virtual double GetTheoreticalValueWithDetails(long dayCalculation, const market_data::CSRMarketData* context = NULL, long fixingFutureShift = 0, SSCommodityIndexCalculationDetails* pDetails = NULL) const;

			virtual long GetDesignatedContract(long componentCode, short mm, short yy) const;
			virtual void SetDesignatedContract(long componentCode, short mm, short yy, long codeContract);
			virtual const CSRGSCI_Contracts *GetContractsList(void) const;
			virtual void SetContractsList(const CSRGSCI_Contracts *contractsList);
			virtual bool IsContractsListActive(long component) const;
			int GetNbWksheetContracts(void);
			void ClearDesignatedContractsList(void);

			virtual long GetSicoToLoad() const { return fSicoToLoad; }

			virtual bool ConstructAgain(void) const;

			/**
			*	ISRProductTypeSubject interface implementation.
			**/
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;

			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

		protected:			
			
			static _STL::vector<_STL::string> fModelsList;

			/** id of the roll rule **/
			long fRollRuleId;

			/** Composition object which contains the components of the GSCI Index (the commodities).*/			
			CSRCommodityIndexCompositionSchedule fCompositionSchedule;			

			/** Sico that must be actually loaded (may be a main or an historical sico).*/
			long fSicoToLoad;
			double fDateHisto;

			CSRGSCI_Contracts fContractsList;

			/** Flag to specify if calculation of price at historical dates should compute the historical theoretical value.
			This flag DO NOT change the result given by the GetTheoreticalValue methods which always are historical values.
			It only force the breakdown computation at any date.
			*/
			mutable bool fComputeTheoreticalHisto;
		public:

			void SetComputeTheoreticalHisto(bool val) const;
			bool MustComputeTheoreticalHisto() const;

			static const char* COMPONENTS_TABLE_NAME;
			static const char* INFOS_TABLE_NAME;

			static void InitModels();

		protected:
			short fVolatilityVersion;
			_STL::map<long, short> fCommoVersions; // Version by commo (instrument) code for GSCI Spot

		public:
			void GetCommoditiesOfIndex(_STL::set<long> &outCodes) const;
		};		

		/** Class for GSCI Spot index.
		*/
		class SOPHIS_COMMODITY CSRGSCIIndexSpot : public virtual CSRGSCIIndex
		{

		public:
			//MACRO for declaration of automatic constructor CSRGSCIIndexSpot(const DTitrePlus *titre)
			DECLARATION_COMMODITY(CSRGSCIIndexSpot)			

			virtual ~CSRGSCIIndexSpot();

			//From CSRInstrument
			virtual CSRInstrument * Clone() const;

			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;

			virtual bool	HasAFormulaForSpot() const;
			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData& context) const;


			//From CSRCommodity
			/** Returns the commodity type {@link sophis::commodity::eGSCISpot}.*/
			virtual CSRCommodity::eCommodityType GetCommodityType() const;

			/** Model name. It will be set to "GSCI Spot". */
			static const char * MODEL_NAME;

		protected:
		};


		class SOPHIS_COMMODITY CSRDefaultMetaModelGSCIIndexER : public virtual finance::CSRDefaultMetaModelCommodity
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelGSCIIndexER);
			virtual ~CSRDefaultMetaModelGSCIIndexER();

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument & instr,
											double computationDate,
											long   futureDate,
											sophis::instrument::eSettlementType settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 			*a,
											double 			*b,
											double 			*rate,
											const market_data::CSRMarketData& context) const OVERRIDE;

			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_COMMODITY CSRDefaultMetaModelGSCIIndexTR : public virtual CSRDefaultMetaModelGSCIIndexER
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelGSCIIndexTR)

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE; 
		};

		/** Class for GSCI ER.
		*/
		class SOPHIS_COMMODITY CSRGSCIIndexER : public virtual CSRCommodity
		{
		
		public:			
			//MACRO for declaration of automatic constructor CSRGSCIIndexSpot(const DTitrePlus *titre)
			DECLARATION_COMMODITY(CSRGSCIIndexER)	

		protected:
			/** Get the default meta model.
			This is called by all basic methods invoking calculations to get the default model.
			@return a pointer which must not be deleted.
			By default, return a pointer on a CSRDefaultMetaModelGSCIIndexER.
			@since 7.0
			*/
			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;
		public:
			const CSRGSCIIndex* GetParentInstance() const;

			static CSRGSCIIndexER* CreateInstance(const DTitrePlus *titre);

			//Overrides of CSRInstrument (link to the parent's methods)
			virtual long GetMarketCode() const;			

			/** GetReturnYieldFamily()
			* @return the yield curve family id (long) used in the ER/TR calculation (returns 0 if the index has no family (e.g. in the ER case))
			*/
			virtual long GetReturnYieldFamily() const;
			
			virtual ~CSRGSCIIndexER();

			void SetParentCode(long sico);

			void SetApplyCalculatedValue(short value);
			short GetApplyCalculatedValue() const;

			//From CSRInstrument
			virtual CSRInstrument * Clone() const;			

			//From CSRCommodity
			/** Returns the commodity type {@link sophis::commodity::eGSCIER}.*/
			virtual CSRCommodity::eCommodityType GetCommodityType() const;
			virtual bool IsACommodityBasket() const { return true; };

			/** Model name. It will be set to "GSCI ER". */
			static const char * MODEL_NAME;		

			virtual eWorksheetType GetWorksheetType(int whichPairing) const;

			virtual double GetTheoreticalValue(const market_data::CSRMarketData& context, long dayCalculation) const;						

			virtual bool	HasAFormulaForSpot() const;
			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData& context) const;
			virtual bool ConstructAgain(void) const;
			virtual void	FillFutureList();

			//virtual void	InitialiseRecomputeAll();
			//virtual int		GetUnderlyingCount() const;
			//virtual long	GetUnderlying(int whichUnderlying) const;
			//virtual int		GetRhoCount() const;
			//virtual long	GetRhoCurrency(int whichUnderlying) const;


			virtual double	GetQuotity(bool withTaxes) const { return 1.; };
			virtual sophis::instrument::CSROption* new_Splitter(sophis::instrument::CSROption* option, bool optionInPortfolio) const;
			virtual	double	GetRepoMargin(double date1,double date2) const;
			virtual	double	GetDelta(const sophis::CSRComputationResults& results, long *code) const OVERRIDE;
			virtual	double	GetEquityGlobalDelta(const market_data::CSRMarketData& context) const;
			virtual	double	GetEquityGlobalDelta(const sophis::CSRComputationResults& results) const OVERRIDE;

			/**
			*	ISRProductTypeSubject interface implementation.
			**/
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;

			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

			/** Apply rate on performance */
			virtual bool GetApplyRateOnPerf() const;

		private:
			short fVolatilityVersion;
			short fParentVersion;
		};

		/** Class for GSCI TR.
		*/
		class SOPHIS_COMMODITY CSRGSCIIndexTR : public virtual CSRGSCIIndexER
		{

		public:
			//MACRO for declaration of automatic constructor CSRGSCIIndexSpot(const DTitrePlus *titre)
			DECLARATION_COMMODITY(CSRGSCIIndexTR)			

			virtual ~CSRGSCIIndexTR();

			//From CSRInstrument
			virtual CSRInstrument * Clone() const;

			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;

			//From CSRCommodity
			/** Returns the commodity type {@link sophis::commodity::eGSCITR}.*/
			virtual CSRCommodity::eCommodityType GetCommodityType() const;
			
			/**
			*	ISRProductTypeSubject interface implementation.
			**/
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;

			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

			/** Rate code */
			virtual long GetFloatingRate() const;
			virtual const bool SetFloatingRate(const long code);

			/** Apply rate on performance */
			virtual bool GetApplyRateOnPerf() const;
			virtual void SetApplyRateOnPerf(bool val);

			/** Model name. It will be set to "GSCI TR". */
			static const char * MODEL_NAME;
		};

	}
}
SPH_EPILOG
#endif
