#pragma once

#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/gui/SphEditList.h" //for roll rule gui

SPH_PROLOG
namespace sophis
{
	namespace commodity
	{
		/** Roll rules for GSCI indexes .
		*/
		class SOPHIS_COMMODITY CSRGSCIRollRule
		{
		public:

			CSRGSCIRollRule();
			virtual ~CSRGSCIRollRule();

			/** GetWeight()
			*
			* Wrapper around GetWeight_internal
			* Checks returned value
			* See GetWeight_internal for description
			*/

			inline double GetWeight(const sophis::static_data::CSRCalendar* calendar,long day) const
			{
				double w = GetWeight_internal(calendar, day);
				if (w<0)
					return 0;
				else if (w>1)
					return 1;
				else
					return w;
			};

		protected:

			/* GetWeight_internal()
			*
			* Pure virtual method.
			* A Rolling rule must implement this method which gives, for any day and a calendar, the weight of F1, the designated contract of the month
			* When weight is below 1.0, the weight of F2, the designated contract for next month, is 1-weight
			*
			* @param calendar : a calendar
			* @param day : day for which we want the weight
			* @return weight : the weight of F1. It must be between 0 and 1 (0 and 1 included).
			*/

			virtual double GetWeight_internal(const sophis::static_data::CSRCalendar* calendar,long day) const = 0;

		public:
			enum eRollRuleIDRange
			{	
				eRollRuleDefaultID = 0,
				eRollRule_TOOLKIT_START = 1000, /* For Toolkit, use eRollRule_TOOLKIT_START+x to be sure that number will not change in Future versions.
												* But do NOT give numbers higher than eRollRule_TOOLKIT_END
												*/
												eRollRule_TOOLKIT_END = 9999,
												eRollRuleBusinessDayWeights_BEGIN = 10000
			};


			/** GetName()
			*
			* Pure virtual method.
			* @return name : roll rule's name
			*/
			virtual const char* GetName() const = 0;

			/** GetID()
			*
			* Pure virtual method.
			* @return id : a long that identify the roll rule. For user implemented roll rules this id must chosen be between eRollRule_TOOLKIT_START and eRollRule_TOOLKIT_END.
			*/
			virtual long GetID() const = 0;

			/** OpenDetailGUI() 
			*
			* Pure virtual method.
			* Opens a dialog given the details of the roll rule.
			*/
			virtual void OpenDetailGUI() const {};


			/** GetUsedByIndexCount()
			*
			* @return number of GSCI indexes using the roll rule.
			*/
			virtual long GetUsedByIndexCount() const;

			enum eSearchDirection
			{
				eNext,
				ePrevious
			};

			/** Get the begin and end dates of the next/last roll period.

			@param calendar Calendar for business days.
			@param date Start date for the search.
			@param[out] startDate Begin date of the roll period.
			@param[out] endDate End date of the roll period.
			@param searchDirection Direction for the search.
			*/
			void GetNearByRollPeriod(const sophis::static_data::CSRCalendar* calendar, long date, long *startDate, long *endDate = NULL, eSearchDirection searchDirection = eNext ) const;			

			//Static methods

			/** GetRollRulesCount()
			*
			* Static method.
			* @return number of roll rules loaded in the static map of roll rules.
			*/
			static unsigned int	GetRollRulesCount();

			/** GetRollRuleByIndex()
			*
			* Static method.
			* @param i : index of the roll rule in the static map of roll rules.
			* @return the roll rule at index i (returns NULL if not found).
			*/
			static const CSRGSCIRollRule* GetRollRuleByIndex( unsigned int i);

			/** GetRollRuleByID()
			*
			* Static method.
			* @param id : id of the roll rule to get from the static map of roll rules.
			* @return the roll rule of id 'id' (returns NULL if not found).
			*/			
			static const CSRGSCIRollRule* GetRollRuleByID(long id);

			/** GetRollRuleByName()
			*
			* Static method.
			* @param name : name of the roll rule to get from the static map of roll rules.
			* @return the roll rule of name 'name' (returns NULL if not found).
			*/			
			static const CSRGSCIRollRule* GetRollRuleByName(const char* name);

			/** AddRule()
			*
			* Static method.
			* @param pRollRule : a pointer on the roll rule to be loaded into the static map of roll rules. Deletion of the pointer is handled internally at map destruction.
			*					To be accessible in Risque, a roll rule must be loaded using this method.
			* @return boolean : true if everything is ok, false otherwise.
			*/			
			static bool AddRule(const CSRGSCIRollRule* pRollRule);

			/** RemoveRule()
			*
			* Static method.
			* @param id id of the roll rule to be removed from the static map of role rule.
			*/			
			static void RemoveRule(long id);

			/** LoadDefaultsRules()
			*
			* Static method
			* Loads the default roll rule and the datadriven roll rules.
			*/
			static bool LoadDefaultRules(bool reload = false);


			bool IsDefaultRollRule() const;
			bool IsDBRollRule() const;
			bool IsUserRollRule() const;

			static const int NAME_MAX_SIZE = 40;

		private:
			/** ClearRulesList()
			*
			* Static method.
			* Clear all the roll rules in the static map roll rules.
			*/
			static void ClearRulesList();

			/** fRulesList
			*
			* Static map of roll rules containing all the roll rules that can be used.
			*/
			static _STL::map<long , const CSRGSCIRollRule*> fRulesList;	

			/** fDataLoaded
			*
			* Static data.
			* Boolean flag that telss if default rool rule was loaded.
			*/
			static bool fDataLoaded;
		};


		/** Roll rule database driven.
		*/
		class SOPHIS_COMMODITY CSRGSCIRollRule_BusinessDayWeights : public virtual CSRGSCIRollRule
		{
		public:
			//Implementation of pure virtual methods
			virtual double GetWeight_internal(const sophis::static_data::CSRCalendar* calendar,long day) const;
			virtual void OpenDetailGUI() const;
			const char* GetName() const;
			long GetID() const;

			//Static methods
			static bool LoadRules( bool reload = false);
			static const CSRGSCIRollRule* LoadRule(long id);//, double date_save);
			static const int MaxSizeName = 20;
			static const int MaxSizeModel = 20;			

			unsigned int GetWeightCount() const;
			const _STL::map<unsigned int,double>& GetWeights() const;
			void ResetWeights();
			bool SetWeight(unsigned int day, double value);			

			virtual CSRGSCIRollRule_BusinessDayWeights* Clone() const;
			virtual void Save()
				throw(sophisTools::base::GeneralException, _STL::string);
			void SaveName()
				throw(sophisTools::base::GeneralException, _STL::string);
			void Delete()
				throw(sophisTools::base::GeneralException, _STL::string);

			void SetName(const char* newName);

			static CSRGSCIRollRule_BusinessDayWeights* GetNewRule();			
			static void OpenDialog(const CSRGSCIRollRule_BusinessDayWeights* pRollRule = NULL);

		protected:
			CSRGSCIRollRule_BusinessDayWeights();
			CSRGSCIRollRule_BusinessDayWeights(long id, const char* name);
			void Initialize(long id, const char* name);

			void SetID( long id );			
			static bool fDataLoaded;

		private:

			/** fId
			*
			* Id of the roll rule (used in database as primary key to identify the roll rule).
			*/
			long fId;

			/** fName
			*
			* Name of the roll rule.
			*/
			_STL::string fName;

			/** fWeightsByDay
			*
			* Day by day definition of the roll rule.
			*/
			_STL::map<unsigned int,double> fWeightsByDay;
		};


		class CSRGSCIRollRule_BusinessDayWeightsGUI : public sophis::gui::CSREditList
		{
			enum eColumns
			{
				eBDay	=0,
				eWeight =1,
				eNbRollruleColumns
			};

		public:
			virtual	void	Open(void);
			virtual	void	LoadDataFromDB(void);
			virtual	void	GetWindowName(char *windowName) const;	
			virtual bool	EnableSave(void);
			virtual void	CommandSave(void);
			virtual Boolean Close();			
			virtual void	GetLineState(	int	lineIndex,
				sophis::gui::eTextStyleType		&style,
				sophis::gui::eTextColorType		&color,
				Boolean							&isSelected,
				Boolean							&canEdit,
				Boolean							&isStrikedThrough) const;

			static void Display(long rollRuleId = 0, bool isDefaultRollRule = false );

			long GetRollRuleId() const { return fRollRuleId;};
			bool SetRollRuleId( long id );
			const CSRGSCIRollRule* GetRollRule() const;			

		protected:			
			CSRGSCIRollRule_BusinessDayWeightsGUI(CSRUserEditInfo	*data);
			long fRollRuleId;	

			bool IsNotDBRollRule() const;
			bool fIsNotDBRollRule;
		};

		class SOPHIS_COMMODITY CSRGSCIRollRuleDefault : public virtual CSRGSCIRollRule
		{
		public:	
			CSRGSCIRollRuleDefault();

			//Implementation of pure virtual methods of CSRGSCIRollRule
			virtual double GetWeight_internal(const sophis::static_data::CSRCalendar* calendar,long day) const;
			virtual const char* GetName() const;
			virtual long GetID() const;
			virtual void OpenDetailGUI() const;

			static const char* CSRGSCIRollRuleDefault::ROLLRULE_NAME;			
		};		

		class CSRGSCIRollRuleUser : public virtual CSRGSCIRollRule
		{
		public:	
			CSRGSCIRollRuleUser();

			//Implementation of pure virtual methods of CSRGSCIRollRule
			virtual double GetWeight_internal(const sophis::static_data::CSRCalendar* calendar,long day) const;
			virtual const char* GetName() const;
			virtual long GetID() const;
			virtual void OpenDetailGUI() const;				
		};		

		///** Give static methods that tell if a DTitrePlus comes from the audit window, is past priced.*/
		//class SOPHIS_COMMODITY CSRInstrumentHistory
		//{
		//public:
		//	static bool IsHistorical(const DTitre* titre);
		//	static long IsAudited(const DTitre* titre);
		//	static long IsPastPriced(const DTitre* titre);
		//	static void GetCodeToLoad(const DTitre* titre, long &code, double &date);
		//	static long GetPersistentCode(const DTitre* titre);
		//};

	}
}
SPH_EPILOG