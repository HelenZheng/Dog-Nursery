/*
 	File:		SphLMEFuture.h
 
 	Contains:	Class for the handling of a future for LME
 
 	Copyright:	� 1995-2002 Sophis.
 
*/
#pragma once

#ifndef __SPH_LME_FUTURE_H
#define __SPH_LME_FUTURE_H

#include "SphInc/Commodity/SphCommodityFuture.h"
#include "SphInc/Commodity/SphCommodity.h"

#define	LMEFUTURE	"LME Future"

SPH_PROLOG
namespace sophis	{
	namespace commodity	{

		class SOPHIS_COMMODITY CSRLMEFuture : public virtual CSRCommodityFuture	{
		public:
			DECLARATION_FUTURE(CSRLMEFuture)

			void InitLMEFuture(); /* Called by constructor : init risk sources and other members according to underlying code and expiry date */

			~CSRLMEFuture();
			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;
  			//virtual void	InitialiseRecomputeAll();
			virtual bool	HasAFormulaForSpot() const;
			virtual bool	HasAVolatilityFormula() const;
			virtual bool	HasACorrelationFormula() const;

			virtual bool	IsDeltaUnderlying() const;
			virtual bool	IsVegaUnderlying() const;

			//virtual long	GetUnderlying(int i) const;

			virtual double	GetFirstDerivativeUndiscounted(const sophis::market_data::CSRMarketData &context, int whichUnderlying) const;

			virtual bool	ConstructAgain() const;
			virtual	double	GetImpliedSpot(const market_data::CSRMarketData& context) const;

			virtual	void	GetExpiryConvention(int *month, int *year) const;

			virtual bool	GetClosedValue(double& value,const market_data::CSRMarketData &context) const;

			virtual double	GetWorksheetValue() const;

			virtual double	GetEquityGlobalDelta(const market_data::CSRMarketData& context) const;

			void			FillRiskValues(SSInterpolationValues &riskFuture1, SSInterpolationValues &riskFuture2) const;
			void			FillVegaValues(SSInterpolationValues &vegaFuture1, SSInterpolationValues &vegaFuture2) const;
			virtual void	GetRiskValues(SSInterpolationValues &riskFuture1, SSInterpolationValues &riskFuture2) const;
			virtual void	GetVegaValues(SSInterpolationValues &vegaFuture1, SSInterpolationValues &vegaFuture2) const;

			//virtual void	GetDeltaUnderlying(const sophis::instrument::CSROption& option, _STL::set<long>& codeList, int whichUnderlying) const;

			virtual double	GetVolatility(	double 						startDate,
											double						endDate,		
											double 						strike,
											NSREnums::eVolatilityType	volatilityType,
											Boolean 					put,
											const market_data::CSRMarketData &context) const;

			virtual	double	GetCorrelation(	const market_data::CSRMarketData&	context,
											long 					currency1,
											long 					currency2,
											double 					startDate,
											double 					endDate) const;

			virtual long	GetSettlementDate(long transactionDate) const;
			virtual bool	IsWithMarginCall() const;

			virtual	sophis::instrument::CSRFuture* new_MultiCurrencyFuture() const;

			//virtual bool	UseForwardCalculation() const;
			virtual sophis::instrument::eUnrealizedMethodType GetUnrealizedMethod() const;
			//virtual double	GetRhoDiscountFactor() const;
			//virtual double	GetConvexityDiscountFactor() const;
			virtual void	GetDiscountFactors(const market_data::CSRMarketData &context, double *discount_factor, double *theta_discount_factor) const;

			//virtual void	GetCalculationData(sophis::tools::CSRArchive & archive) const;
			//virtual void	SetCalculationData (const sophis::tools::CSRArchive & archive);

			virtual double GetNetDeltaForUnderlyingView(double grossDelta, double financingFactor) const;
			virtual double GetHedgeDelta(const sophis::market_data::CSRMarketData &context, double pnlDelta, long pnlDeltaCurrency) const;
			virtual double GetDeltaPnL(const sophis::CSRComputationResults& results, int whichUnderlying) const OVERRIDE;

			virtual const bool SetUnderlyingCode(const long value);
			virtual static_data::CSRCalendar* NewCSRCalendar() const;

			_STL::vector<long>				fUnderlyingInit;
			_STL::vector<long>				fUnderlyingInitVega;

		private:
			mutable SSInterpolationValues	fRiskFuture1;
			mutable SSInterpolationValues	fRiskFuture2;
			mutable SSInterpolationValues	fVegaFuture1;
			mutable SSInterpolationValues	fVegaFuture2;
			mutable	bool					fFillRiskValues;
			mutable	bool					fFillVegaValues;
			mutable	bool					fIsDeltaUnderlying;
			mutable	bool					fIsVegaUnderlying;

		private:
			//DEPRECATED_RESULTS void SetRhoDiscountFactor(double d);
			//DEPRECATED_RESULTS void SetConvexityDiscountFactor(double d);
			//DEPRECATED_RESULTS void SetDiscountFactorFuture(double d);

			// DEPRECATED_RESULTS double	fRhoDF;
			// DEPRECATED_RESULTS double	fConvexityDF;
			// DEPRECATED_RESULTS double	fDiscountFactorFuture;
		};
	}
}

SPH_EPILOG

#endif
