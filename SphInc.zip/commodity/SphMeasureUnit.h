#ifndef _SphMeasureUnit_H_
#define _SphMeasureUnit_H_

#ifndef _SphMacros_H_
	#include "SphInc/SphMacros.h"
#endif

#include "SphInc/gui/SphMenu.h"

class CSUMenu;	// internal
struct TDlog;	// internal


SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace sophis	{
	namespace commodity	{

		enum eWeightGreek
		{
		  eWeightForDelta = 0,
		  eWeightForGamma,
		  eWeightForVega
		};

		struct SSMeasureUnit
		{

			enum	Type		// obselete
			{
				NotDefined,
				Volume,
				Weight
			};
			
			enum	Constant
			{
				NameLength = 20,
				CommentLength = 50
			};

			SOPHIS_COMMODITY void	Initialise();

			long	fIdent;
			char	fName[NameLength];
			double	fValue;
			long	fUnitType;	// Normaly Type but short for alinement reason
			char	fComments[CommentLength];
		};

		struct SOPHIS_BASIC_DATA SSWeight
		{
			SSWeight();

			long	id;
			char	fName[20];
			double	getWeight(int which)const;
			_STL::vector<double> weight;
		};

		typedef _STL::vector<SSMeasureUnit>	SSMeasureUnitVector;
		typedef _STL::vector<SSWeight>		SSWeightVector;

		/**
		*/
		class SOPHIS_COMMODITY CSRUnit
		{
		public:
		//INTERNAL USE

			/** 
			  * Default Constructor.
			  */
			CSRUnit();

			/**
			  * Destructor. 
			  * Calling Delete().
			  */
			~CSRUnit();

			//read function
			/**
			 * initiate fMeasureUnit & fUsedIdList
			 * return the sql error number
			 */
			short		InitUnits(bool initAllUsedId);

			/**
			 * Get the next line Id
			 * return the next line ident
			 */
			int			GetNewLineId(void);

			/**
			 * Get the unit menu
			 * return the menu handle
			 */
			virtual CSUMenu	*	GetMenu() const;

			/**
			 * delete fMeasureUnit if size > 0
			 */
			void		Delete();

			/** Singleton
			*/
			static		CSRUnit global;
			
			/**
			 * static method returning the global CSRUnit list
			 * @return a pointer to the global list
			 */
			static CSRUnit* GetInstance();

		//external use	
			//retrieve functions
			/**
			 * method returning the unit info for a given id code
			 * @param unitId the unit ident
			 * @return a pointer 
			 */
			const SSMeasureUnit			*GetMeasureUnit(long unitId) const;

			//retrieve functions
			/**
			 * method getting the unit type name for a given unit type
			 * @param type the unit type
			 * @param typeName return the name of the unit type
			 */
			static	void				GetUnitTypeName(SSMeasureUnit::Type type, char* typeName);

			//retrieve functions
			/**
			 * method returning the nth unit info
			 * @param whichUnit the unit position in the list starting from 0
			 * @return a pointer 
			 */
			virtual const SSMeasureUnit	*GetNthUnit(int whichUnit) const;

			//retrieve functions
			/**
			 * method returning the units count in the list
			 * @return the count of the units 
			 */
			virtual long				GetUnitCount() const;

			//retrieve functions
			/**
			 * method returning the unit name for a given id code
			 * @param name returns the name of the unit
			 * @param unitId the unit ident
			 */
			virtual void				GetName(char *name, long unitId) const;

			//retrieve functions
			/**
			 * method returning the unit type name for a given id code
			 * @param name returns the name of the unit
			 * @param unitId the unit ident
			 */
			virtual void				GetTypeName(char *name, long unitId) const;

			//retrieve functions
			/**
			 * method returning the comments for a unit by the given id code
			 * @param comments the unit comments
			 * @param unitId the unit ident
			 */
			virtual void				GetComments(char *comments, long unitId) const;

			//retrieve functions
			/**
			 * method returning the value for a unit by given id code
			 * @param unitId the unit ident
			 * @return the value for the unit
			 */
			virtual double				GetValue(long unitId) const;

			//retrieve functions
			/**
			 * method returning the type for a unit by a given id code
			 * @param unitId the unit ident
			 * @return the type for the unit 
			 */
			virtual int					GetTypeValue(long unitId) const;

			//retrieve functions
			/**
			 * method returning the unit id for a given unit name 
			 * @param name the unit name
			 * @return the ident for the unit 
			 */
			virtual long				GetIdByName(const char *name) const;

			//retrieve functions
			/**
			 * method returning convert ratio from an underlying asset to a unit
			 * @param unit_id the unit ident
			 * @param underlying the underlying ident
			 * @return the convert ratio
			 */
			virtual double				GetConvertRatioFromUndToUnit(long	unit_id, long underlying) const;

			//retrieve functions
			/**
			 * method returning the convert ratio from unit1 to unit2 for an underlying asset
			 * @param unit_id1 the first unit ident
			 * @param unitid_2 the second unit ident
			 * @param underlying the underlying ident
			 * @return the convert ratio
			 */
			virtual double				GetConvertRatioUndFromUnit1ToUnit2(long unit_id1, long unitid_2, long underlying) const; 

			//retrieve functions
			/**
			 * method returning the unit ident for the nth menu item
			 * @param nth_menu the nth unit menu item
			 * @return the ident for the unit
			 */
			virtual long				GetIdFromMenu(int nth_menu) const;

			//retrieve functions
			/**
			 * method returning the position in the unit list for a given unit ident starting from 1
			 * @param unitId the unit ident
			 * @return the unit list position
			 */
			virtual int					GetRankFromUnitID(long unitID) const;

			//retrieve functions
			/**
			 * method returning the menu position for a given unit ident
			 * @param unitId the unit ident
			 * @return the menu position
			 */
			virtual short				GetMenuItemFromID(long	unit_id) const;

		protected:
			SSMeasureUnitVector		fMeasureUnit;
			CSUMenu					*fMenu;
			int						fUsedIdList[10];
		};

		class SOPHIS_COMMODITY CSRWeight
		{
		public:

			//INTERNAL USE
			/** 
			  * Default Constructor.
			  */
			CSRWeight(); 

			/**
			  * Destructor. 
			  * Calling Delete().
			  */
			~CSRWeight(); 

			/**
			  * Set current global weight ident 
			  * @param id the ident of current global weight
			  */
			void			SetGlobalWeight(eWeightGreek WeightType,long id) const;

			//read function
			/**
			 * initiate fWeights & fUsedIdList
			 * return the sql error number
			 */
			short			InitWeights(bool initAllUsedId);
			
			/**
			 * Get the next line Id
			 * return the next line ident
			 */
			int				GetNewLineId(void); 
			/**
			 * Get the weight menu
			 * return the menu handle
			 */
			CSUMenu*		GetMenu() const; 

			/**
			 * delete fWeights if fNbOfWeights > 0
			 */
			void			Delete(); 

			static			CSRWeight global;

			/**
			 * static method returning the global CSRWeight list
			 * @return a pointer to the global list
			 */
			static	CSRWeight* GetInstance();
			
			//external use
			//retrieve functions
			/**
			 * method returning the weight info for a given id code
			 * @param id the weight ident
			 * @return a pointer 
			 */
			virtual const SSWeight		*GetWeight(long id) const;
			
			//retrieve functions
			/**
			 * method returning the nth weight info
			 * @param whichWeight the weight position in the list starting from 0
			 * @return a pointer 
			 */
			virtual const SSWeight		*GetNthWeight(int whichWeight) const; 
			
			//retrieve functions
			/**
			 * method returning the weights count in the list
			 * @return the count of the weights 
			 */
			virtual long					 GetWeightCount() const; 

			//retrieve functions
			/**
			 * method returning the weight name for a given id code
			 * @param name returns the name of the weight
			 * @param id the weight ident
			 */
			virtual void				 GetName(char *name, long id) const; 

			//retrieve functions
			/**
			 * method returning the value for the nth weight by given id code
			 * @param id the weight ident
			 * @param nth the nth weight of the ident
			 * @return the value for the weight
			 */
			virtual double				 GetValue(long id, int nth) const; 

			//retrieve functions
			/**
			 * method returning the weight id for a given weight name 
			 * @param name the weight name
			 * @return the ident for the weight 
			 */
			virtual long					 GetIdByName(const char *name) const; 

			//retrieve functions
			/**
			 * method returning the weight ident for the nth menu item
			 * @param nth_menu the nth weight menu item
			 * @return the ident for the weight
			 */
			virtual long					 GetIdFromMenu(int nth_menu) const; 

			//retrieve functions
			/**
			 * method returning the position in the weight list for a given weight ident starting from 1
			 * @param id the weight ident
			 * @return the weight list position
			 */
			virtual int					 GetRankFromWeightID(long id) const; 

			//retrieve functions
			/**
			 * method returning the weight position for a given weight ident
			 * @param id the weight ident
			 * @return the menu position
			 */
			virtual short				 GetMenuItemFromID(long	id) const; 

			//retrieve functions
			/**
			 * method returning the ident for the current global weight
			 * @return the ident for the current global weight
			 */
			virtual long					 GetCurrentId(eWeightGreek WeightType) const;
		protected:
			SSWeight		*fWeights;
			int				fNbOfWeights;
			CSUMenu			*fMenu;
			int				fUsedIdList[10];

			mutable long	fCurrentId_Delta;
			mutable long	fCurrentId_Gamma;
			mutable long	fCurrentId_Vega;
		};

		

		/**************************************************************************************/
		/*																					  */
		/*	The CSRUnitMenu is the class which used for the items in either a list or a dialog*/  
		/*	as a popup menu containning all units name										  */
		/*																					  */
		/**************************************************************************************/

		class SOPHIS_COMMODITY CSRUnitMenu : public gui::CSRElement 
		{
		public:
			CSRUnitMenu(		gui::CSRFitDialog 	*dialog, 
								int 				 ERId_UnitMenu,
								long				 value			= 0, 
						  const char 				*columnName		= kUndefinedField);

			CSRUnitMenu(		gui::CSREditList	*list, 
								int					 CNb_UnitMenu, 
								long				 value			= 0, 
						  const char				*columnName		= kUndefinedField,
								bool				canBeModified	= true);

			virtual void	ValueToString(char *dest, int line) const;
			virtual Boolean	StringToValue(const char *sourc, int line);
			virtual void operator = (const gui::CSRElement&);
					void operator = (const CSRUnitMenu&);
			virtual int		Compare(const gui::CSRElement&) const;
			virtual void	GetValue(void *value) const;
			virtual void	SetValue(const void *value);
			virtual	Boolean	CanBeModifiedInAList(void) const;
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			void			SetUnit(long newUnit);

		protected:
			long			fValue;
			bool			fCanBeModified;

		public:
			virtual	int		DonneTypeTri() const;			// internal
			virtual USMenu	*DonneMenu(void) const;			// internal
			virtual short	GetListValue(void) const;		// internal
			virtual void	SetListValue(short value);		// internal
			virtual Boolean	IsASharedMenu() const;			// internal

			ELEM_COMMON_INTERNALS
		};
	}
}

SPH_END_NOWARN_EXPORT
SPH_EPILOG





#endif