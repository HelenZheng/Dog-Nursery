#pragma once

#ifndef _SphOTCClearedSwap_H__
#define _SphOTCClearedSwap_H__

#include "SphInc/instrument/SphSwap.h"
SPH_PROLOG
namespace sophis	{

	namespace commodity	{

		/**If this class is derived, the global function GetInstrumentToFullLoadWhenLoadingPortfolio
		has to be overloaded to retrieve the sicovam of the instruments of the derived class.
		See SphGlobalFunctions.h.
		*/
		class SOPHIS_COMMODITY CSROTCClearedSwap : public virtual sophis::instrument::CSRSwap
		{
			DECLARATION_SWAP(CSROTCClearedSwap)

		public:
			virtual bool			IsWithMarginCall() const;
			virtual	double			GetQuotity(bool withTaxes=false) const;
			virtual void			AddCashFlow(long start_date, long end_date, const portfolio::CSRPosition & position, portfolio::ISRCashFlow & cashFlow, const market_data::CSRMarketData* context = NULL) const;
			/** get the forecast date of an OTC Cleared Swap or Option.
			In the default implementation, forecast date is computed using global prefs COM_OTC_CLEARED_BO_PAY_MIN and
			COM_OTC_CLEARED_BO_PAY_SHIFT.
			@param paymendDate payment date of the swap (called with the payment date of the left leg of the swap)
			@param endDate end date of the swap (called with the end date of the left leg of the swap.
			@return the forecast date of the swap.
			*/
			virtual long			GetForecastDate(long paymentDate, long endDate) const;

		};
	}
}
SPH_EPILOG
#endif
