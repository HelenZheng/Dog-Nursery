#ifndef __SphParentSpreadVolatility_h__
#define __SphParentSpreadVolatility_h__

#include "SphInc/market_data/SphVolatility.h"
SPH_PROLOG
namespace sophis	{
	namespace market_data	{


		struct SOPHIS_COMMODITY SSParentSpreadVolatilityData
		{
			long fParentSico;
		};
		//---------------------------------------------------------------
		// CSRPowerGasParentSpreadVolatility 
		//---------------------------------------------------------------
		class SOPHIS_COMMODITY CSRPowerGasParentSpreadVolatility : public virtual CSRVolatility
		{
		public:

			DECLARATION_VOLATILITY(CSRPowerGasParentSpreadVolatility)

			static const char* GetVolatilityClassName() { return "Power&Gas Parent spread"; }
		};
	}
}

sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::market_data::SSParentSpreadVolatilityData& v);
const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::market_data::SSParentSpreadVolatilityData &v);
SPH_EPILOG
#endif

