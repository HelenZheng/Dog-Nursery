#ifndef __SphPHysicalCommoFeesCondition__
#define __SphPHysicalCommoFeesCondition__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

namespace sophis {
	namespace portfolio {
		class CSRTransaction;
	}
	namespace commodity {

#define DECLARATION_PHYSICAL_COMMO_FEES_CONDITION(derivedClass)\
	DECLARATION_PROTOTYPE(derivedClass, sophis::commodity::CSRPhysicalCommoFeesCondition)
#define CONSTRUCTOR_PHYSICAL_COMMO_FEES_CONDITION(derivedClass)
#define WITHOUT_CONSTRUCTOR_PHYSICAL_COMMO_FEES_CONDITION(derivedClass)
#define	INITIALISE_PHYSICAL_COMMO_FEES_CONDITION(derivedClass, name)\
	INITIALISE_PROTOTYPE(derivedClass,  name)

		/** New condition for physical commodity fees categories.
		@since 6.2.3
		*/
		class SOPHIS_COMMODITY CSRPhysicalCommoFeesCondition
		{
		public:
			/** Static method to be called externally to get the condition state of the line of 
			* Physical Commodities Fees Categories.
			* @param tr - is the reference to the corresponding transaction.
			* @param vcond - is the vector of string values of condition columns of the line to be checked. 
			* @return - true if all conditions from @vcond param are met, false - otherwise.
			* @version 5.2.6
			**/
			static bool IsConditionMet(const sophis::portfolio::CSRTransaction& tr, 
										const _STL::vector<_STL::string> &vcond);
			/** Method which is called internally by static method sIsConditionMet() to check 
			* a single condition from @vcond vector (see sIsConditionMet() static method above).
			* @return - true if this single condition is met, false - otherwise. 
			* @version 5.2.6
			**/
			virtual bool GetCondition(const sophis::portfolio::CSRTransaction& tr) const = 0;
			
			/** Clone method needed by the prototype.
			@see tools::CSRPrototype
			*/
			virtual CSRPhysicalCommoFeesCondition* Clone() const = 0;
			
			/** The key for the prototype is a const char *
			@see CSRPrototype
			*/
			typedef sophis::tools::CSRPrototype<CSRPhysicalCommoFeesCondition, 
												const char*, 
												sophis::tools::less_char_star> prototype;
			/** Access to the prototype singleton.
			To add a condition to this singleton, use INITIALISE_PHYSICAL_COMMODITY_FEES_CONDITION.
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();
		};

	}
}

#endif //__SphPHysicalCommoFeesCondition__
