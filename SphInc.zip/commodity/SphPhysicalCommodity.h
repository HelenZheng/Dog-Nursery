/*
File:		SphPhysicalCommodity.h

Contains:	Class for the handling of a physical commodity.

Copyright:	� 2012 Sophis.
*/


#ifndef __SPHPHYSICALCOMMODITY_H__
#define __SPHPHYSICALCOMMODITY_H__

#include "SphInc/SphMacros.h"
#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/instrument/SphInstrumentEnums.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning (push)
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

namespace sophis {
	namespace portfolio
	{
		class CSRTransaction;
	}
	namespace collateral
	{
		class CSRCreditCallFrequency;
	}
	namespace commodity {

		enum ePhysCommoUnderlyingType 
		{
			ePCUT_commodity=0,
			ePCUT_preciousMetal
		};

		enum ePhysCommoRateType 
		{
			ePCRT_PerDay=0,
			ePCRT_PerYear
		};

		enum ePhysCommoStartDate 
		{
			ePCSD_FromPurchase=0,
			ePCSD_FromRentStartDate
		};

		struct	SSReporting
		{
			SSReporting() { fReportingIncome = fReportingAccrued = 0; fReportingDate = 0; };
			SSReporting(long reporting_date) { fReportingIncome = fReportingAccrued = 0; fReportingDate = reporting_date; };
			double	fReportingIncome;
			double	fReportingAccrued;
			long	fReportingDate;
		};

		struct SOPHIS_COMMODITY SSNegotiatedRate
		{
			SSNegotiatedRate() { fEndDate = fEndDate = 0; fStorageRate = 0; };
			long	fStartDate;
			long	fEndDate;
			double	fStorageRate;
		};

		class SOPHIS_COMMODITY CSRNegotiatedRateVector : public _STL::vector<SSNegotiatedRate>
		{
		public:
			void Construct(const _STL::vector<SSNegotiatedRate>& schedule);

		protected:
		private:
		};

		/*
		 *
		 * ==== ==== ================================== ==== ====
		 * ==== ==== ====    CSRPhysicalCommodity  ==== ==== ====
		 * ==== ==== ================================== ==== ====
		 *
		 */

		class SOPHIS_COMMODITY CSRPhysicalCommodity : public virtual CSRCommodity	
		{

		public:
			DECLARATION_COMMODITY(CSRPhysicalCommodity)

		public:
			virtual bool IsAPhysicalCommodity() const;
			virtual		 ~CSRPhysicalCommodity();

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);
			virtual const char * GetXMLRootName() const;

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;
			//virtual void InitialiseRecomputeAll();

			static const char * MODEL_NAME;

			//static methods
			static bool IsPhysicalCommoModel(const char* modelName);
			static bool IsPhysicalCommoModel(const DTitre* titre);
			static const char* GetDefaultPhysicalCommodityModel();


			// abstract methods from CSRCommodity
			virtual eWorksheetType	GetWorksheetType(int whichPairing) const;
			virtual void			FillFutureList();
			virtual eCommodityType	GetCommodityType() const;
			virtual instrument::CSRInstrument * Clone() const;

			// virtual methods for audit
			virtual bool IsHistorical() const;
			virtual bool SicoToLoadIsHisto() const;
			virtual long GetSicoToLoad() const { return fSicoToLoad; }
			virtual bool CanModify() const { return !IsHistorical(); }
			virtual double GetDateHisto() const { return fDateHisto; }

			// Duplicates the satellite of DTitre. This method is for internal use when cloning.
			virtual void DuplicateData(const instrument::CSRInstrument &instrument);	// internal

			// virtuals from CSRInstrument
			virtual const portfolio::CSRAssetValueCalculation* GetAssetValueCalculation() const;
			virtual bool GetFastPnlConfigurations(_STL::vector<long>& vectOfIds) const;
			virtual bool MatchMarkPnLRule(char *instrType, char *instrFeature1, char *instrFeature2) const;
			virtual bool GetSpecificAnalysisGrid(FastPnl::eGridAnalysisType analysisType,long underlyingCode,_STL::vector<FastPnl::FPGridMaturity>& outMaturities,_STL::vector<double>& outStrikes,bool& strikesInPercent) const;			
			virtual FastPnl::CSRFastPnlSensibilitiesCalculator*  GetNewFastPnlSensibilitiesCalculator(FastPnl::eGridAnalysisType analysisType) const;
			virtual void ActivateMarketCategory(_STL::auto_ptr<sophis::instrument::CSRMarketCategoryHandle>& returnedHandle) const;

			//virtual int		GetUnderlyingCount() const;
			//virtual long	GetUnderlying(int whichUnderlying) const;
			//virtual long	GetUnderlying(int whichUnderlying, const market_data::CSRMarketData &context) const;
			virtual long	GetLivingFuture(const market_data::CSRMarketData& context) const;
			virtual void	ComputeUnderlyingPrice(const market_data::CSRMarketData& context);
			double GetUnderlyingPrice(const market_data::CSRMarketData& context) const;

			virtual sophis::static_data::CSRCalendar	*	NewCSRCalendar() const;
			virtual bool SpecialTransaction(sophis::portfolio::CSRTransaction &transaction, RecalculeTransaction type) const;
			virtual double GetGrossAmount( const portfolio::CSRTransaction & transaction, double & spotForFees ) const;

			virtual bool SpecialReporting() const;
			virtual eSpecialReportingType GetSpecialReportingType() const;
			virtual bool ReportingBySettlementDate() const;
			virtual void StartReporting(long reporting_date, long portfolio_id, sophis::portfolio::PSRExtraction extraction) const;
			virtual void Reporting(sophis::portfolio::SSReportingTrade* deal, double &cash) const;
			virtual void EndReporting(TViewMvts * position, double fxOfTheDay) const;


			double GetTheoreticalPriceFromUnderlyingPrice(double spot) const;

			virtual	double	GetDelta(const sophis::CSRComputationResults& results, long *instrumentCode)	const;
			virtual	double	GetDeltaPnL(const sophis::CSRComputationResults& results, int whichUnderlying) const;
			virtual	double	GetDeltaPnL(const sophis::CSRComputationResults& results, int whichUnderlying, const market_data::CSRMarketData &context) const;
			virtual double	GetHedgeDelta(const market_data::CSRMarketData &context, double pnlDelta, long pnlDeltaCurrency) const;
			virtual void	GetDiscountFactors(const market_data::CSRMarketData &context, double *discount_factor, double *theta_discount_factor) const;
			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData& context) const;
			virtual	double	GetEquityGlobalDelta(const sophis::CSRComputationResults& results) const;
			virtual	double	GetEquityGlobalDelta(const market_data::CSRMarketData& context) const;

			/** Get the spot by default when purchasing an instrument. 
			@return a double which will appear when buying the instrument.
			@since 6.2.3.2
			*/
			virtual double GetSpotDefaultForPurchase() const;

			//ISRProductTypeSubject interface implementation.
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool HasFeature(const sophis::finance::CSRProductFeature &feature, const _STL::string &featureName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

			
			// Creates a new CSRPhysicalCommodity instance according to the model field contained in {@var titre} and returns a pointer on it.
			static CSRPhysicalCommodity* CreateInstance(const DTitrePlus *titre);
			// Creates the right type of Instrument, depending on the field t->titre->model.
			static sophis::commodity::CSRCommodity* CreateCSRPhysicalCommodity(const DTitrePlus* t);

			// Initialisation 
			static void InitData(SSCommodityInstrument * data);

			// computations
			virtual double			ComputeUnitTermFees(long endDate, const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual double			ComputeTermFees(long endDate, const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual const short		GetSettlementLag() const;

			//accessors			
			virtual ePhysCommoUnderlyingType	GetUnderlyingType() const;
			virtual void						SetUnderlyingType(short type);
			virtual long						GetUnderlyingCode() const;
			virtual void						SetUnderlyingCode(long code);
			virtual double						GetMeasure() const;
			virtual void						SetMeasure(double lotSize);
			virtual long						GetMeasureUnit() const;
			virtual void						SetMeasureUnit(long unit);
			virtual double						GetMultiplicativeQualityFactor() const;
			virtual void						SetMultiplicativeQualityFactor(double factor);
			virtual double						GetAdditiveQualityFactor() const;
			virtual void						SetAdditiveQualityFactor(double factor);
			virtual double						GetUnderlyingSpot() const;
			virtual void						SetUnderlyingSpot(double spot);
			virtual double						GetMeasureConversionFactor() const;
			virtual	double						GetQuotity(bool withTaxes=false) const;

			virtual long						GetRentStartDate() const;
			virtual void						SetRentStartDate(long rentDate);
			
			// As a scheduler is now used, these are the methods to call to get or set the Negotiated Rate Vector. 
			// The different data of each negotiated rate (start date, end date, storage rate) are managed in the CSMPhysicalCommodityUserData 
			// So if a toolkit is necessary, the toolkit user data should inherit from the CSMPhysicalCommodityUserData
			virtual CSRNegotiatedRateVector     GetNegotiatedRates () const;
		    virtual void						SetNegotiatedRates (const CSRNegotiatedRateVector& rates);
			CSRNegotiatedRateVector				GetRealNegotiatedRates() const;
			void								SetRealNegotiatedRates(const CSRNegotiatedRateVector& rates);
			virtual CSRNegotiatedRateVector     GetSortedNegotiatedRates () const;

			//fees getters using physical commodity fees categories
			virtual long											GetUnitTermCurrency(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual ePhysCommoStartDate								GetUnitTermStartDate(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual double  										GetUnitTermRateValue(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual ePhysCommoRateType								GetUnitTermRateType(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual sophis::static_data::eYieldCalculationType		GetUnitTermMode(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual sophis::static_data::eDayCountBasisType			GetUnitTermBasis(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual long											GetUnitTermFrequencyId(const sophis::portfolio::CSRTransaction * transaction=NULL) const;//see CSRCreditCallFrequency::GetId
			virtual const collateral::CSRCreditCallFrequency*		GetUnitTermFrequency(const sophis::portfolio::CSRTransaction * transaction=NULL) const;

			virtual long											GetTermCurrency(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual ePhysCommoStartDate								GetTermStartDate(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual double  										GetTermRateValue(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual ePhysCommoRateType								GetTermRateType(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual sophis::static_data::eYieldCalculationType		GetTermMode(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual static_data::eDayCountBasisType					GetTermBasis(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual long											GetTermFrequencyId(const sophis::portfolio::CSRTransaction * transaction=NULL) const;//see CSRCreditCallFrequency::GetId
			virtual const collateral::CSRCreditCallFrequency*		GetTermFrequency(const sophis::portfolio::CSRTransaction * transaction=NULL) const;
			virtual long											GetTermFixingId(const sophis::portfolio::CSRTransaction * transaction=NULL) const;

			static CSRPhysicalCommodity* CreateInstance(const char* model);

		protected :
			// Sico that must be actually loaded (may be a main or an historical sico).
			long	fSicoToLoad;
			double	fDateHisto;

			// Load the specific data of physical commodity.
			virtual bool LoadSpecificData();

			mutable SSReporting fReporting;

		private:
			static const char* __CLASS__;
		};
	}
}

#endif
