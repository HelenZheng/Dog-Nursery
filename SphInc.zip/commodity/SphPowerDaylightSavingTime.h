/*
File:		SphPowerDaylightSavingTime.h

*/

#ifndef __SPHPOWERDAYLIGHTSAVINGTIME_H__
#define __SPHPOWERDAYLIGHTSAVINGTIME_H__

#define DECLARATION_DAYLIGHT_SAVING_TIME(derivedClass)		DECLARATION_PROTOTYPE(derivedClass,sophis::commodity::CSRPowerDaylightSavingTime)
#define CONSTRUCTOR_DAYLIGHT_SAVING_TIME(derivedClass)			
#define WITHOUT_CONSTRUCTOR_DAYLIGHT_SAVING_TIME(derivedClass)	
#define	INITIALISE_DAYLIGHT_SAVING_TIME(derivedClass,  id)	sophis::tools::install<derivedClass>(id);

#include "sphtools/sphprototype.h"
#include "SphInc/tools/SphAlgorithm.h" 
#include "SphInc/commodity/SphCommodityPower.h" 

SPH_PROLOG
namespace sophis {
	namespace commodity {

		class SOPHIS_COMMODITY CSRPowerDaylightSavingTime
		{
		public:
	
			enum	eID_DaylightSavingTime
			{   eEuropean = 1,
				eUSA,
				eTest,
			};

			//Note: the ID for toolkit models should be greater or equals to 1000

			/** Return Model Name. Used to display the name of model in the ComboBox on commodity screen
			*/
			virtual const char* GetModelName() = 0; 

			/** Return the date corresponding to the  first day of Daylight Saving Period
			* Example : In USA, the Second Sunday in March
			*           In Europe, the last Sunday of March
			* This date, we switch from "winter time" to "summer time", meaning that this day contains only 23 hours (1 hour disappears on that day)
			* @nYear - the Year 
			*/
			virtual long GetFirstDayOfSavingPeriod(long nYear) const = 0;

			/** Return the hour corresponding to the begin of Daylight Saving Period
			* In the most case the StartTimeSavingHour is equals to StopTimeSavingHour
			* Example: in Europe, the last sunday of march, at 2:00am it will be 3:00am
			*          In other words, the hour from 2:00am to 3:00am disappears
			*          The value returned is "3" (since hour H1 is from 0:00am to 1:00am, H3 is from 2:00am to 3:00am)
			*          in USA
			*/
			virtual short GetStartTimeSavingHour() const = 0;

			/** Return true if a date is the  first day of Daylight Saving Period (ex: Second Sunday in March for USA)
			@nDate - the date to be tested
			*/
			virtual bool IsFirstDayOfSavingPeriod(long nDate)const ; 

			/** Return the date corresponding to the  last day of Daylight Saving Period
			* Example : in USA, the First Sunday in November
			*           in Europe, the last Sunday of October
			* This date, we switch from summer time to winter time, hence the day contains 25 hours (1 hour extra on the day)
			* @nYear - the Year 
			*/
			virtual long GetLastDayOfSavingPeriod(long nYear) const = 0;

			/** Return the hour corresponding to the end of Daylight Saving Period
			* In the most case the StartTimeSavingHour is equals to StopTimeSavingHour
			* Example: in Europe, the last sunday of october, at 3:00am it will be 2:00am
			*          In other words, the hour from 2:00am to 3:00am occurs twice
			*          The value returned is "3" (since hour H1 is from 0:00am to 1:00am, H3 is from 2:00am to 3:00am)
			*          in USA
			*/
			virtual short GetStopTimeSavingHour() const = 0;

			/** Return true if a date is the last day of  Daylight Saving Period (ex: First Sunday in November for USA)
			@nDate - the date to be tested
			*/
			virtual bool IsLastDayOfSavingPeriod(long nDate) const; 

			typedef tools::CSRPrototype<CSRPowerDaylightSavingTime, long > prototype;

			/** Access to the singleton containing all the derived class of CSRPowerDaylightSavingTime
			It is filled when using the macro INITIALISE_DAYLIGHT_SAVING_TIME
			*/
			static prototype & GetPrototype();

			/** Clone function used by prototype
			It is generally created by the macro DECLARATION_DAYLIGHT_SAVING_TIME
			*/
			virtual CSRPowerDaylightSavingTime * Clone() const = 0;

			/* Get a pointer to the prototype instance corresponding to 'ident'
			* @param ident : identifies the prototype instance according to eID enumeration
			* @return a pointer to the prototype instance
			*/
			static const CSRPowerDaylightSavingTime* GetDaylightSavingTime(long ident);

			static bool IsLastDayOfSavingPeriod(long nCommoCode, long nDate);
			static bool IsFirstDayOfSavingPeriod(long nCommoCode, long nDate);
			static long GetFirstDayOfSavingPeriod(long nCommoCode, long nYear);
			static long GetLastDayOfSavingPeriod(long nCommoCode, long nYear);
			static short GetStartTimeSavingHour(long nCommoCode);
			static short GetStopTimeSavingHour(long nCommoCode);
		};
	};
};
SPH_EPILOG
#endif
