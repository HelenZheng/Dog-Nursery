/*
 	File:		SphPowerFuture.h
 
 	Contains:	Class for the handling of a future for Power
 
 	Copyright:	� 1995-2002 Sophis.
 
*/
#pragma once

#ifndef __SPH_POWER_FUTURE_H
#define __SPH_POWER_FUTURE_H

#include "SphInc/Commodity/SphCommodityFuture.h"
#include "SphInc/Commodity/SphCommodityPower.h"
#include "SphInc/market_data/SphHistoric.h"

#define	GASFUTURE	"Gas Future"
#define GASHOURLYFUTURE "Gas Hourly Future"

SPH_PROLOG
namespace sophis	{
	namespace commodity	{

		struct SSInterpolationPowerValues : SSInterpolationValues
		{
			double fWeight;

			bool operator==(const SSInterpolationPowerValues& other) const
			{
				return (other.sicovam		== sicovam		&&
						other.expiryDate	== expiryDate	&&
						fabs(other.value - value) < 1e-5	&&
						other.fWeight		== fWeight);
			}
		};


		class SOPHIS_COMMODITY CSRPowerFuture : public virtual CSRCommodityFuture	{
		public:
			DECLARATION_FUTURE(CSRPowerFuture)
			
			~CSRPowerFuture();

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;
			
			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& data_set);

			virtual bool	CanBePurchased(_STL::string & reason) const;
			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData &context) const;
			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;

			virtual double	GetVolatility(			double 						startDate,
													double						endDate,		
													double 						strike,
													NSREnums::eVolatilityType	volatilityType,
													Boolean 					put,
													const market_data::CSRMarketData			&context) const;

			const char * GetDeliveryPeriod() const;
			void SetDeliveryPeriod(const char *period);

			const char * GetDeliveryLoad()	 const;
			void SetDeliveryLoad(const char *load);

			long GetDeliveryPeriodId()		 const;
			long GetDeliveryLoadId()		 const;
			const CSRDeliveryPeriod * GetPeriod() const;
			const CSRDeliveryLoad * GetLoad() const;

			virtual bool	IsDeltaUnderlying() const;
			virtual bool	IsVegaUnderlying() const;
			//virtual void	InitialiseRecomputeAll();
			//virtual long	GetUnderlying(int whichUnderlying) const;
			virtual double	GetFirstDerivativeUndiscounted(const market_data::CSRMarketData &context, int whichUnderlying) const;
			virtual	double	GetDelta(const sophis::CSRComputationResults& results, long *instrumentCode)	const OVERRIDE;
			virtual	double	GetQuotity(bool withTaxes = false) const;
			virtual	double	GetQuotity(instrument::eAskQuotationType type, bool spotInDifferentCurrency) const;
			virtual bool	IsWithMarginCall() const;
			virtual double	GetGrossAmount(const portfolio::CSRTransaction & transaction, double &spotForFees) const;
			virtual bool	ConstructAgain() const;
			virtual void	GetRiskValues(SSInterpolationValues &riskFuture1, SSInterpolationValues &riskFuture2) const;
			// Automatic tickets
			virtual eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<AutomaticTicket> &list) const;
			virtual long				 GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;
			virtual void				 CreateAutomaticTicket(	bool									eoy,
																long									calculation_date,
																const portfolio::CSRPosition			*position,
																_STL::vector<portfolio::CSRTransaction> &list,
																const portfolio_automatic_ticket		&port) const;

			static const char * MODEL_NAME;
			
			//virtual void	GetVegaUnderlying(const sophis::instrument::CSROption& option, _STL::set<long>& codeList, int whichUnderlying) const;

			// specific
			virtual void GetRiskSources(const market_data::CSRMarketData& context, _STL::vector<SSInterpolationPowerValues>& riskSources) const;
			virtual bool GetProfileDecompositionByWorksheetChildren(const market_data::CSRMarketData& context,
																	const CSRCommodityPower* commoPower,
																	const CSRDeliveryPeriod& dPeriod,
																	const CSRDeliveryLoad& dLoad,
																	_STL::vector<SSInterpolationPowerValues>& decomposition) const;

			/* Returns the factor to apply to the worksheet price of the current Future/Forward,
			 * to obtain the price of the same delivery to be paid at the date 'paymentDate'
			 *
			 * Example : current instrument is a Forward for Jun'06 with cash settlement the 13/7/2006
			 *           and we want to know the price factor for a contract (CSRSwap?) for the same delivery which would be paid 10/7/2006
			 *
			 * This is mainly used for the decomposition algorithm of profiles. When we're saying that Price(Sep'06) = 3*Price(Q3'06)-Price(Jul'06)-Price(Aug'06),
			 * this method is used to make the prices adjustement with respect to discount factors
			 *
			 * When the instrument is a Future (margin calls), the factor is always 1.0
			 */
			virtual double GetDiscountedPriceFactor(long currency, long paymentDate, const sophis::market_data::CSRMarketData &context) const;
			virtual bool SpecialReporting() const;
			virtual void Reporting(portfolio::SSReportingTrade* mvt, double &cash) const;
			virtual void StartReporting(long reporting_date, long portfolio_id, sophis::portfolio::PSRExtraction extraction) const;
			virtual void EndReporting(TViewMvts * position, double fxOfTheDay) const;
			virtual const _STL::vector<SSDailyFixingInfo> & GetFixingReporting() const;

			virtual bool CanHaveTomorrowFixing() const;
			bool IsRollingPeriod() const {return fIsRollingPeriod;}

		private:
			bool	fIsRollingPeriod;
			struct	SSPowerReporting
			{
				SSPowerReporting();
				SSPowerReporting(long reporting_date);
				double	fRealized;
				double	fRealizedCCY;
				double	fLongRealized;
				long	fReportingDate;
				_STL::vector<SSDailyFixingInfo> fOutFixingInfos;
			};

			mutable SSPowerReporting fCalculation;

			static const char * __CLASS__;

		public:
			int		fCommoVersion;
			_STL::vector<long> fRiskSources;
		};

		class SOPHIS_COMMODITY CSRPowerForward : public virtual CSRPowerFuture
		{
		public:
			DECLARATION_FUTURE(CSRPowerForward)
			virtual ~CSRPowerForward();

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

			virtual bool	IsWithMarginCall() const;
			//virtual bool	UseForwardCalculation() const;
			virtual sophis::instrument::eUnrealizedMethodType GetUnrealizedMethod() const;
			virtual double	GetHedgeDelta(const sophis::market_data::CSRMarketData &context, double pnlDelta, long pnlDeltaCurrency) const;
			virtual long	GetSettlementDate(long transactionDate) const;
			virtual double GetDiscountedPriceFactor(long currency, long paymentDate, const sophis::market_data::CSRMarketData &context) const;

			static const char * MODEL_NAME;
		};

		class SOPHIS_COMMODITY CSRGasFuture : public virtual CSRPowerFuture	{
		public:
			DECLARATION_FUTURE(CSRGasFuture)
			
			
			~CSRGasFuture();
			virtual bool CanBePurchased(_STL::string & reason) const;

			static const char * MODEL_NAME;
		};

		class SOPHIS_COMMODITY CSRGasHourlyFuture : public virtual CSRPowerFuture {
		public:
			DECLARATION_FUTURE(CSRGasHourlyFuture)
			
			~CSRGasHourlyFuture();
			//virtual bool CanBePurchased(_STL::string & reason) const;

			static const char * MODEL_NAME;
		};

		class CSRPowerHistoricList : public sophis::market_data::CSRHistoricList 
		{
		public:
			CSRPowerHistoricList(PInfoHisto infos);
			virtual static_data::CSRCalendar* NewCalendar() const;
		};
	}
}
SPH_EPILOG
#endif
