#ifndef _SphPeriodicityProfile_H_
#define _SphPeriodicityProfile_H_

class CSUMenu;	// internal
//struct TDlog;	// internal
#include "SphInc/SphMacros.h"


#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis	{
	namespace commodity	{

		struct SOPHIS_COMMODITY SSProfile
		{
			enum	Constant
			{
				NameLength = 32,
				CommentLength = 50,
				ParamentersLength = 40,
				ModelNameLength = 40
			};

			SSProfile();

			long	fIdent;
			long	fCommoCode;
			char	fParameters[ParamentersLength];
			char	fModelName[ModelNameLength];
			char	fName[NameLength];
			char	fComments[CommentLength];
		};

		typedef _STL::vector<SSProfile>	SSProfileVector;

		/**
		*/
		class SOPHIS_COMMODITY CSRProfile
		{
		public:
		//INTERNAL USE

			/** 
			  * Default Constructor.
			  */
			CSRProfile();

			/**
			  * Destructor. 
			  * Calling Delete().
			  */
			virtual ~CSRProfile();

			//read function
			/**
			 * initiate fPeriodicityProfiles
			 * return the sql error number
			 */
			 virtual short InitProfiles() = 0;

			/**
			 * Get the next line Id
			 * return the next line ident
			 */
			int			GetNewLineId(void);

			/**
			 * Get the periodicity profile's menu
			 * return the menu handle
			 */
			CSUMenu	*	GetMenu() const;

			/**
			 * delete fPeriodicityProfiles if size > 0
			 */
			void		Delete();

			/** Singleton
			*/
			//static CSRProfile global;
			
			/**
			 * static method returning the global CSRProfile list
			 * @return a pointer to the global list
			 */
			//static CSRProfile* GetInstance();

		//external use	
			//retrieve functions
			/**
			 * method returning the periodicity profile info for a given id code
			 * @param profileId the periodicity profile ident
			 * @return a pointer 
			 */
			const SSProfile* GetProfile(long profileId) const;

			//retrieve functions
			/**
			 * method returning the nth periodicity profile info
			 * @param whichProfile the periodicity profile position in the list starting from 0
			 * @return a pointer 
			 */
			virtual const SSProfile	*GetNthProfile(int whichProfile) const;

			//retrieve functions
			/**
			 * method returning the periodicity profile count in the list
			 * @return the count of the periodicity profiles 
			 */
			virtual long GetProfileCount() const;

			//retrieve functions
			/**
			 * method returning the periodicity profile name for a given id code
			 * @param name returns the name of the periodicity profile
			 * @param profileId the periodicity profile ident
			 */
			virtual void GetName(char *name, long profileId) const;

			void GetParameters(char *parameters, long profileId) const;

			void GetModelName(char *modelName, long profileId) const;

			//retrieve functions
			/**
			 * method returning the comments for a periodicity profile by the given id code
			 * @param comments the periodicity profile comments
			 * @param profileId the unit ident
			 */
			virtual void GetComments(char *comments, long profileId) const;

			//retrieve functions
			/**
			 * method returning the periodicity profile id for a given periodicity profile name 
			 * @param name the periodicity profile name
			 * @return the ident for the periodicity profile 
			 */
			virtual long GetIdByName(const char *name) const;

			//retrieve functions
			/**
			 * method returning the periodicity profile ident for the nth menu item
			 * @param nth_menu the nth periodicity profile menu item
			 * @return the ident for the periodicity profile
			 */
			virtual long GetIdFromMenu(int nth_menu) const;

			//retrieve functions
			/**
			 * method returning the position in the periodicity profile list for a given periodicity profile ident starting from 1
			 * @param profileId the periodicity profile ident
			 * @return the periodicity profile list position
			 */
			virtual int GetRankFromProfileID(long profileId) const;

			//retrieve functions
			/**
			 * method returning the menu position for a given periodicity profile ident
			 * @param profileId the periodicity profile ident
			 * @return the menu position
			 */
			virtual short GetMenuItemFromID(long profileId) const;

		protected:
			SSProfileVector		fProfiles;
			CSUMenu				*fMenu;
		};


		class SOPHIS_COMMODITY CSRPeriodicityProfile : public virtual CSRProfile
		{
		public:
			CSRPeriodicityProfile();

			virtual short	InitProfiles();
			/** Singleton
			*/
			static CSRPeriodicityProfile global;
			static CSRProfile* GetInstance();		
		};

		/**
		*/
/*		class SOPHIS_COMMODITY CSRHourlyProfile : CSRProfile
		{
		public:
			virtual short	InitProfiles();
			static CSRHourlyProfile global;
			static CSRProfile* GetInstance();		
		};*/
	}
}
SPH_EPILOG
#endif