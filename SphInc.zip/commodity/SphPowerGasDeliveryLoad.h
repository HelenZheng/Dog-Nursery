#ifndef _SphPowerGasDeliveryLoad_H__
#define _SphPowerGasDeliveryLoad_H__

#include "SphInc/commodity/SphCommodityPower.h"
#include "SphInc/commodity/SphCommodityGas.h"

#include __STL_INCLUDE_PATH(vector)
#ifndef _SphMacros_H_
	#include "SphMacros.h"
#endif

#include "SphInc/static_data/SphCalendar.h"

#define INITIALISE_GAS_DELIVERYLOAD_MANAGER(derivedManager)		CSRDeliveryLoadManagerGas::InitManager(derivedManager);
#define INITIALISE_POWER_DELIVERYLOAD_MANAGER(derivedManager)	CSRDeliveryLoadManagerPower::InitManager(derivedManager);

//Create default delivery load managers for POWER && GAS
void init_delivery_load_manager();

SPH_PROLOG
namespace sophis {
	namespace commodity {

		class CSRDeliveryPeriod;
		class CSRDeliveryLoad;
		struct SSWeightedPeriods;

		struct SSWeightedLoad
		{
			const CSRDeliveryLoad*	fLoad;
			double					fWeight;
		};
				
		//Base class for all Delivery Loads
		class SOPHIS_COMMODITY CSRDeliveryLoad
		{
		public:
			CSRDeliveryLoad() : fCommodity(0), fStringIdent(0) {};
			virtual ~CSRDeliveryLoad()
				{};

			const _STL::string & toString() const;
			const char * toStringCStr() const;
			long toStringIdent() const;

			virtual long AdjustFirstDeliveryDay(long firstDeliveryDayProposed) const
				{ return 0; };
			virtual long AdjustLastDeliveryDay(long lastDeliveryDayProposed) const
				{ return 0; };
			virtual int DaysInWeek() const
				{ return 0;	};
			virtual bool isGasDelivery() const
				{ return false; };


			//static const CSRDeliveryLoad * GetInstance(const char* ident);
			static long GetLastSundayOfMonth(short month, short year); // month = 1 to 12
			static long GetFirstSundayOfMonth(short month, short year); // month = 1 to 12
			static long GetSecondSundayOfMonth(short month, short year); // month = 1 to 12
			
			virtual double GetHourCount(long startDate, long endDate, long commoCode) const = 0;
			virtual double SplitIntoBlocks(_STL::vector<SSWeightedPeriods>& children, long date, long commodity) const = 0;
			virtual int GetFirstDeliveryBlock(long day) const = 0;
			virtual int GetLastDeliveryBlock(long commodity, long day) const = 0;
			virtual bool CanBeUsedInWorksheets() const = 0;
			virtual void GetLoadDecompositionForDay(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode) const{};
			virtual void GetLoadDecompositionForMonth(_STL::vector<SSWeightedLoad>& outDecomposition, long commoCode, const CSRDeliveryPeriod* period) const{};
			virtual const char *ShortName() const = 0;

			virtual long GetCommoCode() const{
				return fCommodity;
			}

		protected:				
			static double SplitHourlyIntervalIntoBlocks(_STL::vector<SSWeightedPeriods>& children, int firstBlock, int lastBlock, long commodity);

			virtual _STL::string _internal_toString() const = 0;

			long fCommodity;
			long fStringIdent;
			_STL::string fString;
		private:
		};

		class SOPHIS_COMMODITY CSRGasDeliveryLoad : public virtual CSRDeliveryLoad
		{
		public:
			//static const CSRDeliveryLoad * GetInstance(const char* ident);				
			virtual double SplitIntoBlocks(_STL::vector<SSWeightedPeriods>& children, long date, long commodity) const;

			virtual bool isGasDelivery() const
				{ return true; };

		protected:
			CSRGasDeliveryLoad() {};

		private:
		};

		//Base class for delivery load management
		class SOPHIS_COMMODITY CSRDeliveryLoadManager
		{
		protected:
			virtual CSRDeliveryLoad* CreateInstance(const char* loadId, long commoCode) const = 0;
		};

		//Manages creation of Delivery load for POWER
		class SOPHIS_COMMODITY CSRDeliveryLoadManagerPower : public virtual CSRDeliveryLoadManager
		{
		public:
			CSRDeliveryLoadManagerPower();
			static void InitManager(CSRDeliveryLoadManagerPower* newManager);
			static const CSRDeliveryLoadManagerPower& GetInstance() { return *gDeliveryLoadManager ;}
		protected:
			static CSRDeliveryLoadManagerPower* gDeliveryLoadManager;			
			virtual CSRDeliveryLoad* CreateInstance(const char* loadId, long commoCode) const;
			friend CSRDeliveryLoad * CSRCommodityPower::CreateLoadInstance(const char* loadName) const;
		};

		//Manages creation of Delivery load for GAS
		class SOPHIS_COMMODITY CSRDeliveryLoadManagerGas : public virtual CSRDeliveryLoadManager
		{
		public:
			CSRDeliveryLoadManagerGas();
			static void InitManager(CSRDeliveryLoadManagerGas* newManager);
			static const CSRDeliveryLoadManagerGas& GetInstance() { return *gDeliveryLoadManager ;}
		protected:
			static CSRDeliveryLoadManagerGas* gDeliveryLoadManager;
			virtual CSRDeliveryLoad* CreateInstance(const char* loadId, long commoCode) const;
			friend CSRDeliveryLoad * CSRCommodityGas::CreateLoadInstance(const char* loadName) const;
		};
	};
};
SPH_EPILOG

#endif
