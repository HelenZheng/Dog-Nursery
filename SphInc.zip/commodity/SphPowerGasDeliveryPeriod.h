#ifndef _SphPowerGasDeliveryPeriod_H__
#define _SphPowerGasDeliveryPeriod_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"

#include "SphInc/commodity/SphCommodityPower.h"
#include "SphInc/commodity/SphCommodityGas.h"
#include "SphInc/instrument/SphSwap.h"
#include "SphInc/static_data/SphCalendar.h"

#define INITIALISE_POWER_DELIVERYPERIOD_MANAGER(derivedManager)	CSRDeliveryPeriodManagerPower::InitManager(new derivedManager);
#define INITIALISE_GAS_DELIVERYPERIOD_MANAGER(derivedManager)	CSRDeliveryPeriodManagerGas::InitManager(new derivedManager);
#define INITIALISE_POWER_UK_DELIVERYPERIOD_MANAGER(derivedManager)	CSRDeliveryPeriodManagerPowerUK::InitManager(derivedManager);

#ifndef MAX
#define MAX(a,b)	(((a)>(b))?(a):(b))
#endif

#ifndef MIN
#define MIN(a,b)	((a < b) ? a : b)
#endif

SPH_PROLOG
namespace sophis {
	namespace tools	{
			class CSRCacheOfString;
	}
	namespace commodity {


		/* Warning : The order of the eDeliveryPeriodType enum is important. The financial scenarion decomposition relies on this order.
		 */

		enum eDeliveryPeriodType
		{
			eDPTUndefined,
			eDPTYearly,
			eDPTGasYear,
			eDPTSeasonal,
			eDPTQuarterly,
			eDPTMonthly,
			eDPTBalanceOfMonth,
			eDPTGasBalanceOfMonth,
			eDPTWeekly,
			eDPTBalanceOfWeek,
			eDPTGasBalanceOfWeek,
			eDPTWorkingDaysNextWeek,
			eDPTWeekend,
			eDPTWithinDay,
			eDPTDayAhead,
			eDPTDayPlusK,
			eDPTDaily,
			eDPTDaysInterval,
			eDPTHourly,
			eDPTUnavailableHourly,
			eNonStandardPeriod,
			eNonStandardProfile,
			eUSER_TOOLKIT = 1000		/* Toolkit period types start here */
		};

		class CSRDeliveryPeriod;
		class CSRDeliveryLoad;
		class CSRDeliveryPeriodManagerPower;
		class CSRDeliveryPeriodManagerPowerUK;
		class CSRDeliveryPeriodManagerGas;

		class DLGNonStandardPowerProfile;
		struct SwapInfosForNonStandardProfile;

		struct SOPHIS_COMMODITY SSWeightedPeriods
		{
			SSWeightedPeriods()
			{
				fWeight			= 0.;
				fDeliveryLoad	= NULL;
			}

			_STL::string				fDeliveryPeriod;
			double						fWeight;
			const CSRDeliveryLoad*		fDeliveryLoad;
		};

		extern SOPHIS_FIT tools::CSRCacheOfString gDeliveryLoadString;

		/* Class CSRDeliveryPeriod
		 *
		 * This is the main class in sophis::commodity for management of Power&Gas delivery periods
		 * This class interface allows the management of any kind of delivery periods, including non-standard delivery periods which delivery different amounts of energy the different hours of the different days
		 * However, most delivery periods are standard delivery periods and represent a time interval during which energy is delivered continuously or according to the a delivery load
		 */

		class  SOPHIS_COMMODITY CSRDeliveryPeriod
		{
		public:
			CSRDeliveryPeriod() : fCommodity(0), fStringIdent(0) {};
			virtual ~CSRDeliveryPeriod()
				{};

			/* Returns a string that uniquely identifies the delivery period for a commodity
			* The string can be stored, whereas the pointer to the CSRDeliveryPeriod objects should never be stored
			* There is also a 'long' which corresponds to the string ident (see LongStringMapping)
			*/

			const _STL::string & toString() const;
			const char * toStringCStr() const;
			long toStringIdent() const;

			/* Returns the first delivery day of the period, according to the delivery load.
			 * For a Baseload delivery load, the first day of period "Jan 2006" is 1/1/2006
			 * However, for a Peakload delivery load, the first day of period "Jan 2006" is "2/1/2006" because the Jan 1st is a Sunday and Peakload does not deliver during week-ends
			 */
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad) const
				{ return 0; };

			/* Returns the next delivery day of the period, according to the delivery load and the refenrence date.
			 * When the reference date is the default value (i.e. 0), today is used as the reference date.
			 */
			virtual long GetNextDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate = 0) const;

			/* Returns the first delivery day of the period, according to the delivery load
			* and according to the reference date.
			*/
			virtual long GetFirstDeliveryDay(const CSRDeliveryLoad &dLoad, long referenceDate) const;

			/* Returns the last delivery day of the period, according to the delivery load.
			 */
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad &dLoad) const
			{ return 0; };

			/* Returns the last delivery day of the period, according to the delivery load
			 * and according to the reference date.
			 */
			virtual long GetLastDeliveryDay(const CSRDeliveryLoad& dLoad, long referenceDate) const;
			
			/* Returns the delivery period type (Monthly, Quarterly, Daily, ...)
			 */
			virtual eDeliveryPeriodType GetDeliveryPeriodType() const
				{ return eDPTUndefined; };

			/* Check wether there should be deliveries at some "day" according to the input delivery load "dLoad"
			 * Returns true if there are deliveries
			 *         false if not
			 */
			virtual bool isDeliveryDay(const CSRDeliveryLoad &dLoad, long day) const;

			/* These two method are similar to GetFirstDeliveryDay() and GetLastDeliveryDay() but the time interval of delivery is limited by the start date and end date of the swap
			 */
			inline long GetFirstDeliveryDayForSwap(const CSRDeliveryLoad &dLoad, const sophis::instrument::CSRSwap *swap) const
			{
				if (!swap)
					return 0;
				long x = GetFirstDeliveryDay(dLoad);
				return MAX(x, swap->GetStartDate());
			};
			inline long GetLastDeliveryDayForSwap(const CSRDeliveryLoad &dLoad, const sophis::instrument::CSRSwap *swap) const
			{
				if (!swap)
					return 0;
				long x = GetLastDeliveryDay(dLoad);
				return MIN(x, swap->GetEndDate());
			};

			/* GetChildren()
			 *
			 * Decomposition of a period into smaller periods. The coefficients are computed according to delivery hours and days.
			 * The child periods that are completely in the past are ignored.
			 * In all cases, the weights correspond to the full decomposition.
			 */			
			virtual bool GetChildren(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& children, long today, long commodity, _STL::vector<SSPeriodAndLoad>& periodTrack) const = 0;

			/* GetParents()
			 *
			 * This method is the inverse of GetChildren()
			 * It returns the smallest set of periods that contains the period
			 * In general there is only one parent, for example Q1 2006 is the parent of Jan 2006
			 */			
			virtual void GetParents(const CSRDeliveryLoad &dLoad, _STL::vector<SSWeightedPeriods>& parents, _STL::vector<SSPeriodAndLoad>& periodTrack) const = 0;
			
			/* GetPeriodHourCount()
			 * Returns the number of hours of delivery for the period
			 * The result is in *real* hours, so the result in MWH is obtained by multiplying it according to the commodity granularity when the commodity delivers by 30min, 15min or ...
			 * When the period is a non-standard profile, the result obtained is multiplied, for each intraday delivery block by the quantities that define the profile (all values to 1.0 being a standard period)
			 */
			virtual double GetPeriodHourCount(const CSRDeliveryLoad &dLoad, long startDate, long endDate) const;
			
			virtual void GetIntradayDeliveryQuantities(const CSRDeliveryLoad *dLoad, long day, long commodityCode, _STL::vector<SSWeightedPeriods> &deliveries) const = 0;
			
			/* average of the discount during the delivery period
			 * when the delivery period has begun, only the future part (starting tomorrow) is used
			 */
			virtual double GetDiscountedFactor(const CSRDeliveryLoad *dLoad, long currency, long evaluationDate, long commodityCode, const market_data::CSRMarketData &context) const;

			virtual long GetExpiryDate(const static_data::CSRCalendar* calendar, const CSRDeliveryLoad* dLoad) const;

			/* Returns true when the period correspond to a changing interval (WITHIN_DAY, DAY_AFTER, H1, ...)
			 * Returns false when the period is fixed in time (Q1 2006)
			 */
			virtual bool isRollingPeriod() const
			{ return false; }

			/* Returns true when it is mandatory, for a correct commodity setup, to define in the worksheet the price of the standard contract for this period
			 */
			virtual bool MustBeInWorksheet() const {return false;}

			//static void DeleteDeliveryProfile(const char* ident);

			virtual bool operator !=(const CSRDeliveryPeriod& period) const
			{
				return toString()!=period.toString();
			}

			static bool IsNull(const CSRDeliveryPeriod *dPeriod, const CSRDeliveryLoad *dLoad);
			
			/* Returns true when the commodity that corresponds to commodityCode has the same type as the commodity of this period.
			 */
			virtual bool IsValidForCommodity(long commodityCode) const;

			virtual void DecompositionInTargetPeriod(eDeliveryPeriodType targetPeriodType, const CSRDeliveryLoad &dLoad, const CSRCommodityPower *commo, _STL::set<const CSRDeliveryPeriod *> &outResult, _STL::vector<SSPeriodAndLoad> &periodTrack) const;
			void FinancialDecomposition(eDeliveryPeriodType targetPeriodType, const CSRDeliveryLoad &dLoad, long commodity, _STL::vector<SSWeightedPeriods>& decompositionExactPeriods, _STL::vector<SSWeightedPeriods>& decompositionApproxPeriods, _STL::vector<SSPeriodAndLoad>& periodTrack) const;

			/* Returns true when the price of a contract for this period must be obtained either directly from worksheet, or from the prices of child periods, but not from the prices of parent periods
			 * Returning true in this method makes it unnecessary to implement GetParents() for the period
			 * An example is "Summer 2006", which price should be obtained from "Q2 2006" and "Q3 2006"
			 */
			virtual bool MustComputePriceByChildrenPrices() const
			{ return false; }

			/* Returns the period representing the intersection of the current period with the flow start/end dates of a swap
			 */
			virtual const CSRDeliveryPeriod* GetFlowDeliveryPeriod(const CSRDeliveryLoad& load, const CSRCommodityPower* commodity, const long startDate, const long endDate) const;
			virtual void SetCommodityCode(long code) { fCommodity = code; };
			enum eFlattendInto
			{
				eFlattenUnable,
				eFlattenToMonths,
				eFlattenToDays,
				eFlattenToHours
			};

			// Note : this structure contains a pointer, hence it should be in memory only for the duration of a computation
			struct DayAndHour
			{
			public:
				DayAndHour() : year(0), month(0), day(0),pHourPeriod(NULL){};
				const sophis::commodity::CSRHourlyDeliveryPeriod *pHourPeriod; // when null, the structure represents the entire day
				double hourCount;
				short year;
				short month;
				short day;
			};

			/* Returns a list of periods corresponding to the current period splitted according to a strip of options granularity : monthly, daily, hourly
			 */
			virtual CSRDeliveryPeriod::eFlattendInto FlattenToMonths(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load, long commodityCode) const;
			virtual CSRDeliveryPeriod::eFlattendInto FlattenToDays(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load, long commodityCode, long startDate=0, long endDate=0) const;
			virtual CSRDeliveryPeriod::eFlattendInto FlattenToHours(_STL::vector<CSRDeliveryPeriod::DayAndHour>& outFlattened,const CSRDeliveryLoad& load, long commodityCode, long startDate=0, long endDate=0) const;

		protected:
			virtual _STL::string _internal_toString() const = 0;

			static long GetFirstMondayOfYear(short year);

			long fCommodity;//commodity code
			long fStringIdent;
			_STL::string fString;
		};

		//Manages creation of Delivery period for POWER

		class SOPHIS_COMMODITY CSRDeliveryPeriodManagerPower
		{
		public:
			static void InitManager(CSRDeliveryPeriodManagerPower* newManager);
			static const CSRDeliveryPeriodManagerPower& GetInstance() { return *gDeliveryPeriodManager ;}
		protected:
			virtual CSRDeliveryPeriod* CreateInstance(const char* periodId, long commo, const SwapInfosForNonStandardProfile *swapInfos=NULL,const CSRDeliveryPeriod *pSourceDeliveryPeriod=NULL) const;
			static CSRDeliveryPeriodManagerPower* gDeliveryPeriodManager;

			friend CSRDeliveryPeriod * CSRCommodityPower::CreatePeriodInstance(const char* periodId,
															const SwapInfosForNonStandardProfile *swapInfos,
															const CSRDeliveryPeriod * pSourceDeliveryPeriod) const;
		};

		//Manages creation of Delivery period for GAS

		class SOPHIS_COMMODITY CSRDeliveryPeriodManagerGas
		{
		public:
			static void InitManager(CSRDeliveryPeriodManagerGas* newManager);
			static const CSRDeliveryPeriodManagerGas& GetInstance() { return *gDeliveryPeriodManager ;}
		protected:
			virtual CSRDeliveryPeriod* CreateInstance(const char* periodId, long commo, const SwapInfosForNonStandardProfile *swapInfos=NULL, const CSRDeliveryPeriod *pSourceDeliveryPeriod=NULL) const;
			static CSRDeliveryPeriodManagerGas* gDeliveryPeriodManager;

			friend CSRDeliveryPeriod * CSRCommodityGas::CreatePeriodInstance(const char* periodId,
															const SwapInfosForNonStandardProfile *swapInfos, 
															const CSRDeliveryPeriod * pSourceDeliveryPeriod) const;
		};

		/*class SOPHIS_COMMODITY CSRPowerDeliveryPeriod {
			public:
				static void DeleteDeliveryProfile(const char* ident);

				static void ClearCache(void);

			private:

			friend class CSRDeliveryPeriod;
		};

		class SOPHIS_COMMODITY CSRPowerUKDeliveryPeriod {
		public:
			static void DeleteDeliveryProfile(const char* ident);

			static void ClearCache(void);

		private:
			friend class CSRDeliveryPeriod;
		};

		class SOPHIS_COMMODITY CSRGasDeliveryPeriod
		{
			public :
				static void ClearCache(void);

		protected:
				static void DeleteDeliveryProfile(const char* ident);

		private:
			friend class CSRDeliveryPeriod;
		};*/
	};
};
SPH_EPILOG

#endif
