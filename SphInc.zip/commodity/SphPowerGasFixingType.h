#ifndef __CSRPOWERGASFIXINGTYPE_H_
#define __CSRPOWERGASFIXINGTYPE_H_

#include "SphInc/commodity/SphCommodityPower.h"
#include "SphInc/commodity/SphFixingType.h"
#include "SphInc/instrument/SphSwap.h"
#include "SphInc/static_data/SphHistoricalData.h"

SPH_PROLOG
namespace sophis	{
	namespace commodity	{		

		struct OneFixingPower : CSRFixingType::OneFixing
		{
			bool						fIsStandard;
			const char*					fDeliveryPeriod;
			const char*					fDeliveryLoad;
			const instrument::CSRSwap*	fSwap;
			sophis::instrument::SSFlow	fFlow;
			short						fWhichLeg;
		};


		class SOPHIS_COMMODITY CSRPowerFutureFixingTypeImpl : public virtual CSRFixingType::CSRFixingTypeImpl
		{
		public:
			CSRPowerFutureFixingTypeImpl(const instrument::CSRSwap *parentSwap, int whichLeg);

		protected:
			CSRPowerFutureFixingTypeImpl();
			void Initialize(const instrument::CSRSwap *parentSwap, int whichLeg);

		public:
			virtual bool ComputeBreakDown(	long						today,
											const instrument::SSFlow	&flow,
											const static_data::CSRCalendar			*swap_calendar,
											const CSRCommodity			*commodity,
											long						swap_unit,
											long						strike_unit,
											bool						forceCalendarCheck,
											const static_data::CSRHistoricalData &histoData);

			virtual bool	GetRiskSourceStructures(	_STL::set<long>&				inoutDeltaGammaForSwapFutureArray,
														_STL::set<long>&				inoutVegaForSwapFutureArray,
														_STL::set<long>&				inoutVegaForSwaptionFutureArray,
														_STL::set<long>&				inoutCurrencyCodeArray,
														_STL::vector<SSInstVersion>&	outVersionInfos) const;

			virtual bool GetCouponGenerationDate(int whichFlow, long& generationDate, long& paymentDate) const;
						
			bool GetPhysicalCoupon(	int													whichFlow,
									_STL::vector<instrument::CSRSwap::SSPhysicalCoupon>	&physicalCoupon,
									_STL::vector<_STL::string>							&outFOComments,
									_STL::vector<_STL::string>							&outBOComments,
									const static_data::CSRHistoricalData				&histoData) const;

			bool GetCouponGenerationValue(	int		whichFlow, 
											long&	paymentCurrency,
											double& cashUnitCoupon, 
											double& unitQuotity,
											const static_data::CSRHistoricalData &histoData) const;

			bool GetFactorForDelta(double swapNominal, double tx, double& factorForDelta) const;

			bool IsValidCommoditySwap(const market_data::CSRMarketData &param, _STL::string &errorMessage) const;
			virtual double GetVolatility(	int									isolateNthFlow,
											double 								startDate,
											double								endDate,		
											double 								strike,
											NSREnums::eVolatilityType			volatilityType,
											Boolean 							put,
											const market_data::CSRMarketData	&context) const;

			/* GetPeriodFixedPrice(...)
			 *
			 * computes the sum of fixed price according to the delivery profile between start date and end date
			 * @param forcedCashValue    : when not NULL, this forces to replace the fixing values by a constant, which is usually the price of the cash leg.
			 * @param outPrice           : result of the sum
			 * @param outLatestFixedDate : for financial float legs, the latest date for which a Fixing was found
			 * @return true when successfully completed, false otherwise (wrong type of commodity)
			*/

			static bool GetPeriodFixedPrice(long start,
											long end,
											const CSRDeliveryPeriod *period,
											const CSRDeliveryLoad *load,
											const CSRCommodityPower *commodityPower,
											long fixingcolumn,
											double spread,
											const double *forcedCashValue,
											double &outPrice,
											 long   &outLatestFixedDate,
											 const static_data::CSRHistoricalData &histoData,
											_STL::vector<SSDailyFixingInfo> *outFixingInfos = NULL,
											bool checkPowerDeliveryDaysForRollingPeriod = true,
											bool *missingFixing = NULL,
											double capPrice = 1e99,
											double floorPrice = -1e99,
											const CSRDeliveryPeriod *pNonStdCashProfile = NULL);

			virtual double GetFixedCashPart(long tag_fixing, const market_data::CSRMarketData &context) const;

		protected:
			virtual void InitVegaOptimizationFlow(	int									nthFlow,
													SSVegaCrossedVega&	vegaFlows,
													double 								startDate,
													long								endDate,
													double 								strike,
													NSREnums::eVolatilityType			volatilityType,
													Boolean 							put,
													const market_data::CSRMarketData	&context) const;
		};

		class SOPHIS_COMMODITY CSRPowerFutureFixingTypeImplGRD : public virtual CSRPowerFutureFixingTypeImpl
		{
		public:
			CSRPowerFutureFixingTypeImplGRD(const instrument::CSRSwap *parentSwap, int whichLeg);

		protected:
			CSRPowerFutureFixingTypeImplGRD();
			void Initialize(const instrument::CSRSwap *parentSwap, int whichLeg);

		public:
			virtual ~CSRPowerFutureFixingTypeImplGRD();

			virtual double GetVolatility(	int									isolateNthFlow,
											double 								startDate,
											double								endDate,		
											double 								strike,
											NSREnums::eVolatilityType			volatilityType,
											Boolean 							put,
											const market_data::CSRMarketData	&context) const;

			virtual void InitVegaOptimization(	_STL::vector<SSVegaCrossedVega>&	vegaFlows,
				double 									startDate,
				long									endDate,
				double 									strike,
				NSREnums::eVolatilityType				volatilityType,
				Boolean 								put,
				const market_data::CSRMarketData		&context) const;

			//virtual NSREnums::eVolatilityType	GetVolatilityType() const;
			virtual bool						IsTheoreticalWithoutFixedValue() const;

		private:
			//NSREnums::eVolatilityType fVolatilityType;

		};

		class SOPHIS_COMMODITY CSRPowerFutureFixingTypeImplVPP : public virtual CSRPowerFutureFixingTypeImpl
		{
		public:
			CSRPowerFutureFixingTypeImplVPP(const instrument::CSRSwap *parentSwap, int whichLeg);

		protected:
			CSRPowerFutureFixingTypeImplVPP();
			void Initialize(const instrument::CSRSwap *parentSwap, int whichLeg);

		public:
			virtual ~CSRPowerFutureFixingTypeImplVPP();

			virtual double GetVolatility(	int	isolateNthFlow,
											double 								startDate,
											double								endDate,		
											double 								strike,
											NSREnums::eVolatilityType			volatilityType,
											Boolean 							put,
											const market_data::CSRMarketData	&context) const;

			//virtual NSREnums::eVolatilityType GetVolatilityType() const;

			virtual void InitVegaOptimization(	_STL::vector<SSVegaCrossedVega>&	vegaFlows,
												double 									startDate,
												long									endDate,
												double 									strike,
												NSREnums::eVolatilityType				volatilityType,
												Boolean 								put,
												const market_data::CSRMarketData		&context) const;

			virtual bool IsTheoreticalWithoutFixedValue() const;

		private:
			//NSREnums::eVolatilityType fVolatilityType;

		};

		class CSRPowerFutureBreakDown : public CSRFixingType::CSRBreakDown
		{
		public:
			CSRPowerFutureBreakDown(const CSRFixingType::CSRFixingTypeImpl* fixingTypeImpl) : CSRBreakDown(fixingTypeImpl) {}

			virtual double GetTheoreticalValue(	long								 tag_fixing,
												long								 forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*fixedValue) const;
			virtual void	GetPriceDeltaGamma(	long								 tag_fixing,
												long								 forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*price,
												instrument::DeltaGamma				*delta_gamma) const;
			virtual void	GetPriceWeightDate(	long								 tag_fixing,
												long								 forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*price,
												instrument::DeltaGamma				*weight_date) const;

			virtual double GetBreakDownTheoreticalValue(long								 tag_fixing,
														long								 forexTagFixing, 
														const market_data::CSRMarketData	&context, 
														FixingOutput						*fixedValue	   = NULL,
														sophis::commodity::SSDeltaGamma		*outDeltaGamma = NULL) const;

		public:
			OneFixingPower	fFixing;
		};

		class SOPHIS_COMMODITY CSRPowerCashFixingTypeImpl: public virtual CSRFixingType::CSRFixingTypeImpl
		{
		public:
			CSRPowerCashFixingTypeImpl(const instrument::CSRSwap *parentSwap, int whichLeg);

		protected:
			CSRPowerCashFixingTypeImpl();
			void Initialize(const instrument::CSRSwap *parentSwap, int whichLeg);

		public:
			virtual	bool ComputeBreakDown(	long						today,
											const instrument::SSFlow	&flow,
											const static_data::CSRCalendar			*swap_calendar,
											const CSRCommodity			*commodity,
											long						swap_unit,
											long						strike_unit,
											bool						forceCalendar,
											const static_data::CSRHistoricalData &histoData);
			virtual bool GetRiskSourceStructures(	_STL::set<long>&				inoutDeltaGammaForSwapFutureArray,
													_STL::set<long>&				inoutVegaForSwapFutureArray,
													_STL::set<long>&				inoutVegaForSwaptionFutureArray,
													_STL::set<long>&				inoutCurrencyCodeArray,
													_STL::vector<SSInstVersion>&	outVersionInfos) const;

			bool GetCouponGenerationValue(	int		whichFlow, 
											long&	paymentCurrency,
											double& cashUnitCoupon, 
											double& unitQuotity,
											const static_data::CSRHistoricalData &histoData) const;

			bool GetCouponGenerationDate(	int		whichFlow, 
											long&	generationDate, 
											long&	paymentDate) const;

			virtual void SetCashValue(double forcedCash);

			virtual bool IsTheoreticalWithoutFixedValue() const;

			double fCapPrice,fFloorPrice;

		protected:
			double fForcedCash;

		};

		class CSRBreakDownPowerCash : public CSRFixingType::CSRBreakDown
		{
		public:
			CSRBreakDownPowerCash() : CSRBreakDown(NULL) {};

			virtual double GetTheoreticalValue(	long								tag_fixing,
												long								forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*fixedValue) const;
			virtual void	GetPriceDeltaGamma(	long								tag_fixing,
												long								forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*price,
												instrument::DeltaGamma				*delta_gamma) const;
			virtual void	GetPriceWeightDate(	long								tag_fixing,
												long								forexTagFixing, 
												const market_data::CSRMarketData	&context,
												FixingOutput						*price,
												instrument::DeltaGamma				*weight_date) const;
		protected:
			virtual double GetBreakDownTheoreticalValue(long								tag_fixing,
														long								forexTagFixing, 
														const market_data::CSRMarketData	&context, 
														FixingOutput						*fixedValue    = NULL,
														sophis::commodity::SSDeltaGamma		*outDeltaGamma = NULL) const;
		public:
			OneFixingPower fFixing;
		};
	};
}
SPH_EPILOG
#endif
