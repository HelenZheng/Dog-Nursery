
#ifndef _SPHPOWERGASLOADSPLITSCENARIO_H__
#define _SPHPOWERGASLOADSPLITSCENARIO_H__
/*******************************************************************/
/********************** LoadSplit Scenario classes *****************/
/*******************************************************************/
#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/commodity/SphCommodityPower.h"

#ifndef GCC_XML

SPH_PROLOG
namespace sophis 
{
	namespace portfolio
	{
		class CSRPortfolio;
		class CSRPosition;
		class CSRExtraction;
	};

	namespace instrument
	{
		class CSRInstrument;
	};

	namespace commodity
	{

		class CSRPowerFuture;
		struct PeriodKey
		{
			PeriodKey(void): fYear(-1), fMonth(-1){}
			PeriodKey(const CSRCommodityPower *pCommo, const CSRDeliveryLoad *pLoad, const _STL::string &sPeriod);
			PeriodKey(const CSRPowerFuture *pFut, const CSRCommodityPower *pCommo);

			_STL::string toString(long commoCode) const;
			bool operator  < (const PeriodKey &other) const
			{
				return (fYear == other.fYear) ? fMonth < other.fMonth : fYear < other.fYear;
			}
			bool operator != (const PeriodKey &other) const 
			{
				return fYear != other.fYear || fMonth != other.fMonth;
			}
			void operator  = (const PeriodKey &other)
			{
				fYear = other.fYear;
				fMonth= other.fMonth;
			}
			bool differentYear(const PeriodKey &other) const
			{
				return fYear != other.fYear;
			}
			bool differentQuarter(const PeriodKey &other) const
			{
				return  Quarter() != other.Quarter();
			}

			short Quarter(void) const
			{
				return static_cast<short>(fMonth < 0 ? -1 : (fMonth-1) / 3 + 1);
			}
			int fYear;
			int fMonth;
		};
		struct ComparePeriodKey
		{
			bool operator()(const PeriodKey &a, const PeriodKey &b) const
			{
				return a < b;
			}
		};

		class LoadManager
		{
		public:
			enum LoadType_e
			{
				kNotFound = -1,
				kBaseload,
				kPeakload,
				kOffpeak
			};
			/**
			@return the enum LoadType_e value associated to the load
			*/
			static int DeliveryLoadType(_STL::string load);

			/**
			@return the opposite load for an offpeak or a peakload : returns "Peakload 7-23" when given "Offpeak 7-23" 
			*/
			static _STL::string ComplementaryLoad(_STL::string load);

			/**
			@return true when both loads are either offpeaks or peakloads and defined with the same time span
			*/
			static bool CmpLoads(_STL::string load1, _STL::string load2);

			static bool DeliveryLoadIsInBase(const _STL::string &load, bool IsBaseloadType);

		};

		//If you change this enum, do not forget to change Cache Aggregation (at the end of RunPowerSplitScenario)
		enum eKindOfCalculationData
		{
			eDelta,
			ePowerMTM,
			eMTMforOption,

			eExProbaGlobalNoSmile,
			eExProbaGlobalWithSmile,

			eExProbaPersentNoSmile,
			eExProbaPersentWithSmile,
		};

		//If you change this enum, do not forget to change Cache Aggregation (at the end of RunPowerSplitScenario)
		enum eSplitBasis 
		{
			eBaseloadBasis,
			eOffpeakBasis,
			eNoSplitBasis, // Used for option 
		};

		struct CalculationData
		{
			CalculationData()
			{
				fDelta		= 0;
				fPowerMTM	= 0.;
				fExProbaGlobalNoSmile = 0;
				fExProbaPersentNoSmile = 0;
				fExProbaGlobalWithSmile = 0;
				fExProbaPersentWithSmile = 0;
				fMTMforOption = 0;
			}

			double GetValue(eKindOfCalculationData aKindOfData) const;
			void   SetValue(eKindOfCalculationData aKindOfData, double dValue);

			double fDelta;
			double fPowerMTM;
			double fExProbaGlobalNoSmile;
			double fExProbaPersentNoSmile;
			double fExProbaGlobalWithSmile;
			double fExProbaPersentWithSmile;
			double fMTMforOption;

		};

		class PowerLoadSplitByLoad
		{
		public:
			PowerLoadSplitByLoad(){};
			virtual ~PowerLoadSplitByLoad(){};

			_STL::map<_STL::string, CalculationData> fSplitByLoadMap;	// map<Load, Data> 
			_STL::vector<_STL::string> fVPPLoadDecomposition;
			double GetValue(_STL::string aLoad, eKindOfCalculationData aKindOfData) const;
			CalculationData& GetData(_STL::string aLoad);

		};

		class PowerLoadSplitByBasis
		{
		public:
			PowerLoadSplitByBasis(){};
			virtual ~PowerLoadSplitByBasis(){};

			_STL::map<eSplitBasis, PowerLoadSplitByLoad> fSplitByBasisMap;	// map<Basis, Data> 

			double GetValue(_STL::string aLoad, eKindOfCalculationData aKindOfData, eSplitBasis aBasis) const;
			CalculationData& GetData(_STL::string aLoad, eSplitBasis aBasis);
		};

		class PowerLoadSplitByPosition
		{
		public:
			PowerLoadSplitByPosition(){};
			virtual ~PowerLoadSplitByPosition(){};

			_STL::map<long, PowerLoadSplitByBasis> fSplitByPositionMap;	// map<Position, Data> 
			_STL::vector<_STL::string> fVPPLoadDecomposition;

			double GetValue(long aInstrumentCode, _STL::string aLoad, eKindOfCalculationData aKindOfData, eSplitBasis aBasis) const;
			CalculationData& GetData(long aInstrumentCode, _STL::string aLoad, eSplitBasis aBasis);

		};
		class PowerLoadSplitByPeriod
		{
		public:
			PowerLoadSplitByPeriod(){};
			virtual ~PowerLoadSplitByPeriod(){};

			_STL::map<PeriodKey, PowerLoadSplitByPosition, ComparePeriodKey> fSplitByPeriodMap;	
			//double CreateRemainingTimePerLoad(const _STL::string &load, const PeriodKey &periodKey, long commoCode) const;
			double GetValue( PeriodKey	aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eKindOfCalculationData aKindOfData, eSplitBasis aBasis) const;
			CalculationData& GetData( PeriodKey	aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eSplitBasis aBasis);
		};

		class PowerLoadSplitByCommo
		{
		public:
			PowerLoadSplitByCommo(){};
			virtual ~PowerLoadSplitByCommo(){};

			_STL::map<long, PowerLoadSplitByPeriod> fSplitByCommoMap; // map<CommoCode, Period>

			double GetValue(long aCommodityCode, PeriodKey	aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eKindOfCalculationData aKindOfData, eSplitBasis aBasis) const;
 			CalculationData& GetData(long aCommodityCode, PeriodKey	aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eSplitBasis aBasis);

			static _STL::set<_STL::string> fLoadSet;
		};

		#define nMaxLevelCount 10 // 10 hierarchical levels max

		struct SSIdByLevel // used to store the ID of (counterparties, sectors, ...) for each level
		{
			long fId[nMaxLevelCount+1]; 
			SSIdByLevel(){ memset(fId, 0, sizeof(fId)); };
		};

		struct CustomSort // Sort as in Customer Extraction 
		{
			long nPos;
			long nCode;

			CustomSort()
			{
				nPos=0;
				nCode=0;
			}

			bool operator  < (const CustomSort &other) const
			{
				return nPos < other.nPos;
			}


		};

		class DummyAggregationMap //Used to customer aggregation
		{
		public:
			// Aggregation tree
			int fIconeId;		// Icon to be displayed  
			_STL::string fName; // Caption to be displayed
			int fLevel;
			mutable _STL::map<long, DummyAggregationMap> fAggregationMap; // realization of aggregation tree
			DummyAggregationMap():fLevel(0), fIconeId(0), fName(""){};
			virtual ~DummyAggregationMap(){};

			DummyAggregationMap& AddAggregationLevel(long nIconId, _STL::string sName, SSIdByLevel aIdByLevel);

			// Data for last aggregation level
			PowerLoadSplitByCommo fMapByCommo; 
			PowerLoadSplitByCommo& GetSplitByCommo();
			double GetValue(SSIdByLevel aIdByLevel, long aCommodityCode, PeriodKey aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eKindOfCalculationData aKindOfData, eSplitBasis aBasis) const;
			CalculationData& GetData(SSIdByLevel aIdByLevel, long aCommodityCode, PeriodKey	aByPeriodKey, long aInstrumentCode, _STL::string aLoad, eSplitBasis aBasis);
		};


		struct SSSplitData
		{
			long   nPeakloadFutureCode;
			double dPeakloadFutureDelta; // it meant a Delta that displayed in the calculette, and not Future->GetQuotity();

			long   nBaseloadFutureCode;
			double dBaseloadFutureDelta;

			long   nOffpeakFutureCode;
			double dOffpeakFutureDelta;

			double dCashPrice;

			double dCurveWeightBase;
			double dCurveWeightPeak;
			bool   bUseCurveWeights;

			short nCashLegWay;
			short nPowerLegWay;

			double quantity;
			double nNbOfInstruments;

			LoadManager::LoadType_e fContractLoadType;

			long nCommodityCode;
			long nSwapCode;		  // used for Swap only, must be set to 0 for instrument of others types
			long nInstrumentCode; // code of instrument booked in position 

			double dDiscountFactor; // Used for Swap without margin call. 1 by default

			PowerLoadSplitByCommo* pSplitByCommo;

			SSSplitData()
			{
				memset(this, 0, sizeof(*this));
				bUseCurveWeights = false;
				dDiscountFactor	 = 1;
			}
		};

		enum eSwapLegConfig
		{
			eFloatFixed,
			eFixedFloat,
			eFloatFloat,
			eSwapLegConfigError,
		};
		
		void Split(SSSplitData& aSplitData, bool bSplitDeltaOnly = false);

		void PrepareSplitDataForFuture(	const CSRPowerFuture* pFuture, 
			double dFutureDeltaQty,		  // Delta Qty for Swap 
			const CSRDeliveryLoad* pContractLoad, // Load of Power Leg for Swap
			double dContractNotional,		  // Notional of Swap
			double dCashPrice,			  // Cash Leg Price for Swap
			short  nPowerLegWay,
			long   nInstrumentCode,
			double nNbOfInstruments,
			SSSplitData& aMonthlySplitData,
			PowerLoadSplitByCommo& SplitByCommo);


		const CSRDeliveryLoad* GetFirstPeakOrOffpeakLoadForCommo(const CSRCommodityPower *pow);

		void CalculateExerciseProbability(	const instrument::CSROption*		pOption, 
											const CSRPowerFuture*	pFuture, 
											double					dNumberOfSecurities,
											double					dDeltaQty,
											PowerLoadSplitByCommo& SplitByCommo);

		void CalculateMTMforOption(const instrument::CSROption* pPowerOption, 
									const sophis::CSRComputationResults& powerResults,
								   double dAveragePrice,
								   long nInstrumentCode, 
								   double nNbOfInstruments, 
								   PowerLoadSplitByCommo& SplitByCommo);


		void CalculateMTMforSwap(const instrument::CSRSwap* pPowerSwap, 
								const sophis::CSRComputationResults& powerResults,
								 long	  nInstrumentCode,					 
								 double   nNbOfInstruments,
								 PowerLoadSplitByCommo& SplitByCommo // Data structure used to store the results
								 );

		void CalculateMTMforFuture(	const CSRPowerFuture* pFuture, 
									double dAveragePrice,
									long   nInstrumentCode,
									double nNbOfInstruments, 
									PowerLoadSplitByCommo& SplitByCommo);


		bool CalculateMTMforNonStandardProfile(	const CSRCommodityPower*			pPowerCommo,  // 
			PowerLoadSplitByCommo&				SplitByCommo, // Data structure used to store the results
			long								nInstrumentCode,
			double								nNbOfInstruments,
			const market_data::CSRMarketData	&context,	  // 
			const CSRNonStandardDeliveryProfile	&dPeriod,	  // Non Std Power Profile
			const CSRDeliveryLoad				&dLoad,		  // Load ?	
			long								beginDecompositionAt,
			long								endDecompositionAt,
			const instrument::CSRSwap*			pPowerNonStdSwap);


	};
};
SPH_EPILOG
#endif

#endif