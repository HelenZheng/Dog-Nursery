#ifndef _SPHPOWERGASSCENARIOS_H__
#define _SPHPOWERGASSCENARIOS_H__

#if (!defined(WIN32)&&!defined(_WIN64))
#include "SphInc/commodity/SphPowerGasDeliveryPeriod.h"  // For enum eDeliveryPeriodType
#endif

#include "SphInc/commodity/SphDeliveryPeriodImpl.h"
#include "SphInc/commodity/SphCommodity.h"
#include "SphInc/commodity/SphPowerGasLoadSplitScenario.h" 

#include <stdio.h>
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(sstream)
#include __STL_INCLUDE_PATH(iostream)

#define NB_MAX_POWER_PERIODS_IN_HOUR 6

SPH_PROLOG
namespace sophis 
{
	namespace portfolio
	{
		class CSRPortfolio;
		class CSRPosition;
		class CSRExtraction;
	};

	namespace instrument
	{
		class CSRInstrument;
	};

	namespace commodity
	{
		class CSRPowerFolio;
		class CSRPowerPhysicalExposureDialog;

		struct HourlyExposure {
			HourlyExposure(); // constructor - initializes everything to zero
			bool hasPhysicalExposure(); // returns true if fPhyBought != fPhySold
			bool isEmpty(); // returns true if nothing is bought or sold i.e. fFutBought=fFutSold=fPhyBought=fPhySold = 0
			
			double	fFutBought;
			double	fFutSold;
			double	fPhyBought;
			double	fPhySold;

			double	fCashReceiving; // used for Daily Marging calculation, in Portfolio Currency amount
			double	fCashPaying;
			double  fNetAmount;  // Used only to display status string for scheduling
			double  fDailyQuant; // Used only to display status string for scheduling
			bool	fFutForceToDisplay;
			bool	fPhyForceToDisplay;

		};

		struct ExposurePeriod // Period over which exposure is calculated
		{
			long fStartDate;
			long fEndDate;
			long fRefCommo;
		};

		struct DateFilterPopupInfo
		{
			_STL::vector<long> datesLong;
			_STL::vector<char*> datesString;
		};

		struct BlotterSwapInfo
		{
			int lineNo;
			long templateCode;
			char reference[24];
			long underlyingCodeLeg1;
			char deliveryPeriodLeg1[32];
			char deliveryLoadLeg1[32];
			long underlyingCodeLeg2;
			char deliveryPeriodLeg2[32];
			char deliveryLoadLeg2[32];
			short modelIndex;
			double cash_amount;
			double cash_user;
			char name[40];
			double quantity;
			double totalQty;
			char portfolio[60];
			long ticket_template;
			long broker;
			long counterpartyCode;
			long negoDate;
			long valueDate;
			short depositoryIndex;
			double brokerfees;
			double marketfees;
			char info[81];
		};

		struct ExpByInstrument
		{
			ExpByInstrument()
			{
			    fInstrumentCount = 0.;
				fBought = 0.;
				fSold = 0.;
				fHourlyExposure.resize(NB_MAX_POWER_PERIODS_IN_HOUR*25);
				HourlyExposure zero;
				for(unsigned int i=0; i<fHourlyExposure.size(); i++)
					fHourlyExposure[i] = zero;
			};
			double	fBought;
			double	fSold;
			double  fInstrumentCount;
			bool    fIsOption;

			_STL::vector<HourlyExposure>	fHourlyExposure;
		};


		struct ExpByCounterparty {
			ExpByCounterparty(); // constructor - initilizes everything to zero

			// temporary : used during computation only
			double			fBought;
			double			fSold;

			// scenario result : exposure hour by hour (or by day for gas)
			_STL::vector<HourlyExposure>	fHourlyExposure;
			_STL::map<long, ExpByInstrument> fExpByInst;

			const ExpByInstrument * GetInstExposure(long code) const
			{
				_STL::map<long, ExpByInstrument>::const_iterator it = fExpByInst.find(code);
					if (it==fExpByInst.end())
					return NULL;
				else
					return &it->second;
			}
		};

		struct CommodityExposure;
		struct ClassOfInstrument;

		// this exposure used to group the instruments by class of instruments, 
		// ex: Call or Put with differents strike or Swaps with Standard or NonStandard profiles 
		struct ExpByClassOfInstrument
		{
			ExpByClassOfInstrument();

			// temporary : used during computation only
			double			fBought;
			double			fSold;

			// scenario result : exposure hour by hour (or by day for gas)
			_STL::vector<HourlyExposure>	fHourlyExposure;
			_STL::map<long, ExpByCounterparty> fExpByCounterparty;

			const ExpByCounterparty * GetCounterpartyExposure(long code) const
			{
				_STL::map<long, ExpByCounterparty>::const_iterator it = fExpByCounterparty.find(code);
				if (it==fExpByCounterparty.end())
					return NULL;
				else
					return &it->second;
			}
		};


		struct DailyExposure {
			DailyExposure();
			
			_STL::vector<HourlyExposure>& PowGasHourlyExposure();
			const _STL::vector<HourlyExposure>& GetHourlyExposure() const;
			
			HourlyExposure& GasDayExposure();
			const HourlyExposure& GetGasDayExposure() const;
			
			//const ExpByCounterparty& GetCounterpartyExposure(long code) const;
			const ExpByClassOfInstrument* GetClassOfInstrumentExposure(ClassOfInstrument aClassOfInstrument) const;
			const ExpByCounterparty& DailyExposure::GetOptionsList(long code) const;
			
			void CalculateCumul(bool isDaily);
			void CalculateShiftCumul(CommodityExposure &commoExp, long day, short timeDiff, int nbIterCommo, long nCommoCode);
			
			double	GetCumulPhyBought() const;
			double	GetCumulPhySold() const;
			double	GetCumulFutBought() const;
			double	GetCumulFutSold() const;

			double	GetShiftCumulPhyBought() const;
			double	GetShiftCumulPhySold() const;
			double	GetShiftCumulFutBought() const;
			double	GetShiftCumulFutSold() const;

			bool hasPhysicalRisk; // is true when "physical sold" != "physical bought"
			bool isEmptyDay; // is true when nothing is bought or sold

			bool hasShiftPhysicalRisk;
			bool isShiftEmptyDay;

			_STL::map<ClassOfInstrument, ExpByClassOfInstrument> fExpByClassOfInstrument; // <long> is the counterparty
			//_STL::map<long, ExpByCounterparty>     fExpByCounterparty; // <long> is the counterparty
		private:
			_STL::vector<HourlyExposure>	fHourlyExposure; // only if commo is electricity	
			
			double	fDayCumulPhyBought;
			double	fDayCumulPhySold;
			double	fDayCumulFutBought;
			double	fDayCumulFutSold;
			
			double	fDayShiftCumulPhyBought;
			double	fDayShiftCumulPhySold;
			double	fDayShiftCumulFutBought;
			double	fDayShiftCumulFutSold;
		};

		struct CommodityExposure {
			double GetMonthCumulPhyBought(long day) const;
			double GetMonthCumulPhySold(long day) const;
			double GetMonthCumulFutBought(long day) const;
			double GetMonthCumulFutSold(long day) const;
			
			double GetMonthShiftCumulPhyBought(long day) const;
			double GetMonthShiftCumulPhySold(long day) const;
			double GetMonthShiftCumulFutBought(long day) const;
			double GetMonthShiftCumulFutSold(long day) const;
			
			_STL::map<long, DailyExposure>	fDailyExposure; // <long> is the day

			_STL::map<long, SSLocalDouble>	fMonthCumulPhyBought; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthCumulPhySold; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthCumulFutBought; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthCumulFutSold; // <long> is the 1st calendar day of month
			
			_STL::map<long, SSLocalDouble>	fMonthShiftCumulPhyBought; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthShiftCumulPhySold; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthShiftCumulFutBought; // <long> is the 1st calendar day of month
			_STL::map<long, SSLocalDouble>	fMonthShiftCumulFutSold; // <long> is the 1st calendar day of month
		};

		enum eInstrumentClass
		{
			eOtherInstrumentClass = 0,    // any Instrument with type that is not in the list below 
			eSwapStd,
			eSwapNonStd,
			eOptionCall,
			eOptionPut,
			eCallExercised,
			ePutExercised,
			eFuture
		};
		
		struct ClassOfInstrument
		{
			ClassOfInstrument():fInstrumentClass(eOtherInstrumentClass), fStrike(0)
			{
			}

			ClassOfInstrument(eInstrumentClass aInstrumentClass, double aStrike):fInstrumentClass(aInstrumentClass), fStrike(aStrike)
			{
			}
			eInstrumentClass fInstrumentClass;	// like Option or Swap
			double			 fStrike;		
			bool operator < (const ClassOfInstrument &a) const
			{
				if(fInstrumentClass < a.fInstrumentClass)
					return true;
				if((fInstrumentClass == a.fInstrumentClass)&&(fStrike < a.fStrike))
					return true;
				return false;
			}
			_STL::string toString() const
			{
				_STL::stringstream nom;
				nom.precision(2);
				
				switch (fInstrumentClass)
				{
				case eFuture:
					nom << "Future";
					break;
				case eSwapStd:
					nom << "Swap";
					break;
				case eSwapNonStd:
					nom << "NoStd Profile Swap";
					break;
				case eOptionCall:
					nom << "Call " << fStrike;
					break;
				case eOptionPut:
					nom << "Put " << fStrike;
					break;
				case eCallExercised:
					nom << "Exercise C " << fStrike;
					break;
				case ePutExercised:
					nom << "Exercise P " << fStrike;
					break;
				default:
					nom << "Other";
					break;
				}
				return nom.str();
			}
		};
		struct PowerScenarioResult
		{
			const struct CommodityExposure * GetCommodityExposure(long commoCode) const;
			_STL::map<long, CommodityExposure>	fCommodityExposure; // <long> is the commodity code
			_STL::set<long> fListOfCounterparties;
			_STL::set<ClassOfInstrument> fListClassOfInstrument;
		};

		struct PowerScenarioPhysicalResult {
			PowerScenarioPhysicalResult(bool isDaily);

			mutable bool	fHourlyColumns;
			mutable bool	fHideFinancial;
			mutable bool	fHideFinInstrument;
			mutable bool	fTimeShift;
			mutable bool	fBlotter;
			bool			fIsDaily;
			int				fHourGranularity;
			long			fHourGranularityCommo;
			long			fDisplayUnit;
			long			fFolioUnit;
			long			fFolioUnderlying;
			long			fFolioCurrency;
			_STL::set<long> fUnitsList;
			short			fUnitIndex;
			long			fDisplayDate;
			short			fDateIndex;
			mutable short	fIsBlotterDisplayed;

			PowerScenarioResult fResultFolio;
			PowerScenarioResult fResultBlotter;
		};

		class CSRDeliveryPeriod;
		class CSRDeliveryLoad;
		class CSRCommodityPower;
		class CSRHourlyDeliveryPeriod;
		enum eDeliveryPeriodType;


		struct EQ_Item
		{
			double	quantity;
			long	limit_date;
		};

		/* Class to store and retrieve an exposure quantity for a given instrument.
		* The non-trivial use of this class corresponds to computation of exposure of strip options.
		* See above for usage example.
		*
		* do NOT forget to use "ResetReadIndex()" before retrieving quantity per date.
		*/


		class ExposureQuantity {
		public:
			void push_back(double quantity, long limit_date); // The date argument MUST be greater than previous one.

			void ResetReadIndex() const; // This method MUST be used when the next date to retrieve will not be greater or equals to the previous date.
			double GetNextQuantity(long date) const;

			double fRatioUsedToFolioUnit;
		private:
			mutable unsigned int fCurrentReadIndex;
			_STL::vector<EQ_Item> fData;
		};

		class SOPHIS_COMMODITY_GUI CSRPowerGasScenario
		{
		public:

			/*
			*	 GetInstrumentSwap() take the pointers to Swap and Option for this Instrument
			*    If the Instrument is Swap function return the pointer to Swap and pointer to option is NULL 
			*    If the Instrument is SwapOption function return the pointer to option and the pointer to Swap which is underliyng of Option
			*/

		   virtual bool GetInstrumentSwap(long InstrumentCode,
										  const sophis::instrument::CSRSwap** pSwap, 
										  const sophis::instrument::CSROption** pOption);

		   /*
		   *	GetInstrumentQuantityByFlow()
		   *    this function fill the quantityVector with period and quantity of instrument (ex. SwapOption)
		   *    also it return the pointer to CSRDeliveryPeriod,CSRDeliveryLoad,CSRCommodityPower of the instrument
		   */
		   virtual bool GetInstrumentQuantityByFlow(CSRPowerFolio *pLocalFolio,
													int nCurrentPosition,
													int leg,                          // Swap leg 0 or 1
													double InstrumentCount,           // Number of Instruments
													long portfolioUnit,				  // Unit of the underlying commodity of the portfolio
													ExposureQuantity& quantityVector, // Vector with quantities by period 
													const sophis::commodity::CSRDeliveryPeriod **pPeriod,  // return pointer to CSRDeliveryPeriod
													const sophis::commodity::CSRDeliveryLoad   **pLoad,    // return pointer to CSRDeliveryLoad
													const sophis::commodity::CSRCommodityPower **pPower, // return pointer to CSRCommodityPower
													double *unitRatio,
													_STL::set<long> *unitsList
													);
		};
		
		class SOPHIS_COMMODITY_GUI CSRPowerGasPhysicalScenario: public CSRPowerGasScenario
		{
		public:
			CSRPowerGasPhysicalScenario();
			virtual ~CSRPowerGasPhysicalScenario();
			virtual void RunPowerScenario(const sophis::portfolio::CSRPortfolio *inPortfolio, PowerScenarioPhysicalResult &outResult, ExposurePeriod &exp, _STL::vector<BlotterSwapInfo> &inBlotterSwaps, const _STL::set<long> &filteredCounterparties, long userGranularity);

			/* Method for converting VPP or Call strikes into a strike value for Powernext orders
			 * Can be overloaded by setting the static function pointer to a new implementation
			 */
			
			static double (*gGetStrikePowernext)  (const ClassOfInstrument &instClass, long deliveryDate);
			static void   (*gRoundPowernextOrder) (_STL::vector<_STL::vector<double> > &inoutVectOrder);

			virtual void HourlyAndDailyCalculation(PowerScenarioResult &outResult, 
												double instQuantity,  //  in fact it's (InstrumentCount * notional * unitRatio)
												const _STL::map<long, ExpByCounterparty> & expByCounterparty, 
												const long commodityCode, 
												const sophis::commodity::CSRDeliveryPeriod *period, 
												const sophis::commodity::CSRDeliveryLoad *dLoad, 
												long day,            // calculation day
												bool isPhyFlow,      // contract Flow type 
												int nbIter,          // used for Power contract only
												double dailyQuant,   // used for Gas contract only
												bool isDaily,		 // determines whether the commodity is hourly or dialy
												ClassOfInstrument aClassOfInstrument,
												const sophis::commodity::CSRNonStandardDeliveryProfile *schedulingProfile,
												double schedUnitRatio,
												long nInstrumentCode,
												double dNetAmount // In net amount for the position
												);

			void CSRPowerGasPhysicalScenario::FindExposure(PowerScenarioResult &outResult, bool isDaily, long folioUnderlying);

			static int CalcHourExpIndex(const CSRHourlyDeliveryPeriod * hourPeriod, int nbBlocksPerHour);
			static void TimeShift(int nbIterCommo, long *date, int *hblock, short timeDiff, long nCommoCode);
			static short GetTimeDiff(long folioUnderlying, long commoCode);

			static void positionWindow(CSRPowerPhysicalExposureDialog *oldDialog, CSRPowerPhysicalExposureDialog *newDialog);
		};

		struct CommoLoadPair{
			CommoLoadPair(long commoCode, _STL::string loadName){
				fCommoCode	= commoCode;
				fLoadName	= loadName;
			}
			long			fCommoCode;
			_STL::string	fLoadName;
		};

		struct PeriodExposure
		{
			PeriodExposure() {
				fBoughtExact = fBoughtApprox = fSoldApprox = fCurrentBought = fCurrentSold = fAvgBought = fAvgSold = fNettedAvg = 0.;
			};
			double	fBoughtExact; // Best match value
			double	fBoughtApprox; // Remaining long position when subtracting 'best match' (on the period)
			double  fSoldApprox; // Remaining short position when subtracting 'best match' (on the period)
			long    fPeriodIdent;

			double	fCurrentBought; // current long position
			double	fCurrentSold; // current long position
			double	fAvgBought;  // Remaining long position when subtracting netted average
			double	fAvgSold;   // Remaining short position when subtracting netted average
			double	fNettedAvg; // netted average (= average of netted bought and sold on the whole period)
		};
        
		class CompareDeliveryLoads
		{
		public:
			bool operator() (const CommoLoadPair& a, const CommoLoadPair& b) const;
		};

		class CompareDeliveryPeriods 
		{
		public:
			CompareDeliveryPeriods(const CompareDeliveryPeriods & other);
			CompareDeliveryPeriods(long commoCode);
			CompareDeliveryPeriods(); // default constructor should not be used
			bool operator() (long, long) const;
		protected:
			long fCommoCode;
		};

		struct PowerFinancialLoadExposure
		{
			PowerFinancialLoadExposure(); // default constructor should not be used
			PowerFinancialLoadExposure(long commoCode);
			PowerFinancialLoadExposure(long commoCode, const PowerFinancialLoadExposure &other);

		protected:
			CompareDeliveryPeriods	fCmp; // GREG[14/APR/06] : MUST be declared before 'fPeriodExposure' because it must be used in fPeriodExposure constructor (NOTE : else, VisualC++ compiler doesn't give a compile error although it SHOULD !!!)
		public:		
			_STL::map<long, PeriodExposure, CompareDeliveryPeriods> fPeriodExposure; // string : it's a delivery period
		};

		struct PowerFinancialCommoExposure
		{
			/* Get the instance for the deliveryLoad
			 * If not found, create it using the commodity code (required for the operator)
			 */
			PowerFinancialLoadExposure & GetInstance(long commoCode, const _STL::string & deliveryLoad);
			_STL::map<CommoLoadPair, PowerFinancialLoadExposure, CompareDeliveryLoads>::const_iterator FindInstance(const CommoLoadPair &deliveryLoad) const;
			inline _STL::map<CommoLoadPair, PowerFinancialLoadExposure, CompareDeliveryLoads>::const_iterator Begin() const { return fLoadExposure.begin(); };
			inline _STL::map<CommoLoadPair, PowerFinancialLoadExposure, CompareDeliveryLoads>::iterator Begin() { return fLoadExposure.begin(); };
			inline _STL::map<CommoLoadPair, PowerFinancialLoadExposure, CompareDeliveryLoads>::const_iterator End() const { return fLoadExposure.end(); };

		protected:		
			_STL::map<CommoLoadPair, PowerFinancialLoadExposure, CompareDeliveryLoads> fLoadExposure; // string it's a DeliveryLoad name
		};

		struct PowerScenarioFinancialResult
		{
			_STL::map<long, PowerFinancialCommoExposure> fExposure; // long it's a PowerCommoCode
		};

		class SOPHIS_COMMODITY_GUI CSRPowerGasFinancialScenario: public CSRPowerGasScenario
		{
		public:
			CSRPowerGasFinancialScenario();
			virtual ~CSRPowerGasFinancialScenario();
			virtual void RunPowerFinancialScenario(const sophis::portfolio::CSRPortfolio *port, const sophis::commodity::CSRDeliveryLoad *baseloadReference, PowerScenarioFinancialResult &outResult, int startYear, int endYear, eDeliveryPeriodType targetPeriodType, long refCommo);
			virtual void BottomUpAggregation(int startYear, int endYear, eDeliveryPeriodType targetPeriodType, PowerScenarioFinancialResult &inoutResult);
			virtual void InitPowerFinancialScenarioPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long commodityCode, int startYear, int endYear, eDeliveryPeriodType targetPeriodType, PowerFinancialCommoExposure &outResult);
			virtual void InitPowerFinancialScenarioYearlyPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long startDate, long commodityCode, int year, PowerFinancialCommoExposure &outResult);
			virtual void InitPowerFinancialScenarioQuarterlyPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long startDate, long commodityCode, int year, int quarter, PowerFinancialCommoExposure &outResult);
			virtual void InitPowerFinancialScenarioMonthlyPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long startDate, long commodityCode, int year, int month, PowerFinancialCommoExposure &outResult);
			virtual void InitPowerFinancialScenarioWeeklyPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long startDate, long commodityCode, int year, PowerFinancialCommoExposure &outResult);
			virtual void InitPowerFinancialScenarioDailyPeriods(const sophis::commodity::CSRDeliveryLoad *defaultLoad, long startDate, long commodityCode, int year, PowerFinancialCommoExposure &outResult);
			virtual PeriodExposure BuildAggregation(const _STL::vector<const PeriodExposure*> &array, double exactValue);
						
			virtual PeriodExposure PeriodExposureCalculationMethod(const _STL::vector<const PeriodExposure*> &array);
            virtual void FindBestAggregation(const _STL::vector<const PeriodExposure*> &array, PeriodExposure& periodExposure);
			virtual void UseCurrentPositionValue(const _STL::vector<const PeriodExposure*> &array, PeriodExposure &periodExposure);
			virtual void CalculateAverageValue(const _STL::vector<const PeriodExposure*> &array, PeriodExposure &periodExposure);
		};
		

		/*******************************************************************/
		/*******************************************************************/
		class CSRPowerFuture;


#ifndef GCC_XML

		class SOPHIS_COMMODITY_GUI CSRPowerGasLoadSplitScenario: public CSRPowerGasScenario
		{
		public:
			CSRPowerGasLoadSplitScenario(){}
			virtual ~CSRPowerGasLoadSplitScenario(){}
			virtual bool RunPowerLoadSplitScenario( long folio, 
				sophis::portfolio::PSRExtraction extraction,
				DummyAggregationMap&	AggregationMap,
				int startYear, 
				int endYear,
				long nRefCommo,
				bool bDisplayProgressBar);

			virtual void PrepareCache(DummyAggregationMap&	AggregationMap);

			enum eLoadSplitSpecificColumn
			{
				//elsscNumberOfSecurities,
				elsscNUMBER_OF_COLUMNS
			};
		};


		class SOPHIS_COMMODITY_GUI CSRPowerGasScenarioManager
		{
		public:
			static CSRPowerGasPhysicalScenario  & GetPowerGasPhysicalScenario();
			static CSRPowerGasFinancialScenario & GetPowerGasFinancialScenario();
			static CSRPowerGasLoadSplitScenario & GetPowerGasLoadSplitScenario();

			static void SetPhysicalScenario(CSRPowerGasPhysicalScenario* gPowerGasPhysicalScenario);
			static void SetFinancialScenario(CSRPowerGasFinancialScenario* gPowerGasFinancialScenario);
			static void SetLoadSplitScenario(CSRPowerGasLoadSplitScenario* gPowerGasLoadScenario);

		protected:
			static CSRPowerGasPhysicalScenario*		gPowerGasPhysicalScenario;
			static CSRPowerGasFinancialScenario*	gPowerGasFinancialScenario;
			static CSRPowerGasLoadSplitScenario*	gPowerGasLoadSplitScenario;
		};
#endif

	};

};
double SummOfBoughtExact(double summ,const sophis::commodity::PeriodExposure* x);

SPH_EPILOG
#endif
