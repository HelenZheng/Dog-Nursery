#ifndef __SphPowerGasVolatility_h__
#define __SphPowerGasVolatility_h__

#include "SphInc/market_data/SphVolatility.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphTools/SphCommon.h"
#include "SphInc/commodity/SphPowerGasDeliveryPeriod.h"

SPH_PROLOG
namespace sophis	{
	namespace market_data	{

		//---------------------------------------------------------------
		// SSPowerGasVolatilityDataItem
		//---------------------------------------------------------------

		struct SSPowerGasVolatilityDailyTemplate;
		struct SSPowerGasVolatilityHourlyTemplate;

		struct SOPHIS_COMMODITY SSPowerGasVolatilityMonthlyDataItem
		{
		public:
			SSPowerGasVolatilityMonthlyDataItem();
			_STL::string fDailyTemplateName;
			_STL::string fHourlyWDTemplateName;
			_STL::string fHourlySTTemplateName;
			_STL::string fHourlyBHTemplateName;

			// pointer to the structures corresponding to daily&hourly template. These are used for performance improvement when computing volatilities.
			const SSPowerGasVolatilityDailyTemplate  * fDailyTemplate;
			const SSPowerGasVolatilityHourlyTemplate * fHourlyWDTemplate;			
            const SSPowerGasVolatilityHourlyTemplate * fHourlySTTemplate;			
            const SSPowerGasVolatilityHourlyTemplate * fHourlyBHTemplate;			
		};
		//---------------------------------------------------------------
		// SSPowerGasVolatilityDailyTemplate
		//---------------------------------------------------------------
		struct SOPHIS_COMMODITY SSPowerGasVolatilityDailyTemplate
		{
		public:
			SSPowerGasVolatilityDailyTemplate() : fVolWD_future_code(0),fVolST_future_code(0),fVolBH_future_code(0){}
			long	fVolWD_future_code; // The Future with daily WD vol, the Price will be ignored
			long	fVolST_future_code; // The Future with daily ST vol, the Price will be ignored
			long	fVolBH_future_code; // The Future with daily BH vol, the Price will be ignored
		};

		//---------------------------------------------------------------
		// SSPowerGasVolatilityHourlyTemplateItem
		//---------------------------------------------------------------
		struct SOPHIS_COMMODITY SSPowerGasVolatilityHourlyTemplateItem
		{
		public:
			SSPowerGasVolatilityHourlyTemplateItem() : fFutureSico(0){}
			long fFutureSico;
		};

		//---------------------------------------------------------------
		// SSPowerGasVolatilityHourlyTemplate
		//---------------------------------------------------------------
		struct SOPHIS_COMMODITY SSPowerGasVolatilityHourlyTemplate
		{
		public:		
			int			    fGranularity;	
			mutable long	fIdent;
			static const int NbHours = 25 ;
			void Clear()
			{
				fItems.clear();
				fItems.resize(NbHours * 6);
			};
			SSPowerGasVolatilityHourlyTemplate() : fGranularity(1),fIdent(0)
			{
				Clear();
			};

			_STL::vector<SSPowerGasVolatilityHourlyTemplateItem> fItems;
		};
		//---------------------------------------------------------------
		// SSPowerGasVolatilityData
		//---------------------------------------------------------------
		struct SOPHIS_COMMODITY SSPowerGasVolatilityData
		{
		public:
			SSPowerGasVolatilityData() : fModifiedMonthlyList(false),fModifiedDailyTemplateList(false),fModifiedHourlyTemplateList(false),sico(0), fHistoCode(0){}
			
			// long is a Future code representing a Monthly forward contract
			_STL::map <long, SSPowerGasVolatilityMonthlyDataItem>			fMonthlyList;
			// the string is the daily template name
			_STL::map <_STL::string, SSPowerGasVolatilityDailyTemplate>		fDailyTemplateList;
			// the string is the hourly templace name
			_STL::map <_STL::string, SSPowerGasVolatilityHourlyTemplate>	fHourlyTemplateList;

			bool fModifiedMonthlyList;
			bool fModifiedDailyTemplateList;
			bool fModifiedHourlyTemplateList;
			long sico;
			static const int	MaxNamesLength = 40;
			static const long	MaxYear = 2050;
			static const long	MinYear = 1950;
			static const long	MaxMonth = 12;
			static const long	MinMonth = 1;
			static const long	MaxHour = 25;
			static const long	MinHour = 1;
			static const int    MaxVol = 500;
			static const int	MinVol = 0;
			static const int    Precision = 2;
			static const double MinStrike;
			static const double MaxStrike;

			void LinkItems();
			const SSPowerGasVolatilityData& operator=(const SSPowerGasVolatilityData& ref);
			SSPowerGasVolatilityData(const SSPowerGasVolatilityData& ref);
			_STL::string f_sHistoTitle;
			long fHistoCode;
		protected:
			void CopyTo(const SSPowerGasVolatilityData& from,SSPowerGasVolatilityData& to);

		};

		//---------------------------------------------------------------
		// CSRPowerGasVolatilityBreakdown
		//---------------------------------------------------------------

		class SOPHIS_COMMODITY CSRPowerGasVolatilityCalculation
		{
		public:
			CSRPowerGasVolatilityCalculation(const SSPowerGasVolatilityData& data);

			void GetDailyRiskSources(const _STL::set<long> monthlyFutures, _STL::set<long> & dailyFutures);
			void GetHourlyRiskSources(const _STL::set<long> monthlyFutures, _STL::set<long> & hourlyFutures);
			
			virtual bool ComputeVolatility(const commodity::CSRDeliveryPeriod::DayAndHour& dayAndHour, const CSRMarketData* context, const char* deliveryLoad, double dtStart, double dtEnd, double strike, NSREnums::eVolatilityType volatilityType, Boolean put);

			double GetMonthlyVol() const
			{ return fMonthlyVol; }

			double GetDailyVol() const
			{ return fDailyVol; }

			double GetHourlyVol() const
			{ return fHourlyVol; }

			double GetVol() const
			{ return fVol; }

			long GetMonthlyVolSource() const
			{ return fMonthlyVolSource; }

			long GetDailyVolSource() const
			{ return fDailyVolSource; }

			long GetHourlyVolSource() const
			{ return fHourlyVolSource; }

		protected:
			double fMonthlyVol;
			double fDailyVol;
			double fHourlyVol;
			double fVol;

			long	fMonthlyVolSource;
			long	fDailyVolSource;
			long	fHourlyVolSource;

			virtual double VolFormula(double dblVolMonth,double dblVolDay,double dblVolHour) const;

			const SSPowerGasVolatilityData *fData;
		};

		//---------------------------------------------------------------
		// CSRPowerGasVolatility 
		//---------------------------------------------------------------
		class SOPHIS_COMMODITY CSRPowerGasVolatility : public virtual CSRVolatility
		{
		public:

			DECLARATION_VOLATILITY(CSRPowerGasVolatility)

			CSRPowerGasVolatility(const CSRVolatility& );
			CSRPowerGasVolatility(const CSRPowerGasVolatility& );

		protected:
			void Initialize(const CSRVolatility& );
			void Initialize(const CSRPowerGasVolatility& );

		public:
			static void  DeclarationPowerGasVolatilityAction();

			//load-save to DB
			virtual bool LoadInstance(long code, long histoCode,const SSPowerGasVolatilityData& inData);
			virtual bool SaveInstance(NSREnums::eParameterModificationType typeModif) const;

			//get-set inner data structure
			void							SetPowerGasVolatilityData(SSPowerGasVolatilityData& inData);
			const SSPowerGasVolatilityData& GetPowerGasVolatilityData() const
				{ return fData; }

			void		SetRealCodes(long code, long codeHisto);

			//empty profiles listes and monthly config
			void		ClearVolatilityData();

			//virtual bool ConstructAgain() const; //default returns false

			virtual void push(sophis::tools::CSRArchive &archive) const;

			static const char* GetVolatilityClassName()
				{ return "Power & Gas volatility"; }

			virtual bool DisplayVolatilityGraphs() const
				{ return false; }

		protected:

			SSPowerGasVolatilityData fData;//hold all necessary data
			
			virtual CSRVolatility*	Clone() const;
			void					Construct(const CSRPowerGasVolatility& src);
			
		};
	}
}
//archive operators
sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::market_data::SSPowerGasVolatilityData& v);
const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::market_data::SSPowerGasVolatilityData &v);

SPH_EPILOG
#endif

