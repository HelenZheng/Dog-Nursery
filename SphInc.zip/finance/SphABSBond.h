/*
File:		SphABSBond.h

Contains:	Class for the handling of an ABS bond.

Copyright:	2007 Sophis.

*/

/*! \file SphABSBond.h
\brief Class for the handling of an ABS bond.
*/

#pragma once

#ifndef _SphABSBond_H_
#define _SphABSBond_H_

#include "SphInc/SphMacros.h"

/**
	Application includes
*/
#include "SphInc/finance/SphCDSPricer.h"
#include "SphInc/finance/SphMetaModel.h"
#include "SphInc/instrument/SphAmortizing.h"
#include "SphInc/instrument/SphBond.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/instrument/SphInstrumentEnums.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/gui/SphNewDialog.h"

#include "SphInc/finance/SphABSSpecific.h"
#include "SphInc/finance/SphDefaultMetaModelBond.h"

/**
	STL includes
*/
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

/** Declaration macro for prepayment types.
@version 5.3
*/
#define DECLARATION_PREPAYMENT_TYPE(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRPrepayment)

/** Instantiation macro for prepayment types.
@version 5.3
*/
#define INITIALISE_PREPAYMENT_TYPE(className, name)	INITIALISE_PROTOTYPE(className, name)

/** Declaration macro for ABS parameter names.
@version 7.1.3
*/
#define DECLARATION_ABS_PARAMETER_NAME(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRABSParameterName)

/** Instantiation macro for ABS parameter names.
@version 5.3
*/
#define INITIALISE_ABS_PARAMETER_NAME(className, name)	INITIALISE_PROTOTYPE(className, name)


class PoolFactorComputationFunction;	// INTERNAL

SPH_PROLOG
namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace market_data
	{
		class CSRMarketData;
		class CSRCreditRisk;
	}

	namespace static_data
	{
		class CSRDayCountBasis;
		struct SSDayCountCalculation;
		class CSRYieldCalculation;
	}

	namespace finance
	{
		class CSRABSBond;

		class CSRABSTranches;

		class CSRABSCashFlows;

		class CSRABSSpecific;

		class CSRABSParameters;

		struct SSABSParameter;

		enum ePrepaymentValidity
		{
			_epvABSBond,
			_epvTermLoan
		};

		enum eABSPricingMethod
		{
			epmXXX = 0,
			epmCPR, // = 1
			epmWAMonly,
			epmWAMgiveCPR,
			epmWAMgreeksCPR
		};


		/** Interface for prepayment models.

		@note that this class is abstract.

		@version 5.3
		*/
		class SOPHIS_FIT CSRPrepayment : public sophis::gui::ISRNewDialog
		{
		public:
			/** Constructor.
			@version 5.3
			*/
			CSRPrepayment();

			/** Destructor.
			@version 5.3
			*/
			virtual ~CSRPrepayment();
			
			/** Return whether the prepayment should be available for an type of instrument.
			By default, it returns true.

			@param validity
			an enumeration value describing the instrument.

			@return
			true is the prepayment is available for ABS Bonds, false otherwise.

			@see {@link CSRABSBond}

			@version 6.0
			*/
			virtual bool	IsAvailable(ePrepaymentValidity validity) const;

			/** Return whether the prepayment should be available for an type of instrument.
			By default, it returns true.

			@param validity
			an enumeration value describing the instrument.

			@param provider
			an enumeration value describing the provider of the cash flows.

			@return
			true is the prepayment is available for ABS Bonds for the specified provider, false otherwise.

			@see {@link CSRABSBond}

			@version 7.1.3
			*/
			virtual bool	IsAvailable(ePrepaymentValidity validity, sophis::finance::eCashFlowGeneration provider) const;

			/** Return whether the prepayment is a toolkit one or not.
			By default, it returns false.

			@return
			true if the prepayment is coming from a toolkit for ABS Bonds, false otherwise. It returns false by default.

			@see {@link CSRABSBond}

			@version 7.1.3
			*/
			virtual bool	IsAToolkitPrepayment() const;

			/** Return the name of the prepayment model.
			
			@return
			the name of the prepayment type model.

			@version 5.3
			*/

			_STL::string	GetPrepaymentType() const;

			/** Called during the initialisation of the ABS bond.
			Required actions are done in CSRPrepayment::InitialiseFromABS. Therefore, do not forget
			to call InitialiseFromABS on the base class when overloaded.
			
			@param abs
			the ABS bond being initialised.
			
			@see {@link sophis::finance::CSRABSBond}.

			@version 5.3
			*/
			virtual void	InitialiseFromABS( const CSRABSBond & abs );

			/** Called before pricing, allows to calibrate a prepayment model

			@param context
			the context used for calibration

			@version 5.3
			*/
			virtual void	CalibrateCPRCurve( const market_data::CSRMarketData& context);

			/** Computes the prepayment factor to apply for a given period.

			@param context
			the market data.

			@param prepaymentRate
			the parameter of the model (such as cpr).

			@param startDate
			the start date of the period considered.

			@param endDate
			the end of the period considered.

			@param dayCountBasis
			the day count basis used for computation.

			@param dccData
			the extra data for computation of day count.

			@param poolFactor
			the pool factor at startDate.

			@param redemption
			the redemption without prepayment.

			@param issueDate
			the issue date of the ABS

			@return
			the prepayment, given as the fraction of principal outstanding at startDate 
			which will prepay at endDate.

			@version 5.3
			*/
			virtual double GetPrepayment(	const market_data::CSRMarketData &			context,
											double										prepaymentRate,
											long 										startDate,
											long 										endDate,
											const static_data::CSRDayCountBasis *		dayCountBasis,
											const static_data::SSDayCountCalculation &	dccData,
											double										poolFactor,
											double										redemption,
											long										issueDate	,
											sophis::instrument::SSRedemption            *CashflowRedemption = 0 ,
											CSRABSCashFlows *absCashFlow = 0,
											std::string scenarioName = "") const = 0;

			/* Returns the maximum value of the parameter prepaymentRate in GetPrepayment.

			@return
			the maximum value.

			@see {@link GetPrepayment}.

			@version 5.3
			*/
			virtual double	GetMaxValue() const = 0;

			/**	Return true is the prepayment can be customized through the dialog returned by {@link new_Dialog}.
			@return true if the prepayment is customizable, false otherwise.
			By default, it returns false.
			@version 5.3.3
			*/
			virtual bool	IsCustomizable() const;

			/** Duplicate the prepayment.
			
			@return
			a new pointer on an identical copy of the prepayment, which must be deleted.

			@note that this method is pure virtual.

			@version 5.3
			*/
			virtual CSRPrepayment *	Clone() const = 0;


			/** Get specific element of the prepayment, when you add a dialog.
			@param NRE_element is the element ID in your CSRFitDialog.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_Element is not found.
			@version 5.3.3
			*/
			bool LoadSpecificElement(int NRE_Element,void *address) const;

			/** Get specific element in a list of the prepayment, when you add a dialog.
			@param NRE_List is the element id of your CSREditList in your CSRFitDialog.
			@param lineNumber from 0 to GetSpecificLineCount()-1 is the line number in your CSREditList.
			@param NRC_Colomn is the column number.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_List is not found.
			@version 5.3.3
			*/
			bool LoadSpecificElement(int NRE_List, int lineNumber,int NRC_Colomn,void *address) const;

			/** Get the number of lines in a list of the prepayment, for when you add a dialog.
			@param NRE_List is the element ID of your CSREditList in your CSRFitDialog.
			@return the line count. Returns 0 in case of errors.
			@version 5.3.3
			*/
			int	GetSpecificLineCount(int NRE_Liste) const;

			/** Set specific element of the prepayment, when you add a dialog.
			@param NRE_element is the element ID in your CSRFitDialog.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_Element is not found.
			@version 5.3.3
			*/
			bool	SaveSpecificElement(	int 	ERId_Element,
											void	*address) const;

			/** Set specific element in a list of the prepayment, when you add a dialog.
			@param NRE_List is the element id of your CSREditList in your CSRFitDialog.
			@param lineNumber from 0 to GetSpecificLineCount()-1 is the line number in your CSREditList.
			@param NRC_Colomn is the column number.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_List is not found.
			@version 5.3.3
			*/
			bool	SaveSpecificElement(	int 	ERId_List,
											int 	lineNumber,
											int 	CNb_Column,
											void	*address) const;

			/** Set the number of lines in a list of the prepayment, for when you add a dialog.
			@param NRE_List is the element ID of your CSREditList in your CSRFitDialog.
			@param newLineCount is the new number of lines.
			@return false in case of error : for instance if NRE_List is not found.
			@version 5.3.3
			*/
			bool	SaveSpecificLineCount(	int   ERId_List, int newLineCount);


			typedef sophis::tools::CSRPrototype< CSRPrepayment, const char *, sophis::tools::less_char_star > prototype;

			/** Return the prototype containing all the instances of the registered prepayments.

			@return
			the prototype containing all the instances of the registered prepayments.

			@version 5.3
			*/
			static prototype &	GetPrototype();

		private:
			infos_user *	fInfosUser;
		};

		/** Meta model containing the pricing of the ABS bonds.

		@see {@link sophis::finance::CSRDefaultMetaModelBond}

		@version 5.3
		*/
		class SOPHIS_FIT CSRABSBondMM : public virtual CSRDefaultMetaModelBond
		{
		public:
			DECLARATION_BOND_META_MODEL( CSRABSBondMM );

			virtual sophis::gui::CSRFitDialog *	new_Dialog() const;

			/**  Gets the dirty price using zero coupon rates.

			@param bond
			the bond whose dirty price has to be computed.

			@param context
			the market data.

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param ownershipDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param adjustedDates
			ytm computed on adjusted date

			@param	valueDates
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type

			@return
			the dirty price

			@version 5.3
			*/
			virtual double	GetDirtyPriceByZeroCoupon(	const instrument::CSRBond &					bond,
														const market_data::CSRMarketData &			context,
														long 										transactionDate, 
														long 										settlementDate,
														long										ownershipDate,
														short										adjustedDates,
														short										valueDates			= kUseDefaultValue,
														const static_data::CSRDayCountBasis *		dayCountBasis		= 0, 
														const static_data::CSRYieldCalculation *	yieldCalculation	= 0	) const;

			/** Generates the credit risk data structure.

			@param context
			the market data which can modify the credit risk structure.

			@return
			the credit risk data structure.
			Note: the object returned must be deleted (de-allocated) from memory after use.

			@version 5.3
			*/
			virtual market_data::CSRCreditRisk *	new_CreditRisk(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData & context ) const OVERRIDE;

			virtual double	ComputeNonFlatCurvePrice(	const instrument::CSRInstrument					&instr,
														long											transactionDate,
														long											settlementDate,		
														long											ownershipDate,
														const market_data::CSRMarketData				&param,
														double											*derivee,
														const static_data::CSRDayCountBasis				*base,
														short											adjustedDates,
														short											valueDates,
														const static_data::CSRDayCountBasis				*dayCountBasis,
														const static_data::CSRYieldCalculation			*yieldCalculation,
														_STL::vector<instrument::SSRedemption>			*redemptionArray,
														_STL::vector<instrument::SSBondExplication>		*explicationArray,
														bool											withSpreadMgt,
														bool											throwException) const OVERRIDE;

		
			virtual double ComputeFlatCurvePrice(	const instrument::CSRInstrument		&instr,
													long								transactionDate, 
													long								settlementDate, 
													long								ownershipDate, 
													const market_data::CSRMarketData	&flatCurveParam,
													int									ZCType, 
													bool								weighting,
													const market_data::CSRMarketData	&context,
													bool								adjustedDates,
													bool								valueDates) const OVERRIDE;

			virtual bool	IsAbleToPrice( const instrument::CSRInstrument & toCheck, _STL::string *message ) const OVERRIDE;

			/**
			 *	Returns the pricing type defined in this model
			*/
			sophis::instrument::ePricingType	GetModelPricingType() const;

			/**
			 *	Returns the ABS pricing method defined in this model
			*/
			eABSPricingMethod	GetModelABSPricingMethod() const;

			/**
			 *	Returns the cash flow scenario defined in this model
			*/
			_STL::string	GetModelCashFlowScenario() const;


			static _STL::string		MetaModelName;

		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		/** Configuration dialog for the ABS meta model
		@version 7.1.3
		*/

		class SOPHIS_FIT MMABSDialog : public sophis::gui::CSRFitDialog
		{
		public:
			enum eMMABSElement
			{
				idMMOK	= 1,
				idMMCancel ,
				idMMPricingType ,
				idMMPricingMethod ,
				idMMCashFlowScenario,
				idMMLast 
			};

			MMABSDialog();
		};

		/** Class used to handle ABS bond.
		@version 5.3
		*/
		class SOPHIS_FIT CSRABSBond : public virtual instrument::BondMetaModel
		{
		public:
			DECLARATION_BOND( CSRABSBond );

			/** Destructor.
			@version 5.3
			*/
			virtual ~CSRABSBond();

			/** Duplicate the instrument.

			@return
			a new pointer on an identical copy of the instrument, which must be deleted.

			@version 5.3
			*/
			virtual CSRInstrument *	Clone() const;

			/** The string used to registered the class
			@version 5.3
			*/
			static const char* MODEL_NAME;
			
			/** When no meta model is found then this default meta model is used:
			By default, it returns a pointer on fMMABSBond.
			@version 71
			 */

			virtual const finance::CSRMetaModel * GetDefaultMetaModel() const;

			/** Tells if the bond use a pricing model available for the yield curve calibration.
			This is useful for bond using a mark to market model: by definition such a model will price
			the bond as its market value whatever the yield curve. So such a bond pricing model can not be used
			in yield curve calibration. Instead we can use standard bond pricing model. If the bond is used
			as a yield curve market plot it will be priced at its market price.

			By default this method return false. you must overload it if your pricing model is not
			available in yield curve calibration.

			@return
			True, if the pricing model is available for the yield curve calibration. 
			Returns False otherwise, in which case an error message is reported ind the 
			corresponding point is discarded if we try to use it in a Bond yield curve.

			@version 5.3
			*/
			virtual bool	IsAvailableForYieldCurveBootstrap() const;

			/** Get the type of volatility dependence.
			In greeks calculation, before calling GetTheoreticalValue, those methods need to switch
			the context so that retrieving the P&L volatility returns the risk volatility.
			The risk volatility depends on {@link CSRPreference}; this applies to listed options
			and OTC. This information is given by the method.

			@return
			the volatility dependency type. See {@link sophis::instrument::eVolatilityDependencyType}.

			@version 5.3
			*/
			virtual instrument::eVolatilityDependencyType	GetVolatilityDependencyType() const;

			/** Indicates whether it is a Floating Notional or not.
			@return
			True

			@see {@link sophis::instrument::ePartialRedemptionType}.
			@see {@link sophis::instrument::CSRBond::GetPartialRedemptionType}.

			@version 5.3
			*/
			virtual bool IsFloatingNotional() const;

			/** Indicates whether it is a sinkable bond. 
			A Sinkable bond is defined in sophis by a bond quoted in percent without floating notional and in which there 
			is at least one early redemption without any number of redeemed security. In this case the Bond is quoted 
			in percentage of the current notional.
			@return
			False
			@link 
			IsFloatingNotional()
			*/
			virtual bool IsSinkableBond() const;


			/** Indicates whether the bond can have range accrual
			@return
			false
			*/
			virtual	bool CanHaveRangeAccrual() const;

			/* Returns the notional factor (pool factor) at date accruedCouponDate

			@param accruedCouponDate
			the accrued coupon date.

			@param askQuotationType
			the quotation type.

			@return
			the pool factor at date accruedCouponDate, if askQuotationType is different 
			from aqInPrice and aqInPriceWithoutAccrued

			@version 5.3
			*/
			virtual double  GetFloatingNotionalFactor(	long 							pariPassuDate, 
														long 							accruedCouponDate, 
														instrument::eAskQuotationType	askQuotationType = instrument::aqNotDefined ) const;


			/** Gets the redeemed notional.
			
			@param date
			the date when the redeemed notional has to be computed.
			
			@return
			the redeemed notional.
			
			@version 5.3
			*/
			virtual double	GetRedeemedNotional( const long date ) const;

			/** Returns the pool factor as of today

			@param settlementDate
			date at which the pool factor is required

			@param date
			pool factor date, output

			@return
			the pool factor
			*/
			virtual const double GetValidPoolFactorAt(long settlementDate, long* date = 0) const;

			/** INTERNAL.
			*/
			virtual bool	HasTransparencyBreakDown(sophis::portfolio::PSRExtraction extraction) const;

			/** INTERNAL.
			*/
			virtual void	GetTransparencyBreakDown(	_STL::vector<SSTransparencyBreakDown> &components,
														sophis::portfolio::PSRExtraction extraction,
														const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
														const sophis::portfolio::eLookthroughType fSplitByComponents,
														double* evalInstrument,
														double* evalLookthroughDeals) const;

			
			virtual  sophis::instrument::ePricingType	GetPricingMethod()	const;

			virtual double ComputeMtMSpread(double price = NOTDEFINED, bool isDirtyPrice = false, bool isForceIRSpread = false, const CSRMetaModel * modelPtr = 0) const;

			/* Get the ABS Pricing Method
			@return the Pricing Method
			@param forPricing: if false, returns the ABS pricing method of the ABS.
			If true and if the pricing method is "WAM->CPR" or "WAM greeks CPR ", it returns
			"WAM Only" when no implied CPR has been found. (This prevents from pricing with zero CPR 
			in this case.)
			@see SetABSPricingMethod
			@since 5.3
			*/
			eABSPricingMethod	GetABSPricingMethod(bool forPricing = false) const;

			/* Set the ABS Pricing Method
			
			@param method
			If method is CPR, all prices and sensitivities are computed using a Constant Prepayement Rate
			If method is WAMonly, all remaining notional is supposed supposed to be redeemed at the 
			Weighted Average Maturity
			If method is WAMgiveCPR, a CPR corresponding to the given WAM is computed and used for computations .

			@version 5.3
			*/
			void				SetABSPricingMethod( eABSPricingMethod method );

			/** Get the prepayment type name.

			@return
			the prepayment type name.

			@version 5.3
			*/
			_STL::string GetPrepaymentType() const;

			/** Set the prepayment type name.

			@param prepaymentType
			the prepayment type name to set.

			@version 5.3
			*/
			void	SetPrepaymentType( const _STL::string & prepaymentType );

			/**	Return true if the prepayment is customizable.

			@see {@link CSRPrepayment::IsCustomizable}

			@version 5.3
			*/
			bool					IsPrepaymentCurveCustomisable() const;

			/**	Get the prepayment model.

			@return
			the prepayment model.

			@version 5.3
			*/
			CSRPrepayment *	GetPrepaymentModel() const;

			/** Get the Weighted Average Maturity, expressed in number of days since 01/01/1904.
			Note that the historized WAM is used when not in the pricing window.

			@return the WAM
			If the ABS Pricing Method is WAMonly or WAMgiveCPR, it is the given WAM;
			If the ABS Pricing Method is CPR, this is the WAM computed from the CPR.

			@see {@link ComputeWAM}.
			
			@version 5.3
			*/
			long	GetWAM() const;

			/** Returns the WAM value from the historic table.
			@return the WAM date.
			@version 5.3.3
			*/
			long	GetHistorizedWAM() const;

			/** Set the WAM, expressed in number of days since 01/01/1904.

			@param wam
			the WAM to set.

			@version 5.3 
			*/
			void	SetWAM( long wam );

			/** Get the Constant Prepayment Rate, expressed in annual compounding and in unit fraction.
			Note that the historic CPR is used when not in the pricing window.

			@return
			the CPR
			If The ABS Pricing Method is CPR, this is the given CPR;
			In WAM and WAMgiveCPR methods, it is the CPR which would give the desired WAM.
			
			@see {@link ComputeCPR}.
			@version 5.3
			*/
			double	GetCPR() const;

			/** Returns the CPR value from the historic table.
			@return the CPR.
			@version 5.3.3
			*/
			double	GetHistorizedCPR() const;

			/** Set the Constant Prepayment Rate, expressed in annual compounding and in unit fraction.
			
			@param cpr
			the CPR to set.

			@version 5.3
			*/
			void	SetCPR( double cpr );

			/** Returns the Marked-to-market Accrued Interest value from the historic table if found.
			@param MtMCoupon
			the MtMCoupon filled with data of the historical table.
			@return true if the MtMCoupon was found at same date than Last, false otherwise.
			@version 7.1.3
			*/
			bool	GetHistorizedMtMAccruedInterest(double& MtMCoupon) const;
			
			/**
			*	@return the MtM Accrued Interest given in the historic of the ABS at the specified date, NOTDEFINED otherwise
			*/
			
			void ReadHistorizedMtMCoupon(long date, double& MtMCoupon) const;

			/** Get the tranches.
			@return the tranches			
			@version 7.1.3
			*/
			CSRABSTranches *	GetABSTranches() const;

			/** Set the tranches.
			@param tranches
			the tranches to set.
			@version 7.1.3 
			*/
			void	SetABSTranches( CSRABSTranches * tranches);

			/** Get the accumulatd loss (in amount).
			@return the loss			
			@version 7.1.3
			*/
			double	GetAccumulatedLoss() const;

			/** Set the accumulated loss (in amount).
			@param loss
			the accumulated loss to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedLoss( double loss);

			/** Get the accumulatd writedown.
			@return the writedown			
			@version 7.1.3
			*/
			double	GetAccumulatedWritedown() const;

			/** Set the accumulated writedown.
			@param writedown
			the accumulated writedown to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedWritedown( double writedown);

			/** Get the accumulatd interestShortfall.
			@return the interestShortfall			
			@version 7.1.3
			*/
			double	GetAccumulatedInterestShortfall() const;

			/** Set the accumulated interestShortfall.
			@param interestShortfall
			the accumulated interestShortfall to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedInterestShortfall( double interestShortfall);

			/** Get the cash flow generation
			@return the cash flow generation priovider			
			@version 7.1.3
			*/
			short	GetCashFlowGeneration() const;

			/** Set the cash flow generation provider.
			@param cashFlowGeneration
			the cash flow generation provider to set.
			@version 7.1.3 
			*/
			void	SetCashFlowGeneration( short cashFlowGeneration);

			/** Get the last update date
			@return the last update date of chash flows			
			@version 7.1.3
			*/
			long	GetLastUpdateDate() const;

			/** Set the last update date.
			@param date
			the last update date of the cash flows to set.
			@version 7.1.3 
			*/
			void	SetLastUpdateDate( long date);

			/** Get the credit default type
			@return the credit default	
			@version 7.1.3
			*/
			short	GetCreditDefaultType() const;

			/** Set the credit default type.
			@param creditDefault
			the credit default to set.
			@version 7.1.3 
			*/
			void	SetCreditDefaultType( short creditDefault);
			
			/** Get the severity method
			@return the severity method		
			@version 7.1.3
			*/
			short	GetSeverityMethod() const;

			/** Set the severity method.
			@param severityMethod
			the severity method to set.
			@version 7.1.3 
			*/
			void	SetSeverityMethod( short severityMethod);

			/** Get the recovery type
			@return the recovery type			
			@version 7.1.3
			*/
			short	GetRecoveryType() const;

			/** Set therecovery type.
			@param recoveryType
			the recovery type to set.
			@version 7.1.3 
			*/
			void	SetRecoveryType( short recoveryType);

			/** Get the delinquency type
			@return the delinquency type		
			@version 7.1.3
			*/
			short	GetDelinquencyType() const;

			/** Set the delinquency type.
			@param delinquencyType
			the delinquency type to set.
			@version 7.1.3 
			*/
			void	SetDelinquencyType( short delinquencyType);
			
			/** Get the ABS specific data.
			@return the specific data		
			@version 7.1.3
			*/
			CSRABSSpecific *	GetABSSpecific() const;

			/** Set the ABS specific data.
			@param specific
			the specific data to set.
			@version 7.1.3 
			*/
			void	SetABSSpecific( CSRABSSpecific * specific);

			/** Get the ABS cash flows.
			@return the cash flows			
			@version 7.1.3
			*/
			CSRABSCashFlows *	GetABSCashFlows() const;

			/** Set the ABS cash flows.
			@param cashFlows
			the cash fows to set.
			@version 7.1.3 
			*/
			void	SetABSCashFlows( CSRABSCashFlows * cashFlows);

			/** Get the ABS parameters.
			@return the parameters			
			@version 7.1.3
			*/
			CSRABSParameters *	GetABSParameters() const;

			/** Set the ABS parameters.
			@param params
			the parameters to set.
			@version 7.1.3 
			*/
			void	SetABSParameters( CSRABSParameters * params);

			/** Get the ABS parameters according to the specified scenario
			@param scenarioName is the input scenario
			@return the parameters			
			@version 7.1.3
			*/
			void GetABSParametersAccordingToScenario(_STL::vector< sophis::finance::SSABSParameter>& params, _STL::string scenarioName) const;

			/** INTERNAL.
			@version 5.3
			*/
			bool	IsExchanged() const;

			/** INTERNAL.
			@version 5.3
			*/
			void	SetExchanged( bool isExchanged ) const;

			/** Computes the derivative of WAM with respect to CPR.

			@param context
			the market data.

			@return
			the derivative

			@version 5.3
			*/
			double  ComputeWAMCPRDerivative( const market_data::CSRMarketData & context ) const;

			/** Archive all the results after a recompute all.
			This function is called at the server side after the calculation completion by the
			Calculation Server.
			The default implementation consists in the storage of every GetXXX_API methods returned value.

			@param archive
			an archive where results are saved.

			@version 5.3
			*/
			//virtual void	GetCalculationData( sophis::tools::CSRArchive & archive ) const;


			/** De-archive all the results after a recompute all.
			This function is called at the client side after receiving the calculation by the
			Calculation Server.
			The default implementation consists in calling every SetXXX_API methods with values stored
			in the given archive.

			@param archive
			an archive from which results are loaded.

			@version 5.3
			*/
			//virtual void	SetCalculationData( const sophis::tools::CSRArchive & archive );

			/** Create a market data for simulation. It must be deleted.

			@param context the base context

			@version 5.3.4
			*/
			virtual market_data::CSRMarketData*  new_SimulationMarketData(const market_data::CSRMarketData& context) const;

			
			/** Gets the Dirty Price, Delta and Gamma using a yield rate, and by specifying the calculation mode and day count basis.

			@param price
			output parameter, is loaded with the dirty price.

			@param sensibility
			output parameter, is loaded with the Delta.

			@param convexity
			output parameter, is loaded with the Gamma.

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param yieldToMaturity
			the yield rate.

			@param adjustedDatesCalc
			acts like a boolean value to indicate whether the YTM calculation is on adjusted dates (adjustedDates>0) or not (adjustedDates=0).
			If value passed is -1, then the day count basis taken is from the bond's Market Data. See 

			@param valueDatesCalc
			acts like a boolean value to indicate whether the YTM calculation is on settlement date (valueDates>0) or not (valueDates=0).

			@param dayCountMasis
			the day count basis method for YTM, used for calculating the rate. See {@link static_data::CSRDayCountBasis}.
			If the object passed in null, then the day count basis method taken is that of the Day Count Basis that is specified in the bond's Market Data, which is
			obtained by {@link CSRBond::GetMarketYTMDayCountBasisType}.

			@paramCOM dayCountMasis
			the day count basis method for YTM, used for calculating the rate. See {@link ISphCDayCountBasis}.
			If the object passed in null, then the day count basis method taken is that of the Day Count Basis that is specified in the bond's Market Data, which is
			obtained by {@link ISphCBond::GetMarketYTMDayCountBasisType}.
			@endparamCOM

			@paramC# dayCountMasis
			the day count basis method for YTM, used for calculating the rate. See {@link static_data::CSMDayCountBasis}.
			If the object passed in null, then the day count basis method taken is that of the Day Count Basis that is specified in the bond's Market Data, which is
			obtained by {@link CSMBond::GetMarketYTMDayCountBasisType}.
			@endparamC#

			@param yieldCalculation
			the rate calculation method used. See {@link static_data::CSRYieldCalculation}.
			If the object passed in null, then the calculation method is that of the YTM Calculation mode that is specified in the bond's Market Data, and is
			obtained by {@link CSRBond::GetMarketYTMYieldCalculationType}.

			@paramCOM yieldCalculation
			the rate calculation method used. See {@link ISphCYieldCalculation}.
			If the object passed in null, then the calculation method is that of the YTM Calculation mode that is specified in the bond's Market Data, and is
			obtained by {@link ISphCBond::GetMarketYTMYieldCalculationType}.
			@endparamCOM

			@paramC# yieldCalculation
			the rate calculation method used. See {@link static_data::CSMYieldCalculation}.
			If the object passed in null, then the calculation method is that of the YTM Calculation mode that is specified in the bond's Market Data, and is
			obtained by {@link CSMBond::GetMarketYTMYieldCalculationType}.
			@endparamC#

			@param context
            the market data calculation context.

			@usage
			Dim manager As New SphCInstrument
			Dim sph_bond As SphCBond
			Set sph_bond = New SphCBond 
			sph_bond.GetFrom manager.GetInstance1(45852233) 'set sph_bond to an existing Bond (code for illustration only)

			Dim managerBasis As New SphCDayCountBasis
			Dim managerMode As New SphCYieldCalculation
			Dim context As New SphCMarketData

			Dim sph_day As New SphDay
			Dim dateTransaction, dateSettlement, dateOwnership As Long
			sph_day.InitWithString "20060217"  ' 17/02/2006
			dateTransaction = sph_day.GetDateAsLong
			sph_day.InitWithString "20060221"  ' 21/02/2006
			dateSettlement = sph_day.GetDateAsLong
			sph_day.InitWithString "20060221"  ' 21/02/2006
			dateOwnership = sph_day.GetDateAsLong

			Dim calcAdjusted, calcSettlm As Long

			Dim methodBasis As SphCDayCountBasis
			Dim methodMode As SphCYieldCalculation

			Set methodBasis = managerBasis.GetCSRDayCountBasis(SphE2_dcbActual_360)
			Set methodMode = managerMode.GetCSRYieldCalculation(SphE2_ycLinear)
			calcAdjusted = 1;
			calcSettlm = 0;

			Dim price As Double
			Dim delta As Double
			Dim gamma As Double
			sph_bond.GetPriceDeltaGammaByYTM price, delta, gamma, dateTransaction, dateSettlement, dateOwnership, 2.98, calcAdjusted, calcSettlm, methodBasis, methodMode
			@endusage

			* @version 6.0.0 added the new parameter context
			*/			
			virtual void  GetPriceDeltaGammaByYTM(		double						*price,
								  						double						*sensibility,
								  						double						*convexity,
														long 						transactionDate,
														long 						settlementDate,
														long						pariPassuDate,
														double 						yieldToMaturity,
														short 						adjustedDatesCalc=kUseDefaultValue,
														short 						valueDatesCalc=kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis = 0, 
														const static_data::CSRYieldCalculation	*yieldCalculation = 0,
														const market_data::CSRMarketData		&context =*market_data::gApplicationContext) const; 




			/** Generates the cash flows (explanation) and loads them in a table.

			@param context
			the market data.
			@param explicationArray
			output parameter, which is loaded with the cash flows generated.
			@param explication
			structured object containing the parameters (transaction date, settlement date, ownership date, day count basis, yield calculation type)
			for calculating . See {@link instrument::SSExplication}.
			The structure also specifies the End Date, date until which the cash flows are included. If the End Date is 0, then all cash flows are taken.
			@paramCOM explication
			structured object containing the parameters (transaction date, settlement date, ownership date, day count basis, yield calculation type)
			for calculating . See {@link ISphSExplication}.
			The structure also specifies the End Date, date until which the cash flows are included. If the End Date is 0, then all cash flows are taken.
			@endparamCOM

			@paramC# explication
			structured object containing the parameters (transaction date, settlement date, ownership date, day count basis, yield calculation type)
			for calculating . See {@link instrument::SSMExplication}.
			The structure also specifies the End Date, date until which the cash flows are included. If the End Date is 0, then all cash flows are taken.
			@endparamC#

			@param whichLeg
			not applicable for Bonds.
			*/
			virtual void GetRedemptionExplication(	const market_data::CSRMarketData&					context,
													_STL::vector<sophis::instrument::SSRedemption*>&	explicationArray,
													sophis::instrument::SSExplication&										explication,
													int													whichLeg = 0) const;


			/** Get the next coupon date.
			This method is called, when purshasing the instrument, to display the information
			on the bottom left of the dialog.
			@param whichLeg may be 0 or 1.
			@param transactionDate is the transaction date in number of days from 1/1/1904.
			@param nextCouponDate is the output parameter to set the next coupon date; O if no coupon.
			@param couponRate is the output parameter to put the rate to display.
			@param mayModifyCumExDistribution is the output parameter to know if the button
			@param atTheEndOfTheDay get the pari passu date to put.
			cum/ex can modify the fact to receive that coupon.
			The default implementation is no next coupon.
			@version 5.1 add a atTheEndOfTheDay
			@since 3.5
			*/
			virtual void			GetNextCouponDate(	int		whichLeg,
														long	transactionDate,
														long	*nextCouponDate,
														double	*couponRate,
														bool	*mayModifyCumExDistribution,
														long	*PariPassDate) const;

			/** Get the next coupon date.
			This method is called during the reporting to calculate the coupon to receive column.
			It is called only if the position is opened or if there was a transaction forty days before.
			@param transactionDate is the transaction date in number of days from 1/1/1904.
			@param couponList is the list of coupon.
			The default implementation is an empty list.
			@param couponList is the output parameter containing the list of coupons which may be included or excluded of P&L.
			@version 4.5.2.4 Modification of output parameters to take into account instruments with different record dates and different coupon currencies.
			@since 3.5
			*/
			virtual	void	GetNextCouponDate(	long	transactionDate,
												CouponList &couponList) const;

			/** Build a redemption table from CPR or WAM.

			@param context
			a market data

			@param pricingRedemption
			(output) the modified redemption table, to be used for pricing
			In CPR or WAMgiveCPR mode, all uncertain flows prepay uniformly at annual rate CPR, 
			until the maturity date
			In WAMonly mode, the remaining notional is redeemed in one time at the WAM 
			(even for amortizing bonds) 

			@param nb
			next uncertain flow

			@param cprPtr
			cpr to use for computation, to override the CPR entered in the Bond Window.

			@version 5.3
			@since 6.0 this method is virtual
			*/
			virtual void BuildModifiedRedemption(	const market_data::CSRMarketData		&context,
													_STL::vector<instrument::SSRedemption>	&pricingRedemption, 
													int*									nb=0, 
													double*									cprPtr = 0) const;

			/** INTERNAL.
			@version 5.3
			*/
			void PrepareComputation(const market_data::CSRMarketData												&context,
									_STL::auto_ptr<tools::CSRAssignement<_STL::vector<instrument::SSRedemption> > > &foo,
									_STL::auto_ptr<tools::CSRAssignement<bool> >									&bar,
									double*																			cprPtr = 0) const ;

			/** INTERNAL
				@version 7.2
			*/
			void AdjustRedemptionForFloatingIntex(_STL::vector<instrument::SSBondExplication> explicationSophis) const ;

			/** Computes the WAM from CPR.

			@param context
			a market data

			@param cprPtr
			pointer to a CPR value; if not provided, uses the CPR returned by {@link GetCPR}.

			@return
			the WAM, expressed in days since 01/01/1904
			The WAM is the maturity of remaining flows weighted by their amount,
			with prepayment taken into account, at annual rate CPR

			@version 5.3
			*/
			double ComputeWAM(	const market_data::CSRMarketData	&context,
								double*								cprPtr = 0);

			/** Computes the CPR corresponding to the WAM.
			
			@param wamPtr
			pointer to a WAM value; if not provided, uses the CPR returned by {@link GetWAM}

			@return
			the CPR which give the given WAM
			
			@see {@link ComputeWAM}

			@version 5.3
			*/
			double ComputeCPR(	const market_data::CSRMarketData	&context,
								long*								wamPtr = 0);

			/* Compute the WAM or the CPR according to the ABS pricing method
			In CPR mode, computes the WAM and set it by SetWAM
			In WAM and WAMgiveCPR modes, computes the CPR and set it by SetCPR

			@param context
			a market data.

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param isYTM
			true if the computation is using YTM 

			@param ytm
			the YTM used for computation if isYTM is set to true

			@param adjustedDatesCalc
			ytm computed on adjusted date

			@param	valueDatesCalc
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type
			
			@see {@link ComputeWAM}.
			@see {@link ComputeCPR}.

			@version 5.3
			*/
			void ComputeCPRWAM(	_STL::auto_ptr<tools::CSRAssignement<bool> >&	calibrated,
								const market_data::CSRMarketData				&context,
								long 											transactionDate,
								long 											settlementDate,
								long											pariPassuDate,
								bool											isYTM = false,
								double											ytm = 0,
								short 											adjustedDatesCalc=kUseDefaultValue,
								short 											valueDatesCalc=kUseDefaultValue,
								const static_data::CSRDayCountBasis				*dayCountBasis=0, 
								const static_data::CSRYieldCalculation			*yieldCalculation=0);

			/* Calibrate prepayment model, CPR, WAM, if not already done
			
			@param calibrated
			an autopointer which must point to zero, so that the calibration is released when the auto_ptr
			is destructed.

			@param context
			context used for calibration

			@version 5.3
			*/
			void Calibrate(_STL::auto_ptr<tools::CSRAssignement<bool> >&	calibrated,
							const market_data::CSRMarketData				&context) const;

			/* Computes the CPR and WAM Sensitivities

			@param CPRSensitivity
			(output) the computed CPR sensitivity

			@param WAMSensitivity
			(output) the computed WAM sensitivity

			@param isYTM
			true if the computation is using YTM 

			@param context
			a market data

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param yieldToMaturity
			the YTM used for computation if isYTM is set to true
			
			@param adjustedDatesCalc
			ytm computed on adjusted date

			@param	valueDatesCalc
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type
			
			@see {@link GetCPRSensitivity}
			@see {@link GetWAMSensitivity}

			@version 5.3
			*/
			void  GetCPRWAMSensitivities(	double									&CPRSensitivity,
											double									&WAMSensitivity,
											bool									isYTM,
											const market_data::CSRMarketData		&context,
											long 									transactionDate,
											long 									settlementDate,
											long									pariPassuDate,
											double 									yieldToMaturity = 0.,
											short 									adjustedDatesCalc=kUseDefaultValue,
											short 									valueDatesCalc=kUseDefaultValue,
											const static_data::CSRDayCountBasis		*dayCountBasis = 0, 
											const static_data::CSRYieldCalculation	*yieldCalculation = 0,
											const instrument::CSRInstrument*		instrument = 0 ) const; 

			/* Computes the CPR and WAM implied by the dirty price, according to the ABS pricing method

			@param cpr
			(output) the computed Implied CPR

			@param wam
			(output) the computed Implied WAM

			@param dirtyPrice
			the dirty price to be obtained

			@param context
			a market data

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param adjustedDatesCalc
			ytm computed on adjusted date

			@param	valueDatesCalc
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type
			
			@see {@link GetImpliedCPR}.
			@see {@link GetImpliedWAM}.

			@version 5.3
			*/
			void GetImpliedCPRWAM(	double									&cpr,
									long									&wam,
									double									dirtyPrice,
									const market_data::CSRMarketData		&context,
									long 									transactionDate,
									long 									settlementDate,
									long									pariPassuDate,
									short 									adjustedDatesCalc=kUseDefaultValue,
									short 									valueDatesCalc=kUseDefaultValue,
									const static_data::CSRDayCountBasis		*dayCountBasis = 0, 
									const static_data::CSRYieldCalculation	*yieldCalculation = 0);

			/* Computes the CPR which gives in CPR mode the same price as 
			the entered WAM in WAMonly mode

			@param context
			a market data

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.
			
			@param isYTM
			if true, computation uses the given YTM

			@param ytm
			the YTM to use if isYTM is true

			@param adjustedDatesCalc
			ytm computed on adjusted date

			@param	valueDatesCalc
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type

			@return
			the computed Implied CPR

			@version 5.3
			*/
			double GetImpliedCPRfromWAM(const market_data::CSRMarketData		&context,
										long 									transactionDate,
										long 									settlementDate,
										long									pariPassuDate,
										bool									isYTM = false,
										double									ytm = 0,
										short 									adjustedDatesCalc=kUseDefaultValue,
										short 									valueDatesCalc=kUseDefaultValue,
										const static_data::CSRDayCountBasis		*dayCountBasis=0, 
										const static_data::CSRYieldCalculation	*yieldCalculation=0);

			/* Computes the Pool Factor Sensitivity according to the ABS pricing method
			
			@param isYTM
			if true, computation uses the given YTM

			@param context
			a market data

			@param transactionDate
			the transaction date.

			@param settlementDate
			the payment date.

			@param pariPassuDate
			the ownership date, that is the date when the bond belongs to the buyer.

			@param yieldToMaturity
			the YTM to use if isYTM is true

			@param adjustedDatesCalc
			ytm computed on adjusted date

			@param	valueDatesCalc
			ytm computed on value date

			@param dayCountBasis
			ytm day count basis type

			@param yieldCalculation
			ytm yield calculation type

			@return
			the pool factor sensitivity
			
			@see {@link GetPoolFactorSensitivity}

			@version 5.3
			*/
			double  GetPoolFactorSensitivity(	bool									isYTM,
												const market_data::CSRMarketData		&context,
												long 									transactionDate,
												long 									settlementDate,
												long									pariPassuDate,
												double 									yieldToMaturity = 0.,
												short 									adjustedDatesCalc=kUseDefaultValue,
												short 									valueDatesCalc=kUseDefaultValue,
												const static_data::CSRDayCountBasis		*dayCountBasis = 0, 
												const static_data::CSRYieldCalculation	*yieldCalculation = 0,
												const instrument::CSRInstrument*		instrument = 0 ) const;


			virtual double	GetYTMByDirtyPrice(long 					transactionDate, 
							   long 					settlementDate,
							   long						pariPassuDate,
							   double 					dirtyPrice,
							   short					adjustedDatesCalc,
							   short					valueDatesCalc=kUseDefaultValue,
							   const static_data::CSRDayCountBasis		*dayCountBasis = 0, 
							   const static_data::CSRYieldCalculation	*yieldCalculation = 0,
							   const market_data::CSRMarketData		&context =*market_data::gApplicationContext,
							   double					startPoint = NOTDEFINED ) const OVERRIDE;

			/** Compute the Amortizing Flows for an ABCDS leg defined on the ABS
			The computation is done with zero CPR, considering only known pool factors.
			For the fixed leg, give the pool factors at  start dates of ABCDS coupons.
			For the credit leg, give amortizing at real amortizing dates.

			@param inVector
			coupon dates vector (only one period for the credit leg)

			@param outVector
			Amortizing vector (output)

			@param isCreditLeg
			true when amortizing must be computed for the credit leg

			@version 5.3
			*/
			virtual void GetAmortizedSwapFlows(	const _STL::vector<instrument::SSFlowDatesForAmortizing>&	inVectorFlows,
												_STL::vector<instrument::SSAmortizingfFlow>&				outVectorAmortizing,
												bool														isCreditLeg) const;

			/** Compute the amortizing of an ABCDS from the ABS prepayment model.

			@param context
			market data used for computation

			@param amortizingScheme
			Amortizing computed (output)

			@param issueDate
			start date for amortizing computation

			@param endDate
			end date for amortizing computation

			@version 5.3
			@since 6.0 method is virtual
			*/
			virtual void FillAmortizingScheme(	const market_data::CSRMarketData&	context,
												CSRCDSPricer::AmortizingScheme&		amortizingScheme,
												long								issueDate,
												long								endDate) const;

			/**
			* Overload of the CSRInstrument::NewAlertList method.
			* @param forecastDate is the date of forecast.
			* @param nb is a valid address to set the count of alerts.
			* @return an array of alerts, which is deleted by delete [].
			* This method is called during the forecast for all instruments in
			* open positions and is used to fill the alert books.
			* Note that this list is added to the conventional alerts directly managed by the forecasts.
			*/
			virtual instrument::SSAlert* NewAlertList( long forecastDate , int* nb ) const;

			/** INTERNAL
			@version 5.3
			*/
			double	GetCPR(const market_data::CSRMarketData& context) const;

			/** INTERNAL
			@version 5.3
			*/
			long	GetWAM(const market_data::CSRMarketData& context) const;


			/** INTERNAL
			@version 5.3
			*/
			infos_user *	GetPrepaymentData() const;

			/** INTERNAL
			@version 5.3
			*/
			void			SetPrepaymentData( infos_user * iu );

			/** internal use
				forces the reload of the historized CPR from the datatable
				@version 5.3.3
			*/
			void	ResetCPRDate() const;

			/** internal use
				forces the reload of the historized WAM from the datatable
				@version 5.3.3
			*/
			void	ResetWAMDate() const;

			/** Calculates the accrued coupon.
			It is used when re-evaluating the bond to calculate the accrued.
			Special attention is given to how the bond price is quoted. If the quotation is In Price Without Accrued, then the
			result would be: accrued coupon * (bond's notional / 100).
			@param pariPassuDate
			is the pari passu date in number of days from 1/1/1904, generally obtained by {@link CSRBond::GetPariPassuDate}.
			@paramCOM pariPassuDate
			is the pari passu date in number of days from 1/1/1904, generally obtained by {@link ISphCBond::GetPariPassuDate}.
			@endparamCOM
			@paramC# pariPassuDate
			is the pari passu date in number of days from 1/1/1904, generally obtained by {@link CSMBond::GetPariPassuDate}.
			@endparamC#

			@param accruedCouponDate
			is the accrued coupon date in number of days from 1/1/1904, generally obtained by {@link CSRBond::GetAccruedCouponDate}.
			@paramCOM 
			is the accrued coupon date in number of days from 1/1/1904, generally obtained by {@link ISphCBond::GetAccruedCouponDate}.
			@endparamCOM
			@paramC# 
			is the accrued coupon date in number of days from 1/1/1904, generally obtained by {@link CSMBond::GetAccruedCouponDate}.
			@endparamC#
			@return
			the total accrued coupon in percentage (example 3 for 3%).
			If the quotation is in Price or in Percent With Accrued, then the value returned is 0.

			@usage
			Dim manager As New SphCInstrument
			Dim sph_bond As SphCBond
			Set sph_bond = New SphCBond 
			sph_bond.GetFrom manager.GetInstance1(45852233) 'set sph_bond to an existing Bond (code for illustration only)

			If (Not sph_bond.GetQuotationType = SphE2_aqInPrice) And (Not sph_bond.GetQuotationType = SphE2_aqInPercentWithAccrued) Then
				Dim sph_day As New SphDay
				Dim datePariPassu, dateAccredCoupon As Long
				sph_day.InitWithString "20060103"  ' 1st Jan 2006
				datePariPassu = sph_day.GetDateAsLong
				sph_day.InitWithString "20071009"  ' 9th October 2007
				dateAccredCoupon = sph_day.GetDateAsLong
				Dim accruedCoupon As Double
				accruedCoupon = sph_bond.GetAccruedCoupon(datePariPassu, dateAccredCoupon)
				Set sph_day = Nothing
			End If
			@endusage
			 */
			virtual	double	GetAccruedCoupon(long pariPassuDate, long accruedCouponDate) const;

			enum eABSType
			{
				eatPassthrough = 0,
				eatIO,
				eatPO,
				eatDeal
			};

			/** Return the ABS Type: Passthrough (standard), Interest Only or Principal Only. 
			@version 5.3.6
			*/

			eABSType GetABSType() const;

			/** Set the ABS Type: Passthrough (standard), Interest Only or Principal Only.
			@param absType the ABS type
			@version 5.3.6
			*/
			void SetABSType(eABSType absType);

			/** Gets the tranche notional, as specified in the bond GUI.
			@return
			the nominal amount.
			*/
			double	CSRABSBond::GetTrancheNotional() const;

			/** Gets the Nominal amount, as specified in the bond.
			@return
			the nominal amount.
			*/
			virtual double	GetNotionalInProduct() const;

			virtual	double	GetQuotity(bool withTaxes=false) const;

			double GetQuotity(instrument::eAskQuotationType type, bool coursDansAutreDevise) const;

		protected:
			/** INTERNAL.
			@version 5.3
			*/
			CSRABSBondMM fMMABSBond;

			/** INTERNAL.
			@version 5.3
			*/
			SPH_BEGIN_NOWARN_EXPORT
			mutable _STL::auto_ptr<CSRPrepayment> fPrepayment;
			SPH_END_NOWARN_EXPORT

			/** INTERNAL.
			@version 5.3
			*/
			mutable bool fIsExchanged;

			bool   fNoCPR;

			mutable bool fConsiderAsFloatingNotional;

			/** INTERNAL.
			@version 5.3
			*/
			mutable bool fIsCalibrated;

			/** INTERNAL.
			@version 5.3.3
			*/
			mutable long	fCPRDate;

			/** INTERNAL.
			@version 5.3.3
			*/
			mutable double	fHistoCPR;

			/** INTERNAL.
			@version 5.3.3
			*/
			mutable long	fWAMDate;

			/** INTERNAL.
			@version 5.3.3
			*/
			mutable long	fHistoWAM;

			/** INTERNAL.
			@version 5.3.6
			*/
			eABSType fABSType;

			friend class PoolFactorComputationFunction;

		private:
			//DEPRECATED_RESULTS double GetImpliedCPR() const;
			//DEPRECATED_RESULTS long   GetImpliedWAM() const;
			//DEPRECATED_RESULTS void SetImpliedCPR( double impliedCPR );
			//DEPRECATED_RESULTS void SetImpliedWAM( long impliedWAM );

			//DEPRECATED_RESULTS double fImpliedCPR;
			//DEPRECATED_RESULTS long   fImpliedWAM;

		};

		/** Class used to retrieve the name of the pricing methods.
		@version 5.3
		*/
		class SOPHIS_FIT CSRPricingMethodNames
		{
		public:
			/** Get a pricing method from its name.

			@param name
			the name of the pricing method to get.

			@return
			the pricing method, or epmCPR if not found.

			@version 5.3
			*/
			eABSPricingMethod GetByName(const char* name) const;

			/** Get the name of a pricing method.

			@param method
			the pricing method whose name will be returned.

			@return
			the name of the pricing method.
			*/
			const char* GetName(eABSPricingMethod method) const;

			/** Get the total number fo pricing methods.

			@return
			the number of pricing methods.

			@version 5.3
			*/
			int GetCount() const;

			/** Get the i-th stored name.

			@param i
			the index of the name to retrieve.

			@return
			the i-th name or 0 if i is out of bound.

			@version 5.3
			*/
			const char* GetNthName(int i) const;

			/** Get the global instance.

			@return
			the global pricing method names container.

			@version 5.3
			*/
			static const CSRPricingMethodNames& GetInstance();

		protected:
			/** INTERNAL.
			@version 5.3
			*/
			CSRPricingMethodNames();

			/** INTERNAL.
			@version 5.3
			*/
			static CSRPricingMethodNames instance;

			/** INTERNAL.
			@version 5.3
			*/
			SPH_BEGIN_NOWARN_EXPORT
			_STL::map<_STL::string, eABSPricingMethod> fList;
			SPH_END_NOWARN_EXPORT
		};

		class SOPHIS_FIT CSRABSParameterName
		{
		public:

			CSRABSParameterName() {}
			virtual ~CSRABSParameterName() {}

			/** Clone function used by prototype
			It is generally created by the macro DECLARATION_ABS_PARAMETER
			*/
			virtual	CSRABSParameterName* Clone() const = 0;

			/** The key for the prototype is a const char* 
			@see CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRABSParameterName, const char *, sophis::tools::less_char_star> prototype;
			
			/** Access to the singleton containing all the derived class of CSRABSParameterName
			It is filled when using the macro INITIALISE_ABS_PARAMETER
			*/
			static prototype & GetPrototype();			
			
			/*Name of the CSRABSParameterName menu*/
			virtual bool IsValid (const char * type) const = 0;
		};
		
	} // end of namespace finance

}// end of namespace sophis
SPH_EPILOG


#endif // _SphABSBond_H_

