/*
File:		SphABSCashFlows.h

Contains:	Classes for CashFlows data of ABS Bond.

Copyright:	� 1995-2005 Sophis.

*/
/*! \file SphABSCashFlows.h
\brief Classes for CashFlows data of ABS Bond.
*/

#pragma once


#ifndef _SphABSCashFlows_H__
#define _SphABSCashFlows_H__

#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/finance/SphABSBond.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275) // Can not export a class derivated from a non exported one
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

#include __STL_INCLUDE_PATH(vector)

#define ABS_DEFAULT_SCENARIO "current"

namespace sophis	{
	namespace instrument	
	{
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

namespace sophis	{
	namespace finance	{
		class SOPHIS_FIT CSRABSCashFlows {
		public:
			
			struct SSABSCashFlow
			{
				SSABSCashFlow() : maturityDate(0), paymentDate(0), poolFactor(1.), principal(0), interest(0), balance(0), interestShortfall(0), redemption(0), forexNotional(1.)
				{}

				SSABSCashFlow(const SSABSCashFlow& cashFlow)
				{
					maturityDate = cashFlow.maturityDate;
					paymentDate = cashFlow.paymentDate;
					poolFactor = cashFlow.poolFactor; 
					principal = cashFlow.principal;
					interest = cashFlow.interest;
					balance = cashFlow.balance; 
					interestShortfall = cashFlow.interestShortfall;
					redemption = cashFlow.redemption;
					forexNotional = cashFlow.forexNotional;
				}

				inline bool operator==(const SSABSCashFlow& cashFlow) 
				{
					return (maturityDate == cashFlow.maturityDate);
				}

				inline SSABSCashFlow& operator=(const SSABSCashFlow& cashFlow) 
				{
					maturityDate = cashFlow.maturityDate;
					paymentDate = cashFlow.paymentDate;
					poolFactor = cashFlow.poolFactor; 
					principal = cashFlow.principal;
					interest = cashFlow.interest;
					balance = cashFlow.balance; 
					interestShortfall = cashFlow.interestShortfall;
					redemption = cashFlow.redemption;
					forexNotional = cashFlow.forexNotional;
					return const_cast<SSABSCashFlow&>(*this);
				}	

				long				maturityDate;
				long				paymentDate;
				double				poolFactor;
				double				principal; 
				double				interest; 
				double				balance;
				double				interestShortfall;
				double				redemption;
				double				forexNotional;
			};

			struct lessCashFlow : public _STL::binary_function<const CSRABSCashFlows::SSABSCashFlow&, const CSRABSCashFlows::SSABSCashFlow&, bool>
			{
				bool operator() (const CSRABSCashFlows::SSABSCashFlow& cf1, const CSRABSCashFlows::SSABSCashFlow& cf2)
				{
					return cf1.maturityDate < cf2.maturityDate 
						|| cf1.maturityDate == cf2.maturityDate && (cf1.paymentDate < cf2.paymentDate
						|| cf1.paymentDate == cf2.paymentDate && (cf1.poolFactor < cf2.poolFactor
						|| cf1.poolFactor == cf2.poolFactor && (cf1.principal < cf2.principal
						|| cf1.principal == cf2.principal && (cf1.interest < cf2.interest
						|| cf1.interest == cf2.interest && (cf1.balance < cf2.balance
						)))));
				}
			};

			typedef _STL::vector< SSABSCashFlow> tABSCashFlowsVector; 
			typedef _STL::map<long, tABSCashFlowsVector> tABSCashFlowsMap;


			CSRABSCashFlows();
			virtual ~CSRABSCashFlows();
			virtual CSRABSCashFlows*	Clone() const;
			CSRABSCashFlows(const CSRABSCashFlows& source);	

			virtual void ClearMap(); 
			virtual void ClearList (long scenarioId);

			virtual void GetABSCashFlowsMap(tABSCashFlowsMap& cfMap) const;
			virtual void SetABSCashFlowsMap(tABSCashFlowsMap& cfMap);

			virtual void GetABSCashFlowsList(long scenarioId, tABSCashFlowsVector& cfList) const;
			virtual void SetABSCashFlowsList(long scenarioId, tABSCashFlowsVector& cfList);

			virtual bool GetOneCashFlow(long scenarioId, long date, CSRABSCashFlows::SSABSCashFlow& cashFlow) const;

			long GetABSScenario() const; // here it is just the displayed scenario in the tab cash flows
			void SetABSScenario(long  scenarioId);

			void GetABSScenarioList(_STL::vector<_STL::string>& scenarios);
			
			/***********
			*   SQL   *
			***********/

			/**
			*	Save the CashFlows data into the database
			*	@param sico : sicovam of the instrument which contains the CashFlows
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico);

			/**
			*	Load the CashFlows data from the database
			*	@param sico : sicovam of the instrument which contains these CashFlows
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico);


			/***********
			*   XML  *
			***********/

			void DescribeABSScenario(	sophis::tools::dataModel::DataSet&		dataSet, 
										const char*								field_name,
										const char*								comment,
										const CSRABSBond*						absBond,
										long									scenarioId);

			void UpdateABSScenario (	const sophis::tools::dataModel::DataSet&	dataSet, 
										const char*									field_name,
										CSRABSBond*									absBond,
										long										scenarioId);


			/** Common method to describe CashFlows information for ABS Deals.
			* 
			* \param dataSet the destination DataSet.
			* \param field_name XML tag
			* \param comment optional comment for the grammar
			*/
			void DescribeABSScenarioList(	sophis::tools::dataModel::DataSet&		dataSet, 
											const char*								field_name,
											const char*								comment,
											const CSRABSBond*						absBond);						

			/** Common method to fill CashFlows information from a dataset.
			* 
			* \param dataSet the source DataSet.
			* \param field_name XML tag
			*/
			void UpdateABSScenarioList(	const sophis::tools::dataModel::DataSet&	dataSet, 
										const char*									field_name,
										CSRABSBond*									absBond);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the CashFlows.
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the ABS bond
			*	@param newSico : sico of the archived ABS Bond
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRABSCashFlows *cashFlows );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRABSCashFlows *&cashFlows );

		private:
			/*********************** 
			* CashFlows Data *
			**********************/
			tABSCashFlowsMap	fABSCashFlowsMap;
			long				fScenarioId; 

		};
	}
}

// For archives
extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRABSCashFlows * absCashFlows);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRABSCashFlows *& absCashFlows);

extern sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & , const sophis::finance::CSRABSCashFlows::SSABSCashFlow & );
extern const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & , sophis::finance::CSRABSCashFlows::SSABSCashFlow & );

#endif //!_SphABSCashFlows_H__
