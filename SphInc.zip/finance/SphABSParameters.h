/*
File:		SphABSParameters.h

Contains:	Classes for Parameter data of ABS Bond.

Copyright:	� 1995-2005 Sophis.

*/
/*! \file SphABSParameters.h
\brief Classes for Parameters of ABS Bond.
*/

#pragma once


#ifndef _SphABSParameter_H__
#define _SphABSParameter_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"
#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/static_data/SphHistoricalData.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275) // Can not export a class derivated from a non exported one
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

#include __STL_INCLUDE_PATH(vector)

namespace sophis	{
	namespace instrument	
	{
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

namespace sophis	{
	namespace finance	{
		
		struct SOPHIS_FIT SSABSParameter
		{
				
			SSABSParameter() : maturity(0), value(0), fixedValue(0), overValue(0), overValueInPercent(false)
			{
				strcpy(name, "");
				strcpy(type, "No Type");
			}

			SSABSParameter(const SSABSParameter& parameter)
			{
				strcpy(name, parameter.name);
				strcpy(type, parameter.type);
				maturity = parameter.maturity;
				value = parameter.value;
				fixedValue = parameter.fixedValue; 
				overValue = parameter.overValue;
				overValueInPercent = parameter.overValueInPercent;
			}

			inline bool operator==(const SSABSParameter& parameter) 
			{
				return (strcmp(name,parameter.name) == 0 &&
					strcmp(type,parameter.type) == 0 &&
				maturity == parameter.maturity);
			}

			inline SSABSParameter& operator=(const SSABSParameter& parameter) 
			{
				strcpy(name, parameter.name);
				strcpy(type, parameter.type);
				maturity = parameter.maturity;
				value = parameter.value;
				fixedValue = parameter.fixedValue; 
				overValue = parameter.overValue;
				overValueInPercent = parameter.overValueInPercent;
				return const_cast<SSABSParameter&>(*this);
			}	

			char	name[SIZE_INSTRUMENT_NAME];
			char	type[SIZE_INSTRUMENT_NAME];
			long	maturity;
			double	value;
			double	fixedValue;
			double	overValue;
			bool    overValueInPercent;
					
		};

		class SOPHIS_FIT CSRABSParameters {
		public:
			
			typedef _STL::vector< SSABSParameter> tABSParametersVector; 

			CSRABSParameters();
			virtual ~CSRABSParameters();
			virtual CSRABSParameters*	Clone() const;
			CSRABSParameters(const CSRABSParameters& source);	
			
			void ClearParameters(); 

			void GetABSParametersVector(tABSParametersVector& params) const;
			void SetABSParametersVector(tABSParametersVector& params);

			void GetABSParametersByName(_STL::string parameterName, tABSParametersVector& params) const;
			void SetABSParametersByName(_STL::string parameterName, tABSParametersVector& params);

			void GetABSParameterNames(_STL::vector<_STL::string>& parameterNames) const;
			
			/***********
			*   SQL   *
			***********/

			/**
			*	Save the Parameters data into the database
			*	@param sico : sicovam of the instrument which contains the Parameters
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico);

			/**
			*	Load the Parameters data from the database
			*	@param sico : sicovam of the instrument which contains these Parameters
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico);


			/***********
			*   XML  *
			***********/


			/** Common method to describe Parameters information for ABS.
			* 
			* \param dataSet the destination DataSet.
			* \param field_name XML tag
			* \param comment optional comment for the grammar
			*/
			void DescribeABSParameters(	sophis::tools::dataModel::DataSet&		dataSet, 
										const char*								field_name,
										const char*								comment);						

			/** Common method to fill Parameters information from a dataset.
			* 
			* \param dataSet the source DataSet.
			* \param field_name XML tag
			*/
			void UpdateABSParameters(	const sophis::tools::dataModel::DataSet&	dataSet, 
										const char*									field_name);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the Parameters.
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the ABS bond
			*	@param newSico : sico of the archived ABS Bond
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRABSParameters *parameters );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRABSParameters *&parameters );

		private:
			/*********************** 
			* Parameters Data      *
			**********************/
			tABSParametersVector	fABSParameters;
		};
	}
}

// For archives
extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRABSParameters * absParameters);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRABSParameters *& absParameters);

extern sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & , const sophis::finance::SSABSParameter & );
extern const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & , sophis::finance::SSABSParameter & );


#endif //!_SphABSParameters_H__

			