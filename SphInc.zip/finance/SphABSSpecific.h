/*
File:		SphABSSpecific.h

Contains:	Classes for Specific data of ABS Bond.

Copyright:	� 1995-2005 Sophis.

*/
/*! \file SphABSSpecific.h
\brief Classes for Specific data of ABS Bond.
*/

#pragma once


#ifndef _SphABSSpecific_H__
#define _SphABSSpecific_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"
#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/static_data/SphHistoricalData.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275) // Can not export a class derivated from a non exported one
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

#include __STL_INCLUDE_PATH(vector)

namespace sophis	{
	namespace instrument	
	{
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

namespace sophis	{
	namespace finance	{
		
		enum SOPHIS_FIT eCashFlowGeneration
		{
			_ecfSophis		= 1,
			_ecfBloomberg	= 2,
			_ecfIntex		= 3
		};

		enum SOPHIS_FIT eCreditDefaultType
		{
			_ecdNoDefault		= 1,
			_ecdMDR				= 2,
			_ecdREPAYMDR		= 3,
			_ecdCDR				= 4,
			_ecdSDA				= 5,
			_ecdSDR				= 6,
			_ecdORIGMDR			= 7,
			_ecdORIGCDR			= 8,
			_ecdORIGSDR			= 9,
			_ecdSCHMDR			= 10,
			_ecdSCHCDR			= 11,
			_ecdAGGMDR			= 12,
			_ecdORIGAGGMDR		= 13,
		};

		enum SOPHIS_FIT eSeverityMethod
		{
			_esmStandard		= 1,
			_esmLIQAMT			= 2,
			_esmAmount			= 3,
			_esmRecoverAmount	= 4,
			_esmAllowExcessLoss	= 5
		};

		enum SOPHIS_FIT eDelinquencyType
		{
			_edtInPercent		= 1,
			_edtInAggregPercent	= 2
		};

		enum SOPHIS_FIT eRecoveryType
		{
			_ertInPercent		= 1
		};

		class SOPHIS_FIT CSRABSSpecific {
		public:
			
			CSRABSSpecific();
			virtual ~CSRABSSpecific();
			virtual CSRABSSpecific*	Clone() const;
			CSRABSSpecific(const CSRABSSpecific& source);	

			/** Get the accumulatd loss (in amount).
			@return the loss			
			@version 7.1.3
			*/
			double	GetAccumulatedLoss() const;

			/** Set the accumulated loss (in amount).
			@param loss
			the accumulated loss to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedLoss( double loss);

			/** Get the accumulatd writedown.
			@return the writedown			
			@version 7.1.3
			*/
			double	GetAccumulatedWritedown() const;

			/** Set the accumulated writedown.
			@param writedown
			the accumulated writedown to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedWritedown( double writedown);

			/** Get the accumulatd interestShortfall.
			@return the interestShortfall			
			@version 7.1.3
			*/
			double	GetAccumulatedInterestShortfall() const;

			/** Set the accumulated interestShortfall.
			@param interestShortfall
			the accumulated interestShortfall to set.
			@version 7.1.3 
			*/
			void	SetAccumulatedInterestShortfall( double interestShortfall);

			/** Get the last update date.
			@return the last cash flow generation update			
			@version 7.1.3
			*/
			long	GetLastUpdateDate() const;

			/** Set the last update date.
			@param date
			the last update cash flow date to set.
			@version 7.1.3 
			*/
			void	SetLastUpdateDate( long date);

			/** Get the Cash Flow Generation provider.
			@return the cash flow generation provider			
			@version 7.1.3
			*/
			short	GetCashFlowGeneration() const;

			/** Set the cash flow generation provider.
			@param cashFlowGeneration
			the cash flow generation provider to set.
			@version 7.1.3 
			*/
			void	SetCashFlowGeneration( short cashFlowGeneration);

			/** Get the Credit Default Type.
			@return the credit defaukt type			
			@version 7.1.3
			*/
			short	GetCreditDefaultType() const;

			/** Set the credit defaukt type.
			@param creditDefault
			the credit default type to set.
			@version 7.1.3 
			*/
			void	SetCreditDefaultType( short creditDefault);

			/** Set the severity method.
			@param severityMethod
			the severity method to set.
			@version 7.1.3 
			*/
			short	GetSeverityMethod() const;

			/** Set the severity method.
			@param severityMethod
			the severity method to set.
			@version 7.1.3 
			*/
			void	SetSeverityMethod( short severityMethod);

			/** Get the Revovery Type.
			@return the recoverytype		
			@version 7.1.3
			*/
			short	GetRecoveryType() const;

			/** Set the Recovery Type.
			@param recoveryType
			the recovery type to set.
			@version 7.1.3 
			*/
			void	SetRecoveryType( short recoveryType);

			/** Get the Delinquency type.
			@return the delinquency type			
			@version 7.1.3
			*/
			short	GetDelinquencyType() const;

			/** Set the Delinquency Type.
			@param delinquencyType
			the delinquency type to set.
			@version 7.1.3 
			*/
			void	SetDelinquencyType( short delinquencyType);

			/** Get the Cash Flow scenario chosen for calculation.
			@return the cah flow scenario Id			
			@version 7.1.3
			*/
			long	GetCashFlowScenario() const;

			/** Set the cash flow scenario chosen for calculation.
			@param scenarioId
			the cash flow scenario to set.
			@version 7.1.3 
			*/
			void	SetCashFlowScenario( long scenarioId);


			/***********
			*   SQL   *
			***********/

			/**
			*	Save the Specific data into the database
			*	@param sico : sicovam of the instrument which contains the Specific
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico);

			/**
			*	Load the Specific data from the database
			*	@param sico : sicovam of the instrument which contains these Specific
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico);


			/***********
			*   XML  *
			***********/

			/** Common method to describe Specific information for ABS Deals.
			* 
			* \param dataSet the destination DataSet.
			* \param field_name XML tag
			* \param comment optional comment for the grammar
			*/
			void DescribeABSSpecific(	sophis::tools::dataModel::DataSet&		dataSet, 
										const char*								field_name,
										const char*								comment);						

			/** Common method to fill Specific information from a dataset.
			* 
			* \param dataSet the source DataSet.
			* \param field_name XML tag
			*/
			void UpdateABSSpecific(	const sophis::tools::dataModel::DataSet&	dataSet, 
									const char*									field_name);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the Specific.
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the ABS bond
			*	@param newSico : sico of the archived ABS Bond
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRABSSpecific *Specific );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRABSSpecific *&Specific );

		private:
			/*********************** 
			* Specific Data *
			**********************/
			double					fAccumulatedLoss;
			double					fAccumulatedWritedown;
			double					fAccumulatedInterestShortfall;
			long					fLastUpdateDate;
			short					fCashFlowGeneration;
			short					fCreditDefaultType;
			short					fSeverityMethod;
			short					fRecoveryType; 
			short					fDelinquencyType;
			long					fCashFlowScenarioId; 
		};


		class SOPHIS_FIT CSRCashFlowProviderNames
		{
		public:
			sophis::finance::eCashFlowGeneration GetByName(const char* name) const;
			
			const char*		GetName(sophis::finance::eCashFlowGeneration provider) const;

			int				GetCount() const;

			const char*		GetNthName(int i) const;

			static const CSRCashFlowProviderNames& GetInstance();

		protected:

			CSRCashFlowProviderNames();

			static CSRCashFlowProviderNames instance;

			_STL::map<_STL::string, sophis::finance::eCashFlowGeneration> fList;
		};

		class SOPHIS_FIT CSRCreditDefaultTypeNames
		{
		public:
			sophis::finance::eCreditDefaultType GetByName(const char* name) const;
			
			const char*		GetName(sophis::finance::eCreditDefaultType creditDefault) const;

			int				GetCount() const;

			const char*		GetNthName(int i) const;

			static const CSRCreditDefaultTypeNames& GetInstance();

		protected:

			CSRCreditDefaultTypeNames();

			static CSRCreditDefaultTypeNames instance;

			_STL::map<_STL::string, sophis::finance::eCreditDefaultType> fList;
		};

		class SOPHIS_FIT CSRSeverityMethodNames
		{
		public:
			sophis::finance::eSeverityMethod GetByName(const char* name) const;
			
			const char*		GetName(sophis::finance::eSeverityMethod severityMethod) const;

			int				GetCount() const;

			const char*		GetNthName(int i) const;

			static const CSRSeverityMethodNames& GetInstance();

		protected:

			CSRSeverityMethodNames();

			static CSRSeverityMethodNames instance;

			_STL::map<_STL::string, sophis::finance::eSeverityMethod > fList;
		};

		class SOPHIS_FIT CSRRecoveryTypeNames
		{
		public:
			sophis::finance::eRecoveryType GetByName(const char* name) const;
			
			const char*		GetName(sophis::finance::eRecoveryType severityMethod) const;

			int				GetCount() const;

			const char*		GetNthName(int i) const;

			static const CSRRecoveryTypeNames& GetInstance();

		protected:

			CSRRecoveryTypeNames();

			static CSRRecoveryTypeNames instance;

			_STL::map<_STL::string, sophis::finance::eRecoveryType > fList;
		};

		class SOPHIS_FIT CSRDelinquencyTypeNames
		{
		public:
			sophis::finance::eDelinquencyType GetByName(const char* name) const;
			
			const char*		GetName(sophis::finance::eDelinquencyType severityMethod) const;

			int				GetCount() const;

			const char*		GetNthName(int i) const;

			static const CSRDelinquencyTypeNames& GetInstance();

		protected:

			CSRDelinquencyTypeNames();

			static CSRDelinquencyTypeNames instance;

			_STL::map<_STL::string, sophis::finance::eDelinquencyType > fList;
		};
	}
}

// For archives
extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRABSSpecific * absSpecific);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRABSSpecific *& absSpecific);

#endif //!_SphABSSpecific_H__
