/*
File:		SphABSTranches.h

Contains:	Classes for tranches data of ABS Bond.

Copyright:	� 1995-2005 Sophis.

*/

/*! \file SphABSTranches.h
\brief Classes for tranches data of ABS Bond.
*/

#pragma once


#ifndef _SphABSTranches_H__
#define _SphABSTranches_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/static_data/SphHistoricalData.h"


#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275) // Can not export a class derivated from a non exported one
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

#include __STL_INCLUDE_PATH(vector)

namespace sophis	{
	namespace instrument	
	{
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

class CSABSTranchesTab;
class CSRTrancheList;

namespace sophis	{
	namespace finance	{
		
		class SOPHIS_FIT CSRABSTranches {
		public:
			CSRABSTranches();
			virtual ~CSRABSTranches();
			CSRABSTranches(const CSRABSTranches& source);

			/**
			*	"virtual copy constructor"
			*	@return : a copy of the object
			*/
			virtual CSRABSTranches*	Clone() const;

			void GetTrancheList(_STL::vector<long>& tList) const;
			void SetTrancheList(_STL::vector<long>& tList);
			
			void SortTrancheList();


			/***********
			*   SQL   *
			***********/

			/**
			*	Save the tranches data into the database
			*	@param sico : sicovam of the instrument which contains the tranches
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico);

			/**
			*	Load the tranches data from the database
			*	@param sico : sicovam of the instrument which contains these tranches
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico);


			/***********
			*   XML  *
			***********/

			/** Common method to describe tranches information for ABS Deals.
			* 
			* \param dataSet the destination DataSet.
			* \param field_name XML tag
			* \param comment optional comment for the grammar
			*/
			void DescribeABSTranches(	sophis::tools::dataModel::DataSet&		data_set, 
										const char*								field_name,
										const char*								comment);

			/** Common method to fill tranches information from a dataset.
			* 
			* \param dataSet the source DataSet.
			* \param field_name XML tag
			*/
			void UpdateABSTranches (const sophis::tools::dataModel::DataSet& dataSet, 
									const char*								 field_name);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the tranches.
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the ABS bond
			*	@param newSico : sico of the archived ABS Bond
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRABSTranches *tranches );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRABSTranches *&tranches );

			/***************
			*   Friends   *
			***************/
			
			friend class CSABSTranchesTab;
			friend class CSRTrancheList;

		private:
			/*********************** 
			* Tranches Data *
			**********************/
			_STL::vector<long>	fTrancheList;

		};
	}
}

// For archives
extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRABSTranches * absTranches);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRABSTranches *& absTranches);

#endif //!_SphABSTranches_H__
