#pragma once

#ifndef __SphAdditionalComputation_H__
#define __SphAdditionalComputation_H__

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	class CSRComputationResults;
	namespace instrument
	{
		class CSRInstrument;
	}
	namespace market_data
	{
		class CSRMarketData;
	}

	namespace finance
	{
		class SOPHIS_FIT CSRAdditionalComputation
		{
		public:
			CSRAdditionalComputation();
			virtual ~CSRAdditionalComputation();

			void BeforeComputeAll(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;
			void AfterComputeAll(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;

			// Always called last, even in case of failure
			void CleanUp(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;

			static const CSRAdditionalComputation* GetAdditionalComputationByPriority(const sophis::instrument::CSRInstrument& instr);

		protected:
			virtual void BeforeComputeAllCore(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;
			virtual void AfterComputeAllCore(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;
			virtual void CleanUpCore(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& md, sophis::CSRComputationResults& results) const;
		};
	}
}
SPH_EPILOG
#endif
