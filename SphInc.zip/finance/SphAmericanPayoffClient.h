//-------------------------------------------------------------------------------
/*!
     \file		SphAmericanPayoffClient.h
     \author	Louis Paulot, Calypso Herrera
     \date		23 January 2013
     \brief		Class for an American Payoff using American Monte Carlo 
				on the Client Side
*/
//-------------------------------------------------------------------------------

#ifndef __SPH_MONTE_CARLO_AMERICAN_PAYOFF_CLIENT_
#define __SPH_MONTE_CARLO_AMERICAN_PAYOFF_CLIENT_

#include "SphInc/finance/SphNewMonteCarlo.h"
#include "Sphinc/finance/SphAmericanPayoffServer.h"
#include "SphInc/finance/SphMonteCarloMultiUnderlying.h"

namespace sophis {
	namespace finance {

#ifndef GCC_XML
/************************************************************************/
/*	American Payoff Client                                              */
/************************************************************************/

class CSRAmericanPayoffClient : public MultiUnderlyingsClientPayoff
{

public:

	CSRAmericanPayoffClient();

	virtual ~CSRAmericanPayoffClient();

	Boolean	ValidInstrument(bool isInInitialisation) const;

	virtual bool IsAmerican() const;


	virtual void GetBlockSizeForRegression(	_STL::vector<int> & blockSize,
											_STL::vector<int> & baseFuncSize) const;

	virtual bool GetBoundary(	_STL::vector<_STL::vector<sophis::math::VectorD> >	const & coeff, 
								_STL::vector<sophis::math::VectorD>	& boundary) const;

	virtual void ProportionalBlocksCreation(int nbDatesPerBlock, int nbBaseFunctionsPerBlock) const;

	virtual void InitBlocks() const = 0; 

	virtual void Initialise(const instrument::CSRInstrument* instr) override;

	virtual void SetStaticDataFromPathGenerator(const CSRLocalPathGeneratorClient* pathGenerator);

	virtual void GetStaticData(sophis::tools::CSRArchive& archive) const;

protected:

	double								fStrike;
	double								fProp;

	_STL::vector<long>					fDates;
	mutable sophis::math::VectorD		fTimeToDate;

	mutable int							fNbUnderlyings;
	mutable int							fNbVolatilities;
	mutable int							fNbRegressionVariables; 
	mutable _STL::vector<int>			fBlockSize;
	mutable _STL::vector<int>			fBaseFuncSize;

};
#endif // GCC_XML

	} // finance
} // sophis

#endif