//-------------------------------------------------------------------------------
/*!
     \file		SphAmericanPayoffServer.h
     \author	Louis Paulot, Calypso Herrera
     \date		23 January 2013
     \brief		Class of American Payoff using American Monte Carlo in the Server Side
*/
//-------------------------------------------------------------------------------

#ifndef __SPH_MONTE_CARLO_AMERICAN_PAYOFF_SERVER_H_
#define __SPH_MONTE_CARLO_AMERICAN_PAYOFF_SERVER_H_

#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/finance/SphMonteCarloMultiUnderlyingServer.h"


namespace sophis {
	namespace finance {

#ifndef GCC_XML
/************************************************************************/
/*	American payoff Server                                              */
/************************************************************************/

class SOPHIS_MONTECARLO_SERVER CSRAmericanPayoffServer :  public MultiUnderlyingsServerPayoff
{	
public :
		
	CSRAmericanPayoffServer();
	virtual ~CSRAmericanPayoffServer();

	
	/** Compute the option pay-off associated with the underlying path and fill a temporary buffer in the CSRServerOutput object.
	* @param path is an input parameter corresponding to the underlying paths that are used to compute pay-off.
	* @param output is an output parameter corresponding to a buffer object in which we write the results of a pay-off computation.
	*/
	virtual void	GetPayOffForOnePath(	const CSRLocalPath	*path, 
											int					nthAntitheticSampling, 
											CSRServerOutput		*serverOutput) const;

	/** Fill the Market Path vector (Time, Underlyings and eventually volatilities).
	* It corresponds to the regression variables.
	* @param path is an input parameter corresponding to the underlying paths that are used to compute pay-off.
	* @param pathGenerator is an input parameter corresponding to the underlying generated path.
	* @param nthAntitheticSampling is the number ID for the antithetic sampling.
	*/
	virtual void	FillMarketPath(	const CSRLocalPath					*path, 
									const CSRLocalPathGeneratorServer	&pathGenerator,
									int									nthAntitheticSampling) const;


	/** Get The information needed from the payoff server for the CSRRegression
	*/
	virtual void	GetDataForRegression(	int										& nbRegressionVariables,
											_STL::vector<int>						& blockSize,
											_STL::vector<int>						& baseFuncSize,
											_STL::shared_ptr<CSRRegressionFunction>	& regressionFunction) const;
	/**Get the Static Data
	*/
	virtual void	SetStaticData(const sophis::tools::CSRArchive& archive, const CSRLocalPathGeneratorServer* pgs) override;

	/** Set the boundary of the trajectory for all tasks and all blocks
	*/
	void			SetBoundary(_STL::vector<sophis::math::VectorD> const & boundary) const;

	/** The payoff of a mono-underlying product
	*/
	virtual double	Payoff(int const iDate) const = 0;

	/** Set the Regression function. The base functions used in the regression.
	*/
	virtual void	InitRegressionFunction() const = 0;

	/** Weight function
	*/
	virtual double	WeightForPath(	double const	exerciseValue, 
									int const		iBlock, 
									int	const		iDate) const;;


protected:
	virtual void	Init(CSRServerOutput *serverOutput) const;
	/// The different Vectors of the American Strategy
	/// The inputs from American Payoff Client
	
	double												fStrike;
	double												fProp;
	
	mutable int											fNbDates;
	mutable _STL::vector<long>							fDates;
	mutable sophis::math::VectorD						fTimeToDate;	

	mutable int											fNbUnderlyings;
	mutable int											fNbVolatilities;
	mutable int											fNbRegressionVariables; 
	
	mutable int											fNbBlocks;
	mutable _STL::vector<int>							fBlockSize;
	mutable _STL::vector<int>							fBaseFuncSize;
	mutable _STL::shared_ptr<CSRRegressionFunction>		fRegressionFunction;
	mutable _STL::map<int,int>							fBlockIndex;

	mutable int											fIteration;
	mutable int											fCurrentTask;
	mutable bool										fCheckExercice;
	mutable bool										fInitialized;	
	
	mutable _STL::vector<sophis::math::VectorD>			fMarketPath; 	
	mutable sophis::math::VectorD						fContinuationValues;
	mutable _STL::vector<sophis::math::VectorD>			fBoundary;
	mutable	sophis::math::VectorD						fWeightForPath;	

	mutable sophis::math::VectorD						fPresentValues;
};

#endif // GCC_XML
	} //math
} // finance

#endif