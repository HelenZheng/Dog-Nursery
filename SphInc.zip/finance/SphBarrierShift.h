/*
 	File:		SphBarrierShift.h

 	Contains:	Classes for the handling of the shift of barrier options.

 	Copyright:	� 1995-2012 Sophis.

*/

/*! \file SphBarrierShift.h
	\brief Handling of the shift of barrier options.
*/

#ifndef _SphBarrierShift_H_
#define _SphBarrierShift_H_



#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning (push)
#	pragma warning(disable:4290)
#endif
#include "SphTools/SphPrototype.h"
#if (defined(WIN32)||defined(_WIN64))
#	pragma warning (pop)
#endif


#define DECLARATION_BARRIER_SHIFT_METHOD(derivedClass)							\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRBarrierShiftMethod)	\
	public: derivedClass();

#define CONSTRUCTOR_BARRIER_SHIFT_METHOD(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_BARRIER_SHIFT_METHOD(derivedClass)
#define	INITIALISE_BARRIER_SHIFT_METHOD(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)


#define DECLARATION_BARRIER_SHIFT_TIME_BUCKET(derivedClass)							\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRBarrierShiftTimeBucket)	\
	public: derivedClass();

#define CONSTRUCTOR_BARRIER_SHIFT_TIME_BUCKET(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_BARRIER_SHIFT_TIME_BUCKET(derivedClass)
#define	INITIALISE_BARRIER_SHIFT_TIME_BUCKET(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)


#if (defined(WIN32)||defined(_WIN64))
#	pragma warning (push)
#	pragma warning(disable:4251)
#	pragma warning(disable:4275)
#	pragma warning(disable:4786)
#	pragma warning (disable : 4103)
#endif

#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/instrument/SphClause.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

namespace sophis {

	namespace instrument
	{
		class CSROption;
		struct SSClause;
	};

	namespace market_data
	{
		class CSRMarketData;
	}

	namespace finance {

		/**
		Shift method for barrier options.
		@version 6.3.2.2
		*/
		class SOPHIS_FIT CSRBarrierShiftMethod
		{
		public:
			/**
			Public constructor.
			*/
			CSRBarrierShiftMethod();

			/**
			Virtual destructor.
			*/
			virtual ~CSRBarrierShiftMethod();

			/**
			Gets the parameters used for the shift method.
			The parameters are used for display in the Barrier Shift Configuration window.
			@return The parameters used for the shift method.
			*/
			virtual _STL::string GetParameters() const = 0;

			/**
			Sets the parameters used for the shift method.
			The parameters can be provided by the display in the Barrier Shift Configuration window.
			You can overload this method to parse the parameters of your shift method.
			@param the parameters to set.
			*/
			virtual void SetParameters(const _STL::string& parameters) = 0;

			/**
			Gets the name of the shift method.
			@return
			*/
			virtual _STL::string GetName() const = 0 ;

			/**
			Validates the parameters of the method.
			@remark This method is used by the GUI to validate the parameters the user set.
			@param the parameters as it is stored in the database.
			@param errorMessage the error message which can be logged or displayed by GUI if the input parameters are not set correctly.
			@return true if the parameters are correctly set. Otherwise, false.
			*/
			virtual bool Validate(const _STL::string& parameters, _STL::string& errorMessage) const = 0;

			/**
			Do the shift of the barrier or of the clause.
			@param pClause the clause which needs to be shifted.
			@param pOption the option used for the shift of the clauses or the barriers.
			@param pMD the market data used for the current shift.
			*/
			virtual void Shift(sophis::instrument::SSClause* pClause,const sophis::instrument::CSROption* pOption,const sophis::market_data::CSRMarketData* pMD) const = 0;


			/**
			Clones the barrier shift method.
			@remark this method is used for prototype but also in the GUI to use temporary shift method.
			@return a cloned barrier method.
			*/
			virtual CSRBarrierShiftMethod* Clone() const = 0;

			/** 
			Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRBarrierShiftMethod, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_BARRIER_SHIFT_METHOD.
			With the .net toolkit, in C#, please use CSMBarrierShiftMethod.Register(method.GetName(), method).
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();
		};

		/**
		Time bucket used for shifting barriers in barrier options.
		@version 6.3.2.2
		*/
		class SOPHIS_FIT CSRBarrierShiftTimeBucket
		{
		public:
			/**
			Public constructor
			*/
			CSRBarrierShiftTimeBucket();

			/**
			Virtual destructor
			*/
			virtual ~CSRBarrierShiftTimeBucket();
			
			/**
			Gets the time bucket name. The name is displayed in the list of the bucket name. 
			For example it can be "<1m", "After six months", "Around the 14th of July", ...
			*/
			virtual _STL::string GetName() const = 0;

			/**
			Sets the time bucket name. The name is displayed in the list of the bucket name. 
			For example it can be "<1m", "After six months", "Around the 14th of July", ...
			*/
			virtual void SetName(const _STL::string& name) const = 0;

			/**
			Gets the time bucket data.
			@remark the data is stored in database.
			*/
			virtual _STL::string GetData() const = 0;
			
			/**
			Sets the time bucket data.
			@remark the data is stored in database.
			*/
			virtual void SetData(const _STL::string& data) = 0;

			/** 
			Gets the type name of the time bucket. This type name is in the combobox of the time bucket edit window.
			For example, it can be "Sophis standard time bucket", ...
			*/
			virtual _STL::string GetType() const = 0;
			
			/** 
			Sets the type name of the time bucket. This type name is in the combobox of the time bucket edit window.
			*/
			virtual void SetType(const _STL::string& data) = 0;
	        
			/**
			Clones the time bucket instance.
			@remark it's used for the prototype and for the GUI while editing the time bucket.
			@return a cloned time bucket instance.
			*/
			virtual CSRBarrierShiftTimeBucket* Clone() const = 0;

			/**
			Validates the parameters of the time bucket.
			@remark it's by the GUI while editing the time bucket.
			@param errorMessage the error message which is displayed or logged if the validation fails.
			@return true if the validation is sucessful. Otherwise, false.
			*/
			virtual bool ValidateData(_STL::string& errorMessage) const = 0;

			/*
			Check if the current day matches with the time bucket definition.
			For example, in a barrier option, the barrier cross date is set to 2012/08/15. 
			A time bucket defines the shift of the barrier must be done between 6m and 1y. That means between 2011/08/15 and 2012/02/15. 
			If the currentDay matches with the time bucket, the barrier can be shifted.
			@param currentDay the day uses to check if the clause or barrier must be shifted or not.
			@return true if the day matches. Otherwise, false.
			*/
			virtual bool Match(long currentDay) const = 0;

			//
			// FOR INTERNAL SOPHIS' USE
			//
			void SetId(long id);
			long GetId();

			/** 
			Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRBarrierShiftTimeBucket, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_BARRIER_SHIFT_TIME_BUCKET.
			With the .net toolkit, in C#, please use CSMBarrierShiftTimeBucket.Register(tb.GetName(), tb).
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

		private:
			long fId;
		};

		/**
		FOR INTERNAL SOPHIS' USE
		Generates the shifted barrier
		*/
		class SOPHIS_FIT CSRBarrierShiftGenerator
		{
		private:
			CSRBarrierShiftGenerator();
			static CSRBarrierShiftGenerator* fInstance;
		
		public:
			static CSRBarrierShiftGenerator* GetInstance();
			void ShiftBarriers(sophis::instrument::CSRInstrument* instrument);
			_STL::list<sophis::instrument::SSClause> CSRBarrierShiftGenerator::ShiftBarriers(sophis::instrument::CSRInstrument* instrument, const _STL::list<sophis::instrument::SSClause>& selectedBarriers);
		};


	}
}

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(pop)
#endif

#endif
