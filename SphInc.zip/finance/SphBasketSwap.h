/*! \file SphBasketSwap.h
\brief Class for the handling of a basket swap (which is a swap having the 'Basket Swap' model).
*/

#pragma once

#ifndef _SphBasketSwap_H_
#define _SphBasketSwap_H_

#include "SphInc/SphMacros.h"

#include "SphInc/instrument/SphSwapExplanation.h"
#include "SphInc/instrument/SphSwapEnums.h"
#include "SphInc/instrument/SphSwap.h"
#include "SphInc/instrument/SphEquity.h"
#include "SphInc/portfolio/SphTransactionEnums.h"
#include "SphInc/static_data/SphDayCountBasis.h"
#include "SphInc/static_data/SphYieldCalculation.h"
#include "SphInc/instrument/SphForexSpot.h"
#include "SphInc/instrument/SphSwapExtraFunding.h"
#include "SphInc/finance/SphDefaultMetaModelBasketSwap.h"
#include "SphTools/SphDay.h"
#include "SphInc/finance/SphBasketSwapIO.h"

#include "SphTools/SphPrototype.h"
#include "SphSDBCInc/SphSQLQueryBase.h"

/**
	STL includes
*/
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(utility)

#ifndef GCC_XML
BOOST_INCLUDE_BEGIN
	#include BOOST_INCLUDE_PATH(unordered_map.hpp)
BOOST_INCLUDE_END
#endif

#define EPSILON_BASKET_SWAP_SPREAD	1e-11

class CSRFixingListComputation;	// INTERNAL.
class CSRBasketSwapSpecialReporting; // INTERNAL
struct flux_jambe; //INTERNAL
class CSRBasketSwapManager;

SPH_PROLOG

/**
 * For registering CSRBasketSwap derived implementation.
 * @version 7.1.1
 */
#define	INITIALISE_BASKET_SWAP(derivedClass,name)\
	INITIALISE_SWAP(derivedClass,name)\
	sophis::finance::CSRBasketSwap::GetBasketSwapModels().insert(_STL::string(name));

/** Reporting Method Prototype
 * @version 5.3.7
 */
#define DECLARATON_BASKETSWAP_REPORTINGMETHOD(derivedClass)                 DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRBasketSwapReportingMethod)
#define CONSTRUCTOR_BASKETSWAP_REPORTINGMETHOD(derivedClass)
#define WITHOUT_CONSTRUCTOR_BASKETSWAP_REPORTINGMETHOD(derivedClass)
/**
 * Macro to be placed in the clients <main>.cpp to register derived client classes with the prototype framework.
 * @param derivedClass is the name of the client derived class.
 * @param name is the unique string to be used as a key to identify registered class in the framework.
 * @version 5.3.7
 */
#define INITIALISE_BASKETSWAP_REPORTINGMETHOD(derivedClass, name)   INITIALISE_PROTOTYPE(derivedClass, name)

namespace sophis
{
	namespace gui
	{
		class CSRFitDialog;
	}

	namespace static_data
	{
		class CSRInterestRate;
		class CSRDayCountBasis;
		class CSRYieldCalculation;
		class CSRCalendar;
		struct SSDayCountCalculation;
		struct SSCouponCalculation;
	}

	namespace market_data
	{
		class CSRMarketData;
	}

	namespace tools
	{
		namespace dataModel
		{
			class DataSet;
		}
	}

	namespace misc
	{
		class CSREvent;
	}

	namespace finance
	{
		class CSRBasketSwap;
		class BasketComponentsCache;
		class CSRMultiCurrencyBasket;	// INTERNAL
		struct MSpreadAdjustmentHistory;
		struct DetailledCalculationMap;
		class CSRDefaultMetaModelBasketSwap;
		class CSRBasketAdjustmentDataLineData;
		struct BasketAdjustmentDataLineData;

		/**
		 * Enumeration for levels in the basket adjustment history hieararchy.
		 * @version 7.1.2
		 */
		enum eBasketSwapAdjustmentHistoryHierLevel
		{
			eBasketSwapAdjustmentHistoryHierLevel_DateGroup = 1,
			eBasketSwapAdjustmentHistoryHierLevel_Adjustment,
			eBasketSwapAdjustmentHistoryHierLevel_Explanation
		};

		/** Interface calculation used in MSpreadAdjustmentHistory.
		@since 5.3.4
		*/
		struct	ICalculation
		{
			virtual double	GetCalcul(long start_date,
									  long end_date,
									  double spread,
									  const ISRBasketSwapIO& io,
									  BasketComponentsCache& compCache,
									  instrument::CSRCashFlowInformation *explanation=0,
									  const static_data::SSCouponCalculation *ccData=0) = 0;
		};

		/** Interface calculation used in MSpreadAdjustmentHistory.
		@since 5.3.7
		*/
		struct ISwapFlowManagement
		{
			virtual bool FindCurrentRateFlow(int &scan_flux_taux, const flux_jambe * &fluxPtrTaux, long startDate, long endDate, long currentDate) const = 0;
			virtual bool FindNextCurrentRateFlow(int &scan_flux_taux, const flux_jambe * &fluxPtrTaux, long startDate, long endDate, long currentDate) const = 0;
			virtual bool FindCurrentEquityFlow(int &scan_flux, const flux_jambe * &fluxPtr, long startDate, long endDate, long currentDate) const = 0;
			virtual bool FindNextCurrentEquityFlow(int &scan_flux, const flux_jambe * &fluxPtr, long startDate, long endDate, long currentDate) const = 0;
			virtual bool FindCurrentDividendFlow(int &scan_flux, const flux_jambe * &fluxPtr, bool &onTheFly, long startDate, long endDate, long currentDate, long *tradeDate = 0, long *settlementDate = 0) const = 0;
			virtual bool FindNextCurrentDividendFlow(int &scan_flux, const flux_jambe * &fluxPtr, bool &onTheFly, long startDate, long endDate, long currentDate, long *tradeDate = 0, long *settlementDate = 0) const = 0;
		};

		struct SOPHIS_FINANCE SpreadFloating
		{
			SpreadFloating();
			double fSpread;
			double fFloating;

			SpreadFloating& operator+=(const SpreadFloating& rhs);
			/** Write a SpreadFloating into a CSRArchive.
				Overload of the "<<" operator version.
			*/
			friend sophis::tools::CSRArchive& operator << ( sophis::tools::CSRArchive& ar, const sophis::finance::SpreadFloating & results );

			/** Read a SpreadFloating from a CSRArchive.
				Overload of the ">>" operator version.
			*/
			friend const sophis::tools::CSRArchive& operator >> ( const sophis::tools::CSRArchive& ar, sophis::finance::SpreadFloating & results);
		};

		struct SOPHIS_FINANCE SpreadResetEnum
		{
			enum Enum
			{
				error = -1 // to avoid error
				, eUndefined = 0
				, eNone
				, eBorrow
				, eFunding
				, eBoth
				, size = 5 //just to declare the size;
			};

			const static std::string Text[size];

			static std::string TextOf(Enum field);
			static Enum EnumOf(std::string text);
		};

		struct SOPHIS_FINANCE SpreadHelper
		{
			/**
			return true; only if type as:
						, eBorrow
						, eFunding
						, eBoth
			**/
			static bool IsReset(const long e);

#ifndef GCC_XML
			/**
			* lazy execute
			* return if any function executed.
			**/
			static bool ExecuteByResetType(const long type, std::function<void()> fnBorrow, std::function<void()> fnFunding);
#endif
		};

		struct SOPHIS_FINANCE LongShortDouble
		{
			LongShortDouble();
			double fLong;
			double fShort;
			double& operator()(bool isLong);

			LongShortDouble& operator+=(const LongShortDouble& rhs);
						/** Write a LongShortDouble into a CSRArchive.
			Overload of the "<<" operator version.
			*/
			friend sophis::tools::CSRArchive& operator << ( sophis::tools::CSRArchive& ar, const sophis::finance::LongShortDouble & results );

			/** Read a LongShortDouble from a CSRArchive.
			Overload of the ">>" operator version.
			*/
			friend const sophis::tools::CSRArchive& operator >> ( const sophis::tools::CSRArchive& ar, sophis::finance::LongShortDouble & results);

		};

		struct SOPHIS_FINANCE LongShortSpreadFloating
		{
			SpreadFloating fLong;
			SpreadFloating fShort;
			SpreadFloating& operator()(bool isLong);
			LongShortSpreadFloating& operator+=(const LongShortSpreadFloating& rhs);
			/** Write a LongShortSpreadFloating into a CSRArchive.
				Overload of the "<<" operator version.
			*/
			friend sophis::tools::CSRArchive& operator << ( sophis::tools::CSRArchive& ar, const sophis::finance::LongShortSpreadFloating & results );

			/** Read a LongShortSpreadFloating from a CSRArchive.
				Overload of the ">>" operator version.
			*/
			friend const sophis::tools::CSRArchive& operator >> ( const sophis::tools::CSRArchive& ar, sophis::finance::LongShortSpreadFloating & results);
		};


		/**
		Class that contains the data of a basket adjustment.
		@version 5.3.4
		*/
		class SOPHIS_FINANCE BasketAdjustmentData
		{
		public:
			/**
				Default constructor.
				@version 5.3
			*/
			BasketAdjustmentData();

			/**
			Method that tell if the adjusment is generated or user entry. It does not check for accrued adjustment.
			@version 5.3.7
			*/
			bool IsGeneratedAdj() const;

			/**
			The internal code of the previous basket components set during the adjustment.
			@version 5.3
			*/
			long fOldBasketComponentsID;

			/**
			The internal code of the new basket components set during the adjustment.
			@version 5.3
			*/
			long fNewBasketComponentsID;

			/**
			The date of the adjustment.
			@version 5.3
			*/
			long fModificationDate;

			/**
			The value date of the adjustment.
			@version 5.3
			*/
			long fValueDate;

			/**
			The type of accrued payment.
			@see {@link sophis::instrument::eAccruedPaymentType}
			@version 5.3
			*/
			int fPaymentType;

			/**
			The relative order on which this adjustment was made. Introduced to allow multiple
			adjustments on the same date
			@version 5.3.6
			*/
			int fOrder;

			/**
			The type of the adjustment.
			@version 5.3.6
			*/
			int fAdjustmentType;

			/**
			The Custom Rate used for Extra Funding.
			@version 6.2.1
			*/
			long fExtraFundingRate;

			/**
			The Fixing Value used for Extra Funding.
			@version 6.2.1
			*/
			double fExtraFundingFixingValue;

			/**
			Internal. This is filled by BuildAdjustmentsForPricing.
			@version 5.3.7
			*/
			const flux_jambe *fRateFlow;
			int fFlowID;
			bool fIsDividendDate;
			bool fIsTermination;

			/**
			The notional value used in basket creation using Forward Start.
			@version 5.3.7
			*/
			double fFwdNotional;

			/**
			The currency of the notional value used in basket creation using Forward Start.
			@version 5.3.7
			*/
			long fFwdNotionalCcy;

			/**
			The previous modification date of the adjustment, only applicable on  backdated adjustments.
			@version 7.1.3
			*/
			long fOldBackdatedModficationDate;

			/**
			The previous order of the adjustment, only applicable on backdated adjustments.
			@version 7.1.3
			*/
			int fOldBackdatedOrder;

			/**
			The global spread applied to the adjustment.
			@version 7.1.3
			*/
			//double fSpread; // DEPRECATED

			/**
			Spread adjustment type. 0 for global adjustment
			@version 7.1.3
			*/
			long fSpread_adj_type;

			/**
			Spread endd application date. Should rely on spread_adj_type choice.
			@version 7.1.3
			*/
			long fSpreadEndDate;

			/**
			Upfront Fees related to the adjustment.
			@version 7.1.3
			*/
			double fUpfrontFees;


			bool	fIsResetDate;

			bool fEarlyTermination;

			long fCorporateActionID;
		};

		/** Structure used for line picking.
		* key is component instrument id + decrease adjustment id
		* value is a map of adjustment ids and quantities
		@version 5.3.7
		*/
		typedef _STL::map<long /*adjustment*/, double /*quantity*/> LinePickingData;
		typedef _STL::map<_STL::pair<long /*sicovam*/, long /*adj*/>, LinePickingData> LinePickingMap;
		typedef _STL::map<long /*sicovam*/, LinePickingData> LinePickingMapNoAdj;

		//forward declaration

		struct SOPHIS_FINANCE CashFundingList
		{
		public:
			CashFundingList();
			~CashFundingList();

			struct ExplanationDataCF
			{
				long	negotiationDate;
				long	originalNegotiationDate;
				int		order;
				long	startRatePeriod;
				long	endRatePeriod;
				long	paymentDate;
				double	amount;
				double	spreadPart;
				double	spread;
				double	notional;
				double	globalNotional;
				int		dayCount;
				double	fixing;
				long	fixindDate;
				double fundingSpreadPart;
				double borrowingSpreadPart;
				double realizedUnpaidInterest;
			};
			typedef _STL::list< ExplanationDataCF > ExtraFundingExplanation;
			typedef _STL::map<long,CashFundingList::ExtraFundingExplanation> ExtraFundingExplanationPerComponent;

			/** Function to add notional to fund.
			@param notional is the added notional to fund.
			@param adjData is the current basket adjustment.
			@param brokenFlow is false if for funding computation the rate period should not be considered as broken
			@param interestRateCode is the rate code to use for next funding period.
			@param rateFixing is the interest rate fixing if known or manually set.
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@version 6.2.1
			*/
			virtual void AddNotional(	double	notional,
								const BasketAdjustmentData &adjData,
								bool	brokenFlow,
								long	interestRateCode,
								double	rateFixing,
								bool useLegRate);

			/** Function that stops the funding for all notional starting before valueDate.
			@param adjData is the current basket adjustment.
			@version 6.2.1
			*/
			virtual void StopFunding(const BasketAdjustmentData &adjData);

			/** Function that compute the global notional to fund.
			@return the notional to fund.
			@version 6.2.1
			*/
			virtual double GetGlobalNotionalToFund(long	valueDate) const;

			/** Function that check if there is any notional to fund.
			@return true if there no notional to fund.
			@version 6.2.1
			*/
			virtual bool IsEmpty() const;

			/** Function that clean the funding notional.
			@version 6.2.1
			*/
			virtual void Clean();

			/** Function that add the funding notional of an other cash funding list for payment management and computation.
			@param source is the funding list to merge.
			@version 6.2.1
			*/
			virtual void Merge(const CashFundingList &source);

			/** Function that reset the start financing date.
			@param adjData is the current basket adjustment.
			@param interestRateCode is the rate code to use for next funding period.
			@param rateFixing is the interest rate fixing if known or manually set.
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@version 6.2.1
			*/
			virtual void ResetStartRemunaratingDate(const BasketAdjustmentData &adjData, double interestRateCode, double rateFixing, bool useLegRate);

			/** Function that compute the accrued financing.
			@param value is the end date for funding.
			@param spreadMap is the spread list to use for remuneration with rate leg.
			@param spreadLong is the spread for long notional. Set only for custom rate funding.
			@param spreadShort is the spread for short notional. Set only for custom rate funding.
			@param spreadComputation is the computation interface for the spread part or fixed rate leg.
			@param floatingComputation is the computation interface for the floating part to use when remunaration is based on rate leg.
			@param floatingComputationCustom is the computation interface for the floating part when using custom rate.
			@param spreadPart is the computation output for the spread part.
			@param floatingPart is the computation output for the floating part.
			@param globalNotionalInfo is the notional information for the whole basket. It is usefull to get the spread when netting notionals.
			@version 6.2.1
			*/
			virtual void ComputeAccrued(long									valueDate,
										const MSpreadAdjustmentHistory			&spreadMap,
										double									spreadLong,
										double									spreadShort,
										ICalculation							&spreadComputation,
										ICalculation							&floatingComputation,
										ICalculation							&floatingComputationCustom,
										double									&spreadPart,
										double									&floatingPart,
										const CashFundingList					&globalNotionalInfo,
										const ISRBasketSwapIO& io,
										BasketComponentsCache& compCache) const;

			/** Function that compute the financing amount
			@param value is the end date for funding.
			@param context is the computation context.
			@param spreadMap is the spread list to use for remuneration with rate leg.
			@param spreadLong is the spread for long notional. Set only for custom rate funding.
			@param spreadShort is the spread for short notional. Set only for custom rate funding.
			@param spreadComputation is the computation interface for the spread part or fixed rate leg.
			@param floatingComputation is the computation interface for the floating part to use when remunaration is based on rate leg.
			@param floatingComputationCustom is the computation interface for the floating part when using custom rate.
			@param spreadPart is the computation output for the spread part.
			@param floatingPart is the computation output for the floating part.
			@param globalNotionalInfo is the notional information for the whole basket. It is usefull to get the spread when netting notionals.
			@param explanationList is the output for interest computation explanation.
			@param extraFundingExp is an optional parameter for details extra funding explanation.
			@version 6.2.1
			*/
			virtual void ComputeFunding(long									valueDate,
										const market_data::CSRMarketData		&context,
										const MSpreadAdjustmentHistory			&spreadMap,
										double									spreadLong,
										double									spreadShort,
										ICalculation							&spreadComputation,
										ICalculation							&floatingComputation,
										ICalculation							&floatingComputationCustom,
										double									&spreadPart,
										double									&floatingPart,
										const CashFundingList					&globalNotionalInfo,
										const ISRBasketSwapIO& io,
										BasketComponentsCache& compCache,
										instrument::CSRCashFlowInformationList	*explanationList = 0,
										ExtraFundingExplanation					*extraFundingExp = 0) const;

		protected:
			struct ComplexCase
			{
				long	negotiationDate;
				long	valueDate;
				long	refValueDateForFixing;
				long	interestRateCode;
				double	notional;
				double	rateFixing;
				bool	brokenFlow;
				long	originalNegotiationDate;
				int		order;
				bool	useLegRate;
			};

			_STL::map<long,_STL::list<ComplexCase> > fNotDataListPerRate;
			_STL::map<long,_STL::map<long,_STL::list<ComplexCase> > > fNotDataListPerRatePerStoppingDate;

			/** Function that compute the the accrued or full interest amount to be paid.
			@param value is the end date for funding.
			@param context is the computation context.
			@param spreadMap is the spread list to use for remuneration with rate leg.
			@param spreadLong is the spread for long notional. Set only for custom rate funding.
			@param spreadShort is the spread for short notional. Set only for custom rate funding.
			@param spreadComputation is the computation interface for the spread part or fixed rate leg.
			@param floatingComputation is the computation interface for the floating part to use when remunaration is based on rate leg.
			@param floatingComputationCustom is the computation interface for the floating part when using custom rate.
			@param spreadPart is the computation output for the spread part.
			@param floatingPart is the computation output for the floating part.
			@param globalNotionalInfo is the notional information for the whole basket. It is usefull to get the spread when netting notionals.
			@param explanationList is the output for interest computation explanation.
			@param isAccruedComputation tells if we are computing an accrued interest or a full interest
			@param extraFundingExp is an optional parameter for details extra funding explanation.
			@version 6.2.1
			*/
			virtual void PayFundingInternal(long									valueDate,
									const market_data::CSRMarketData		&context,
									const MSpreadAdjustmentHistory			&spreadMap,
									double									spreadLong,
									double									spreadShort,
									ICalculation							&spreadComputation,
									ICalculation							&floatingComputation,
									ICalculation							&floatingComputationCustom,
									double									&spreadPart,
									double									&floatingPart,
									const CashFundingList					&globalNotionalInfo,
									instrument::CSRCashFlowInformationList	*explanationList,
									bool									isAccruedComputation,
											ExtraFundingExplanation					*extraFundingExp,
											const ISRBasketSwapIO& io,
											BasketComponentsCache& compCache) const;

			/** internal use
			@since 5.3.7
			*/
			static void PayFundingInternal(	const _STL::map<long,_STL::list<ComplexCase> > &notionalData,
											long									untilDate,
											long									payDate,
											const market_data::CSRMarketData		&context,
											const MSpreadAdjustmentHistory			&spreadMap,
											double									spreadLong,
											double									spreadShort,
											ICalculation							&spreadComputation,
											ICalculation							&floatingComputation,
											ICalculation							&floatingComputationCustom,
											double									&spreadPart,
											double									&floatingPart,
											const _STL::map<long,_STL::list<ComplexCase> >	&globalNotionalInfo,
											instrument::CSRCashFlowInformationList	*explanationList,
											bool									isAccruedComputation,
											ExtraFundingExplanation					*extraFundingExp,
											const ISRBasketSwapIO& io,
											BasketComponentsCache& compCache);
			static void ResetStartRemunaratingDateInternal(_STL::map<long,_STL::list<ComplexCase> > &data, const BasketAdjustmentData &adjData, double interestRateCode, double rateFixing, bool useLegRate);
			static double GetNotionalInternal(const _STL::map<long,_STL::list<ComplexCase> > &data, long valueDate);
			static void MergeInternal(_STL::map<long,_STL::list<ComplexCase> > &data1,const _STL::map<long,_STL::list<ComplexCase> > &data2);
			static bool Compare(const ComplexCase& data1, const ComplexCase& data2);
		};

		/**
		Structure that manages the increase decrease of a component in basket adjustments.
		@version 5.3.6
		*/
		struct SOPHIS_FINANCE IncreaseDecreseForReporting
		{
			/**
			Default constructor.
			@version 5.3.6
			*/
			IncreaseDecreseForReporting();

			struct SOPHIS_FINANCE ExplanationData
			{
				ExplanationData();
				double	quantity;
				double	diffQuantity;
				double	forex;
				double	forexForPerf;
				double	fixing;
				double	adjFixing;
				double	spread;
				double  fundingSpread;
				double	performance;
				double	performenceFromDecreaseOnly;
				long	negotiationDate;
				long	settlementDate;
				sophis::finance::SpreadResetEnum::Enum 	spreadReset;
				int		divEligibility;
				double	divRebateRatio;
				long	originalNegotiationDate;
				int		order;
				double	accrued;
				long	adjustment;
			};
			typedef _STL::list< ExplanationData > PerfExplanation;

			/** Function called to increase the quantity of one component in a basket adjustment
			@param adjData is the current basket adjustment.
			@param quantity is the quantity to increase.
			@param compoFixing is the fixing of the component expressed in the swap currency for the increase.
			@param compoFixingForPerf is the adjusted fixing of the component expressed in the swap currency for the increase.
			@param forex is the FX spot to consider for this component and this adjustment.
			@param spread reset change change type using SpreadResetEnum @version 7.1.3
		    @param spread is the spread for financing to apply on the whole component or to the added notional depending on isSpreadResetted.
			@param fundingSpread add in 7.1.3
			@param divEligibility is the dividend payment strategy (Standard, Special Ex, Special Cum).
			@param divRebateRatio is the dividend rebate ratio defined per component.
			@param accrued is the accrued coupon if the fixing is in clean price.
			@param isDailyMarginCall if true component has margin calls and data for daily margin calculation must be filled.
			@see ComponentDetails::ChangeComposition
			@version 5.3.6
			*/
			void IncreaseComponent(	const BasketAdjustmentData &adjData,
									double	quantity,
									double	compoFixing,
									double	compoFixingForPerf,
									double	forex,
									sophis::finance::SpreadResetEnum::Enum	spreadReset,
									double	spread,
									double  fundingSpread,
									int		divEligibility,
									double	divRebateRatio,
									double	accrued,
									bool	isDailyMarginCall);

			/** Function called to decrease the quantity of one component in a basket adjustment
			@param adjData is the current basket adjustment.
			@param quantity is the quantity to decrease.
			@param compoFixing is the fixing of the component expressed in the swap currency for the decrease.
			@param compoFixingForPerf is the adjusted fixing of the component expressed in the swap currency for the decrease.
			@param accruedValue is the value of the accrued of the component expressed in the swap currency for the decrease.
			@param redeemedNotionalFundingToBePaid is a boolean to say if the redeemed notional is to be paid now or not.
			@param averagePriceType is the reporting mode (@see CSRBasketSwap::eTRSReportingMethod).
			@param realizedPerf is the performance flow generated by the decrease.
			@param perfExpl is a list of pair date (long) and performance (double) defining the performance changes in time. Modified inside.
			@param accruedPerf is the performance on the accrued by the decrease.
			@param onlyManageQty if true, this function only manages the quantities.
			@param sicovamComponent identifier of the component in order to convert prices to correct quotation type.
			@param isDailyMarginCall if true component has margin calls and data for daily margin calculation must be filled.
			@param basketSwapCode internal code of the Basket Swap instrument.
			@param linePicking line picking information if any
			@see ComponentDetails::ChangeComposition
			@version 5.3.6
			*/
			void DecreaseComponent(	const BasketAdjustmentData &adjData,
									double	quantity,
									double	compoFixing,
									double	compoFixingForPerf,
									double	accruedValue,
									bool	redeemedNotionalFundingToBePaid,
									short	averagePriceType,
									double	&realizedPerf,
									PerfExplanation *perfExpl,
									double	&accruedPerf,
									bool	onlyManageQty=false,
									const sophis::instrument::CSRInstrument* instrument = 0,
									bool	isDailyMarginCall = false,
									long	basketSwapCode = 0,
									bool	hasLinePicking = false,
									const LinePickingData & linePicking = LinePickingData());

			/** Function called to perform split of one component in a basket adjustment
			@param adjData is the current basket adjustment.
			@param splitFactor is the split factor.
			@param isFreeAttribution true if free recieved free shares
			@see ComponentDetails::ChangeComposition
			@version 7.1.0
			*/
			void SplitComponant(	const BasketAdjustmentData &adjData,
									double	splitFactor,
									bool isFreeAttribution);

			/** Function called to set some performance that will be paid at next reset (syntetic or not) (used for no accrual adjustment)
			@param adjData is the current basket adjustment.
			@param amount is the realized not paid amount.
			@param interestRateCode is the interest rate code to use for the remuneration of the notional.
			@param rateFixing is the rate fixing if known or manually set
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void AddRealizedUnpaid(const BasketAdjustmentData &adjData, double amount, long	interestRateCode, double	rateFixing, bool useLegRate);

			/** Function called to set some performance that will is paid in advance (performance paid in the midle of a rate period)
			@param adjData is the current basket adjustment.
			@param amount is the realized paid amount.
			@param interestRateCode is the interest rate code to use for the remuneration of the notional.
			@param rateFixing is the rate fixing if known or manually set
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void AddRealizedPaidInAdvance(const BasketAdjustmentData &adjData, double amount, long	interestRateCode, double	rateFixing, bool useLegRate);

			/** Function called to stop the current funding of the realized not paid. It is called when the perf not paid is paid.
			@param adjData is the current basket adjustment.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void StopFundingRealizedUnpaid(const BasketAdjustmentData &adjData);

			/** Function called to stop the current funding of the realized not paid. It is called when the perf not paid is paid.
			@param adjData is the current basket adjustment.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void StopFundingRealizedPaidInAdvance(const BasketAdjustmentData &adjData);

			/** Function called to set the funding of performance paid in advance to be paid
			@param keepRemunaratingAfter to tell if the funding of the notional should continue.
			@param adjData is the current basket adjustment.
			@param amount is the realized paid amount.
			@param interestRateCode is the interest rate code to use for the remuneration of the notional.
			@param rateFixing is the rate fixing if known or manually set
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void SetPaidInAdvanceFundingToBePaid(bool keepRemunaratingAfter, const BasketAdjustmentData &adjData, long	interestRateCode, double	rateFixing, bool useLegRate);

			/** Function called to set the funding of the unpaid performance to be paid
			@param keepRemunaratingAfter to tell if the funding of the notional should continue.
			@param adjData is the current basket adjustment.
			@param amount is the realized paid amount.
			@param interestRateCode is the interest rate code to use for the remuneration of the notional.
			@param rateFixing is the rate fixing if known or manually set
			@param useLegRate is to tell if extrq funding is bqsed on rqte leg or not.
			@see ComponentDetails::ChangeComposition
			@version 6.2.1
			*/
			void SetRealizedUnpaidFundingToBePaid(bool keepRemunaratingAfter, const BasketAdjustmentData &adjData, long	interestRateCode, double	rateFixing, bool useLegRate);

			/** Function called to reset only the fixings for performence in order to get after the good average spread. It is used in the future and for Resets.
			@param adjData is the current basket adjustment.
			@param compoFixing is the fixing of the component expressed in the swap currency for the reset.
			@param forex is the FX spot to consider for this component and this adjustment.
			@param realizedPerf the perf generated by the change of fixing.
			@param perfExpl is a list of pair date (long) and performance (double) defining the performance changes in time. Modified inside.
			@param accruedValue is the value of the accrued of the component expressed in the swap currency for the reset.
			@param accruedPerf is the performance generated by the change of accrued value.
			@param onlyExplain if set to true this method will only explain the perf that would be computed but does not compute it nor modify the deal (NecessaryData) list.
			@param sicovamComponent identifier of the component in order to convert prices to correct quotation type.
			@param isDailyMarginCall if true component has margin calls and data for daily margin calculation must be filled.
			@see ComponentDetails::ChangeComposition
			@version 5.3.7
			*/
			void ResetPerfFixing(	const BasketAdjustmentData &adjData,
									double	compoFixing,
									double	forex,
									double	&realizedPerf,
									PerfExplanation *perfExpl,
									double	accruedValue,
									double	&accruedPerf,
									sophis::finance::BasketComponentsCache& compCache,
									bool onlyExplain=false,
									const sophis::instrument::CSRInstrument* instrument = 0,
									bool	isDailyMarginCall = false);

			/** Function called to reset only the fixings to be used for the funding notional in order to get after the good average spread.
			@param adjData is the current basket adjustment.
			@param compoFixing is the fixing of the component expressed in the swap currency for the reset.
			@param forex is the FX spot to consider for this component and this adjustment.
			@see ComponentDetails::ChangeComposition
			@version 5.3.7
			*/
			void ResetNotionalFixing(	const BasketAdjustmentData &adjData,
										double	compoFixing,
										double forex);

			/** Function called to pay the redeemed notional from a previous adjustment not paid yet.
			@see ComponentDetails::ChangeComposition
			@version 5.3.7
			*/
			void PreviouslyRedeemedNotionalPayment();

			/** Function called to pay the main funding.
			@param adjData is the current basket adjustment.
			@param spread reset change change type using SpreadResetEnum @version 7.1.3
			@param spread is the spread for financing to apply on the whole component or to the added notional depending on isSpreadResetted.
			@see ComponentDetails::ChangeComposition
			@version 5.3.7
			*/
			void GenerateRatePayment(const BasketAdjustmentData &adjData, sophis::finance::SpreadResetEnum::Enum spreadReset, double spread, double fundingSpread);

			struct SOPHIS_FINANCE NotionalSpread
			{
				NotionalSpread();
				double notional;
				double avgSpread; // avg borrowing spread
				double avgFundingSpread;
			};
			typedef _STL::map<long, NotionalSpread >	NotionalStartSpread;

			/** Function that returns the map of cumulative redeemed notional and corresponding average spreads after a change of composition.
			@version 5.3.6
			*/
			const NotionalStartSpread & GetRedeemedNotional() const;

			/** Function that returns the map of cumulative redeemed notional corresponding to performances not paid when realized.
			@version 5.3.6
			*/
			const CashFundingList * GetNotionalForFinancing() const;

			const CashFundingList& GetAsynchronousRealizedToRemunarate() const;
			const CashFundingList& GetRealizedUnpaidList() const;
			const CashFundingList& GetAnticipatedRealizedList() const;


			/** Function that compute the the accrued of the extra funding
			@param accruedDate is the accrued computation date.
			@param spreadMap is the spread list to use for remuneration with rate leg.
			@param spreadLong is the spread for long notional. Set only for custom rate funding.
			@param spreadShort is the spread for short notional. Set only for custom rate funding.
			@param spreadComputation is the computation interface for the spread part or fixed rate leg.
			@param floatingComputation is the computation interface for the floating part to use when remunaration is based on rate leg.
			@param floatingComputationCustom is the computation interface for the floating part when using custom rate.
			@param spreadPart is the computation output for the spread part.
			@param floatingPart is the computation output for the floating part.
			@param spreadPartToRenumerate is the computation output for the spread part to be paid with the adjustment.
			@param floatingPartToRenumerate is the computation output for the floating part to be paid with the adjustment.
			@param globalNotionalInfo is the notional information for the whole basket. It is usefull to get the spread when netting notionals.
			@version 6.2.1
			*/
			virtual void ComputeAccruedFinancing(	long									accruedDate,
													const MSpreadAdjustmentHistory			&spreadMap,
													double									spreadLong,
													double									spreadShort,
													ICalculation							&spreadComputation,
													ICalculation							&floatingComputation,
													ICalculation							&floatingComputationCustom,
													double									&spreadPart,
													double									&floatingPart,
													double									*spreadPartToRenumerate,
													double									*floatingPartToRenumerate,
													const CashFundingList& globalNot,
													const CashFundingList& asynchronousRealizedToRemunarate,
													const ISRBasketSwapIO& io,
													BasketComponentsCache& compCache) const;

			/** Function that compute the accrued of the main funding.
			@param notionalSpread is a map of change of notional.
			@version 5.3.7
			*/
			virtual void BuildNotionalForMainFundingAccrued(NotionalStartSpread	&notionalSpread) const;

			/** Function that return the current notional for the component
			@param averageSpread is the corresponding average spread.
			@param notionalForPerf is the notional computed from adjusted fixings.
			@param quantity is the total quantity for the component.
			@return the current notional for the component.
			@version 5.3.6
			*/
			double GetCurrentNotional(double &averageSpread, double & averageFundingSpread, double *notionalForPerf=0, double *quantity=0) const;

			/** Function that return the current notional for financing (coming from realized unpaid)
			@version 5.3.6
			*/
			double GetCurrentNotionalForFinancing() const;

			/** Function that clean the structure before the next adjustment.
			@version 5.3.6
			*/
			void	CleanForNextStep();

			/** Function the tells if there is anything left to keep for the component..
			@version 5.3.6
			*/
			bool	IsEmpty() const;

			/** Function that erase everything
			@version 5.3.6
			*/
			void Clear();

			/** Function that merges the notional structures
			@param source is the date to merge.
			@version 5.3.7
			*/
			void Merge(const IncreaseDecreseForReporting&source);

			/** Function calculating the interest on daily margin values for accruedDate. It also modifies fDailyMarginDataList, removing the part already calculated.
			@param sicovam id of the component
			@param accruedDate is the accrued computation date.
			@param context is the computation context.
			@param spreadMap is the spread list to use for remuneration with rate leg.
			@param spreadComputation is the computation interface for the spread part or fixed rate leg.
			@param floatingComputation is the computation interface for the floating part to use when remuneration is based on rate leg.
			@param floatingComputationCustom is the computation interface for the floating part when using custom rate.
			@param spreadPart is the computation output for the spread part.
			@param floatingPart is the computation output for the floating part.
			@param marginCallUnpaid is the Daily Margin Notional for Futures.
			@param spreadLong is the spread for long notional. Set only for custom rate funding.
			@param spreadShort is the spread for short notional. Set only for custom rate funding.
			@param useCustomRate boolean which specifies if calculation is done with leg's rate or a custom rate.
			@param fxFixingType is the type of spot used for forex (LAST by default).
			@param basketSwap is the basket swap instrument.
			@version 7.1
			*/
			void CalculateDailyMargin(	long									sicovam,
										long									accruedDate,
										const market_data::CSRMarketData		&context,
										const MSpreadAdjustmentHistory			&spreadMap,
										ICalculation							&spreadComputation,
										ICalculation							&floatingComputation,
										ICalculation							&floatingComputationCustom,
										double									&spreadPart,
										double									&floatingPart,
										double									&marginCallUnpaid,
										double									spreadLong,
										double									spreadShort,
										bool									useCustomRate,
										const CSRBasketSwap						&basketSwap,
										const ISRBasketSwapIO& io,
										BasketComponentsCache& compCache);

			/** Sets the daily margin interest to be paid in the current adjustment, following the extra funding rules.
			@param toBePaid is the indicator that daily margin interest is to be paid in current adjustment.
			@version 7.1
			*/
			void SetDailyMarginInterestToBePaid(bool toBePaid = true) { fDailyMarginInterestToBePaid = toBePaid; }

			/** Function returning true or false depending on if daily margin interest needs to be paid or not.
			@return bool true if daily margin interest needs to be paid, false otherwise
			@version 7.1
			*/
			bool IsDailyMarginInterestToBePaid() { return fDailyMarginInterestToBePaid; }

			struct DailyMarginData
			{
				long	startDate;
				long	endDate;
				double	quantity;
				double	spot;
				long	rateId;
				double	rateFixing;
			};

			/** Data specifying a bucket of securities booked as a basket component.
			@version 5.3.6
			*/
			struct NecessaryData
			{
				double	quantity;
				double	notionalUnit;
				double	notionalUnitForPerf;
				double	forex;
				double	forexForPerf;
				double	spread;
				double	fundingSpread;
				sophis::finance::SpreadResetEnum::Enum	spreadReset;
				long	negotiationDate;
				long	settlementDate;
				int		divEligibility;
				double	divRebateRatio;
				long	originalNegotiationDate;
				int		order;
				double	accrued;
				long	adjustment;
			};

		private:

			/**
			internal use
			@version 5.3.6
			*/
			_STL::list<NecessaryData> fDataList;
			NotionalStartSpread fNotionalRedeemed;
			NotionalStartSpread fNotionalRedeemedNotPaid;
			CashFundingList fAsynchronousRealizedToRemunarate;
			CashFundingList fAnticipatedRealizedList;
			CashFundingList fRealizedUnpaidList;
			_STL::map<int, _STL::list<DailyMarginData> > fDailyMarginDataList;
			bool fDailyMarginInterestToBePaid;
			void CleanData();
			static void AgregateNotionalSpread(const NotionalStartSpread& map1, NotionalStartSpread& map2);
		};

		/**
		Class that contains the data of a basket component.
		@version 5.3.4
		*/
		struct SOPHIS_FINANCE ComponentDetails
		{

			/**
			Default constructor.
			@version 5.3.4
			*/
			ComponentDetails();

			ComponentDetails(const ComponentDetails& other);

			// do not put a vtable on this struct, it is memcopied.
			~ComponentDetails();

			ComponentDetails& operator=(const ComponentDetails& other);

			/**
			Compares two components.
			@param other the other components to compare with.
			@returns true if components are the same.
			@version 5.3
			*/
			bool operator == (const ComponentDetails & other) const;
			/**
			Compares two components.
			@param other the other components to compare with.
			@returns true if components are different.
			@version 5.3
			*/
			bool operator != (const ComponentDetails & other) const;

			/**
			Compares two components.
			@param other the other components to compare with.
			@param checkReferenceID specifies whether to compare the reference
			@returns true if components are the same.
			@version 5.3
			*/
			bool Compare(const ComponentDetails & other, bool checkReferenceID = false) const;

			/** Structure for output of the composition
			*/
			struct SOPHIS_FINANCE ChangeCompositionOutput
			{
				ChangeCompositionOutput() {reset(true);}
				/**
				@param cleanNot if true it cleans also fNotionalMgt;
				*/
				void reset(bool cleanNot=false);
				bool canBeDeleted(bool resetData);
				void operator += (const ChangeCompositionOutput &term);

				double	fRealizedPaid;
				double	fRealizedUnpaid;
				double	fNewNotionalLong;
				double	fNewNotionalShort;
				double	fNewNotionalForFinancing;
				double	fNewAverageSpreadLong;
				double	fNewAverageSpreadShort;
				double	fNewAverageFundingSpreadLong;
				double	fNewAverageFundingSpreadShort;
				double	fNewNotionalForPerf;
				double	fReferenceNotionalForPerf;
				double	fAccruedPaid;
				double	fAccruedUnpaid;

				// Tracking of the different notional and spread for the component
				IncreaseDecreseForReporting fNotionalMgt;

				// Specific dividend (Special Ex, Special Cum) information per component and the quantity to be applied.
				double fDeltaQuantity;
				double fPreviousDeltaQuantity;
				instrument::eDividendEligibility fDivEligibility;
				instrument::eDividendEligibility fPreviousDivEligibility;
			};

			/** Impact of notional due to change a composition.
			@param old is the previous composition.
			@param adjData is the current adjustment data.
			@param context is used to fill the fixing if missing.
			@param basketSwap is the basket swap instrument.
			@param flowMgt is an interface used for calculation on the flow management.
			@param notionalBasedOnAdjustedFixings says if the financing is based on adjusted fixing. Used for price return swaps.
			@param fundingMethod is the way to found the asynchronous payments.
			@param fundingPaymentRule is the rule to define when the funding of asynchronous payment is paid.
			@param forwardValue if adjustment is in the future then it is set to the forward value at modification date. If not in the future, it is set to NOTDEFINED.
			@param output is the output giving the realized, the new notional for interest, the nominal redeemed.
			@param perfExplanation is a list of pair date (long) and performance (double) defining the performance changes in time. Modified inside.
			@version 5.3.4
			@since 5.3.6 added one parameter for the reposting method 'reportingMethod'
			@since 5.3.7 parameters swapId, swapCurrency and reportingMethod are substituted by basketSwap and flowMgt(as their values can be taken from them).
			@since 5.3.7 added parameter perfExplanation in order to keep record of the changes in the performance.
			*/
			void ChangeComposition(	const ComponentDetails &old,
										const BasketAdjustmentData &adjData,
										const market_data::CSRMarketData & context,
										const CSRBasketSwap &basketSwap,
										const ISwapFlowManagement &flowMgt,
										bool notionalBasedOnAdjustedFixings,
										instrument::eExtraFundingMethod fundingMethod,
										const instrument::CSRSwapPaymentRule *fundingPaymentRule,
										double forwardValue,
										ChangeCompositionOutput &output,
									IncreaseDecreseForReporting::PerfExplanation *perfExplanation,
									const ISRBasketSwapIO& io,
									sophis::finance::BasketComponentsCache& compCache);

			/** Check and fill if needed the fixing.
			Update also the fSpotInSwapCurrency.
			@param adjData is the current adjustment for which fixing and average price should be set. if NULL just fill with current market datas.
			@param context is used to fill the fixing if missing.
			@param basketSwap is the current basket swap.
			@param computedForward if the adjustment is in the future and if computed it is the forward at adjustment date. Else it is set to NOTDEFINED.
			@param old if any it is the previous composition to get previous fixing and average price, else it is NULL.
			@param forceNoPerf if old is not NULL and set to true, then fixings are set to previous average price as well as average price.
			@version 5.3.4
			*/
			void CheckFixing(const BasketAdjustmentData *adjData,
								const market_data::CSRMarketData & context,
								const CSRBasketSwap &basketSwap,
								double computedForward,
								const ComponentDetails *old,
							 const ISRBasketSwapIO& io,
							 BasketComponentsCache& compCache,
								bool forceNoPerf=false) const;


			/**
			Calculated the forex value to be used in calculation
			*/
			static double GetForexInToBasketCcyOrder(double fixing_value, long ccy, long refccy, sophis::instrument::eForexOrder forexOrder);

			/**
			Used to order two lists so that it is easier to compare two baskets.
			The order used is instrument id.
			@version 5.3.4
			*/
			friend bool operator < (const ComponentDetails & x1, const ComponentDetails & x2);

			/**
			  Archive the fields of Structure not linked to CSRElement data
			*/
			friend sophis::tools::CSRArchive & operator<<(sophis::tools::CSRArchive &, const ComponentDetails &);

			/**
			 Unarchive the fields of Structure not linked to a CSRElement data
			*/
			friend const sophis::tools::CSRArchive & operator>>(const sophis::tools::CSRArchive &, ComponentDetails &);

			/**
			The Swap ID code the component belongs to
			@version 5.3.4
			*/
			long fSwapID;

			/**
			The instrument ID of the component
			@version 5.3.4
			*/
			long fSicovam;

			/**
			The quantity of the component
			@version 5.3.4
			*/
			double  fQuantity;

			/**
			The dividend ratio of the component
			@version 5.3.4
			*/
			double  fDividend;

			/**
			The fixing of the component
			@version 5.3.4
			*/
			double   fFixing;

			/**
			The forex fixing of the component as displayed in the GUI
			@version 5.3.4
			*/
			double fDisplayFxFixing;

			/**
			The value date of the component change
			@deprecated 5.3.4
			*/
			long fValueDate;

			/**
			The spread value for component
			@version 5.3.6
			*/
			double fBorrowSpread;
			double fFundingSpread;

			/**
			The Forex Order
			@version 5.3.6
			*/
			long fForexOrder;

			/**
			The Adjusted fixing. Used only for Price return swap
			@version 5.3.6
			*/
			double  fAdj_fixing;

			/**
			The nominal weight (in %, ratio, or quantities) used by Forward Swaps
			@version 5.3.6
			*/
			double fNomWeight;

			/**
			The spread adjustment
			@version 5.3.6
			*/
			SpreadResetEnum::Enum  fSpread_Adj;

			/**
			The forex fixing of the component used for calculation
			@version 5.3.4
			*/
			double  fFx_fixing;

			/**
			Dividend Eligibility. Can be Standard, Special Ex or Special Cum.
			@version 5.3.7
			*/
			int fDivEligibility;

			/**
			 Tells whether the FX Fixing has been modified by the suer or not.
			 0 = not modified manually, 1 = modified manually by the user.
			 */
			long fFx_Fixing_User_Mod;

			/**
			The fixing value in unit of the TRS. Updated by CheckFixing.
			This is used for funding notional computation
			@version 5.3.4
			*/
			mutable double fSpotInSwapCurrency;

			/**
			The adjusted fixing value in unit of the PRS. Updated by CheckFixing.
			This is used for performance computation
			@version 5.3.6
			*/
			mutable double fAdjSpotInSwapCurrency;

			/**
			Boolean to say if the quantity was computed from weight or not.
			@version 5.3.7
			*/
			bool fComputedQuantity;

			/**
			Is the accrued to consider for the component. Started using in 7.1.
			@version 5.3.7
			*/
			double fAccrued;

			/**
			Is the accrued per component in unit of the Basket Swap.
			Used for Accrued performance computation.
			*/
			double fAccruedInSwapCurrency;

			/**
			For toolkit fields added in CSRBasketCompositionColumn::GetFactory
			 */
			long fExtraFieldCount;
			sophis::sql::CSRStructureDescriptor::Element* fExtraFieldsDesc;
			char* fExtraFields;
		};

		/**
		   This cache accelerates the pricing of basket swaps by computing
		   some pieces of information only once per component.
		 */

		class SOPHIS_FINANCE BasketComponentsCache
		{
		public:
			BasketComponentsCache();

			double GetQuotity(long sicovam);

			void SetDividends(long sicovam,
							  const _STL::vector<sophis::instrument::SSDividendArray>& divs);
			void SetDividends(long sicovam,
							  long beginDate,
							  long endDate,
							  sophis::instrument::eSettlementType settlementType,
							  const sophis::market_data::CSRMarketData& context,
							  const ISRBasketSwapIO& io);

			const _STL::vector<sophis::instrument::SSDividendArray>&
				GetDividends(long sicovam) const;

			void GetDividends(long sicovam,
							  sophis::instrument::eSettlementType settlementType,
							  long beginDate,
							  long endDate,
							  double globalDivFactor,
							  const sophis::market_data::CSRMarketData& context,
							  /*out*/_STL::vector<sophis::instrument::SSDividendArray>& oDiv,
							  const ISRBasketSwapIO& io) const;

			double GetUniversalCouponRate(const sophis::static_data::CSRInterestRate& rate,
										  const sophis::market_data::CSRMarketData& context,
										  long start_date,
										  long end_date,
										  const sophis::static_data::SSCouponCalculation& ccData,
										  sophis::instrument::CSRCashFlowInformation* explanation,
										  double minimum,
										  double maximum,
										  const ISRBasketSwapIO& io);

			struct CouponRateKey
			{
				long sicovam;
				long start_date;
				long end_date;
				double minimum;
				double maximum;
				double spread;

				bool operator<(const CouponRateKey& other) const;
				bool operator==(const CouponRateKey& other) const;
			};

			double fFixedAssetFirstRatio;

		protected:
			_STL::map<long, double> fQuotities;
			_STL::map<long, _STL::vector<sophis::instrument::SSDividendArray> > fDividends;
#ifndef GCC_XML
			boost::unordered_map<CouponRateKey, _STL::pair<double, sophis::instrument::CSRCashFlowInformation> > fCouponRates;
#endif
		};
		_STL::size_t hash_value(const BasketComponentsCache::CouponRateKey& k);

		/**
		Class that contains vector of basket components.
		@version 5.3.4
		*/
		typedef _STL::vector<ComponentDetails> ComponentDetailsList;

		/**
		Class that contains list of basket components.
		This container will be more usefull for pricing to compare two composition changes.
		@version 5.3.4
		*/
		struct SOPHIS_FINANCE ComponentDetailsSTLList : _STL::list<ComponentDetails>
		{
			/* Constructor to initialize the forward notional member variables.
			*/
			ComponentDetailsSTLList() {fFwdNotional=0;fFwdNotionalCcy=0;}

			/** Structure for output of the composition component by component
			*/
			struct SOPHIS_FINANCE ChangeCompositionOutputMap : public ComponentDetails::ChangeCompositionOutput,public _STL::map<long,ComponentDetails::ChangeCompositionOutput>
			{
			public:
				/** after each composition change, it aggregates the results of the components in the main structure.
				*/
				void	UpdateAgregatedValues();

				/** Function that clean the structure before the next adjustment.
				@version 5.3.6
				*/
				void	CleanForNextStep();
			};

			/** Calculate the notional at fixing date.
			Note that it checks the fixing and fill if necessary.
			Update also the fSpotInSwapCurrency.
			@param fixing_date is the negotiation date of the adjustment.
			@param value_date the value date of the adjustment.
			@param context is used to fill the fixing if missing.
			@param basketSwap is the basket swap instrument.
			@param notionalBasedOnAdjustedFixings says if the financing is based on adjusted fixing. Used for price return swaps.
			@param forwardPerComponent if adjustment is in the future then the map should contain the forward value per component. If not in the future, the map is empty.
			@param output is the output giving the realized, the new notional for interest, the nominal redeemed.
			*/
			double GetNotional(const BasketAdjustmentData &adjData,
				const market_data::CSRMarketData & context,
				const CSRBasketSwap &basketSwap,
				bool notionalBasedOnAdjustedFixings,
				const _STL::map<long, double> &forwardPerComponent,
							   ChangeCompositionOutputMap &output,
							   const ISRBasketSwapIO& io,
							   BasketComponentsCache& compCache) const;

			typedef _STL::map<long,IncreaseDecreseForReporting::PerfExplanation> PerfExplanationPerComponent;

			/** Impact of notional due to change a composition.
			@param old is the previous composition.
			@param adjData is the current adjustment data.
			@param context is used to fill the fixing if missing.
			@param basketSwap is the basket swap instrument.
			@param flowMgt is an interface used for calculation on the flow management.
			@param notionalBasedOnAdjustedFixings says if the financing is based on adjusted fixing. Used for price return swaps.
			@param fundingMethod is the way to found the asynchronous payments.
			@param fundingPAymentRule is the rule to define when the funding of asynchronous payment is paid.
			@param forwardPerComponent if adjustment is in the future then the map should contain the forward value per component. If not in the future, the map is empty.
			@param output is the output giving the realized, the new notional for interest, the nominal redeemed.
			@param perfExplanationPerComponent map per component of a list of performance changes in time.
			@since 5.3.6 the signature has changed to add the reporting method and remove notional redeemed that is now in 'output'
			@since 5.3.7 parameters swapId, swapCurrency and reportingMethod are substituted by basketSwap and flowMgt(as their values can be taken from them).
			@since 5.3.7 added parameter perfExplanationPerComponent in order to keep record of the changes in the performance per component.
			*/
			void ChangeComposition(const ComponentDetailsSTLList &old,
				const BasketAdjustmentData &adjData,
				const market_data::CSRMarketData & context,
				const CSRBasketSwap &basketSwap,
				const ISwapFlowManagement &flowMgt,
				bool notionalBasedOnAdjustedFixings,
				instrument::eExtraFundingMethod fundingMethod,
				const instrument::CSRSwapPaymentRule *fundingPAymentRule,
				const _STL::map<long, double> &forwardPerComponent,
				ChangeCompositionOutputMap &output,
								   PerfExplanationPerComponent *perfExplanationPerComponent,
								   bool aggregateValues,
								   const ISRBasketSwapIO& io,
								   BasketComponentsCache& compCache);

			/** Structure for output of the dividend explanation component by component.
			*/
			struct DivExplanation
			{
				double	fAmount;
				_STL::vector<instrument::SSDividendArray>	fDividendArray;
			};

			/** Calculate dividend Amount between two dates.
			Dividends are discounted to calculation_date.
			This method is used in an equity swap when paying dividends.
			@param basketSwap is the basket swap instrument.
			@param flowMgt is an interface used for calculation on the flow management.
			@param globalDivFactor is a multiplicative factor to apply to each component dividend.
			@param context is a market data.
			@param start_date is the start of the period for dividend in ex-div.
			@param end_date is the end of the period for dividend in ex-div.
			@param nextAdjDate is the modification date of the next adjustment. it is usefull for special ex/cum
			@param paye_date is payment date of dividend; it may be a relative date. If null it will use dividend payment date for discount.
			@param base is the criterion to include dividend dates: ex-div, record or payment date
			@param paymentInSwapCurrency is to tell if dividends are paid in dividend currency or in swap currency.
			@param noCompound if set to true then amounts are not compunded.
			@param outputAsInput contains the map of results of the basket adjustment per component.
			@param possibleDividendResetDates set of dates which correspond to the possible dates of virtual reset dates for dividends.
			@param explanation holds the dividend explanation in case of immediate dividend payment (ie a relative pay date).
			*/
			double GetGrossDividendAmount(
				const CSRBasketSwap &basketSwap,
				const ISwapFlowManagement &flowMgt,
				double	globalDivFactor,
				const market_data::CSRMarketData & context,
				long start_date,
				long end_date,
				long paye_date,
				long nextAdjDate,
				instrument::eDividendBase	base,
				bool paymentInSwapCurrency,
				bool noCompound,
				const ChangeCompositionOutputMap &outputAsInput,
				const _STL::set<long>			&possibleDividendResetDates,
				const ISRBasketSwapIO& io,
				BasketComponentsCache& compCache,
				instrument::CSRCashFlowInformationList		*explanation = 0) const;

			/** Calculate the forward prices of the composition for a list of dates.
			This method is used in an equity swap when computing forward part of the performance.
			@param futureDate is an array of expiries of the forward, in number of days from 1/1/1904.
			@param val is an output array for the values of forward per component, which must be effectively allocated. FirstIndex is the date, second index is the component.
			@param matchingCodes are the corresponding component codes.
			@param dateCount is the number of dates in the array.
			@param currency is the swap currency to get the forward expressed in this currency.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			@param basketSwap is the basket swap instrument.
			*/
			void  GetForwardPrice(	long									*fowardDate,
									_STL::vector<_STL::vector<double> >		&val,
									_STL::vector<long>						&matchingCodes,
									short									dateCount,
									long									currency,
									market_data::eTaxCreditPercentageType	forEvaluation,
									const market_data::CSRMarketData		&context,
									const CSRBasketSwap&					basketSwap,
									const ISRBasketSwapIO& io) const ;

			/** Calculates the quantities and updates them in the composition with the value calculated based on the weight values.
			@param basketSwap is the basket swap instrument.
			@param context is the market data.
			*/
			void SetQuantitiesFromWeight(const CSRBasketSwap &basketSwap, const market_data::CSRMarketData & context);

			/**
			The notional value used in basket creation using Forward Start.
			@version 5.3.7
			*/
			double fFwdNotional;

			/**
			The currency of the notional value used in basket creation using Forward Start.
			@version 5.3.7
			*/
			long fFwdNotionalCcy;
		};

		struct SOPHIS_FINANCE BasketHistoryKey
		{
			long date;
			long order;

			BasketHistoryKey(long d, long o)
				:date(d), order(o)
			{}

			bool operator < (const BasketHistoryKey &otherKey) const
			{
				return date < otherKey.date ||((date ==  otherKey.date) && order < otherKey.order);
			}

			bool operator == (const BasketHistoryKey &otherKey) const
			{
				return date ==  otherKey.date && order == otherKey.order;
			}

		};
		typedef _STL::map<BasketHistoryKey, BasketAdjustmentData> BasketAdjustmentHistoryMap;

		/** Structure containing the spread list.
		@since 5.3.4
		*/
		struct MSpreadAdjustmentHistory : _STL::map< long, double >
		{
			/** Get list of spread.
			@param start_date is the start of calculation.
			@param end_date is the end of calculation.
			@param calcul is the interface for calculation.
			@param notionalList is a map of change of notional.
			@param useOnlyComponentSpread is a boolean specifying what spread should be used for interest calculation (i.e. futures only use component spread).
			@return the number of days multiplied by the spread and notional. To get
			the interest, you just have to divide by the basis.
			*/
			double GetCalculation(long start_date,
							long end_date,
							ICalculation * calcul,
									const IncreaseDecreseForReporting::NotionalStartSpread &notionalList,
								  const ISRBasketSwapIO& io,
								  BasketComponentsCache& compCache,
								  instrument::CSRCashFlowInformationList* explanationList=0,
								  bool useOnlyComponentSpread = false) const;
		};

		struct SOPHIS_FINANCE MSpreadHistoryPerComponent : _STL::map< long, MSpreadAdjustmentHistory >
		{
			MSpreadAdjustmentHistory& GetSpreadAdjustmentHistory(long sicovam) ;
			void SetSpreadForDate(long date, double spread, ComponentDetailsList *currentComposition = 0);
		};

		/** Structure used as output for {@link GetPnlValues}.
		@since 5.3.4
		*/
		struct	SOPHIS_FINANCE DetailledCalculation
		{
			DetailledCalculation() {reset();}

			/** Write a DetailledCalculation into a CSRArchive.
				Overload of the "<<" operator version.
			*/
			friend SOPHIS_FINANCE sophis::tools::CSRArchive& operator << ( sophis::tools::CSRArchive& ar, const sophis::finance::DetailledCalculation & results );

			/** Read a DetailledCalculation from a CSRArchive.
			Overload of the ">>" operator version.
			*/
			friend SOPHIS_FINANCE const sophis::tools::CSRArchive& operator >> ( const sophis::tools::CSRArchive& ar, sophis::finance::DetailledCalculation& results);


			/** Method to reset all data.
			 */
			void reset();

			/** Called after pricing to take into account the number of securities
			which is generally plus or minus one.
			*/
			void MultiplySecutities(double factor);

			/** Called to aggregate results for several positions.
			*/
			void operator +=(const DetailledCalculation & term);

			/** Return the corresponding accounting value.
			*/
			double	GetAccountingValue() const;

			/** Return the corresponding theoretical value.
			*/
			double	GetTheoreticalValue() const;

			/** members not aggregated by operator +=.
			*/
			double	fAveragePrice;
			double	fAveragePriceMtM;

			/** members aggregated by operator +=.
			*/
			LongShortDouble	fNotionalEq;
			LongShortDouble	fAvgSpreadEq;
			LongShortDouble	fAvgFundingSpreadEq;

			double	fNotionalFina;

			// equity part
			double	fRealizedEquityPaid;//already paid
			double	fRealizedEquityPending; // amount known but automatic ticket not generated yet (we are modification modification dateand tickets are generated for the day after).
			double	fRealizedEquityUnpaid; // realized to be paid with a latter adjustment (coming for example from a no accrued adjustment).
			double	fUnrealizedMTM; // accounting equity value : realized equity performance we would have doing a reset today at current spot.
			double	fEquityDiscounted; // present value of expected performance from future flows (modification date in the future).
			double	fEquityFinancing; // this is the discounted fRealizedEquityPending and fRealizedEquityUnpaid.
			double	fFullyFundedNotional; // this is the notional to be returned at Basket Swap termination in Fully Funded. It is part of the theoretical but not of the Realized/Unrealized.

			// dividend part
			double	fRealizedDividend;
			double	fAccruedDividend;
			double	fDividendDiscounted;
			double	fDividendFinancing;

			// main funding part
			LongShortSpreadFloating		fRealizedPaidEq; // already paid
			LongShortSpreadFloating		fRealizedUnpaidEq; // amount known but not paid yet (we are between modification date and value date).
			LongShortSpreadFloating		fAccruedEq; // this is the accrued interest amount for the main funding.
			LongShortSpreadFloating		fDiscountedEq; // this is the present value of expected future main funding amount.
			LongShortSpreadFloating		fFinancingEq; // this is the discounted fRealizedUnpaidEq.


			// extra funding part
			SpreadFloating				fRealizedPaidFina;  // already paid
			SpreadFloating				fRealizedUnpaidFina; // amount known but not paid yet (we are between modification date and value date).
			SpreadFloating				fAccruedFina; // this is the accrued interest amount for the extra funding.
			SpreadFloating				fDiscountedFina; // this is the present value of expected future extra funding amount.
			SpreadFloating				fFinancingFina; // this is the discounted fRealizedUnpaidFina.

			// extra variables used for some SF columns
			double	fPnlNextCoupon;
			double	fDicountedDividendFromEquity;
			double	fRepoCost;

			// Accrued part
			double	fAccruedCouponPaid;
			double	fAccruedCouponPending;
			double	fAccruedCouponUnpaid;
			double	fAccruedCouponUnrealized;
			double	fAccruedCouponDiscounted;
			double	fAccruedCouponFinancing;

			// Daily Margin Interest for futures
			SpreadFloating				fRealizedPaidDailyMargin;  // already paid
			SpreadFloating				fRealizedUnpaidDailyMargin; // amount known but not paid yet (we are between modification date and value date).
			SpreadFloating				fAccruedDailyMargin; // this is the accrued interest amount for the daily margin interest.
			SpreadFloating				fDiscountedDailyMargin; // this is the present value of expected future daily margin interest.
			SpreadFloating				fFinancingDailyMargin; // this is the discounted fRealizedUnpaidDailyMargin.

			// Daily Margin Notional for Futures
			double	fMarginCallUnpaid;

			// Total Borrowing Interest. Used for ticket generation split.
			double fBorrowingInterest;
		};

		/** Structure used as output for {@link GetPnlValues}.
		It is used to have information adjustment by adjustment in order to fill the specific dialog
		@since 5.3.4
		*/
		struct SOPHIS_FINANCE DetailledCalculationWithAddedData : public DetailledCalculation
		{
		public:
			DetailledCalculationWithAddedData();

			double	fDividendInSwapCurrency;
			long	fDividendCurrency;
			int		fDividendCount;
			long	fCountry;
			double 	fFx_Fixing;
			double 	fFixing;
			double	fAdjFixing;
			double 	fQuantity;
			double	fDividendRatio;
			sophis::finance::SpreadResetEnum::Enum	fSpreadReset;
			double	fBorrowSpread; // has fFixing, so it's a component's data
			double	fFundingSpread;
			long	fInterestDayCount;
			double	fNomWeight;
			bool	fComputedQuantity;
			int		fDivEligibility;
			double	fAccrued;
		};

		/** Structure used as output for {@link GetPnlValues}.
		It is used to have information adjustment by adjustment in order to fill the specific dialog
		@since 5.3.4
		*/
		struct SOPHIS_FINANCE DetailledCalculationMap : public DetailledCalculation, public BasketAdjustmentData, public _STL::map<long,DetailledCalculationWithAddedData>
		{
		public:
			DetailledCalculationMap();

			/** Method to reset all data. and set parameters corresponding to the next basket adjustment.
			@param adjData is the next basket adjustment to proceed.
			@since 5.3.6
			*/
			void	reset(const BasketAdjustmentData& adjData);

			/** Method that initialise a new component to explain.
			@param sicovam is the internal code of the component to add.
			@param componentDetails contains the details about the component for the basket adjustment.
			@param changeCompositionOutput contains the results of the basket adjustment for the component.
			@since 5.3.6
			*/
			void	AddComponent(long sicovam, const ComponentDetails& componentDetails, const ComponentDetails::ChangeCompositionOutput &changeCompositionOutput);

			/** Method to the explaination to fill or to read for a component.
			@param sicovam is the code of the component to get.
			@return NULL pointer if the component was not added. Else it returns a pointer to the explaination of the PnL for this component.
			*/
			DetailledCalculationWithAddedData*	GetInitialised(long sicovam);

			/** after each adjustment explanation, it aggregates all detailed calculation data and the average price.
			*/
			void	UpdateAgregatedValues();

			bool	fIsResetDate;
			bool	fIsDividendDate;
			long	fInterestDayCount;
			double	fInterestFixing;
		};

		/**
			Instrument class for the handling of a basket swap (which is a swap having the 'Basket Swap' model).
			Note that it links with SphFinance.

			To derive from CSRBasketSwap, use INITIALISE_BASKET_SWAP macro.
				INITIALISE_BASKET_SWAP(MyBasketSwap, "My Basket Swap");
				INITIALISE_SPECIFIC_DIALOG(CSRBasketSwapSpecific, MyBasketSwap);

			@version 5.3
		*/
		class SOPHIS_FINANCE CSRBasketSwap : public virtual instrument::CSRSwap
		{
			friend class CSRDefaultMetaModelBasketSwap;

		public:
			typedef finance::CSRDefaultMetaModelBasketSwap DefaultMMClass;
		public:

			/** Modification type of the basket
				@version 5.3.4
			*/
			enum ModificationType{ eNotModified, eBasketCreation, eBasketAdjustment, eAdjustmentDeleted};

			/**
				Reporting Method
				@version 5.3.6
			*/
			enum eTRSReportingMethod {
				eWap	= 1,
				eFifo,
				eLifo,
			   	eHico,
				eLoco,
				eHibo,
				eLobo,

			};

			/**
				Swap declaration.
				@version 5.3
			*/
			DECLARATION_SWAP( CSRBasketSwap )

			/**
				Destructor.
				@version 5.3
			*/
			virtual ~CSRBasketSwap();

			virtual const finance::CSRMetaModel* GetDefaultMetaModel() const;

			/**
			Clone.
			@version 5.3
			*/
			virtual sophis::instrument::CSRInstrument* Clone() const;
			virtual bool	ConstructAgain() const;

			/**
				Launches the initialization procedure, used by {@link CSRBasketSwap::RecomputeAll}.
				Initializes the variables with respect to which the greeks and indicators are calculated.
				@see {@link CSRBasketSwap::RecomputeAll}.
				@version 5.3
			*/
			//virtual	void	InitialiseRecomputeAll();

			virtual long GetSettlementDate(long transactionDate) const OVERRIDE; 

			/** Used to specify the unrealized is computed in the reporting.
			*/
			virtual instrument::eUnrealizedMethodType GetUnrealizedMethod() const;

			/** Method to tell if the valuation should be done as if the Lending and Borrowing preference was ticked.
			@since 5.3.6.1
			*/
			bool ValuateAsRepoMarginRediscount() const;
			void SetValuateAsRepoMarginRediscount(sophis::instrument::eValuationType t);

			/** Method to tell if the valuation should split the greeks on compo index components.
			@since 5.3.6.1
			*/
			bool SplitIndexGreeks() const;

			/** enum for computation
			@see BasketSwapComputation
			@since 5.3.4
			*/
			enum eBasketSwapComputation
			{
				eAll,
				eAllExceptPastFlows,
				eAllExceptRateLeg,
				eAllNoPresentValue,
				eAllNoPresentValueNoPastFlows,
				eAllNoPresentValueNoRateLeg
			};

			class SOPHIS_FINANCE SpecificResults : public sophis::CSRGenericContainer
			{
			public:
				virtual sophis::CSRGenericContainer* Clone() const;
				virtual const char* GetName() const;
				virtual void WriteToArchive(sophis::tools::CSRArchive& a) const;
				virtual void ReadFromArchive(const sophis::tools::CSRArchive& a);

				const DetailledCalculation& GetBasketResults() const;
				void SetBasketResults(const DetailledCalculation& basketResults);

			protected:
				DetailledCalculation	fBasketResults;

			};

			/** Complement of BasketSwapComputation in case of svBreakFundingFees.
			@since 5.3.6
			*/
			struct SOPHIS_FINANCE BreakFundingFeesComp
			{
				BreakFundingFeesComp();
				long fRateStartDate;
				long fRateEndDate;
				double fPreviousNotional;
				double fNotional;
				double fSwapRateValue;
				double fZeroCoupon;
			};
			/** Sructure to say what should be computed in GetPnlValues
			@since 5.3.4
			*/
			struct SOPHIS_FINANCE BasketSwapComputation : BreakFundingFeesComp
			{
				BasketSwapComputation();
				BasketSwapComputation(const eBasketSwapComputation &val);

				bool doRate;
				bool doEquity;
				bool doDividend;
				bool doExtraData;

				bool doPastFlows;
				bool doAccrued;
				bool doForwardPart;

				bool noDiscount;
				bool diplayAllHistory;

				// internal use
				enum
				{
					svNo,
					svFlowExplanation,
					svAutomaticTickets,
					svBreakFundingFees,
					svCurrentDivExpl,
				}	doSpecialValuation;
			};

			/** Main calculation method.
			Calculate the fair value and split it between different components.
			@param context is the market data.
			@param spreadMap is the spread list to use.
			@param startDate date from which flows should be considered (@see GetCouponAmount).
			@param endDate date until which flows should be considered (@see GetCouponAmount).
			@param bsCalcMethod is the structure to say what should be computed.
			@param output is the output.
			@param receivedLeg is the cash flow explanation of the receiving leg.
			@param paidLeg is the cash flow explanation of the paying leg.
			@param outputPerComponentPerDate is the detailed output per adjustment.
			@param perfExplMapPerDate is the detailed explanation of the performance per adjustment from previous adjustments.
			@see BasketSwapComputation
			@since 5.3.4
			*/
			virtual void	GetPnlValues(const market_data::CSRMarketData		&context,
											const MSpreadHistoryPerComponent			&spreadMap,
											long									startDate,
											long									endDate,
											BasketSwapComputation					&bsCalcMethod,
											DetailledCalculation					&output,
											instrument::CSRCashFlowInformationList * receivedLeg = 0,
											instrument::CSRCashFlowInformationList * paidLeg = 0,
											_STL::vector<DetailledCalculationMap>	*outputPerComponentPerDate = 0,
											_STL::vector<ComponentDetailsSTLList::PerfExplanationPerComponent>	*perfExplMapPerDate = 0,
											_STL::vector<CashFundingList::ExtraFundingExplanationPerComponent>	*extraFundingMapPerDate = 0,
											_STL::vector<CashFundingList::ExtraFundingExplanationPerComponent>	*mainFundingMapPerDate = 0) const;

			/** Main calculation method.
				Same as previous method, with IOs interfaced.
			*/
			void	GetPnlValuesSafe(const market_data::CSRMarketData		&context,
											const MSpreadHistoryPerComponent		&spreadMap,
											long									startDate,
											long									endDate,
											BasketSwapComputation					&bsCalcMethod,
											DetailledCalculation					&output,
								 const ISRBasketSwapIO& io,
											instrument::CSRCashFlowInformationList * receivedLeg = 0,
											instrument::CSRCashFlowInformationList * paidLeg = 0,
											_STL::vector<DetailledCalculationMap>	*outputPerComponentPerDate = 0,
											_STL::vector<ComponentDetailsSTLList::PerfExplanationPerComponent>	*perfExplMapPerDate = 0,
											_STL::vector<CashFundingList::ExtraFundingExplanationPerComponent>	*extraFundingMapPerDate = 0,
											_STL::vector<CashFundingList::ExtraFundingExplanationPerComponent>	*mainFundingMapPerDate = 0 ) const;


			virtual bool GetPortfolioPnlValues(DetailledCalculation& calc, const TViewMvts* mvts) const ;

			/** Method to generate missing adjustment compared to the leg schedule and in the future.
			@param adjustmentListCopy is a map which contains the existing adjustments in the basket. Generated adjustments are added to it inside.
			@param bsc is the structure to say what should be computed.
			@param flowMgt is an interface used for calculation on the flow management.
			@param comptationDate is the calculation date.
			@param possibleDividendResetDates set of dates which correspond to the possible dates of virtual reset dates for dividends. Set inside.
			@since 5.3.7
			*/
			void	BuildAdjustmentsForPricing(	BasketAdjustmentHistoryMap	&adjustmentListCopy,
												const BasketSwapComputation	&bsc,
												const ISwapFlowManagement	&flowMgt,
												long						comptationDate,
												_STL::set<long>				&possibleDividendResetDates,
												const ISRBasketSwapIO& io) const;

			void GetDividendsForPricing(const BasketAdjustmentHistoryMap& adj,
										instrument::eDividendBase base,
										const sophis::market_data::CSRMarketData& context,
										const ISRBasketSwapIO& io,
										/*out*/BasketComponentsCache& compCache) const;

			/** Calculate the coupon amount which is going to be distributed over a period.
			@param startDate is the start of the period. It is excluded.
			@param endDate is the end of the period. It is included.
			@param context is the market data.
			@param discounted asks for discount of the coupons.
			This function is called during theta calculation and P&L attributions
			to compare the previous day's trades P&L with the expected coupon amount.
			@since 5.3
			@see GetTheta
			@see GetPnlValue
			*/
			virtual double	GetCouponAmount(long							startDate,
											long							endDate,
											const market_data::CSRMarketData&context,
											bool							discounted) const;

			/** Overloaded from CSRSwap to consider adjustments.
			@param transactionDate is the transaction date in number of days from 1/1/1904.
			@param couponList is the list of coupon.
			@since 5.3.4
			*/
			virtual	void	GetNextCouponDate(	long	transactionDate,
												CouponList &couponList) const;

			/** Overloaded from CSRSwap to consider adjustments.
			@param whichLeg may be 0 or 1.
			@param transactionDate is the transaction date in number of days from 1/1/1904.
			@param nextCouponDate is the output parameter to set the next coupon date; O if no coupon.
			@param couponRate is the output parameter to put the rate to display.
			@param mayModifyCumExDistribution is the output parameter to know if the button
			@param PariPassDate get the pari passu date to put.
			@since 5.3.4
			*/
			virtual void	GetNextCouponDate(	int		whichLeg,
												long	transactionDate,
												long	*nextCouponDate,
												double	*couponRate,
												bool	*mayModifyCumExDistribution,
												long	*PariPassDate) const;

			/** Get the notional in that date.
			@param date is date for the notional.
			@return the notional for that date.
			*/
			double GetCurrentNotional(long date) const;

			/** Get the last notional to be displayed in portfolio view.
			@see GetCurrentNotional
			@since 5.3.4
			*/
			virtual double GetOtherNotional(long * currency) const;

			/**	Returns reporting method
			@param hasLinePicking if line picking should be used to suplement the reporting method;
			@since 5.3.6
			*/
			eTRSReportingMethod GetReportingMethod(bool *hasLinePicking) const;

			/**	Returns the flag telling if it is a forward start swap or not
			@since 5.3.7
			*/
			bool IsForwardStartSwap() const;

			/** Gets the Funding Fixing Method as selected in advanced tab. Only for Basket Swap Model.
			@since 5.3.7
			*/
			sophis::instrument::eFundingFixingMethod GetFundingFixingMethod() const;

			/** Sets the Funding Fixing Method. Only for Basket Swap Model.
			@param fundingType  is Funding Fixing Method either "Gross Fixing" or "Net Fixing", or no distinct Gross and Net fixings.
			@since 5.3.7
			*/
			void SetFundingFixingMethod(sophis::instrument::eFundingFixingMethod fundingType);

			/** Sets Reporting method
			@param reportingMethod reporting method;
			@param hasLinePicking if line picking should be used to suplement the reporting method. If true reporting method can not be set to wap;
			@since 5.3.6
			*/
			void SetReportingMethod (eTRSReportingMethod reportingMethod, bool hasLinePicking);

			/** Gets the Price Return Swap Funding Type as selected in advanced tab
			used only for PRS;
			@since 5.3.6
			*/
			sophis::instrument::ePRSFundingType GetPRSFundingType() const;

			/** Sets the Price Return Swap Funding Type
			@param fundingType  is Funding Type either "Adjusted Equity Fixing" or "Mark-to-Market" fixing
			only for basket swaps (PRS)
			@since 5.3.6
			*/
			void SetPRSFundingType(sophis::instrument::ePRSFundingType fundingType);

			/**	Returns the truncation date. It can be relative or absolute.
			@since 6.2
			*/
			long GetTruncationDate() const;


			/** Sets the truncation date
			@param date is the truncation date to set. It can be relative or absolute. 0 is for no truncation.
			@since 6.2
			*/
			void SetTruncationDate(long date);

			/** Gets the local index split preference
			@since 6.2
			*/
			sophis::instrument::eBasketGreeksSplit GetIndexSplitLocalPref() const;

			/** Sets the Price Return Swap Funding Type
			@param splitPref  is Funding Type either "Adjusted Equity Fixing" or "Mark-to-Market" fixing
			only for basket swaps (PRS)
			@since 6.2
			*/
			void SetIndexSplitLocalPref(sophis::instrument::eBasketGreeksSplit splitPref);

			/** Returns true if the basket swap is fully funded, false otherwise.
			@since 5.3.7
			*/
			bool IsFullyFunded() const;

			/** Sets the Price Return Swap Funding Type
			@param isFullyFunded specifies if the swap is fully funded or not.
			@since 5.3.7
			*/
			void SetIsFullyFunded(bool isFullyFunded);

			/** Returns true if the basket swap is quanto model, false otherwise.
			* @since 7.1
			*/
			bool IsQuantoBasket() const;

			/** Sets the Quanto Basket model
			* @param isQuantoBasket specifies if the basket swap is quanto model or not.
			* @since 7.1
			*/
			void SetIsQuantoBasket(bool isQuantoBasket);

			/**
			* Return whether treat spread for each component separatly 
			**/
			bool IsDefineFundingSpreadPerComponent();

			/** Structure to explains the income of a TRS.
			It is calculated during the reporting and showed in portfolio columns.
			*/

			struct SOPHIS_FINANCE DetailledReporting
			{
				void reset();
				void operator +=(const DetailledReporting & term);

				double	fDividend;
				double	fFloating;
				double	fSpread;
				double	fEquity;
				double  fBorrowingSpread;

			};

			/**
			Methods computing upfront fees for a new adjustment.
			@param newComposition contains the new composition data.
			@param newAdjustment contains the new adjustment information.
			@param spreadList contains the list of spread to use.
			@param currentSpread gives the spread chosen for the adjustment.
			@param spreadEndDate gives the date until the user defined spread is to be considered.
			@param newPrice is an output to give the theoretical value of the TRS after the adjustment.
			@param lp New line picking information. Only entries with adjustment id set to zero is used.
			@version 5.3.4.
			*/
			virtual double ComputeUpfrontFees(	const ComponentDetailsList& newComposition,
												const BasketAdjustmentData&	newAdjustment,
												const MSpreadHistoryPerComponent& spreadList,
												double						currentSpread,
												long						spreadEndDate,
												double						*newPrice=0,
												const LinePickingMap		*lp=NULL) const;

			/**
			Methods computing upfront fees for a new adjustment.
			@param newComposition contains the new composition data.
			@param newAdjustment contains the new adjustment information.
			@param spreadList contains the list of spread to use.
			@param currentUpfront gives the upfront chosen for the adjustment.
			@param remainingPeriodSpread is the output for the spread to set for the remaining period in order not to generate PnL. It may be null for no computation.
			@param globalAdjustmentSpread is the output for the spread to set until maturity in order not to generate PnL. It may be null for no computation.
			@param remainingPeriodBreakEven is the output for the spread to set for the remaining period in order not to have a null new price. It may be null for no computation.
			@param globalAdjustmentBreakEven is the output for the spread to until maturity in order not to have a null new price. It may be null for no computation.
			@param lp New line picking information. Only entries with adjustment id set to zero is used.
			@version 5.3.4.
			*/
			virtual void ComputeAdjustmentSpreads(	const ComponentDetailsList& newComposition,
													const BasketAdjustmentData&	newAdjustment,
													const MSpreadHistoryPerComponent& spreadList,
													double						currentUpfront,
													double						*remainingPeriodSpread,
													double						*globalAdjustmentSpread,
													double						*remainingPeriodBreakEven,
													double						*globalAdjustmentBreakEven,
													const LinePickingMap		*lp=NULL) const;

			/**
			Methods computing upfront fees for a new adjustment.
			@param newComposition contains the new composition data.
			@param newAdjustment contains the new adjustment information.
			@param rateCode is the interpolated rate code to use for computation.
			@param fixingValue is the interpolated fixing to use.
			@param lp New line picking information. Only entries with adjustment id set to zero is used.
			@version 5.3.4.
			*/
			virtual double ComputeBrokenFundingFees(const ComponentDetailsList& newComposition,
													const BasketAdjustmentData&	newAdjustment,
													long						rateCode,
													double						fixingValue,
													const LinePickingMap		*lp=NULL) const;

			/**
			Methods computing the change of notional due to composition change in quantity.
			@param newComposition contains the new composition data.
			@param newAdjustment contains the new adjustment information.
			@param lp New line picking information. Only entries with adjustment id set to zero is used.
			@version 5.3.7.
			*/
			virtual double ComputeRedeemedNotionalFromAdjustment(const ComponentDetailsList& newComposition,
															     const BasketAdjustmentData&	newAdjustment,
																 const LinePickingMap	*lp=NULL,
																 double* currentNotional = 0) const;

			/**
			* Defines ordered history of spread change as pairs of date and value.
			* @param spreadList the spread list to set.
			* @version 5.3.4
			*/
			void ResetCurrentSpreadList();

			/**
			* Check whether the spread was already defined or not.
			* @version 7.1.3
			*/
			bool IsSpreadDefined() const;

			/**
			* Get the current spread list.
			* @return the spread list that has been set.
			* @version 5.3.4
			*/
			const MSpreadHistoryPerComponent& GetCurrentSpreadList() const;

			MSpreadAdjustmentHistory GetSpreadForLastAdjustment(const BasketAdjustmentData& adj) const; // For a given adjustment, list of spreads

			MSpreadAdjustmentHistory GetSpreadForAdjustment(const BasketAdjustmentData& adj) const; // For a given adjustment, list of spreads
			/**
			* Get the current spread from a spread list.
			* @param spreadList is the spread list to use.
			* @param date is the date at which we want the spread.
			* @return the spread that is used at this date.
			* @version 5.3.6
			*/
			double GetCurrentSpread(const MSpreadHistoryPerComponent& spreadList, long date) const ;

			/**
			* Get the spread list from the Extra Position related to positionId and saves it in spreadList.
			* @param positionId is the identifier of the position from which we want to get the spread map.
			* @param spreadList is the object where the spread map from the extra position is saved.
			* @return true if the spread map has been taken correctly from the extra position, false otherwise.
			* @version 6.1.2
			*/
			//static bool GetSpreadListFromPosition(sophis::portfolio::PositionIdent positionId, MSpreadAdjustmentHistory& spreadList);

			/**
			Get the history of the basket swap between two dates.
			@param basketList is an output vector which contains the history of the baskets used during
			the period startDate and endDate.
			@param startDate is the begin date of the period to consider
			@param endDate is the end date of the period to consider
			@see {@link BasketAdjustmentHistory}.
			@version 5.3.4
			*/
			void	GetBasketAdjustments(	BasketAdjustmentHistoryMap::const_iterator &iterBegin,
											BasketAdjustmentHistoryMap::const_iterator &iterEnd,
											long									startDate,
											long									endDate) const;

			void	SetBasketAdjustments(const BasketAdjustmentHistoryMap& adj);


			/**
			Get the number of adjustments between two dates.
			@param startDate is the begin date of the period to consider.
			@param endDate is the end date of the period to consider.
			@return int number of adjustments between startDate and endDate.
			@see {@link BasketAdjustmentHistory}.
			@note when startDate and endDate specified and not include all adjustments between them the cost of calling this method is similar to GetBasketAdjustments.
			@version 7.1.3
			*/
			inline int GetNbAdjustments(long startDate = 0, long endDate = sophisTools::kInfiniteDate) const;

			/**
			Get the list of last basket components.
			@param componentsList is an output vector which contains the list of basket components.
			@see {@link ComponentDetails}.
			@version 5.3.4
			*/
			void	GetBasketComponents(ComponentDetailsList &	componentsList) const;

			/**
			Workaround for RiskCOM
			Returns the number of components in the basket
			(i.e the size of the vector that would be returned by a call to
			CSRBasketSwap::GetBasketComponents)
			Returns 0 if the basket is empty
			@see {@link GetBasketComponents}.
			@version 5.3.4.1
			*/
			long GetBasketComponentNb();

			/**
			Workaround for RiskCOM
			Returns the Nth component of the basket ( ie the Nth element of vector that would be
			returned by CSRBasketSwap::GetBasketComponents)
			Returns NULL if the basket is empty or if index is out of bound
			@param index can range from 0 to CSRBasketSwap::GetBasketComponentNb -1
			@see {@link GetBasketComponents}.
			@see {@link GetBasketComponentNb}.
			@version 5.3.4.1
			*/
			ComponentDetails* GetNthBasketComponent(long index);

			/**

			Get the list of basket components for previous adjustment.
			@param basketID is historic basket id.
			@param componentsList is an output vector which contains the list of basket components.
			@param adjustFromCA is to say if we want to adjust component information according to CA (i.e. dividend ration is adjusted before splits). default value is false.
			@param basketDate is the corresponding modification date for the basket and is used for CA adjustments
			@see {@link ComponentDetails}.
			@version 5.3.4.1
			*/
			const ComponentDetailsList& GetComponentsHistory() const;
			void	GetComponentsHistory(long basketID, ComponentDetailsList & componentsList) const;
			void	GetComponentsHistory(long basketID, ComponentDetailsList & componentsList, bool adjustFromCA, long basketDate) const;

			/**
			Get the list of basket components for previous adjustment.
			This version give a STL list which is sorted by sicovam and will be more efficient for comparason
			of two baskets.
			@param basketID is historic basket id.
			@param fwdNotional the notional value set in basket creation using Forward Start.
			@param fwdNotionalCCY the currency of the notional value set in basket creation using Forward Start.
			@param componentsList is an output list which contains the list of basket components.
			@param adjustFromCA is to say if we want to adjust component information according to CA (i.e. dividend ration is adjusted before splits). default value is false.
			@param basketDate is the corresponding modification date for the basket and is used for CA adjustments
			@see {@link ComponentDetails}.
			@version 5.3.4
			*/
			void	GetComponentsHistory(long basketID, double fwdNotional, long fwdNotionalCCY, ComponentDetailsSTLList & componentsList) const;
			void	GetComponentsHistory(long basketID, double fwdNotional, long fwdNotionalCCY, ComponentDetailsSTLList & componentsList, bool adjustFromCA, long basketDate) const;

			/**
			Get the list of basket components for adjustment on modificationDate with specified order, if no adjustment is found on that date it returns the previous composition.
			@param modificationDate is the date of the adjustment to get the composition from, if not found returns previous composition.
			@param order is the order of the adjustment to get the composition from, if not found returns previous composition.
			@param componentsList is an output vector which contains the list of basket components.
			@return id of the composition returned in componentsList, -1 if no composition returned.
			@see {@link ComponentDetails}.
			@version 7.1.3
			*/
			long	GetComponentsHistory(long modificationDate, long order, ComponentDetailsList& componentsList) const;


			/**
			Returns the absolute order in the adjustment list based on the modification date and the order relative in the day.
			@param modificationDate is the date where the adjustment is to be searched.
			@param relativeOrder is the order relative in modification date to be transformed in absolute.
			@return int absolute order in the adjustment list.
			@version 7.1.3
			*/
			int GetAbsoluteOrder(long modificationDate, int relativeOrder) const;

			/**
			Called  by the basket adjustment dialog.
			@param adjustmentData contains the data entered in the adjustment dialog.
			@param components contains new list of basket components entered in the adjustment dialog.
			@param lp New line picking information. Only entries with adjustment id set to zero is used.
			@param fillAutoPerfTicketsMap boolean which specifies if gAutoPerfTicketsMap should be filled with this adjustment if applicable.
			@throw {@link sophisTools::base::GeneralException}
			@version 5.3
			*/
			virtual void	OnBasketAdjustment(BasketAdjustmentData & adjustmentData, const ComponentDetailsList & components, const LinePickingMap *lp = NULL, bool fillAutoPerfTicketsMap = false);

			/**
			Called by Risque to remove a previously entered basket adjustment.
			@param adjustmentData contains the data of the adjustment to remove.
			@version 5.3.4
			*/
			virtual bool OnRemoveBasketAdjustment( const BasketAdjustmentData & adjustmentData );

			/**
			Called by Risque to remove a previously entered basket adjustment.
			@param adjustmentData contains the line number to remove.
			@version 5.3.4
			*/
			virtual void	OnRemoveBasketAdjustment( int line );

#ifndef GCC_XML
			/**
			Called inside OnBasketAdjustment and OnRemoveBasketAdjustment to propagate the backdated modifications for the future adjustments.
			@param key contains the key of the created/modified/deleted adjustment.
			@param newComponentList only used for creation and modification (otherwise NULL), contains the list of components updated after adjustment.
			@version 7.1.3
			*/
			virtual void UpdateQuantitiesForward(const BasketAdjustmentHistoryMap::key_type& key, const ComponentDetailsList* newComponentList = 0);
#endif
			/**
			* Populates given vector with history of spread modifications from portfolio.
			* @param positionId Return spread modification history only for given portfolio position.
			* @param cpty Only for deals with given counterparty.
			* @param entity Only for deals with given entity.
			* @return true if data is available and unique; false if multiple data is present
			* for given input parameters.
			* @version 5.3.4
			*/
			//bool	GetSpreadAdjustmentHistory(MSpreadAdjustmentHistory & history,
			//					sophis::portfolio::PositionIdent positionId = 0, long cpty = 0, long entity = 0) const;

			virtual double	GetAccountingValue(const market_data::CSRMarketData& context) const;
			virtual double	GetLegAccountingValue(const market_data::CSRMarketData& context, int which) const;

			virtual	double	GetAccruedCoupon(long pariPassuDate, long accruedCouponDate) const;
			virtual	double	GetAccruedCoupon(int whichLeg, long pariPassuDate, long accruedCouponDate) const;
			virtual long	GetAccruedCouponDate(long transactionDate, long settlementDate) const;
			virtual double	GetAccruedCoupon(	long pariPassuDate,
												long accruedCouponDate,
												double price,
												portfolio::eTransactionType transactionType) const;
			virtual double	GetAccruedCoupon(	int whichLeg,
												long pariPassuDate,
												long accruedCouponDate,
												double price,
												portfolio::eTransactionType transactionType) const;
			virtual double GetDuration(const market_data::CSRMarketData &context, int i) const OVERRIDE;
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagram(const sophis::market_data::CSRMarketData& context) const;
			virtual sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagram(const sophis::market_data::CSRMarketData& context, int i) const;
			virtual void	GetSwapInformation(	const market_data::CSRMarketData& context,
												instrument::CSRCashFlowInformationList& receivedLeg,
												instrument::CSRCashFlowInformationList& paidLeg) const;
			virtual	double	GetDelta(const sophis::CSRComputationResults& results, long * instrumentCode )	const OVERRIDE;
			virtual	double	GetGamma(const sophis::CSRComputationResults& results, long * instrumentCode ) const OVERRIDE;
			virtual double	GetVega(const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual	double	GetEquityGlobalDelta( const market_data::CSRMarketData & context ) const;
			virtual	double	GetEquityGlobalGamma( const market_data::CSRMarketData & context ) const;
			virtual void	CorrectDeltaBySmile( const market_data::CSRMarketData &	context, sophis::CSRComputationResults& results ) OVERRIDE;
			virtual double	GetSensitivity(const sophis::market_data::CSRMarketData& context, int whichLeg);
			virtual	double	GetImpliedSpread(const sophis::market_data::CSRMarketData& context, double price, int which) const;

			//virtual int		GetUnderlyingCount() const;
			//virtual long	GetUnderlying(int whichUnderlying) const;
			//virtual int		GetRhoCount() const;
			//virtual long	GetRhoCurrency(int whichUnderlying) const;
			//virtual bool	IsAVegaUnderlying(int whichUnderlying) const;
			//virtual bool	IsADeltaUnderlying(int whichUnderlying) const;
			//virtual bool	IsAnEpsilonUnderlying(int whichUnderlying) const;

			/**
				Get the components fixing dialog.
				@param fixingDate is the fixing date, expressed in number of days since 01/01/1904.
				@return a pointer to the fixing equity dialog object, which must be deleted.
			*/
			virtual  sophis::gui::CSRFitDialog *	new_FixingDialog( long fixingDate ) const;

			/**
			Get the composition dialog for Corporate Action. Opened from Automatic Tickets Dlg
			@param date is the CA date, expressed in number of days since 01/01/1904.
			@param factor is the conversion factor for the stokcs.
			@return a pointer to the fixing equity dialog object, which must be deleted.
			@5.3.6
			*/
			virtual sophis::gui::CSRFitDialog	*new_CorpActionAdjustmentDialog(long sicovam, double factor, long underlyingCode) const;

			sophis::gui::CSRFitDialog	*new_CorpActionAdjustmentDialogBS(long sicovam, double factor, long underlyingCode, long CAid) const;


			/**
			Overloaded from CSRSwap to create automatic ticket for immediate dividend payment.
			@version 5.3.4
			*/
			virtual eAutomaticTicketType	GetAutomaticTicket(	long								date,
																_STL::vector< AutomaticTicket > &	list	) const;

			/** Overloaded from CSRSwap to consider adjustments. It is used in reporting and for automatic tickets to know if there is a coupon to pay
			*/
			virtual bool	GetNextEquityPaymentDate(long calculation_date, long *trade_date, long *settlement_date, double * fixing) const;
			virtual bool	GetNextDividendsPaymentDate(long calculation_date, long *trade_date, long *settlement_date) const;
			virtual bool	GetNextRatePaymentDate(long calculation_date, long *trade_date, long *settlement_date) const;

			/** Overloaded from CSRSwap to consider adjustments in alerts.
			*/
			virtual instrument::SSAlert *NewAlertList(long forecastDate, int *nb) const;

			/** Overloaded to return false for the rate leg as notional may change due to composition change.
			*	@param whichLeg is index of the leg of which the flow type is sought.
			*	@since 5.3.4
			*/
			virtual bool GenerateTicketsInAdvance(int whichLeg) const;
			
			/** For an instrument where SpecialReporting() returns true, this tells whether
			EndReporting() is supposed to fill every field of the PnL on its own
			or is supposed to adjust the results computed internally
			Per default returns eOverloadStandardReporting
			@return an enum telling whether the instrument classes handles the full
			PnL computation by itself or simply adjusts the standard computation
			@see SpecialReporting
			@see EndReporting
			@version 6.0
			*/
			virtual eSpecialReportingType GetSpecialReportingType() const;

			/** Overloaded from CSRSwap to return false in all cases.
			*/
			virtual bool SpecialReporting() const;

			virtual void StartReporting(long reporting_date, long portfolio_id, sophis::portfolio::PSRExtraction extraction) const;

			virtual void Reporting(sophis::portfolio::SSReportingTrade* deal, double &cash) const;

			virtual void EndReporting(TViewMvts * position, double fxOfTheDay) const;

			/** Overloaded from CSRSwap to manage the transaction. It avoids accrued computation.
			*/
			virtual bool SpecialTransaction(sophis::portfolio::CSRTransaction &transaction, RecalculeTransaction type) const;

			/** Overloaded from CSRSwap to manage the transaction. It avoids accrued computation.
			*/
			virtual double GetGrossAmount(const portfolio::CSRTransaction & transaction, double &spotForFees) const;

			/** Handle data specific to Basket Swaps. The rest is left to the base class.
			 * @see CSRSwap::UpdateFromDescription()
			 */
			virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);

			/** Describe data specific to Basket Swaps. The rest is left to the base class.
			 * @see CSRSwap::GetDescription()
			 */
			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			/** INTERNAL.
			 * @version 5.3.4
			 */
			virtual portfolio::CSRExtraPosition* CreatePosition(const TViewMvts *mvts) const;
			/** INTERNAL.
			 * @version 5.3.4
			 */
			virtual bool CreatePosition(void) const;

			/** INTERNAL.
			 * @version 5.3.4.5
			 */
			virtual void GetBasketDescription(tools::dataModel::DataSet& legDataSet) const;

			/** INTERNAL.
			 * Create initial composition, basket fixing, or adjustment.
			 * @version 5.3.6.X
			 * @param legDataSet DataSet of type EquityLeg, with a basket underlyer.
			 */
			virtual void AdjustBasketFromDescription(const tools::dataModel::DataSet& legDataSet);

			/**
			* Type of composition adjustment to be made. Corresponds to an XSD type of the same name.
			* dfNew new adjustment to be made, full composition specified.
			* dfNewByDifference new adjustment to be made, composition is based on previous adjustment's and modifications are made only in composition specified.
			* dfReplace swap existing composition with the specified, if no pair modificationDate/adjOrder is specified or if invalid last adjustment is replaced.
			* dfAmendByDifferenceVsItself modification of adjustment based on existing composition.
			* dfAmendByDifferenceVsPrevious modification of adjustment based on previous adjustment's composition.
			* dfDeleteLast delete last adjustment.
			* dfDelete delete adjustment specified.
			*/
			enum UnderlyerAdjustmentDataFlavour {
				dfNew,
				dfNewByDifference,
				dfReplace,
				dfAmendByDifferenceVsItself,
				dfAmendByDifferenceVsPrevious,
				dfDeleteLast,
				dfDelete
			};

			/**
			* Type of modification to be made on a component's quantity. Corresponds to an XSD type of the same name.
			* opSet sets the quantity to the value specified.
			* opAdd adds to existing quantity the value specified.
			* opMultiply multiplies existing quantity by value specified.
			*/
			enum ConstituentWeightOp {
				opSet,
				opAdd,
				opMultiply
			};

			/**
			* Struct to read composition from XML description.
			* Offers everything ComponentDetails does plus a handful of booleans, mainly to record which elements were present in the XML data.
			*/
			struct ExtendedComponentDetails : public ::sophis::finance::ComponentDetails {
				ExtendedComponentDetails() : ComponentDetails()
					,hadQuantity(false)
					,hadDividend(false)
					,hadFixing(false)
					,hadSpread(false)
					,quantityOp(opSet)
				{}
				bool hadQuantity;
				bool hadDividend;
				bool hadFixing;
				bool hadSpread;
				ConstituentWeightOp quantityOp;	//< contents of constituentWeight/@op
			};
			typedef _STL::vector<ExtendedComponentDetails> ExtComponentDetailsVector;

			/** update spreads and dividend rebates from agreement if no spread and dividen rebates data in xml
			 */
			void UpdateBasketSwapAdjustmentSpreadsAndDividendRebates(const tools::dataModel::DataSet& dataSet,
																     const sophis::collateral::CSRLBAgreement* agreement);

			/** set external references (defined in legDataSet) to the transaction passed as parameter
			 */
			void SetTransactionExternalReferences(const tools::dataModel::DataSet& legDataSet, const sophis::portfolio::CSRTransaction& transaction) const;

			/**
			* Process DartaSet describing the basket adjustment and fill a BasketAdjustmentData and a transaction with the data.
			* adjDataSet XML description of the adjustment information.
			* adjData adjustment where to set the information.
			* trans transaction to be created for the adjustment.
			* @version 7.1.3
			*/
			void GetAdjustmentDetailsFromDescription(const tools::dataModel::DataSet& adjDataSet, BasketAdjustmentData& adjData, portfolio::CSRTransaction& trans);

			/**
			* Process DataSet describing a basket underlyer and fill a ComponentDetailsList with the data.
			* @param basketUnderlyerDS DataSet that should contain a BasketUnderlyer, as defined in instrument.xsd.
			* @param outComponents Any basket constituents found in the data set will be appended to the list.
			* @param fwdNot forward target notional defined in case of forward adjustment/creation.
			* @notCCY forward target notional currency in case of forward adjustment/creation.
			* @version 7.1.3
			*/
			void GetComponentDetailsListFromDescription(const tools::dataModel::DataSet& legDataSet, const tools::dataModel::DataSet& basketUnderlyerDS,
				ExtComponentDetailsVector& outComponents, double &fwdNot , long &notCCY, bool earlyTerminated);

			/**
			* Read line picking information from XML description.
			* @param basketUnderlyer XML description at the level of "basketUnderlyer".
			* @param lpMap empty line picking map to be filled with the information from the description.
			* @version 7.1.3
			*/
			void GetLinePickingFromDescription(const tools::dataModel::DataSet& basketUnderlyer, LinePickingMap& lpMap);

			/**
			* Converts composition of type ExtComponentDetailsVector read from description to ComponentDetailsList compatible with CSRBasketSwap methods.
			* Also checks that no differential operators are used for the quantities (not allowed in absolute composition, not based on previous composition).
			* extComponents composition read from the description.
			* out resulting composition.
			* @throw {@link sophisTools::base::InvalidArgument}
			* @version 7.1.3
			*/
			void ProcessAbsoluteComposition(const ExtComponentDetailsVector& extComponents, ComponentDetailsList& out);

			/** Overloaded from CSRSwap to update value date of basket creation.
			*/
			virtual void SetSettlementAtDPlus(const int value);

			/** INTERNAL.
			//virtual void UpdateImportedBasketSwapTransaction(sophis::portfolio::CSRTransaction& tr) const;
			* @note Called from Sophis.dll (that is why it is virtual).
			*		Fills the transaction's commission with the spread of the lfFloating leg.
			*		Also sets the reference field (adds tagTradeRef to #event if non-null instead of modifying #tr directly).
			* @version 5.3.6
			*/
			virtual void UpdateImportedBasketSwapTransaction(sophis::misc::CSREvent& event) const;

			/** INTERNAL.
			* @note Called from Sophis.dll (that is why it is virtual).
			* @note If non-null #event is given, tags in it are used instead of the values in #tr.
			* @warning The function assumes #tr is on 'this' instrument and does not check this.
			* @version 5.3.6
			*/
			virtual bool IsBasketSwapInitialTransaction(const sophis::misc::CSREvent* event = 0) const;

			/** INTERNAL.
			* @note Called from Sophis.dll (that is why it is virtual).
			* @note This is useful in the tradepersistence to check the type before the transaction has been parsed.
			* @version 6.2
			*/
			virtual bool IsBasketSwapInitialTransaction(const sophis::portfolio::CSRTransaction &transaction) const;

			/** INTERNAL.
			 * @note Called from Sophis.dll (that is why it is virtual).
			 * @note If non-null #event is given, tags in it are used instead of the values in #tr.
			 * @warning The function assumes #tr is on 'this' instrument and does not check this.
			 * @version 5.3.6
			 */
			virtual bool IsBasketSwapSpreadModification(const sophis::misc::CSREvent* event = 0) const;

			/** INTERNAL.
			* @note Called from Sophis.dll (that is why it is virtual).
			* @note This is useful in the tradepersistence to check the type before the transaction has been parsed.
			* @version 6.2
			*/
			virtual bool IsBasketSwapSpreadModification(const sophis::portfolio::CSRTransaction &transaction) const;

			/**
			@version 5.3.6.
			*/
			virtual sophis::instrument::eSplitActionType Split(long splitDate, long underlyingCode) const;

			/**
			@version 5.3.6.
			*/
			virtual bool SplitDone(long date_split, long underlying_id, double factor) const;

			/**
			@version 5.3.6.
			*/
			virtual bool MergeDone(long mergeDate, long oldUnderlyingCode, long newUnderlyingCode) const;

			/**
			@version 5.3.6.
			*/
			long NewBasketAdjustment(long number, long code) const;

			/**
			@version 5.3.6.
			*/
			bool IsSicovamInLastBasketAjustment(long sicovam, long date, bool cheQuantity = true) const;
			bool IsCAAdjustment(long sicovam, long caID, long date) const;

			/** Factory method, instantiate the appropriate CA strategy and applies the tranformation
			@param adjustmentId: identifier of the Corporate Action (refcon from ajustments table)
			@param CAid: identify what kind of corporate action has to be applied
			@param basketSwapManagerList: a list which stores instances of CSRBasketSwapManager to be deleted after the messages have been run
			@version 5.3.6.
			*/
			bool CADone(long adjustmentId, long CAid, sophis::tools::CSRTransactionEventVector &messages, _STL::list<CSRBasketSwapManager*> *basketSwapManagerList) const;

			/** Generate coupons tickets for the Merger CA
			@param adjustmentId: identifier of the Corporate Action (refcon from ajustments table)
			@version 5.3.6.
			*/
			bool GenerateExtraTickets(long adjustementId, long corpActionType) const;

			/**
			@version 5.3.6.
			*/
			virtual bool Merge(long mergeDate, long underlyingCode) const;


			/** Enum for TRS business events.
			*/
			enum	{
				eEquityIncome,
				eDividendIncome,
				eInterestIncome,
				eSwapBooking,
				eSwapExpiry,
				eSwapRedemption,
				eSwapBasketAdjustment,
				eSwapSpread,
				eSwapCAAdjustment,
				eLastIncome
			};

			/** Array filled when the reporting starts to be able
			to split the income in the TRS column.
			*/
			static int gBusinessEvent[eLastIncome];

			/** Returns the default Interest Rate taken from Extra Funding settings.
			 *  In case it is interpolated it returns the closer Interest Rate in the list.
			 @param valueDate, the value date of the adjustment needed to get the correct Interest Rate from the interpolated list (if necessary).
			 @return code of the Interest Rate to be used in Extra Funding.
			 @version 6.2.1
			 */
			long GetRateFromInterpolated(long valueDate=0) const;

			/** Updates Basket Creation modification and value date to suit swap start date. Basket Creation must be the only existing adjustment.
			* @param newDate new swap start date.
			* @version 5.3.7
			*/
			void OnSwapStartDateModification(long newDate);

			/** Return line picking information
			* @version 5.3.7
			*/
			const LinePickingMap& GetLinePickingMap() const;

			/** Returns line picking information for specific basket adjustment
			* @param adjustmentId Adjustment which line picking to return
			* @param lp Output map to fill
			* @version 5.3.7
			*/
			void GetLPForAdjustment(long adjustmentId, LinePickingMap& lp) const;

			/** Sets line picking for specific adjustment and component
			* To reset line picking for component just pass empty map
			* @param adjustment_id Adjustment where component was decreased
			* @param sicovam Instrument id of the component
			* @param lp New line picking information
			* @version 5.3.7
			*/
			void SetLPForComponent(long adjustment_id, long sicovam, const LinePickingData& lp);

			/** Sets line picking for every adjustment in the map
			* Be carefull, for every unique adjustment (LinePickingMap::key_type.first) line picking is reseted.
			* To set line picking for the whole adjustment lp should have the same adjustment_id in all keys.
			* @param lp New line picking information
			* @version 5.3.7
			*/
			void SetLPForAdjustment(const LinePickingMap& lp, long adjustmentId);

			/** This method is called before calling GetTheoreticalValue or RecomputeAll and can be used if the pricing depends on the position.
			For TRS, this is used to set the spread set at the trade level.
			@version 6.3.2
			*/
			//virtual void SetMvtBeforePricing(const TViewMvts * position) const;

			/** This method returns the forex between two currencies checking if the basket swap is quanto model.
			* @param context is the context which contains the reporting date and is used to calculate the forex.
			* @param currency1 is the first currency.
			* @param currency2 is the second currency.
			* @version 7.1
			*/
			double GetForex(const market_data::CSRMarketData& context,
							long currency1,
							long currency2,
							const ISRBasketSwapIO& io) const;

			/** Set line picking map.
			* @version 7.1.1
			*/
			void SetLinePickingMap(LinePickingMap& linePickingMap) { fLinePickingMap = linePickingMap; }

			/** Get the list of dividends to be taken into account in calculations and forecast on top of the list of dividends taken from the instrument.
			* @param inst is the component from what the dividends are taken.
			* @param startDate is the start date of the period to be calculated.
			* @param endDate is the end date of the period to be calculated.
			* @param settlementType is the type of settlement.
			* @param param is the market data.
			* @param percent is the tax credit percentage type.
			* @param dividendList is the list of dividends returned to be added on top of Dividends Table of the instrument.
			* @version 7.1.1
			*/
			virtual void GetExtraDividends(const sophis::instrument::CSRInstrument& inst, long startDate, long endDate, sophis::instrument::eSettlementType settlementType, const market_data::CSRMarketData & param, market_data::eTaxCreditPercentageType percent, _STL::vector<instrument::SSDividendArray>& dividendList) const;

			/* When set to true, components fixings and forex are calculated following settings in advanced tab.
			* @version 7.1.2
			*/
			mutable bool fUseContractualFixings;

			/**
			 * Must create line data object to display in the basket adjustment history.
			 * @param hierLevel Hierarchy level.
			 * @param lineData Basic structure containing pre-computed results.
			 * @version 7.1.2
			 */
			virtual CSRBasketAdjustmentDataLineData* new_BasketAdjustmentDataLineData(eBasketSwapAdjustmentHistoryHierLevel hierLevel,
				const BasketAdjustmentDataLineData& lineData) const;

			// INTERNAL
			inline const std::map<long, std::vector<instrument::SSBasket> >& GetBasketMembers() const;

			// INTERNAL
			mutable long fOnlyConsiderThisUnderlying;

#ifndef GCC_XML
			/**
			 * INTERNAL. Used for storing collection of CSRBasketSwap derived instruments.
			 */
			static _STL::set<_STL::string>& GetBasketSwapModels();
#endif

			/** When a Basket Swap is created modifying the reference of an existing one, this method is triggered.
			* It deletes all basket adjustments except creation, which is assigned a new code.
			* @version 7.1.2
			*/
			void UpdateAdjustmentsForClonedSwap();

			void GetEarlyTerminationDate(long calculationDate, /*out*/ long& modificationDate, /*out*/ long& valueDate) const;
			bool IsEarlyTerminated() const;

			static void PrepareCalendarList(_STL::vector<sophis::static_data::CSRCalendar *> & calendarList, const CSRInstrument * instrument, short * maxLag);

			static bool IsSameCalendar(const sophis::static_data::CSRCalendar * cal1, const sophis::static_data::CSRCalendar * cal2);

			static short GetCalendarsMaxLag(const ComponentDetailsList & componentsList, SW_Donne* dlgData);

			void ChangeOrder(  sophis::portfolio::CSRTransaction * transaction, int newOrder) ;
		protected:

			/** returns an object to handle reporting of Floating Asset Total Return Swaps
			* @param eoy_date is the end of year date
			* @param reporting_date is the reporting date
			* @param extraction is the the extraction which is reported.
			* @param portfolio_id is the portfolio ID (or the virtual portfolio ID)
			* @param accrued_date is the accrued date of the swap
			*  is accrued_date = -1, we take the start date of the next asset flow as accrued date
			* @since 5.3
			*
			*virtual instrument::CSRSwapSpecialReporting* new_CSRSwapSpecialReporting(	long 						reporting_date,
			*																			portfolio::PSRExtraction	extraction,
			*																		long 						portfolio_id,
																					long 						accrued_date) const;*/


			/**
			* Returns the index on the basket components list of the requested component
			* @param basketID: id of the adjustment
			* @param sicovam: id of the component
			* @return the index of the component in the component list. -1 if not found
			* @version 5.3.6
			*/
			int GetComponent(long basketID, long sicovam) const;

			/**
			* Internal only
			* @version 5.3.6
			*/
			void HackBasketAdjustForDisplayOnly(BasketAdjustmentData& adjData, long underlyingCode, double factor) const;

			/**
			* Changes the quantity of the specified component according to the factor. Used for display purposes in case of
			* for Corporate Action Automatic Tickets (Internal only)
			* @param adjCode: id of the adjustment
			* @param sicovam: id of the component
			* @param factor: conversion factor
			* @version 5.3.6
			*/
			void ChangeComponentQuantity(long adjCode, long sicovam, double factor) const;

			bool	fIsPriceReturnSwap;

			/* This method compares the root name of an imported XML with the XML name of the instrument to be modified.
			@param rootName is the string containing the root of the XML imported to Risk.
			@param instrumentName is the XML name of the instrument.
			@return true if the imported XML root name is equal to the instrument XML name false if they are different.
			@since 6.2
			*/
			virtual bool IsXMLRootNameSuitable(const char* rootName, const char* instrumentName=0) const;

		protected:
			//mutable int fOptimiserCounter;
			//mutable _STL::map<long,double> fDeltaSOptim;
			//mutable _STL::map<long,_STL::map<long, double> > fDeltaFwdOptim;

			/**
				INTERNAL.
				@version 5.3
			*/
			//mutable long fOnlyConsiderThisUnderlying;

			/**
				INTERNAL.
				@version 5.3
			*/
			std::set<long> fBasketList;
			std::map<long, std::vector<instrument::SSBasket> > fBasketMembers; // key is the risk source
			bool fSplitGreeks;

			/**
				INTERNAL.
				@version 5.3
			*/
			MSpreadHistoryPerComponent			fCurrentSpreadList; // sicovam, spreadList

			bool fIsSpreadDefined;

			/**
				INTERNAL.
				@version 5.3.4
			*/
			BasketAdjustmentHistoryMap			fAdjustmentList;

			/**
			INTERNAL.
			@version 5.3.4
			*/
			// Vector of ComponentDetails which should be always kept ordered by fSwapId (adjustment id).
			mutable ComponentDetailsList				fComponentList;
			typedef _STL::map<long,double> SplitFactors;
			typedef _STL::map<long,SplitFactors> SplitFactorsMap;
			SplitFactorsMap fSplitFactorsMap;
			void RebuildSplitInfo();
			_STL::map<long,long> fUnderlyingVersion;
			_STL::map<long,long> fRiskSourcesVersion;
			LinePickingMap fLinePickingMap;

			/** Used as cache to show the notional in the portfolio. Storing notional per date.
			*/
			mutable _STL::map<long,double> fCurrentNotional;

			friend class ::CSRFixingListComputation;
			friend class sophis::instrument::CSRInstrument;
			friend class ::CSRBasketSwapSpecialReporting;

		private:
			mutable sophis::portfolio::PSRExtraction fExtraction;
			mutable CSRBasketSwap::DetailledReporting	fExplanation;
			mutable double fUpfrontInAveragePrice;
			mutable double fUpfrontInAveragePriceCCY;
			mutable double fFullyFundedInit;
			mutable double fFullyFundedInitCCY;
			mutable bool fIsFullyFunded;
			mutable bool fStockLoanForecast;
			mutable long fReportingDate;

			//DEPRECATED_METAMODEL void GetDeltaAndForwardAnalysis(double &deltaS, _STL::map<long, double> &deltasFwd, long indexCode, const market_data::CSRMarketData &param) const;
		};

		inline const std::map<long, std::vector<instrument::SSBasket> >& CSRBasketSwap::GetBasketMembers() const { return fBasketMembers; }

		/**
			Prototype class for the handling of Reporting Method implementations (FIFO, LIFO, WAP...).
			@version 5.3.7
		*/
		class SOPHIS_FINANCE CSRBasketSwapReportingMethod
		{
		public:

			/** Destructor. */
			virtual ~CSRBasketSwapReportingMethod() {}

			/**
			 * Clone method needed by the prototype. To be implemented by derived classes.
			 * Usually, it is done automatically by the macro DECLARATON_BASKETSWAP_REPORTINGMETHOD.
			 * @see tools::CSRPrototype
			 */
			virtual CSRBasketSwapReportingMethod* Clone() const = 0;

			/**
			 * Typedef for the prototype, the key is a const char*.
			 */
			typedef tools::CSRPrototypeWithId<CSRBasketSwapReportingMethod, const char*, sophis::tools::less_char_star> prototype;

			/**
			 * Access to the prototype singleton.
			 * To add a trigger to this singleton, use INITIALISE_BASKETSWAP_REPORTINGMETHOD.
			 * @see tools::CSRPrototype
			 */
			static prototype& GetPrototype();

			/**
			 * Modifies the quantities in the list of components received as parameter, until all "quantity" is redeemed.
			 * @param necessaryDataList is the list containing the component's explanations in chronological order, the field quantity must be modified with the new quantity.
			 * @param quantity is the quantity decreased that needs to be redeemed.
			 */
			virtual void DecreaseComponent(_STL::list<IncreaseDecreseForReporting::NecessaryData>& necessaryDataList, double quantity, const LinePickingData& linePicking) const = 0;

 			/** Get the id.
			Used when building the ids from names by {@link CSUReorderColumns}
			*/
			int GetId() const
			{
				return fId;
			}


 			/** Set the id.
			Used when building the ids from names by {@link CSUReorderColumns}
			*/
			void SetId(long id)
			{
				fId = id;
			}

		protected:
			long	fId;
		};
	}
}
SPH_EPILOG

#endif //!_SphBasketSwap_H_
