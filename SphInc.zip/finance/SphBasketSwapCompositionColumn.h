#pragma once

#include "SphInc/gui/SphEditList.h"

#define	INITIALISE_BASKET_COMPOSITION_COLUMN(derivedClass, name) derivedClass::GetFactory()[name] = &derivedClass::CreateInstance;

#define DECLARATION_BASKET_COMPOSITION_COLUMN(derivedClass) \
	static CSRBasketCompositionColumn* CreateInstance(sophis::gui::CSREditList* editList, int colId) \
	{ return new derivedClass(editList, colId); }
					

namespace sophis {
namespace finance {	

class SOPHIS_FINANCE CSRBasketCompositionColumn : public sophis::gui::SSColumn
{
public:

	/**
	   Standard columns that can be used inside LoadLine.
	*/
	enum EBAColumns 
	{
		ebacInstrument	= 0,
		ebacInstrumentName,
		ebacCCY,
		ebacQuantity,
		ebacDiffQuantity,
		ebacDiffQuantityPC,
		ebacNomWeight,
		ebacDividend,
		ebacFixing,
		ebacAdjFixing,
		ebacFxFixing,
		ebacSpread,
		ebacSpreadAdj,
		ebacDivEligibility,
		ebacAccrued,
		ebacQuotationType,
		ebacLinePicking,
		ebacLast
	}; 

	
	CSRBasketCompositionColumn();
	virtual ~CSRBasketCompositionColumn();

	typedef CSRBasketCompositionColumn* (*creator)(sophis::gui::CSREditList* editList, int colId);
	static std::map<std::string, creator>& GetFactory();	
	
	virtual bool LoadLine(int lineIndex) const;
	virtual bool SaveLine(int lineIndex);

	// Internal
	void SetDeleteElement(bool b);
	void SetBasketSwapCode(long basketSwapCode);

protected:
	bool fDeleteElement;
	long fBasketSwapCode;
};

}}
