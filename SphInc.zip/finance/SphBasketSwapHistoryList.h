#ifndef _BASKETSWAP_HISTORY_LIST_H
#define _BASKETSWAP_HISTORY_LIST_H

#include "SphInc/finance/SphBasketSwap.h"
#include "SphInc/finance/SphBasketSwapTab.h"

#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

namespace sophis {
	namespace finance {
class CSRBasketSwapSpecific;

/**
 * Structure representing line data inside the TRS Basket Swap history list.
 * @version 5.3.4
 * @version 7.1.1 In the SphInc
 */
struct SOPHIS_FINANCE BasketAdjustmentDataLineData
{
public:
	BasketAdjustmentDataLineData() {Reset();}
	void Reset(long swapCurrency=0);

	enum  AssetChangeNature
	{	
		eAssetChange_Undefined = 0,
		eAssetChange_NotModified,
		eAssetChange_Added,
		eAssetChange_Deleted,
		eAssetChange_Modified,
		eAssetChange_IncreasedShort,
		eAssetChange_DescreasedShort,
		eAssetChange_IncreasedLong,
		eAssetChange_DescreasedLong,
		eAssetChange_Crossing
	} fType;

	enum AdjustmentNature
	{	
		eBasketAdjustment_Undefined = 0,
		eBasketAdjustment_Creation,
		eBasketAdjustment_NoAccruedPayment,
		eBasketAdjustment_RealizedPayment,
		eBasketAdjustment_SyntheticReset,
		eBasketAdjustment_Reset,	
		eBasketAdjustment_ResetGenerated,	
		eBasketAdjustment_CreationCurrent,
		eBasketAdjustment_NoAccruedPaymentCurrent,
		eBasketAdjustment_RealizedPaymentCurrent,
		eBasketAdjustment_SyntheticResetCurrent,
		eBasketAdjustment_ResetCurrent,	
		eBasketAdjustment_ResetGeneratedCurrent,	
		eBasketAdjustment_Accrued,
		eBasketAdjustment_Merger,
		eBasketAdjustment_Demerger,
		eBasketAdjustment_Split,
		eBasketAdjustment_Forward,
		eBasketAdjustment_ForwardCurrent,
		eBasketAdjustment_ForwardFixed,
		eBasketAdjustment_ForwardFixedCurrent,
		eBasketAdjustment_RateOnly,
		eBasketAdjustment_RateOnlyCurrent,
		eBasketAdjustment_PerfOnly,
		eBasketAdjustment_PerfOnlyCurrent,
		eBasketAdjustment_PerfOnlyGenerated,
		eBasketAdjustment_PerfOnlyGeneratedCurrent,
		eBasketAdjustment_FreeAttribution,
		eBasketAdjustment_EarlyTermination
	} fCouponType;

	long fSicovam;
	double fQuantity;
	double fFixing;
	double fAdjFixing;
	double fFx_fixing;
	long fOldBasketComponentsID;
	long fNewBasketComponentsID;
	long fOriginalModificationDate;
	long fModificationDate;
	long fValueDate;
	int	fOrder;

	long	fSwapCurrency;
	long	fComponentCurrency;
	long	fDivCurrency;
	long	fDate;
	long	fPaymentDate;
	double	fCouponPerformance;
	double	fPerformance;
	double	fRealized;
	double	fUnrealized;
	double	fRealizedUnpaid;
	double	fCompoSecurityFixing;
	double	fAdjCompoSecurityFixing;
	double	fSpot;
	double	fFXSpot;
	double	fCompoSpot;
	double	fNotionalEq;
	double	fNotionalFina;
	double	fIRCouponEq;
	double	fIRCouponFina;
	double	fTotalInterestValueEq;
	double	fTotalInterestValueFina;
	double	fTotalInterestValueAll;
	double	fTotalSpreadValueFina;
	double	fTotalSpreadValueEq;
	double	fTotalSpreadValueAll;
	double	fTotalInterestRateValueFina;
	double	fTotalInterestRateValueEq;
	double	fTotalInterestRateValueAll;
	double	fInterestUnpaidEq;
	double	fInterestUnpaidFina;
	double	fRateFixing;
	long	fIRDayCount;
	double	fDiffQuantity;
	double	fPercentageRemoved;
	double	fAveragePrice;
	double	fAverageSpread;
	double	fAverageFundingSpread;
	double	fCouponAmount;
	int		fNumberOfRebates;
	double	fRebateRatio;
	_STL::string	fCountry;
	sophis::finance::SpreadResetEnum::Enum  	fSpreadAdj;
	double	fBorrowSpread; // has fSpot and fDiffQuantity, it's a component's data
	double  fFundingSpread;
	double	fBorrowSpreadInterests;
	double  fFundingSpreadInterests;
	long    fSpread_adj_type;
	long    fSpreadEndDate;
	double  fUpfrontFees;

	double fExtraFundingValue;
	double fGrossPerformance;
	double fCommissions;

	double fTargetNotional;
	double fNomWeight;
	int		fDivEligibility;

	int		fExtraFundingDayCount;
	long	fExtraFundingStart;
	long	fExtraFundingEnd;
	double	fExtraFundingSpread;
	long	fExtraFundingFixindDate;

	double	fAccrued;
	int		fQuotationType;
	double	fDailyMarginInterest;
	bool    fIsResetDate;

	sophis::portfolio::TransactionIdent fTicketID;
	_STL::string fStatus;
};

/// forward declaration
class CSRBasketAdjustmentDataLineData;

/**
 * TRS Basket Swap history list.
 * @version 5.3.4
 * @version 7.1.1 In the SphInc
 */
class SOPHIS_FINANCE CSRBasketSwapHistory
{
public:
	CSRBasketSwapHistory();
	CSRBasketSwapHistory(sophis::portfolio::PositionIdent positionId);
	void Initialize(sophis::portfolio::PositionIdent positionId);
	CSRBasketSwapHistory(const sophis::finance::CSRBasketSwapSpecific * dlg);
	void Initialize(const sophis::finance::CSRBasketSwapSpecific * dlg);
	~CSRBasketSwapHistory();

	long GetFirstCode();

#ifndef GCC_XML
	/** Obsolete 7.1.2, use sophis::finance::eBasketSwapAdjustmentHistoryHierLevel
	enum eBasketSwapAdjustmentHistoryHierLevel
	{
	};
	*/
	static sophis::finance::eBasketSwapAdjustmentHistoryHierLevel eBasketSwapAdjustmentHistoryHierLevel_DateGroup;
	static sophis::finance::eBasketSwapAdjustmentHistoryHierLevel eBasketSwapAdjustmentHistoryHierLevel_Adjustment;
	static sophis::finance::eBasketSwapAdjustmentHistoryHierLevel eBasketSwapAdjustmentHistoryHierLevel_Explanation;

	/** Obsolete 7.1.2, use CSRBasketAdjustmentDataLineData. */
	struct BasketAdjustmentLine
	{
		BasketAdjustmentLine(const eBasketSwapAdjustmentHistoryHierLevel& _first, const BasketAdjustmentDataLineData& _second) : first(_first), second(_second) {}
		const eBasketSwapAdjustmentHistoryHierLevel& first;
		const BasketAdjustmentDataLineData& second;
	};
#endif // GCC_XML

	typedef _STL::vector< CSRBasketAdjustmentDataLineData* > BasketAdjustmentChanges;

	_STL::string GetLineName(const CSRBasketAdjustmentDataLineData& line) const;

	void FillData(const CSRBasketSwap& swap,
				  long filter, // 0 means no filter
				  long dealStatusFilter, // 1 means all status
				  bool useContractualFixings);

	/** Clears fBasketAdjustmentHistory and fAdjustments. */
	void Clear();

	BasketAdjustmentChanges							fBasketAdjustmentHistory;
	sophis::portfolio::PositionIdent fPositionID;
	const sophis::finance::CSRBasketSwapSpecific *	fDlg;
	BasketAdjustmentHistoryMap						fAdjustments;

	void SetDisplayExplanations(bool val) { fIsDisplayExplanations = val; }
	void SetDisplayAllHistory(bool val) { fIsDisplayAllHistory = val; }

private:
	bool fIsDisplayExplanations;
	bool fIsDisplayAllHistory;
};

/**
 * Wrapper interface around BasketAdjustmentDataLineData structure.
 * @version 7.1.2
 */
class SOPHIS_FINANCE CSRBasketAdjustmentDataLineData
{
public:
	virtual ~CSRBasketAdjustmentDataLineData() {};
	virtual BasketAdjustmentDataLineData& operator*() = 0;
	virtual CSRBasketAdjustmentDataLineData* Clone() const = 0;

	// deliberately non-virtual, provided for convenience (no need to const_cast)
	BasketAdjustmentDataLineData* operator->()				{ return &**this; }
	const BasketAdjustmentDataLineData& operator*() const	{ return const_cast<CSRBasketAdjustmentDataLineData*>(this)->operator*(); }
	const BasketAdjustmentDataLineData* operator->() const	{ return const_cast<CSRBasketAdjustmentDataLineData*>(this)->operator->(); }

	const BasketAdjustmentDataLineData& GetLineData() const	{ return const_cast<CSRBasketAdjustmentDataLineData*>(this)->operator*(); }

	eBasketSwapAdjustmentHistoryHierLevel GetHierLevel() const { return fHierLevel; }

protected:
	CSRBasketAdjustmentDataLineData() {}
	CSRBasketAdjustmentDataLineData(const CSRBasketAdjustmentDataLineData& copy) : fHierLevel(copy.fHierLevel) {}
	CSRBasketAdjustmentDataLineData(eBasketSwapAdjustmentHistoryHierLevel hierLevel) { Initialize(hierLevel); }
	void Initialize(eBasketSwapAdjustmentHistoryHierLevel hierLevel) { fHierLevel = hierLevel; }
	eBasketSwapAdjustmentHistoryHierLevel fHierLevel;
};

/**
 * Wrapper class template around any struct derived from BasketAdjustmentDataLineData (or itself).
 * @param T struct/class derived from BasketAdjustmentDataLineData, must be copy-constructible.
 * @version 7.1.2
 * @note Since this is a template, it is deliberately not tagged SOPHIS_FINANCE.
 */
template<typename T>
class CSRBasketAdjustmentDataLineDataImpl : public CSRBasketAdjustmentDataLineData
{
public:
	/** Passed line data must actually a reference to T. */
	CSRBasketAdjustmentDataLineDataImpl(eBasketSwapAdjustmentHistoryHierLevel hierLevel,
		const BasketAdjustmentDataLineData& lineData) : CSRBasketAdjustmentDataLineData(hierLevel), fLineData(static_cast<const T&>(lineData)) { }
	virtual ~CSRBasketAdjustmentDataLineDataImpl() {}
	virtual T& operator*() { return fLineData; }
	virtual CSRBasketAdjustmentDataLineDataImpl* Clone() const { return new CSRBasketAdjustmentDataLineDataImpl(*this); }

	// deliberately non-virtual, ones from base class are hidden
	T* operator->()				{ return &**this; }
	const T& operator*() const	{ return const_cast<CSRBasketAdjustmentDataLineDataImpl*>(this)->operator*(); }
	const T* operator->() const	{ return const_cast<CSRBasketAdjustmentDataLineDataImpl*>(this)->operator->(); }

protected:
	CSRBasketAdjustmentDataLineDataImpl(const CSRBasketAdjustmentDataLineDataImpl &copy) : CSRBasketAdjustmentDataLineData(copy), fLineData(copy.fLineData) {}
	T fLineData;
};

SOPHIS_FINANCE long GetBasketSwapSpreadAccuracy();

/**
 * Macros for handling Basket Swap tab context menu prototype implementation.
 * @param derivedClass is the name of the client custom context menu class.
 * @version 7.1.3
 */
#define DECLARATION_BASKET_SWAP_TAB_CONTEXT_MENU(derivedClass) DECLARATION_PROTOTYPE(derivedClass, sophis::finance::CSRBasketSwapTabContextMenu)
#define CONSTRUCTOR_BASKET_SWAP_TAB_CONTEXT_MENU(derivedClass)
#define WITHOUT_CONSTRUCTOR_BASKET_SWAP_TAB_CONTEXT_MENU(derivedClass)
#define	INITIALISE_BASKET_SWAP_TAB_CONTEXT_MENU(derivedClass, name) INITIALISE_PROTOTYPE(derivedClass, name)

/**
 * Interface for creating custom context menu in Basket Swap tab.
 * The key string of the derived element is displayed in the menu.
 *
 * Note that menu items on the dialog appear in the order they are registered within the application.
 * Also, the order is not stored in the COLUMN_NAME table but is decided at run-time.
 *
 * @version 7.1.3
 */
class SOPHIS_FINANCE CSRBasketSwapTabContextMenu
{
public:

	/** 
	 * Typedef for the prototype : the key is a string.
	 */
	typedef tools::CSRPrototype<CSRBasketSwapTabContextMenu, const char*, tools::less_char_star> prototype;

	/** 
	 * Access to the prototype singleton.
	 * To add a trigger to this singleton, use appropriate derived class INITIALISE_XXX_CONTEXT_MENU.
	 */
	static prototype& CSRBasketSwapTabContextMenu::GetPrototype();

	/**
	* Clone interface required for the prototype and toolkit wrapper.
	*/
	virtual CSRBasketSwapTabContextMenu* Clone() const = 0;

	/** 
	 * This function is called when opening the dynamic context menu. 
	 * If IsAuthorized returns true, the key of the prototype (that is its name) is added in the context menu.
	 * Must be overloaded and implemented in custom classes.
	 * @param is the basket adjustment information from the line selected.
	 * @return true to include the prototype in the context menu, false to skip it.
	 */
	virtual bool IsAuthorized(const CSRBasketAdjustmentDataLineData& resultList) const { return true; }

	/** 
	* This function is called when opening the dynamic context menu. 
	* If IsEnabled returns true, the key of the prototype (that is its name) is enabled in the context menu.
	* User should generally override IsEnabled().
	* @param swapDialog is the CSRInstrumentDialog of the basket swap tab.
	* @param resultList is the basket adjustment information from the line selected.
	* @return true to enabled the prototype in the context menu, false to disable it.
	*/
	virtual bool IsEnabled(CSRBasketSwapSpecific& swapDialog, const CSRBasketAdjustmentDataLineData& resultList) const { return true; }

	/**
	 * Perform some action (like open a specific dialog) using the given results line.
	 * Must be overloaded and implemented in custom classes.
	 * @param swapDialog is the CSRInstrumentDialog of the basket swap tab.
	 * @param resultList is the basket adjustment information from the line selected.
	 * @return true to indicate action was performed, false otherwise.
	 */
	virtual bool DoBasketSwapTabContextMenu(CSRBasketSwapSpecific& swapDialog, const CSRBasketAdjustmentDataLineData& resultList) const { return false; }

	/**
	 * Allows to group context menu items in the specified order.
	 * Items in different groups will be separated by a separator.
	 * Groups 0 to 9 are reserved by Sophis.
	 */
	virtual long GetContextMenuGroup() const { return 0; }

};

	} // finance
} // sophis

SPH_EPILOG

#endif