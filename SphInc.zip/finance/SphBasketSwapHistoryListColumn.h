#ifndef _BASKETSWAP_HISTORY_LIST_COLUMN_H
#define _BASKETSWAP_HISTORY_LIST_COLUMN_H

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#include __STL_INCLUDE_PATH(string)
#include "SphInc/finance/SphBasketSwapHistoryList.h"

SPH_PROLOG

/**
 * Macros for handling basket swap TRS history column prototype implementation.
 */
#define DECLARATION_BASKET_ADJUSTMENT_HISTORY_LIST_COLUMN(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::finance::CSRBasketAdjustmentHistoryListColumn)
#define CONSTRUCTOR_BASKET_ADJUSTMENT_HISTORY_LIST_COLUMN(derivedClass)
#define WITHOUT_CONSTRUCTOR_BASKET_ADJUSTMENT_HISTORY_LIST_COLUMN(derivedClass)
#define	INITIALISE_BASKET_ADJUSTMENT_HISTORY_LIST_COLUMN(derivedClass,name)		INITIALISE_PROTOTYPE(derivedClass, name)

union SSCellValue;
struct SSCellStyle;

namespace sophis
{
	namespace finance {
	
	/**
	 * Column definition and prototype in basket swap TRS history.
	 */
	class SOPHIS_FINANCE CSRBasketAdjustmentHistoryListColumn
	{
	public:
		/** 
		 * Typedef for the prototype : the key is a const char*.
		 */
		typedef tools::CSRPrototypeWithId<CSRBasketAdjustmentHistoryListColumn, const char*, tools::less_char_star> prototype;
		
		/** 
		 * Main method to display the content.
		 * Must be implemented in derived classes.
		 * @param basketSwap BasketSwap instrument.
		 * @param line Corresponding line in the history.
		 * @param cellValue An output parameter, used to return the value to be displayed.
		 * @param cellStyle An output parameter, used to describe the style and the data type.
		 * @version 7.1.2
		 */
		virtual	void GetCell(const CSRBasketSwap &basketSwap, const CSRBasketAdjustmentDataLineData &line,
			SSCellValue *cellValue, SSCellStyle *cellStyle) const;

	protected:
#ifndef GCC_XML
		/**
		 * @obsolete 7.1.2 Use GetCell() with CSRBasketAdjustmentDataLineData
		 * Main method to display the content.
		 * Must be implemented in derived classes.
		 * @param basketSwap BasketSwap instrument.
		 * @param line Corresponding line in the history.
		 * @param value An output parameter, used to return the value to be displayed.
		 * @param style An output parameter, used to describe the style and the data type.
		 */
		virtual	void GetCell(const CSRBasketSwap &basketSwap, const CSRBasketSwapHistory::BasketAdjustmentLine &line,
			SSCellValue *value, SSCellStyle *style) const;
#endif // GCC_XML

	public:
		/**
		 * Clone interface required for the prototype and toolkit wrapper.
		 */
		virtual CSRBasketAdjustmentHistoryListColumn* Clone() const = 0;

		/** 
		 * Returns the default cell size in pixels.
		 */
		virtual short GetDefaultWidth() const;

		/**
		 * Returns icon that is displayed in tree view.
		 */
		virtual short GetIconId() const;

		/**
		 * Returns the id.
		 * The value is created at the end of the initialise because it must
		 * be unique according to the table COLUMN_NAME.
		 */
		int GetId() const
		{
			return fId;
		}

		/**
		 * Sets the id.
		 * Used when building the columns by {@link CSUReorderColumns}.
		 */
		void SetId(long id)
		{
			fId = id;
		}
		
		/** 
		 * Access to prototype singleton.
		 */
		static prototype& GetPrototype();

		/**
		 * Returns resource id for columns configuration.
		 */
		static long GetColumnsResId();

	protected:
		long fId;
	};

	}
}

SPH_EPILOG

#endif