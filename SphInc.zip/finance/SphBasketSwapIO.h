#pragma once

#ifndef _SphBasketSwapIO_H_
#define _SphBasketSwapIO_H_

#include "SphInc/market_data/SphDataIntegrityManager.h"
#include "SphInc/market_data/SphMarketDataEnums.h"
#include "SphInc/static_data/SphInterestRate.h"
#include "SphInc/static_data/SphCalendar.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/instrument/SphSwapExplanation.h"

#ifndef GCC_XML
namespace sophisTools
{
	template<class T> class ListeVariable;
}
struct flux_jambe;
typedef sophisTools::ListeVariable<flux_jambe> ListeFlux;
struct SW_Donne;
struct jambe;
#endif

namespace sophis {
	namespace finance {

class SOPHIS_FINANCE ISRBasketSwapIO
{
	// Interface between basket swaps and the rest of Sophis. By default use standard Sophis API.
	// Avoid complex Sophis types like CSRInstrument.
	
public:
	virtual void DeclareError(long sicovam,
							  const char* msg,
							  const char* msgType,
							  sophis::dataIntegrity::EMessageLevel level) const;

	virtual long GetCurrentDate() const;

	virtual bool UseCorporateActionsAsDividendsTable() const;

	virtual void GetForwardPrice(const sophis::instrument::CSRInstrument* instr,
								 const long* futureDates,
								 /*out*/std::vector<double>& prices,
								 short dateCount,
								 sophis::market_data::eTaxCreditPercentageType forEvaluation,
								 const sophis::market_data::CSRMarketData& context) const;
	
	virtual double GetTheoreticalValue(const sophis::instrument::CSRInstrument* instr,
									   const market_data::CSRMarketData* context = 0) const;

	virtual const sophis::instrument::CSRInstrument::SSFixing*
		GetFixing(const sophis::instrument::CSRInstrument* instr,
				  long startDate,
				  long endDate,
				  int* elementCount,
				  int tag = -1) const;
	
	virtual sophis::instrument::SSDividendArray * new_DividendArray(
												const sophis::instrument::CSRInstrument* instr,
												long 									beginDate, // delete with delete []
												long 									endDate,
												sophis::instrument::eSettlementType		settlementType,
												const market_data::CSRMarketData		&context,
												market_data::eTaxCreditPercentageType	toEvaluate,
												int										*elementsCount) const;

	// Non virtual on CSRInterestRate
	virtual double GetUniversalCouponRate(
										    const static_data::CSRInterestRate *            rate,
										    const market_data::CSRMarketData				&context,
											long 											startCouponDate,
											long 											endCouponDate,
											const static_data::SSCouponCalculation			&cc_data,
											instrument::CSRCashFlowInformation				*explanation			= 0,
											bool											useConvexityAdjustment	= true,
											bool											isQuanto				= false,
											long											currency				= 0,
											double											minimum					= NOTDEFINED	,
											double											maximum					= NOTDEFINED) const;

	
	virtual const sophis::instrument::CSRInstrument* GetInstrument(long instrument_id) const;

	virtual const sophis::static_data::CSRDayCountBasis* GetCSRDayCountBasis(sophis::static_data::eDayCountBasisType indexInDatabaseTable) const;

	virtual const sophis::static_data::CSRYieldCalculation* GetCSRYieldCalculation(sophis::static_data::eYieldCalculationType indexInDatabaseTable) const;

	virtual const sophis::static_data::CSRCalendar* GetCSRCalendarForPayment(const sophis::instrument::CSRSwap* swap, int whichLeg) const;

 	virtual const sophis::static_data::CSRCalendar* GetCSRCalendarForRolling(const sophis::instrument::CSRSwap* swap, int whichLeg) const;

	virtual const sophis::instrument::CSRForexSpot* GetCSRForexSpot(long currency1, long currency2) const;

#ifndef GCC_XML					
	virtual ListeFlux DonneFlux(const jambe& jb,
								const SW_Donne* sw,
								const sophis::instrument::CSRSwap* swap) const;
#endif
};

class SOPHIS_FINANCE ISRBasketSwapIOConstants
{
public:
	static const ISRBasketSwapIO gIO;
};

}}

#endif
