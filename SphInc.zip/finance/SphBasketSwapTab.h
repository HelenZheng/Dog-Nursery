#pragma once
#ifndef _SPHBASKETSWAPTAB_H
#define _SPHBASKETSWAPTAB_H

#ifndef GCC_XML

#include "SphInc\gui\SphButton.h"
#include "SphInc\gui\SphDialog.h"

#include "SphInc\gui\SphInstrumentDialog.h"
#include "SphInc/finance/SphBasketSwap.h"

/// internal
class CSDialogSwapTabs;

namespace sophis{
	namespace gui
	{
		class CSRBasicButton;
	}
	namespace finance{
		/**
		 * TRS Basket Swap tab dialog.
		 *
		 * Use this as part of custom TRS Basket Swap initialization:
		 *		INITIALISE_BASKET_SWAP(MyBasketSwap, "My Basket Swap");
		 *		INITIALISE_SPECIFIC_DIALOG(CSRBasketSwapSpecific, MyBasketSwap);
		 *
		 * @version 5.3.4
		 * @version 7.1.1
		 */
		class SOPHIS_FINANCE CSRBasketSwapSpecific : public sophis::gui::CSRInstrumentDialog, public sophis::gui::CSRBasicButton::CSRListener, public sophis::gui::ISRGenericTabPage
		{
			DECLARATION_INSTRUMENT_DIALOG(CSRBasketSwapSpecific)

		public: 

			/** Resource ids. */
			enum BasketSwapSpecEnum
			{
				bsAdjustmentList = -1, // List of all adjustments
				bsComponentsHistory = -2, // History of all basket compositions
				bsLinePicking = -3, // Line picking list
				bsModificationType = -4, // Type of modification (i.e. NotModified, BasketCreation, BasketAdjustment, AdjustmentDeletion)
				bsOK = 1,
				bsCancel, 
				bsBasket = 5,
				bsAdjustmentBtn = 6,
				bsHedgeBookingBtn = 7,
				bsPortfolioEdit,
				bsPortfolioName,
				bsFixingBtn = 10
			};

			/** Enumeration for fElementList */
			enum ElementNbInDlg
			{
				spcBasketNb, // Tree area must be created first of otherwise the command handler does not work
				spcBasketAdjustments,
				//	spcBasketComponents ,
				spcBasketComponentsHistory,
				spcLinePicking,
				spcModificationType,
				spcButtonOKNb,
				spcButtonHedgeBooking,
				spcEditFolioCode,
				spcEditFolioName,
				spcFixing,
				// default number of elements
				spcCount
			};

			/// See {@link CSRBasicButton::CSRListener::OnButtonAction}
			virtual void OnButtonAction(const sophis::gui::CSRBasicButton& iButton);

			/// See {@link CSRFitDialog::Open}
			virtual	void	Open(void);

			/// See {@link ISRGenericTabPage::LeavePage}
			virtual bool LeavePage();
			/// See {@link ISRGenericTabPage::EnterPage}
			virtual bool EnterPage();
			/// See {@link ISRGenericTabPage::OnToolbarButton}
			virtual void OnToolbarButton(int nId);

			/// See {@link CSRFitDialog::OnGotFocus}
			virtual void OnGotFocus();
			/// See {@link CSRFitDialog::OnLostFocus}
			virtual void OnLostFocus();
			/// See {@link CSRFitDialog::ElementValidation}
			virtual void ElementValidation(int EAId_Modified);

			/** Get position id of the basket swap contract associated with this instance. */
			sophis::portfolio::PositionIdent GetMvtident();
			/** Set position id of the basket swap contract associated with this instance. */
			void SetMvtident(sophis::portfolio::PositionIdent mvtident);
			/** Set folio for hedge booking, based on current position id of the basket swap contract.
			 * See also "HedgeBookingFolio" riskpref. */
			void SetFolioCode();
			
			/** Check if adjustments have been saved or not. */
			bool IsModified();

			/// See {@link CSRFitDialog::InitialiseDialogue}
			virtual const char * InitialiseDialogue(const char* result);

			/** Invoked from CSRBasketSwapSpecific::NewDeriveSophis() or similar method of derived class.
			 * @param resourceId resource id to use (can be 0 to indicate default)
			 * @param elementCount how many elements to initialise (can be 0 to indicate default)
			 * @version 7.1.2 */
			virtual void InitBasketSwapSpecific(int resourceId, int elementCount);

		protected:
			virtual void DoBasketAdjustmentAction(CSDialogSwapTabs* swapTabs, CSRBasketSwap& basketSwap);
			virtual void DoHedgeBookingAction(CSDialogSwapTabs* swapTabs, CSRBasketSwap& basketSwap, long folioCode, ComponentDetailsList& componentsList, long modificationDate);

			sophis::portfolio::PositionIdent fMvtIdent;
		};

		/**
		 * Market data customization for TRS Basket Swap.
		 */
		class SOPHIS_FINANCE CSRMarketDataCustomTRS : public sophis::scenario::CSRMarketDataOverloader
		{
		public:
			CSRMarketDataCustomTRS(const CSRMarketData& context, long date=0, bool noZC=false,
				sophis::market_data::eTaxCreditPercentageType forceType=sophis::market_data::tcpFuture, bool noCredit=false, bool divAutoTicket=false, bool gloalAutoTicket=false);

			bool IsDivAutoTicket() const {return fDivAutoTicket;}
			bool IsGlobAutoTicket() const {return fGlobAutoTicket;}

			virtual	long GetDate() const;
			const sophis::market_data::CSRYieldCurve *	GetCSRYieldCurve(long currency) const;
			double	GetTaxCreditPercentageType(long equityCode, sophis::market_data::eTaxCreditPercentageType toEvaluate) const;
			virtual	double GetInstrumentSpread(long instrumentCode, long maturity) const;
			virtual const sophis::market_data::CSRCreditRisk* GetCreditRisk(long issuerCode, long currencyCode, bool withDefault) const OVERRIDE;

		private:
			sophis::market_data::eTaxCreditPercentageType fForceType;
			long fDateToUse;
			bool fNoZC,fNoCredit,fDivAutoTicket,fGlobAutoTicket;
		};
	}
}

#endif // GCC_XML
#endif // _SPHBASKETSWAPTAB_H
