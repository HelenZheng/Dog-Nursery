/*
File:		SphABSBond.h

Contains:	Class for the handling of an ABS bond.

Copyright:	2007 Sophis.

*/

/*! \file SphABSBond.h
\brief Class for the handling of an ABS bond.
*/

#pragma once

#ifndef _SphBermudanClauseGenerator_H_
#define _SphBermudanClauseGenerator_H_

#include "SphInc/SphMacros.h"

/**
	Application includes
*/

#include "SphTools/SphPrototype.h"
#include "SphInc/instrument/SphSwap.h"
/**
	STL includes
*/
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275)	// Can not export a class derivated from a non exported one
#	pragma warning(disable:4251)	// Can not export a class agregating a non exported one
#endif

#define DECLARATION_BERMUDEAN_CLAUSE_GENERATOR_DATE(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRBermudanClauseGeneratorBuildDate)

#define INITIALISE_BERMUDEAN_CLAUSE_GENERATOR_DATE(className, name)	INITIALISE_PROTOTYPE(className, name)

namespace sophis
{
	namespace finance
	{
		class SOPHIS_YIELDCURVEBYSPLINE CSRBermudanClauseGeneratorBuildDate 
		{
			public:
			CSRBermudanClauseGeneratorBuildDate();

			virtual ~CSRBermudanClauseGeneratorBuildDate();

			virtual long BuildStartDate(long iCouponStartDate, long iResetGap,const sophis::instrument::CSRSwap* iSwap) const;

			virtual long BuildEndDate(long iCouponStartDate, const sophis::instrument::CSRSwap* iSwap) const;

			typedef sophis::tools::CSRPrototype< CSRBermudanClauseGeneratorBuildDate, const char *, sophis::tools::less_char_star > prototype;

			static prototype &	GetPrototype();

		};


		/*class CSRBermudanClauseGeneratorBuildDateTestImplementation  : public CSRBermudanClauseGeneratorBuildDate
		{
			public:
			CSRBermudanClauseGeneratorBuildDateTestImplementation();

			virtual ~CSRBermudanClauseGeneratorBuildDateTestImplementation();

			virtual long BuildStartDate(long iCouponStartDate, long iResetGap,const sophis::instrument::CSRSwap* iSwap) const;

			virtual long BuildEndDate(long iCouponStartDate, const sophis::instrument::CSRSwap* iSwap) const;

			DECLARATION_BERMUDEAN_CLAUSE_GENERATOR_DATE(CSRBermudanClauseGeneratorBuildDateTestImplementation)

		};*/
	} // end of namespace finance
}// end of namespace sophis


#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(pop)
#endif

#endif // _SphBermudanClauseGenerator_H_

