#ifndef _SphCDSPricer_H__
#define _SphCDSPricer_H__


#if (defined(WIN32)||defined(_WIN64))
namespace sophis {
	namespace static_data {
		enum eYieldCalculationType;
		enum eDayCountBasisType;
		enum eHolidayAdjustmentType;
	}
	namespace instrument {
		enum eSwapPeriodicityType;
		enum eForexOrder;
	}
}
enum eCreditRiskCurve;
#else
#	include "SphInc/static_data/SphInterestRate.h"
#	include "SphInc/static_data/SphCalendar.h"
#	include "SphInc/instrument/SphInstrumentEnums.h"
#	include "SphInc/instrument/SphForexSpot.h"
#	include "SphInc/SphPreference.h"
#endif

#include "SphInc/instrument/SphSwapExplanation.h"
#include "SphInc/market_data/SphCreditRisk.h"


SPH_PROLOG

class CSRCreditRiskBasket;

namespace sophis {
	namespace instrument {
		struct SSFixedFlow;
	}
}

namespace sophis	{
	namespace finance	{

		/**
		*	Pricing class for CDS.
		*	It is the interface to price
		*	@see CSRSwap
		*	@since 5.0.2
		*/
		class SOPHIS_FIT CSRCDSPricer
		{
		public:
			CSRCDSPricer();
			CSRCDSPricer(bool noMarkedCredit);

			virtual ~CSRCDSPricer();
			
			/** Clone method.
			Used to clone an object.
			@return a new derived class from CSRCDSPricer (the same as this) which must be deleted.
			Actually, it is implemented for each derived structure and does need to be overloaded
			by your model because their is no copy constructor and the clone is corrupted if the original is deleted. 
			@since 5.2.2
			*/
			virtual CSRCDSPricer *Clone() const;

			/** Return the value of a the credit leg.
			@param computationDate is the computation date.
			@param discountCurrency is the discount currency or family for cashflow discount (@since 5.2.2)
			@param context is the market data.
			@param explaination may be null and if not null should be filled to explain the leg value.
			@return the value for a nominal of one taking into account the spreaded pricer.
			@see fSpreadedPricer
			@see fBasicPricer
			*/
			virtual double	GetCreditLegValue(long computationDate, long discountCurrency, const market_data::CSRMarketData& context, instrument::CSRCashFlowInformationList * explaination = 0) const;

			/** Return the recovered value in case of default event.
			@param computationDate is the computation date.
			@param startDate is the start date.
			@param endDate is the end date.
			@param discountCurrency is the discount currency or family for cashflow discount (@since 5.2.2)
			@param context is the market data.
			@return the value that is recovered in case of default event.
			*/
			virtual double	GetRecoveredValue(long computationDate, long startDate, long endDate, long discountCurrency, const market_data::CSRMarketData& context) const;

			/** Return the value today of a the coupon paid if no default.
			@param computationDate is the computation date.
			@param flow describe the fixed flow.
			@param couponValueDiscounted describe coupon which is already discounted.
			@param context is the market data.
			@param explaination may be null and if not null should be filled to explain the leg value; as the discount is already
			in the coupon, the yield in explanation will be added in the swap pricer.
			@return the value for a nominal of one.
			@see GetSurvivalProba
			*/
			virtual double	GetWeightedFixedCoupon(long computationDate, const instrument::SSFixedFlow &flow, double couponValueDiscounted, const market_data::CSRMarketData& context, instrument::CSRCashFlowInformationList * explaination = 0) const;

			/** Return the survival probability of the issuer
			@param computationDate is the computation date.
			@param endDate is the date until which the survival probability is computed
			@param context is the market data.
			@return the survival probability taking into account the spreaded pricer
			@see fSpreadedPricer
			@see fBasicPricer
			@version 5.2.2 this function is only implemented for CSRCDSPricer object corresponding to a single issuer
			it is due to CDO� development because basket underlyings are not necessarly an issuer
			*/
			virtual double	GetSurvivalProba(double computationDate, double endDate, const market_data::CSRMarketData& context) const;

			/** Return the value today of a the accrued paid if default during fixed flow.
			@param computationDate is the computation date.
			@param discountCurrency is the discount currency or family for cashflow discount (@since 5.2.2)
			@param flow describe the fixed flow.
			@param context is the market data.
			@param explaination may be null and if not null should be filled to explain the leg value.
			@return the value for a nominal of one taking into account the spreaded pricer.
			@see fSpreadedPricer
			@see fBasicPricer
			*/
			virtual double	GetAccruedCoupon(long computationDate, long discountCurrency, const instrument::SSFixedFlow &flow, const market_data::CSRMarketData& context, instrument::CSRCashFlowInformationList * explaination = 0) const;

			/** Return the recovery rate used for computation
			@return the recovery rate used for computation (fRecoveryRateForCreditLeg) plus an eventual bump due to the spreaded pricer
			@see fRecoveryRateForCreditLeg
			@see fSpreadedPricer
			@see fBasicPricer
			@version 5.2.2 this function is only implemented for CSRCDSPricer object corresponding to a single issuer
			it is due to CDO� development because basket underlyings are not necessarly an issuer
			*/
			virtual double	GetRecoveryRate() const;

			virtual void	InitStaticData(long issuerCode, long seniority, long defEvent);
			virtual void	InitData(int creditLegIndex, const instrument::CSRSwap &swap, const market_data::CSRMarketData& context);
			virtual void	SetIssuer(long issuer, long seniority, long defaultEvent);
			virtual void	InitContextData(	const market_data::CSRMarketData& context, long underlyingCode, long currencyCode, eCreditRiskCurve curveType, long endDate, bool isMarkedCredit, double fixedRate, long ForcedRunningCoupon = 0);
			virtual void	InitInstrumentData(int creditLegIndex, const instrument::CSRSwap &swap, const market_data::CSRMarketData& context);
			virtual void	InitSwapData(int creditLegIndex, const instrument::CSRSwap &swap, const market_data::CSRMarketData& context);

			/** This method is used to know if a simulated CSRMarketData is to be used for a credit default swap pricing.
			* If returns null,  the standard context is used for CDS pricing .
			**/
			const market_data::CSRMarketData	*GetCSRMarketData() const;

			/** This method returns the credit risk associated with a single issuer **/
			const market_data::CSRCreditRisk*	GetCSRCreditRisk() const;

			/**
			* tells if the defaults events are constrained between two dates usefull for scenario computation optimisation.
			* @param startDate	start date for default events.
			* @param data		end date for defaults events.
			* @return			true if the defaults events are constrained between two dates.
			* @see CSRCreditRisk::GetDefaultDateRange
			* @since 5.2.2
			*/
			virtual bool GetDefaultDateRange(long &startDate, long &endDate) const;

			/** Add the explanation for GetWeightedFixedCoupon.
			This may be used to push back an explanation for a cash flow resulting of a payement of a coupon on
			the fixed leg for a cds and is generally called by one of the derived method {@link GetWeightedFixedCoupon}
			@param explaination is the container explaining the leg value.
			@param flow describe the fixed flow.
			@param couponValueDiscounted describe coupon which is already discounted.
			@param percentage describes the percentage of the coupon paid.
			*/
			void	AddExplanationForProbability(instrument::CSRCashFlowInformationList &explaination, double probability, const instrument::SSFixedFlow &flow, double couponValueDiscounted, double percentage) const;

			/** Add the explanation in case of a default.
			This may be used to push back an explanation for a cash flow resulting of a payement of an accrued coupon on
			the fixed leg  {@link GetAccruedCoupon} or for the credit leg {@link GetCreditLegValue} of a cds 
			and is generally called by one of the derived methods.
			@return true if an explanation has been added
			@param explaination is the container explaining the leg value.
			@param amountIfDefault is the amount in case of default.
			@param startDefault is the start of a possible default.
			@param endDefault is the end of a possible default.
			@param percentage describes the percentage of the amount paid.
			@param context is the market data used to calculate default probability.
			@param paymentDate is the payment date to display; if null, end_default is used.
			*/
			bool	AddExplanationForDefault(instrument::CSRCashFlowInformationList &explaination, long computationDate, double amountIfDefault, long start_default, long end_default, double percentage, const market_data::CSRMarketData &context, long paymentDate = 0) const;


			/**
			* @Return a clone of the underlying basket for multiple name credit source in which all past default are managed. 
			* The clone is deleted by the CDSPricer. Default implementation for an issuer returns a NULL pointer.
			* Used for multiple name credit products
			*/
			virtual const CSRCreditRiskBasket* GetModifiedUnderlyingBasket() const {return 0;};

			/** This method is used for credit basket in order to get the CSRCDSPricer corresponding to the n-th basket component.
			@param nth is the number of the corresponding basket underlying.
			@return the n-th direct underlying CDSPricer.
			@see GetModifiedUnderlyingBasket
			@since 5.2.2
			*/
			virtual const finance::CSRCDSPricer* GetNthPricer(int nth) const {return 0;};

			/** This method is used for credit basket in order to get the number of underlying CSRCDSPricer.
			@param nth is the number of the corresponding basket underlying.
			@return 0 by default, and for Credit baskets returns the number of not defaulted issuer in the basket.
			@see GetModifiedUnderlyingBasket
			@since 5.2.2
			*/
			virtual int GetPricerCount() const {return 0;};

			inline long GetIssuerCode() const {return fIssuerCode;};
			inline long GetCreditCarrierCode() const {return fCreditCarrierCode;};
			inline long GetSeniority() const {return fSeniority;};
			inline long GetDefaultEvent() const {return fDefaultEvent;};
			inline long GetRunningCoupon() const {return fRunningCoupon;};
			virtual void	SetRunningCoupon(long runningCoupon);

			inline eCreditRiskCurve	GetCreditRiskCurve() const {return fCreditRiskCurve;};
 			inline static_data::eDayCountBasisType			GetFixedLegBasis() const {return fFixedLegBasis;};
			inline static_data::eYieldCalculationType		GetFixedLegMode() const {return fFixedLegMode;};

			inline	void	SetCreditCarrierCode(long carrierCode) {fCreditCarrierCode = carrierCode;};

			// Return true if there is credit risk data defined in fCreditRisk
			// for fSeniority,  fDefaultEvent and fCreditRiskCurve
			bool	IsCreditDataDefined() const;

			/** This method is used to add a zero coupon spread on the reference credit risk. For this it 
			works on a clone of the credit risk (if the credit risk is not cloned, it clones it).
			@param spread is the spread to apply.
			@param isAdditive say if the spread is additive or multiplicative.
			@see fIsClonedCreditRisk
			@see fCreditRisk
			@since 5.2.2
			*/
			void	AddSpreadOnCreditRisk(double spread, bool isAdditive);

			/** This method is used to set a basic and a bumped CSRCDSPricer in order to apply a shift on credit and/or recovery rate.
			For exemple it is used when you want to price with the index data and want to have risk analysis component by component.
			@param basic is the basic CSRCDSPricer.
			@param spreaded is the shocked CSRCDSPricer.
			@see fBasicPricer
			@see fSpreadedPricer
			@see GetDefaultDateRange
			@see GetCreditLegValue
			@see GetRecoveryRate
			@see GetSurvivalProba
			@since 5.2.2
			*/
			void	SetPricerForSensitivity(const CSRCDSPricer* basic, const CSRCDSPricer* spreaded);

			/** This structure describe one period for the credit leg.
			It is used for amortizing CDS for the credit leg valuation.
			The list of amortizing flows is set in InitSwapData 
			@see fAmortizingScheme
			@see InitSwapData
			@see GetCreditLegValue
			@since 5.2.2
			*/
			struct AmortizingFlow
			{
				long	startPeriod;		// start of period (date included)
				long	endPeriod;			// end of period (date included)
				double	remainingFactor;	// notional factor (between 0 and 1)
				double	percentage;			// percentage of flow to consider (between 0 and 1)
			};
			typedef _STL::vector<AmortizingFlow> AmortizingScheme;

		protected:
			const market_data::CSRCreditRisk		*fCreditRisk;
			market_data::CSRCreditRisk				*fMarkedCreditRisk;
			double									fRecoveryRateForCreditLeg;
			long									fIssuerCode;
			// by default fCreditCarrierCode = fIssuerCode;
			long									fCreditCarrierCode;
			long									fSeniority;
			long									fDefaultEvent;
			long									fRunningCoupon;
			long									fIssueDate;
			long									fEndDate;
			eCreditRiskCurve						fCreditRiskCurve;
			static_data::eDayCountBasisType			fFixedLegBasis;
			static_data::eYieldCalculationType		fFixedLegMode;
			mutable instrument::CSRDataForPricing	*fDataForPricing;

			SPH_BEGIN_NOWARN_EXPORT
			AmortizingScheme	fAmortizingScheme;
			SPH_END_NOWARN_EXPORT

			bool									fDeleteDataForPricing;
			bool									fIsClonedCreditRisk;
			
			const CSRCDSPricer						*fBasicPricer;
			const CSRCDSPricer						*fSpreadedPricer;

			const static_data::CSRCalendar*			fCalendarCreditLeg;
			long									fCreditPaymentShift;
			bool									fIsCalibration;
		};

	} // namespace finance
}

SPH_EPILOG


#endif //!_SphCDSPricer_H__

