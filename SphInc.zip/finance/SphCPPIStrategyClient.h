/*
File:		SphCPPIStrategyClient.h

Contains:	CPPI Standard StrategyClient.

Copyright:	2008 Sophis.

*/

/*! \file SphCPPIStrategyClient.h
\brief CPPI Standard StrategyClient.
*/
#pragma once

#ifndef _SphCPPIStrategyClient_H__
#define _SphCPPIStrategyClient_H__

#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/instrument/SphCPPICommon.h"
#include "SphInc/instrument/SphOption.h"

#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)



/** Declaration macros for CPPI strategy and substrategies

@version 6.0
*/
#define DECLARATION_CPPI_STRATEGY_CLIENT(derived)				DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyClient)

#define DECLARATION_CPPI_STRATEGY_CLIENT_INDEX(derived)			DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyClientIndex)
#define DECLARATION_CPPI_STRATEGY_CLIENT_THRESHOLD(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyClientThreshold)
#define DECLARATION_CPPI_STRATEGY_CLIENT_RAW(derived)			DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyClientRAW)

/** Instantiation macros for CPPI strategy and substrategies

@version 6.0
*/
#define INITIALISE_CPPI_STRATEGY_CLIENT(className, name)			INITIALISE_PROTOTYPE(className, name)

#define INITIALISE_CPPI_STRATEGY_CLIENT_INDEX(className, name)		INITIALISE_PROTOTYPE(className, name)
#define INITIALISE_CPPI_STRATEGY_CLIENT_THRESHOLD(className, name)	INITIALISE_PROTOTYPE(className, name)
#define INITIALISE_CPPI_STRATEGY_CLIENT_RAW(className, name)		INITIALISE_PROTOTYPE(className, name)

SPH_PROLOG
namespace sophis
{
	class CSRUserData;
	namespace tools
	{
		class CSRArchive;
	}
	namespace finance
	{
		class CSRCPPI;

		enum eCPPIThresholdType
		{
			ecttZC = 0,
			ecttZCspread,
			ecttFixedRate,
			ecttLinear
		};

		/**	CPPI Index Strategy interface for Markov Meta Model.
		This structure is passed to CSRCPPIStrategyClientIndex, through the 
		FillParametersForMarkov virtual method of CSRCPPIStrategyClient.
		@version 6.0
		*/
		struct SSCPPIMarkovStrategyIndex 
		{
			// Standard
			_STL::set< long > FeesDates;
			double		FeesRate;
			double		FeesDefeasanceRate;
			double		FeesRiskyRate;

			int			FeesType;
			int			FeesReferenceDateType;

			static_data::eDayCountBasisType		FeesBasis;
			static_data::eYieldCalculationType	FeesMode;
			instrument::eQuantoType				QuantoType;

			// Double Decker
			bool		isDoubleDecker;

			double		DoubleDeckerLevel;
			long		MoreRiskyCode;
			long		MoreRiskyFixingType;
			long		MoreRiskyOffset;
			instrument::eQuantoType	MoreRiskyQuantoType;

			// Constructor
			SSCPPIMarkovStrategyIndex () {
				FeesRate				= 0;
				FeesDefeasanceRate		= 0;
				FeesRiskyRate			= 0;
				FeesType				= 0;
				FeesReferenceDateType	= 0;
				FeesBasis				= static_data::dcbUndefined;
				FeesMode				= static_data::ycUndefined;
				QuantoType				= instrument::qIsAQuanto;
				isDoubleDecker			= false;
				DoubleDeckerLevel		= 0;
				MoreRiskyCode			= 0;
				MoreRiskyFixingType		= 0;
				MoreRiskyOffset			= 0;
				MoreRiskyQuantoType		= instrument::qIsAQuanto;
			}
		};

		/**	CPPI Threshold Strategy interface for Markov Meta Model.
		This structure is passed to CSRCPPIStrategyClientThreshold, through the 
		FillParametersForMarkov virtual method of CSRCPPIStrategyClient.
		@version 6.0
		*/
		struct SSCPPIMarkovStrategyThreshold
		{
			// Standard
			long	ExtendedSubscriptionEndDate;

			// Advanced (in fact standard...)
			bool	isAdvanced;

			bool	HasLockIn;
			bool	ContinuousLockIn;
			double	LockInProportion;
			instrument::eSwapPeriodicityType LockInFrequency;
			long	LockInStartDate;
			long	LockInEndDate;
			_STL::set< long > LockInDates;

			bool	HasArtificialThreshold;
			eCPPIThresholdType ThresholdType;
			double	ThresholdRate;
			double	InitialThreshold;
			static_data::eYieldCalculationType	ThresholdMode;
			static_data::eDayCountBasisType		ThresholdBasis;

			// Open Ended
			bool	isOpenEnded;

			// Constructor
			SSCPPIMarkovStrategyThreshold () {
				ExtendedSubscriptionEndDate	= 0;
				isAdvanced					= false;
				HasLockIn					= false;
				ContinuousLockIn			= false;
				LockInProportion			= 0;
				LockInFrequency				= instrument::spUndefined;
				LockInStartDate				= 0;
				LockInEndDate				= 0;
				HasArtificialThreshold		= false;
				ThresholdType				= finance::ecttZC;
				ThresholdRate				= 0;
				ThresholdMode				= static_data::ycUndefined;
				ThresholdBasis				= static_data::dcbUndefined;
				isOpenEnded					= false;
			}
		};


		struct SOPHIS_CPPI_CLIENT SSRawTableLine
		{
			double tolmin;
			double min;
			double max;
			double tolmax;

			double raw1;
			double raw2;

			bool isValid(bool lastLine) const;

			//void SetStaticData(const sophis::tools::CSRArchive& archive);
			void GetStaticData(sophis::tools::CSRArchive& archive) const;
		};

		class SOPHIS_CPPI_CLIENT RawTableData : public _STL::vector<SSRawTableLine>
		{
		public:
			bool isValid() const;

			//void SetStaticData(const sophis::tools::CSRArchive& archive);
			void GetStaticData(sophis::tools::CSRArchive& archive) const;
		};


		/**	CPPI RAW Strategy interface for Markov Meta Model.
		This structure is passed to CSRCPPIStrategyClientRAW, through the 
		FillParametersForMarkov virtual method of CSRCPPIStrategyClient.
		@version 6.0
		*/
		struct SSCPPIMarkovStrategyRAW
		{
			// Common
			long	FirstPeriodEndDate;
			double	FirstPeriodRAW;

			double	RebalancingConditionMin;
			double	RebalancingConditionMax;
			bool	isConditionalRebalancing;

			// Standard
			double	Multiplier;
			double	ExposureMin;
			double	ExposureMax;
			bool	isExposureConstrained;
			double	DefeasanceTrigger;

			// Table
			bool	isTable;
			RawTableData RAWTable;

			// Constructor
			SSCPPIMarkovStrategyRAW () {
				FirstPeriodEndDate		= 0;
				FirstPeriodRAW			= 0;
				RebalancingConditionMin	= 0;
				RebalancingConditionMax	= 0;
				isConditionalRebalancing= false;
				Multiplier				= 0;
				ExposureMin				= 0;
				ExposureMax				= 0;
				isExposureConstrained	= false;
				DefeasanceTrigger		= 0;
				isTable					= false;
				
				RAWTable.clear();
			}
		};

		/**	CPPI Strategy interface for Markov Meta Model.
		This structure is passed to CSRCPPIStrategyClient to be filled by
		the sub modules
		@version 6.0
		*/
		struct SSCPPIMarkovStrategy
		{
			SSCPPIMarkovStrategyIndex		Index;
			SSCPPIMarkovStrategyThreshold	Threshold;
			SSCPPIMarkovStrategyRAW			RAW;
		};

		class SOPHIS_CPPI_CLIENT CSRCPPIStrategyClient
		{
		public:

			CSRCPPIStrategyClient();
			CSRCPPIStrategyClient( const CSRCPPIStrategyClient & toCopy );
			virtual ~CSRCPPIStrategyClient();

			virtual CSRCPPIStrategyClient* Clone() const = 0;

			virtual _STL::string GetName() const = 0;

			virtual void InitFromCPPI(const CSRCPPI& cppi);

			virtual void AddNeededBasis(_STL::set<static_data::eDayCountBasisType>& basisSet) const;

			virtual void GetStaticData(sophis::tools::CSRArchive& archive) const = 0;

			//for MC control variate
			virtual bool SetSelfFinancing();
			
			/**	Fill the structure SSCPPIMarkovStrategy for the Markov Meta Model
			@param SSCPPIMarkovStrategy to be filled.
			@return true on success, false otherwise
			@version 6.0
			*/
			virtual bool FillParametersForMarkov(SSCPPIMarkovStrategy& parameters) const;

			/**	Method called when checking the validity of the CPPI.
				By default, returns true.
				@param err is a string to fill with an error message in case of validation failure.
				@return true when valid, false otherwise.
				@version 6.0
			*/
			virtual bool IsValid( _STL::string & err ) const;
			
			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyClient, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();

			sophis::CSRUserData *	GetUserData() const;
			virtual void	SetUserData( sophis::CSRUserData * toSet );
		private:
			sophis::CSRUserData *	fUserData;
		};


		class SOPHIS_CPPI_CLIENT CSRCPPIStrategyClientIndex
		{
		public:
			CSRCPPIStrategyClientIndex();
			CSRCPPIStrategyClientIndex( const CSRCPPIStrategyClientIndex & toCopy );
			virtual ~CSRCPPIStrategyClientIndex();

			virtual CSRCPPIStrategyClientIndex* Clone() const = 0;

			virtual _STL::string GetName() const = 0;

			virtual void InitFromCPPI(const CSRCPPI& cppi);

			virtual void AddNeededBasis(_STL::set<static_data::eDayCountBasisType>& basisSet) const;

			virtual void GetDefeasanceFeesData(	double								&rate,
													int									&type, 
													static_data::eYieldCalculationType	&mode,
													static_data::eDayCountBasisType		&basis) const;

			virtual void GetStaticData(sophis::tools::CSRArchive& archive) const = 0;

			//for MC control variate
			virtual bool SetSelfFinancing();

			/**	Fill the structure SSCPPIMarkovStrategy for the Markov Meta Model
			@param SSCPPIMarkovStrategy to be filled.
			@return true on success, false otherwise
			@version 6.0
			*/
			virtual bool FillParametersForMarkov(SSCPPIMarkovStrategy& parameters) const;

			/**	Method called when checking the validity of the CPPI.
				By default, returns true.
				@param err is a string to fill with an error message in case of validation failure.
				@return true when valid, false otherwise.
				@version 6.0
			*/
			virtual bool IsValid( _STL::string & err ) const;

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyClientIndex, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();

			sophis::CSRUserData *	GetUserData() const;
			virtual void	SetUserData( sophis::CSRUserData * toSet );
		private:
			sophis::CSRUserData *	fUserData;
		};

		class SOPHIS_CPPI_CLIENT CSRCPPIStrategyClientThreshold
		{
		public:

			CSRCPPIStrategyClientThreshold();
			CSRCPPIStrategyClientThreshold( const CSRCPPIStrategyClientThreshold & toCopy );
			virtual ~CSRCPPIStrategyClientThreshold();

			virtual CSRCPPIStrategyClientThreshold* Clone() const = 0;

			virtual _STL::string GetName() const = 0;

			virtual void InitFromCPPI(const CSRCPPI& cppi);

			virtual void AddNeededBasis(_STL::set<static_data::eDayCountBasisType>& basisSet) const;

			virtual void GetStaticData(sophis::tools::CSRArchive& archive) const = 0;

			//for MC control variate
			virtual bool SetSelfFinancing();

			/**	Fill the structure SSCPPIMarkovStrategy for the Markov Meta Model
			@param SSCPPIMarkovStrategy to be filled.
			@return true on success, false otherwise
			@version 6.0
			*/
			virtual bool FillParametersForMarkov(SSCPPIMarkovStrategy& parameters) const;

			/**	Method called when checking the validity of the CPPI.
				By default, returns true.
				@param err is a string to fill with an error message in case of validation failure.
				@return true when valid, false otherwise.
				@version 6.0
			*/
			virtual bool IsValid( _STL::string & err ) const;

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyClientThreshold, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();

			sophis::CSRUserData *	GetUserData() const;
			virtual void	SetUserData( sophis::CSRUserData * toSet );
		private:
			sophis::CSRUserData *	fUserData;
		};

		class SOPHIS_CPPI_CLIENT CSRCPPIStrategyClientRAW
		{
		public:

			CSRCPPIStrategyClientRAW();
			CSRCPPIStrategyClientRAW( const CSRCPPIStrategyClientRAW & toCopy );
			virtual ~CSRCPPIStrategyClientRAW();

			virtual CSRCPPIStrategyClientRAW* Clone() const = 0;

			virtual _STL::string GetName() const = 0;

			virtual void InitFromCPPI(const CSRCPPI& cppi);

			virtual void AddNeededBasis(_STL::set<static_data::eDayCountBasisType>& basisSet) const;

			virtual void GetStaticData(sophis::tools::CSRArchive& archive) const = 0;

			//for MC control variate
			virtual bool SetSelfFinancing();

			/**	Fill the structure SSCPPIMarkovStrategy for the Markov Meta Model
			@param SSCPPIMarkovStrategy to be filled.
			@return true on success, false otherwise
			@version 6.0
			*/
			virtual bool FillParametersForMarkov(SSCPPIMarkovStrategy& parameters) const;

			/**	Method called when checking the validity of the CPPI.
				By default, returns true.
				@param err is a string to fill with an error message in case of validation failure.
				@return true when valid, false otherwise.
				@version 6.0
			*/
			virtual bool IsValid( _STL::string & err ) const;

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyClientRAW, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();

			sophis::CSRUserData *	GetUserData() const;
			virtual void	SetUserData( sophis::CSRUserData * toSet );
		private:
			sophis::CSRUserData *	fUserData;
		};

	}
}
SPH_EPILOG


#endif