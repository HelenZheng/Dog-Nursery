/*
File:		SphCPPIStrategyServer.h

Contains:	CPPI Standard Strategy.

Copyright:	2007 Sophis.

*/

/*! \file SphCPPIStrategyServer.h
\brief CPPI Standard Strategy.
*/
#pragma once

#ifndef _CPPI_STRATEGY_SERVER_H_
#define _CPPI_STRATEGY_SERVER_H_

#include "SphInc/SphMacros.h"
#include "SphInc/instrument/SphCPPICommon.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/static_data/SphYieldCalculation.h"
#include "SphInc/static_data/SphDayCountBasis.h"
#include "SphInc/instrument/SphOption.h"



/** Declaration macros for CPPI strategy and substrategies

@version 6.0
*/
#define DECLARATION_CPPI_STRATEGY_SERVER(derived)					DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyServer)

#define DECLARATION_CPPI_STRATEGY_SERVER_INDEX(derived)				DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyServerIndex)
#define DECLARATION_CPPI_STRATEGY_SERVER_THRESHOLD(derived)			DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyServerThreshold)
#define DECLARATION_CPPI_STRATEGY_SERVER_RAW(derived)				DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPIStrategyServerRAW)

#define DECLARATION_CPPI_COUPONS(derived)							DECLARATION_PROTOTYPE(derived, sophis::finance::CSRCPPICoupons)

/** Instantiation macros for CPPI strategy and substrategies

@version 6.0
*/
#define INITIALISE_CPPI_STRATEGY_SERVER(className, name)			INITIALISE_PROTOTYPE(className, name)

#define INITIALISE_CPPI_STRATEGY_SERVER_INDEX(className, name)		INITIALISE_PROTOTYPE(className, name)
#define INITIALISE_CPPI_STRATEGY_SERVER_THRESHOLD(className, name)	INITIALISE_PROTOTYPE(className, name)
#define INITIALISE_CPPI_STRATEGY_SERVER_RAW(className, name)		INITIALISE_PROTOTYPE(className, name)

#define INITIALISE_CPPI_COUPONS(className, name)					INITIALISE_PROTOTYPE(className, name)

SPH_PROLOG
namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace finance
	{
		class SOPHIS_CPPI CSRCPPIStrategyServer
		{
		public:

			CSRCPPIStrategyServer();
			virtual ~CSRCPPIStrategyServer();

			virtual CSRCPPIStrategyServer* Clone() const = 0;

			virtual void 	FillTable(	CSRCPPITable&								table,
										const _STL::vector< _STL::vector<double> >&	zc,
										YearCountData& 								period,
										YearCountData& 								maturity,
										long										maxDate = 0) const = 0;

			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) = 0;

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyServer, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();
		};


		class SOPHIS_CPPI CSRCPPIStrategyServerIndex
		{
		public:

			CSRCPPIStrategyServerIndex();
			virtual ~CSRCPPIStrategyServerIndex();

			virtual CSRCPPIStrategyServerIndex* Clone() const = 0;

			virtual bool	FillTable(	CSRCPPITable&								table,
										const _STL::vector< _STL::vector<double> >&	zc,
										YearCountData& 								period,
										YearCountData& 								maturity,
										long										maxDate,
										int											l) const = 0;

			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) = 0;

			virtual void	ResetOptim();

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyServerIndex, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();
		};

		class SOPHIS_CPPI CSRCPPIStrategyServerThreshold
		{
		public:

			CSRCPPIStrategyServerThreshold();
			virtual ~CSRCPPIStrategyServerThreshold();

			virtual CSRCPPIStrategyServerThreshold* Clone() const = 0;

			virtual bool FillTable(	CSRCPPITable&								table,
									const _STL::vector< _STL::vector<double> >&	zc,
									YearCountData& 								period,
									YearCountData& 								maturity,
									long										maxDate, 
									int											l) const = 0;
			virtual void SetStaticData(const sophis::tools::CSRArchive& archive) = 0;

			virtual void ResetOptim();

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyServerThreshold, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();
		};

		class SOPHIS_CPPI CSRCPPIStrategyServerRAW
		{
		public:

			CSRCPPIStrategyServerRAW();
			virtual ~CSRCPPIStrategyServerRAW();

			virtual CSRCPPIStrategyServerRAW* Clone() const = 0;

			virtual bool FillTable(	CSRCPPITable&								table,
									const _STL::vector< _STL::vector<double> >&	zc,
									YearCountData& 								period,
									YearCountData& 								maturity,
									long										maxDate, 
									int											l) const = 0;

			virtual void SetStaticData(const sophis::tools::CSRArchive& archive) = 0;

			virtual void ResetOptim();

			typedef sophis::tools::CSRPrototype< CSRCPPIStrategyServerRAW, const char *, sophis::tools::less_char_star > prototype;

			static prototype& GetPrototype();
		};


	}
}
SPH_EPILOG


#endif