/*
 	File:		SphCompoBasket.h

 	Contains:	Class for the handling of a compo basket.

 	Copyright:	� 1995-1999 Sophis.
*/

/*! \file SphCompoBasket.h
	\brief Handling of a compo basket.
*/

#ifndef _SphCompoBasket_H_
#define _SphCompoBasket_H_

#include "SphInc/instrument/SphEquity.h"

SPH_PROLOG
namespace sophis {
	namespace market_data {
		class CSRVolatilityComputation;
	}
}

namespace sophis {
	namespace finance {

		class SOPHIS_FINANCE CSRCompoBasket : public virtual instrument::CSREquity
		{
			DECLARATION_EQUITY(CSRCompoBasket)

		public:
			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

			virtual eQuantoCompoPossible QuantoCompoPossible() const;

			virtual bool	HasAVolatilityFormula() const;
			virtual double	GetVolatility(			double 						startDate,
													double 						endDate,
													double 						strike,
													NSREnums::eVolatilityType	volatType,
													Boolean 					put,
									  				const market_data::CSRMarketData 		&context) const;

			virtual double	GetEquivalentDividendYield(	long 				startDate,
														long 				endDate,
														sophis::instrument::eSettlementType		settlementType,
														const market_data::CSRMarketData& context) const;

			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData& context) const;

			virtual double	GetRepoMargin(double date1, double date2) const;

			virtual double GetNthBasketValue(const market_data::CSRMarketData& context, int which) const;

			virtual sophis::market_data::CSRVolatilityComputation*	new_CSRVolatilityComputation() const;

			virtual	sophis::instrument::CSROption* new_Splitter(sophis::instrument::CSROption* option, bool optionInPortfolio) const;

			/** 
			return true
			*/
			virtual bool ConsideredAsBasketIfUnderlyingOfOption() const;

		protected :
			void GetTabIndiceTC(int** Tindices) const;
		};
	} // namespace instrument
} //namespace sophis
SPH_EPILOG
#endif
