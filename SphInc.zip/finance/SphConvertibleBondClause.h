#ifndef __CONVETIBLE_BOND_CLAUSE__
#define __CONVETIBLE_BOND_CLAUSE__

#include "SphInc/instrument/SphClause.h"
#include "SphInc/market_data/SphMarketDataEnums.h"

#if (defined(WIN32)||defined(_WIN64))
#	ifdef SPHCB_EXPORTS
#		define SOPHIS_CB __declspec(dllexport)
#	else
#		define SOPHIS_CB __declspec(dllimport)
#	endif
#else
#	define SOPHIS_CB
#endif

SPH_PROLOG
namespace sophis {
	namespace market_data
	{
		class CSRCreditRisk;
		class CSRMarketData;
		class CSRDividend;
	}

	namespace finance	
	{
		class SOPHIS_CB CSRCBCallClause : public virtual instrument::CSRCallClause 
		{
		public:
			DECLARATION_CLAUSE(CSRCBCallClause)

			virtual ~CSRCBCallClause() {};

			/**
			 * This methods calls the virtual CallClauseInfo, and returns GetClauseType.
			 * Do not overload this method.
			 **/
			instrument::eCallClauseType	HasACallClause(	double 								computationDate,
														const market_data::CSRMarketData	&context,
														double 								&min,
														double 								&max,
														double 								&performance,
														double 								&redemption,
														int									nthCrossedBarrier) const;

			/**
			 * This methods returns the type of call (Call/Put)
			 * @return sophis::instrument::acIssuer if it is an issuer call.
			 * @return sophis::instrument::acHolder if it is a bearer put.
			 **/
			virtual instrument::eCallClauseType GetClauseType() const;

			/**
			* This methods reset the data depending on the market data before each backwardation
			**/
			virtual void						Reset(const market_data::CSRMarketData	&context) {};

			/**
			* This methods returns true if the trigger on the spot value is quanto for compo CB (default is false).
			**/
			virtual bool IsQuanto() const;

		protected:
			/** 
			 * This function fill the data for the call treatment.
			 * @param computationDate: the computation date for the call outputs.
			 * @param context: the market data used for pricing.
			 * @param min: the soft trigger (only used for calls). must be 0 for puts. It is a trigger on the conversion value. @see:CSRExercisePayoff::funct.
			 * @param max: the number of days the holder has to decide if he convert or not.
			 * @param performance: cash additive amount you get when the CB is converted after being called. 
			 * @param redemption: redemption value (including the cash additive amount if any when called without being converted).
			 * @param nthCrossedBarrier: not used in convertible bond pricing.
			 **/
			virtual void	CallClauseInfo(	double 								computationDate,
											const market_data::CSRMarketData	&context,
											double 								&min,
											double 								&max,
											double 								&performance,
											double 								&redemption,
											int									nthCrossedBarrier) const {};
		};

		class SOPHIS_CB CSRCushion : public virtual instrument::CSRClause
		{
		public:
			DECLARATION_CLAUSE(CSRCushion)

				/** 
				* This function modifies the data for the call treatment.
				* @param callType: the type of call/put (acIssuer, acHolder).
				* @param min: the soft trigger (only used for calls). must be 0 for puts. It is a trigger on the conversion value. @see:CSRExercisePayoff::funct.
				* @param max: not used in convertible bond pricing.
				* @param performance: cash additive amount you get when the CB is converted after being called. 
				* @param valTrigger: redemption trigger value to consider for optimal exercise 
				* @param redemption: true redemption value.
				**/
			virtual void GetModifiedValues(	sophis::instrument::eCallClauseType callType,
											double								&min,
											double								&max,
											double								&perf,
											double								&valTrigger,
											double								&valRembo) const {};
		};

		/**  
		* This class is made to change the values in the dividend table of the underlying between GetStartDate() and GetEndDate().
		**/
		class SOPHIS_CB CSRDividendProtection : public virtual sophis::instrument::CSRClause
		{
		public:
			DECLARATION_CLAUSE(CSRDividendProtection)

			/** 
			* This function can change the whole dividend structure.
			* @param context the market data used for pricing.
			* @param underlyingCode the underlying equity code. To get the original dividend array, use new_DividendList
			* @return the dividend that will be used for evaluating the CB.
			* @return 0 if one only wants to change dividends values or type using GetModifiedValues
			* @see CSRDividend
			* @see CSREquity::new_DividendList
			* @since 5.2.4
			**/
			virtual market_data::CSRDividend* NewWholeDividendList(const market_data::CSRMarketData &context, long underlyingCode) const {return 0;};

			/** 
			* This function can change the value and the type of the dividend. It is called if NewWholeDividendList returned 0.
			* @param context: the market data used for pricing.
			* @param type: the type of the dividend.
			* @param value: the value of the dividend.
			* @since 5.2.4
			**/
			virtual void GetModifiedValues(const market_data::CSRMarketData &context, market_data::eDividendValueType &type, double &value) const {return GetModifiedValues(type,value);};

			long	GetStartDate() const {return GetClauseStartDate() ? GetClauseStartDate() : 0;};
			long	GetEndDate() const {return GetClauseEndDate() ? GetClauseEndDate() : 99999;};

		private:
			/** 
			* This function can change the value and the type of the dividend.
			* @param type: the type of the dividend.
			* @param value: the value of the dividend.
			* @deprecated since 5.2.4
			**/
			virtual void GetModifiedValues(market_data::eDividendValueType &type, double &value) const {};
		};

		/**  
		 * This class is made to overload the conversion value in the CBModel for convertible bonds.
		 * When it is not active, the standard payoff is taken into account.
		 **/
		class SOPHIS_CB CSRExercisePayoff : public virtual sophis::instrument::CSRClause
		{
		public:
			DECLARATION_CLAUSE(CSRExercisePayoff)
			
			/** 
			 * This function compute the conversion value from the spot value including conversion cost and accrued or full coupon. The proportion
			 * is only here for multiplying the coupons.
			 * it must be a monotone function
			 * @param spot: the underlying spot value.
			 * @param baseConvRatio: the current base conversion ratio.
			 * @param conversionCost: the current conversion cost.
			 * @param proportion: the current proportion.
			 * @param coupon: the full coupon if the date correspond to the date the coupon is in the tree. If not it is zero.
			 * @param accruedCoupon: the current accrued coupon. @see CSROption::IsConversionWithAccrued().
			 * @param t: the current date in the tree.
			 * @return the conversion value.
			 **/
			virtual double funct(double spot, double baseConvRatio, double proportion, double conversionCost, double coupon, double accruedCoupon, double t) const = 0;

			/** 
			 * This function compute the general inverse of funct.
			 * it must be a monotone function.
			 * @param spot: the underlying spot value.
			 * @param baseConvRatio: the current base conversion ratio.
			 * @param conversionCost: the current conversion cost.
			 * @param proportion: the current proportion.
			 * @param coupon: the full coupon if the date correspond to the date the coupon is in the tree. If not it is zero.
			 * @param accruedCoupon: the current accrued coupon. @see CSROption::IsConversionWithAccrued().
			 * @param t: the current date in the tree.
			 * @param max: if true return the maximum value for the general in verse function.
			 * @return the general inverse of the conversion value.
			 **/
			virtual double functInv(double conversionValue, double baseConvRatio, double proportion, double conversionCost, double coupon, double accruedCoupon, double t, bool max) const = 0;

			/** 
			 * This function has to say if the specific user payoff is active. It can also be used to initialise some class variable.
			 * @param computationDate: the date in the tree.
			 * @param context: the market data.
			 * @return true if and only if the specific payoff has to be used at this date. The basic implementation return true if computationDate is 
			 * between start and end clause date (those dates are included).
			 **/
			virtual bool IsActive(double computationDate, const market_data::CSRMarketData &context);
		};
		
		class SOPHIS_CB CSRCreditRiskClause : public virtual instrument::CSRClause
		{
		public:
			DECLARATION_CLAUSE(CSRCreditRiskClause)

			virtual double GetCreditRiskFactorForFixedIncome(long										startDate,
															long										endDate,
															long										seniority,
															long										defaultEvent,
															long										runningCoupon,
															const sophis::market_data::CSRCreditRisk	*creditRisk,
															const market_data::CSRMarketData			&context) const;

			virtual double GetCreditRiskFactorForEquity(long										startDate,
														long										endDate,
														long										seniority,
														long										defaultEvent,
														long										runningCoupon,
														const sophis::market_data::CSRCreditRisk	*creditRisk,
														const market_data::CSRMarketData			&context) const;

			virtual double GetRecoveryRateForFixedIncome(	long										endDate,
															long										seniority,
															long										defaultEvent,
															const market_data::CSRMarketData			&context,
															const sophis::market_data::CSRCreditRisk	*creditRisk) const;

			virtual double GetRecoveryRateForEquity(long										endDate,
													long										seniority,
													long										defaultEvent,
													const market_data::CSRMarketData			&context,
													const sophis::market_data::CSRCreditRisk	*creditRisk) const;
		};

		class SOPHIS_CB CSRAscotStrikeClause : public virtual instrument::CSRClause
		{
		public:
			DECLARATION_CLAUSE(CSRAscotStrikeClause)

			virtual double GetAscotStrike(const market_data::CSRMarketData& context, double maturity) const;
		};
	}
}
SPH_EPILOG
#endif //__CONVETIBLE_BOND_CLAUSE__