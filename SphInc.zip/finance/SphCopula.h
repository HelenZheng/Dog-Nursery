/*
File:		SphCopula.h

Contains:	Class for the handling of copulas.

Copyright:	2007 Sophis.

*/

/*! \file SphCopula.h
\brief Class for the handling of copulas.
*/
#pragma once

#ifndef _SphCopula_H_
#define _SphCopula_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphMath.h"

#include __STL_INCLUDE_PATH(vector)

/** Declaration macro for copulas.

@version 6.0
*/
#define DECLARATION_COPULA(derived)		DECLARATION_PROTOTYPE(derived, sophis::math::CSRCopula)

/** Instantiation macro for copulas.

@version 6.0
*/
#define INITIALISE_COPULA(className, name)	INITIALISE_PROTOTYPE(className, name)

class CSRCreditRiskBasket;	// internal
struct DTitre;				// internal

SPH_PROLOG
namespace sophis
{
	namespace math
	{

typedef _STL::vector<double>			DefaultProbaVect;
typedef _STL::vector<DefaultProbaVect>	DefaultProbaVectList;

/** Interface for copulas in Credit Derivatives

@version 6.0
*/

class SOPHIS_MATH CSRCopula
{
public:

	/** Constructor.

	@version 6.0
	*/
	CSRCopula();

	/** Destructor.

	@version 6.0
	*/
	virtual ~CSRCopula();

	/**
	*	Copula initialisation from an archive. The archive must have been filled
	*	by using virtual void GetStaticData(sophis::tools::CSRArchive& archive) const;
	*/
	virtual void SetStaticData(const sophis::tools::CSRArchive& archive);


	/************************************************************************/
	/*                      One-Factor Methods                              */
	/************************************************************************/

	/** Initializes the copula for One Factor model.

	@param issuerCount
	the number of issuers.

	@param correlationList
	the vector of correlations for which computations will be done.

	@version 6.0
	*/
	virtual void InitialiseForOneFactor(int							issuerCount,
										const _STL::vector<double>&	correlationList);

	/** Returns true if the default probability for the given maturity are not known. For optimization, 
	default probabilities for a given maturity are not computed again if they have already been given 
	to the copula.

	@param maturity
	the maturity

	@version 6.0
	*/
	virtual bool MustRecomputeDefaultProba(double maturity) const;

	/** Reset the optimizations so that the copula can be used with new default probabilities.

	@version 6.0
	*/
	virtual void ResetDefaultProba();

	/** If MustRecomputeDefaultProba(maturity) returns true, this function is called with default probabilities
	as input, to be stored in the copula.

	@param probaVect
	vector of default probabilities of issuers.

	@param maturity
	the maturity

	@see {@link MustRecomputeDefaultProba}

	@version 6.0
	*/
	virtual void FillMarginals(	const DefaultProbaVect&		probaVect,
								double						maturity);

	/** Fills vectors of default probabilities conditionally to the common factor value. 

	@param probaVectList
	output: vector of vector. Each vector contains the default probabilities of issuers conditionally
	to the common factor being commonFactor and for correlations given in InitialiseForOneFactor.

	@param commonFactor
	the value of the common factor for which the conditional probabilities must be computed.

	@param maturity
	the maturity

	@see {@link InitialiseForOneFactor}

	@version 6.0
	*/
	virtual void FillConditionalProba(	DefaultProbaVectList&		probaVectList,
										double						commonFactor,
										double						maturity) const;

	/** Computes the density of the common factor.

	@param densityVect
	Output: densities for correlations given in InitialiseForOneFactor.

	@param commonFactor
	the value of the common factor for which the density must be computed.

	@see {@link InitialiseForOneFactor}

	@version 6.0
	*/
	virtual void GetDensity(_STL::vector<double>& densityVect,
							double				  commonFactor) const;

	/** Called before integrating over the common factor for a given maturity,
	if needed for optimization.

	@param maturity
	the maturity

	@version 6.0
	*/
	virtual void SetMaturity(double maturity);

	/** Returns the common factor minimum for integration.

	@return
	the minimum value of the common factor.

	@version 6.0
	*/
	virtual double GetCommonFactorMin() const;

	/** Returns the common factor maximum for integration.

	@return
	the maximum value of the common factor.

	@version 6.0
	*/
	virtual double GetCommonFactorMax() const;

	/** Returns the common factor accuracy for adaptative trapeze integration.
	Integration over the common factor is performed as a trapeze integration with iterations.
	A step p, 2^p points are used. If the relative difference between two steps is less than accuracy,
	the iteration stops.
	Returns 1e-4 by default.

	@return
	accuracy

	@see {@link GetCommonFactorMaxIter}

	@version 6.0
	*/
	virtual double GetCommonFactorAccuracy() const;

	/** Returns the common factor accuracy for adaptative trapeze integration.
	Integration over the common factor is performed as a trapeze integration with iterations.
	A step p, 2^p points are used. This method returns the maximum number of iterations to be performed.
	Returns 7 by default (128 points).

	@return
	maximum number of iteration

	@see {@link GetCommonFactorMaxIter}

	@version 6.0
	*/
	virtual int GetCommonFactorMaxIter() const;

	/************************************************************************/
	/*                      Monte-Carlo Methods                             */
	/************************************************************************/

	/** Initializes the copula for Monte-Carlo model from a single correlation.

	@param issuerCount
	the number of issuers.

	@param correlVect
	vector of correlations for which the simulations will be done.

	@param defaultProba
	vector of default probability of issuers before maturity $T$.

	@see {@link AcceptSingleCorrel}

	@version 6.0
	*/
	virtual void InitialiseForMonteCarloFromCorrel(	int							issuerCount,
													const _STL::vector<double>&	correlVect,
													const _STL::vector<double>& defaultProba);

	/** Initializes the copula for Monte-Carlo model from a correlation Matrix.

	@param issuerCount
	the number of issuers.

	@param correlMatrix
	matrix of correlations

	@param defaultProba
	vector of default probability of issuers before maturity $T$.

	@see {@link AcceptMatrixCorrel}

	@version 6.0
	*/
	virtual void InitialiseForMonteCarloFromMatrix(	int							issuerCount,
													const UblasMatrixDb&		correlMatrix,
													const _STL::vector<double>& defaultProba);


	/** Returns the number of independent uniform random variables needed to produce one set
	of correlated uniform variables.

	@return the number of random variables

	@see {@link FillCorrelatedSampling}

	@version 6.0
	*/
	virtual int GetNumberVariablesNeeded() const;

	/** Returns true if conditional sampling can be used with the copula.
	If true, FillCorrelatedSampling will be called on every issuer and  GetConditionProbability will be used
	to weight the path.

	False by default.

	@version 6.0
	*/
	virtual bool IsConditionalSamplingAvailable() const;

	/** Set the random sampling before calling FillCorrelatedSampling.

	@param uniformSampling
	array of uniform random variables, of size given by IsConditionalSamplingAvailable

	@see {@link GetNumberVariablesNeeded}
	@see {@link FillCorrelatedSampling}

	@version 6.0
	*/
	virtual void SetSampling(	const double* uniformSampling);

	/** Fills a vector of correlated uniform variables from independent variables input in SetSampling.

	@return
	true if valid path (for conditional sampling)

	@param correlatedSampling
	Output: vector of correlated uniform variables.

	@param issuerIndex 
	If conditional sampling is used, probabilities are computed contionally to the default of issuer issuerIndex
	before maturity. Called with 0 value if contional sampling is not available.

	@param correlIndex
	If the copula has been initialized with a vector of single correlations, the correlation for which the
	sampling has to be computed.

	@see {@link SetSampling}
	@see {@link IsConditionalSamplingAvailable}

	@version 6.0
	*/
	virtual bool FillCorrelatedSampling (	_STL::vector<double>&	correlatedSampling,
											int						issuerIndex,
											int						correlIndex = 0) const;

	/** If conditional sampling is used, computes the conditional weight that issuer indexIssuer has defaulted.

	@return	
	the probability that issuer indexIssuer has defaulted before maturity.

	@param issuerIndex
	the issuer for which the default probability must be computed.

	@param correlIndex
	If the copula has been initialized with a vector of single correlations, the correlation for which the
	sampling has to be computed.

	@see {@link IsConditionalSamplingAvailable}

	@version 6.0
	*/
	virtual double GetConditionProbability(int indexIssuer, int indexCorrel = 0) const;

	virtual _STL::string GetName() const = 0;

	/** Duplicate the copula.

	@return
	a new pointer on an identical copy of the copula, which must be deleted.

	@note that this method is pure virtual.

	@version 6.0
	*/
	virtual CSRCopula *	Clone() const = 0;

	typedef sophis::tools::CSRPrototype< CSRCopula, const char *, sophis::tools::less_char_star > prototype;

	/** Return the prototype containing all the instances of the registered copulas.

	@return
	the prototype containing all the instances of the registered copulas.

	@version 6.0
	*/
	static prototype &	GetPrototype();


};

	}
}
SPH_EPILOG
#endif