/*
File:		SphCopulaData.h

Contains:	Class for the handling of copulas.

Copyright:	2007 Sophis.

*/

/*! \file SphCopulaData.h
\brief Class for the handling of copulas data.
*/
#pragma once

#ifndef _SphCopulaData_H_
#define _SphCopulaData_H_

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/finance/SphCopula.h"
#include "SphInc/gui/SphNewDialog.h"
#include "SphInc/gui/SphDialog.h"
#include "SphInc/instrument/SphInstrument.h"


/** Declaration macro for copulas.

@version 6.0
*/
#define DECLARATION_COPULA_DATA(derived) DECLARATION_PROTOTYPE(derived, sophis::math::CSRCopulaData)

/** Instantiation macro for copulas.

@version 6.0
*/
#define INITIALISE_COPULA_DATA(className, name)	\
	{	\
		className * copulaData = new className(); \
		sophis::math::CSRCopulaData::registerCopulaData( copulaData, name );	\
	}

class CSRCreditRiskBasket;	// internal
struct DTitre;				// internal

SPH_PROLOG
namespace sophis
{
	namespace math
	{

typedef _STL::vector<double>			DefaultProbaVect;
typedef _STL::vector<DefaultProbaVect>	DefaultProbaVectList;

/** Interface for copulas in Credit Derivatives

@version 6.0
*/

class SOPHIS_FIT CSRCopulaData : public sophis::gui::ISRNewDialog
{
public:

	/** Constructor.

	@version 6.0
	*/
	CSRCopulaData();

	/** Destructor.

	@version 6.0
	*/
	virtual ~CSRCopulaData();

	/**
	* Must return the registered string of the copula class inherited CSRCopula that must be filled with the 
	* data coming from this dialog.
	*/
	virtual _STL::string GetCopulaID() const = 0;

	/************************************************************************/
	/* The following methods aim to allow the customisation of a Copula by  */
	/* manipulating its parameters.						*/
	/************************************************************************/
	static void registerCopulaData( CSRCopulaData *copulaData, const char *name ); // internal (use the instantiation macro "INITIALISE_COPULA" instead)
	
	/** Gets the name of the DB Table saving the Copula's parameters' information.

	@return
	The name of the DB Table saving the Copula's parameters' information.

	@version 6.0
	*/
	virtual char *GetTableName() const;
	
	/** Sets the name of the DB Table saving the Copula's parameters' information with its parameter.

	@param name
	The new name of the DB Table saving the Copula's parameters' information.

	@version 6.0
	*/
	virtual void SetTableName(char *name);
	
	/** Redefinition of sophis::gui::ISRNewDialog::new_Dialog() : returns the specificDialog of this Copula
	(if it exists). This method is typically redefined in the toolkit Copula classes (daughters of this one).

	@return
	The Copula's specific Dialog if it is a toolkit one or 0 instead.

	@version 6.0
	*/
	virtual gui::CSRFitDialog * new_Dialog() const;
	
	/** Redefinition of sophis::gui::ISRNewDialog::new_ReadDialog() : do the same thing as the previous.

	@param instrument
	Is not used in this context !
	
	@return
	The Copula's specific Dialog if it is a toolkit one or 0 instead.

	@version 6.0
	*/
	virtual gui::CSRFitDialog * new_ReadDialog(const instrument::CSRInstrument * instrument) const;
	
	/** Loads the value of the element of this Copula's specificDialog specified by "ERId_Element" and puts it
	at "address".

	@param ERId_Element
	The identifier in this Copula of the Element to load.

	@param address
	The address where to load the Element.

	@return
	true if the loading operation has been successfully finished.

	@version 6.0
	*/
	bool LoadSpecificElement(int ERId_Element, void	*address) const;
	
	/** Loads the value of the cell of this Copula's specificDialog's list specified by 
	"(ERId_List, lineNumber, CNb_Column)" and puts it at "address".

	@param ERId_List
	The identifier in this Copula of the List where the Cell (~the Element) to load could be found.

	@param lineNumber
	The line (in the List) of the Element to load.

	@param CNb_Column
	The column (in the List) of the Element to load.
	
	@param address
	The address where to load the Element.

	@return
	true if the loading operation has been successfully finished.

	@version 6.0
	*/
	bool LoadSpecificElement(int ERId_List, int lineNumber, int CNb_Column, void *address) const;
	
	/** Saves the value of the element of this Copula's specificDialog specified by "ERId_Element" from "address".

	@param ERId_Element
	The identifier in this Copula of the Element to save.

	@param address
	The address form where to save the Element.

	@return
	true if the saving operation has been successfully accomplished.

	@version 6.0
	*/
	bool SaveSpecificElement(int ERId_Element, void *address) const;
	
	/** Saves the value of the cell of this Copula's specificDialog's list specified by 
	"(ERId_List, lineNumber, CNb_Column)" from "address".

	@param ERId_List
	The identifier in this Copula of the List where the Cell (~the Element) to save could be found.

	@param lineNumber
	The line (in the List) of the Element to save.

	@param CNb_Column
	The column (in the List) of the Element to save.

	@param address
	The address from where to save the Element.

	@return
	true if the saving operation has been successfully accomplished.

	@version 6.0
	*/
	bool SaveSpecificElement(int ERId_List, int lineNumber, int CNb_Column, void *address) const;
	
	/** Returns the number of lines of this Copula's specificDialog's list specified by "ERId_List".

	@param ERId_List
	The identifier in this Copula of the List which lines number is to be returned.

	@return
	The lines number of the List specified by the parameter.

	@version 6.0
	*/
	int	GetSpecificLineCount(int ERId_List) const;
	
	/** Sets the number of lines of this Copula's specificDialog's list specified by "ERId_List" with "newLineCount".

	@param ERId_List
	The identifier in this Copula of the List which lines number is to be set.

	@param newLineCount
	The new lines number.

	@return
	true if the saving operation has been successfully accomplished.

	@version 6.0
	*/
	bool SaveSpecificLineCount(int ERId_List, int newLineCount);
	//***********************************************************************/

	/************************************************************************/
	/*                      One-Factor Methods                              */
	/************************************************************************/

	/** Returns true if the copula can bu used with One Factor model. False by default.

	@version 6.0
	*/
	virtual bool IsValidForOneFactor() const;

	

	/************************************************************************/
	/*                      Monte-Carlo Methods                             */
	/************************************************************************/

	/** Returns true if the copula can bu used with Monte-Carlo model. False by default.

	@version 6.0
	*/
	virtual bool IsValidForMonteCarlo() const;

	/** Returns true if the copula can be parametrized by a correlation matrix.
	False by default.

	@version 6.0
	*/
	virtual bool AcceptMatrixCorrel() const;

	/** Returns true if the copula can be parametrized by a single parameter.
	False by default.

	@version 6.0
	*/
	virtual bool AcceptSingleCorrel() const;

	/** Returns true if conditional sampling can be used with the copula.
	
		Call method {@link CSRCopula::IsConditionalSamplingAvailable} on the prototype.
	
	@version 6.0
	*/
	bool IsConditionalSamplingAvailable() const;

	/**
	* Store the data needed to initialize the copula in the archive
	*/
	virtual void GetStaticData(sophis::tools::CSRArchive& archive) const;

	
	/**
	* Create a new copula.
	*/
	CSRCopula* new_Copula() const;

	/** Duplicate the copula Data.

	@return
	a new pointer on an identical copy of the copula, which must be deleted.

	@note that this method is pure virtual.

	@version 6.0
	*/
	virtual CSRCopulaData *	Clone() const = 0;

	typedef sophis::tools::CSRPrototype< CSRCopulaData, const char *, sophis::tools::less_char_star > prototype;

	/** Return the prototype containing all the instances of the registered copulas.

	@return
	the prototype containing all the instances of the registered copulas.

	@version 6.0
	*/
	static prototype &	GetPrototype();

	void SetCreditRiskBasket(const CSRCreditRiskBasket* theCreditRiskBasket); // internal

protected :
	/** The name of the DB Table corresponding to this Copula.

	@version 6.0
	*/
	char *fTableName;

	// internal
	infos_user *fCRBiu;
};

	}
}
SPH_EPILOG


#endif