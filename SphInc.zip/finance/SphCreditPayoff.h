#ifndef ___CREDIT_PAYOFF_H__
#define	___CREDIT_PAYOFF_H__

#include "SphInc/finance/SphMonteCarloMultiUnderlying.h"

SPH_PROLOG
namespace sophis {

	namespace finance {

		class SOPHIS_MONTECARLO CSRClientPayoffCredit : public virtual MultiUnderlyingsClientPayoff
		{
		public:
			CSRClientPayoffCredit();
			virtual ~CSRClientPayoffCredit();

			/**	Initialise the payoff for a given option. You should call it in any derived class to 
			*	initialize properly fGeneratorID. 
			*
			*	@param	option is the option for which this object handle actualized payoff computation
			*/
			virtual void Initialise(const instrument::CSRInstrument* instr);

			/** Returns the list of Credit Risk sources on which the payoff depends
			Credit risk sources have an impact on the theoretical value of the instrument, for obvious reasons or because of the model.
			For example, the Issuer/Currency/Seniority of a Bond affect it's theoretical value because of the consequences in case of default (recovery rate)
			The "default event" of the Bond is used to decide which default probability curve to use.
			Thus, the 4-uple (Issuer,Currency,Seniority,DefaultEvent) is a credit risk source for the Bond.
			This method has to be overloaded for toolkit payoff with credit risk sources

			@param outCreditRiskSources is the list of credit risk sources to be filled
			*/
			virtual void GetCreditRiskSources(_STL::set<instrument::SSCreditRiskSource>& outCreditRiskSources) const;

			/** Gives the credit underlyings of the payoff.
			@param	creditUnderlyings is the output, it contains credit underlying codes.
			@since 6.0
			*/
			virtual void GetCreditUnderlyings(_STL::vector<long>& creditUnderlyings) const;

			/** This method is called after calling {@link CSRClientPayoff::Initialise}.
			It sets the credit underlying and the credit copula on the path generator.
			It gets the credit risk sources from the underlying.

			@param option is the derivative
			@param model is the Monte Carlo metamodel
			@since 6.0
			*/
			virtual void InitialiseUnderlyingToDiffuse(	const instrument::CSRInstrument* instr,
														const CSROptionMonteCarloMetaModel*	model);

			/** For credit payoff, this method can be overloaded in order to use a uniform correlation.
			By default, returns 1.
			@param	param is a market data
			@return the credit correlation
			@since 6.0
			*/
			virtual double GetCreditCorrelationUniform(const market_data::CSRMarketData& param) const;

			/** Return the number of antithetic sampling used for pricing
			*/
			virtual int GetAntitheticSamplingCount() const;

			/** Check if a greek should be computed
			*	@param	resultToCompute is the greek we want to know if it should be computed.
			*	@see eGreeksToCompute
			*	@return true if the greek should be computed, else return false.
			*/	
			virtual bool ComputeResults(eGreeksToCompute resultToCompute) const;

			/**	This function store only static data needed to initialise a CSRServerPayoff in an archive {@link sophis::tools::CSRArchive}. 
			*	Static data are the one depending only on gApplicationContext and will be shared by all serverpayoff on server side in order to
			*	minimize bandwith occupation.
			*	In any derived class call the mother GetStaticData.
			*	@param archive is the archive in which we store statics data
			*/
			virtual void GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** Use of GetData had changed since version 5.3. 
			*	Now this function only store market data dependent data.  
			*	needed to initialise a CSRServerPayoff in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRServerPayoff for the Monte Carlo computation on the server side.
			*	In any derived class call the mother GetData.
			*	@param archive is the archive in which we store data
			*/
			virtual void GetData(sophis::tools::CSRArchive& archive) const;

			/**
			* Returns the registered name of the server payoff containing the valuation procedure.
			*/
			virtual _STL::string GetServerPayoffID() const = 0;

			virtual _STL::string GetPayoffType() const;

			// not used for credit payoff, default implementation
			virtual void GetForeignCurrencyRiskSources(_STL::vector<long>& foreignSources) const;
			virtual void GetPayoffUnderlying(	_STL::vector<long>&	equityAndForexRiskSources,
												int&				equityCount) const;
			virtual int GetPayoffUnderlyingCount() const;	
			virtual sophis::instrument::eQuantoType GetQuantoCompoRiskSource(int nth) const;
			virtual int	GetDateCount() const;
			virtual long GetNthDate(int i) const;
			virtual void GetStrikeForVolatilityArray(	int									indexDiffused, 
														const market_data::CSRMarketData&	param, 
														const sophis::instrument::CSROption* option, 
														const _STL::vector<long>&			dates,
														_STL::vector<double>&				strikeVector) const;

		protected:
			_STL::vector<long>							fCreditUnderlying;
			int											fCreditUnderlyingCount;
			int											fAntitheticSamplingCount;
			_STL::set<instrument::SSCreditRiskSource>	fCreditRiskSources;

		};
	}
}

SPH_EPILOG
#endif