#ifndef ___CREDIT_PAYOFF_SERVER_H__
#define	___CREDIT_PAYOFF_SERVER_H__

#include "SphInc/finance/SphMonteCarloMultiUnderlyingServer.h"


SPH_PROLOG
namespace sophis {

	namespace finance {

		class SOPHIS_MONTECARLO_SERVER CSRServerPayoffCredit : public virtual MultiUnderlyingsServerPayoff
		{
		public :

			CSRServerPayoffCredit();

			virtual ~CSRServerPayoffCredit();

			/** Compute the option payoff associated with the underlying path and fill a temporary buffer in CSRServerOutput abject.
			* Here, calls GetPayoffValue for each antithetic sample and multiply the returned value by the relevant weight.
			*
			* @param path is an input parameter corresponding to the underlying paths which are used to compute payoff
			* @param output is an output buffer corresponding in which we write result of a payoff computation.
			*/
			virtual void operator() (const CSRLocalPath* path, CSRServerOutput* serverOutput) const;

			/** Computes the payoff for one path. This is the method to overload to create a new credit payoff.
			@return the discounted value of the payoff
			@param path is the CSRLocalPath containing credit events
			@param nthAntitheticSampling is the antithetic sampling ID for which the payoff must be computed.
			*/
			virtual double GetPayoffValue(const CSRLocalPath* path, int nthAntitheticSampling) const = 0;

			/** Give the number of antithetic sampling used for pricing;
			* @return the number of antithetic sampling used for pricing;
			*/
			virtual int GetAntitheticSamplingCount(const CSRLocalPathGeneratorServer & pathGenerator) const;

			/** Initialise the CSRServerPayoff with static data stored in an archive {@link sophis::tools::CSRArchive}
			*	This is done in order to create one or several payoff object on the server side.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRServerPayoff
			*/
			virtual void SetStaticData(const sophis::tools::CSRArchive& archive, const CSRLocalPathGeneratorServer* pgs);

			/** Initialise the CSRServerPayoff with the market dependent data stored in an archive {@link sophis::tools::CSRArchive}
			*	
			*	This is done in order to create one or several payoff object on the server side.
			*	@param archive is the archive storing the data needed to initialise the CSRServerPayoff
			*/
			virtual void SetData(const sophis::tools::CSRArchive& archive);

		protected:

			int					fCreditUnderlyingCount;
			_STL::vector<long>	fCreditUnderlying;

		};

	}	//finance

}// //sophis

SPH_EPILOG
#endif