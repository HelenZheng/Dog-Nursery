/*
 	File:		SphDefaultMetaModelBond.h

 	Contains:	Class for the handling default Bond metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelBond_H_
#define _SphDefaultMetaModelBond_H_

#include "SphInc/instrument/SphBond.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		class SOPHIS_FIT ISRMetaModelBond
		{
		public :
			virtual double ComputeFlatCurvePrice(	const instrument::CSRInstrument		&instr,
													long								transactionDate, 
													long								settlementDate, 
													long								ownershipDate, 
													const market_data::CSRMarketData	&flatCurveParam,
													int									ZCType, 
													bool								weighting,
													const market_data::CSRMarketData	&context,
													bool								adjustedDates,
													bool								valueDates) const = 0;

			
			virtual double	ComputeNonFlatCurvePrice(	const instrument::CSRInstrument					&instr,
														long											transactionDate,
														long											settlementDate,		
														long											ownershipDate,
														const market_data::CSRMarketData				&param,
														double											*derivative,
														const static_data::CSRDayCountBasis				*base,
														short											adjustedDates,
														short											valueDates,
														const static_data::CSRDayCountBasis				*dayCountBasis,
														const static_data::CSRYieldCalculation			*yieldCalculation,
														_STL::vector<instrument::SSRedemption>			*redemptionArray,
														_STL::vector<instrument::SSBondExplication>		*explicationArray,
														bool											withSpreadMgt,
														bool											throwException) const = 0;


			virtual double	GetDirtyPriceByZeroCoupon(	const instrument::CSRBond				&bond,
														const market_data::CSRMarketData		&context,
														long 									transactionDate, 
														long 									settlementDate,
														long									ownershipDate,
														short									adjustedDates,
														short									valueDates		  = kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis	  = 0, 
														const static_data::CSRYieldCalculation	*yieldCalculation = 0) const = 0;


		};

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRBond.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelBond : public virtual CSRMetaModel , public ISRMetaModelBond
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelBond);
			CSRDefaultMetaModelBond(const CSRDefaultMetaModelBond & toCopy);
			virtual ~CSRDefaultMetaModelBond(){};

			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetInflationRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;








			/** Get the forward price.
			@param futureDate
			is the expiry of the forward, in number of days from 1/1/1904.
			@param forEvaluation
			is the tax credit percentage type to take into account.
			@param context
			is the market data.

			@usage
			See VBA examples on ISphCInstrument.
			@endusage
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			/** Get the forward prices.
			@param futureDate is an array of expiries of the forward, in number of days from 1/1/1904.
			@param val is an output array for the values, which must be effectively allocated.
			@param dateCount is the number of dates in the array.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			This method is used in model option with NMU, to give the drift
			of the underlying. As there is normally more than one forward to calculate
			and a significant optimisation to calculate a list of forwards,
			this method is called for each expiry date.
			The default implementation is to call it for each expiry date.
			@see GetForwardPrice(long futureDate, eTaxCreditPercentageType forEvaluation, const market_data::CSRMarketData& context)
			@since 5.3
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument				&instr,
											long					 					*futureDates,
											double					 					*val,
											short					 					dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			/** Gets the value of the cash as a linear formula, when the bond is a future's underlying.
			@param computationDate
			is the date for the cash.
			@param futureDate
			is the expiry date for the cash.
			@param settlementType
			is the settlement type of the option.
			@param forEvaluation
			is the tax credit percentage type to take into account.
			This has no effect, and is not used by the method.
			@param a
			is an output coefficient corresponding to a factor to multiply the future.
			@param b
			is an output coefficient to a term to add to the future.
			@param rate
			is an output coefficient corresponding to a compound factor to get the pay-off.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			The spot will be $\f a F + b $\f and the pay-off with a strike $\f K $\f will be
			$\f \frac{a F + b - K}{\mbox{rate}} $\f.

			@usage
			See VBA examples on ISphCInstrument.
			@endusage

			@usageC#
			sophis.instrument.CSMBond sph_bond = sophis.instrument.CSMBond.GetInstance(67157362);
			sophis.instrument.eMSettlementType settle = sophis.instrument.eMSettlementType.M_sFuture;
			sophis.market_data.eMTaxCreditPercentageType forEval = sophis.market_data.eMTaxCreditPercentageType.M_tcpFuture;
			double a=0, b=0, rate=0;
			sph_bond.GetLinearValue(dateBegin,(int)dateEnd,settle,forEval,ref a,ref b,ref rate,context);
			@endusageC#
			*/
			virtual	void	GetLinearValue(	const instrument::CSRInstrument			&instr,
											double						computationDate,
											long 						futureDate,
											instrument::eSettlementType 			settlement,
											market_data::eTaxCreditPercentageType	forEvaluation,
											double 						*a,
											double 						*b,
											double 						*rate,
											const market_data::CSRMarketData &context) const OVERRIDE;			

			/** Gets the duration using the Interest Rate curve, using the evaluation date (from the context) as the transaction date.
			From the context's evaluation date ({@link market_data::CSRMarketData::GetDate}), the settlement date and the ownership date
			are obtained. See {@link CSRBond::GetDurationByZC} for explanation on how the duration is calculated.
			The methods for calculation mode and day count basis, are taken from the bond's Market Data.
			@descCOM
			Gets the duration using the Interest Rate curve, using the evaluation date (from the context) as the transaction date.
			From the context's evaluation date ({@link ISphCMarketData::GetDate}), the settlement date and the ownership date
			are obtained. See {@link ISphCBond::GetDurationByZC} for explanation on how the duration is calculated.
			@enddescCOM

			@descC#
			Gets the duration using the Interest Rate curve, using the evaluation date (from the context) as the transaction date.
			From the context's evaluation date ({@link market_data::CSMMarketData::GetDate}), the settlement date and the ownership date
			are obtained. See {@link CSMBond::GetDurationByZC} for explanation on how the duration is calculated.
			@enddescC#

			@param context
			is a market data.
			@return
			the duration in number of years.

			@usage
			Dim manager As New SphCInstrument
			Dim sph_bond As SphCBond
			Set sph_bond = New SphCBond 
			sph_bond.GetFrom manager.GetInstance1(45852233) 'set sph_bond to an existing Bond (code for illustration only)

			Dim context As New SphCMarketData
			Dim sph_day As New SphDay

			Dim dateEvaluation As Long
			Dim duration As Double

			sph_day.InitWithString "20060117"  ' 17/01/2006
			dateEvaluation = sph_day.GetDateAsLong
			context.SetGlobalDate dateEval
			duration = sph_bond.GetDuration(context)
			@endusage
			*/
			virtual double  GetDuration(const instrument::CSRInstrument& instr,
						    const market_data::CSRMarketData& context,
						    const sophis::CSRComputationResults* results = 0) const OVERRIDE;

			/** Get the modified duration.
			@param context:	is a market data.
			@param ytm:		is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.

			@return:		the modified duration as a number of years.

			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double			GetModDuration(	const instrument::CSRInstrument& instr, 
													const market_data::CSRMarketData&context,
													double							ytm	= NOTDEFINED) const OVERRIDE;



			/** Generates the credit risk data structure.
			@param context:		is the market data which can modify the credit risk structure.

			@return:			the credit risk data structure. Note: the object returned must be deleted (de-allocated) from memory after use.
			@returnC#:			the credit risk data structure.
			@endreturnC#
	
			@usage
				Dim manager As New SphCInstrument
				Dim sph_bond As SphCBond
				Set sph_bond = New SphCBond 
				sph_bond.GetFrom manager.GetInstance1(45852233) 'set sph_bond to an existing Bond (code for illustration only)
				Dim context As New SphCMarketData
				Dim creditRisk As SphCCreditRisk
				Set creditRisk = sph_bond.new_CreditRisk(context)
				If creditRisk Is Nothing Then
					Dim code As Long
					code = creditRisk.GetIssuerCode
				End If
			@endusage
			*/
			virtual market_data::CSRCreditRisk*	new_CreditRisk(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const  OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, instrument::CSRCoxTreeGraphics *graph) const  OVERRIDE;

			/*
			Get min and max bounds for MtM spread computation by Newton-Raphson.
			@param min returns the minimum value
			@param max returns the maximum value
			@since 5.3
			*/
			virtual void	GetMinMaxForMtMSpread(	const instrument::CSRBond				&bond,
													long 	transactionDate, 
													long 	settlementDate,
													long	pariPassuDate,
													long	usedFamilyOrYieldCurve,
													double	dirtyPrice,
													double	&min,
													double	&max) const;



			//CSRInterfaceMetaModelBond Functions
			
			/** Low level computation of dirty price from YTM.

			@ param instr : the instrument to be priced
			@param transactionDate : the transaction date.
			@param settlementDatethe : payment date.
			@param ownershipDatethe ownership date, that is the date when the bond belongs to the buyer.
			@param flatCurveParam : the market data for flat curves.
			@param ZCType : the zero coupon type.
			@param weighting : true for computing time weighted price (for duration)
			@param context : the market data
			@param adjustedDates : ytm computed on adjusted date
			@param	valueDates : ytm computed on value date

			@version 6.1.1*/

			virtual double ComputeFlatCurvePrice(	const instrument::CSRInstrument		&instr,
													long								transactionDate, 
													long								settlementDate, 
													long								ownershipDate, 
													const market_data::CSRMarketData	&flatCurveParam,
													int									ZCType, 
													bool								weighting,
													const market_data::CSRMarketData	&context,
													bool								adjustedDates,
													bool								valueDates) const;

			
			/** Low level computation of dirty price (or duration) of a bond or debt instrument from the zero coupon curve

			@param instr:				the instrument to be priced
			@param transactionDate:		the transaction date.
			@param settlementDate:		the payment date.
			@param ownershipDate:		the ownership date, that is the date when the bond belongs to the buyer.
			@param context:				the market data
			@param base:				Day count basis used for computing duration. Must be 0 when computing a price.
			@param adjustedDates:		ytm computed on adjusted date
			@paramvalueDates:			computed on value date
			@param dayCountBasis:		the day count basis used for computation.
			@param yieldCalculation:	ytm yield calculation type
			@param redemptionArray:		pointer to a redemption array if not null, the redemption array is filled
			@param explanationArray:	pointer to a explanation array if not null, the explanation array is filled
			@param withSpreadMgt:		true if spread must be considered
			@param throwException:		true is exception must be thrown in credit computation

			@version 6.1.1
			*/
			virtual double	ComputeNonFlatCurvePrice(	const instrument::CSRInstrument					&instr,
														long											transactionDate,
														long											settlementDate,		
														long											ownershipDate,
														const market_data::CSRMarketData				&param,
														double											*derivative,
														const static_data::CSRDayCountBasis				*base,
														short											adjustedDates,
														short											valueDates,
														const static_data::CSRDayCountBasis				*dayCountBasis,
														const static_data::CSRYieldCalculation			*yieldCalculation,
														_STL::vector<instrument::SSRedemption>			*redemptionArray,
														_STL::vector<instrument::SSBondExplication>		*explicationArray,
														bool											withSpreadMgt,
														bool											throwException) const;


			virtual double	GetDirtyPriceByZeroCoupon(	const instrument::CSRBond				&bond,
														const market_data::CSRMarketData		&context,
														long 									transactionDate, 
														long 									settlementDate,
														long									ownershipDate,
														short									adjustedDates,
														short									valueDates		  = kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis	  = 0, 
														const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			virtual double	GetCoupon(	const instrument::CSRBond &					bond,
										const market_data::CSRMarketData &			context,
										const instrument::SSRedemption &			flow,
										static_data::SSCouponCalculation &			ccData,
										instrument::CSRCashFlowInformation *		rateExplanation) const;

			
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

		protected:
			void	Initialize(const CSRDefaultMetaModelBond & toCopy);
			virtual void ComputeAllCore(instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, CSRComputationResults& results) const OVERRIDE;
		};
		
		
		class SOPHIS_FIT CSRMetaModelBondPriceToFirstCall : public virtual CSRDefaultMetaModelBond
		{
		public:
			DECLARATION_META_MODEL(CSRMetaModelBondPriceToFirstCall);
			CSRMetaModelBondPriceToFirstCall(const CSRMetaModelBondPriceToFirstCall & toCopy);
			virtual ~CSRMetaModelBondPriceToFirstCall();


			virtual void	RecomputeYTM(	instrument::CSRInstrument & instrument,
											const market_data::CSRMarketData& context, 
											sophis::CSRComputationResults& results, 
											double price) const;

			virtual double	GetDirtyPriceByZeroCoupon(	const instrument::CSRBond				&bond,
											const market_data::CSRMarketData		&context,
											long 									transactionDate, 
											long 									settlementDate,
											long									ownershipDate,
											short									adjustedDates,
											short									valueDates		  = kUseDefaultValue,
											const static_data::CSRDayCountBasis		*dayCountBasis	  = 0, 
											const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;



			virtual double ComputeDirtyPrice(	const instrument::CSRInstrument					&instr,
												long											transactionDate,
												long											settlementDate,									
												long											ownershipDate,									
												const market_data::CSRMarketData				&context,										
												double											*sensibility	  = 0,							
												const sophis::static_data::CSRDayCountBasis		*basis			  = 0,		
												short											adjustedDates	  = kUseDefaultValue,			
												short											valueDates		  = kUseDefaultValue,			
												const sophis::static_data::CSRDayCountBasis		*dayCountBasis	  = 0,		
												const sophis::static_data::CSRYieldCalculation	*yieldCalculation = 0,		
												_STL::vector<instrument::SSRedemption>			*redemptionArray  = 0,							
												_STL::vector<instrument::SSBondExplication>		*explicationArray = 0) const;


		protected:
			void	Initialize(const CSRMetaModelBondPriceToFirstCall & toCopy);
		};


		

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelBond_H_
