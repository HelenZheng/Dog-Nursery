/*
 	File:		SphDefaultMetaModelCPPI.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelCPPI_H_
#define _SphDefaultMetaModelCPPI_H_

#include "SphInc/instrument/SphCPPI.h"
#include "SphInc/finance/SphDefaultMetaModelOption.h"

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		class SOPHIS_CPPI_CLIENT CSRDefaultMetaModelCPPI : public virtual CSRDefaultMetaModelOption
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelCPPI)
			virtual ~CSRDefaultMetaModelCPPI();

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			UNMASK_FUNCTION(CSRDefaultMetaModelOption, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelCPPI_H_