/*
 	File:		SphDefaultMetaModelCapFloor.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelCapFloor_H_
#define _SphDefaultMetaModelCapFloor_H_

#include "SphInc/instrument/SphCapFloor.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRCapFloor.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelCapFloor : public virtual CSRMetaModel
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelCapFloor)
				
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetInflationRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
				
			//virtual instrument::CSRGreekValues* new_GreekValues(const instrument::CSRInstrument& instrument) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(	const instrument::CSRInstrument &	instrument,
											const market_data::CSRMarketData &	context) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, instrument::CSRCoxTreeGraphics *graph) const OVERRIDE;

			virtual double	GetTheoreticalValue(const instrument::CSRInstrument &		instrument, 
												const market_data::CSRMarketData &		context, 
												_STL::vector<instrument::SSCaplet> *	vectorToFill,
												sophis::instrument::CSRCashFlowInformationList *explanation, 
												int							startFlowIndex = -1,
												int							endFlowIndex   = -1) const OVERRIDE;

			virtual double	GetFirstDerivative(	const instrument::CSRInstrument &	instrument,
										const market_data::CSRMarketData &	context,
										int						which) const OVERRIDE;

			virtual double	GetSecondDerivative(	const instrument::CSRInstrument &	instrument,
											const market_data::CSRMarketData &	context,
											int						which1,
											int						which2) const OVERRIDE;

			virtual void	GetPriceDeltaGamma(	const instrument::CSRInstrument &	instrument,
										const market_data::CSRMarketData &	context,
										double *				price,
										double *				delta,
										double *				gamma,
										int						which) const OVERRIDE;

			virtual double GetEquityGlobalVega(	const instrument::CSRInstrument &	instrument,
										const market_data::CSRMarketData &	context) const OVERRIDE;

			virtual double GetEquityGlobalVega(	const instrument::CSRInstrument &	instrument, const sophis::CSRComputationResults& results) const OVERRIDE;

			virtual bool	IsAbleToPrice( const instrument::CSRInstrument & toCheck , _STL::string *message) const OVERRIDE;

			/** Get the cash flow diagram used to compute duration and modified duration.
			By default returns new_CashFlowDiagram(context)
			It is overloaded for example in CSROption to include only the bond part
			@param context is a market data
			@return a new cash flow diagram.
			@since 6.0
			@see CSRCashFlowDiagram
			*/
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagramForDuration(const instrument::CSRInstrument& instrument, const market_data::CSRMarketData& context) const OVERRIDE;

		private:
			double GetNthCapletTheoreticalValue(	instrument::CSRCapFloor *			capFloor,
													const market_data::CSRMarketData &	context,
													int						i,
													instrument::SSCaplet *				capletInfos,
													sophis::instrument::CSRCashFlowInformation *explanation) const;

			mutable _STL::vector< instrument::SSCaplet >	fCapletsVector;

		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		private:
			DEPRECATED_OBSOLETE virtual double	GetTheoreticalValue(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData &context, _STL::vector<instrument::SSCaplet> *vectorToFill,int startFlowIndex,int endFlowIndex) const;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelCapFloor_H_