/*
 	File:		SphDefaultMetaModelContractForDifference.h

 	Contains:	Class for the handling default Loan and repo metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelContractForDifference_H_
#define _SphDefaultMetaModelContractForDifference_H_

#include "SphInc/instrument/SphContractForDifference.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRBond.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelContractForDifference : public virtual CSRMetaModel 	
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelContractForDifference);
			virtual ~CSRDefaultMetaModelContractForDifference();

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetVegaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetEpsilonRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetInflationRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual double	GetCrossedVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int which1, int which2) const OVERRIDE;
			virtual double	GetVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int whichUnderlying) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual	double	GetEquityGlobalVegaMarket(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual	double	GetEquityGlobalVegaMarket(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual void	GetPriceDeltaGamma(	const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double *price, double *delta, double *gamma, int whichUnderlying) const OVERRIDE;
			virtual double	GetEpsilon(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which) const  OVERRIDE;
			virtual	double	GetGlobalEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double	GetRho(const instrument::CSRInstrument & instrument,const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double	GetConvexity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void	GetRhoConvexity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, double price, double *rho, double *convexity, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double	GetCrossedDeltaRho(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying, int whichCurrency, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void	GetDeltaGamma(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const sophis::CSRComputationResults& results, double *delta,  double *gamma,  int whichUnderlying) const OVERRIDE;
			virtual void	ComputeCreditRiskSensitivities(const instrument::CSRInstrument	&instrument, const market_data::CSRMarketData &context, const sophis::CSRComputationResults& results, double refPrice, double &sensitivity, double &convexity, bool computeCrossedGammas, bool computeAllCreditDeltaGamma = true) const OVERRIDE;
			virtual double	GetCreditRiskDelta(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &source) const OVERRIDE;
			virtual double	GetCreditRiskGamma(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &source1, const instrument::SSCreditRiskSource &source2) const OVERRIDE;
			virtual void	ComputeInflationSensitivities(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData &context, double &sensitivity, double &convexity, long inflationCode1, long inflationCode2) const OVERRIDE;
			virtual double	ComputeInflationVega(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual double	GetCreditRiskSensitivity(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double	GetCreditRiskConvexity(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetRecoveryRateSensitivity(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData& context) const OVERRIDE;
		};

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelContractForDifference_H_