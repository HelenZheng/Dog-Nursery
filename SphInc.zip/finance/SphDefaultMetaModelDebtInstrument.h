/*
 	File:		SphDefaultMetaModelDebtInstrument.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelDebtInstrument_H_
#define _SphDefaultMetaModelDebtInstrument_H_

#include "SphInc/instrument/SphDebtInstrument.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRDebtInstrument.
		*/

		class SOPHIS_FIT CSRDefaultMetaModelDebtInstrument : public virtual CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelDebtInstrument)
		
		public:
			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, 
												const market_data::CSRMarketData &context) const OVERRIDE;

			// GetDuration() uses new_CashFlowDiagram
			/** Get the duration.
			@param context is a market data.
			@return the duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetDurationByZC.
			@since 5.3
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double			GetDuration(const instrument::CSRInstrument & instr,
								    const market_data::CSRMarketData& context,
								    const sophis::CSRComputationResults* results = 0) const OVERRIDE;

			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double			GetModDuration(	const instrument::CSRInstrument & instr, 
													const market_data::CSRMarketData	&context,
													double								ytm = NOTDEFINED) const OVERRIDE;

			virtual market_data::CSRCreditRisk* new_CreditRisk(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;
		};

		class SOPHIS_FIT CSRDefaultMetaModelInterestRate : public virtual CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelInterestRate)
		
		public:
			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument & instr, 
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType	settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData &context) const OVERRIDE;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

		};


	}//end of finance
}//end of sophis

SPH_EPILOG

#endif //_SphDefaultMetaModelDebtInstrument_H_
