/*
 	File:		SphDefaultMetaModelEquity.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelEquity_H_
#define _SphDefaultMetaModelEquity_H_

#include "SphInc/instrument/SphEquity.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		/**
		Class to factorize the old code in CSREquity.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelEquity : public virtual CSRMetaModel
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelEquity);

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			virtual void GetForwardRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetVegaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual market_data::CSRMarketData* new_ComputationContext(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context, 
																		const sophis::CSRComputationResults& riskSources,
																		double basketValue, 
																		bool smile) const OVERRIDE;

			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int whichUnderlying) const OVERRIDE;

			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;

			virtual double	GetRho(const instrument::CSRInstrument & instr,const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;

			virtual double	GetVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int whichUnderlying) const OVERRIDE;

			virtual double	GetConvexity(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;

			//virtual double	GetCrossedDeltaRho(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int whichUnderlying, int whichCurrency) const;

			virtual double	GetCrossedVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int which1, int which2) const OVERRIDE;

			virtual double	GetTheta(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const OVERRIDE;

			/** Get the value of the cash from the future without linear formula.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			If the GetLinearValue returns an output a to 0, the model assumes there is no linear formula and calls for each point of the tree to get the spot.
			By default, if there is an arbitrage with an underlying model, consult the arbitrage, otherwise return spot = futureValue.

			@param computationDate
			is the date for the cash, in number of days from 1/1/1904.

			@param futureDate
			is the expiry date for the cash, in number of days from 1/1/1904.

			@param futureValue
			is the future value.

			@param settlementType
			is the settlement type of the option.

			@param forEvaluation
			is the tax credit percentage type to take into account.

			@param spot
			is the cash value produced by the method.

			@param context
			Is the market data.

			@usage
			Dim sph_instrument As SphCInstrument
			Set sph_instrument = New SphCInstrument
			... ' set sph_instrument to an existing instrument
			Dim context As SphCMarketData
			Dim sph_day As New SphDay
			Dim value As Double
			Dim valueFuture As Double
			Dim dateFuture As Long
			Dim dateComputation As Long
			sph_day.InitWithString "20060120"   '  computation date is 20th Jan 2006
			dateComputation = sph_day.GetDateAsLong
			sph_day.InitWithString "20080131"   '  future date is 31st Jan 2008
			dateFuture = sph_day.GetDateAsLong
			valueFuture = 15
			Set context = New SphCMarketData
			sph_instrument.GetValue dateComputation, dateFuture, valueFuture, SphE2_sNewShare, _
			SphE2_tcpOption, value, context
			...
			Set sph_day = Nothing
			@endusage
			*/
			virtual	void	GetValue(	const instrument::CSRInstrument & instr,
										double 					 computationDate,
										long 					 futureDate,
										double 					 futureValue,
										instrument::eSettlementType 		 settlementType,
										market_data::eTaxCreditPercentageType forEvaluation,
										double 					 *spot,
										const market_data::CSRMarketData 	 &context) const OVERRIDE;
	

			virtual double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;

			/** Get the forward prices.
			This method is used in model option with NMU, to give the drift of the underlying. As there is normally more than one
			forward to calculate and a significant optimisation to calculate a list of forwards, this method is called for each expiry date.
			The default implementation is to call it for each expiry date.

			@param futureDate
			is an array of expiries of the forward, in number of days from 1/1/1904.

			@param val
			is an output array for the values, which must be effectively allocated.

			@param dateCount
			is the number of dates in the array.

			@param forEvaluation
			is the tax credit percentage type to take into account.

			@param context is the market data.

			@usage
			COM: Fails- method does not accept array parameters (futureDates)
			@endusage
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long										*futureDates,
											double										*val,
											short										dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			/** Get the forward price.
			This method is used in model option where NMU is used to give the drift of the underlying. It may not be the forward of the spot but of another underlying.
			The real value of the spot will be calculated by GetValue.
			By default, if there is an arbitrage with underlying model, check with the arbitrage, otherwise return the cash value.

			@param futureDate
			is the expiry of the forward, in number of days from 1/1/1904.

			@param forEvaluation
			is the tax credit percentage type to take into account.
			See {@link market_data::eTaxCreditPercentageType}.

			@paramCOM forEvaluation
			is the tax credit percentage type to take into account.
			See {@link SphE2TaxCreditPercentageType}.
			@endparamCOM

			@paramC# forEvaluation
			is the tax credit percentage type to take into account.
			See {@link market_data::eMTaxCreditPercentageType}.
			@endparamC#

			@param context
			is the market data.

			@return
			The value of forward price.

			@usage
			Dim sph_instrument As SphCInstrument
			Set sph_instrument = New SphCInstrument
			... ' set sph_instrument to an existing instrument
			Dim context As SphCMarketData
			Dim sph_day As New SphDay
			Dim valueFuture As Double
			Dim dateFuture As Long
			sph_day.InitWithString "20080131"   '  future date is 31st Jan 2008
			dateFuture = sph_day.GetDateAsLong
			Set context = New SphCMarketData
			valueFuture = sph_instrument.GetForwardPrice(dateFuture, SphE2_tcpOption, context)
			...
			Set sph_day = Nothing
			@endusage
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			/** Get the value of the cash from the future as a linear formula.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			The spot will be $\f a F + b $\f and the pay-off with a strike $\f K $\f will
			be $\f \frac{a F + b - K}{\mbox{rate}} $\f. Note that if 'a' is null, meaning that the
			cash is not a linear formula in the future, the algorithm calls GetValue.
			By default, if there is an arbitrage with underlying model, asks the arbitrage. Else, it sets a = 1, b = 0 and rate = 1.

			@param computationDate
			is the date for the cash.

			@param futureDate
			is the expiry date for the cash.

			@param settlementType
			is the settlement type of the option.

			@param forEvaluation
			is the tax credit percentage type to take into account.

			@param a
			is an output coefficient corresponding to a factor to multiply the future.

			@param b
			is an output coefficient to a term to add to the future.

			@param rate
			is an output coefficient corresponding to a compound factor to get the pay-off.

			@param context
			the market data for computation.

			@usage
			Dim sph_instrument As SphCInstrument
			Set sph_instrument = New SphCInstrument
			... ' set sph_instrument to an existing instrument
			Dim context As SphCMarketData
			Dim sph_day As New SphDay
			Dim valueLinear As Double
			Dim dateFuture As Long
			Dim dateComputation As Long
			Dim a As Double
			Dim b As Double
			sph_day.InitWithString "20060120"   '  computation date is 20th Jan 2006
			dateComputation = sph_day.GetDateAsLong
			sph_day.InitWithString "20080131"   '  future date is 31st Jan 2008
			dateFuture = sph_day.GetDateAsLong
			Set context = New SphCMarketData
			sph_instrument.GetLinearValue dateComputation, dateFuture, SphE2_sNewShare, _
			SphE2_tcpOption, a, b, valueLinear, context
			...
			Set sph_day = Nothing
			@endusage
			*/
			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelVolatilityIndex : public virtual CSRDefaultMetaModelEquity
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelVolatilityIndex);

		public:
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			/** Get the forward price.
			This method is used in model option where NMU is used to give the drift of the underlying. It may not be the forward of the spot but of another underlying.
			The real value of the spot will be calculated by GetValue.
			By default, if there is an arbitrage with underlying model, check with the arbitrage, otherwise return the cash value.
			@param	futureDate is the expiry of the forward, in number of days from 1/1/1904.
			@param	forEvaluation is the tax credit percentage type to take into account.
			See {@link market_data::eTaxCreditPercentageType}.
			@param	context	is the market data.
			@return	The value of forward price.
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;


			/** Get the value of the cash from the future as a linear formula.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			The spot will be $\f a F + b $\f and the pay-off with a strike $\f K $\f will
			be $\f \frac{a F + b - K}{\mbox{rate}} $\f. Note that if 'a' is null, meaning that the
			cash is not a linear formula in the future, the algorithm calls GetValue.
			By default, if there is an arbitrage with underlying model, asks the arbitrage. Else, it sets a = 1, b = 0 and rate = 1.
			@param computationDate 	is the date for the cash.
			@param futureDate	is the expiry date for the cash.
			@param settlementType	is the settlement type of the option.
			@param forEvaluation	is the tax credit percentage type to take into account.
			@param a	is an output coefficient corresponding to a factor to multiply the future.
			@param b	is an output coefficient to a term to add to the future.
			@param rate	is an output coefficient corresponding to a compound factor to get the pay-off.
			@param context	the market data for computation.
			*/
			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;
		};

		class SOPHIS_FIT CSRDefaultMetaModelIssuer : public virtual CSRDefaultMetaModelEquity
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelIssuer);

		public:
			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			virtual market_data::CSRMarketData* new_ComputationContext(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context, 
																		const sophis::CSRComputationResults& riskSources,
																		double basketValue, 
																		bool smile) const OVERRIDE;

			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate,
											long 					futureDate,
											instrument::eSettlementType 		settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					*a,
											double 					*b,
											double 					*rate,
											const market_data::CSRMarketData&context) const OVERRIDE;

			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					computationDate, 
										long 					futureDate, 
										double 					fowardValue,
										sophis::instrument::eSettlementType settlementType, 
										sophis::market_data::eTaxCreditPercentageType forEvaluation,
										double 					*forex,
										const sophis::market_data::CSRMarketData 	&context) const OVERRIDE;

			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;
			virtual double	GetFirstDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int whichUnderlying) const OVERRIDE;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which1, int which2) const OVERRIDE;
			virtual double	GetRho(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double	GetConvexity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;

			virtual double	GetVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which) const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double	GetCrossedVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int whichUnderlying1, int whichUnderlying2) const OVERRIDE;
			virtual double	GetTheta(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelCompoBasket : public virtual CSRDefaultMetaModelEquity
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelCompoBasket);

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate,
											long 					futureDate,
											instrument::eSettlementType 		settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					*a,
											double 					*b,
											double 					*rate,
											const market_data::CSRMarketData&context) const OVERRIDE;

			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					computationDate, 
										long 					futureDate, 
										double 					fowardValue,
										sophis::instrument::eSettlementType settlementType, 
										sophis::market_data::eTaxCreditPercentageType forEvaluation,
										double 					*forex,
										const sophis::market_data::CSRMarketData 	&context) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelCompoRepoBasket : public virtual CSRDefaultMetaModelCompoBasket
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelCompoRepoBasket);

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate, 
											long 					futureDate,
											sophis::instrument::eSettlementType settlementType, 
											sophis::market_data::eTaxCreditPercentageType forEvaluation, 
											double 					*a, 
											double 					*b,
											double 					*rate,
											const  sophis::market_data::CSRMarketData  	&context) const OVERRIDE;

			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					computationDate, 
										long 					futureDate, 
										double 					fowardValue,
										sophis::instrument::eSettlementType settlementType, 
										sophis::market_data::eTaxCreditPercentageType forEvaluation,
										double 					*forex,
										const sophis::market_data::CSRMarketData 	&context) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelStandardCompoBasket : public virtual CSRDefaultMetaModelCompoBasket
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelStandardCompoBasket);

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate, 
											long 					futureDate,
											sophis::instrument::eSettlementType settlementType, 
											sophis::market_data::eTaxCreditPercentageType forEvaluation, 
											double 					*a, 
											double 					*b,
											double 					*rate,
											const  sophis::market_data::CSRMarketData  	&context) const OVERRIDE;

			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					computationDate, 
										long 					futureDate, 
										double 					fowardValue,
										sophis::instrument::eSettlementType settlementType, 
										sophis::market_data::eTaxCreditPercentageType forEvaluation,
										double 					*forex,
										const sophis::market_data::CSRMarketData 	&context) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelQuantoBasket : public virtual CSRDefaultMetaModelEquity
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelQuantoBasket);

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate,
											long 					futureDate,
											sophis::instrument::eSettlementType 		settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					*a,
											double 					*b,
											double 					*rate,
											const market_data::CSRMarketData  	&context) const OVERRIDE;

			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					computationDate, 
										long 					futureDate, 
										double 					fowardValue,
										sophis::instrument::eSettlementType settlementType, 
										sophis::market_data::eTaxCreditPercentageType forEvaluation,
										double 					*forex,
										const sophis::market_data::CSRMarketData 	&context) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRDefaultMetaModelMultiCurrencyBasket : public virtual CSRDefaultMetaModelEquity
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelMultiCurrencyBasket);

		public:
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					computationDate,
											long 					futureDate,
											sophis::instrument::eSettlementType 		settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					*a,
											double 					*b,
											double 					*rate,
											const market_data::CSRMarketData  	&context) const OVERRIDE;

			virtual void			GetValue(		const instrument::CSRInstrument& instr,
											double 						computationDate,
											long 						fowardDate,
											double 						fowardValue,
											sophis::instrument::eSettlementType delivery,
											market_data::eTaxCreditPercentageType 	tcpTaxCredit,
											double 						*spot,
											const market_data::CSRMarketData 		&context) const OVERRIDE;
		};

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelEquity_H_