/*
 	File:		SphDefaultMetaModelForexFuture.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelForexFuture_H_
#define _SphDefaultMetaModelForexFuture_H_

#include "SphInc/instrument/SphForexFuture.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRForexFuture.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelForexFuture : public virtual CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelForexFuture)
			
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetVegaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, 
													const market_data::CSRMarketData &context) const;

			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which1, int which2) const;
			virtual double	GetVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int whichUnderlying) const;
			virtual double	GetCrossedVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int which1, int which2) const;
			virtual double	GetEpsilon(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, int which) const;

			virtual double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelForexFuture_H_