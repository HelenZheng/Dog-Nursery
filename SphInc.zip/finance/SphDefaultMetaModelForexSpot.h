/*
 	File:		SphDefaultMetaModelForexSpot.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelForexSpot_H_
#define _SphDefaultMetaModelForexSpot_H_

#include "SphInc/instrument/SphForexSpot.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRForexSpot.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelForexSpot : public virtual CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelForexSpot)
				
		public:
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void			GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void			GetVegaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRForexFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetForwardRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData & context) const;
			virtual double GetFirstDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int whichUnderlying) const;
			virtual double GetTheta(const instrument::CSRInstrument& instr, const market_data::CSRMarketData & context) const;

			/** Get the forward price.
			It uses the preference {@link ForexWithFinancing} to calculate settlement at the beginning and at the end. 
			@version 5.0.3 The forward price is the forward fixing as in 4.6 instead of the forward rate 
			@see GetForwardRate
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual	void	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long										*futureDates,
											double 										*values,
											short										nbOfDates,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			double	GetForwardPriceWithAdjustedDates(const instrument::CSRInstrument&			instr,
													long 										futureDate,
													market_data::eTaxCreditPercentageType		forEvaluation,
													const market_data::CSRMarketData 			&context,
													bool										adjustFutureDates,
													const instrument::CSRInstrument*			initialForward = NULL) const;

			virtual	void			GetLinearValue(	const instrument::CSRInstrument& instr,
													double					 computationDate,
													long 					 futureDate,
													instrument::eSettlementType 		 settlementType,
													market_data::eTaxCreditPercentageType forEvaluation,
													double 					 *a,
													double 					 *b,
													double 					 *rate,
													const market_data::CSRMarketData		 &context) const OVERRIDE;
			virtual	void			GetValue(	const instrument::CSRInstrument& instr,
												double 					 computationDate,
												long 					 futureDate,
												double 					 futureValue, 
												instrument::eSettlementType 		 settlementType,
												market_data::eTaxCreditPercentageType forEvaluation,
												double 					 *spot,
												const market_data::CSRMarketData 	 &context) const;

			virtual double GetSecondDerivative(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param,int lequel1, int lequel2) const OVERRIDE;
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelForexSpot_H_