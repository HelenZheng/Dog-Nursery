/*
 	File:		SphDefaultMetaModelFuture.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelFuture_H_
#define _SphDefaultMetaModelFuture_H_

#include "SphInc/instrument/SphFuture.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRFuture.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelFuture : public virtual CSRMetaModel
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelFuture)

		public:
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			virtual void GetForwardRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetVegaRiskSources(const instrument::CSRInstrument& instr, sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetInflationRiskSources(const instrument::CSRInstrument& instr, sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetParentDeltaRiskSources);
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			UNMASK_FUNCTION(CSRMetaModel, GetParentVegaRiskSources);
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			UNMASK_FUNCTION(CSRMetaModel, GetParentRhoRiskSources);
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const OVERRIDE;

			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;

			virtual double	GetVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int whichUnderlying) const OVERRIDE;

			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results)  const OVERRIDE;
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;

			virtual double	GetCrossedVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int which1, int which2) const OVERRIDE;			

			virtual double GetDuration(const instrument::CSRInstrument& instr,
						   const sophis::market_data::CSRMarketData &context,
						   const sophis::CSRComputationResults* results = 0) const OVERRIDE;
		};

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelFuture_H_
