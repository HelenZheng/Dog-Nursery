/*
 	File:		SphDefaultMetaModelNotionalFuture.h

 	Contains:	Class for the handling default instrument metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelNotionalFuture_H_
#define _SphDefaultMetaModelNotionalFuture_H_

#include "SphInc/finance/SphDefaultMetaModelFuture.h"
#include "SphInc/instrument/SphFuture.h"
#include "SphInc/finance/SphMetaModel.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		class SOPHIS_FINANCE CSRDefaultMetaModelNotionalFuture : public virtual CSRDefaultMetaModelFuture
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelNotionalFuture)

			/**
			@param context is the market data.
			@return the duration of the cheapest to deliver.
			@since 5.2.3
			*/
			virtual double	GetDuration(const instrument::CSRInstrument & instr,
						    const sophis::market_data::CSRMarketData &context,
						    const sophis::CSRComputationResults* results = 0) const OVERRIDE;


			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double			GetModDuration(	const instrument::CSRInstrument & instr,
													const market_data::CSRMarketData&context,
													double							ytm	= NOTDEFINED) const OVERRIDE;

			/** This is the evaluation method.
			@param context is the market data.
			@return the adjusted forward price of the cheapest to deliver expressed in percentage of the notional
			@see GetConcordanceFactor
			@since 5.2.3
			*/
			virtual double GetTheoreticalValue(const instrument::CSRInstrument & instr, const sophis::market_data::CSRMarketData& context) const OVERRIDE;

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelNotionalFuture_H_
