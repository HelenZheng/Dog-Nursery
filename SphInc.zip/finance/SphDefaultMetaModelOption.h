/*
File:		SphDefaultMetaModelOption.h

Contains:	Class for the handling default instrument metamodel

Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelOption_H_
#define _SphDefaultMetaModelOption_H_

#include "SphInc/instrument/SphOption.h"
#include "SphInc/finance/SphMetaModel.h"


SPH_PROLOG
namespace sophis {
	namespace finance {

		/**	
		Class to factorize the old code in CSROption.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelOption : public virtual CSRMetaModel
		{
		public:
			virtual  CSRMetaModel * Clone() const ;

			CSRDefaultMetaModelOption();

			virtual ~CSRDefaultMetaModelOption();

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double			GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, instrument::CSRCoxTreeGraphics *graph) const  OVERRIDE;
			/** By default this method calls the previous one with grah = NULL */
			virtual double			GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const  OVERRIDE;

			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			UNMASK_FUNCTION(CSRMetaModel, GetParentDeltaRiskSources);
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			virtual double			GetTheta(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			//virtual double			GetOptionalTheta(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			//virtual double			GetCreditRiskSensitivity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			//virtual double			GetCreditRiskConvexity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			//virtual double			GetRecoveryRateSensitivity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			//virtual double 			GetCreditRiskDelta(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &x) const;
			//virtual double 			GetCreditRiskGamma(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &x, const instrument::SSCreditRiskSource &y) const;

			virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;

			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double	GetModDuration(	const instrument::CSRInstrument& instr,
											const market_data::CSRMarketData	&context,
											double								ytm = NOTDEFINED) const OVERRIDE;

			virtual void	GetDeltaGammaInPricingWindow(	const instrument::CSRInstrument& instr, 
 															const market_data::CSRMarketData& context,
															const sophis::CSRComputationResults& results,
 															double				price,
 															double				delta,
 															double				gamma,
 															int					which,
 															double				&deltaOut,
 															double				&gammaOut) const OVERRIDE;
			virtual double			GetSecondDerivative(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which1, int which2) const  OVERRIDE;
			virtual double			GetDuration(const instrument::CSRInstrument& instr,
								    const market_data::CSRMarketData& context,
								    const sophis::CSRComputationResults* results = 0) const OVERRIDE;
	


			virtual double			ComputeValueSecondLeg(const instrument::CSRInstrument& instr, const market_data::CSRMarketData & context) const OVERRIDE;

			/** Get the cash flow diagram used to compute duration and modified duration.
			By default returns new_CashFlowDiagram(context)
			It is overloaded for example in CSROption to include only the bond part
			@param context is a market data
			@return a new cash flow diagram.
			@since 6.0
			@see CSRCashFlowDiagram
			*/
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagramForDuration(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;

			virtual double			GetEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which) const OVERRIDE;
			virtual	double			GetVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which) const OVERRIDE;
			virtual double			GetCrossedVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which1, int which2) const OVERRIDE;
			
			
			virtual double			GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const; // unmask
			
			virtual	double			GetEquityGlobalVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual	double			GetGlobalEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual	void			GetRhoConvexity(const instrument::CSRInstrument& instr,  
													const market_data::CSRMarketData& context, 
													double				price, 
													double				*rho, 
													double				*convexity, 
													int										which,
													instrument::eRhoBumpType				rhoBumpType) const OVERRIDE;
			virtual	double			GetRho(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double			GetConvexity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;

			/** Get the forward price.
			@param futureDate
			is the expiry of the forward, in number of days from 1/1/1904.
			@param forEvaluation
			is the tax credit percentage type to take into account.
			@param context
			is the market data.
			@since 5.3.6
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument&			instr,
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData 			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			/** Get the forward prices.
			@param futureDate is an array of expiries of the forward, in number of days from 1/1/1904.
			@param val is an output array for the values, which must be effectively allocated.
			@param dateCount is the number of dates in the array.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			This method is used in model option with Basket swaps (TRS) having CBs
			@since 5.3.6
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument&			instrument, 
											long*										futureDates,
											double*										val,
											short										dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

			virtual sophis::market_data::CSRCreditRisk*	new_CreditRisk(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;

			//virtual	double			GetImpliedVolatility(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, double premium) const;

			void ComputeDeltaGamma(	const instrument::CSROption& option, 
									const market_data::CSRMarketData&context,
									double							theo,
									double							delta,
									double							gamma,
									sophis::CSRComputationResults& outResults) const;
		protected:
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results) const OVERRIDE;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelOption_H_
