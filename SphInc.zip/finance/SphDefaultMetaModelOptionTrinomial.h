/*
File:		SphDefaultMetaModelOption.h

Contains:	Class for the handling default instrument metamodel

Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelOptionTrinomial_H_
#define _SphDefaultMetaModelOptionTrinomial_H_

#include "SphInc/instrument/SphOption.h"
#include "SphInc/finance/SphMetaModel.h"
#include "SphInc/finance/SphDefaultMetaModelOption.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		class CSROptionTrinomial;
		class CSRTrinomial;

		/**	
		Class to factorize the old code in CSROption.
		*/
		class SOPHIS_FINANCE  CSRDefaultMetaModelOptionTrinomial : public virtual CSRDefaultMetaModelOption
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelOptionTrinomial)
			virtual ~CSRDefaultMetaModelOptionTrinomial();

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double			GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, instrument::CSRCoxTreeGraphics *graph) const OVERRIDE;
			/** By default this method calls the previous one with grah = NULL */
			virtual double			GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual void			GetPriceDeltaGamma(	const instrument::CSRInstrument& instr,  
														const market_data::CSRMarketData& context, 
														double				*price, 
														double				*delta, 
														double				*gamma, 
														int 				whichUnderlying) const OVERRIDE;
			virtual	double			GetVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which) const OVERRIDE;
			virtual	void			GetRhoConvexity(const instrument::CSRInstrument& instr,  
													const market_data::CSRMarketData& context, 
													double				price, 
													double				*rho, 
													double				*convexity, 
													int									which,
													instrument::eRhoBumpType			rhoBumpType) const OVERRIDE;
			virtual	double			GetRho(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double			GetConvexity(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void			ComputeCreditRiskSensitivities(	const instrument::CSRInstrument		&instr,
																	const market_data::CSRMarketData	&context, 
																	const sophis::CSRComputationResults	&results,
																	double								refPrice,
																	double								&sensitivity,
																	double								&convexity,
																	bool								computeCrossedGammas,
																	bool								computeAllCreditDeltaGamma = true) const OVERRIDE;
			virtual void	ComputeCreditRiskSensitivities(	const instrument::CSROption			&instr, 
															const market_data::CSRMarketData	&context, 
															const sophis::CSRComputationResults	&results,
															finance::CSRTrinomial				*tree, 
															double								basicPrice, 
															NSREnums::eVolatilityType			vol_type,	
															double								&sensitivity, 
															double								&convexity, 
															bool								computeCrossedGammas,
															bool								computeAllCreditDeltaGamma = true) const;
			/** GetNewTrinomial() simply calls new CSRTrinomial(this, param, vol_type, ...). Overwrite this method if you use a child class of CSRTrinomial. */
			virtual CSRTrinomial * GetNewTrinomial(	const instrument::CSROption& option, 
													const market_data::CSRMarketData& param,
													NSREnums::eVolatilityType vol_type =NSREnums::vResult,
													int number_starting_points = 0) const;
			virtual double GetImpliedVolatility(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData & param, const sophis::CSRComputationResults& results, double premium, double accuracy = NOTDEFINED) const OVERRIDE;
			virtual double GetImpliedCreditSpread(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& context, double premium, double accuracy) const OVERRIDE;
			// specific
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
			virtual CSRTrinomial* GetPriceDeltaGammaBis(const instrument::CSROption* opt, const market_data::CSRMarketData & param, double *prix, double *delta, double *gamma) const;
			virtual double	GetRhoFromTree(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			virtual double	GetConvexityFromTree(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			virtual void	GetRhoConvexityFromTree(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, double price, double* rho, double* convexity, instrument::eRhoBumpType rhoBumpType) const;
			virtual double	GetVegaFromTree(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, bool recomputeLocalVol) const;
			CSRTrinomial* GetPriceDeltaGammaBisSmooth(const instrument::CSROption* opt, bool& isValidPricing, const market_data::CSRMarketData & param, double *prix, double *delta, double *gamma) const;
			CSRTrinomial* GetPriceDeltaGammaBisBasic(const instrument::CSROption* opt, const market_data::CSRMarketData & param, double *prix, double *delta, double *gamma) const;
			bool	GetRhoFromTreeSmooth(const instrument::CSROption* opt, double& rho, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetConvexityFromTreeSmooth(const instrument::CSROption* opt, double& convexity, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetRhoConvexityFromTreeSmooth(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, double price, double* rho, double* convexity, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetRhoFromTreeBasic(const instrument::CSROption* opt, double& rho, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetConvexityFromTreeBasic(const instrument::CSROption* opt, double& convexity, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetRhoConvexityFromTreeBasic(const instrument::CSROption* opt, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, double price, double* rho, double* convexity, instrument::eRhoBumpType rhoBumpType) const;
			bool	GetVegaFromTreeSmooth(const instrument::CSROption* opt, double& vega, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, bool recomputeLocalVol) const;
			bool	GetVegaFromTreeBasic(const instrument::CSROption* opt, double& vega, CSRTrinomial* trinomial, const market_data::CSRMarketData& context, int which, bool recomputeLocalVol) const;
		};


		class SOPHIS_FINANCE  CSRDefaultMetaModelOptionTrinomialForwardStart : public virtual CSRDefaultMetaModelOptionTrinomial
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelOptionTrinomialForwardStart)
		public:

			virtual CSRTrinomial * GetNewTrinomial(	const instrument::CSROption& option, 
													const market_data::CSRMarketData& param,
													NSREnums::eVolatilityType vol_type =NSREnums::vResult,
													int number_starting_points = 0) const;

		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelOptionTrinomial_H_