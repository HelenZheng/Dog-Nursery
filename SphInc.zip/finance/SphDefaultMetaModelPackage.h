/*
File:		SphDefaultMetaModelBond.h

Contains:	Class for the handling default Bond metamodel

Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelPackage_H_
#define _SphDefaultMetaModelPackage_H_

#include "SphInc/finance/SphMetaModel.h"
#include <vector>

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRPackage.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelPackage : public virtual CSRMetaModel 	
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelPackage);
			virtual ~CSRDefaultMetaModelPackage();

			UNMASK_FUNCTION(CSRMetaModel, GetTheoreticalValue);
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double GetForwardPrice(	const instrument::CSRInstrument& instr,  
											long dateFutur, 
											market_data::eTaxCreditPercentageType	pourEvaluer, 
											const market_data::CSRMarketData& param, 
											const instrument::CSRInstrument*	initialForward) const OVERRIDE;
			virtual double			GetFirstDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int which) const OVERRIDE;
			virtual double			GetEpsilon(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int which) const OVERRIDE;
			virtual	double			GetGlobalEpsilon(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual void			GetPriceDeltaGamma(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, double *price, double *delta, double *gamma, int which) const OVERRIDE;
			virtual double			GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int which1, int which2) const OVERRIDE;
			virtual double			GetRho(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double			GetVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context,int which) const OVERRIDE;
			virtual double			GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual	double			GetEquityGlobalVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double			GetCrossedVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context,int which1, int which2) const OVERRIDE;
			virtual double			GetTheta(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double			GetConvexity(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void			GetRhoConvexity(const instrument::CSRInstrument & instr, 
													const market_data::CSRMarketData& context,
													double				price,
													double				*rho,
													double				*convexity,
													int									which,
													instrument::eRhoBumpType			rhoBumpType) const OVERRIDE;
			virtual double			GetCrossedDeltaRho(const instrument::CSRInstrument & instr, const market_data::CSRMarketData& context, int whichUnderlying, int whichCurrency, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetInflationRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			//virtual void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			UNMASK_FUNCTION(CSRMetaModel, GetParentRhoRiskSources);
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double			GetModDuration(		const instrument::CSRInstrument & instrument,
														const market_data::CSRMarketData&	context,
														double								ytm	= NOTDEFINED) const OVERRIDE;

			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@param price is the package price. If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			double	GetModDuration(		const instrument::CSRInstrument & instrument,
										const market_data::CSRMarketData&	context,
										double								ytm,
										double								price) const;
			
			virtual void ComputeAllCore(instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;

			sophis::CSRComputationResults * GetLocalComputationResultsForAComponent (int indexOfComponent) const;
#ifndef GCC_XML
			void SetComponentsComputationResults(_STL::vector<CSRComputationResults> * computationsResults) const;
#endif

		private:
			static const char * __CLASS__;
		protected:
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagramForDuration(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			// Parameter to force the components computation during the package computation (true by default)
			bool fForceToComputeComponents;
#ifndef GCC_XML
				mutable _STL::vector <sophis::CSRComputationResults> * fLocalComputationResults; 
#endif
			
		public:
			virtual void PreviousResultsCleanup(sophis::CSRComputationResults& previousResults) const;
		};

		class SOPHIS_FIT CSRDefaultMetaModelBondBasket : public virtual CSRDefaultMetaModelPackage 	
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelBondBasket);
			virtual ~CSRDefaultMetaModelBondBasket();

			/** Get the forward price. Used for instance in the pricing of Total Return Swaps
			@param futureDate is the expiry of the forward, in number of days from 1/1/1904.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			This method is used in model option where NMU is used to give the drift
			of the underlying. It may not be the forward of the spot but of another underlying.
			The real value of the spot will be calculated by GetValue.
			By default, if there is an arbitrage with underlying model, check with the arbitrage, otherwise
			return the cash value.
			@see GetValue
			@see GetLinearValue
			@since 5.3
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument&			instrument, 
											long*										futureDates,
											double*										val,
											short										dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;


			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

		};

		class SOPHIS_FIT CSRDefaultMetaModelLoanFacility : public virtual CSRDefaultMetaModelPackage 	
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelLoanFacility);
			virtual ~CSRDefaultMetaModelLoanFacility();

			/** Get the forward price.
			@param futureDate is the expiry of the forward, in number of days from 1/1/1904.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			This method is used in model option where NMU is used to give the drift
			of the underlying. It may not be the forward of the spot but of another underlying.
			The real value of the spot will be calculated by GetValue.
			By default, if there is an arbitrage with underlying model, check with the arbitrage, otherwise
			return the cash value.
			@version 6.0
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument&			instrument, 
											long*										futureDates,
											double*										val,
											short										dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;


			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const OVERRIDE;

		};

	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelBond_H_