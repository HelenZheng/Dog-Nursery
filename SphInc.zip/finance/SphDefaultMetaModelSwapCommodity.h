/*
 	File:		SphDefaultMetaModelSwapCommodity.h

 	Contains:	Class for the handling default Swap metamodel

 	Copyright:	2011 Sophis.

*/
#pragma once

#ifndef _SphDefaultMetaModelSwapCommodity_H_
#define _SphDefaultMetaModelSwapCommodity_H_

#include "SphInc/instrument/SphSwap.h"
#include "SphInc/finance/SphDefaultMetaModelSwap.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		// CSRMetamodel handle the case
		/**
		Class to factorize the old code in CSRSwap.
		*/
		class SOPHIS_FIT CSRDefaultMetaModelSwapCommodity : public virtual CSRDefaultMetaModelSwap
		{
			DECLARATION_META_MODEL(CSRDefaultMetaModelSwapCommodity)

			virtual double	GetFirstDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int whichUnderlying) const;

			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which1, int which2) const;
			
			virtual double	GetTheta(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context) const;

			virtual double	GetCrossedVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int which1, int which2) const;

			virtual double	GetVega(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context,int whichUnderlying) const;


			virtual void	GetPriceDeltaGamma(	const instrument::CSRInstrument & instr,
												const market_data::CSRMarketData& context,
												double				*price,
												double				*delta,
												double				*gamma,
												int 				whichUnderlying) const;

			virtual void	GetDeltaGamma(	const instrument::CSRInstrument & instr,
											const market_data::CSRMarketData& context, 
											const sophis::CSRComputationResults& results,
											double				*delta, 
											double				*gamma, 
											int 				whichUnderlying) const OVERRIDE;

			virtual double	GetCrossedDeltaRho(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int whichUnderlying, int whichCurrency, instrument::eRhoBumpType rhoBumpType) const;

		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;

			mutable bool	fOptimiseDeltaGamma;
			mutable bool	fOptimiseVega;
		};


	}//end of finance
}//end of sophis
SPH_EPILOG

#endif //_SphDefaultMetaModelSwap_H_