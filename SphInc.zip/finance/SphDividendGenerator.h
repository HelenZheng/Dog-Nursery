#pragma once

#ifndef _SPH_DIVIDEND_GENERATOR_H
#define _SPH_DIVIDEND_GENERATOR_H

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(list)
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/gui/SphNewDialog.h"
#include "SphInc/market_data/SphMarketDataEnums.h"

SPH_PROLOG

struct SOPHIS_FIT BDivid
{
	long	code;
	long	date;
	double	value;
	short	exeSoc;
	sophis::market_data::eDividendValueType	type;
	long	payment_date;
	char	infos[40];
	sophis::market_data::eDividendNatureType avoir_fiscal;
	long	declaredDate;	// may be one or 2 see eDividendStatus
	long	currency;
	long	exdivDate;
	long	ident;
	char	taxCountry[80];

	BDivid(): 
		code(0), 
		date(0), 
		value(0), 
		exeSoc(0), 
		type(sophis::market_data::dvPercentage), 
		payment_date(0), 
		avoir_fiscal(sophis::market_data::dnDividend), 
		declaredDate(0), 
		currency(0), 
		exdivDate(0), 
		ident(0)
	{
		*infos=0;
		*taxCountry=0;
	}

	BDivid& operator = (const BDivid& div)
	{
		code = div.code;
		date = div.date;
		value = div.value;
		exeSoc = exeSoc;
		type = div.type;
		payment_date = div.payment_date;
		memcpy( infos, div.infos, sizeof(div.infos) );
		memcpy( taxCountry, div.taxCountry, sizeof(div.taxCountry) );
		avoir_fiscal = div.avoir_fiscal;
		declaredDate = div.declaredDate;	
		currency = div.currency;
		exdivDate = div.exdivDate;
		ident = div.ident;
		return *this;
	}
};

struct SOPHIS_FIT BDividendProperty
{
	char fName[41];
	long fDividend;
	char fValue[81];
};


#define DECLARATION_DIVIDEND_MODEL(derivedClass)								\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRDividendGenerator)	\
	public: derivedClass();

#define CONSTRUCTOR_DIVIDEND_MODEL(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_DIVIDEND_MODEL(derivedClass)
#define	INITIALISE_DIVIDEND_MODEL(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)

struct infos_user;

namespace sophis
{
	namespace market_data
	{
		class CSRMarketData;
	}
	namespace instrument
	{
		class CSRInstrument;
	}
}



namespace sophis {
	namespace finance {

		class SOPHIS_FIT CSRDividendGenerator : public sophis::gui::ISRNewDialog
		{
		public:
			CSRDividendGenerator();
			CSRDividendGenerator(const CSRDividendGenerator &model);
			CSRDividendGenerator & operator =(const CSRDividendGenerator &model);
			virtual ~CSRDividendGenerator();
			virtual CSRDividendGenerator * Clone() const = 0;

			static CSRDividendGenerator& GetDefaultGenerator();
			static CSRDividendGenerator * CreateInstance(const char* model_name, long id);

			virtual void FillDividendArray(	BDivid*										div,
											int											n,
											_STL::list<BDivid>&							divid,
											long										instrumentCode,
											const sophis::market_data::CSRMarketData &	marketData,
											long										endDate) const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRDividendGenerator, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_META_MODEL.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			void OpenDialogInReadMode(const sophis::instrument::CSRInstrument * instrument) const;
			bool OpenDialogInWriteMode();

			virtual void Save(long id);
			static bool SaveDividendModelData(CSRDividendGenerator *metaModel, long &usedID);
			static void SetVersion(int version);
			static int GetVersion();

			void			SetInfosUser( infos_user * infosUser , bool todelete = false) const;
			infos_user *	GetInfosUser() const;

			bool GetDataToDelete() const;
			
			int GetID() const;

			static const char * gNoModelName;
		protected:
			virtual void Initialise();
			void Initialize(const CSRDividendGenerator &model);

			bool LoadSpecificElement(int NRE_Element,void *address) const;
			bool LoadSpecificElement(int NRE_List, int lineNumber,int NRC_Colomn,void *address) const;
			int	GetSpecificLineCount(int NRE_Liste) const;

			bool	SaveSpecificElement(	int 	ERId_Element,
											void	*address) const;
			bool	SaveSpecificElement(	int 	ERId_List,
											int 	lineNumber,
											int 	CNb_Column,
											void	*address) const;
			bool	SaveSpecificLineCount(	int   ERId_List, int newLineCount);


		private:
			static int fVersion;
			int fId;
			mutable infos_user* fInfosUser;
			mutable bool fDataToDelete;
		};

	} //finance
} //sophis


SPH_EPILOG

#endif



 
