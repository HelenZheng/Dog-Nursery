/*
File:		SphExoticSpread.h

Contains:	Classes for exotic spread data of interest rate legs (fixed, floating).

Copyright:	� 1995-2005 Sophis.

*/

/*! \file SphExoticSpread.h
\brief Classes for exotic spread data of interest rate legs (fixed, floating).
*/

#pragma once


#ifndef _SphExoticSpread_H__
#define _SphExoticSpread_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/static_data/SphHistoricalData.h"
#include "SphInc/instrument/SphSwapEnums.h"

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4275) // Can not export a class derivated from a non exported one
#	pragma warning(disable:4251) // Can not export a class agregating a non exported one
#endif

#include __STL_INCLUDE_PATH(vector)

namespace sophis	{
	namespace instrument	
	{
		struct SSFlow;
		class CSRLeg;
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

namespace sophis	{
	namespace finance	{

		class SOPHIS_FIT CSRExoticSpread {
		public:
			CSRExoticSpread();
			virtual ~CSRExoticSpread();
			CSRExoticSpread(const CSRExoticSpread& source);

			/**
			*	"virtual copy constructor"
			*	@return : a copy of the object
			*/
			virtual CSRExoticSpread*	Clone() const;

			bool GetDigital() const;
			void SetDigital(bool digital);
			
			long GetShortRate() const;
			void SetShortRate(long rate);

			long GetRangeAccrualShortRate() const;
			void SetRangeAccrualShortRate(long rate);

			double GetPercent() const;
			void SetPercent(double percent);

			// this rate reflects the field taux_var of the struct jambe in the file "swap.h" 
			/*
			long GetMainRate() const;
			void SetMainRate(long rate); 
			*/

			// this rate reflects the field fRateIndex in the file "SphRangeAccruals.h" 
			/*
			long GetRangeAccrualMainRate() const;
			void SetRangeAccrualMainRate(long rate);
			*/
			
			// this spread reflects the field ref1.marge of the struct jambe in the file "swap.h" 
			/*
			double GetSpread() const;
			void SetSpread(double spread);
			*/
			
			// this minimum reflects the field fMinimum of the struct jambe in the file "swap.h" 
			/*
			double GetMinimum() const;
			void SetMinimum(double minimum);
			*/

			// this maximum reflects the field fMaximum of the struct jambe in the file "swap.h" 
			/*
			double GetMaximum() const;
			void SetMaximum(double maximum);
			*/

			/**
			*	This method returns the RateFormula that will be used for calculation
			*/
			virtual _STL::string ComputeCouponRateFormula
									(	sophis::instrument::eLegFlowType	legType,
										double								fixedRate,
										long								mainRate,
										long								rangeAccrualMainRate,
										long								dualRangeAccrualRate,
										double								spread, 
										double								minimum,
										double								maximum) const;


			/***********
			*   SQL   *
			***********/

			/**
			*	Save the exotic spead data into the database
			*	@param sico : sicovam of the instrument which contains this exotic spread leg
			*	@param leg : index of the leg in the swap (0 or 1)
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico, int leg);

			/**
			*	Load the exotic spead data from the database
			*	@param sico : sicovam of the instrument which contains this exotic spead leg
			*	@param leg : index of the leg in the swap (0 or 1)
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico, int leg);


			/***********
			*   XML  *
			***********/

			/** Common method to describe exotic spread information for legs.
			* 
			* \param dataSet the destination DataSet.
			* \param field_name XML tag
			* \param comment optional comment for the grammar
			*/
			void DescribeExoticSpread(	sophis::tools::dataModel::DataSet&		data_set, 
										const char*								field_name,
										const char*								comment);

			/** Common method to fill exotic spread information from a dataset.
			* 
			* \param dataSet the source DataSet.
			* \param field_name XML tag
			*/
			void UpdateExoticSpread(const sophis::tools::dataModel::DataSet& dataSet, 
									const char*								 field_name);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the exotic spread(of the 2 legs).
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the swap
			*	@param newSico : sico of the archived swap
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRExoticSpread *es );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRExoticSpread *&es );

			/***************
			*   Friends   *
			***************/
			friend tools::CSRArchive & WriteToArchive(tools::CSRArchive & far, const CSRExoticSpread *fes );
			friend const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &far , CSRExoticSpread *&fes );

		private:
			/********************* 
			* Exotic Spread Data *
			**********************/
			bool					fDigital;
			long					fShortRate;
			long					fRangeAccrualShortRate;
			double 					fPercent;
		};
	}
}

// For archives
extern SOPHIS_FIT sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRExoticSpread * exoticSpread);
extern SOPHIS_FIT const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRExoticSpread *& exoticSpread);

#endif //!_SphExoticSpread_H__
