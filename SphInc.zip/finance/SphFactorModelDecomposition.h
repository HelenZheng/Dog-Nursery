/*
 	File:		SphFactorModelDecomposition.h
 
 	Contains:	Class for the handling of a Facor MOdel
 
 	Copyright:	� 2012 Sophis.
*/

/*! \file SphFactorModelDecomposition.h
	\brief For the handling of a meta model.
*/

#pragma once


#ifndef _SPH_FACTOR_MODEL_DECOMPOSITION_
#define _SPH_FACTOR_MODEL_DECOMPOSITION_

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
//#include __STL_TR1_INCLUDE_PATH(memory)

#include "SphMetaModel.h"


#if (!defined(WIN32)&&!defined(_WIN64))
#include "SphInc/instrument/SphOption.h"
#endif

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning (push)
#	pragma warning(disable:4275)
#endif

namespace sophis {
	namespace instrument {
		
		class CSRInstrument;
		class CSROption;
		class CSRCoxTreeGraphics;
		enum eGreekParameterType;
		enum eUnderlyingComputationType;
		struct SSParametersOfDerivation;
		
		//struct SSCaplet; //BR-30.11.2006 CLR
		class  CSRGreekValues;
	}

	namespace market_data	{
		class CSRMarketData;
	}
	namespace finance
	{
		class SOPHIS_FIT CSRFactorModelDecomposition : public virtual  CSRMetaModel
		{
		protected:
			const CSRMetaModel * fBaseModel;
		public:
			CSRFactorModelDecomposition();
			CSRFactorModelDecomposition(const CSRFactorModelDecomposition& c );
			
			static const char* __CLASS__ ;
			

			virtual CSRMetaModel* Clone() const ;

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual void	ComputeAllCore(instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
			virtual bool InitialiseMetaModel(const instrument::CSRInstrument	&instrument,
									const market_data::CSRMarketData	&marketData,
									bool computeGreeks, bool forceLoading = false) const OVERRIDE;
			
			_STL::string GetModelName()const {return pModelName;}
			_STL::string GetProviderName()const {return pPorviderName;}
			_STL::string GetProviderType()const {return pProviderType;}
			void SetModelName(_STL::string modelname){pModelName=modelname;}
			void SetProviderName(_STL::string providername){pPorviderName=providername;}
			void SetProviderType(_STL::string providertype){pProviderType=providertype;}
			void SetId(long id)
			{
				fId = id;
			}
			struct SOPHIS_FIT FactorModelKey
			{
				_STL::string ProviderName;
				_STL::string ProviderType;
				_STL::string ModelName;
				bool operator < (const  FactorModelKey& right) const;
			};
			void SetBaseMetaModel(const CSRMetaModel* model)
			{
				fBaseModel = model;
			}

			static long RegisterMetaModel(FactorModelKey k);
		private:
			_STL::string pPorviderName;
			_STL::string pModelName;
			_STL::string pProviderType;
			static _STL::map<FactorModelKey,long> pKeyByMetaModel;
			static _STL::map<long,FactorModelKey> pMetaModelbyKey;

		};
		
	}
}


#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(pop) // used #pragma pack to change alignment
#endif


#endif
