/*
File:		SphFastPnlClient.h

Contains:	Class for handling the Fast Pnl calculation 

Copyright:	1995-2005 Sophis.

*/

/*! \file SphFastPnlClient.h
\brief Class for handling the Fast Pnl calculation.
*/

#ifndef __SphFastPnlClient_H__
#define __SphFastPnlClient_H__
#ifdef GCC_XML
#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif
#else
#include "SphTools/SphCommon.h"
#endif

#include "SphTools/SphArchive.h"
#include "Sphinc/finance/SphFastPnlEnums.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(memory)

#if (defined(WIN32)||defined(_WIN64))
#	ifdef SOPHIS_FASTPNL_EXPORTS
#		define SOPHIS_FASTPNL __declspec(dllexport)
#	else
#		define SOPHIS_FASTPNL __declspec(dllimport)
#	endif
#else
#	define SOPHIS_FASTPNL
#endif

SPH_PROLOG

namespace sophis
{
	namespace FastPnl
	{
		static const char FRA_unit = 'x';
		const char UNIT[8] = "dmyMQYw";

		enum {
			uJour,
			uMois,
			uAnnee,
			uFinMois,
			uFinTrim,
			uFinAnnee,
			uWeek
		};

		enum eFPMaturityType
		{
			tDateFixe,			//	12/05/96
			tDureeJ,			//	30 j + 1(j)
			tDureeM,			//	2 m	- 5(j)
			tDureeA,			//	5 a - 3(j)
			tRelatifFinMois,	//	2M - 1 (j)		fin du 2 eMonthType suivant (au 5/09/96 correspond le 30/10/96 - 1)
			tRelatifFinTrim,	//	1T - 2(j)		fin du first trimeste	(31/03/xx) moins 2 jours
			tRelatifFinAnnee,	//	1A				fin de l'ann�e courante
			tCodeOblig,			//					code sico d'une obligation
			tNullValue,
			tFixedMonth,
			tFRA,				//	1x3				FRA starting in 1 month ending in 3 months
			tBrazilianFuture,
			tDureeBD,
			tIMM,
			tDureeW				//	7 j 
		};

		class SOPHIS_FASTPNL FPGridMaturity
		{
		public:
			FPGridMaturity();
			FPGridMaturity(long maturity, eFPMaturityType type);
			FPGridMaturity(const _STL::vector<double>& maturities, eFPMaturityType type);
			FPGridMaturity(const FPGridMaturity& mat);
			~FPGridMaturity();
			virtual void GetString(_STL::string& out);
			virtual bool operator==(const FPGridMaturity& other) const;
			virtual bool operator<(const FPGridMaturity& other) const;
			virtual void Serialize(sophis::tools::CSRArchive& out) const;
			virtual void DeSerialize(const sophis::tools::CSRArchive& in);
#ifndef GCC_XML
			virtual void Serialize(void* out) const;
			virtual void DeSerialize(const void* in);
#endif
			virtual long GetValue() const;
			eFPMaturityType GetType() const;
			virtual long GetMaturity() const;
		protected:
			short fMaturity;
			eFPMaturityType fType;

			// in case there are many maturities. For example, the FRA have 2 maturities 3x6 (3 & 6)
			_STL::vector<double> fMaturities; 
		};

		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FASTPNL CSRFastPnlInterpolationGrid
		{
		public:

			CSRFastPnlInterpolationGrid(_STL::vector<double>& strikes, _STL::vector<FPGridMaturity>& maturities, bool strikeInPercent = true);
			CSRFastPnlInterpolationGrid(const CSRFastPnlInterpolationGrid& grid);
			virtual ~CSRFastPnlInterpolationGrid();
			virtual CSRFastPnlInterpolationGrid* Clone() const;			

			virtual unsigned int GetMaturitiesCount() const;
			virtual unsigned int GetStrikesCount() const;

			virtual FPGridMaturity	GetNthMaturity(unsigned int index) const;
			virtual void	GetNthMaturityString(unsigned int index,_STL::string& out) const;
			virtual double	GetNthStrike(unsigned int index) const;
			virtual bool	IsStrikeInPercent() const;
			virtual CSRFastPnlInterpolationGrid* Merge(const CSRFastPnlInterpolationGrid& other) const;
/*			virtual bool operator==(CSRFastPnlInterpolationGrid& other) const;*/
			
		protected:
			CSRFastPnlInterpolationGrid();
			_STL::vector<double> fStrikes;
			_STL::vector<FPGridMaturity> fMaturities;
			bool fStrikesInPercent;
		};
		SPH_END_NOWARN_EXPORT

		/** Base Class to handle Fast Pnl triggers.
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL FastPnLTrigger
		{
		public:
			FastPnLTrigger() {};
			virtual ~FastPnLTrigger() {};
		};

		class CSRFastPnlDataGrid;
		/** Base class to store volatility surfaces
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL FPVolatility
		{		
		public:
			FPVolatility() {};
			virtual ~FPVolatility() {};

			/** Get the volatility.
			@param startDate is a date (in double) for the start of the option.
			@param endDate is a date (in double) for the expiry of the option.
			@param strike is the strike of the option put in the unit and currency of the underlying.
			@param isPut is a boolean to use the put or call volatility.
			@param volatType is the volatility curve to use.
			@return the volatility to use.
			@since 5.3.5
			*/
			virtual double GetVolat(double startDate, double endDate, double strike, bool isPut, int volatilityType) const=0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;
			/** Abstract, clone FPVolatility object, useful for = operators
			@return cloned object of the current object
			@since 5.3.5
			*/
			virtual FPVolatility* Clone() const = 0;
		};


		/** Base class to store yield curves
		@since 5.3.6
		*/
		class SOPHIS_FASTPNL FPYieldCurve
		{		
		public:
			virtual ~FPYieldCurve() {};

			virtual double GetForwardCompoundFactor(long currency_family, double date1,double date2) const=0;

			virtual double GetForwardCompoundFactor(FPGridMaturity& maturity) const=0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;

			virtual FPYieldCurve* Clone() const = 0;
		};


		/** Base class to store vegas
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL FPVega
		{
		public:
			FPVega() {};
			virtual ~FPVega() {};

			/** Gives the theo. price shift when volatility changes
			@param baseVolatility is the volatility stored in the Fast PnL buffer.
			@param vol is the current volatility.
			@return the volatity to use.
			@since 5.3.5
			*/
			virtual double GetShift(const FPVolatility & baseVolatility, const FPVolatility & vol) const = 0;
			
			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;
			
			/** Abstract, clone FPVega object, useful for = operators
			@return cloned object of the current object
			@since 5.3.5
			*/
			virtual FPVega* Clone() const = 0;
		};

		/** Base class to store Rhos
		@since 5.3.6
		*/
		class SOPHIS_FASTPNL FPRho
		{
		public:
			virtual ~FPRho() {};

			/** Gives the theo. price shift when yield curves changes
			@param baseYieldCurve is the yield curve stored in the Fast PnL buffer.
			@param yieldCurve is the current yieldCurve.
			@return the shift to use.
			@since 5.3.6
			*/
			virtual double GetShift(const FPYieldCurve & baseYieldCurve, const FPYieldCurve & yieldCurve) const=0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;

			/** Abstract, clone FPRho object, useful for = operators
			@return cloned object of the current object
			@since 5.3.6
			*/
			virtual FPRho* Clone() const = 0;
		};

		/** Base class to store repos
		@since 5.3.6
		*/
		class SOPHIS_FASTPNL FPRepo
		{		
		public:
			virtual ~FPRepo() {};

			/** Get the repo cost between two dates.
			@param instrumentCode is an instrument id.
			@param date1 is the start date of the repo.
			@param date2 is the end date of the repo.
			@return a repo cost factor 
			@since 5.3.6
			*/
			virtual	double	GetRepoMargin(long instrumentCode, double date1, double date2) const = 0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;

			virtual FPRepo* Clone() const = 0;
		};

		/** Base class to store Credit
		@since 5.3.6
		*/
		class SOPHIS_FASTPNL FPCredit
		{		
		public:
			virtual ~FPCredit() {};

			/** Gets the credit.
			@param index the index corresponding to the nth maturity.
			@return the credit 
			@since 6.3
			*/
			//virtual double GetCredit(unsigned int index) const = 0;

			///** Gets the upfront.
			//@param index the index corresponding to the nth maturity of 
			//the credit risk curve.
			//@return the upfront 
			//@since 6.3
			//*/
			//virtual double GetUpfront(unsigned int index) const = 0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;

			virtual FPCredit* Clone() const = 0;
		};

		/** Base class to store Forward effect, sensitivity of the theo to the repo costs
		@since 5.3.6
		*/
		class SOPHIS_FASTPNL FPForwardEffect
		{
		public:
			virtual ~FPForwardEffect() {};

			/** Gives the theo. price shift when repos changes
			@param baseRepo is the repo stored in the Fast PnL buffer.
			@param yieldCurve is the current yieldCurve.
			@return the shift to use.
			@since 5.3.6
			*/
			virtual double GetShift(const FPRepo & baseRepo, const FPRepo & repo) const = 0;

			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;

			/** Abstract, clone FPForwardEffect object, useful for = operators
			@return cloned object of the current object
			@since 5.3.6
			*/
			virtual FPForwardEffect* Clone() const = 0;
		};

		/** Base class to store credit effect, sensitivity of the theo to the credit risk
		@since 6.3
		*/
		class SOPHIS_FASTPNL FPCreditSensitivity
		{
		public:
			virtual ~FPCreditSensitivity() {};

			/** Gives the theo. price shift when credit risks change
			@param baseCredit is the credit risk stored in the Fast PnL buffer.
			@param credit is the current credit risk.
			@return the shift to use.
			@since 6.3
			*/
			virtual double GetShift(const FPCredit& baseCredit, const FPCredit& credit, bool isUpfront = false) const = 0;

			/** Gives the CDS rate regarding the maturity
			@param maturityIndex is an index corresponding to the Nth maturity of the credit risk curve
			@return the CDS rate regarding the maturity
			@since 6.3
			*/
			virtual double GetCDSRate(long maturityIndex) const = 0;

			/** Gives the sensitivity regarding the maturity
			@param maturityIndex is an index corresponding to the Nth maturity of the credit risk curve
			@return the sensitivity regarding the maturity
			@since 6.3
			*/
			virtual double GetSensitivity(long maturityIndex) const = 0;
			
			/** Abstract, clone FPCreditSensitivity object, useful for = operators
			@return cloned object of the current object
			@since 6.3
			*/
			virtual FPCreditSensitivity* Clone() const = 0;
			virtual const CSRFastPnlDataGrid* GetStorage() const = 0;
		};

		/** Base class to store greeks other than Delta/Gamma/Vega
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL  FPToolkitGreek
		{
		public:
			virtual ~FPToolkitGreek() {};

			/** Abstract, clone FPToolkitGreek object, useful for = operators
			@return cloned object of the current object
			@since 5.3.5
			*/
			virtual FPToolkitGreek* Clone() const = 0;
		};

		/** Base class to store market data other than Spot/Vol
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL  FPToolkitMarketData
		{
		public:
			virtual ~FPToolkitMarketData() {};

			/** Abstract, clone FPToolkitMarketData object, useful for = operators
			@return cloned object of the current object
			@since 5.3.5
			*/
			virtual FPToolkitMarketData* Clone() const = 0;
		};

		/** Helper class to get,set prototypes names
		@since 6.1
		*/		
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FASTPNL PrototypesNamesHelperClass
		{
		public:
			void SetCalculatorName(const char* name, eGridAnalysisType type);
			const char* GetCalculatorName(eGridAnalysisType type) const;
		private:
			_STL::string fVegaCalculatorPrototypeName;
			_STL::string fRhoCalculatorPrototypeName;
			_STL::string fFwdCalculatorPrototypeName;
			_STL::string fCreditCalculatorPrototypeName;
		};
		SPH_END_NOWARN_EXPORT

		/** Base class to retrieve market data
		Override this class to give access to your market data provider
		@since 5.3.5
		*/		
		class SOPHIS_FASTPNL  FastPnlMarketData			// abstract class
		{
		protected:
			static		FastPnlMarketData*	fInstance;		
			PrototypesNamesHelperClass fCalculatorPrototypesNames;
		public :
			virtual ~FastPnlMarketData() {}

			/** Returns the current market data -- equivalent to gApplicationContext in APIs
			  */
			static FastPnlMarketData * GetInstance();

			/** Returns the current spot for a given instrument
			@param code is the instrument identifier
			@param outSpot (out) is the output spot
			@return true is the spot was available in from the market data provider.
			@since 5.3.5
			*/
			virtual			bool				GetSpot		(long code, double &outSpot) const	= 0;

			/** Returns the current volatility surface for a given instrument			
			@param code is the instrument identifier
			@return a pointer to the volatility surface object. Caller DOES NOT have to delete this pointer / Default returns NULL
			@since 5.3.5
			*/		
			virtual			const FPVolatility * GetVolat	(long code, const CSRFastPnlInterpolationGrid* grid) const;

			/** Returns the current volatility surface for a given instrument			
			@param code is the instrument identifier
			@return a pointer to the volatility surface object. Caller DOES NOT have to delete this pointer / Default returns NULL
			@since 5.3.5
			*/		
			virtual			const FPYieldCurve * GetYieldCurve	(long code, const CSRFastPnlInterpolationGrid* grid) const;

			/** Returns the current repo for a given instrument			
			@param code is the instrument identifier
			@return a pointer to the repo object. Caller DOES NOT have to delete this pointer / Default returns NULL
			@since 5.3.6
			*/		
			virtual			const FPRepo * GetRepo	(long code, const CSRFastPnlInterpolationGrid* grid) const;

			/** Returns the current credit for a given credit risk			
			@param creditCurve is the code of the curve of credit risk
			@param grid interpolation grid used to retrieve data
			@return a pointer to the credit object. Caller DOES NOT have to delete this pointer / Default returns NULL
			@since 6.3
			*/		
			virtual			const FPCredit* GetCredit (long creditCurve, const CSRFastPnlInterpolationGrid* grid) const;

			/** Returns the current credit for a given credit risk			
			@param code code of the instrument which spread is needed 
			@param outSpread spread value of the instrument given by the code.
			@return true if it succeeded, otherwise false.
			@since 6.3
			*/	
			virtual			bool GetCreditSpread(long code, double &outSpread) const;

			/** Returns the current object that represents a generic market data (user defined).			
			@param code is the instrument identifier
			@return a pointer to the generic market data object. Caller DOES NOT have to delete this pointer / Default returns NULL
			@since 5.3.5
			*/		
			virtual			const FPToolkitMarketData* GetToolkitMarketData(long code) const;

			virtual void SetCalculatorName(const char* name, eGridAnalysisType type);

			virtual const char* GetCalculatorName(eGridAnalysisType type) const;
		};

		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FASTPNL CSRFastPnlDataGrid
		{			
		public:

			virtual ~CSRFastPnlDataGrid();

  			CSRFastPnlDataGrid(long productCode, long underlyingCode, eGridAnalysisType type, const CSRFastPnlInterpolationGrid* grid=NULL);

			CSRFastPnlDataGrid(const CSRFastPnlDataGrid& fpnlRiskMng); 

			virtual const CSRFastPnlInterpolationGrid* GetGrid() const;

			virtual long GetProductCodeToLoad() const;

  			virtual long GetUnderlyingCodeToLoad() const;

			virtual double GetNthElement(unsigned int index) const;

			virtual void SetNthElement(unsigned int index, double val);

			virtual double GetElement(double strike, FPGridMaturity& maturity) const;

			virtual void SetElement(double strike, FPGridMaturity& maturity, double value);
  
			virtual unsigned int GetElementsCount() const;

			virtual void ClearElements();

  			virtual void SetGrid(const CSRFastPnlInterpolationGrid* grid);
  
  			//virtual CSRFastPnlDataGrid& operator-(const CSRFastPnlDataGrid& other) const;
  
  			//virtual CSRFastPnlDataGrid& operator*(const CSRFastPnlDataGrid& other) const;
  
  			virtual double Accumulate() const;
  
		protected:
			CSRFastPnlDataGrid();	
  			CSRFastPnlInterpolationGrid* fInterpolationGrid;
  			//CSRFastPnlInterpolationGridHandle* fGridHandle;
			_STL::vector<double> fData;
  			long fProductSicovam;
  			long fUnderlyingCode;
  			eGridAnalysisType fType;
  		};
		SPH_END_NOWARN_EXPORT
		
		class SOPHIS_FASTPNL CSRFastPnlVolatilityGrid :  public FastPnl::FPVolatility
		{			
		public:

			virtual ~CSRFastPnlVolatilityGrid();

			CSRFastPnlVolatilityGrid(long productCode,long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL);

			CSRFastPnlVolatilityGrid(const CSRFastPnlVolatilityGrid& vol);

			virtual CSRFastPnlVolatilityGrid* Clone() const;				

			virtual double GetVolat(double startDate, double endDate, double strike, bool isPut, int volatilityType) const;

			virtual double GetNthVolat(unsigned int index) const;

			virtual double GetVolat(double strike, FPGridMaturity& maturity) const;

			virtual void SetVolat(double strike, FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;

			virtual void SetNthVolat(unsigned int index, double val);

		protected:
			CSRFastPnlVolatilityGrid();
			CSRFastPnlDataGrid* fDataGrid;
		};

		class SOPHIS_FASTPNL CSRFastPnlVegaGrid : public FastPnl::FPVega
		{			

		public:

			virtual ~CSRFastPnlVegaGrid();

			CSRFastPnlVegaGrid(long productCode, long underlyingCode , const CSRFastPnlInterpolationGrid* grid=NULL, bool arbitrage = false);

			CSRFastPnlVegaGrid(const CSRFastPnlVegaGrid& vega);

			virtual CSRFastPnlVegaGrid* Clone() const;				

			virtual double GetShift(const FPVolatility & baseVolatility, const FPVolatility & vol) const;

			virtual double GetNthVega(unsigned int index) const;

			virtual double GetVega(double strike, FPGridMaturity& maturity) const;

			virtual void SetVega(double strike, FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;

			virtual void SetNthVega(unsigned int index, double val);

		protected:
			CSRFastPnlVegaGrid();
			bool fArbitrage;
			long fProductCode;
			CSRFastPnlDataGrid* fDataGrid;
		};


		class SOPHIS_FASTPNL CSRFastPnlYieldCurveGrid : public FastPnl::FPYieldCurve
		{			

		public:

			virtual ~CSRFastPnlYieldCurveGrid();

			CSRFastPnlYieldCurveGrid(long productCode , long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL); 

			CSRFastPnlYieldCurveGrid(const CSRFastPnlYieldCurveGrid& yc); 

			virtual CSRFastPnlYieldCurveGrid* Clone() const;				

			virtual double GetForwardCompoundFactor(long currency_family, double date1,double date2) const;

			virtual double GetNthForwardCompoundFactor(unsigned int index) const;

			virtual void SetNthForwardCompoundFactor(unsigned int index, double val);

			virtual void SetForwardCompoundFactor(FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;

			virtual double GetForwardCompoundFactor(FPGridMaturity& maturity) const;

		protected:
			CSRFastPnlYieldCurveGrid();			
			CSRFastPnlDataGrid* fDataGrid;
		};

		class SOPHIS_FASTPNL CSRFastPnlRhoGrid : public FastPnl::FPRho
		{			

		public:

			virtual ~CSRFastPnlRhoGrid();

			CSRFastPnlRhoGrid(long productCode ,long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL, bool arbitrage = false);

			CSRFastPnlRhoGrid(const CSRFastPnlRhoGrid& rho);

			virtual CSRFastPnlRhoGrid* Clone() const;				

			virtual double GetShift(const FPYieldCurve & baseYieldCurve, const FPYieldCurve & yieldCurve) const;

			virtual double GetNthRho(unsigned int index) const;

			virtual void SetNthRho(unsigned int index, double val);

			virtual double GetRho(FPGridMaturity& maturity) const;

			virtual void SetRho(FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;

		protected:
			CSRFastPnlRhoGrid();	
			bool fArbitrage;
			long fProductCode;
			CSRFastPnlDataGrid* fDataGrid;
		};

		class SOPHIS_FASTPNL CSRFastPnlRepoGrid :  public FastPnl::FPRepo
		{			

		public:

			virtual ~CSRFastPnlRepoGrid();

			CSRFastPnlRepoGrid(long productCode ,long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL); 

			CSRFastPnlRepoGrid(const CSRFastPnlRepoGrid& repo); 	

			virtual CSRFastPnlRepoGrid* Clone() const;				

			virtual	double GetRepoMargin(long instrumentCode, double date1, double date2) const;

			virtual double GetNthRepo(unsigned int index) const;

			virtual void SetNthRepo(unsigned int index, double val);

			virtual double GetRepo(FPGridMaturity& maturity) const;

			virtual void SetRepo(FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;
		protected:
			CSRFastPnlRepoGrid();			
			CSRFastPnlDataGrid* fDataGrid;
		};

		class SOPHIS_FASTPNL CSRFastPnlCreditGrid :  public FastPnl::FPCredit
		{			

		public:

			virtual ~CSRFastPnlCreditGrid();

			CSRFastPnlCreditGrid(long productCode ,long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL); 

			CSRFastPnlCreditGrid(const CSRFastPnlCreditGrid& credit); 	

			virtual CSRFastPnlCreditGrid* Clone() const;				

			//virtual const CSRFastPnlInterpolationGrid* GetGrid() const;

			virtual double GetNthCredit(unsigned int index) const;

			virtual void SetNthCredit(unsigned int index, double val);

			virtual double GetCredit(FPGridMaturity& maturity) const;

			virtual void SetCredit(FPGridMaturity& maturity, double val);

			//virtual double GetUpfront(unsigned int index) const;

			//virtual void SetUpfront(unsigned int index, double val);
	
			virtual const CSRFastPnlDataGrid* GetStorage() const;
		protected:
			CSRFastPnlCreditGrid();
			//CSRFastPnlInterpolationGrid* fGrid;
			CSRFastPnlDataGrid* fDataGrid;
			//_STL::vector<double> fCDSRates;
			//_STL::vector<double> fUpfrontData;
			//bool fArbitrage;
			//long fProductCode;
		};

		class SOPHIS_FASTPNL CSRFastPnlForwardEffectGrid : public FastPnl::FPForwardEffect
		{			

		public:

			virtual ~CSRFastPnlForwardEffectGrid();

			CSRFastPnlForwardEffectGrid(long productCode ,long underlyingCode, const CSRFastPnlInterpolationGrid* grid=NULL, bool arbitrage = false);

			CSRFastPnlForwardEffectGrid(const CSRFastPnlForwardEffectGrid& fwd);

			virtual CSRFastPnlForwardEffectGrid* Clone() const;				

			virtual double GetShift(const FPRepo & baseRepo, const FPRepo & repo) const;

			virtual double GetNthForwardEffect(unsigned int index) const;

			virtual void SetNthForwardEffect(unsigned int index, double val);

			virtual double GetForwardEffect(FPGridMaturity& maturity) const;

			virtual void SetForwardEffect(FPGridMaturity& maturity, double val);

			virtual const CSRFastPnlDataGrid* GetStorage() const;
		protected:
			CSRFastPnlForwardEffectGrid();			
			bool fArbitrage;
			long fProductCode;
			CSRFastPnlDataGrid* fDataGrid;
		};

		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FASTPNL CSRFastPnlCreditSensitivityGrid : public FastPnl::FPCreditSensitivity
		{			
		public:

			virtual ~CSRFastPnlCreditSensitivityGrid();

			CSRFastPnlCreditSensitivityGrid(long productCode, long curveCode, const CSRFastPnlInterpolationGrid* grid=NULL, bool arbitrage = false);

			CSRFastPnlCreditSensitivityGrid(const CSRFastPnlCreditSensitivityGrid& credit);

			virtual CSRFastPnlCreditSensitivityGrid* Clone() const;

			virtual double GetShift(const FPCredit& baseCredit, const FPCredit& credit, bool isUpfront = false) const;

			double GetCDSRate(long maturity) const;

			void SetCDSRate(long maturity, double rate);

			double GetSensitivity(FPGridMaturity maturity) const;	
 
			void SetSensitivity(FPGridMaturity maturity, double sensitivity);

			double GetSensitivity(long index) const;	

			void SetSensitivity(long index, double sensitivity);

			virtual const CSRFastPnlDataGrid* GetStorage() const;
		protected:
			CSRFastPnlCreditSensitivityGrid();			
			bool fArbitrage;
			long fProductCode;
			_STL::vector<double> fCDSRates;
			_STL::vector<double> fSensitivities;
			CSRFastPnlDataGrid* fDataGrid;
		};
		SPH_END_NOWARN_EXPORT

		/** Forward declaration of CSRFastPnlBufferProxy */
		class CSRFastPnlBufferProxy;
		class CSRFastPnlCumulativeBufferProxy;
		
		/** Enum describing the status of the data stored in the Fast Pnl
		@since 5.3.5
		*/
		enum eLastCalcResult
		{
			eNoData,
			eDataAvailable,
			eFullCalcDone,
			eFromEOD,
			eFastCalcDone,
			eNeedRecompute,
			eNothingInEOD,
			eNoConf,
			eToolkitState
		};
		
		/** Events that the Fast Pnl can send to the registred observers
		@see IObserverFastPnL
		@since 5.3.5
		*/
		enum eFastPnLEventType
		{
			eDisconnected,
			eReconnected
		};

		/** Interface to observe Fast PnL events
		@since 5.3.5
		*/
		class IObserverFastPnL
		{
		public:
			/** Send to the observers the given event
			@param evenType the event to send
			@see eFastPnLEventType
			@since 5.3.5
			*/
			virtual void Update(eFastPnLEventType eventType) = 0;
		};
		
		/** Class to handle all the data (Calculated data, calculation state, archiving ...) of the Fast Pnl.
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL FastPnlBuffer
		{
		public :
			/** Trivial constructor.*/
			FastPnlBuffer();
			virtual ~FastPnlBuffer();

			/**
			* This class stores all greeks values for a given product
			@since 5.3.5
			*/
			SPH_BEGIN_NOWARN_EXPORT
			class SOPHIS_FASTPNL FPGreeks
			{
			public :
				/** Trivial constructor.*/
				FPGreeks() : spot0(0.0),delta(0.0),vega(NULL),volat0(NULL), repo0(NULL), forwardEffect(NULL), riskSourceCode(0){};
				
				virtual ~FPGreeks();
				
				/** Copy constructor */
				FPGreeks(const FPGreeks& other);
				
				virtual FPGreeks& operator=(const FPGreeks& other);

				/** Clone method.
				Useful for operator = in FPBufferData
				@return cloned object of the current object
				@since 5.3.5
				*/
				virtual FPGreeks* Clone() const;

				long					riskSourceCode;
				double					delta;
				FPVega*					vega;
				double					spot0;
				_STL::vector<double>	gamma;
				FPVolatility*			volat0;
				FPRepo*					repo0;
				FPForwardEffect*		forwardEffect;
			};
			SPH_END_NOWARN_EXPORT

			/**
			* This class stores Rho risk sources for a given product
			@since 5.3.6
			*/
			class SOPHIS_FASTPNL FPRhoSource
			{
			public :
				/** Trivial constructor.*/
				FPRhoSource() : yieldCurve0(NULL),rho(NULL),currencyCode(0){};

				virtual ~FPRhoSource();

				/** Copy constructor */
				FPRhoSource(const FPRhoSource& other);

				virtual FPRhoSource& operator=(const FPRhoSource& other);

				/** Clone method.
				Useful for operator = in FPBufferData
				@return cloned object of the current object
				@since 5.3.6
				*/
				virtual FPRhoSource* Clone() const;

				long					currencyCode;
				FPYieldCurve*			yieldCurve0;
				FPRho*					rho;
			};

			/**
			* This class stores credit risk sources for a given product
			@since 6.3
			*/
			class SOPHIS_FASTPNL FPCreditSource
			{
			public :
				/** Trivial constructor.*/
				FPCreditSource();

				virtual ~FPCreditSource();

				/** Copy constructor */
				FPCreditSource(const FPCreditSource& other);

				virtual FPCreditSource& operator=(const FPCreditSource& other);

				/** Clone method.
				Useful for operator = in FPBufferData
				@return cloned object of the current object
				@since 6.3
				*/
				virtual FPCreditSource* Clone() const;

				long					curveCode;
				FPCredit*				credit0;
				FPCreditSensitivity*	creditSensitivity;
			};

			/** Class to handle product calculation state
			@since 5.3.5
			*/
			class SOPHIS_FASTPNL FPBufferState
			{
			public:			

				virtual ~FPBufferState();

				FPBufferState();

				FPBufferState(long code);
				
				/** Copy constructor */
				FPBufferState(const FPBufferState& other);
				
				FPBufferState& operator=(const FPBufferState& other);
				
				/* Get the last calculation status.
				@return The status of last calculation.
				@since 5.3.5
				@see eLastCalcResult
				*/
				virtual eLastCalcResult GetLastCalcRes() const;

				/* Get the time of the last full calculation.
				@return The time of the last full calculation.
				@since 5.3.5
				*/
				virtual long GetLastCalcTime() const;

				/* Set the time of the last full calculation.
				@return The status of last calculation
				@since 5.3.5
				*/
				virtual void SetLastCalcRes(eLastCalcResult calcRes);

				/* Set the time of the last full calculation.
				@return The status of last calculation
				@since 5.3.5
				*/
				virtual void	SetLastCalcTime(long calcTime);

				long fCode;

			protected:				

				void Initialize(long code);

				void Initialize(const FPBufferState& other);

				char fCalcRes;

				long fLastCalcTime;

			};

			/** Class for handling data archiving
			@since 5.3.5
			*/
			class SOPHIS_FASTPNL FPBufferArchiving
			{
			public:
				/** Serialize the volatility, used for distributed cache
				@param vol volatility to be serialized
				@param toArchive archive where to serialize the volatility
				@return true if succeeded else false
				@since 5.3.5
				*/
				virtual bool SerializeVolatility(const FPVolatility* vol,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeVolatility(const FPVolatility* vol, void* gridData) const;
				#endif

				/** Deserialize the volatility, used for distributed cache
				@param fromArchive archive where to extract the volatility
				@return deserialized volatility
				@since 5.3.5
				*/
				virtual FPVolatility* DeserializeVolatility(long code, long underlyingCode,
					const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPVolatility* DeserializeVolatility(long code, long underlyingCode,
					const void* gridData) const;
				#endif
				
				/** Serialize the vega, used for distributed cache
				@param vega volatility to be serialized
				@param toArchive archive where to serialize the vega
				@return true if succeeded else false
				@since 5.3.5
				*/
				virtual bool SerializeVega(const FPVega* vega,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeVega(const FPVega* vega, void* gridData) const;
				#endif
				
				/** Deserialize the vega, used for distributed cache
				@param fromArchive archive where to extract the vega
				@return deserialized vega
				@see FPVega
				@since 5.3.5
				*/
				virtual FPVega* DeserializeVega(long code,long underlyingCode,const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPVega* DeserializeVega(long code,long underlyingCode,const void* gridData) const;
				#endif
				
				/** 
				*/
				virtual bool SerializeYieldCurve(const FPYieldCurve* yc,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeYieldCurve(const FPYieldCurve* yc, void* gridData) const;
				#endif

				/**
				*/
				virtual FPYieldCurve* DeserializeYieldCurve(long code,long underlyingCode, const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPYieldCurve* DeserializeYieldCurve(long code,long underlyingCode, const void* gridData) const;
				#endif

				/** 
				*/
				virtual bool SerializeRho(const FPRho* rho,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeRho(const FPRho* rho, void* gridData) const;
				#endif

				/**
				*/
				virtual FPRho* DeserializeRho(long code,long underlyingCode,const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPRho* DeserializeRho(long code,long underlyingCode, const void* gridData) const;
				#endif

				/** 
				*/
				virtual bool SerializeRepo(const FPRepo* repo,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeRepo(const FPRepo* repo, void* gridData) const;
				#endif

				/**
				*/
				virtual FPRepo* DeserializeRepo(long code,long underlyingCode, const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPRepo* DeserializeRepo(long code,long underlyingCode, const void* gridData) const;
				#endif

				/**
				*/
				virtual bool SerializeCredit(const FPCredit* repo, sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeCredit(const FPCredit* credit, void* gridData) const;
				#endif

				/**
				*/
				virtual FPCredit* DeserializeCredit(long code,long curveCode, const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPCredit* DeserializeCredit(long code,long curveCode, const void* gridData) const;
				#endif

				/**
				*/
				virtual bool SerializeForwardEffect(const FPForwardEffect* fwd,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeForwardEffect(const FPForwardEffect* fwd, void* gridData) const;
				#endif

				/**
				*/
				virtual FPForwardEffect* DeserializeForwardEffect(long code,long underlyingCode, const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPForwardEffect* DeserializeForwardEffect(long code,long underlyingCode, const void* gridData) const;
				#endif

				/**
				*/
				virtual bool SerializeCreditSensitivity(const FPCreditSensitivity* fwd,sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool SerializeCreditSensitivity(const FPCreditSensitivity* fwd, void* gridData) const;
				#endif

				/**
				*/
				virtual FPCreditSensitivity* DeserializeCreditSensitivity(long code, long curveCode, const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual FPCreditSensitivity* DeserializeCreditSensitivity(long code, long curveCode, const void* gridData) const;
				#endif

				/** Serialize the toolkit greeks(user defined), used for distributed cache
				@param tkgreek user defined greeks
				@param toArchive archive where to serialize the toolkit greeks
				@return true if succeeded else false
				@since 5.3.5
				*/
				/** 
				*/
				//virtual bool SerializeGrid(const _STL::map<long,const CSRFastPnlInterpolationGrid*>& grids, sophis::tools::CSRArchive& toArchive) const;

				virtual void SerializeGrid(const CSRFastPnlInterpolationGrid* grid, sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual void SerializeGrid(const CSRFastPnlInterpolationGrid* grid, void* toGrid) const;
				#endif
				/** 
				*/
				//virtual void DeserializeGrid(const sophis::tools::CSRArchive& fromArchive,_STL::map<long,CSRFastPnlInterpolationGrid*>& outGrids) const;

				virtual CSRFastPnlInterpolationGrid* DeserializeGrid(const sophis::tools::CSRArchive& fromArchive) const;
				#ifndef GCC_XML
				virtual CSRFastPnlInterpolationGrid* DeserializeGrid(const void* grid) const;
				#endif

				virtual bool SerializeToolkitGreek(const FPToolkitGreek* tkgreek,sophis::tools::CSRArchive& toArchive) const;
				
				/** Deserialize the toolkit greeks, used for distributed cache
				@param fromArchive archive where to extract the vega
				@return deserialized toolkit greeks
				@see FPToolkitGreek
				@since 5.3.5
				*/
				virtual FPToolkitGreek* DeserializeToolkitGreek(const sophis::tools::CSRArchive& fromArchive) const;
				
				/** Serialize the toolkit market data(user defined), used for distributed cache
				@param tkmd user defined market data
				@param toArchive archive where to serialize the user defined market data
				@return true if succeeded else false
				@since 5.3.5
				*/
				virtual bool SerializeToolkitMarketData(const FPToolkitMarketData* tkmd,sophis::tools::CSRArchive& toArchive) const;
				
				/** Deserialize the toolkit market data(user defined), used for distributed cache
				@param fromArchive archive where to to extract the user defined market data
				@return deserialized toolkit market data
				@since 5.3.5
				*/
				virtual FPToolkitMarketData* DeserializeToolkitMarketData(const sophis::tools::CSRArchive& fromArchive) const;				

				/** Create a single instance of CSRArchive
				@return an instance of CSRArchive
				@see sophis::tools::CSRArchive
				@since 5.3.5
				*/
				virtual sophis::tools::CSRArchive* CreateArchive() const;
				
				/** Set the single instance the FPBufferArchiving
				@param arch instance of FPBufferArchiving to set
				@since 5.3.5
				*/
				static void SetInstance(FPBufferArchiving* arch);
				
				/** Get the single instance the FPBufferArchiving
				@return instance of FPBufferArchiving
				@since 5.3.5
				*/
				static const FPBufferArchiving* GetInstance();

				protected:
					/** single instance of FPBufferArchiving */
					static FPBufferArchiving* fInstance;
			};

			/** Base class to store all data for a given product in the buffer
			It contains all initial values (spot0, theo0....) , greeks (delta/gamma/vega...) and underlyings (count and codes)									
			Data were stored during last full calculation
			@since 5.3.5
			*/			
			SPH_BEGIN_NOWARN_EXPORT
			class SOPHIS_FASTPNL FPBufferData : public virtual FPBufferState
			{
			public:

				enum eInterpolationMode
				{
					eUseDelta			= 0x1,
					eUseGamma			= 0x2,
					eUseCrossedGamma	= 0x4,
					eUseVega			= 0x8,
					eUseRho				= 0x10,
					eUseForward			= 0x20,
					eUseCredit			= 0x40,
					eUseToolkitGreek	= 0x10000,
					eUseDefault			= eUseDelta + eUseGamma + eUseCrossedGamma
				};

				virtual ~FPBufferData();

				FPBufferData(const FPBufferData& other);

				virtual FPBufferData& operator=(const FPBufferData& other);

				/** Copy all the current buffer data to the given buffer data structure,
				except data related to the state
				@param dest destination of buffer data copy
				@since 5.3.5
				*/
				virtual void	CopyNoState(FPBufferData& dest) const;

				/** Returns a new Greek storage object
				Override this method to use your own greek storage
				@return default returns new FPGreeks()	
				@since 5.3.5
				*/
				virtual FPGreeks* CreateNewGreek() const; 

				/** Returns a new Rho storage object
				Override this method to use your own rho storage
				@return default returns new FPRhoSource()	
				@since 5.3.5
				*/
				virtual FPRhoSource* CreateNewRhoSource() const; 

				virtual FPCreditSource* CreateNewCreditSource() const;

				double fTheoreticalValue;

				void ResetUnderlyingSources();
				_STL::vector<FPGreeks*> fGreeksInfo;//Not that ~FPGreeks will automatically delete each element

				_STL::vector<FPRhoSource*> fRhosInfo;

				_STL::vector<FPCreditSource*> fCreditInfo;

				bool fIsUpfront;

				double fZCSpreadSensitivity;

				double fSpread;

				double fTheta;

				/** This represents the time of the last full calculation stored in the cache, 
				useful for distributed calculation */
				long fLastBufferUpdate;

				FPToolkitGreek* fToolkitGreek;

				FPToolkitMarketData* fToolkitMarketData0;

				long fInterpolationMode;

				PrototypesNamesHelperClass fCalculatorPrototypesNames;
				
				/** Save the last full calculation time
				Useful in case of distributed cache
				@param buffTime Time of the last full calculation in the cache
				@since 5.3.5
				*/
				virtual void	SetLastBufferUpdateTime(long buffTime);				
				
				/** Get the number of the current product risk sources.
				@return number of underlying	
				@since 5.3.5
				*/
				virtual long	GetUnderlyingCount() const;
				
				/** Get the nth underlying risk sources.
				@param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
				@return the ID of the instrument.
				@since 5.3.5
				*/
				virtual long	GetNthUnderlying(int whichUnderlying) const;

				/** Get the index of a given underlying code
				@param whichUnderlying is an index between 0 (included) and GetUnderlyingCount() (excluded).
				@param underlyingIndex index of the underlying if present, output of the method.
				@return true if underlyingCode is a code of an underlying of the current product else false.
				@since 5.3.5
				*/
				virtual bool	GetUnderlyingindexInInstrument(long underlyingCode, int& underlyingIndex) const;
				
				virtual const _STL::vector<FPGreeks*>&	GetUnderlyingSources() const;

				/** Get the number of the current product rho sources.
				@return number of rho sources	
				@since 5.3.6
				*/
				virtual long	GetRhoCount() const;

				/** Get the nth underlying rho sources.
				@param whichCurrency is in index between 0 (included) and GetRhoCount() (excluded).
				@return the ID of the currency.
				@since 5.3.5
				*/
				virtual long	GetNthRho(int whichCurrency) const;

				/** Get the index of a given currency rho source code
				@param CurrencyCode rho source code
				@param underlyingIndex index of the currency if present, output of the method.
				@return true if CurrencyCode is a code of a rho source of the current product else false.
				@since 5.3.5
				*/
				virtual bool	GetRhoIndexInInstrument(long CurrencyCode, int& CurrencyIndex) const;

				/** Get all the stored rho sources
				@return stored rho sources in the Fast Pnl buffer
				@since 6.3
				*/
				virtual const _STL::vector<FPRhoSource*>&	GetRhoSources() const;

				/** Get the stored delta of a given risk source index
				@param whichUnderlying index of the underlying on which we want to get the delta
				@return delta of the underlying
				@since 5.3.5
				*/
				virtual			double					GetDelta			(int whichUnderlying) const;

				/** Get the stored gamma of a given underlying indexes,
				a matrix represents internally gammas
				@param which1 index of first underlying
				@param which2 index of the second underlying
				@return gamma indexed by the two given underlyings
				@since 5.3.5
				*/
				virtual			double					GetGamma			(int which1, int which2) const;
				
				/** Get the stored vega of a given underlying index
				@param whichUnderlying index of the underlying on which we want to get the vega
				@return stored vega in the fast Pnl buffer of the underlying in parameter
				@since 5.3.5
				*/
				virtual			const FPVega *			GetVega				(int whichUnderlying) const;

				/** Get the stored Rho of a given underlying index
				@param whichCurrency index of the currency for which we want to get the rho
				@return stored Rho in the fast Pnl buffer of the given currency index
				@since 5.3.6
				*/
				virtual			const FPRho *			GetRho				(int whichCurrency) const;

				/** Get the stored Forward effect(sensitivity to repo) of a given underlying index
				@param whichUnderlying index of the underlying on which we want to get the forward effect
				@return stored forward effect in the Fast Pnl buffer of the given underlying index
				@since 5.3.6
				*/
				virtual			const FPForwardEffect*			GetForwardEffect	(int whichUnderlying) const;


				/** Get the number of the current product credit risk sources.
				@return number of credit risk sources	
				@since 6.3
				*/
				virtual long	GetCreditSourcesCount() const;
				
				/** Get the nth credit risk source.
				@param whichUnderlying is in index between 0 (included) and GetCreditSourcesCount() (excluded).
				@return the ID of the credit risk source.
				@since 6.3
				*/
				virtual long	GetNthCreditSource(int whichUnderlying) const;

				/** Get all the stored credit effects
				@return stored credit effects in the Fast Pnl buffer
				@since 6.3
				*/
				virtual const _STL::vector<FPCreditSource*>&	GetCreditSources() const;

				/** Get the stored credit effect.
				@param curveCode code of the credit risk curve
				@return stored credit effect in the Fast Pnl buffer of the given key
				@since 6.3
				*/
				virtual			const FPCreditSensitivity*			GetCreditSensitivity	(long curveCode) const;

				/** Get the stored ZC credit spread sensitivities.
				@return true if the credit risk source is quoted in upfront. Otherwise, false.
				@since 6.3
				*/
				virtual			bool							IsUpfront() const;

				/** Set the stored ZC credit spread sensitivities.
				@param value true if the credit risk source is quoted in upfront. Otherwise, false.
				@since 6.3
				*/
				virtual			void							SetIsUpfront(bool value);

				/** Get the stored ZC credit spread sensitivities.
				@return the stored ZC credit spread sensitivities.
				@since 6.3
				*/
				virtual double								GetZCSpreadSensitivity() const;

				/** Get the stored credit spread sensitivities.
				@return the stored credit spread sensitivities.
				@since 6.3
				*/
				virtual double								GetCreditSpread() const;

				/** Get the greeks other than Delta/Gamma/Vega
				@return the other greeks defined by the user 
				@since 5.3.5
				*/
				virtual			const FPToolkitGreek*	GetToolkitGreek() const;
				
				/** Get the market data other than spot/vol
				@return the market data defined by the user
				@since 5.3.5
				*/
				virtual			const FPToolkitMarketData*	GetToolkitMarketData0() const;
				
				/** Get the theoretical value stored in the buffer
				@return the theoretical value
				@since 5.3.5
				*/
				virtual			double						GetTheoretical0	() const;

				/** Get the volatility of the given risk source index
				@return the volatility stored in buffer
				@since 5.3.5
				*/
				virtual			const FPVolatility *		GetVolat0		(int whichUnderlying) const;

				/** Get the spot value of the given risk source index
				@param whichUnderlying index of the underlying of which we want to get the spot
				@return the spot in buffer
				@since 5.3.5
				*/
				virtual			double						GetSpot0			(int whichUnderlying) const;

				/** Get the yield cruve of the given currency source index
				@param whichCurrency index of the currency of which we want to get the yield curve
				@return the yield curve stored in buffer
				@since 5.3.6
				*/
				virtual			const FPYieldCurve *		GetYieldCurve0		(int whichCurrency) const;

				/** Get the repo of the given risk source index
				@return the volatility stored in buffer
				@since 5.3.6
				*/
				virtual			const FPRepo *		GetRepo0		(int whichUnderlying) const;

				/** Get the credit of the given risk source index
				@param whichUnderlying index of the credit risk source
				@return the credit risk stored in buffer
				@since 6.3
				*/
				virtual			const FPCredit *	GetCredit0	(int whichUnderlying) const;

				/** Get the credit of the given risk source code
				@param curveCode code of the credit riskCode
				@return the credit risk stored in buffer
				@since 6.3
				*/
				virtual			const FPCredit *	GetCredit0ByCode	(long curveCode) const;

				/** Get the theoretical interpolation mode that will be used for the instrument.				
				@return a combination of the eInterpolationMode values (bitmask).
				@since 5.3.5
				*/
				virtual long GetInterpolationMode() const;

				/** Store the delta for the given risk source index in the buffer 
				@param whichUnderlying index of the underlying of which we want to set the delta
				@param in_delta delta to store
				@since 5.3.5
				*/
				virtual void SetDelta(int whichUnderlying, double in_delta);
				
				/** Store the gamma for the two given risk sources in the buffer 
				@param which1 index of first underlying
				@param which2 index of the second underlying
				@param in_gamma gamma to be stored in the coordinates which1, which2
				@since 5.3.5
				*/
				virtual void SetGamma(int which1, int which2, double in_gamma);
			
				/** Store the vega for the given underlying index in the buffer
				@param whichUnderlying index of the underlying for which we want to get the vega
				@param in_vega vega to be stored
				@since 5.3.5
				*/
				virtual void SetVega(int whichUnderlying, FPVega * in_vega); // we give ownership of the in_vega structure !!

				/** Store the rho for the given underlying index in the buffer
				@param whichCurrency index of the currency for which we want to get the rho
				@param in_rho rho to be stored
				@since 5.3.6
				*/
				virtual void SetRho(int whichCurrency, FPRho * in_rho); 
				
				/** Store the Forward effect(sensitivity to repo) for the given underlying index in the buffer
				@param whichUnderlying index of the underlying for which we want to get the forward effect
				@param in_forwardEffect forward effect to be stored
				@since 5.3.5
				*/
				virtual void SetForwardEffect(int whichUnderlying, FPForwardEffect * in_forwardEffect); 

				/** Store the credit effect for the given key (issuer, default event, currency, seniority)
				@param issuer issuer which provides the credit risk
				@param defaultEvent the default event
				@param currency the currency of the credit risk
				@param seniority the currency of the credit risk
				@since 6.3
				*/
				virtual	void SetCreditSensitivity (long curveCode, FPCreditSensitivity* in_creditSensitivity);

				/** Store the ZC Spread sensitivity
				@param ZCSpreadSensitivity the ZC Spread sensitivity to store
				@since 6.3
				*/
				virtual void SetZCSpreadSensitivity(double ZCSpreadSensitivity);
				
				/** Store the credit spread sensitivity
				@param spread the spread sensitivity to store
				@since 6.3
				*/
				virtual void SetCreditSpread(double spread);

				/** Store the given theoretical value for the current product
				@param in_theoVal theoretical value to store
				@since 5.3.5
				*/
				virtual void SetTheo(double in_theoVal);


				/** Store the volatility for the given  risk source index in the buffer
				@param whichUnderlying index of the underlying for which we want to save the volatility in the buffer
				@param in_vol volatility to be saved
				@since 5.3.5
				*/
				virtual void SetVolat0(int whichUnderlying, FPVolatility* in_vol);

				/** Store the spot for the given risk source in the buffer
				@param whichUnderlying index of the underlying for which we want to save the spot in the buffer
				@param in_last spot to be saved
				@since 5.3.5
				*/
				virtual void SetSpot0(int whichUnderlying, double in_last);

				/** Store the yield curve for the given  risk source index in the buffer
				@param whichCurrency index of the currency for which we want to save the yield curve in the buffer
				@param in_yieldCurve yield curve to be saved
				@since 5.3.6
				*/
				virtual void SetYieldCurve0(int whichCurrency, FPYieldCurve* in_yieldCurve);

				/** Store the repo for the given risk source index in the buffer
				@param whichUnderlying index of the underlying for which we want to save the repo in the buffer
				@param in_repo repo to be saved
				@since 5.3.5
				*/
				virtual void SetRepo0(int whichUnderlying, FPRepo* in_repo);

				/** Store the credit for the given risk source index in the buffer
				@param issuer issuer which provides the credit risk
				@param defaultEvent the default event
				@param currency the currency of the credit risk
				@param seniority the currency of the credit risk
				@param in_credit credit to be saved
				@since 6.3
				*/
				virtual void SetCredit0(long curveCode, FPCredit* in_credit);

				/** Store the theoretical interpolation mode that will be used for the instrument.
					This allows to select which greeks will be considerated during interpolation.   
				@param mode is a combination of the eInterpolationMode values (bitmask).
				@since 5.3.5
				*/
				virtual void SetInterpolationMode(long mode);

				/** Used to initialize the greeks of the current product
				@param whichUnderlying index of the underlying where to add new greeks
				@param codeSJ code of risk source code to add
				@since 5.3.5
				*/
				virtual void SetSourceCode(int whichUnderlying, long codeSJ);

				/** Used to initialize the rho source of the current product
				@param whichCurrency index of the currency where to add new greeks
				@param codeCurrency code of cuurency source code to add
				@since 5.3.5
				*/
				virtual void SetRhoSourceCode(int whichCurrency, long codeCurrency);
				
				/** Used to initialize the rho source of the current product
				@param whichCurrency index of the currency where to add new greeks
				@param codeCurrency code of cuurency source code to add
				@since 5.3.5
				*/
				virtual void SetCreditRiskSourceCode(int whichCurrency, long curveCode);

				/** Serialize the data of the buffer, save the current data in buffer into the given archive
				@param toArchive archive where the serialized data is stored
				@return true if succeeded else false
				@see FPBufferArchiving::SerializeVolatility
				@see FPBufferArchiving::SerializeVega
				@see FPBufferArchiving::SerializeToolkitGreek
				@see FPBufferArchiving::SerializeToolkitMarketData
				@since 5.3.5
				*/
				virtual bool Serialize(sophis::tools::CSRArchive& toArchive) const;
				#ifndef GCC_XML
				virtual bool Serialize(void* toMessage) const;
				#endif
				
				/** Deserialize the given archive, store the data extracted from the archive into the buffer
				@param fromArchive archive to be deserialized in the buffer
				@return true if succeeded else false
				@see FPBufferArchiving::DeserializeVolatility
				@see FPBufferArchiving::DeserializeVega
				@see FPBufferArchiving::DeserializeToolkitGreek
				@see FPBufferArchiving::DeserializeToolkitMarketData
				@since 5.3.5
				*/
				virtual bool Deserialize(const sophis::tools::CSRArchive& fromArchive);
				#ifndef GCC_XML
				virtual bool Deserialize(const void* fromMessage);
				#endif

				virtual void SetCalculatorName(const char* name, eGridAnalysisType type);

				virtual const char* GetCalculatorName(eGridAnalysisType type) const;

				/** Set the yesterday theta. Should be done only when fast pnl buffer is loaded from the EOD.
				@param theta is the new theta value
				@since 6.3.1.2
				*/
				virtual void SetTheta(double theta);

				/** Get the yesterday theta. Available only when fast pnl buffer is loaded from the EOD.				
				@since 6.3.1.2
				*/
				virtual double GetTheta() const;

			protected:
				/** hided constructors */
				FPBufferData();
				FPBufferData(long instrumentCode);
				
				void Initialize(const FPBufferData& other);
				void Initialize(long instrumentCode);				

				friend class FastPnlBuffer;
			};
			SPH_END_NOWARN_EXPORT

			/** Default interpolation mode when a new FPBufferData is created
			@since 5.3.6
			*/
			static FPBufferData::eInterpolationMode fDefaultInterpolationMode;

			/** Create a single instance of FPBufferData
			@param code instrument code of the new FPBufferData
			@return instance of FPBufferData
			@since 5.3.5
			*/
			virtual FPBufferData* CreateNewBufferData(long code = 0) const { return new FPBufferData(code); }

			/** Get all the data stored in the buffer for a given instrument 
			@param code instrument code of the searched buffer data
			@param out  buffer data of the given instrument
			@return true if succeeded else false
			@since 5.3.5
			*/
			virtual bool GetBufferData(long code,FPBufferData & out) const;

			/** Set data in buffer 
			@param bufferElts data to be stored
			@since 5.3.5
			*/
			virtual void SetBufferData(const FPBufferData& bufferElts) const; 

			/** Set the data related to the state of calculation in buffer for the given instrument code 
			@param code instrument ID for which the data related to the state is needed
			@return data related to the state in the buffer of the given instrument
			@since 5.3.5
			*/
			virtual const FPBufferState &GetBufferState(long code) const;	
			
			/** Get the last calculation type carried out by the Fast Pnl of the given instrument
			@param code instrument ID for which the calculation type is needed
			@return last calculation type
			@see eLastCalcResult
			@see FPBufferState::GetLastCalcRes()
			@since 5.3.5
			*/
			virtual eLastCalcResult GetLastCalcRes(long code) const;

			/** Get the time of the last full calculation of the given instrument
			@param code instrument ID for which the the time of the last full calculation is needed
			@return time of the last full calculation
			@see FPBufferState::GetLastCalcTime()
			@since 5.3.5
			*/
			virtual long			GetLastCalcTime(long code) const;
			
			/** Check whether the given instrument code exists in the Fast Pnl buffer
			@param code instrument ID for which we check the existence in the buffer
			@return true if the instrument exists in buffer else false
			@see FastPnlBuffer::GetBufferData
			@since 5.3.5
			*/
			virtual bool HasDataForInstrument(long code) const;
			
			/** Initialize the proxy, by which we access to the data storage
			@see CSRFastPnlBufferProxy
			@since 5.3.5
			*/
			virtual void InstallProxy();
			
			/** Say whether we can access to the data storage or not
			@return true if we can access to the data storage else false
			@since 5.3.5
			*/
			virtual bool IsActive() const;

			/** Clear for the given code the data stored within the Fast Pnl buffer
			@since 5.3.6
			*/
			virtual void Clear(long code);
			
			/** Clear all the data stored within the Fast Pnl buffer
			@since 5.3.5
			*/
			virtual void Clear();
			
			/** Register observers to Fast Pnl events, this in an implementation of Observer pattern
			@param observer the object which observes Fast Pnl events
			@see IObserverFastPnL
			@since 5.3.5
			*/
			virtual void RegisterCacheObserver(IObserverFastPnL *observer) const;		
			
			/** Set the single instance of the Fast Pnl Buffer
			@param buff instance of the buffer
			@since 5.3.5
			*/
			static			void			SetInstance		(FastPnlBuffer* buff);
			
			/** Get the single instance of the Fast Pnl buffer
			@return the single instance of the buffer
			*/
			static const	FastPnlBuffer*	GetInstance		();

			protected:
				/** Proxy for data storage */
				sophis::FastPnl::CSRFastPnlBufferProxy* fFastPnlBufferProxy; //Ref Proxy
				static		FastPnlBuffer*	fInstance;
		};

		/* Class needed to handle adjustment of the greeks when an interpolation is done
		@since 5.3.5
		*/
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FASTPNL FPCalculationAdjustment
		{
		public:
			FPCalculationAdjustment();
			virtual ~FPCalculationAdjustment();

			virtual FPCalculationAdjustment& operator=(const _STL::vector<FastPnlBuffer::FPGreeks*>& other);
			virtual FPCalculationAdjustment& operator=(FPToolkitGreek* other);

			_STL::vector<FastPnlBuffer::FPGreeks*> fAdjustedGreeksInfo;//Not that ~FPGreeks will automatically delete each element
			FPToolkitGreek* fAdjustedToolkitGreek;
		};
		SPH_END_NOWARN_EXPORT

		/** Base class for the interpolation and getting Theoretical value
		@since 5.3.5
		*/
		class SOPHIS_FASTPNL  FastPnlServer			// abstract class
		{
		public :
			FastPnlServer();

			/** Set the single instance of the Fast Pnl server
			@param buff instance of the server
			@since 5.3.5
			*/
			static			void			SetInstance		(FastPnlServer* fpnls);

			/** Get the single instance of the Fast Pnl server
			@return the single instance of the server
			*/
			static const	FastPnlServer*	GetInstance		();

			virtual FPCalculationAdjustment* CreateNewCalculationAdjustment() const { return new FPCalculationAdjustment(); }

			/** Principal method of the Fast Pnl, it does the interpolation of the greeks and the theoretical value
			@param code instrument ID, of which the theoretical value is calculated 
			@param md is the current updated market data 
			@param pnlb instance of Fast Pnl buffer
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the interpolated theoretical value
			@since 5.3.5
			*/
			virtual			double			GetTheoretical	(long code, const FastPnlMarketData & md, const FastPnlBuffer & pnlb,FPCalculationAdjustment* outAdjust = NULL) const;
			
			/** Get the spot shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data 
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the spot shift
			@since 5.3.5
			*/
			virtual			double			GetSpotShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data,FPCalculationAdjustment* outAdjust = NULL) const;		// for delta
			
			/** Get the volatility shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data 
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the volatilty shift
			@since 5.3.5
			*/
			virtual			double			GetVolatShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data,FPCalculationAdjustment* outAdjust = NULL) const;	// for vega : B&S Vega only
			
			/** Get the yield curve shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data 
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the yield curve shift
			@since 5.3.6
			*/
			virtual			double			GetYieldCurveShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data,FPCalculationAdjustment* outAdjust = NULL) const;
			
			/** Get the repo shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data 
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the repo shift
			@since 5.3.6
			*/
			virtual			double			GetRepoShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data,FPCalculationAdjustment* outAdjust = NULL) const;	// for vega : B&S Vega only

			/** Get the credit risk shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data 
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the credit risk sensitivities.
			@return the credit risk shift
			@since 6.3
			*/
			virtual			double			GetCreditShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data, long code, bool isUpfront) const;

			/** Get the toolkit greeks(user defined) shift of a product between the market data of the buffer and the given market data  
			@param md is the current updated market data  
			@param data is the data stored in the buffer for an instrument, including market data 
			@param FPCalculationAdjustment eventually we can set an adjustment of the greeks
			@return the toolkit greeks shift
			@since 5.3.5
			*/
			virtual			double			GetToolkitGreeksShift	(const FastPnlMarketData & md, const FastPnlBuffer::FPBufferData & data,FPCalculationAdjustment* outAdjust = NULL) const;	// Empty

			/** Get the spot variation between the market data in buffer and the market data for a given underlying in percent 
			@param code instrument ID
			@param underlyingCode underlyling ID for which the spot variation is calculated
			@param md is the current updated market data 
			@param pnlb instance of Fast Pnl buffer 
			@return the spot variation in percent
			@since 5.3.5
			*/
			virtual			double			GetSpotVariation	(long code, long underlyingCode, const FastPnlMarketData & md, const FastPnlBuffer & pnlb) const;			
			
			/** Say for a given instrument whether it is supported for the Fast Pnl calculation or not, by default return true
			@param code instrument ID for which we test if it supported or not by the Fast Pnl calculation  
			@return true if the instrument is supported else false
			@since 5.3.5
			*/
			virtual bool					IsSupportedInstrumentType(long code) const { return true; }
			
			/** Fast Pnl error message logger
			@param msg is the error message to log
			@since 5.3.5
			*/
			virtual void					LogErrorMessage(const char* msg) const;

			/** Say whether the Fast Pnl component is activated or not
			@return true if Fast Pnl is activated else false
			@since 5.3.5
			*/
			virtual bool IsActive() const;

			/** Gives Fast Pnl today's date in Sophis format
			@since 6.3
			*/
			virtual long GetCurrentDate() const;

			/** Say whether the Fast Pnl component and the data storage are activated
			@return true if it is activated else false
			@since 5.3.5
			*/
			static bool IsFastPnlActive();

		protected:

			static		FastPnlServer*	fInstance;
			//FastPnlRiskMNGGreeksFactory *fGreeksFactory;

		};
	} // namespace FastPnl
} // namespace sophis

SPH_EPILOG
#endif
