#ifndef __SphFastPnlCumulativeBuffer_H__
#define __SphFastPnlCumulativeBuffer_H__

#include "SphInc/finance/SphFastPnlClient.h"

SPH_PROLOG
namespace sophis
{
	namespace FastPnl
	{
		/* Cumulative Strategy, handles cumulation for the intraday Pnl explainer */
		class SOPHIS_FASTPNL FPCumulativeServices
		{
		public:

			virtual ~FPCumulativeServices();

			/** Accumulate the different explanations of the difference between two buffers in the cumulative buffer, happens when a new ref fast pnl buffer is created
			@param previousBuffer buffer before the calculation, created previously than the currentBuffer
			@param currentBuffer is the current reference buffer
			@param cumulativeBuffer buffer where the cumulation is stored
			@since 6.3
			*/
			virtual void Accumulate(const FastPnlBuffer::FPBufferData& previousBuffer, const FastPnlBuffer::FPBufferData& currentBuffer, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;

			/** Accumulate the different explanations of the difference between a buffer and the current market data
			@param buffer is the buffer to compare
			@param md current market data
			@return buffer containing the explanations
			@since 6.3
			*/
			virtual FastPnlBuffer::FPBufferData* Accumulate(const FastPnlBuffer::FPBufferData& buffer, const FastPnlMarketData& md) const;

			/** Aggregate the effects of a buffer for a given grid
			@type determine the effect to aggregate
			@param grid to use for the aggregation
			@param buffer is the buffer that contains the effects to aggregate
			@return buffer containing aggregated data according to the given grid 
			@since 6.3
			*/
			virtual FastPnlBuffer::FPBufferData* RefineGrid(eGridAnalysisType type, const CSRFastPnlInterpolationGrid& grid, const FastPnlBuffer::FPBufferData& cumulativeBuffer) const;

			static void SetInstance(FPCumulativeServices* instance);

			static const FPCumulativeServices* GetInstance();
		
		protected:
			FPCumulativeServices();
			virtual double CalculateSpotShift(const FastPnlBuffer::FPBufferData& currentBufferElts, const FastPnlBuffer::FPBufferData& previousBufferElts, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;
			virtual double CalculateVolShift(const FastPnlBuffer::FPBufferData& currentBufferElts, const FastPnlBuffer::FPBufferData& previousBufferElts, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;
			virtual double CalculateYCShift(const FastPnlBuffer::FPBufferData& currentBufferElts, const FastPnlBuffer::FPBufferData& previousBufferElts, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;
			virtual double CalculateRepoShift(const FastPnlBuffer::FPBufferData& currentBufferElts, const FastPnlBuffer::FPBufferData& previousBufferElts, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;
			virtual double CalculateCreditShift(const FastPnlBuffer::FPBufferData& currentBufferElts, const FastPnlBuffer::FPBufferData& previousBufferElts, FastPnlBuffer::FPBufferData& cumulativeBuffer) const;
			static const char* __CLASS__;
			static FPCumulativeServices* fInstance;
		};
	}

}
SPH_EPILOG
#endif