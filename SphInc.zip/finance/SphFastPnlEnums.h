#ifndef __SphFastPnlEnums_H__
#define __SphFastPnlEnums_H__


#include "SphInc/SphMacros.h"

SPH_PROLOG

namespace sophis
{
	namespace FastPnl
	{
		enum eGridAnalysisType
		{
			eRhoAnalysis = 1,
			eVegaAnalysis,				
			eFwdAnalysis,
			eCreditAnalysis,
			eLastAnalysis
		};
	}
}

SPH_EPILOG
#endif