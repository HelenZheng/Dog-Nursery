/*
File:		SphFastPnlImpl_API.h

Contains:	Class for the handling the Risque implementation of FastPnL

Copyright:	� 2004 Sophis.
*/

/*! \file SphFastPnlImpl_API.h
\brief For the handling of Risque FastPnL implementation.
*/

#ifndef __SphFastPnlImpl_API_H__
#define __SphFastPnlImpl_API_H__

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(strstream)

#include "SphInc/finance/SphFastPnlClient.h" // from repository
#include "sphinc/tools/SphFastPnlBufferProxy.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphMenu.h"
#include "SphInc/finance/SphProductType.h"
#include "SphInc/finance/SphProductFeature.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphInc\finance\SphFastPnlPrototypes.h"


#define DECLARATION_FASTPNL_TRIGGER(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,FastPnLTriggerBase)
#define CONSTRUCTOR_FASTPNL_TRIGGER(derivedClass)
#define WITHOUT_CONSTRUCTOR_FASTPNL_TRIGGER(derivedClass)
#define	INITIALISE_FASTPNL_TRIGGER(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

#define DECLARATION_FASTPNL_TRIGGER_ACTION(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,FastPnLTriggerActionBase)
#define CONSTRUCTOR_FASTPNL_TRIGGER_ACTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_FASTPNL_TRIGGER_ACTION(derivedClass)
#define	INITIALISE_FASTPNL_TRIGGER_ACTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

#define DECLARATION_FASTPNL_TRIGGER_RESTRICTION(derivedClass)					DECLARATION_PROTOTYPE(derivedClass,FastPnLRestrictiveRule)
#define CONSTRUCTOR_FASTPNL_TRIGGER_RESTRICTION(derivedClass)
#define WITHOUT_CONSTRUCTOR_FASTPNL_TRIGGER_RESTRICTION(derivedClass)
#define	INITIALISE_FASTPNL_TRIGGER_RESTRICTION(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)


#define SizeOfStringInDB  100

SPH_PROLOG
namespace sophis
{
	class CSRComputationResults;

	namespace FastPnl
	{		
		class FastPnlBufferAPI ;
		class FastPnlContext;
		class FastPnLTriggerActionBase;
		class FastPnLRestrictiveRule;
		class CSRFastPnlBufferProxy;

		/** EOD implementation of the FastPnlBuffer class
		*/
		class SOPHIS_FIT FastPnlBufferAPI : public virtual sophis::FastPnl::FastPnlBuffer
		{

		private :
		

		public :
			FastPnlBufferAPI();

			virtual ~FastPnlBufferAPI();

			static const char* __CLASS__;	
			
			virtual bool GetBufferData(long code, FastPnlBuffer::FPBufferData & out) const;	
			
			virtual void SetBufferData(const FastPnlBuffer::FPBufferData& bufferElts) const;

			virtual void InstallProxy();

			static  void  PreRegisterCacheObserver(IObserverFastPnL *observer);

			virtual void TryCacheActivate() const;

			static FastPnlBuffer::FPBufferData* (*ChangeFastPNLBufferAccordingToPreferencesFct)(long instrumentCode, const FastPnlBuffer::FPBufferData& data, const sophis::market_data::CSRMarketData& context);
		};

		enum eTypeAction
		{
			eNever=0,
			eManual,
			eAuto
		};

		class SOPHIS_FIT FastPnLTriggerActionBase
		{
		public :
			FastPnLTriggerActionBase();

			typedef sophis::tools::CSRPrototype<FastPnLTriggerActionBase, _STL::string> prototype;

			static prototype & GetPrototype	();

			virtual FastPnLTriggerActionBase * Clone() const = 0;

			/** Accessor method to the type of action
			\return Type of action; is a value of the eTypeAction enum
			*/
			virtual eTypeAction Action()  const;

			virtual ~FastPnLTriggerActionBase();

		protected :	

			eTypeAction typeAction;

		};

		class SOPHIS_FIT FastPnLRestrictiveRule
		{
		public :
			FastPnLRestrictiveRule();

			virtual ~FastPnLRestrictiveRule();

			typedef sophis::tools::CSRPrototype<FastPnLRestrictiveRule, _STL::string> prototype;

			static prototype & GetPrototype	();

			virtual FastPnLRestrictiveRule * Clone() const = 0;

			/** Accessor method to the restriction
			\return Type of restriction
			*/
			virtual bool isRestrictive()  const;

		protected :	

			bool fRestrictive;

		};

		class SOPHIS_FIT FastPnLTriggerBase : public virtual FastPnLTrigger
		{
		public :
			FastPnLTriggerBase(const char* triggerName);

			/**
			Typedef for the prototype.... inspired from InstrumentAction
			*/
			typedef sophis::tools::CSRPrototype<FastPnLTriggerBase, _STL::string> prototype;

			/**
			Access to the prototype singleton.
			To add a trigger to this singleton, use INITIALISE_INSTRUMENT_ACTION.
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype	();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_INSTRUMENT_ACTION.
			@see tools::CSRPrototype
			*/
			virtual FastPnLTriggerBase * Clone() const = 0;

			/** Says whether a trigger is reached or not for a given instrument
			\param instrumentCode Sicovam of the instrument for which to test the trigger condition
			\param underlyingCode Sicovam of the underlying for which a DRT signal was received
			\param md Market data object to look into for checking if trigger was reached or not
			\param pnlb Pnl buffer object to look into for checking if trigger was reached or not
			\return true if trigger was reached, false otherwise
			*/
			virtual bool isReached(const FastPnlBuffer::FPBufferData& data,long underlyingCode, const FastPnlMarketData & md)  const;

			virtual bool isReached(const FastPnlBuffer::FPBufferData& data, FastPnlBuffer::FPCreditSource* creditSource, const FastPnlMarketData & md)  const;

			virtual bool isOnProduct() const;

			virtual bool isOnRhoSources() const;

			virtual bool isOnCreditSources() const;

			virtual void SetParameter(double param);

			virtual const char* GetParameterUnit() const;

		protected :	
			FastPnLTriggerBase();
			void Initialize(const char* triggerName);

			char __CLASS__[100];
			
		};


		class SOPHIS_FIT FastPnLTriggerActionNever : public virtual FastPnLTriggerActionBase
		{
		public :
			DECLARATION_FASTPNL_TRIGGER_ACTION(FastPnLTriggerActionNever)
				FastPnLTriggerActionNever();
		};

		class SOPHIS_FIT FastPnLTriggerActionManual : public virtual FastPnLTriggerActionBase
		{
		public :
			DECLARATION_FASTPNL_TRIGGER_ACTION(FastPnLTriggerActionManual)
				FastPnLTriggerActionManual();
		};

		class SOPHIS_FIT FastPnLTriggerActionAuto : public virtual FastPnLTriggerActionBase
		{
		public :
			DECLARATION_FASTPNL_TRIGGER_ACTION(FastPnLTriggerActionAuto)
				FastPnLTriggerActionAuto();
		};


		class SOPHIS_FIT FastPnLRestrictiveRuleYes : public virtual FastPnLRestrictiveRule
		{
		public :
			DECLARATION_FASTPNL_TRIGGER_RESTRICTION(FastPnLRestrictiveRuleYes)
				FastPnLRestrictiveRuleYes();
		};

		class SOPHIS_FIT FastPnLRestrictiveRuleNo : public virtual FastPnLRestrictiveRule
		{
		public :
			DECLARATION_FASTPNL_TRIGGER_RESTRICTION(FastPnLRestrictiveRuleNo)
				FastPnLRestrictiveRuleNo();
		};


		enum comparativeOperator
		{
			lessThan,
			lessOrEqualThan,
			equalTo,
			moreOrEqualThan,
			moreThan
		};

		class SOPHIS_FIT CSRForceFastCalculation
		{
		public :
			CSRForceFastCalculation();
			virtual ~CSRForceFastCalculation();
		};
		
		class SOPHIS_FIT FastPnlSourceKeysManager
		{
		public:
			static FastPnlSourceKeysManager* GetInstance() 
			{
				if (!fInstance) 
					fInstance = new FastPnlSourceKeysManager();
				
				return fInstance;
			}

			static void SetInstance(FastPnlSourceKeysManager* instance) 
			{
				if (fInstance)
					delete fInstance;
				fInstance = instance;
			}
			
			virtual FastPnlBufferAPI::FPBufferData* GetKeysBuffer(long instrumentCode, const FastPnlBufferAPI::FPBufferData& bufferElts) {return NULL;}

		protected:
			FastPnlSourceKeysManager(){}
			static FastPnlSourceKeysManager* fInstance;
		};

		class FastPnlVegaAndRhoFactory
		{
		public:
			virtual void Init(const sophis::instrument::CSRInstrument& titre){}
			virtual FPVega *CreateVega(long productCode, long udlCode,const FastPnlMarketData& md, const CSRFastPnlInterpolationGrid* grid, CSRFastPnlSensibilitiesCalculator* precalc = NULL){return NULL;}
			virtual FPRho *CreateRho(long productCode, long currency,const FastPnlMarketData& md,const CSRFastPnlInterpolationGrid* grid, CSRFastPnlSensibilitiesCalculator* precalc = NULL){return NULL;}
			virtual FPForwardEffect *CreateForwardEffect(long code, long udlCode,const FastPnlMarketData& md,const CSRFastPnlInterpolationGrid* grid, CSRFastPnlSensibilitiesCalculator* precalc = NULL){return NULL;}
			virtual FPCreditSensitivity* CreateCreditSensitivity(long instrumentCode, long creditCurveCode, const FastPnlMarketData& md,const CSRFastPnlInterpolationGrid* grid,CSRFastPnlSensibilitiesCalculator* precalc = NULL){return NULL;}
			virtual void CreateCreditSpreadEffect(long productCode, const FastPnlMarketData& md, _STL::vector<double>& outSpreads, CSRFastPnlSensibilitiesCalculator* precalc = NULL) {}
			virtual void RunPrecalc(const CSRFastPnlSensibilitiesCalculator* calc,const FastPnlMarketData& md) {}
		};

		/** Used for defining a cache view of the configurations defined in the "Fast Pnl Categories" dialog
		*/
		struct SOPHIS_FIT SSFPNLConfiguration
		{		
			SSFPNLConfiguration();
			~SSFPNLConfiguration();
			SSFPNLConfiguration& operator=(const SSFPNLConfiguration& other);
			SSFPNLConfiguration(const SSFPNLConfiguration& other);

			/// id of the configuration
			long fSubID;

			/// Category which the configuration applies to
			long fCategoryID;

			/// Name of the category
			char fCategoryName[SizeOfStringInDB];

			/// Instrument type (corresponds to the string choosen in the list)
			char fInstrType[SizeOfStringInDB];

			/// Instrument Feature 1 (corresponds to the string choosen in the list)
			char fInstrFeature1[SizeOfStringInDB];

			/// Instrument Feature 2 (corresponds to the string choosen in the list)
			char fInstrFeature2[SizeOfStringInDB];

			/// Market chosen for the configuration
			long fPnlMarket;

			/// Currency chosen for the configuration
			long fPnlCurrency;

			/// Pointer to the trigger prototype
			FastPnLTriggerBase* concernedTrigger;

			/// Pointer to the action prototype
			const FastPnLTriggerActionBase* concernedAction;

			/// Pointer to the restrictive rule prototype
			const FastPnLRestrictiveRule*  fRestrictiveRule;
		};

		/** Gives a map of all the defined configurations in the "Fast Pnl Categories" dialog
		*/
		SOPHIS_FIT const _STL::map<long, SSFPNLConfiguration>& GetDefinedPnlConfigurations();
			
		class SOPHIS_FIT FastPnlServerAPI	: public virtual sophis::FastPnl::FastPnlServer
		{
		protected :

			class FastPnLCategoryConfig
			{
			protected :
				static FastPnLCategoryConfig* fInstance;

			public :
				
				static const FastPnLCategoryConfig* GetInstance();

				static			void			SetInstance		(FastPnLCategoryConfig* fpnlcc);

				/**<ul><li> Browse the list of rules defined in Fast Pnl Categories, 
				<li>Controls that the instrument whose code was given as parameter matches the rule
				</ul>
				If it matches rule, adds pointer to the corresponding trigger in the to-return-vector
				\param code Instrument code
				\param configurationsIds [out] vector of configurations the instrument matches with
				\return True if instrument exists; false if it was not found
				*/
				bool GetMatchingConfigurations(long code, _STL::vector<long>& configurationsIds) const;

			};


			/// Gives a list of configurations; it is used for giving the categories matching with a given instrument
			class DependentProductsElt
			{
			public :

				DependentProductsElt() {};
				_STL::vector< long > fConfigurations;
			};

			class MatchingConfigurations
			{

			public :
				/// Associates instruments with list of configurations it matches with
				_STL::map<long, DependentProductsElt> fInstrumentToFastPnlConf;

				/** Adds the configurations dependency tree for the given instrument
				* \param codeProduct Product which we want to get the matching congigurations, and that we want to put in the dependency tree
				*/
				DependentProductsElt& ResolveMatchingConfiguration(long codeProduct);

				void RefreshAllMatchingConfiguration();


			protected:
				_STL::set<long> fEmptySet;
			};



			// Group of triggers added by user in the FastPnl Categories windows
			// this is made of references to the prototype of triggers
			// is to be filled with references while user adds triggers into the FastPnl categories window
			_STL::vector<sophis::FastPnl::FastPnLTriggerBase*> fActiveTriggers;

			/** All Dependency trees : associating products 
			with instruments, and instruments with the configurations they match with
			*/
			mutable MatchingConfigurations fDependents;


			static const char* __CLASS__;

		public :
			static FastPnlContext *fTriggerContext;
			static FastPnlVegaAndRhoFactory *fVegaAndRhoFactory;

			class SOPHIS_FIT CSRFastPnlCategoryNames
			{
			public:
				static CSRFastPnlCategoryNames& GetInstance();

				MenuHandle GetHandleMenu() const { return fMenuHandle; }
				long GetIdFromPosition(short position);
				short GetPositionFromId(long id);
				static void Clear();
				static void Add(long id_category, const char* catname);

			protected:
				static CSRFastPnlCategoryNames fInstance;			
				MenuHandle fMenuHandle;
				_STL::map<long,_STL::string> fCategoriesIdToName;
			};

			template <class X>
			class FastPnLCategoryConfigParametrization
			{
			public :
				static bool GetMatchingConfigurations(const X& instrument, _STL::vector< long >& catIds)
				{
					// let us browse all the triggers in the windows of fast pnl categories 
					//  for the given instrument
					catIds.clear();

					_STL::map<long, sophis::FastPnl::SSFPNLConfiguration>::const_iterator it= sophis::FastPnl::GetDefinedPnlConfigurations().begin();					

					while (it!=sophis::FastPnl::GetDefinedPnlConfigurations().end())
					{
						if (
							((it->second.fCategoryID == CSRPreference::GetFastPnlCategory())
							&&  sophis::finance::CSRProductType::GetPrototype().GetData(it->second.fInstrType)->BelongsTo(instrument))
							&& 	(sophis::finance::CSRProductFeature::GetPrototype().GetData(it->second.fInstrFeature1)->BelongsTo(instrument))
							&& 	(sophis::finance::CSRProductFeature::GetPrototype().GetData(it->second.fInstrFeature2)->BelongsTo(instrument))
							&&  ((it->second.fPnlCurrency==-1)||(instrument.GetCurrency()==it->second.fPnlCurrency))
							&& ((it->second.fPnlMarket==-1)||(instrument.GetMarketCode()==it->second.fPnlMarket))
							)
						{
							catIds.push_back(it->first);
						}

						it++;
					}

					return true;

				}




			};

			enum eCreateNewMarketDataAPIUsage
			{
				eCreateNewMarketDataAPIUsage_Reference,
				eCreateNewMarketDataAPIUsage_Interpolation
			};

			virtual FastPnlMarketData* CreateNewMarketData(const sophis::market_data::CSRMarketData& md,long productContext,eCreateNewMarketDataAPIUsage usage = eCreateNewMarketDataAPIUsage_Reference) const;
			virtual FPVega* ComputeVega(const sophis::instrument::CSRInstrument& product,long codeSJ) const;

			static FastPnlMarketData*	(*CreateNewMarketDataFct)(const sophis::market_data::CSRMarketData& md,long productContext,eCreateNewMarketDataAPIUsage usage);
			static FPVega*				(*ComputeVegaFct)(const sophis::instrument::CSRInstrument& product,long codeSJ);			
			static CSRFastPnlInterpolationGrid*	(*CheckAndGetSpecificGridFct)(long instrCode, long udl, eGridAnalysisType type);

			virtual bool IsSupportedInstrumentType(long code) const;

			/// Force recalculation (possibly on calc server) of the instrument & greeks
			virtual		void	Recompute(long sico, bool alreadyRecomputed, sophis::CSRComputationResults& results, const sophis::FastPnl::FastPnlBuffer & pnlb, const sophis::FastPnl::FastPnlMarketData& md, const _STL::vector<const sophis::FastPnl::FastPnLTrigger*>* triggers = NULL) const ;
			virtual		void	StoreTheoricalValue(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md, const sophis::CSRComputationResults& results) const;
			virtual		void	StoreDeltaGamma(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md, const sophis::CSRComputationResults& results) const;

			virtual		void	StoreVega(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;
			virtual		void	StoreRho(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md, const sophis::CSRComputationResults& results) const;
			virtual		void	StoreForwardEffect(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;
			virtual		void	StoreCreditEffect(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;
			virtual		void	StoreOtherGreeks(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;					

			/** Says whether a full computation will be done
			\param code Instrument sicovam for which user wants to check if a full computation will be done
			\param md Fast Market Data instance to use for calculation
			\param pnlb Fast PnL buffer to use to get or set greeks and old calculated values
			\return true if a full calculation is needed, else false
			*/
			virtual		bool	NeedFullRecompute(long code, bool arbitrage,const sophis::market_data::CSRMarketData& context, const FastPnlBuffer & pnlb, FastPnlContext* ctx = NULL) const;


			/** This function gives current rho for a given instrument
			\param code Instrument sicovam for which user wants to get the theorical value
			\param md Fast Market Data instance to use for calculation
			\param pnlb Fast PnL buffer to use to get greeks and old calculated values
			\return Theoretical of the instrument
			*/
			virtual			double			GetTheoretical	(long code, const FastPnlMarketData & md, const FastPnlBuffer & pnlb,FPCalculationAdjustment* outAdjust = NULL) const;


			virtual double UpdateInstrument(const sophis::market_data::CSRMarketData& param,sophis::instrument::CSRInstrument& toBeUpdated, sophis::CSRComputationResults& results) const;

			/** Tests the different triggers available, on all the underlyings of the instrument
			and says the type on calculation needed for this instrument 
			\param code Sicovam for an instrument which we want to check all the underlyings
			\return type of calculation to do, depending on the mode and reached triggers
			*/
			eLastCalcResult TesteTriggers(long code, const sophis::market_data::CSRMarketData* context,const FastPnlMarketData* fastcontext, const FastPnlBuffer & pnlb, _STL::vector<const sophis::FastPnl::FastPnLTrigger*>* reachedTriggers=NULL) const;

			void ResolveMatchingConfiguration(long codeProduct) const;
			void UpdateDependantConfigurations();

			/** This function gets all the fast Pnl Categories from database, and fills the 
			fDefinedPnlCategories map (containing all the categories, with priority as key, including
			pointer to the trigger prototypes).
			This map will be updated while user will update categories in the corresponding screen
			*/
			void Load();			

			bool NeedToLoad() const;

			enum eFastPnlPreference
			{
				eFPNLActivated, //from global pref. Can be overrident with .ini file
				eFPNLLoadEOD,   //from global pref. Can be overrident with .ini file
				eFPNLContribute
			};

			virtual bool IsActive() const;

			virtual void LogErrorMessage(const char* msg) const;

			virtual const _STL::vector<_STL::string>& GetLastErrorMessages() const;

			static bool GetFastPnlPreference(eFastPnlPreference pref);

			virtual void TryConnect() const;

			virtual long GetCurrentDate() const;

			typedef void (*InstrumentFullCalcNotify)(long sicovam);

			_STL::vector<InstrumentFullCalcNotify> OnInstrumentFullCalcNotify;

		protected:

			mutable _STL::vector<_STL::string> fErrMessages;


		private:
			DEPRECATED_SIGNATURE virtual		void	Recompute(long sico, bool alreadyRecomputed, const sophis::FastPnl::FastPnlBuffer & pnlb, const sophis::FastPnl::FastPnlMarketData& md, const _STL::vector<const sophis::FastPnl::FastPnLTrigger*>* triggers = NULL) const ;
			DEPRECATED_SIGNATURE virtual		void	StoreTheoricalValue(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;
			DEPRECATED_SIGNATURE virtual		void	StoreDeltaGamma(const sophis::instrument::CSRInstrument& instr,FastPnlBuffer::FPBufferData& elt, const sophis::FastPnl::FastPnlMarketData& md) const;
			DEPRECATED_SIGNATURE virtual double UpdateInstrument(const sophis::market_data::CSRMarketData& param,sophis::instrument::CSRInstrument& toBeUpdated) const;
		};
		
		class SOPHIS_FIT FastPnlContext
		{
		private:

			long fCode;

			eLastCalcResult fStatus;

			_STL::vector<const FastPnLTrigger*> fReachedTriggers;

			FastPnlBuffer::FPBufferData* fBufferData;

			bool fValidData;

		public:
			FastPnlContext(); 

			virtual ~FastPnlContext();
			

			void SetCode(long code);

			long GetCode();

			void SetStatus(eLastCalcResult status);

			eLastCalcResult GetStatus();

			void SetReachedTriggers(_STL::vector<const FastPnLTrigger*> rTrig);

			_STL::vector<const FastPnLTrigger*> GetReachedTriggers();

			void SetBufferData(const FastPnlBuffer::FPBufferData *buffData);

			bool GetBufferData(FastPnlBuffer::FPBufferData& buffData);
		};


		typedef void (*InitFPNLFct)();
		void SOPHIS_FIT AddInitFct(sophis::FastPnl::InitFPNLFct fct);
		bool SOPHIS_FIT FastPnL_Initialize();
		void SOPHIS_FIT ExecAllInitFct();
		
		

	}
}
SPH_EPILOG
#endif
