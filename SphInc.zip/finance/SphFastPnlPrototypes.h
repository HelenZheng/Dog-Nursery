#ifndef _SphFastPnlPrototypes_H_
#define _SphFastPnlPrototypes_H_

#include "SphTools/SphPrototype.h"
#include "SphInc/finance/SphFastPnlClient.h"
#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/finance/SphFastPnlEnums.h"
#include "SphInc/scenario/SphScenario.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_FAST_PNL_CALCULATOR(derivedClass)			DECLARATION_PROTOTYPE(derivedClass,CSRFastPnlSensibilitiesCalculator)
template  <class _Derivate>
struct installCalculator
{
	installCalculator(const typename _Derivate::prototype::key_type & k, sophis::FastPnl::eGridAnalysisType type)
	{
		_Derivate *clone = new _Derivate;
		_Derivate::GetPrototype(type).insert(k,clone);
	}
};

#define	INITIALISE_FAST_PNL_VEGA_CALCULATOR(derivedClass)	\
	installCalculator<derivedClass>(derivedClass().GetName(), eVegaAnalysis);

#define	INITIALISE_FAST_PNL_RHO_CALCULATOR(derivedClass)	\
	installCalculator<derivedClass>(derivedClass().GetName(), eRhoAnalysis);

#define	INITIALISE_FAST_PNL_FWD_CALCULATOR(derivedClass)	\
	installCalculator<derivedClass>(derivedClass().GetName(), eFwdAnalysis);

#define	INITIALISE_FAST_PNL_CREDIT_CALCULATOR(derivedClass)	\
	installCalculator<derivedClass>(derivedClass().GetName(), eCreditAnalysis);


SPH_PROLOG
namespace sophis
{
	namespace FastPnl
	{
		SOPHIS_PORTFOLIO void ActivateFastPnlOptimizations(eGridAnalysisType analysisType, bool optim);

		class SOPHIS_FIT CSRComputationGrid
		{
		public :
			CSRComputationGrid();

			virtual ~CSRComputationGrid();

			typedef sophis::tools::CSRPrototype<CSRComputationGrid, _STL::string> prototype;

			static prototype & GetPrototype	();

			virtual CSRComputationGrid * Clone() const = 0;

			virtual bool GetNewGrid(long code,
				eGridAnalysisType analysisType,
				long underlyingCode,
				_STL::vector<FPGridMaturity>& outMaturities,
				_STL::vector<double>& outStrikes,
				bool& strikesInPercent) const;

			virtual bool IsUserGrid() const;

			virtual const char* GetName() const = 0;
		protected :
			bool fIsUserGrid;
		};

		class SOPHIS_FIT CSRFastPnlSensibilitiesCalculator
		{
		public :
			CSRFastPnlSensibilitiesCalculator();

			virtual ~CSRFastPnlSensibilitiesCalculator();

			typedef sophis::tools::CSRPrototype<CSRFastPnlSensibilitiesCalculator, _STL::string> prototype;

			typedef prototype prototypes[eLastAnalysis];

			static prototype & GetPrototype(eGridAnalysisType type);

			virtual CSRFastPnlSensibilitiesCalculator * Clone() const = 0;

			virtual void GetMarketDataValues(long currency, const CSRFastPnlInterpolationGrid* grid, const FastPnlMarketData& md, _STL::vector<double>& data) const;

			virtual void Compute(long udlCode, sophis::portfolio::PSRExtraction extraction, const CSRFastPnlInterpolationGrid* grid, const FastPnlMarketData& mdArg, _STL::vector<double>& sensibilities, double coeff = 1.0) const;

			virtual const char* GetName() const = 0;

			virtual bool IsCompatibleWith(const char* gridName) const;

			virtual bool CalculatorProvidesRiskSources() const;

			virtual void PreCalculation(sophis::portfolio::PSRExtraction extraction , const FastPnlMarketData& mdArg) const;

			virtual void ExtractRiskSourcesFromPrecalculation(_STL::set<long>& outSources, long code = 0) const;

			virtual bool CalculatorProvidesAnalysisGrids() const;

			virtual sophis::FastPnl::CSRFastPnlInterpolationGrid* ExtractAnalysisGrid(long riskSource,const FastPnlMarketData& md) const;

		};

		class SOPHIS_FIT CSRFastPnlCreditSensibilitiesCalculator : public CSRFastPnlSensibilitiesCalculator
		{
		public :
			
			virtual void Compute(long curveCode, sophis::portfolio::PSRExtraction extraction, const CSRFastPnlInterpolationGrid* grid, const FastPnlMarketData& mdArg, _STL::vector<double>& rates, _STL::vector<double>& sensibilities, double coeff = 1.0) const;

			virtual void ComputeCreditSpread(long instrumentCode, sophis::portfolio::PSRExtraction extraction, const FastPnlMarketData& mdArg, _STL::vector<double>& spreads, double coeff = 1.0) const;

			virtual void ExtractRiskSourcesFromPrecalculation(_STL::set<long>& outSources, long code = 0) const;

			virtual void ExtractRiskSourcesFromPrecalculation(_STL::set<long>& outSources, bool& isUpfront, long code = 0) const;
		};
	}
}
SPH_EPILOG
#endif