/*
File:		SphForexOption.h

Contains:	Class for the handling of the "FX Option" model.

Copyright:	2008 Sophis.

*/

#ifndef _FOREX_OPTION_H_
#define _FOREX_OPTION_H_

#include "SphInc/instrument/SphClause.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/instrument/SphOption.h"

#include "SphInc/finance/SphDefaultMetaModelOption.h"

SPH_PROLOG

namespace sophis
{
	namespace finance
	{
		/** The options handled by the class CSRForexOption. This enum is linked to the property CSMOptionForexUserData::FXOptionType .
		@version 6.0.1
		 */
		enum eFXOptionType
		{
			Vanilla,
			Asian,
			Barrier,
			KnockIn,
			KnockOut,
			DoubleKnockIn,
			DoubleKnockOut,
			Digital,
			OneTouch,
			NoTouch,
			DoubleOneTouch,
			DoubleNoTouch,
			AverageStrike,
			AverageRate,
			DoubleAverage
		};

		/** Class that handles the options defined with the model 'FX Option'.
		@version 6.0.1
		 */

		class SOPHIS_FINANCE CSRDefaultMetaModelForexOption : public virtual CSRDefaultMetaModelOption
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelForexOption)
			virtual ~CSRDefaultMetaModelForexOption();
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};


		class SOPHIS_FINANCE CSRForexOption : public virtual sophis::instrument::CSROption
		{
		public :
			CSRForexOption(produit ** h, bool initialiseRecomputeAll = true);
		
		protected :	
			CSRForexOption();
			void Initialize(produit ** h, bool initialiseRecomputeAll = true);
		
		public :	

			static sophis::instrument::CSRInstrument* NewDeriveSophis(const void *x);
		
			enum eGreeks
			{
				Undefined = -1,
				// deltas
				Delta,
				DeltaForwardPartial,
				DeltaForwardTotal,
				DeltaSpotPartial,
				DeltaSpotTotal,
				DeltaPartialMinusPremium,
				DeltaTotalMinusPremium,
				DeltaDayForexPartial,
				DeltaDayForexTotal,
				// gammas
				Gamma,
				// Vegas
				Vega,
				VegaMarket,
				WeightedVega,
				WeightedVegaMarket,
				Volga,
				Vanna,
				// theta
				Theta,
				// rhos
				Rho,
				// crossed Greeks
				CrossedGamma,
				CrossedVega,
				Count
			};

			/** Structure that stores greeks and sorts them.
			@version 6.0.1
			 */
			struct SSFXOptionGreek
			{
				SSFXOptionGreek()
				{
					fValue = 0.;
					fPremiumCurrency = fUnderlying = fCrossUnderlying =0;
					fType = Undefined;
				}
				SSFXOptionGreek(eGreeks type, double value, long premiumCurrency = 0, long underlying = 0, long crossUnderlying = 0)
				{
					fType = type;
					fValue = value;
					fPremiumCurrency = premiumCurrency;
					fUnderlying = underlying;
					fCrossUnderlying = crossUnderlying;
				}
				operator double() { return fValue; }
				friend bool operator < (const SSFXOptionGreek& g1, const SSFXOptionGreek& g2)
				{
					if (g1.fType < g2.fType)
						return true;
					else if (g1.fType == g2.fType && g1.fUnderlying < g2.fUnderlying)
						return true;
					else
						return false;
				}

				eGreeks fType;
				double fValue;
				long fPremiumCurrency;
				long fUnderlying;
				long fCrossUnderlying;
			};
			

			virtual const sophis::finance::CSRAdditionalComputation* GetDefaultAdditionalComputation() const OVERRIDE;
			
			/** Returns true.
			@version 6.0.1
			 */
			virtual bool UseMetaModel() const;
			
			/** Method called to validate the instrument.
			@version 6.0.1
			 */
			virtual Boolean	ValidInstrument() const;
			
			/** Used for Digital options: returns false for digitals.
			@version 6.0.1
			 */
			virtual bool IsSecondNotional(_STL::string &caption) const;
			
			/** Returns "fxOption".
			@version 6.0.1
			 */
			virtual const char * GetXMLRootName() const;

			virtual double GetStrikeOffset() const;

			/** Initiliaze the premium currencies and clear the greeks container.
			@version 6.0.1
			 */
			void InitializeGreeks();
			
			/** Initiliaze the list of possible premium currencies: the instrument currency, the settlement currency, the strike currency, the foreign currency, the domestic currency.
			Then each of these currencies are put as the premium currency in the option and the corresponding greeks are stored in the map fGreeks during the recompute all of the instrument.
			@version 6.0.1
			 */
			void InitializePremiumCurrencies();

			/** Returns the FXOptionType stored in the CSMOptionForexUserData class. If there is no user data then the default value eFXOptionType::Vanilla is returned.
			@version 6.0.1
			 */
			eFXOptionType GetFXOptionType() const;

			/** Set the FXOptionType stored in the CSMOptionForexUserData class.
			@version 6.0.1
			 */
			void SetFXOptionType(eFXOptionType fxOptionType);
			
			/** Returns true if the instrument has a eDerivativeClauseType::dcDeparture clause.
			@version 6.0.1
			 */
			bool IsForwardStart() const;
			
			/** INTERNAL: returns the greeks by premium currency i.e. Key = premium currency, Value = list of greeks
			@version 6.0.1
			 */
			inline _STL::map<long, _STL::vector<SSFXOptionGreek> > & GetForexGreeks() {return fGreeks;};
			void FillGreeks(sophis::CSRComputationResults& results, const sophis::market_data::CSRMarketData & context);

			inline _STL::set<long> &	GetPremiumCurrencies() {return fPremiumCurrencies;};


			/**
			@version 6.0.1
			 */
			bool IsAverageOption() const;

			/** Get the settlement date.
			@param transactionDate is the transaction date in number of days from 1/1/1904.
			@return the settlement date in number of days from 1/1/1904.
			It is used to calculate the settlement date when purchasing the instrument,
			but also to determine the date for the validity of the fair value (see {@link GetTheoriticalValue}).
			In this way, if the preference is P&L with financing, the value of the option
			is discounted according to the date.
			By default, this method called the market to get the settlement date.
			If there is no market defined, the lag associated to the currency pair will be taken into account
			@see CSRMarket
			*/
			virtual long			GetSettlementDate(long transactionDate) const;

		protected:
		
			/** Methods used to validate the instrument
			@version 6.0.1
			 */
			bool ValidOneTouch() const;
			bool ValidNoTouch() const;
			bool ValidDoubleOneTouch() const;
			bool ValidDoubleNoTouch() const;
			bool ValidKnockIn() const;
			bool ValidKnockOut() const;
			bool ValidDoubleKnockIn() const;
			bool ValidDoubleKnockOut() const;
			bool ValidWindow(const sophis::instrument::SSClause& cl) const;
			bool ValidCrossDate(const sophis::instrument::SSClause& cl, _STL::string errorMessageToDisplay) const;
			bool ValidBarrierValue(const sophis::instrument::SSClause& cl, _STL::string errorMessageToDisplay) const;
			void DeclareError(_STL::string message) const;
			bool ValidDoubleBarriers(const sophis::instrument::SSClause& down, const sophis::instrument::SSClause& up, _STL::string errorMessageToDisplay) const;
			bool ValidAverageStrike() const;
			bool ValidAverageRate() const;
			bool ValidDoubleAverage() const;
			bool ValidAsian() const;

			/** When no meta model is found then these default meta models are used:
			- Vanilla and single barrier options: B&S
			- Multi-barrier options: Trinomial
			- Average options: New Monte Carlo
			- Digital quanto foreign currency options: FX Digital in CCY1 (B&S)
			Inherited from CSROption.
			@version 6.0.1
			 */
			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

		private:
			_STL::map<long, _STL::vector<SSFXOptionGreek> > fGreeks;
			_STL::set<long> fPremiumCurrencies;

			typedef CSROption base;

		public:
			bool IsBarrierType() const;
		};
	}
}

SPH_EPILOG
#endif