/*
File:		SphForexRiskManager.h

Contains:	Class for the handling/computing Forex delta and gamma on any coherent definition.

			Having N+1 currencies one can define N independent forex rate from which 
			every exchange rate can be computed. Currencies can be view as a graph vertexes
			and FX rate are graph edge. Any non cyclic graph is a coherent choice for FX risk.
			
			Graph is not oriented but we need to have a choice for the corresponding FX definition
			(e.g. for currencies A and B we can chose A/B or B/A).
		
Copyright:	2010 Sophis.

*/

#pragma once

#include "SphTools/SphCommon.h"
#include "SphInc/SphMath.h"

/**
	STL includes
*/
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		/**
		* Structure to store one forex A/B, e.g. number in currency B needed to buy one currency A.
		*/
		struct SSForexStructure
		{
			/**
			* The first currency A.
			*/
			long			firstCurrency;

			/**
			* The second currency B.
			*/
			long			secondCurrency;

			/**
			* True, if A/B is the market way, false otherwise.
			*/
			bool			marketWay;

			/**
			* Current forex value. Internally it is populated when making computation by the 
			* computation market data.	
			*/
			mutable double	forexValue;

			bool operator< (const SSForexStructure & rhs) const 
			{ 
				return ((firstCurrency<rhs.firstCurrency) || 
					(firstCurrency == rhs.firstCurrency && secondCurrency<rhs.secondCurrency));
			}
		};


		class SOPHIS_MATH CSRForexRiskSourceDefinitionInterface
		{
		public:

			/**
			*	Constructon.
			*/
			CSRForexRiskSourceDefinitionInterface();

			/**
			* Destructor.
			*/
			virtual ~CSRForexRiskSourceDefinitionInterface();


			/**
				Method to define new forex risk sources tree from the old one defined by foreign currencies
				versus a pivot currency.
			
				@param pivotCurrency
				is the pivot currency denoted P. 

				@param foreignCurrencyRiskSources
				is the foreign risk sources currencies denoted F_i with i in {1,...,N}.
				Corresponding forex risk sources are forex rates F_i/P.

				@param newForexRiskSourcestoFill
				New forex risk sources description. It is assumed that there is M+1 different currencies
				when there is M new forex risk sources. M is greater or equal to the number N of foreign currencies.
				Every foreign currencies an must appear in one of the new forex risk source.
			*/
			virtual bool FindNewForexRiskSources(	long							pivotCurrency,
													const _STL::vector<long>		&foreignCurrencyRiskSources,
													_STL::vector<SSForexStructure>	&newForexRiskSourcestoFill) const = 0;
		};

		/**
		* Structure to identify a FX component. When changing from a fx risk set to another
		* it allow to map how old component is computed from new ones and also which component
		* is impacted by a change in the new one. 
		*
		* As all currencies in the old set must be in the new one but we can have more additional currency 
		* in the new set, we can have more FX pair in the new set than  in  a old one.
		*/
		struct SSFXComponent 
		{
			/**
			* Constructor.
			*/
			SSFXComponent(	size_t	index,
							bool	reverseOrder)
				: fFxIndex(index), fReverseOrder(reverseOrder)
			{};

			/**
			*	Index in a vector identifying one component.
			*/
			size_t	fFxIndex;

			/**
			* True if the component
			*/
			bool	fReverseOrder;
		};

		/** Class handling change of forex risk sources.
		*	Technically this is just chain rule formulas with the specific case of forex for which 
		*	old forex are a product of new one: old_i = prod_j new_j^{P_j^i} with P_j^i in {-1, 0, 1}.
		*/
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_MATH CSRForexRiskManager
		{
		public:
			/**
			* Constructor
			*/
			CSRForexRiskManager();

			/**
			Initialize method 

			@param oldForexRiskSources
			Old forex risk sources description. It is assumed that there is N+1 different currencies
			when there is N forex rates.  

			@param newForexRiskSources
			Old forex risk sources description. It is assumed that there is M+1 different currencies
			when there is M forex rates.  

			@param pivotCurrency
			Optional parameter giving the central currency to use. It is relevant to minimize the components
			vector size.
			*/
			bool SetRiskSources(	const _STL::vector<SSForexStructure> &oldForexRiskSources,
									const _STL::vector<SSForexStructure> &newForexRiskSources,
									long	pivotCurrency = -1);

			/**
			* Destructor.
			*/
			virtual ~CSRForexRiskManager();

			/**
			* Method to retreive error message when one of the method {@link SetRiskSources} or {@link SetNewForexRiskSourcesValue}
			* failed.
			*/
			void GetErrorMessage(_STL::string &errorMessage);


			/**
			* Accessor on old forex risk sources.
			*/
			inline const _STL::vector<SSForexStructure> & GetOldForexRiskSources() const {return fOldForexRiskSources;};

			/**
			* Accessor on new forex risk sources.
			*/
			inline const _STL::vector<SSForexStructure> & GetNewForexRiskSources() const {return fNewForexRiskSources;};

			/** 
			*	Update new and old forex values.
			*/
			bool SetNewForexRiskSourcesValue(const _STL::vector<double>& newFxValues) const;

			/**
			* 
			*/
			static size_t GetGammaIndex(size_t i, size_t j);

			void ComputeNewDeltaFromOldOnes(const _STL::vector<double> &oldDelta, _STL::vector<double> &newDelta) const;
			void ComputeNewGreeksFromOldOnes(	const _STL::vector<double>	&oldDelta, 
												const _STL::vector<double>	&oldGamma,
												_STL::vector<double>		&newDelta, 
												_STL::vector<double>		&newGamma) const;

			double GetNewFirstDerivative(	size_t newFXIndex, const _STL::vector<double> &oldDelta) const;
			double GetNewSecondDerivative(	size_t newFXIndex1, 
											size_t newFXIndex2, 
											const _STL::vector<double> &oldDelta,
											const _STL::vector<double> &oldGamma) const;


			inline const _STL::vector< _STL::vector< SSFXComponent> >	&GetOldForexRiskSourcesFromNewOnes() const {return 	fOldForexRiskSourcesFromNewOnes;};
			
			inline const _STL::vector< _STL::vector< SSFXComponent> >	&GetNewFXRiskSourceImpactArea() const {return fNewFXRiskSourceImpactArea;};


			//inline long GetPivotCurrency() {return fPivotCurrency;};

		protected:
			//long fPivotCurrency;
			_STL::vector<SSForexStructure> fOldForexRiskSources;// size N
			_STL::vector<SSForexStructure> fNewForexRiskSources;// size M

			_STL::vector< _STL::vector< SSFXComponent> >	fOldForexRiskSourcesFromNewOnes;//  give how to compute old from new
			_STL::vector< _STL::vector< SSFXComponent > >	fNewFXRiskSourceImpactArea;// for a new it just give which old are impacted and with reverseOrder giving  

			mutable bool fIsValid;
			mutable _STL::string fErrorMessage;
		};
		SPH_END_NOWARN_EXPORT

		class SOPHIS_MATH CSRFXCodeManager
		{
		public:

			CSRFXCodeManager();
			virtual ~CSRFXCodeManager();

			virtual  long GetForexCode(long currency1, long currency2 , bool & marketWay, long & reverseCode) const = 0;

			virtual bool IsACurrency(long code) const = 0;

			virtual bool IsAForexCode(long code, long & currency1, long & currency2, bool & marketWay) const = 0;
		};

		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_MATH CSRFXDataManager
		{
		public:

			CSRFXDataManager(const CSRFXCodeManager & codeManager);
			virtual ~CSRFXDataManager();

			void Reset();
			// dayforex are relatice to an implicit pivot currency with dayforex=1
			// this is the number of currency unit for one pivot currency unit
			void SetDayForex(long currency, double dayforex);

			// this is the number of currency2 unit for one unit of currency1
			double GetDayForex(long currency1,long currency2) const;

			bool IsRegisteredCurrency(long currency, double & dayFX) const;
			bool IsRegisteredForex(long fxCode, SSForexStructure & fxStructure) const;

			void FillCurrencyVector(_STL::vector<long> & currencyVector) const;
			bool SetDayForexValues(const _STL::vector<double> & dayFXVector);

			long GetForexCode(long currency1,long currency2) const;


			double AddNewCurrency(long newCurrency) const;

		protected:
			const CSRFXCodeManager * fForexCodeManager;
			mutable _STL::map<long, double> fDayForex;

			mutable _STL::map<long, SSForexStructure> fForexStructure;

			mutable _STL::map<SSForexStructure, long> fFXCode;
		};
		SPH_END_NOWARN_EXPORT

		/**
		* Interface Handling computation results
		*/
		class SOPHIS_MATH CSRComputationResult
		{
		public :
			CSRComputationResult();
			virtual ~CSRComputationResult();

			/**
			* Result are expressed in currency which can have a base currency
			*/
			virtual long	GetCurrency() const = 0;
			virtual long	GetBaseCurrency() const = 0;

			// return the change factor to apply to price and so on all greeks not depending on forex
			virtual double GetChangeFactor() const {return 1.0;};

			/**
			* Value in currency of one unit of base currency
			*/
			virtual double	GetConstantForex() const = 0;
			
			virtual int		GetUnderlyingCount() const =0;
			
			virtual long	GetUnderlying(int which) const =0;
			virtual bool	IsAVegaUnderlying(int whichUnderlying) const	= 0;
			virtual bool	IsADeltaUnderlying(int whichUnderlying) const	= 0;

			virtual bool IsAnUnderlying(long codeTitre, int *which) const = 0;

			virtual int		GetRhoCount() const =0;
			virtual long	GetRhoCurrency(int which) const =0;

			virtual bool	IsARhoCurrency(long currency, int *which) const = 0;

			virtual	double	GetQuotity(bool withTaxes=false) const =0;
			
			virtual double	GetTheoreticalValue() const =0;
			virtual double	GetManagementTheoreticalValue() const =0;

			virtual double	GetFirstDerivative(int which) const =0;
			virtual double	GetEpsilon(int which) const =0;
			virtual double	GetSecondDerivative(int which1,int which2) const =0;

			virtual double	GetRho(int which) const =0;
			virtual double	GetConvexity(int which) const =0;

			virtual double	GetCrossedDeltaRho(int whichSousJacent, int laquelleDevise) const =0;

			virtual double	GetVega(int which) const =0;
			virtual double	GetCrossedVega(int which1, int which2) const =0;

			virtual double	GetTheta() const =0;

			virtual double	GetCreditRiskConvexity() const =0;
			virtual double	GetCreditRiskSensitivity() const =0;
			
			virtual int		GetInflationSourcesCount() const = 0;
			virtual long	GetNthInflationSources(int which) const = 0;

			virtual double	GetRecoveryRateSensitivity() const = 0;
			virtual double	GetYTMSensitivity() const = 0;
			virtual double	GetInflationConvexity(int which1, int which2) const = 0;
			virtual double	GetInflationSensitivity(int which) const = 0;
			virtual double	GetInflationVega(int which) const = 0;

			// Overloaded function for Calculation Server compatibility.

			virtual double	GetFirstDerivativeUndiscounted(int whichUnderlying) const = 0;
			virtual	double	GetEquityGlobalDeltaUndiscounted() const = 0;
			virtual	double	GetDeltaPnL(int whichUnd) const = 0;
			virtual double	GetVegaMarket(int which1) const = 0;

			virtual double	GetVanna(int which) const = 0;
			virtual double	GetVolga(int which) const = 0;


		protected:
			
		};


		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_MATH CSRComputationResultInOtherCurrency : public CSRComputationResult
		{
		public :
			CSRComputationResultInOtherCurrency();
			virtual ~CSRComputationResultInOtherCurrency();

			void	Initialize(	long	newCurrency,
								long	newBaseCurrency,
								const	CSRComputationResult *resultInOldCurrency,
								long	oldBaseCurrency,
								double	newCurrencyFactor,
								double	oldCurrencyFactor,
								const	CSRFXDataManager & fxDataManager);

			/**
			* Result are expressed in currency which can have a base currency
			*/
			virtual long	GetCurrency() const;
			virtual long	GetBaseCurrency() const;

			virtual double GetChangeFactor() const;

			/**
			* Value in currency of one unit of base currency
			*/
			virtual double	GetConstantForex() const;
			
			virtual int		GetUnderlyingCount() const;
			
			virtual long	GetUnderlying(int which) const;
			virtual bool	IsAVegaUnderlying(int whichUnderlying) const;
			virtual bool	IsADeltaUnderlying(int whichUnderlying) const;

			virtual bool IsAnUnderlying(long codeTitre, int *which) const;

			virtual int		GetRhoCount() const;
			virtual long	GetRhoCurrency(int which) const;

			virtual bool	IsARhoCurrency(long currency, int *which) const;

			virtual	double	GetQuotity(bool withTaxes=false) const;
			
			virtual double	GetTheoreticalValue() const;
			virtual double	GetManagementTheoreticalValue() const;

			virtual double	GetFirstDerivative(int which) const;
			virtual double	GetEpsilon(int which) const;
			virtual double	GetSecondDerivative(int which1,int which2) const;

			virtual double	GetRho(int which) const;
			virtual double	GetConvexity(int which) const;

			virtual double	GetCrossedDeltaRho(int whichSousJacent, int laquelleDevise) const;

			virtual double	GetVega(int which) const;
			virtual double	GetCrossedVega(int which1, int which2) const;

			virtual double	GetTheta() const;

			virtual double	GetCreditRiskConvexity() const;
			virtual double	GetCreditRiskSensitivity() const;
			
			virtual int		GetInflationSourcesCount() const;
			virtual long	GetNthInflationSources(int which) const;

			virtual double	GetRecoveryRateSensitivity() const;
			virtual double	GetYTMSensitivity() const;
			virtual double	GetInflationConvexity(int which1, int which2) const;
			virtual double	GetInflationSensitivity(int which) const;
			virtual double	GetInflationVega(int which) const;

			// Overloaded function for Calculation Server compatibility.

			virtual double	GetFirstDerivativeUndiscounted(int whichUnderlying) const;
			virtual	double	GetEquityGlobalDeltaUndiscounted() const;
			virtual	double	GetDeltaPnL(int whichUnd) const;
			virtual double	GetVegaMarket(int which1) const;

			virtual double	GetVanna(int which) const;
			virtual double	GetVolga(int which) const;


		protected:

			const CSRComputationResult	*fResultInOldCurrency;
			const	CSRFXDataManager	*fFXDataManager;

			long	fCodeChange;
			
			long	fNewCurrency;
			long	fNewBaseCurrency;

			double	fNewCurrencyFactor;
			
			long	fOldBaseCurrency;

			long	fDevisePrimaire;
			double	fCoefficient;
			double	fOldCurrencyFactor;

			/** Structure of underlyings modified due to change of observator.
			@since 5.2
			*/
			struct	underlyings
			{
				/** Underlying code. */
				long	fCode;

				/** Underlying position for delta in fInstrument; -1 for no delta. */
				int		fPosDelta;
				
				/** Underlying position for vega in fInstrument; -1 for no vega. */
				int		fPosVega;

				/** Underlying corresponding to the  currency (i.e USD)*/
				bool	fIsOldResultCurrency;

				/** Underlyings is a currency : only if ZAR not for THB/ZAR	*/
				bool	fCurrency;	
			};

			typedef _STL::vector <underlyings> underlyings_vect;
			underlyings_vect	fUnderlyings;
			
		};


		class SOPHIS_MATH CSRComputationResultForexRisk : public CSRComputationResult
		{
		public :
			CSRComputationResultForexRisk();
			virtual ~CSRComputationResultForexRisk();

			bool SetComputationResult(	CSRComputationResult						*wrappedCR, 
										const CSRFXDataManager						*fcDataManager,
										const CSRForexRiskSourceDefinitionInterface	*fxrsDef);

			void RecomputeForexValue();

			virtual double GetChangeFactor() const;

			/**
			* Result are expressed in currency which can have a base currency
			*/
			virtual long	GetCurrency() const;
			virtual long	GetBaseCurrency() const;

			/**
			* Value in currency of one unit of base currency
			*/
			virtual double	GetConstantForex() const;

			virtual int		GetUnderlyingCount() const;
			
			virtual long	GetUnderlying(int which) const;
			virtual bool	IsAVegaUnderlying(int whichUnderlying) const;
			virtual bool	IsADeltaUnderlying(int whichUnderlying) const;

			virtual bool IsAnUnderlying(long codeTitre, int *which) const;

			virtual int		GetRhoCount() const;
			virtual long	GetRhoCurrency(int which) const;

			virtual bool	IsARhoCurrency(long currency, int *which) const;

			virtual	double	GetQuotity(bool withTaxes=false) const;
			
			virtual double	GetTheoreticalValue() const;
			virtual double	GetManagementTheoreticalValue() const;

			virtual double	GetFirstDerivative(int which) const;
			virtual double	GetEpsilon(int which) const;
			virtual double	GetSecondDerivative(int which1,int which2) const;

			virtual double	GetRho(int which) const;
			virtual double	GetConvexity(int which) const;

			virtual double	GetCrossedDeltaRho(int whichSousJacent, int laquelleDevise) const;

			virtual double	GetVega(int which) const;
			virtual double	GetCrossedVega(int which1, int which2) const;

			virtual double	GetTheta() const;

			virtual double	GetCreditRiskConvexity() const;
			virtual double	GetCreditRiskSensitivity() const;
			
			virtual int		GetInflationSourcesCount() const;
			virtual long	GetNthInflationSources(int which) const;

			virtual double	GetRecoveryRateSensitivity() const;
			virtual double	GetYTMSensitivity() const;
			virtual double	GetInflationConvexity(int which1, int which2) const;
			virtual double	GetInflationSensitivity(int which) const;
			virtual double	GetInflationVega(int which) const;

			// Overloaded function for Calculation Server compatibility.

			virtual double	GetFirstDerivativeUndiscounted(int whichUnderlying) const;
			virtual	double	GetEquityGlobalDeltaUndiscounted() const;
			virtual	double	GetDeltaPnL(int whichUnd) const;
			virtual double	GetVegaMarket(int which1) const;

			virtual double	GetVanna(int which) const;
			virtual double	GetVolga(int which) const;

			int GetVegaIndexInWrappedInstrument(int which) const;

		protected:

			CSRComputationResult		*fWrappedComputationResult;

			const	CSRFXDataManager	*fFXDataManager;

			sophis::finance::CSRForexRiskManager fForexRiskManager;

			struct SOPHIS_MATH SSRiskSourceMapper 
			{
				SSRiskSourceMapper ()
				{
					code = 0;
					indexInWrappedInstrument = vegaIndex = -1;
					reverseWay = false;
				}

				long	code;
				int		indexInWrappedInstrument;
				int		vegaIndex;
				bool	reverseWay;
			};

			// fx delta in original instrument
			_STL::vector<SSRiskSourceMapper>		fForeignCurrencyRiskSourcesInWrappedInstrument;

			// other delta/vega in original instrument
			_STL::vector<SSRiskSourceMapper>		fOtherRiskSourcesInWrappedInstrument;

			// new FX delta structure
			_STL::vector<sophis::finance::SSForexStructure>		fNewForexRiskSources;
			_STL::vector<double> fNewForexValue;

			// fx vega which can be handled by new fx risk sources
			_STL::vector<SSRiskSourceMapper>		fNewForexRiskSourcesOldvega;

			// old fx vega which can not be handled by new fx risk sources
			_STL::vector<SSRiskSourceMapper>		fRemainingOldFXVega;// index in fForeignCurrencyRiskSourcesInWrappedInstrument

		};
		SPH_END_NOWARN_EXPORT


	}// end of finance
}// end of math

SPH_EPILOG
