#pragma once

#include "SphTools/SphCommon.h"
#include "SphInc/SphMath.h"
#include "SphInc/finance/SphForexRiskManager.h"
#include "SphTools/SphArchive.h"
#include "SphTools/SphExceptions.h"

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_MATH CSRForexRiskSourceDefinitionDeserializable : public CSRForexRiskSourceDefinitionInterface
		{
		public:

			CSRForexRiskSourceDefinitionDeserializable();

			/*
			 * Can throw sophisTools::ExceptionBase inherited classes :
			 */
			virtual void Deserialize(const sophis::tools::CSRArchive& data);

			/**
			* Destructor.
			*/
			virtual ~CSRForexRiskSourceDefinitionDeserializable();


			virtual bool FindNewForexRiskSources(	long							pivotCurrency,
													const _STL::vector<long>		&foreignCurrencyRiskSources,
													_STL::vector<SSForexStructure>	&newForexRiskSourcestoFill) const;

			virtual long GetDefaultCurrency() const;

			static const CSRForexRiskSourceDefinitionDeserializable & InitInstance(const sophis::tools::CSRArchive& data);

			static const CSRForexRiskSourceDefinitionDeserializable & GetInstance();

			const CSRForexRiskManager* CSRForexRiskSourceDefinitionDeserializable::GetForexRiskManager(long pivotCurrency) const;

		protected:
			_STL::map< long,_STL::vector<SSForexStructure> > fRawDeserializedData;
			long fDefault;

			mutable _STL::map<long , CSRForexRiskManager> fForexRiskManagerMap;
		};
		
		class SOPHIS_MATH CSRFXCodeManagerDeserializable : public CSRFXCodeManager
		{
		public:

			CSRFXCodeManagerDeserializable();
			virtual ~CSRFXCodeManagerDeserializable();

			virtual  long GetForexCode(long currency1, long currency2 , bool & marketWay, long & reverseCode) const;
			virtual bool IsACurrency(long code) const;
			virtual bool IsAForexCode(long code, long & currency1, long & currency2, bool & marketWay) const;

			virtual void Deserialize(const sophis::tools::CSRArchive& data);

			virtual void FillCurrencyVector(_STL::vector<long> & currencyVector) const;

			static const CSRFXCodeManagerDeserializable& InitInstance(const sophis::tools::CSRArchive& data);
			static const CSRFXCodeManagerDeserializable& GetInstance();
		protected:

			struct SSForexcodeInfo
			{
				long code1;
				long code2;
				bool invert;
				long code;
				long codeinvert;
			};

			virtual void Deserialize(const sophis::tools::CSRArchive& data,SSForexcodeInfo& out) const;

			_STL::vector<SSForexcodeInfo> fInternalData;
		};
		SPH_END_NOWARN_EXPORT

		struct SOPHIS_MATH SSPNLEffect
		{
			long currency1, currency2; // risk source is currency1/currency2
			double effect;

			static void FillLastPNLEffect( double	lastPNL, 
										   long		pnlCurrency,  
										   const	CSRFXDataManager& fxDataOnLastDate, 
										   const	CSRFXDataManager& currentfxData,
										   _STL::vector<SSPNLEffect>& fxPNLEffect);
		};


	}// end of finance
}// end of math

SPH_EPILOG