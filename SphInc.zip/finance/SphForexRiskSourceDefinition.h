/*
File:		SphForexRiskSourceDefinition.h

Contains:	Class for the handling/computing Forex delta and gamma on any coherent definition.

Copyright:	2010 Sophis.

*/

#pragma once

#include "SphTools/SphCommon.h"
#include "SphInc/finance/SphForexRiskManager.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"

// Macro declaration for forex risk sources selector
#define DECLARATION_FOREXRISKSOURCEDEFINITION(className) \
	public: static _STL::string	className::sRegistrationName;	\
	public: virtual const _STL::string	& GetName() const	{return className::sRegistrationName;}; \
	DECLARATION_PROTOTYPE(className, sophis::finance::CSRForexRiskSourceDefinition) 

// Macro to define forex risk sources selector identifier. Must be used in 
#define INITIALISE_FOREXRISKSOURCEDEFINITION_NAME(className, name) _STL::string className::sRegistrationName = name;

// Macro instantiation for forex risk sources selector, fxRiskSelectionIdent is unique identifier in enum CSRForexRiskSourceDefinition::eFXRiskSelection
#define INITIALISE_FOREXRISKSOURCEDEFINITION(className,  fxRiskSelectionIdent) INITIALISE_PROTOTYPE(className,  CSRForexRiskSourceDefinition::eFXRiskSelection(className::fxRiskSelectionIdent))


SPH_PROLOG
namespace sophis
{
	namespace finance
	{

		
		/**
		* Class to handle forex risk sources definition.
		* Can be overloaded to change portfolio forex greeks aggregation.
		*
		* @see sophis::finance::SSForexStructure 
		*/
		class SOPHIS_FINANCE CSRForexRiskSourceDefinition : public CSRForexRiskSourceDefinitionInterface
		{
		public:

			enum eFXRiskSelection
			{
				eStandard		= 0,
				eMasterCurrency = 1,
				eLiquidMasterCurrency = 2,
				eLastForSophis	= 100
			};

			/**
			*	Constructon.
			*/
			CSRForexRiskSourceDefinition();

			/**
			* Destructor.
			*/
			virtual ~CSRForexRiskSourceDefinition();

			/**Give the Object identifier. Used for prototype construction of the object, don't implement this method in any child class,
			*	this is done by using DECLARATION_FOREXRISKSOURCEDEFINITION macro.
			*
			@return A Object string identifier.
			*/
			virtual const _STL::string	& GetName() const = 0;


			/**
			* Accessor to the currently Forex risk sources aggregation set up in Forex preferences.
			*/
			static const CSRForexRiskSourceDefinition* CSRForexRiskSourceDefinition::GetCurrentForexRiskSourceDefinition();


			/**
				Method to define new forex risk sources tree from the old one defined by foreign currencies
				versus a pivot currency.
			
				@param pivotCurrency
				is the pivot currency denoted P. 

				@param foreignCurrencyRiskSources
				is the foreign risk sources currencies denoted F_i with i in {1,...,N}.
				Corresponding forex risk sources are forex rates F_i/P.

				@param newForexRiskSourcestoFill
				New forex risk sources description. It is assumed that there is M+1 different currencies
				when there is M new forex risk sources. M is greater or equal to the number N of foreign currencies.
				Every foreign currencies an must appear in one of the new forex risk source.
			*/
			virtual bool FindNewForexRiskSources(	long							pivotCurrency,
													const _STL::vector<long>		&foreignCurrencyRiskSources,
													_STL::vector<SSForexStructure>	&newForexRiskSourcestoFill) const = 0;



			/**
			*	Structure identifying a new forex risk source and
			*	the derivative of the old forex risk source versus the new one.
			*/
			struct SSDerivative
			{
				/** New forex risk source code.
				*/
				long	code;

				/** New forex risk source currency code.
				*/
				long	currencyCode;

				/** Derivative of old forex versus new risk source.
				*/
				double	dOldVersusdNew;
			};

			/** 
				Give new risk sources needed to retrieve an old one, and compute derivatives of old forex versus the new risk sources.

				@param currencyRisk
				is the foreign risk source F defining the old forex risk source F/P.

				@param pivotCurrency
				is the pivot currency denoted P. 

				@param derivativeToFill
				is the output new forex risk sources vector, and corresponding derivatives of old forex F/P 
				versus the new risk source.

				@param param
				Optional market data needed to retrieve current forex spots. Default behavior is to use application market data.
			*/
			static void SplitOneOldForex(	long currencyRisk, 
											long pivotCurrency,
											_STL::vector<SSDerivative>& derivativeToFill,
											const market_data::CSRMarketData* param = NULL);

			

		
			/** Clone for this object. Used for prototype construction of the object, don't implement this method in any child class,
			*	this is done by using INITIALISE_FOREXRISKSOURCEDEFINITION macro.
			*
			@return A pointer on the clone created by the method.
			*/
			virtual CSRForexRiskSourceDefinition* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRForexRiskSourceDefinition for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRForexRiskSourceDefinition, short> prototype;
			static	prototype&	GetPrototype();
		};


		class SOPHIS_FINANCE CSRBumpForexAccordingToDefinition
		{
		public:
			CSRBumpForexAccordingToDefinition(	const  scenario::CSRMarketDataOverloader& paramWithBump,
												long	pivotCurrency,
												long	firstCurrency,
												long	secondCurrency, 
												double	bumpedValue);

			double GetForex(long currency);

			void ResetForexValue();

			inline long GetFirstCurrency() const {return fFirstCurrency;};
			inline long GetSecondCurrency() const {return fSecondCurrency;};

		protected:
			bool UpdateManager();

			bool fIsValidBumpInTree;
			const  scenario::CSRMarketDataOverloader * fParamWithBump;
			long	fPivotCurrency;
			double	fBumpedValue, fNotBumpedValue, fNotBumpedPivot;
			long	fFirstCurrency;
			long	fSecondCurrency;
			mutable _STL::set<long> fForeignCurrency;
			mutable CSRForexRiskManager fForexRiskManager;
		};

	}// end of finance
}// end of sophis

SPH_EPILOG