/*
 	File:		SphHybridTwoFactor.h

 	Contains:	An hybrid two-factor asset/rate model
				The asset is lognormal, and the rate follows a Ho & Lee process

 	Copyright:	� 1997-2002 Sophis.

*/

/*! \file SphHybridTwoFactor.h
	\brief Hybrid two-factor asset/rate model.
*/

#ifndef	_SphHybridTwoFactor_H_
#define	_SphHybridTwoFactor_H_


#include "SphInc/instrument/SphOption.h"

#include "SphInc/finance/SphDefaultMetaModelOption.h"
//#include "SphInc/instrument/SphInstrumentCompatibility.h"


SPH_PROLOG

DEPRECATED_RESULTS struct SSRateVol	{
	//double RateVega;
	//double RateCrossedVega;
};

// --------------------------
// 1. The computation classes
// --------------------------

namespace sophis
{
	namespace finance
	{

class CBPricer;

class SOPHIS_FINANCE CSRHybridTwoFactor
{
public:
	CSRHybridTwoFactor(const CBPricer *option, const  market_data::CSRMarketData*  market_data);
	virtual ~CSRHybridTwoFactor();

	// the pricing function
	virtual double	GetValue(double *delta=0, double *gamma=0);

	// initialization and calibration
	virtual void	DefaultValue();
	virtual void	ConstruireProduit();
	virtual void	ConstruireProbaTaux();
	virtual void	ConstruireProbaAction();
	virtual void	ConstruireDividendes();
	virtual void	TauxParametre(int nb, double* zero,	double vol,	double dt, double* F)  const;

	Boolean GetCurrentClausePaiement(double dateCalcul, sophis::instrument::CSRPayOffClause** clause) const;
	Boolean	GetCurrentClauseIntervention(double dateCalcul, sophis::instrument::CSRCoxTreeCustomisationClause** clause) const;


	//optimisation de l'arbre en tronquant les queues de distribution
	virtual	int GetBorneLowRate	()	const;
	virtual	int GetBorneHighRate()	const;
	double		GetHoLeeVol()		const;

public:
	bool	fConstruireProbaTaux;
	bool	fConstruireProduit;
	bool	fConstruireProbaAction;
	bool	fConstruireDividendes;

protected:
	const CBPricer		*fOption;
	const  market_data::CSRMarketData	*fMarketData;
	int		fNbPoints;
	int		fI;
	long	fDebut;
	long	fDF;
	long	fDateFinRemb;

	bool	fDefaultValue;
	bool	fProduitUser;
	bool	fInterventionUser;

	double	fNominal;
	double	fVolatiliteSsJacent;
	double	fCorrelation;
	double	fDt;
	double	fDivPresValue;
	double	fDivPresValueTrigger;
	double	fVolatiliteTaux;

	double *fCallsPayBack;
	double *fCallsTrigger;

	double *fPutPayBack;
	double *fPutTrigger;

	double *fExProportion;
	double *fExParite;
	double *fExStrike;

	double *fCouponAcc;
	double *fCoupon;
	double *fDivMult;
	double *fDivAdd;
	double *fDivMultTrigger;
	double *fDivAddTrigger;

	double *fF;
	double **fPROBA;

	sophis::instrument::CSRPayOffClause**	fPayOffClause;
	int										fPayOffClauseCount;
	sophis::instrument::CSRCoxTreeCustomisationClause** fCoxTreeCustomisationClause;
	int										fCoxTreeCustomisationClauseCount;

	friend class CBPricer;
	friend class CSRDefaultMetaModelCBPricer;
};

// -----------------------------------
// 2. The pricer for convertible bonds
// -----------------------------------

class SOPHIS_FINANCE CSRDefaultMetaModelCBPricer : public virtual CSRDefaultMetaModelOption
{
public:
	DECLARATION_META_MODEL(CSRDefaultMetaModelCBPricer);
	virtual ~CSRDefaultMetaModelCBPricer();

	virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

	virtual double	GetTheoreticalValue(const instrument::CSRInstrument& instr, const  market_data::CSRMarketData & param) const OVERRIDE;
	virtual void	GetPriceDeltaGamma(const instrument::CSRInstrument& instr, const  market_data::CSRMarketData & param,double *price,double *delta, double *gamma,int which) const OVERRIDE;
	virtual double	GetVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which) const OVERRIDE;
	virtual double	GetCrossedVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,int which1, int which2) const OVERRIDE;
	virtual void	ComputeCreditRiskSensitivities(	const instrument::CSRInstrument		&instr,
													const market_data::CSRMarketData	&context,
													const sophis::CSRComputationResults	&results,
													double 								refPrice,
													double 								&sensitivity,
													double 								&convexity,
													bool								computeCrossedGammas,
													bool								computeAllCreditDeltaGamma = true) const OVERRIDE;
	virtual double GetImpliedVolatility(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData & param, const sophis::CSRComputationResults& results, double premium, double accuracy = NOTDEFINED) const OVERRIDE;
	virtual double GetImpliedCreditSpread(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& context, double premium, double accuracy) const OVERRIDE;
protected:
	virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
};

class SOPHIS_FINANCE CBPricer : public virtual sophis::instrument::CSROption
{
public :
	DECLARATION_OPTION(CBPricer)
	virtual	~CBPricer();
	virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

	virtual Boolean ValidInstrument() const;
	//virtual int		GetUnderlyingCount() const;
	//virtual long	GetUnderlying(int which) const;

	// two hedging parameters that are specific to hybrid products
	virtual double  GetRateVega(const  market_data::CSRMarketData& param) const;
	virtual double  GetRateCrossedVega(const  market_data::CSRMarketData& param) const;

	double			GetDefaultCorrelation() const;
	double			GetDefaultVol() const;
	long			GetCodeTaux(const  market_data::CSRMarketData& param) const;


	virtual void	ComputeCreditRiskSensitivities( const market_data::CSRMarketData	&context,
													const CSRComputationResults			&results,
													CSRHybridTwoFactor					*tree,
													double								basicPrice,
													NSREnums::eVolatilityType			vol_type,
													double								&sensitivity,
													double								&convexity,
													bool								computeCrossedGammas,
													bool								computeAllCreditDeltaGamma = true) const;

//protected:
	virtual CSRHybridTwoFactor* new_CSRHybridTwoFactor(const  market_data::CSRMarketData* param) const;

private:
	DEPRECATED_RESULTS virtual double  GetRateVega() const;
	DEPRECATED_RESULTS virtual double  GetRateCrossedVega() const;

	//DEPRECATED_RESULTS SSRateVol	fRateVol;
};

}	//	namespace finance

}	//	namespace sophis

SPH_EPILOG

#endif _SphHybridTwoFactor_H_
