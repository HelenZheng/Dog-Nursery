/*
 	File:		SphInterpolation.h

 	Contains:	Class which allows you to define an interpolation method.

 	Copyright:	� 1995-1997 Sophis.
*/

/*! \file SphInterpolation.h
	\brief Defining an interpolation method.
*/

#ifndef _SphInterpolation_H_
#define _SphInterpolation_H_

#ifndef _SphMacros_H_
#include "SphInc/SphMacros.h"
#endif


struct TInfosPrecalc ;	// internal

#define DECLARATION_INTERPOLATION(derivedClass)				DECLARATION_DERIVE_AVEC_PARAM(derivedClass, TInfosPrecalc)
#define CONSTRUCTOR_INTERPOLATION(derivedClass, parent)		CONSTRUCTEUR_DERIVE_AVEC_PARAM(derivedClass, parent, TInfosPrecalc)
#define WITHOUT_CONSTRUCTOR_INTERPOLATION(derivedClass)		SANS_CONSTRUCTEUR_DERIVE_AVEC_PARAM(derivedClass, TInfosPrecalc)
#define	INITIALISE_INTERPOLATION(derivedClass, name)		INITIALISE_DERIVE_AVEC_PARAM(derivedClass, sophis::finance::CSRInterpolation, name)
#define	DISABLE_INTERPOLATION(item)							DISABLE_DERIVE(sophis::finance::CSRInterpolation, item)

SPH_PROLOG
namespace sophis	{
	namespace instrument {
		class	CSROption;
		struct	SSPrecalculation;
	}

	namespace market_data {
		class CSRMarketData;
	}

	namespace finance	{

		/** Class for interpolating the night calculations.
		It explains
		- How to get the spot, volatility, rate whith the grid defined by PRECAL
		- What are the values to store in tha database
		- How to interpolate once the values has been stores.
		- It gives also access to the stored values.
		This class can be derived using DECLARATION_INTERPOLATION and instantiated by INITIALISE_INTERPOLATION. Different models can be used for each option.
		@see SSPrecalculation
		@see CSROption
		*/
		class SOPHIS_FIT CSRInterpolation	{
		public:

			/** Constructor using a low level class containg the data from the tables RESULTCALC and PRECALCUL.
			If you overload the class, you must generate a construction with the same signature
			and give the pointer to the parent. The declaration is done by DECLARATION_INTERPOLATION
			and if your constructor is trivial, you can use the macro CONSTRUCTOR_INTERPOLATION in your cpp code.
			*/
			CSRInterpolation(const TInfosPrecalc *);

			/** Destructor.
			*/
			virtual ~CSRInterpolation();

		public :

			/** Start of the night calculation.
			@param option is the instrument to which night calculation is required.
			During the night calculation, for each option where night calculation is required,
			this method is called to initialize a new night calculation.
			By default, it does nothing.
			@see CSRInterpolation::TerminateInterpolation
			*/
			virtual void	InitInterpolation(const instrument::CSROption &option);

			/** End of the night calculation.
			During the night calculation, for each option where night calculation is required,
			this method is called after all the points of the matrix have been calculated, but not yet saved.
			By default, it does nothing.
			@see CSRInterpolation::InitInterpolation
			*/
			virtual void	TerminateInterpolation();


			/** Get the spot value for the night calculation.
			@param index is an index starting from -GetSpotPointCount() to GetSpotPointCount() included.
			@param option is the instrument whose night calculation is required.
			@param context is the context for night calculation (normally gApplicationContext).
			@return the spot to use that corresponds to the index.
			This function is called during the night calculation to get the spot to calculate.
			By default, use the step defined in PRECALCUL centralized at the current spot.
			*/
			virtual double	GetSpot(int index, const instrument::CSROption &option, const market_data::CSRMarketData& context) const;

			/** Get the volatility for the night calculation.
			@param index is an index starting from -GetVolatilityPointCount() to GetVolatilityPointCount() included.
			@param option is the instrument whose night calculation is required.
			@param context is the context for night calculation (normally gApplicationContext).
			@return the volatility to use corresponding to the index.
			This function is called during the night calculation to get the rate to calculate.
			This is used as a over-volatility comparing to CSROption::GetVolatility to add to the volatility surface
			to define the context in GetValuesToStore.
			By default, use the step defined in PRECALCUL centralized at {@link CSROption::GetVolatility(const CSRMarketData &)}.
			*/
			virtual double	GetVolat(int index, const instrument::CSROption &option, const market_data::CSRMarketData& context) const;

			/** Get the rate for the night calculation.
			@param index is an index starting from -GetRatePointCount() to GetRatePointCount() included.
			@param option is the instrument whose night calculation is required.
			@param context is the context for night calculation (normally gApplicationContext).
			@return the rate (.03 for 3%) as an actuarial rate Exact/365F, which means the compound factor is
			$\f (1 + r )^{\frac{T}{365}} $\f where $\fT$\f is the maturity of the option in number of days.
			This function is called during the night calculation to get the rate to calculate.
			This is used as a over-rate comparing to the zero coupon currenct with {@link CSROption::CSROption::GetStartDate} and  {@link CSROption::GetExpiry}
			to add to the yield curve, to define the context in GetValuesToStore.
			By default, use the step and the pivot, defined as an overrate of the zero coupon, defined in PRECALCUL.
			*/
			virtual double	GetRate(int index, const instrument::CSROption &option, const market_data::CSRMarketData& context) const;

			/** Get the value to store in the table RESULT_CALC.
			@param spotIndex is an index starting from -GetSpotPointCount() to GetSpotPointCount() inclusive.
			@param volatIndex is an index starting from -GetVolatilityPointCount() to GetVolatilityPointCount() inclusive.
			@param rateIndex is an index starting from -GetRatePointCount() to GetRatePointCount() inclusive.
			@param option is the instrument whose night calculation is required.
			@param context is an overload market bumping rate, spot, volatility acoording the method GetRate, GetVolat, GetSpot
			@param theoreticalValue is an output parameter to save the fair value.
			@param delta is an output parameter to save the delta.
			@param gamma is an output parameter to save the gamma.
			@param vega is an output parameter to save the vega.
			@param theta is an output parameter to save the theta.
			@param rho is an output parameter to save the rho.
			@param convexity is an output parameter to save the convexity.
			@param delta_rho is an output parameter to save the delta_rho.
			During the night calculation, this method is called for each point of the cubic matrix spot/rate/volat
			to get the value that is to be stored in RESULTCALC, if the option is one rho (not quanto, nor compo).
			By default, the method is called {@link CSROption::RecomputeAll} and fills the output values.
			@see CSRInterpolation::GetRate
			@see CSRInterpolation::GetSpot
			@see CSRInterpolation::GetVolat
			*/
			virtual	void	GetValuesToStore(	int					spotIndex,
												int					volatIndex,
												int					rateIndex,
												const instrument::CSROption	&option,
												const market_data::CSRMarketData &context,
												float				*theoreticalValue,
												float				*delta,
												float				*gamma,
												float				*vega,
												float				*theta,
												float				*rho,
												float				*epsilon,
												float				*convexity,
												float				*delta_rho,
												float				*rhoBasis,
												float				*convexityBasis,
												float				*delta_rhoBasis) const;

			/** Get the value to store in the table RESULT_CALC.
			@param spotIndex is an index starting from -GetSpotPointCount() to GetSpotPointCount() inclusive.
			@param volatIndex is an index starting from -GetVolatilityPointCount() to GetVolatilityPointCount() inclusive.
			@param rateIndex is an index starting from -GetRatePointCount() to GetRatePointCount() inclusive.
			@param option is the instrument whose night calculation is required.
			@param context is an overload market bumping rate, spot, volatility according to the method GetRate, GetVolat, GetSpot.
			@param theoreticalValue is an output parameter to save the fair value.
			@param delta is an output parameter to save the delta.
			@param gamma is an output parameter to save the gamma.
			@param vega is an output parameter to save the vega.
			@param theta is an output parameter to save the theta.
			@param rho is an output parameter to save the rho in the option currency.
			@param convexity is an output parameter to save the convexity.
			@param delta_rho is an output parameter to save the delta_rho.
			@param equity_rho is an output parameter to save the rho in the equity currency.
			During the night calculation, this method is called for each point of the cubic matrix spot/rate/volat
			to get the value to store in RESULTCALC if the option has two rhos (quanto or compo).
			By default, the method is called {@link CSROption::RecomputeAll} and fills the output values.
			@see CSRInterpolation::GetRate
			@see CSRInterpolation::GetSpot
			@see CSRInterpolation::GetVolat
			*/
			virtual	void	GetValuesToStore(	int					spotIndex,
												int					volatIndex,
												int					rateIndex,
												const instrument::CSROption	&option,
												const market_data::CSRMarketData &context,
												float				*theoreticalValue,
												float				*delta,
												float				*gamma,
												float				*vega,
												float				*theta,
												float				*rho,
												float				*epsilon,
												float				*convexity,
												float				*delta_rho,
												float				*equity_rho,
												float				*rhoBasis,
												float				*convexityBasis,
												float				*delta_rhoBasis,
												float				*equity_rhoBasis) const;

	/** Get the interpolated value from the night calculation for a mono-currency option.
			@param spot is the underlying value of the option.
			@param volatility is the volatility of the underlying obtained by {@link CSROption::GetVolatility(const CSRMarketData &)}
			@param rate (.03 for 3%) is an actuarial rate Exact/365F, which means the compound factor is
			$\f (1 + r )^{\frac{T}{365}} $\f where $\fT$\f is the maturity of the option in number of days,
			which is obtained extracting the zero coupon between {@link CSROption::GetStartDate} and  {@link CSROption::GetExpiry}
			@param option is the instrument whose quick calculation is required.
			@param theoreticalValue is an output parameter to get the fair value.
			@param delta is an output parameter to get the delta.
			@param gamma is an output parameter to get the gamma.
			@param vega is an output parameter to get the vega.
			@param theta is an output parameter to get the theta.
			@param rho is an output parameter to get the rho in the option currency.
			@param convexity is an output parameter to get the convexity.
			@param delta_rho is an output parameter to get the delta_rho.
			This function is called by {@link CSROption::LoadResults} to calculate quickly the
			option using the night calculation. The spot, volatility and rate comes from the context of calculation.
			By default, the algorithm calls {@link CSRInterpolation::GetLinearInterpolation}.
			Note that the Rho is given using the preference used during the night calculation and not the user one.
			*/
			virtual void	GetInterpolatedValue(double				spot,
												double				volat,
												double				rate,
												const instrument::CSROption		&option,
												float				*theoreticalValue,
												float				*delta,
												float				*gamma,
												float				*vega,
												float				*theta,
												float				*rho,
												float				*epsilon,
												float				*convexity,
												float				*delta_rho,
												float				*rhoBasis,
												float				*convexityBasis, 
												float				*delta_rhoBasis) const;

			/** Get the interpolated value from the night calculation for a quanto option.
			@param values is an output/input parameter containing the spot, volat, rate, correlation, equity_rate.
			@param option is the instrument whose quick calculation is required.
			This function is called by {@link CSROption::LoadResults} to calculate quickly a quanto
			option using the night calculation. The market data comes from the context of calculation.
			By default, the algorithm supposes that the formula is
			$\f F(S \exp((r_o - r_S - \sigma_S \sigma_F \rho ) T ) $\f with
			$\fF$\f only dependant of spot, spot volatility and domestic rate.
			It then modifies the spot to get the value using {@CSRInterpolation::GetLinearInterpolation}
			and deduces the greeks using the formula above. See the Financial Documentation for more information.
			Note that the Rho are given using the preference used during the night calculation, not the user preference.
			*/
			virtual void	GetQuantoInterpolatedValues(instrument::SSPrecalculation & values, const instrument::CSROption &option) const;

			/** Get the interpolated value from the night calculation for a compo option.
			@param values is an output/input parameter containing the spot, volat, rate, correlation, equity_rate.
			@param option is the instrument whose quick calculation is required.
			This function is called by {@link CSROption::LoadResults} to quickly calculate a quanto
			option using the night calculation. The market data comes from the context of calculation.
			By default, the algorithm supposes that the formula is
			$\f F(S \mbox{Forex}, \sqrt{\sigma_S^2 + 2 \rho \sigma_S \sigma_F  + \sigma_F^2}) $\f with
			$\fF$\f only dependant of spot, spot volatility and domestic rate.
			It then modifies the spot to get the value using {@CSRInterpolation::GetLinearInterpolation}
			and deduces the greeks using the formula above. See the Financial Documentation for more information.
			Note that the Rho are given using the preference used during the night calculation, not the user preference.
			*/
			virtual void	GetCompoInterpolatedValues(instrument::SSPrecalculation & values, const instrument::CSROption &option) const;

			/** Specify if night calculation is performed elsewhere.
			@return true if it is the case.
			By default, returns false. Overload the method if the night calculation has been performed elsewhere and the values are saved directly into RESULTCALC and PRECALC.
			This method is called for each option at the beginning of the night calculation and if it returns true,
			all the processes of the night calculation are skipped.
			*/
			virtual bool	ExternalNightCalculation() const;

		public:
			DECLARATION_CASTAGE2

		private:
			/** Pointer to the low level structure of night calculation.
			*/
			const TInfosPrecalc *	fInfos;

		protected:
		/** Get the interpolated value from the night calculation for a mono-currency option.
			@param spot is the underlying value of the option.
			@param volatility is the volatility of the underlying obtained by {@link CSROption::GetVolatility(const CSRMarketData &)}
			@param rate (.03 for 3%) is an actuarial rate Exact/365F, which means the compound factor is
			$\f (1 + r )^{\frac{T}{365}} $\f where $\fT$\f is the maturity of the option in number of days.
			which is obtained extracting the zero coupon between {@link CSROption::GetStartDate} and  {@link CSROption::GetExpiry}
			@param option is the instrument, whose quick calculation is required.
			@param theoreticalValue is an output parameter to get the fair value.
			@param delta is an output parameter to get the delta.
			@param gamma is an output parameter to get the gamma.
			@param vega is an output parameter to get the vega.
			@param theta is an output parameter to get the theta.
			@param rho is an output parameter to get the rho in the option currency.
			@param convexity is an output parameter to get the convexity.
			@param delta_rho is an output parameter to get the delta_rho.
			This function is called by {@link CSROption::LoadResults} to quickly calculate the
			option using the night calculation. The spot, volatility and rate comes from the context of calculation.
			By default, the algorithm interpolates in the cubic matrix of the night calculation
			using interpolation, extrapolation and the greeks, if the size in one dimension is equal to one.
			See Financial Documentation for more information.
			Note that the Rho is given using the preference used during the night calculation and not the user preference.
			*/
			void	GetLinearInterpolation(	double			spot,
											double			volat,
											double			rate,
											const instrument::CSROption &option,
											float			*theoreticalValue,
											float			*delta,
											float			*gamma,
											float			*vega,
											float			*theta,
											float			*rho,
											float			*epsilon,
											float			*convexity,
											float			*delta_rho,
											float			*equity_rho,
											float			*rhoBasis,
											float			*convexityBasis,
											float			*delta_rhoBasis,
											float			*equity_rhoBasis) const;

			/** Get the number of spots input for the night calculation.
			Note that the total number is 2N + 1 because
			it is from -N to N.
			*/
			int		GetSpotPointCount() const;

			/** Get the number of volatilities input for the night calculation.
			Note that the total number is 2N + 1 because
			it is from -N to N.
			*/
			int		GetVolatilityPointCount() const;

			/** Get the number of rates input for the night calculation.
			Note that the total number is 2N + 1 because
			it is from -N to N.
			*/
			int		GetRatePointCount() const;

			/** Get the spot variations input for the night calculation.
			*/
			double	GetSpotVariation() const;

			/** Get the volatility variations input for the night calculation.
			@return the volatility variation in the format .23 for 23%.
			*/
			double	GetVolatilityVariation() const;

			/** Get the rate variations input for the night calculation.
			@return the rate variation in the format .03 for 3% in the meaning as an overate of
			an actuarial rate Actual/365G.
			*/
			double	GetRateVariation() const;

			/** Get the FX used for compo, quanto option during the night calculation.
			@return the FX in the unit currency equity / currency option.
			*/
			double	GetForex() const;

			/** Get the FX volatility used for compo, quanto option during the night calculation.
			@return the FX volatility in the format .23 for 23%.
			*/
			double	GetForexVolatility() const;

			/** Get the correlation equity, FX used for compo, quanto option during the night calculation.
			@return the FX correlation in the format .23 for 23% for the pair(equity, currency equity / currency option).
			*/
			double	GetCorrelation() const;

			/** Get the equity rate used for compo, quanto option during the night calculation.
			@return the equity rate in the format .23 for 23% in the format .03 for 3% in the meaning as an
			actuarial rate Actual/365G
			*/
			double	GetEquityRate() const;

			/** Get the stored spot during the night calculation.
			@param index is an index starting from -GetSpotPointCount() to GetSpotPointCount() included.
			@return the spot value corresponding to the index.
			@see CSRInterpolation::GetSpot
			*/
			double	GetStoredSpot(int index) const;

			/** Get the stored volatility during the night calculation.
			@param index is an index starting from -GetVolatilityPointCount() to GetVolatilityPointCount() included.
			@return the volatility in the format .23 for 23%.
			*/
			double	GetStoredVolatility(int index) const;

			/** Get the stored rate during the night calculation.
			@param index is an index starting from -GetRatePointCount() to GetRatePointCount() included.
			@return the rate in the format .23 for 23% in the meaning as an
			actuarial rate Actual/365G.
			*/
			double	GetStoredRate(int index) const;

			/** Get the stored value during the night calculation.
			@param spotIndex is an index starting from -GetSpotPointCount() to GetSpotPointCount() included.
			@param volatIndex is an index starting from -GetVolatilityPointCount() to GetVolatilityPointCount() included.
			@param rateIndex is an index starting from -GetRatePointCount() to GetRatePointCount() included.
			@param theoreticalValue is an output parameter to save the fair value.
			@param delta is an output parameter to save the delta.
			@param gamma is an output parameter to save the gamma.
			@param vega is an output parameter to save the vega.
			@param theta is an output parameter to save the theta.
			@param rho is an output parameter to save the rho.
			@param convexity is an output parameter to save the convexity.
			@param delta_rho is an output parameter to save the delta_rho.
			@param equity_rho is an output parameter to get the equity rho.
			@throws viloation exception is the indexes are out of bonds.
			*/
			void	GetStoredValue(	int		spotIndex,
									int		volatIndex,
									int		rateIndex,
									float	*theoreticalValue,
									float	*delta,
									float	*gamma,
									float	*vega,
									float	*theta,
									float	*rho,
									float	*epsilon,
									float	*convexity,
									float	*delta_rho,
									float	*rhoBasis,
									float	*convexityBasis,
									float	*delta_rhoBasis,
									float	*equity_rho = 0,
									float	*equity_rhoBasis = 0) const;
		};
	}
}

SPH_EPILOG
#endif
