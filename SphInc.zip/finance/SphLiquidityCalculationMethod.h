/*
 	File:		SphLiquidityCalculationMethod.h
 
 	Contains:	Class for the handling of a liquidity calculation method
 
 	Copyright:	� 2010 Sophis.
*/

/*! \file SphLiquidityCalculationMethod.h
	\brief For the handling of a liquidity calculation method.
*/

#pragma once

#ifndef _SPH_LIQUIDITY_CALCULATION_METHOD_
#define _SPH_LIQUIDITY_CALCULATION_METHOD_

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(string)

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/portfolio/SphPosition.h"


#define DECLARATION_LIQUIDITY_CALCULATION_METHOD(derivedClass)							\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRLiquidityCalculationMethod)	\
	public: derivedClass();

#define CONSTRUCTOR_LIQUIDITY_CALCULATION_METHOD(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_LIQUIDITY_CALCULATION_METHOD(derivedClass)
#define	INITIALISE_LIQUIDITY_CALCULATION_METHOD(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)



SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		/** Interface to define a liquidity calculation method.
		It is used to define a liquidity calculation method which will be applied to the instrument.
		To add a new method, derive that class and install it in the prototype.
		@since 6.2
		*/
		class SOPHIS_FIT CSRLiquidityCalculationMethod
		{
		public:

			/** Trivial constructor.
			@see Initialise
			*/
			CSRLiquidityCalculationMethod();

			/** Copy constructor.
			*/
			CSRLiquidityCalculationMethod(const CSRLiquidityCalculationMethod &method);

			/** Assignation.
			*/
			CSRLiquidityCalculationMethod & operator =(const CSRLiquidityCalculationMethod &method);

			/** Destructor.
			*/
			virtual ~CSRLiquidityCalculationMethod();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_LIQUIDITY_CALCULATION_METHOD.
			@see tools::CSRPrototype
			*/
			virtual CSRLiquidityCalculationMethod* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRLiquidityCalculationMethod, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_LIQUIDITY_CALCULATION_METHOD.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/* This method is used for the Liquidity Risk Management.
			@param context is the market data which contains some data to compute the number of day to close.
			@param position is the position in the book.
			@return the number of days to close the position.
			@since 6.2
			*/
			virtual double GetNumberOfDayToClose(const market_data::CSRMarketData& context, const portfolio::CSRPosition * position) const = 0;

			virtual _STL::string GetName() const = 0;
		};
	}
}
SPH_EPILOG

#endif