/*
File:		SphLoanFacility.h

Contains:	Class for the handling of a Loan Facility.

Copyright:	2008 Sophis.

*/

/*! \file SphLoanFacility.h
\brief Class for the handling of a Loan Facility.
*/

#pragma once

#ifndef _SphLoanFacility_H_
#define _SphLoanFacility_H_

#include "SphInc/SphMacros.h"
#include "SphInc/instrument/SphPackage.h"
#include "SphInc/instrument/SphSwapEnums.h"
#include "SphInc/instrument/SphLeg.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(set)

#define DECLARATION_LOANFACILITY(derivedClass)			DECLARATION_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define CONSTRUCTOR_LOANFACILITY(derivedClass, parent)	CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, parent, const DTitrePlus)
#define WITHOUT_CONSTRUCTOR_LOANFACILITY(derivedClass)	SANS_CONSTRUCTEUR_INSTRUMENT_AVEC_PARAM(derivedClass, const DTitrePlus)
#define	INITIALISE_LOANFACILITY(derivedClass, name)		INITIALISE_INSTRUMENT(derivedClass, sophis::finance::CSRLoanFacility, name)
#define	DISABLE_LOANFACILITY(item)						DISABLE_DERIVE(sophis::finance::CSRLoanFacility, item)

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		enum eLoanFacilityHistoryType
		{
			_elfhtUndefined,
			_elfhtLoanAdded,
			_elfhtLoanRemoved,
			_elfhtLoanModified,
			_elfhtPrepaymentAdded,
			_elfhtPrepaymentRemoved,
			_elfhtPrepaymentModified,
			_elfhtForexFixingModified,
			_elfhtDealDateModified,
			_elfhtNotionalIncrease
		};

		struct SOPHIS_FIT SSRLoanFacilityComponent
		{
			SSRLoanFacilityComponent();

			double	fDrawnNotional;
			double	fForex;
			long	fTradeDate;
			long	fValueDate;
			double	fNotional;
		};

		struct SOPHIS_FIT SSRLoanFacilityHistory
		{
			SSRLoanFacilityHistory();

			double						fModificationDate;
			long						fEffectiveDate;
			eLoanFacilityHistoryType	fType;
			long						fLoanCode;
			double						fValue;
		};

		/**	structure to store the explanation of the loans
			in GetRedemptionExplication
			@version 6.0
		*/
		struct SOPHIS_FIT SSLoanExplication
		{
			SSLoanExplication();
			long					startDate;		// coupon start date
			long					endDate;		// coupon end date (0 for redemption flows)
			long					maturityDate;	// coupon payment date
			int						dayCount;		// number of days in the calculation basis
			double  				coupon;			// expected coupon amount
			double  				netCoupon;		// expected net coupon amount
			instrument::eFlowType	flowType;		// coupon flow type
			double 					presentValue;	// expected present value
			double 					floatingRate;	// expected floating rate (10 for 10%)
			double 					YTM;			// discount rate at coupon maturity (10 for 10%)
			double 					percentage;		// percentage of full coupon paid (1 for 100%)
			double					redemption;		// redemption amount, if any
			double 					inflationRate;	// absolute inflation rate
			double 					fixingWeight1;  // first fixing weight for the floating rate, in case of interpolated rate
			double 					fixingWeight2;  // second fixing weight for the floating rate, in case of interpolated rate
			double					pikFactor;		// the number of pik loans issued per loan in portfolio
			long					loanCode;		// code of the loan, or commitment fee swap
			long					currencyCode;	// currency in which the coupon is paid
			double					survivalProba;	// the survival probability at the coupon payment date
		};

		class CSRFacilitySpecialReporting;

		class SOPHIS_FIT CSRLoanFacility : public virtual instrument::CSRPackage
		{
		public:
			CSRLoanFacility(const DTitrePlus *instrument, Boolean initialiseRecomputeAll = true, Boolean fromClone = false);
			virtual ~CSRLoanFacility();

			virtual	sophis::instrument::CSRInstrument *	Clone() const;

			static CSRLoanFacility *	CreateInstance( const char * modelName );
			static CSRLoanFacility *	CreateInstance( DTitrePlus * dtP );

			// INTERNAL
			static void	InitialiseDTitre( DTitre * dt );

			/** Test if the instrument is in the right state to be priced.
			@return true if the instrument is valid.
			@version 6.0
			*/
			virtual Boolean	ValidInstrument() const;

			virtual long	GetIssuerCode() const;
			virtual bool	SetIssuerCode(long value);

			virtual sophis::instrument::CSRFixingDateComputation * new_FixingDateComputation( int whichLeg ) const;

			virtual bool SpecialTransaction(portfolio::CSRTransaction &transaction, RecalculeTransaction type) const;

			virtual double GetGrossAmount( const portfolio::CSRTransaction & transaction, double & spotForFees ) const;


			/**	Gets the type of the undrawn fees.
				Only lfFloating, lfFixed or lfNone are valid for a facility.

				@return
				a {@link sophis::instrument::eLegFlowType} describing the type of undrawn fees.

				@version 6.0
			*/
			sophis::instrument::eLegFlowType	GetLegFlowType() const;

			static bool	IsLegFlowTypeValid( sophis::instrument::eLegFlowType flowType );

			sophis::instrument::CSRLeg *	GetLeg();

			sophis::instrument::CSRLeg*	SetLeg( sophis::instrument::eLegFlowType flowType );

			/** Returns the swap whose price is equal to the commitment fees
				receiving leg is a risky fixed or floating leg, paying leg is empty
				@return a swap built in memory, assigned to sicovam fReservedSwapCode
				@version 6.0
			*/
			const sophis::instrument::CSRSwap*   GetCommitmentFeeSwap() const;

			void	ResetLeg();


			void	PasteLeg();

			/** Returns the facility total commitment in the facility currency
				Unlike packages, the facility notional is never recomputed from the notional of its components
				@return the facility notional, aka total commitment
				@version 6.0
			*/
			virtual	double	GetNotional() const;


			/** Returns the facility maturity
				Unlike packages, the facility maturity is never recomputed from the maturities of its components
				@return the facility maturity date (absolute date)
				@version 6.0
			*/
			virtual	long	GetExpiry() const;

			/** Returns the facility drawn notional
				This is the sum of the notionals drawn from each component
				@return the drawn notional in the facility currency
				@version 6.0
			*/
			virtual double	GetDrawnNotional() const;

			/** Returns the facility undrawn notional
				This is the notional minus the drawn notional, floored to 0
				@return the undrawn notional in the facility currency
				@version 6.0
			*/
			double	GetUndrawnNotional() const;


			/** Returns the facility outstanding notional
				This is the sum of the outstanding notionals for each component
				@param date is the evaluation date
				@return the outstanding notional in the facility currency
				@version 6.0
			*/
			virtual double	GetOutstandingNotional(long date) const;

			/** Returns the drawn notional for a component of the facility
				@param code of a loan or facility which is a component of the facility
				@return the drawn notional in the facility currency
				@version 6.0
			*/
			virtual double	GetComponentDrawnNotional( long loanCode ) const;

			/** Returns the equivalent quantity for a component of the facility
				@param code of a loan or facility which is a component of the facility
				@param date is the date for which the quantity is to be computed
				@return the quantity
				@version 6.0
			*/
			virtual double	GetComponentQuantity( long loanCode, long date ) const;

			/** Returns the outstanding notional for a component of the facility
				@param code of a loan or facility which is a component of the facility
				@param date is the evaluation date
				@return the outstanding notional in the facility currency
				@version 6.0
			*/
			virtual double	GetComponentOutstandingNotional( long loanCode, long date ) const;

			/** Indicates whether it is a Floating Notional.
				See {@link sophis::instrument::ePartialRedemptionType}, {@link CSRBond::GetPartialRedemptionType}.
				@return True, if it is a floating notional.
				@version 6.0
			*/
			virtual bool	IsFloatingNotional() const;

			/** Gets the Floating Notional factor.
				@param pariPassuDate
				the Pari Passu date. It is expressed in number of days since 01/01/1904.
				If value 0 is passed, then the pari passu date is considered the same as the accrued coupon date.
				@param accruedCouponDate
				the accrued coupon date. It is expressed in number of days since 01/01/1904.
				@param askQuotationType
				the quotation type. By default it is "Not Defined", in which case the quotation type taken is the
				one used in the bond (see {@link CSRBond::GetQuotationType}).
				@return
				the floating notional factor.
				@version 6.0
			*/
			virtual	double	GetFloatingNotionalFactor(	long							pariPassuDate,
														long							accruedCouponDate,
														instrument::eAskQuotationType	askQuotationType=instrument::aqNotDefined) const;
			
			/** Gets the list of components of the facility
				It includes loans, under facilities but not the commitment.
				Note that outResult is cleared in the process.
				@param outResult is an output which contains the code of the facility components
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	GetComponentCodes( _STL::set< long > & outResult ) const;

			/** Gets the list of all the components of the facility, including those of sub-facilities.
				It includes loans, under facilities but not the commitment.
				Note that outResult is not cleared in the process.
				@param outResult is an output which contains the code of all the facility components
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	GetAllComponentCodesIncludingSubComponents( _STL::set< long > & outResult ) const;

			/** Gets the list of trades done for a component in a facility
				It includes loans, under facilities but not the commitment
				@param code of a loan or facility which is a component of the facility
				@param outResult is an output which contains the deals of the facility components
				@return true, unless loanCode is incorrect or the facility is badly setup in memory
				@version 6.0
			*/
			bool	GetComponentDetails( long loanCode, _STL::vector< SSRLoanFacilityComponent > & outResult ) const;

			/** Add a trade on a new or existing facility component
				@param loanCode is the code of a loan or facility
				@param comp contains the details of the deal
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	AddComponentDetail( long loanCode, const SSRLoanFacilityComponent & comp );

			/** Set all the deals attached to a new or existing facility component
				@param loanCode is the code of a loan or facility
				@param detailVect contains the details of the deals
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	SetComponentDetails( long loanCode, const _STL::vector< SSRLoanFacilityComponent > & detailVect );

			/** Removes all components of the facility (loans and facilities)
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	RemoveAllComponents();

			/** Removes one components of the facility (loan or facility)
				@param loanCode is the code of the loan or facility to remove
				@return true, unless loanCode is incorrect or the facility is badly setup in memory
				@version 6.0
			*/
			bool	RemoveComponent( long loanCode );

			/** Sets the forex fixings to 1 for every deal in the facility
				@return true, unless the facility is badly setup in memory
				@version 6.0
			*/
			bool	ResetAllComponentForexFixings();

			/** Returns the number of facility components
				In case where the facility is being computed (@see CSRPackage::fBeeingCalculated), one more component is added
				@param the number of components to compute
				@version 6.0
			*/
			virtual int		GetBasketComponentCount() const;

			/** Returns the code and quantity of a facility component
				In case where the facility is being computed (@see CSRPackage::fBeeingCalculated), the last component corresponds
				to the swap returned by GetCommitmentFeeSwap
				@param which is the component's index from 0 to GetBasketComponentCount() - 1
				@param basket is an output, which contains the component's code and quantity
				@return true unless the component does not exist
				@version 6.0
			*/
			virtual	Boolean	GetNthBasketComponent(int which, sophis::instrument::SSBasket *basket) const;

			/** This method computes the "explanation" of the facility
				@param context is the evaluation context
				@param explicationArray is an output which contains the details of the future flows, for each component, including the commitments, and each coupon date
				explicationArray is not sorted
				@version 6.0
			*/
			void GetRedemptionExplication(	const market_data::CSRMarketData&	context,
											_STL::vector<SSLoanExplication>&	explicationArray) const;

			/** Returns the list of every loan contained in the facility or its sub-facilities, in a recursive way
				@param loanComponents is an output which contains the list of loan codes and total quantities
				@version 6.0
			*/
			void GetAllLoanComponents(_STL::vector<sophis::instrument::SSBasket>& loanComponents) const;

			/** Specify if the instrument has a special reporting.
				This method is called at the beginning of the reporting for each position,
				which has had a transaction in the last forty days.
				If the answer is yes, the reporting engine will call StartReporting for each position, and then call Reporting for each transaction on that position, and at the end, call EndReporting.
				@see StartReporting
				@see Reporting
				@see EndReporting
				@version 6.0
			*/
			virtual bool SpecialReporting() const;

			/** For an instrument where SpecialReporting() returns true, this tells whether
			EndReporting() is supposed to fill every field of the PnL on its own
			or is supposed to adjust the results computed internally
			Per default returns eOverloadStandardReporting
			@return an enum telling whether the instrument classes handles the full
			PnL computation by itself or simply adjusts the standard computation
			@see SpecialReporting
			@see EndReporting
			@version 6.0
			*/
			virtual eSpecialReportingType GetSpecialReportingType() const;

			/** Begin to process one position, for special reporting.
				This method is called at the beginning of the calculation of a position, with special reporting
				during the reporting.
				@param eoy_date is the end of year date.
				@param reporting_date is reporting date.
				@param portfolio_id is the portfolio ID (or the virtual portfolio ID).
				@param extraction is the the extraction which is reported.
				@see SpecialReporting
				@see Reporting
				@see EndReporting
				@version 6.0
			*/
			virtual void StartReporting(long reporting_date, long portfolio_id, sophis::portfolio::PSRExtraction extraction) const;

			/** Process new transaction into one position when special reporting.
				This method is called for each position transaction with special reporting
				during the reporting.
				@param deal is a pointer on the transaction (only the fields read during the reporting);
				If the extraction (given by Start) request more fields, the pointer will contain it and it is
				safe to cast it.
				@param cash is an amount which may be paid in value_date and not in the deal like a realized 
				on a future; it will be used to update the treasury of the financing; it is up to Reporting and
				especially EndReporting to update the right column in the position; by default, the value is 0,
				it should be in the settlement currency of the instrument.
				By default, call the deprecated version of Reporting for maintenance reason.
				@see SpecialReporting
				@see StartReporting
				@see EndReporting
				@version 6.0
			*/
			virtual void Reporting(sophis::portfolio::SSReportingTrade* deal, double &cash) const;

			/** End to process one position when special reporting.
				This method is called when all of the position transactions with special reporting
				have been reported.
				@param position is a pointer on an internal structure equivalent to CSRPosition.
				@param fxOfTheDay is the fx used to convert the p&l in a global currency.
				@see SpecialReporting
				@see StartReporting
				@see EndReporting
				@version 6.0
			*/
			virtual void EndReporting(TViewMvts * position, double fxOfTheDay) const;

			virtual void AddCashFlow(long start_date, long end_date, const portfolio::CSRPosition & position, portfolio::ISRCashFlow & cashFlow, const market_data::CSRMarketData* context = NULL) const;

			/** Automatic ticket to create.
				During the forecast, this method is called before doing the
				standard Sophis automatic ticket.
				According the return, the automatic tickets will be inserted into prevision
				table (used for cash in the future) when the date is in the future else
				in automatic ticket.
				This works also for instruments in package. If your forecast needs some
				information from the position like the average price, you must use the
				special automatic ticket {@link GetAutomaticTicketByReporting}.
				@param date is the forecast date.
				@param list is the automatic ticket list.
				@see AutomaticTicket
				@see eAutomaticTicketType
				@version 6.0
			*/
			virtual eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<AutomaticTicket> &list) const;


			/** Automatic ticket to create by reporting.
				During the forecast, this method is called to know if a reporting has to be done
				to be able to generate the forecast. The main difference with the
				version {@link GetAutomaticTicket} is that you get the position and you specify
				all the fields of the trade you want to create. But it does not work for instruments
				in package and does not allow to create deals in the future in automatic ticket.
				and it is of course much longer.
				The algorithm consists to generate an extraction by counterpart, entity, depositary
				on this underlying with a reporting date equals to the return; then calling {@link CreateAutomaticTicket} 
				for each position to get a list of transaction. Then it will save
				in prevision and mvt_auto table according the transaction dates.
				If the instrument has a special reporting (@link SpecialReporting} and needs to know
				that you try to generate the automatic ticket, you can use AddSpecialReportingForAutomaticTicket
				to tell it.
				@param date is the forecast date. 
				@param eoy specifies if this is for an end of year (not yet implemented).
				@param filter is a sql filter string for the where of the extraction, generally used to filter some transaction type;
				it is empty by default and if modified, must be for instance "and type = 1".
				@return the reporting date to generate the position (generally the day itself or the date before);
				if the return is null, nothing will be done.
				By default, return 0.
				@see CreateAutomaticTicket
				@see AddSpecialReportingForAutomaticTicket
				@version 6.0
			*/
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

			/** Called by each position when a special automatic ticket.
				@param eoy tells if this is for the end of year; not implemented yet.
				@param calculation_date is the date of the forecast.
				@param position is the position in the special extraction.
				@param list is the output list of transactions to generate.
				@param port is the description of the position by counterpart, entity and depositary.
				By default does nothing.
				@see GetAutomaticTicketByReporting
				@see AddSpecialReportingForAutomaticTicket
				@version 6.0
			*/
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const sophis::portfolio::CSRPosition * position, _STL::vector<sophis::portfolio::CSRTransaction> &list, const portfolio_automatic_ticket &port) const;

			/** Call back of the special extraction created for automatic ticket.
			Can be used if a special reporting needs to know if this is for a forecast.
			By default, return false 
			@since 6.0
			@see CSRExtraction::AddSpecialReporting
			*/
			virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;

			/** Get the alert list.
				@param forecastDate is the date of forecast.
				@param nb is a valid address to set the count of alerts.
				@return an array of alerts, which is deleted by delete [].
				This method is called during the forecast for all instruments in
				open positions and is used to fill the alert books.
				Note that this list is added to the conventional alerts directly managed by the forecasts.
				The default implementation is to return NULL.
				@version 6.0
			*/
			virtual sophis::instrument::SSAlert*	NewAlertList(long forecastDate, int *nb) const;

			/** Get the dialog in case of Fixing automatic ticket
				@param fixingDate is the forecast date
				@return a dialog which handles the fixing ticket, in case where fixingDate is a fixing date for the facility
				@version 6.0
			*/
			virtual sophis::gui::CSRFitDialog*      new_FixingDialog(long fixingDate) const;


			/** Split type to execute.
				@param splitDate is the date of the split of the underlying.
				@param underlyingCode is the underlying ID of the instrument.
				@return the split type.
				During a corporate action split, the engine will ask all the open
				positions if a split has to be performed, by calling this method. The return will indicate
				what action to take. By default, return saStandard.
				@version 6.0
			*/
			virtual sophis::instrument::eSplitActionType	Split(long splitDate, long underlyingCode) const;

			/** Split action to execute.
				@param splitDate is the date of the split of the underlying.
				@param underlyingCode is the underlying ID of the instrument.
				@param factor is the split factor.
				@return the action executes successfully.
				During a corporate action split, after calling Split, the engine will call SplitDone which modifies the instrument to integrate the	underlying split. By default, return false.
				@version 6.0
			*/
			virtual	bool				SplitDone(long splitDate, long underlyingCode, double factor) const;


			/** computes the total outstanding notional of the loans in the facility and the sub-facilities
				@param date the date where the outstanding notional must be recomputed
				@return the sum of loan outstanding notionals
				@version 6.0
			*/
			virtual double GetBondNotionalRedeemed(long date) const;

			/** INTERNAL.
			*/
			virtual bool HasTransparencyBreakDown(sophis::portfolio::PSRExtraction extraction) const;

			/** INTERNAL.
			*/
			virtual void	GetTransparencyBreakDown(	_STL::vector<SSTransparencyBreakDown> &components,
														sophis::portfolio::PSRExtraction extraction,
														const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
														const sophis::portfolio::eLookthroughType fSplitByComponents,
														double* evalInstrument,
														double* evalLookthroughDeals) const;


			/** Create an array of dividends in view of calculating an option or a swap.
				@param beginDate
				is the date of calculation.
				@param endDate
				is the exercise date of your option.
				@param settlementType
				is the type of settlement of the option.
				@param context
				is the market data which may modify the dividend array.
				@param toEvaluate
				is the nature of the derived product to price. The rate to take into account may be different.
				@param elementCount
				is an output parameter giving the array size.
				@return
				an array of dividends.
				The returned object is released from memory, after use.
				For explanation about calculation, see Financial Documentation.
				@see SSDividendArray
				@version 6.0
			*/
			virtual instrument::SSDividendArray *new_DividendArray(	long 									beginDate,
																	long 									endDate,
																	instrument::eSettlementType				settlementType,
																	const market_data::CSRMarketData		&context,
																	market_data::eTaxCreditPercentageType	toEvaluate,
																	int										*elementsCount) const;

			/** Calculate dividend Amount between two dates.
				Revenues are discounted to calculation_date. This is now method of the main class
				to allow total return swap on all assets classes.
				This method is used in an equity swap when paying dividends.
				@param context
				is a market data.
				@param start_date
				is the start of the period for dividend in ex-div.
				@param end_date
				is the end of the period for dividend in ex-div.
				@param paye_date
				is payment date of dividend; it may be a relative date.
				@param base is the criterion to include dividend dates: ex-div, record or payment date
				@param divData
				holds the dividend amount per currency (used for the multi-currency basket)
				when they are paid immediately.
				@version 6.0
			*/
			virtual double GetGrossDividendAmount(	const market_data::CSRMarketData	&context,
													long 								start_date,
													long 								end_date,
													long 								paye_date, 
													instrument::eDividendBase			base = instrument::_dbExDivDate,
													instrument::CSRInstrument::MapDivCurrencyAmount	*divData = NULL) const;

			/** Calculates the redeemed amount of the instrument redemption table between two dates
				This allows treatment of partial redemptions for Total Return Swaps
				on bonds and bond baskets
				@param context is the computation context
				@param startDate is the date from which the redemptions are to be taken into account (excluded)
				@param endDate is the date until which the redemptions are to be taken into account (included)
				@param paymentDate is the date at which the flows will be paid (can be a relative date)
				@param discounted tells whether the amount must be discounted and take the credit risk into account
				@version 6.0
			*/
			virtual double GetRedeemedDividendAmount(const market_data::CSRMarketData	&context,
													 long								startDate,
													 long								endDate,
													 long								paymentDate,
													 bool								discounted) const;

			/** Get the yield to maturity.
				@param transactionDate is the transaction date in number of days from 1/1/1904.
				@param settlementDate is the settlement date in number of days from 1/1/1904, generally obtained by {@link GetSettlementDate}.
				@param pariPassuDate is the pari passu date in number of days from 1/1/1904, generally obtained by {@link GetPariPassuDate}.
				@param dirtyPrice is the dirty price in the format 103 for 103%.
				@return the yield to maturity .07 for 7%.
				It is called during RecomputeAll and also in the purchase dialog.
				By default, return 0.
				@see GetYTM
				@see GetDirtyPriceByYTM
				@version 6.0
			*/
			virtual double	GetYTMByDirtyPrice(	long 	transactionDate,
												long 	settlementDate,
												long	pariPassuDate,
												double 	dirtyPrice,
												double	startPoint = NOTDEFINED) const OVERRIDE;

			/** Get the yield to maturity.
				@param transactionDate is the transaction date in number of days from 1/1/1904.
				@param settlementDate is the settlement date in number of days from 1/1/1904, generally obtained by {@link GetSettlementDate}.
				@param pariPassuDate is the pari passu date in number of days from 1/1/1904, generally obtained by {@link GetPariPassuDate}.
				@param dirtyPrice is the dirty price in the format 103 for 103%.
				@return the yield to maturity .07 for 7%.
				It is called during RecomputeAll and also in the purchase dialog.
				By default, return 0.
				@see GetYTM
				@see GetDirtyPriceByYTM
				@version 6.0
			*/
			virtual double	GetDirtyPriceByYTM(	long 	transactionDate,
												long 	settlementDate,
												long	pariPassuDate,
												double	yieldToMaturity) const;


			bool	CoerceBasket();
			
			/**	Retrieve the facility history.
				This method performs a SQL query and can therefore be slow.

				@param toFill
				a STL vector which will be filled with the history data.

				@return
				true on success, false otherwise.

				@version 6.0
			*/
			bool	GetFacilityHistory( _STL::vector< SSRLoanFacilityHistory > & toFill ) const;

			/** Get the quotation available as well as the default one.
				@param canBeInPrice is an output parameter asking if the spot can be in price.
				@param canBeInRate is an output parameter asking if the spot can be in yield.
				@param canBeInPercentage is an output parameter asking if the spot can be in percent.
				@return the default one.
				Note that the output parameters can be null.
				This method is used when purchasing the instrument to update the pop-up menu
				for the quotation type available.
				By default, 'in price' and 'in percent' are available.
			*/
			virtual sophis::instrument::eAskQuotationType	GetAskQuotationType(bool *canBeInPrice = 0,
																				bool *canBeInRate = 0,
																				bool *canBeInPercentage = 0) const;



			virtual const char *	GetXMLRootName() const;
			virtual void	GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual	void	UpdateFromDescription(const tools::dataModel::DataSet& dataSet);
			virtual	int		GetAccrualPeriod(int whichLeg, long pariPassuDate, long accruedCouponDate) const;	

			// INTERNAL
			DECLARATION_CASTAGE_CHILD;

			long GetReservedSwapCode() const;


			void UpdateCommitmentNotionals(flux_jambe** flowList, int elemCount) const;

		protected:
			/**	INTERNAL
				@version 6.0
			*/
			CSRLoanFacility();
			void Initialize(const DTitrePlus *instrument, Boolean initialiseRecomputeAll = true, Boolean fromClone = false);

			virtual const finance::CSRMetaModel * GetDefaultMetaModel() const;

			/**	INTERNAL
				@version 6.0
			*/
			virtual void GetComponentTickets(long date, _STL::vector<AutomaticTicket> &list, int which) const;
			void GetCommitmentTickets(long date, _STL::vector<AutomaticTicket> &list) const;
			void GetExpiryTicket(long date, _STL::vector<AutomaticTicket> &list) const;

			sophis::instrument::CSRLeg *	fLeg;
			mutable sophis::instrument::CSRSwap*	fSwap;
			mutable long							fReservedSwapCode;

			mutable CSRFacilitySpecialReporting*	fReportingCalculation;

			mutable _STL::map<long, double>    fSpecialReportingCoupons;
		};
	}
}
SPH_EPILOG
#endif

