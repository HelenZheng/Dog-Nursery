/*
File:		SphLoanTerm.h

Contains:	Class for the handling of a Term Loan.

Copyright:	2008 Sophis.

*/

/*! \file SphLoanTerm.h
\brief Class for the handling of a TermLoan.
*/

#pragma once

#ifndef _SphLoanTerm_H_
#define _SphLoanTerm_H_

#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(map)

/**
	Application includes
*/
#include "SphInc/finance/SphABSBond.h"

/**	Macro defining the maximal number of char that can be used to define
	a Term Loan termsheet path.
	This size does NOT include the final '\0'
	@version 6.0
*/
#define TERM_LOAN_TERMSHEET_PATH_SIZE	300

/**	Macro defining the maximal number of char that can be used to define
	a Term Loan covenant string.
	This size does NOT include the final '\0'
	@version 6.0
*/
#define TERM_LOAN_COVENANT_SIZE			1500

SPH_PROLOG
namespace sophis
{
	namespace static_data {
		struct SSDayCountCalculation;
	}
	namespace finance
	{
		// internal
		class CSRLoanSpecialReporting;

		enum eTermLoanCollateralType
		{
			tlctSecured,
			tlctUnsecured
		};

		enum eTermLoanParticipation
		{
			tlpAssignment,
			tlpSubParticipation
		};



		class SOPHIS_FIT CSRTermLoanMM : public virtual CSRABSBondMM
		{
		public:
			DECLARATION_BOND_META_MODEL( CSRTermLoanMM );

		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
		};


		/** Class used to handle Term Loans.
		@version 6.0
		*/
		class SOPHIS_FIT CSRTermLoan : public virtual CSRABSBond
		{
		public:
			DECLARATION_BOND( CSRTermLoan );

			/** Destructor
			@version 6.0
			*/
			virtual ~CSRTermLoan();

			/** When no meta model is found then this default meta model is used
			By default, it returns a pointer on fMMTermLoan.
			@version 71
			 */

			virtual const finance::CSRMetaModel * GetDefaultMetaModel() const;

			/**	Gets a boolean saying whether a prepayment exists for the specified date.

			@param date
			the date to test.

			@return
			true if a prepayment exists at this date, false otherwise.

			@version 6.0
			*/
			bool	HasLoanPrepayment( long date ) const;

			/**	Gets the prepayment value for the flows at the specified date.
			If the prepayment does not exist at this date, 0 is added and returned.

			@param date
			the date at which the prepayment should be returned.

			@return
			the prepayment corresponding to date.

			@see {@link HasLoanPrepayment}.

			@version 6.0
			*/
			double	GetLoanPrepayment( long date ) const;

			/**	Returns all the prepayments between startDate (excluded) and endDate (included).
			If startDate > endDate, the date are swapped.

			@param startDate
			the first date of the date range for whose the prepayments are fetched. (excluded)

			@param endDate
			the second date of the date range for whose the prepayments are fetched. (included)

			@param outResultMap
			a map (as an output parameter), having the dates as keys and the prepayment as values, that will be
			filled with the existing prepayments between startDate and endDate.

			@version 6.0
			*/
			void	GetLoanPrepayments( long startDate, long endDate, _STL::map< long, double > & outResultMap ) const;

			/**	Returns all the loan prepayments.

			@param outResultMap
			a map (as an output parameter), having the dates as keys and the prepayment as values, that will be
			filled with all the existing prepayments.

			@version 6.0
			*/
			void	GetAllLoanPrepayments( _STL::map< long, double > & outResultMap ) const;

			/**	Sets the prepayment value at the specified date.

			@param date
			the date of the prepayment to set.

			@param prepayment
			the value of the prepayment.

			@version 6.0
			*/
			void	SetLoanPrepayment( long date, double prepayment );

			/**	Removes the prepayment entry at the specified date.

			@param date
			the date of the prepayment to remove.

			@return
			true if a prepayment has effectively been removed, false otherwise.

			@version 6.0
			*/
			bool	RemoveLoanPrepayment( long date );

			/**	Removes all the term loan prepayments.

			@version 6.0
			*/
			void	RemoveAllLoanPrepayments();



			/** Calculates the accrued coupon.
			It is used when re-evaluating the bond to calculate the accrued.
			Special attention is given to how the bond price is quoted. If the quotation is In Price Without Accrued, then the
			result would be: accrued coupon * (bond's notional / 100).

			@param pariPassuDate
			is the pari passu date in number of days from 1/1/1904, generally obtained by {@link CSRBond::GetPariPassuDate}.

			@param accruedCouponDate
			is the accrued coupon date in number of days from 1/1/1904, generally obtained by {@link CSRBond::GetAccruedCouponDate}.
			
			@return
			the total accrued coupon in percentage (example 3 for 3%).
			If the quotation is in Price or in Percent With Accrued, then the value returned is 0.

			@version 6.0
			*/
			virtual	double	GetAccruedCoupon(long pariPassuDate, long accruedCouponDate) const;


			/** Build a redemption table from CPR or WAM.

			@param context
			a market data

			@param pricingRedemption
			(output) the modified redemption table, to be used for pricing
			In CPR or WAMgiveCPR mode, all uncertain flows prepay uniformly at annual rate CPR, 
			until the maturity date
			In WAMonly mode, the remaining notional is redeemed in one time at the WAM 
			(even for amortizing bonds) 

			@param nb
			next uncertain flow

			@param cprPtr
			cpr to use for computation, to override the CPR entered in the Bond Window.

			@version 6.0
			*/
			virtual void BuildModifiedRedemption(	const market_data::CSRMarketData		&context,
													_STL::vector<instrument::SSRedemption>	&pricingRedemption, 
													int*									nb=0, 
													double*									cprPtr = 0) const;

			/** Computes the pool factor to apply to a single coupon flow for equivalency with a list of prepayments done during this flow
			
			@param coupon
			the coupon data (cannot be a redemption)

			@param couponNotional
			the notional at the beginning of the coupon, including effect from both redemptions and prepayments

			@param prepayments
			the list of prepayments during this coupon period

			@param dccData
			needed for day count basis computation

			@param prepaymentSum
			has to be filled with the sum of prepayments done at during the flow

			@return
			the equivalent pool factor (1 if all prepayments are null)

			@version 6.0
			*/
			double ComputeEquivalentPoolFactor(	const instrument::SSRedemption				&coupon,
												double										couponNotional,
												const  _STL::map< long, double >			&prepayments,
												const static_data::SSDayCountCalculation	&dccData,
												double										&prepaymentSum) const;

			/** Returns the pool factor as of today

			@param settlementDate
			date at which the pool factor is required

			@param date
			pool factor date, output

			@return
			the pool factor

			@version 6.0
			*/
			virtual const double GetValidPoolFactorAt(long settlementDate, long* date = 0) const;

			/** Compute the Amortizing Flows for an ABCDS leg defined on the ABS
			The computation is done with zero CPR, considering only known pool factors.
			For the fixed leg, give the pool factors at  start dates of ABCDS coupons.
			For the credit leg, give amortizing at real amortizing dates.

			@param inVector
			coupon dates vector (only one period for the credit leg)

			@param outVector
			Amortizing vector (output)

			@param isCreditLeg
			true when amortizing must be computed for the credit leg

			@version 6.0
			*/
			virtual void GetAmortizedSwapFlows(	const _STL::vector<instrument::SSFlowDatesForAmortizing>&	inVectorFlows,
												_STL::vector<instrument::SSAmortizingfFlow>&				outVectorAmortizing,
												bool														isCreditLeg) const;

			/** Compute the amortizing of an ABCDS from the ABS prepayment model.

			@param context
			market data used for computation

			@param amortizingScheme
			Amortizing computed (output)

			@param issueDate
			start date for amortizing computation

			@param endDate
			end date for amortizing computation

			@version 6.0
			*/
			virtual void FillAmortizingScheme(	const market_data::CSRMarketData&	context,
												CSRCDSPricer::AmortizingScheme&		amortizingScheme,
												long								issueDate,
												long								endDate) const;


			/** Specify if the instrument has a special reporting.
			This method is called at the beginning of the reporting for each position,
			which has had a transaction in the last forty days.
			If the answer is yes, the reporting engine will call StartReporting for each position, and then call Reporting for each transaction on that position, and at the end, call EndReporting.
			@see StartReporting
			@see Reporting
			@see EndReporting
			@version 6.0
			*/
			virtual bool SpecialReporting() const;

			/** For an instrument where SpecialReporting() returns true, this tells whether
			EndReporting() is supposed to fill every field of the PnL on its own
			or is supposed to adjust the results computed internally
			Per default returns eOverloadStandardReporting
			@return an enum telling whether the instrument classes handles the full
			PnL computation by itself or simply adjusts the standard computation
			@see SpecialReporting
			@see EndReporting
			@version 6.0
			*/
			virtual eSpecialReportingType GetSpecialReportingType() const;

			/** Begin to process one position, for special reporting.
			This method is called at the beginning of the calculation of a position, with special reporting
			during the reporting.
			@param eoy_date is the end of year date.
			@param reporting_date is reporting date.
			@param portfolio_id is the portfolio ID (or the virtual portfolio ID).
			@param extraction is the the extraction which is reported.
			@see SpecialReporting
			@see Reporting
			@see EndReporting
			@version 6.0
			*/
			virtual void StartReporting(long reporting_date, long portfolio_id, sophis::portfolio::PSRExtraction extraction) const;

			/** Process new transaction into one position when special reporting.
			This method is called for each position transaction with special reporting
			during the reporting.
			@param deal is a pointer on the transaction (only the fields read during the reporting);
			If the extraction (given by Start) request more fields, the pointer will contain it and it is
			safe to cast it.
			@param cash is an amount which may be paid in value_date and not in the deal like a realized 
			on a future; it will be used to update the treasury of the financing; it is up to Reporting and
			especially EndReporting to update the right column in the position; by default, the value is 0,
			it should be in the settlement currency of the instrument.
			By default, call the deprecated version of Reporting for maintenance reason.
			@see SpecialReporting
			@see StartReporting
			@see EndReporting
			@version 6.0
			*/
			virtual void Reporting(sophis::portfolio::SSReportingTrade* deal, double &cash) const;

			/** End to process one position when special reporting.
			This method is called when all of the position transactions with special reporting
			have been reported.
			@param position is a pointer on an internal structure equivalent to CSRPosition.
			@param fxOfTheDay is the fx used to convert the p&l in a global currency.
			@see SpecialReporting
			@see StartReporting
			@see EndReporting
			@version 6.0
			*/
			virtual void EndReporting(TViewMvts * position, double fxOfTheDay) const;


			/** Automatic ticket to create.
			During the forecast, this method is called before doing the
			standard Sophis automatic ticket.
			According the return, the automatic tickets will be inserted into prevision
			table (used for cash in the future) when the date is in the future else
			in automatic ticket.
			This works also for instruments in package. If your forecast needs some
			information from the position like the average price, you must use the
			special automatic ticket {@link GetAutomaticTicketByReporting}.
			@param date is the forecast date.
			@param list is the automatic ticket list.
			@see AutomaticTicket
			@see eAutomaticTicketType
			@version 6.0
			*/
			virtual eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<AutomaticTicket> &list) const;

			/** Automatic ticket to create by reporting.
			During the forecast, this method is called to know if a reporting has to be done
			to be able to generate the forecast. The main difference with the
			version {@link GetAutomaticTicket} is that you get the position and you specify
			all the fields of the trade you want to create. But it does not work for instruments
			in package and does not allow to create deals in the future in automatic ticket.
			and it is of course much longer.
			The algorithm consists to generate an extraction by counterpart, entity, depositary
			on this underlying with a reporting date equals to the return; then calling {@link CreateAutomaticTicket} 
			for each position to get a list of transaction. Then it will save
			in prevision and mvt_auto table according the transaction dates.
			If the instrument has a special reporting (@link SpecialReporting} and needs to know
			that you try to generate the automatic ticket, you can use AddSpecialReportingForAutomaticTicket
			to tell it.
			@param date is the forecast date. 
			@param eoy specifies if this is for an end of year (not yet implemented).
			@param filter is a sql filter string for the where of the extraction, generally used to filter some transaction type;
			it is empty by default and if modified, must be for instance "and type = 1".
			@return the reporting date to generate the position (generally the day itself or the date before);
			if the return is null, nothing will be done.
			By default, return 0.
			@see CreateAutomaticTicket
			@see AddSpecialReportingForAutomaticTicket
			@version 6.0
			*/
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;


			/** Called by each position when a special automatic ticket.
			@param eoy tells if this is for the end of year; not implemented yet.
			@param calculation_date is the date of the forecast.
			@param position is the position in the special extraction.
			@param list is the output list of transactions to generate.
			@param port is the description of the position by counterpart, entity and depositary.
			By default does nothing.
			@see GetAutomaticTicketByReporting
			@see AddSpecialReportingForAutomaticTicket
			@version 6.0
			*/
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const sophis::portfolio::CSRPosition * position, _STL::vector<sophis::portfolio::CSRTransaction> &list, const portfolio_automatic_ticket &port) const;


			/** Returns the type of collateral used by the loan.
			@return a {@link eTermLoanCollateralType} which correspond to the type currently used by the loan.
			@version 6.0
			*/
			eTermLoanCollateralType	GetCollateralType() const;

			/** Sets the type of collateral that should be used by the loan.
			@param collatType is the {@link eTermLoanCollateralType} which should be used by the loan.
			@version 6.0
			*/
			void	SetCollateralType( eTermLoanCollateralType collatType );

			long	GetCollateralInstrumentCode() const;
			void	SetCollateralInstrumentCode( long code );

			eTermLoanParticipation	GetParticipation() const;
			void	SetParticipation( eTermLoanParticipation participation );

			// TERM_LOAN_TERMSHEET_PATH_SIZE
			const char *	GetTermsheetPath() const;
			void			SetTermsheetPath( const char * path );

			// TERM_LOAN_COVENANT_SIZE
			const char *	GetCovenantDescription() const;
			void	SetCovenantDescription( const char * desc );


			/** The string used to registered the class
			@version 6.0
			*/
			static const char* MODEL_NAME;

		protected:

			/** INTERNAL.
			@version 6.0
			*/
			CSRTermLoanMM fMMTermLoan;

			/** INTERNAL.
			@version 6.0
			*/
			mutable CSRLoanSpecialReporting	*fReportingCalculation;

			/**	INTERNAL
				@version 6.0
			*/
			void GetFixedCouponsTickets(long date, _STL::vector<AutomaticTicket> &list) const;
			void GetFloatingCouponsTickets(long date, _STL::vector<AutomaticTicket> &list) const;
			void GetRedemptionTickets(long date, _STL::vector<AutomaticTicket> &list) const;
			void GetPrepaymentTickets(long date, _STL::vector<AutomaticTicket> &list) const;
		};
	}
}
SPH_EPILOG
#endif
