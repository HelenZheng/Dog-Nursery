#ifndef __SphMCClauseBase_H__
#define	__SphMCClauseBase_H__

#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/finance/SphMonteCarloMultiUnderlyingServer.h"

#include "SphTools/SphArchive.h"

#define maxInteger 100000
#ifndef maxValue
	#define maxValue  1.0E+100
#endif

// Macro declaration for Clause Builder clause classes
#define DECLARATION_CLAUSEBUILDER_CLAUSE(derived)	\
	public: static _STL::string	derived::sRegistrationName;	\
	public: virtual const _STL::string	& GetName() const	{return derived::sRegistrationName;}; \
	DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derived, sophis::finance::CSRClauseBuilderClause)
// Macro to define clause identifier
#define INITIALISE_CLAUSEBUILDER_CLAUSENAME(className, name) _STL::string className::sRegistrationName = name;
// Macro instantiation for Clause Builder clause classes
#define INITIALISE_CLAUSEBUILDER_CLAUSE(className) INITIALISE_PROTOTYPE(className, className::sRegistrationName.c_str())

// Macro declaration for Clause Builder basket classes
#define DECLARATION_CLAUSEBUILDER_BASKET(derived) \
	public: static _STL::string	derived::sRegistrationName;	\
	public: virtual const _STL::string	& GetName() const	{return derived::sRegistrationName;}; \
	DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derived, sophis::finance::CSRMCBasketBase)
// Macro to define clause identifier
#define INITIALISE_CLAUSEBUILDER_BASKETNAME(className, name) _STL::string className::sRegistrationName = name;
// Macro instantiation for Clause Builder basket classes
#define INITIALISE_CLAUSEBUILDER_BASKET(className) INITIALISE_PROTOTYPE(className, className::sRegistrationName.c_str())

// Macro declaration for Clause Builder fixing classes
#define DECLARATION_CLAUSEBUILDER_FIXING(derived) \
	public: static _STL::string	derived::sRegistrationName;	\
	public: virtual const _STL::string	& GetName() const	{return derived::sRegistrationName;}; \
	DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derived, sophis::finance::CSRMCFixingBase)
// Macro to define clause identifier
#define INITIALISE_CLAUSEBUILDER_FIXINGNAME(className, name) _STL::string className::sRegistrationName = name;
// Macro instantiation for Clause Builder fixing classes
#define INITIALISE_CLAUSEBUILDER_FIXING(className) INITIALISE_PROTOTYPE(className, className::sRegistrationName.c_str())

SPH_PROLOG
namespace sophis{

	namespace market_data{


		class CSRBarrierDataImpl;

		/**
		* Class to handle data needed to compute barrier shift.
		*/
		class 	SOPHIS_MONTECARLO_SERVER CSRBarrierData
		{
		public:

			CSRBarrierData();
			~CSRBarrierData();

			/** Give the current date
			*/
			long GetDate()  const;

			/** Give the underlying spots.
			*/
			double GetSpot(long underlyingCode) const;

			/** Give the underlying implied volatility.
			*/
			double GetVolatility(long underlyingCode, double strike, long startDate, long endDate ) const;

			void SetDataImpl(CSRBarrierDataImpl * dataImpl);
	
			/**
			* PIMPL structure to handle data needed.
			*/
			CSRBarrierDataImpl * fDataImpl;
		};
	}

	namespace finance{

//--------------------------------------------------------------------------------
		/**
		* Enumeration to identify Basket Type
		*/
		enum eBasketType
		{
			eStandardBasket,	// standard Basket
			eBestOf,			// best of Basket
			eWorstOf,			// worst of Basket
			eRainbow,			// rainbow Basket
			eSpread,			// Two component spread Basket
			eSingleStock,		// Single component
			eFirstNearby,		// First Nearby future for commo
			eLastBasketTypeForSophis = eSingleStock
		};

		/**
		* Enumeration to identify Clause Type
		*/
		enum eClauseType
		{
			//operation clauses
			eSum,
			eSpreadClause,
			eProduct,
			eMax,
			eMin,
			eAbs,
			eInverse,
			eRatio,
			eConstant,
			ePower,
			eExp,
			eLog,
			eRank,
			eAutoFloor,
			eCruiseControl,
			eNothing,
			//hierarchical clauses
			eContinuation,
			//payoff clauses
			eCliquet,
			eDigitalUp,
			eDigitalDown,
			eMemoryUp,
			eMemoryDown,
			eMemoryLookBack,
			eCashFlow,
			eCappuccino,
			eOptima,
			eIndividualLock,
			eColumba,
			eRangeAccrual,
			eDispersion,
			eSquareDispersion,
			eAsianUp,
			eAsianDown,
			eSwitch,
			eMemoryStrike,
			eStepUp,
			eStepDown,
			eVariance,
			//exit event clauses
			eExitUp,
			eExitDown,
			eExitOnRange,
			eBarrierUpOut,
			eBarrierDownOut,
			eDoubleBarrierOut,
			eAccumulate,
			eTarnUp,
			eTarnDown,
			//basket manipulation clauses
			eRemoveUp,
			eRemoveDown,
			eLockUp,
			eLockDown,
			//property Clause
			ePhysicalDelivery,
			eGapRisk,
			eAsianTrigger,
			eLadder,
			ePenalty,
			eStepPenalty,
			eBasis,
			eRateLeg,
			ePayAtExit,
			eLeverage,
			eKnockOut,
			eGuaranteed,
			eNoFixings,
			eBarrierReached,
			eDiscreteBarrier,
			eTARNProperty,
			eChainedEventProperty,
			eUpdateCapProperty,
			eWeighted,
			eSwitchInequalityType,
			//model clauses, not used
			eFloorCorrelation,
			eCapCorrelation,
			eAdjustCorrelation,
			//for the base class
			eBaseClause,
			eTimePruning,
			eBarrierShift,
			eExitUpOnComponents,
			eExitDownOnComponents,
			eSwitchOnRange,
			eBuyNotional,
			eSellNotional,
			eBarrierUpTrigger,
			eBarrierDownTrigger,
			eDoubleBarrierTrigger,
			eExoticLadder,
			eRangeAccrualWithExit,
			eLastClauseTypeForSophis = eExoticLadder

		};

		//struct SSPhysicalExchange	
		//{
		//	double	quantity,
		//			cashPrice;
		//	int		underlyingIndexInGUI;
		//};


		/**
		* Enumeration for Rate leg type, e.g. behavior of rate leg in case of an exit event. 
		*/
		enum eRateLegType
		{
			eFinished,
			eAccrued,
			eFull,
			eNoExit,
			eAccruedOnPaymentDate
		};

		enum eResetRateLegActivationType
		{
			eResetNotActivated,	// not activated on this path,
			eResetActivated,		// activated in the past
			eResetAlreadyReached // reached in the past
		};

		/**
		* Internal structure to manage rate leg valuation in case of exit.
		*/
		struct SOPHIS_MONTECARLO_SERVER SSOneResetRate
		{
			SSOneResetRate() 
			{
				resetProbability	= 0.0;
				activationType		= eResetNotActivated;
				resetType			= eFull;
				paymentDate			= 0; // 0 mean not set up
			}

			double							resetProbability;
			eRateLegType					resetType;
			eResetRateLegActivationType		activationType;
			long							paymentDate;
		};

		// int is the date index in simulation manager
		typedef _STL::map<int, SSOneResetRate>	SSResetRateLeg;
	
		/** Key for a fixing.
		*/
		struct SOPHIS_MONTECARLO_SERVER SSFixingKey  
		{
			SSFixingKey();
			SSFixingKey(long code, long date, long type);

			long underCode;
			long fixingDate;
			long fixingType;

			bool operator< (const SSFixingKey& other) const;
		};

		/** List of fixings.
		*/
		typedef _STL::map<SSFixingKey , double> FixingsList;

		//--------------------------------------------------------------------------------
		class CSRClausePayoffServer;
		class CSRMCFixingBase;
		class CSRUnderlyingIndexProvider;

		struct SOPHIS_MONTECARLO_SERVER SSOneSimulationFixing 
		{
			int		underlyingIndexForPayoff;
			long	underlyingCode;
			long	fixingDate;
			long	fixingType; // -1 for simulatedValue
			double	fixingValue;

			bool operator<(const SSOneSimulationFixing& other) const;	
		};


		/**
		* Class handling simulation data.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRSimulationManager
		{
			friend class CSRClausePayoffServer;
		public:
			/**
			* Constructor
			* @version 6.1
			*/
			CSRSimulationManager();

			/**
			* Destructor
			* @version 6.1
			*/
			virtual ~CSRSimulationManager();

			/** Compute the fixing value of a single stock underlying for a given fixing clause.
			* @param fixingIndex is the identifier of the fixing clause (asian, min, max).
			* @param underlyingIndex is the identifier of the single stock underlying.
			* @param fxCompoIndex identify the forex to use if needed in a compo basket {@link CSRMCBasketBase::GetQuantoType()}.
			* @param reverse is a boolean which is false if the component spot must be multiplied by the forex spot and true if it must be divided.
			* @param underlyingIndexProvider is the single stock underlying identifier provider {@link CSRUnderlyingIndexProvider}.
			* @return the computed fixing value.
			* @version 6.1
			*/
			double						GetFixingValue(	int		fixingIndex, 
														int		underlyingIndex,
														int		fxCompoIndex=-1,
														bool	reverseOrder=false,
														const CSRUnderlyingIndexProvider*	underlyingIndexProvider = 0) const;

			/** Compute the spot value of a single stock underlying at a given fixing date.
			* @param dateIndex is the identifier of the fixing date.
			* @param underlyingIndex is the identifier of the single stock underlying.
			* @param fxCompoIndex identify the forex to use if needed in a compo basket {@link CSRMCBasketBase::GetQuantoType()}.
			* @param reverse is a boolean which is false if the component spot must be multiplied by the forex spot and true if it must be divided. 
			* @param underlyingIndexProvider is the single stock underlying identifier provider {@link CSRUnderlyingIndexProvider}.
			* @return the computed spot value.
			* @version 6.1
			*/
			double						GetSimulatedSampling(int	dateIndex, 
															int		underlyingIndex,
															long	fixingType,
															int		fxCompoIndex=-1,
															bool	reverseOrder=false) const ;	

			/** Get the number of date used to compute fixing value.
			*	@return the number of date used to compute fixing value.
			* @version 6.1
			*/
			int							GetDateCount(int nthFixingClause) const;

			/** Get the absolute date in a fixing clause from its index.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@param nthDate is index of the date in the fixing clause. It must be between 0 and GetDateCount(nthFixingClause)-1.
			*	@return the absolute date.
			* @version 6.1
			*/
			long						GetDate(int nthFixingClause, int nthDate)	const;

			
			/** Get the first absolute date in a fixing clause.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@return the first absolute date of the fixing clause.
			* @version 6.1
			*/
			long						GetFirstDate(int nthFixingClause)			const;


			/** Get the date indexes used by a fixing clause.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@return a vector of date indexes used by the fixing clause.
			*/
			const _STL::set<int>		&GetDateIndexes(int nthFixingClause) const;

			/** Get the last absolute date in a fixing clause.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@return the last absolute date of the fixing clause.
			* @version 6.1
			*/
			long						GetLastDate(int nthFixingClause)			const;

			/** Get the last absolute date index in a fixing clause.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@return the last absolute date index of the fixing clause.
			* @version 6.1
			*/
			int						GetLastDateIndex(int nthFixingClause)			const;

			/** Get the fixing type date in a fixing clause.
			*	@param nthFixingClause is the fixing clause identifier.
			*	@return the fixing type of the fixing clause.
			* @version 6.3.2.9
			*/
			long						GetFixingType(int nthFixingClause)			const;

			/** Get single stock underlying spot value.
			* @param underlyingIndex is the identifier of the single stock underlying.
			* @return the underlying spot value.
			* @version 6.1
			*/
			double						GetSpot(int underlyingIndex) const ;
			double						GetForwardPrice(int underlyingIndex, int dateIndex) const ;

			/** Validation method to check that the fixing are properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid fixings definition, false otherwise.
			* @version 6.1
			*/
			bool EnsureCoherence(_STL::string &errorMsg) const;

			/** Store all the data needed to initialise a CSRSimulationManager in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring basket definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRSimulationManager with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create basket on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRSimulationManager.
			* @version 6.1
			*/
			virtual void SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Set the simulated path of monte carlo underlying.
			*
			*	@param localPath is the simulated path {@link CSRLocalPath}.
			* @version 6.1
			*/
			inline void SetLocalPath(CSRLocalPath * localPath) {fLocalPath = localPath;};

			/** Set the antithetic sampling index.
			*
			*	@param antitheticSamplingIndex is the antithetic sampling index.
			* @version 6.1
			*/
			inline void SetAntitheticSamplingIndex(int antitheticSamplingIndex) {fAntitheticSamplingIndex = antitheticSamplingIndex;};

			/** Set the last date index in the past.
			*
			*	@param lastIndexInPast is the last date index in the past.
			* @version 6.1
			*/
			inline void SetLastIndexInPast(int lastIndexInPast) {fLastIndexInthePast = lastIndexInPast;ResizePastFixings();};
			
			/** Set the number of single stock underlying.
			*
			*	@param underlyingCount is the number of single stock underlying.
			* @version 6.1
			*/
			inline void SetUnderlyingCount(int underlyingCount) {fUnderlyingCount = underlyingCount;ResizePastFixings();};
			
			/** Give the number of single stock underlying.
			*
			*	@return the number of single stock underlying.
			* @version 7.1.3
			*/
			inline int GetUnderlyingCount() const {return fUnderlyingCount;};

			/** Initialise a past fixing value	
			*	@param dateIndex is the simulation date index.
			*	@param underlyingIndex is the single stock underlying index.
			*	@param fixingValue is the fixing value.
			* @version 6.1
			*/
			void	SetPastFixingValue(	int		dateIndex, 
										int		underlyingIndex,
										long	fixingType,
										double	fixingValue);

			double GetPastFixingValue(	int		dateIndex, 
										int		underlyingIndex,
										long	fixingType) const;



			struct SSCLBFixingClauseDescription
			{
				SSCLBFixingClauseDescription(){fixingType = 0;};
				// index in sorted dates
				_STL::vector<int>	fixingDates;
				// fixing, asian , max, min, ....
				_STL::string		fixingClauseType;
				// LAST, HIGH, OPEN, ....
				long fixingType;
			};

			/**
			* Set all the needed date and fixing data.
			* @param dates is the sorted vector of all needed dates.
			* @param fixingDescription is a map identifying a fixing clause with the fixing date index in the dates vector.
			*/
			void						SetAllDates(const _STL::vector<long>&					dates,
													const _STL::vector< SSCLBFixingClauseDescription >&	fixingDescription);

			/** Set the mapping single stock underlying for payoff indexes in {@link CSRLocalPath} and single stock underlying 
			*	identifier defined in GUI.
			* @param idxInGUI is the single stock underlying for payoff index.
			* @return the single stock underlying index defined in GUI. 
			*/
			inline void SetIndexForPayoffFromIndexInGUI(const _STL::vector<int>& indexForPayoffFromIndexInGUI) {fIndexForPayoffFromIndexInGUI = indexForPayoffFromIndexInGUI;};

			/** Give the index of a single stock underlying for payoff {@link CSRLocalPath} from the index of single stock underlying 
			*	defined in GUI.
			* @param indexForPayoffFromIndexInGUI is the vector to set.
			*/
			int							GetIndexForPayoffFromIndexInGUI(int idxInGUI){return fIndexForPayoffFromIndexInGUI[idxInGUI];};

			
			/** Get the simulated path of underlyings.
			*
			*	@return the simulated path {@link CSRLocalPath}.
			* @version 6.1
			*/
			CSRLocalPath *				GetLocalPath() const { return fLocalPath;};

			/** Get the vector of all date needed during simulation (past and future).
			*
			*	@return the vector of all date needed during simulation.
			* @version 6.1
			*/
			inline const _STL::vector<long>	 & GetAllDates() const { return fAllDates;};		

			int GetIndexFromDate(long date) const;	

			/** Get the vector of all indexes in path generator corresponding to date needed during simulation (past and future).
			*	Only initialised on server side after calling {@link FillOptimisation}.

			*	@return the vector of all date indexes in path generator needed during simulation.
			* @version 6.1
			*/
			inline const _STL::vector<int>	 & GetIndexMapping() const { return fIndexMapping;};		

			/**	Check that the corresponding fixing is defined.
			*	@param index is the fixing identifier.
			*	@return true is fixing is defined, false otherwise.
			* @version 6.1
			*/
			bool						IsFixingDefined(int index) const;

			/** Get the current antithetic sampling index.
			*
			*	@return the current antithetic sampling index.
			* @version 6.1
			*/
			inline int GetAntitheticSamplingIndex() const {return fAntitheticSamplingIndex;};


			/**	This method is called after CSRLocalPathGeneratorServer have been initialized 
			*		in order to allow optimisation during payoff computation. Default implementation optimisation is to 
			*		store in {@link CSRSimulationManager::fIndexMapping } the index in time grid of path generator corresponding to fixing dates 
			*		needed by CSRServerPayoff to compute payoff in order to allow call to {@link CSRLocalPath::GetSamplingValue}
			*		instead of {@link CSRLocalPath::GetSamplingValueFromDate} during payoff computation.
			*		
			*	@param pathGenerator is the CSRLocalPathGeneratorServer which will be used to generate path.
			*/
			virtual void	FillOptimisation(const CSRLocalPathGeneratorServer& pathGenerator);


			inline const CSRMCFixingBase*  GetFixingClause(size_t nth) const  {return fFixingClauses[nth];};

			inline size_t GetFixingClauseCount() const {return fFixingClauses.size();};

		protected:
			/**
			* Set up the past fixing storage.
			*/
			void	ResizePastFixings();

			/**
			*	Vector mapping single stock underlying for payoff indexes in {@link CSRLocalPath} and single stock underlying 
			*	identifier defined in GUI.
			*/
			_STL::vector<int>	fIndexForPayoffFromIndexInGUI;

			/**
			*  Current the simulated path {@link CSRLocalPath}.
			*/
			CSRLocalPath * fLocalPath;

			/**
			*  Current antithetic sampling index.
			*/
			int fAntitheticSamplingIndex;

			/** Last date index in the past.
			*/
			int fLastIndexInthePast;

			/** Number of single stock underlying.
			*/
			int fUnderlyingCount;

			/** map indexed by fixing type of vector storing past fixings with index =  underlying + underlyingCount*dateIndexInThePast.
			*/
			_STL::map<long,  _STL::vector<double> > fPastFixing;

			/** Filled by {@link  FillOptimisation} this vector store  the index in time grid of path generator corresponding to fixing dates 
			*	needed by CSRSimulationManager.
			*/
			_STL::vector<int> fIndexMapping;

			/** The sorted vector of all needed dates.
			*/
			_STL::vector<long>					fAllDates;

			/** The fixing clause vector with the fixing date index in the dates vector, and fixing type.
			*/
			_STL::vector< SSCLBFixingClauseDescription > fFixingDescription;

			/** Vector of all fixing clause handling fixing computation.
			*	@see CSRMCFixingBase
			*/
			_STL::vector<CSRMCFixingBase*> fFixingClauses;

			public:
				/**
				* Internal for simulation information 
				*/
#ifndef GCC_XML
				void FillSimulationDump(_STL::set<SSOneSimulationFixing> & toFill) const;
				void UpdateSimulationFromDump(const _STL::set<SSOneSimulationFixing> & fixingsToUse);
#endif // GCC_XML
		};

//--------------------------------------------------------------------------------
		class CSRMCBasketManager;
		class CSRMCClauseProperty;
		class CSRHierarchicalClauseManager;
		class CSRMCRateLeg;


		enum	 eCLB_UnderlyingType
		{
			eCLB_Unknow,
			eCLB_Equity,
			eCLB_Forex,
			eCLB_Commodity,
			eCLB_CommodityFuture,
			eCLB_SyntheticBasket

		};

		enum eClausePaymentType
		{
			eCLB_CashOptionCurrency, // cash flow in option currency
			eCLB_CashUnderlyingCurrency, // cash flow in option currency
			eCLB_Physical, // Physical payment
			eCLB_Currencies // FX case when 2 currencies are exchanged.
		};

		/**
		* Base class to handle basket definition in clause builder.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCBasketBase
		{
		public:

			/**
			* Structure to handle performance lock or remove a basket component. 
			* Performance lock or component removing are done after a given fixing index. This assume implicitly that
			* fixing indexes are coherently defined with the chronological order.  
			* @version 6.1
			*/
			struct BasketLock
			{
				/**
				* Constructor
				* @version 6.1
				*/
				BasketLock()
				{
					ResetBasketLock();
				}

				/** Inactivate a lock.
				* @version 6.1
				*/
				void ResetBasketLock()
				{
					lockFixingIndex		= removeFixingIndex	= -1;
					lockedValue			= 0.0;
				}

				/** Copy a lock.
				*/
				BasketLock&	operator=(const BasketLock& source)
				{
					lockFixingIndex		= source.lockFixingIndex;
					lockedValue			= source.lockedValue;
					removeFixingIndex	= source.removeFixingIndex;

					return *this;
				}
				
				/** When lockFixingIndex has a non negative value it identify the first end fixing index (included) after which the component performance is locked.
				*	When it has a negative value the component is not locked.
				*/
				int		lockFixingIndex;

				/** locked performance.
				*/
				double	lockedValue;

				/** When removeFixingIndex has a non negative value it identify the first end fixing index (included) after which the component is removed from the basket.
				*	When it has a negative value the component is not removed.
				*/
				int		removeFixingIndex;
			};

			/**
			* Structure to define a basket component. 
			* Internally the single underlying will be managed as basket with single component.
			* @version 6.1
			*/
			struct BasketComponent 
			{
				BasketComponent()
				{
					componentPtr			= NULL;
					weight					= 1.;
					indexInBasketManager	= maxInteger;
					floor					= -maxValue;
					cap						= maxValue;
					fxCompoIndex			= -1;
					reverseCompoFX			= false;
				};

				/**
				* Internal identifier of the component
				* @version 6.1
				*/
				_STL::string		componentID;

				/**
				* Identifier of the component
				*/
				size_t				indexInBasketManager;

				/**
				* Weight associated to the component.
				*/
				double				weight;

				/**
				* Pointer to the corresponding component used for optimization.
				*/
				CSRMCBasketBase*	componentPtr;

				/**
				* Floor to apply to the component performance.
				*/
				double 				floor;

				/**
				* Cap to apply to the component performance.
				*/
				double 				cap;

				/**
				* comment.
				*/
				_STL::string		information;

				/**
				*	In compo basket when component is not in option currency this field identify the relevant Forex
				*	to use to compute performance compo.
				*/
				int					fxCompoIndex;

				/**
				*	Bool to know if simulated fx for compo must multiply (false) or divide the componet simulated spot (true).
				*/
				bool				reverseCompoFX;
			};

			/**
			* Constructor
			* @version 6.1
			*/
			CSRMCBasketBase();

			/**
			* Destructor
			* @version 6.1
			*/
			virtual ~CSRMCBasketBase();

			/** Initialise the basket.
			* @param basketManager is an internal storage class to manage basket.
			* @param iD is a capital letter identifying the basket.
			* @version 6.1
			*/
			void									InitBasket(	CSRMCBasketManager	*basketManager, 
																const _STL::string		&iD);

			/** Give the number of basket component.
			* @return the number of component.
			* @version 6.1
			*/
			int										GetComponentCount() 			const;

			/** Give the basket type.
			* @return the basket type.
			* @version 6.1
			* @see eBasketType
			*/
			eBasketType								GetBasketType()					const;

			/** Give the basket identifier as a capital letter between A and Z for a basket or an integer for single stock.
			* @return the identifier string.
			* @version 6.1
			*/
			const _STL::string&						GetId()							const;

			/** Accessor to the simulation manager.
			*	@return a reference on the simulation manager.
			*	@version 6.1
			*/
			CSRSimulationManager&					GetSimulationManager()			const;

			/** Accessor to a basket's component.
			* @param nth is the index of the component between 0 to GetComponentCount()-1.
			* @return the component structure.
			* @version 6.1
			* @see BasketComponent
			*/
			const BasketComponent&					GetNthComponent(size_t nth)		const;


			/** Return the index of the basket (0 to n) in the basket manager.
			* @return the index of the basket in the basket manager.
			* @version 6.1
			*/
			size_t									GetIndexInBasketManager()		const;

			/** Set the index of the basket (0 to n) in the basket manager.
			* @param index is the index of the basket in the basket manager.
			* @version 6.1
			* @see GetIndexInBasketManager
			*/
			void									SetIndexInBasketManager(size_t index) ;

			/** Accessor to the vector of basket's components.
			* @return the component structure.
			* @version 6.1
			* @see BasketComponent
			*/
			const _STL::vector<BasketComponent>&	GetComponentVector()			const;

			/** Accessor to quanto/compo type of the basket. When a single stock is not in the option currency the performance
			*	of this stock between two fixings can be computed by using spot in single stock currency (quanto case)
			*	or by converting value in option currency by using current forex rate spot (compo case). 
			* @return the quanto/compo type of the basket.
			* @version 6.1
			* @see eQuantoType
			*/
			sophis::instrument::eQuantoType			GetQuantoType()					const;

			/** Set the quanto/compo type of the basket. 
			* @param type is the quanto/compo type of the basket.
			* @version 6.1
			* @see CSRMCBasketBase::GetQuantoType
			*/
			void									SetQuantoType(sophis::instrument::eQuantoType type);


			/** Optimisation method used to initialize pointer to basket components. 
			*	Basket components are stored in class CSRMCBasketManager.
			* @version 6.1
			* @see BasketComponent.componentPtr
			*/
			virtual void							InitialiseComponentPtr();

			void  CheckDatesForBarrier(long barrierStartDate, long barrierEndDate, _STL::set<long>& distinctDates);

			/** Add a new component in the basket. 
			* @param indexInBasketManager is the index identifying the component in the basket manager.
			* @param weight is the component weight.
			* @param cap is the cap applied to the component performance.
			* @param floor is the floor applied to the component performance.
			* @param information is a string giving user information on the component definition (as an example ranking defining the component).
			* @param fxCompoIndex identify the forex to use if needed in a compo basket {@link CSRMCBasketBase::GetQuantoType()}.
			* @param reverse is a boolean which is false if the component spot must be multiplied by the forex spot and true if it must be divided. 
			* @version 6.1
			*/
			virtual void 							AddComponent(size_t			indexInBasketManager, 
																 double			weight,
																 double			cap = maxValue,
																 double			floor = -maxValue,
																 _STL::string	information = "",
																 int			fxCompoIndex = -1,
																 bool			reverse = false);

			/** Accessor to the index in the storage class CSRBasketmanager. 
			* @return the index identifying the basket.
			* @version 6.1

			*/
			inline size_t GetIndexInBasketmanager() const {return fIndexInBasketManager;};

			/** Compute the performance of the basket between two fixing clauses {@link CSRMCFixingBase}.
			*	When computing a performance it also fill member {@link fBestPerformance}, {@link fWorstPerformance}, {@link fBestPerformer} and {@link fWorstPerformer}.
			*	in order to manage worst of and best of performer.
			* @param startFixingIndex is the index identifying the start fixing.
			* @param endFixingIndex is the index identifying the end fixing.
			* @param fxCompoIndex identify the forex to use if needed in a compo basket {@link CSRMCBasketBase::GetQuantoType()}.
			* @param reverse is a boolean which is false if the component spot must be multiplied by the forex spot and true if it must be divided. 
			* @return the computed performance.
			* @version 6.1
			*/
			virtual double 							GetPerformance(int	startFixingIndex,
																   int	endFixingIndex,
																   int	fxCompoIndex = -1,
																   bool reverseOrder = false) const; // sets BW performer as well

			/** Give the basket name. Do not overload this method, it is defined by using macro DECLARATION_CLAUSEBUILDER_BASKET.
			* @return the basket name.
			* @version 6.1
			*/
			virtual const _STL::string	& GetName() const	=0;

			/** Validation method to check that the basket is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool							EnsureBasketCoherence(_STL::string &errorMsg)	const;

			/** Store all the data needed to initialise a CSRMCBasketBase in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring basket definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRMCBasketBase with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create basket on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRMCBasketBase.
			* @version 6.1
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);

			
			/**	Method to know if a component is already removed from the basket.
			* @param component is the basket component index.
			* @param endDateIndex is the end fixing clause index.
			* @return true is the component is already removed for end fixing identified by endDateIndex, false otherwise.
			* @version 6.1
			*/
			bool 									IsRemoved(int component, int endDateIndex) const;

			/**	Remove a component from the basket for end fixing with identifier greater then endDateIndex.
			* @param component is the basket component index.
			* @param endDateIndex is the end fixing clause index.
			* @version 6.1
			*/
			void 									Remove(int component, int endDateIndex);

			/**	Method to know if a component performance is already locked.
			* @param component is the basket component index.
			* @param endDateIndex is the end fixing clause index.
			* @param lockedValue is a reference to fill the locked performance value.
			* @return true is the component is already locked for end fixing identified by endDateIndex, false otherwise.
			* @version 6.1
			*/
			bool 									IsLocked(int component, int endDateIndex, double& lockedValue) const;

			/**	Lock a component performance from the basket for end fixing with identifier greater then endDateIndex.
			* @param component is the basket component index.
			* @param endDateIndex is the end fixing clause index.
			* @param lockedValue is the locked performance value.
			* @version 6.1
			*/
			void 									Lock(int component, int endDateIndex, double lockedValue);

			/** Internal handle accessors to manage  Basket manipulation clause
			*/
			inline									_STL::vector<BasketLock>*& GetHandleOnLocks() {return fLocksPtr;};

			/** A method to know if after performance evaluation on a period the basket performance is the one of a single underlying.
			*	@see CSRMCReducibleBasket
			*
			*	@return true for a reducible basket, false otherwise.
			*/
			virtual bool IsReducible() const {return false;}

			/**
			*	@return the index in GUI of the single underlying which is used to compute basket performance.
			*	As an example the index of the best performer for a best of basket.
			*/
			virtual int GetSingleUnderlying(int & fxCompoIndex, bool &reverseCompoFX, long paymentDate) const;


		protected:


			

			/**	Basket identifier string. It is a capital letter between A and Z for a basket or an integer for single stock.
			*/
			_STL::string							fID; 

			/**	Enumeration identifying the basket type.
			* @see eBasketType
			*/
			eBasketType								fBasketType;

			/**	Index in the storage class CSRBasketmanager. 
			*/
			size_t									fIndexInBasketManager;

			/**	Internal storage class to manage basket.
			*/
			CSRMCBasketManager*						fBasketManager;

			/**	Vector of basket components.
			* @see BasketComponent
			*/
			_STL::vector<BasketComponent>			fComponent;

			/**	pointer on a vector of basket lock. It is locally filled by Basket modification clauses.
			* @see BasketLock
			*/
			_STL::vector<BasketLock>*				fLocksPtr;

			/**	Quanto/Compo type of the basket.
			* @see CSRMCBasketBase::GetQuantoType
			*/
			sophis::instrument::eQuantoType			fQuantoType;

			/**
			*  
			*/
			eCLB_UnderlyingType						fCLB_UnderlyingType;
			
		public:

			inline void  SetCLB_UnderlyingType(eCLB_UnderlyingType clb_UnderlyingType){fCLB_UnderlyingType = clb_UnderlyingType;};
			inline eCLB_UnderlyingType GetCLB_UnderlyingType() const {return fCLB_UnderlyingType;};

#ifndef GCC_XML
			virtual void FillComponentCLB_UnderlyingType(_STL::set<eCLB_UnderlyingType> & toFill) const;
#endif
			/** Respectively best performance and worst performance computed from the last call to method {@link CSRMCBasketBase::GetPerformance}.
			*/
			mutable double fBestPerformance, fWorstPerformance;

			/** Performance of component computed from the last call to method {@link CSRMCBasketBase::GetPerformance}.
			*/
			mutable _STL::vector<double> fComponentPerformance;

			/** Respectively best performer component index and worst performer component index computed from the last call to method {@link GetPerformance}.
			*/
			mutable int fBestPerformer, fWorstPerformer;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRMCBasketBase* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRMCBasketBase for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRMCBasketBase, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

		};


		/** Class handling reducible basket. 
		*	A basket is reducible if after performance evaluation on a period the basket performance is the one 
		*	of a single underlying.
		*	Only reducible basket can be physically delivered.
		*
		*	In default implementation reducible basket are single underlyings, or Best of/Worst of basket for which all component are reducible.
		*
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCReducibleBasket : public CSRMCBasketBase
		{
		public:

				/**
			*	@return the index in GUI of the single underlying which is used to compute basket performance.
			*	As an example the index of the best performer for a best of basket.
			*/
			virtual int GetSingleUnderlying(int & fxCompoIndex, bool &reverseCompoFX, long paymentDate) const;

			/** A method to know if after performance evaluation on a period the basket performance is the one of a single underlying.
			*
			*	Default implementation is to check that every component is reducible. 
			*	
			*	@return true for a reducible basket, false otherwise.
			*/
			virtual bool IsReducible() const;

		protected:
			/**
			*	@return the component index of the single underlying which is used to compute basket performance.
			*	As an example the index of the best performer for a best of basket.
			*/
			virtual int GetSingleUnderlyingComponent(long paymentDate) const =0;
		};


//--------------------------------------------------------------------------------
		
		/**
		* Flag used to identify relevant column data for a given clause {@link CSRHierarchicalClauseBase::fClauseFormat}.
		*/ 
		enum ClauseCellPermission
		{
			eValueCell			= 0x0000000001,
			eUnderlyingsCell	= 0x0000000002,
			ePropertiesCell		= 0x0000000004,
			eChildrenCell		= 0x0000000008,
			eContinuationCell	= 0x0000000010,
			ePaymentDateCell	= 0x0000000020,
			eCouponCell			= 0x0000000040,
			eFactorCell			= 0x0000000080,
			eStrikeCell			= 0x0000000100,
			eFloorCell			= 0x0000000200,
			eCapCell			= 0x0000000400,
			eStartFixingCell	= 0x0000000800,
			eEndFixingCell		= 0x0000001000,
			// from Life
			eMinAgeCell			= 0x0010000000,
			eMaxAgeCell			= 0x0020000000,
			eStartCell			= 0x0040000000,
			eEndCell			= 0x0080000000
		};					 
			  
							  
		/**					  
		* Base class to handle hierarchical clauses in Monte Carlo.
		*/					  
		class SOPHIS_MONTECARLO_SERVER CSRHierarchicalClauseBase
		{
		friend class CSRHierarchicalClauseManager;
		public:
			/**
			* Constructor. Must set up fClauseFormat by adding element of enum {@link ClauseCellPermission} to define which column is relevant for the given clause.
			* @version 6.1
			*/
			CSRHierarchicalClauseBase();
			
			/**
			* Destructor
			* @version 6.1
			*/
			virtual ~CSRHierarchicalClauseBase();

			static _STL::vector<int> emptyVect;
			/**
			* Method to initialise a clause.
			* @param comment is a string to fill comment for a clause.		
			* @param value is a string to define value field for a clause.		
			* @param factor	is the multiplicative factor of a clause.		
			* @param coupon	is the coupon of a clause.			
			* @param strike	is the strike of a clause.				
			* @param floor is the floor of a clause.		
			* @param cap is the cap of a clause.				
			* @param children is a vector of child clause indexes.
			* @param properties	is a vector of property clause indexes.
			* @version 6.1
			*/
			void							InitClause(	_STL::string				comment			= "",
														_STL::string				value			= "",
														double						factor			= 1,
														double						coupon			= 0,
														double						strike			= 0,
														double						floor			= -maxValue,
														double						cap				= maxValue,
														const _STL::vector<int>&	children		= emptyVect,
														const _STL::vector<int>&	properties		= emptyVect,
														const _STL::vector<int>&	continuation	= emptyVect);

			/** virtual method to initialise specific parameter of a clause from its value string or from its properties.
			* @version 6.1
			*/
			virtual void					InitSpecificData() {return;};

			/** Mask identifying relevant column for clause definition. Member fClauseFormat must be filled in constructor.
			* @version 6.1
			*/
			inline long	GetClauseFormat() const {return fClauseFormat;};			

		public:
			/**
			* Copy constructor.
			* @version 6.1
			*/
			CSRHierarchicalClauseBase&	operator=(const CSRHierarchicalClauseBase& source);

			/** Give the clause name. Do not overload this method, it is defined by using macro DECLARATION_CLAUSEBUILDER_CLAUSE.
			* @return the clause name.
			* @version 6.1
			*/
			virtual const _STL::string	&GetName() const	=0;

			//-----------------------------------------------------------------------------------------------
			/** Accessor to the clause's value field.	
			* @return the clause's value field.	
			* @version 6.1
			*/
			inline const _STL::string	&GetValue()				const					{return fValue;};

			/** Accessor to the clause's comment string.
			* @return  the clause's comment string.
			* @version 6.1
			*/
			inline const _STL::string	&GetComment()			const					{return fComment;};

			/** Accessor to the clause's multiplicative factor.
			* @return the clause's multiplicative factor.
			* @version 6.1
			*/
			inline double				GetFactor() 			const					{return fFactor;};

			/** Accessor to the clause's coupon factor.
			* @return the clause's coupon factor.
			* @version 6.1
			*/
			inline double				GetCoupon() 			const					{return fCoupon;};

			/** Accessor to the clause's strike.
			* @return the clause's strike.
			* @version 6.1
			*/
			inline double				GetStrike() 			const					{return fStrike;};

			/** Accessor to the clause's floor.
			* @return the clause's floor.
			* @version 6.1
			*/
			inline double				GetFloor()				const					{return fFloor;};

			/** Accessor to the clause's cap.
			* @return the clause's cap.
			* @version 6.1
			*/
			inline double				GetCap()				const					{return fCap;};

			//-----------------------------------------------------------------------------------------------

			/** Set the value field.	
			* @param value is the clause's value field to set up.	
			* @version 6.1
			*/
			inline void					SetValue(const _STL::string & val)				{fValue			= val;};


			/** Set the clasue's comment.	
			* @param value is the clause's comment string to set up.	
			* @version 6.1
			*/
			inline void					SetComment(const _STL::string & comment)		{fComment		= comment;};

			/** Set the clause's multiplicative factor.	
			* @param value is the clause's multiplicative factor to set up.	
			* @version 6.1
			*/
			inline void					SetFactor(double factor)						{fFactor		= factor;};

			/** Set the clause's coupon.	
			* @param value is the clause's coupon to set up.	
			* @version 6.1
			*/
			inline void					SetCoupon(double coupon)						{fCoupon		= coupon;};	

			/** Set the clause's strike.	
			* @param value is the clause's strike to set up.	
			* @version 6.1
			*/
			inline void					SetStrike(double strike)						{fStrike		= strike;};

			/** Set the clause's floor.	
			* @param value is the clause's floor to set up.	
			* @version 6.1
			*/
			inline void					SetFloor(double floor)							{fFloor			= floor;};

			/** Set the clause's cap.	
			* @param value is the clause's cap to set up.	
			* @version 6.1
			*/
			inline void					SetCap(double cap)								{fCap			= cap;};	
			
			/** Accessor to the clause type enum identifier.
			* @return the clause type enum identifier.
			* @version 6.1
			*/
			inline eClauseType 			GetClauseType()			const					{return fClauseType;};

			/**
			* @param type is the clause type enum identifier to set up.
			* @version 6.1
			*/
			inline void					SetClauseType(const eClauseType type)			{fClauseType = type;};

			/** Accessor to the integer identifier of the clause.
			* @return the integer identifier of the clause.
			* @version 6.1
			*/
			inline int			 		GetId()					const 					{return fID;};

			/** Give the number of child clauses.
			* @return the number of child clauses.
			* @version 6.1
			*/
			inline int	 				GetChildCount()			const 					{return (int) fChildrenIndex.size();};
			
			/** Give the number of property clauses.
			* @return the number of property clauses.
			* @version 6.1
			*/
			inline int	 				GetPropertyCount()		const 					{return (int) fPropertiesIndex.size();};

			/** Give the number of continuation clauses.
			* @return the number of continuation clauses.
			* @version 7.1.3
			*/
			inline int	 				GetContinuationCount()			const 					{return (int) fContinuationIndex.size();};

			/** Give the index identifier of the nth child clause.
			* @param nth is the child clauses between 0 and GetChildCount()-1.
			* @return the index identifier of the nth child clause.
			* @version 6.1
			*/
			inline int					GetNthChildIndexInClauseManager(int nth) const	{return fChildrenIndex[nth];};
		
			/** Set up the child clause indexes.
			* @param childrenIndex is a vector of child clause indexes.
			* @version 6.1
			*/
			inline void					SetChildren(const _STL::vector<int>&	childrenIndex)	{fChildrenIndex = childrenIndex;};

			/** Set up the property clause indexes.
			* @param properties is a vector of property clause indexes.
			* @version 6.1
			*/
			inline void					SetProperties(const _STL::vector<int>& properties)	{fPropertiesIndex = properties;};
			
			
			/** Give the index identifier of the nth continuation clause.
			* @param nth is the continuation clauses between 0 and GetContinuationCount()-1.
			* @return the index identifier of the nth continuation clause.
			* @version 7.1.3
			*/
			inline int					GetNthContinuationIndexInClauseManager(int nth) const	{return fContinuationIndex[nth];};
		
			/** Set up the continuation clause indexes.
			* @param continuationIndex is a vector of continuation clause indexes.
			* @version 7.1.3
			*/
			inline void					SetContinuation(const _STL::vector<int>&	continuationIndex)	{fContinuationIndex = continuationIndex;};
			
			/**
			* Set the clause as a root in hierarchical clause tree.
			* @version 6.1
			*/
			inline void					SetToRoot() { fIsRootNode = true;};

			/**
			* @return true if the clause is a root in hierarchical clause tree, false when it is a child clause or a property of another clause.
			* @version 6.1
			*/
			inline bool					IsRootNode()			const					{return fIsRootNode;};

			/** Store all the data needed to initialise a CSRHierarchicalClauseBase in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring clause definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRHierarchicalClauseBase with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create clause on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRMCBasketBase.
			* @version 6.1
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);

			/**
			* Optimisation method called to initialise pointer on other clauses. 
			* @version 6.1
			*/
			virtual void				InitialisePtr();

			
			/** Validation method to check that the clause is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool				EnsureClauseCoherence(_STL::string &errorMsg)	const {return true;};
	
			/** Method to define the tooltip help associated to the clause.
			* @return the tooltip help string.
			* @version 6.1
			*/
			virtual _STL::string		GetToolTipHelp()		const					{return "";};


			inline int GetIDinGUI() const {return fIDinGUI;};

		protected:

			/**
			* Define which column is relevant for the given clause {@link ClauseCellPermission}, must be initialized in constructor.
			* @version 6.1
			*/
			long						fClauseFormat;

			/**
			*  Clause's comment string.
			* @version 6.1
			*/
			_STL::string				fComment;

			/**
			*  Clause's value field.
			* @version 6.1
			*/
			_STL::string				fValue;
			
			/**
			*  Clause's coupon.
			*  In GUI coupon is a percentage of notional for standard clause or an absolute value for an absolute clause performance.
			*  In order to have an unified management of clauses for an absolute clause fCoupon is 100 times the value set up in GUI out of option notional.
			* @version 6.1
			*/
			double						fCoupon;

			/**
			*  Clause's multiplicative factor.
			* @version 6.1
			*/
			double						fFactor;

			/**
			*  Clause's strike.
			*  In GUI strike is a percentage of notional for standard clause or an absolute value for an absolute clause performance.
			*  In order to have an unified management of clauses for an absolute clause fStrike is 100 times the value set up in GUI out of option notional.
			* @version 6.1
			*/
			double						fStrike;

			/**
			*  Clause's floor. 
			*  In GUI floor is a percentage of notional for standard clause or an absolute value for an absolute clause performance.
			*  In order to have an unified management of clauses for an absolute clause fFloor is 100 times the value set up in GUI out of option notional.
			* @version 6.1
			*/
			double						fFloor;

			/**
			*  Clause's cap.
			*  In GUI cap is a percentage of notional for standard clause or an absolute value for an absolute clause performance.
			*  In order to have an unified management of clauses for an absolute clause fCap is 100 times the value set up in GUI out of option notional.
			* @version 6.1
			*/
			double						fCap;
			
			/**
			*  Clause's identifier in clause manager.
			* @version 6.1
			*/
			int							fID;


			/**
			*  Clause's identifier in GUI.
			* @version 6.1
			*/
			int							fIDinGUI;

			/**
			* Clause type {@link eClauseType}.
			* @version 6.1
			*/
			eClauseType					fClauseType;

			/**
			*  Vector of child clause indexes.
			* @version 6.1
			*/
			_STL::vector<int>			fChildrenIndex;

			/**
			*  Vector of property clause indexes.
			* @version 6.1
			*/
			_STL::vector<int>			fPropertiesIndex;

			/**
			*  Vector of continuation clause indexes.
			* @version 6.1
			*/
			_STL::vector<int>			fContinuationIndex;


			/**
			* True when the clause is a root in the hierarchical definition, false when it is a child or a property of another clause.
			* @version 6.1
			*/
			bool						fIsRootNode;


			/**
			* Set up the clause manager managing all clauses.
			* @param clauseManager is the clause manager.
			* @version 6.1
			*/
			virtual void	SetClauseManager(CSRHierarchicalClauseManager* clauseManager);

			/**
			* Set up the index identifying this clause in the clause manager.
			* @param indexInClauseManager is the clause identifier.
			* @version 6.1
			*/
			inline void		SetIndexInClauseManager(size_t indexInClauseManager) {fID = (int)indexInClauseManager;};

			/**
			* Set up the index identifying this clause in the GUI.
			* @param identInGUI is the clause identifier in GUI.
			* @version 6.1
			*/
			inline void		SetIndexInGUI(int identInGUI) {fIDinGUI = (int)identInGUI;};

		};


		class CSRChainedEvent;
		//--------------------------------------------------------------------------------

		/**
		* Class to handle State variable used during hierarchical payoff computation.
		* It is useful for feature like a reserve in cruise control or accumulated payoff in TARN
		* where a clause can modify the value of a variable used by another clause.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRCLBStateVariable
		{
		public:
			/**
			* Constructor 
			*/
			CSRCLBStateVariable& operator=(const CSRCLBStateVariable& other);

			/**
			* Destructor 
			*/
			virtual ~CSRCLBStateVariable();

			/**
			* Add a new variable with initial value.
			@param initValue is the initial variable value.
			@return on creation return index to use to access to new variable.
			*/
			size_t AddStateVariable(double initValue = 0.0);

			/** Variable accessor as a double type.
			@param  idx is the variable index.
			@return variable value as a double type.
			*/
			double	GetDoubleVariableValue(size_t idx) const;

			/**
			* Set one variable value.
			@param  idx is the variable index.
			@param	val is the variable value to set.
			*/
			void	SetDoubleVariableValue(size_t idx, double val);

			/** Variable accessor as a integer type.
			@param  idx is the variable index.
			@return variable value as a integer type.
			*/
			int		GetIntegerVariableValue(size_t idx) const;

			/**
			* Set one variable value.
			@param  idx is the variable index.
			@param	val is the variable value to set.
			*/		
			void	SetIntegerVariableValue(size_t idx, long val);


			inline _STL::vector<double> & GetVariableValue() {return fVariableValue;};

			/**
			* Clean variables. 
			*/
			virtual void Clean();



			/**
			* Add a new chained event variable.
			@return on creation return index to use to access to new chained event variable.
			*/
			size_t AddChainedEventVariable();

			/**
			*  Accessor on a registered event
			*/
			CSRChainedEvent & GetChainedEvent(size_t idx);
		protected:
			/**
			* Variables storage.
			*/
			_STL::vector<double> fVariableValue;

			_STL::vector< CSRChainedEvent >		fChainedEvent;
		};

#ifndef GCC_XML
		/**
		*	Class to localy set a variable value in a {@see CSRCLBStateVariable}.
			When a creating CSRCLBLocalStateVariableSwitcher object the nth variable value will be set up
			to a new value until the end of the scope where CSRCLBLocalStateVariableSwitcher will be deleted and 
			variable will recover its previous value.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRCLBLocalStateVariableSwitcher
		{
		public:
			/**
			* Constructor 
			@param  other is the {@see CSRCLBStateVariable} object storing variable to modifyindex.
			@param  nth is the variable index.
			@param	val is the variable value to set.
			*/
			CSRCLBLocalStateVariableSwitcher(CSRCLBStateVariable& other, int nth, double val);

			/**
			* Destructor 
			*/
			virtual ~CSRCLBLocalStateVariableSwitcher();

		protected:
			// internal
			double fPreviousValue;
			int fNth;
			CSRCLBStateVariable & fCSRCLBStateVariable;
		};
#endif
		//

		class CSRClauseBuilderClauseManager;
		class CSRClauseBuilderPayoffServer;
		class CLRCLBDumpNode;

		/**
		* Hierarchical clauses used in clause builder. 
		* It manage gap risk, start fixing and end fixing index	and payment date.
		*/
		class SOPHIS_MONTECARLO_SERVER  CSRClauseBuilderClause : public virtual CSRHierarchicalClauseBase
		{
			friend class CSRClauseBuilderPayoffServer;
			friend class CSRClauseBuilderClauseManager;
			friend class CLRCLBDumpNode;
		public:
			/**
			* Constructor.
			* @version 6.1
			*/
			CSRClauseBuilderClause();

			/**
			* Destructor.
			* @version 6.1
			*/
			virtual ~CSRClauseBuilderClause() ;

			/**
			* Accessor to the server payoff using this clause.
			* @return the server payoff using this clause.
			* @version 6.1
			*/
			const CSRClauseBuilderPayoffServer& GetClausePayoffServer() const;

			/**
			* @param underlyingIndexes is the vector of underlying indexes for which we need a feature to manage.	
			* @param feature is the identifier of the feature to manage{@link eUnderlyingPathFeature };
			* @param startDate is the start date for the corresponding feature period.
			* @param endDate is the end date for the corresponding feature period.
			* @return true when clause need a feature to be managed by path generator, false otherwise.
			* @see CSRLocalPathGeneratorClient::AddFeatureToManage
			* @version 6.1
			*/
			virtual bool GetFeatureToManage(	_STL::vector<int>		&underlyingIndexes,	
												eUnderlyingPathFeature	&feature,
												long					&startDate,
												long					&endDate) const; 

			/** Check if an alert must be sent to user. Currenttly it is used to follow multi barrier clause.
			* @param alertMessage is the alert message to display when .
			* @return true if an alert must be sent, false otherwise.
			* This method is called during the forecast for all instruments in
			* open positions and is used to fill the alert books.
			* Note that this list is added to the conventional alerts directly managed by the forecasts.
			* The default implementation is to return false.
			* @version 6.1
			*/
			virtual bool CheckAlert(_STL::string &  alertMessage) const {return false;};


			/** Clone for this object. Used for prototypal construction of the object.
			* @version 6.1
			*/
			virtual CSRClauseBuilderClause* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRClauseBuilderClause for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			* @version 6.1
			*/
			typedef	sophis::tools::CSRPrototype<CSRClauseBuilderClause, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/**
			* Optimisation method called to initialise pointer fProperties and fChildren on other clauses. 
			* @version 6.1
			*/
			virtual void				InitialisePtr();

			/** Give a pointer to the nth property clause.
			* @param nth is the property clauses index between 0 and GetPropertyCount()-1.
			* @return the pointer to the nth property clause.
			* @version 6.1
			*/
			inline const CSRClauseBuilderClause*		GetNthProperty(int i)	const 			{return fProperties[i];};
			
			/** Give a pointer to the nth child clause.
			* @param nth is the child clauses index between 0 and GetChildCount()-1.
			* @return the pointer to the nth child clause.
			* @version 6.1
			*/
			inline const CSRClauseBuilderClause*		GetNthChild(int i)		const 			{return fChildren[i];};


			/** Give a pointer to the nth continuation clause.
			* @param nth is the continuation clauses index between 0 and GetContinuationCount()-1.
			* @return the pointer to the nth continuation clause.
			* @version 7.1.3
			*/
			inline const CSRClauseBuilderClause*		GetNthContinuation(int i)		const 			{return fContinuations[i];};

			/** Method called to display differently child clause used to computation purpose and the one used to 
			*	defined computation.
			* @param is the child clauses index between 0 and GetChildCount()-1.
			* @return true when child clause is a continuation, false otherwise.
			* @version 6.1
			*/
			virtual bool IsContinuation(int childIndex) const {return false;};

			/** Method to get the gap risk value. Gap risk can be the one defined in the clause if any or zero during computation,
			*	so gap risk must always be accessed by using this method during computation. 
			* @return the gap risk value to use.
			* @version 6.1
			*/
			double GetGapRisk() const;

			/** Method to set up which dates are needed for future simulation. Only such date must be used in future computation
			* Default implementation is to add every date needed greater or equal to today.
			* 
			* @version 6.3.2
			*/
			virtual void AddFutureDate(long today, _STL::set<long> & futureDate);

			/** Get clause payment date defined in the clause. When the payment date is set up the corresponding clause generate a cash flow,
			*	while clause without payment date are used only for computation purpose.
			*	Note that some properties can modify the real payment date.
			* @return the clause payment date defined in the clause.
			* @version 6.1
			*/
			inline long					GetPaymentDate()		const					{return fPaymentDate;};

			/** Set the clause payment date.
			* @param paymentDate is the clause payment date to set up.
			* @version 6.1
			*/
			inline void					SetPaymentDate(long paymentDate)				{fPaymentDate	= paymentDate;};	

			/** Get the last start fixing defined in the clause.
			* @return the last start fixing.
			* @version 6.1
			*/
			int					GetStartFixing()		const;
			
			/** Get the number of start fixing defined in the clause.
			* @return the number of start fixing.
			* @version 6.1
			*/
			inline int					GetStartFixingSize()	const					{return (int) fStartFixing.size();};
			
			/** Get the nth start fixing defined in the clause.
			* @return the nth start fixing.
			* @version 6.1
			*/
			inline int					GetStartFixing(int nth)	const					{return (GetStartFixingSize()>nth ? fStartFixing.at(nth) : -1);};
			
			/** Get the last end fixing defined in the clause.
			* @return the last end fixing.
			* @version 6.1
			*/
			int					GetEndFixing()			const;
			
			/** Get the number of end fixing defined in the clause.
			* @return the number of end fixing.
			* @version 6.1
			*/
			inline int					GetEndFixing(int i)		const					{return (GetEndFixingSize()>i ? fEndFixings.at(i) : -1);};
			
			/** Get the nth end fixing defined in the clause.
			* @return the nth end fixing.
			* @version 6.1
			*/
			inline int					GetEndFixingSize()		const					{return (int) fEndFixings.size();};

			/** Set the start fixing with only one value.
			* @param index is the start fixing index to set up.
			* @version 6.1
			*/
			inline void					SetStartFixing(int index) 						{SetStartFixing(_STL::vector<int>(1,index));};
			
			/** Set the start fixing with a vector of value.
			* @param indexes is the vector of start fixing indexes to set up.
			* @version 6.1
			*/
			inline void					SetStartFixing(const _STL::vector<int>& indexes){fStartFixing	= indexes;};
			
			/** Set the end fixing with only one value.
			* @param index is the end fixing index to set up.
			* @version 6.1
			*/
			inline void					SetEndFixing(int index) 						{SetEndFixings(_STL::vector<int>(1,index));};
			
			/** Set the end fixing with a vector of value.
			* @param indexes is the vector of end fixing indexes to set up.
			* @version 6.1
			*/
			inline void					SetEndFixings(const _STL::vector<int>& indexes) {fEndFixings	= indexes;};

			/**	
			* @return true for a property clause, false otherwise.
			*/
			inline bool					IsProperty()			const 					{return fIsProperty;};

			/**	
			* @return true for a exit event clause, false otherwise.
			*/
			inline bool					IsExitEvent()			const 					{return fIsExitEvent;};

			/**	
			* @return true for a payoff clause, false otherwise.
			*/
			inline bool					IsPayoff()				const 					{return fIsPayoff;};


			/**	
			* @return true if the clause is on absolute values, false if it is in percentage of the nominal.
			* @version 7.1.2
			*/
			inline bool					IsOnAbsoluteValues()				const 					{return fIsOnAbsoluteValues;};

			/** Set the type absolute/percentage of the clause.
			* @version 7.1.2
			*/
			inline void					SetIsOnAbsoluteValues(const bool isAbsolute);

			/** Initialize clause parameter to manage clause in percentage/absolute
			* @version 7.1.2
			*/
			virtual void InitializeAbsoluteClause(double notional);

			/** return true if the clause can manage absolute value on the basket underlying instead of performance
			*  @version 7.1.2                                                                   
			*/
			virtual bool IsCompatibleWithAbsoluteValues() const;

			/** return the underlying index in GUI of the forex used to convert a cashflow into the option currency.
			*	(If the forex is not defined in the underlying list defined by the user, the forex was added to the underlying list for payoff.)
			*	return -1 if the cashFlow is paid in option currency
			*  @version 7.1.2                                                                   
			*/
			inline int					GetForexIndexForCashFlow() const {return fForexIndexForCashFlow;};
			// settlement date of fx needed to convert in option currency at cash flow fixing date
			inline long					GetCashFlowFXSettlementDate() const {return fCashFlowFXSettlementDate;};
			inline void					SetForexIndexForCashFlow(int forexIndex, long cashFlowFXSettlementDate) {fForexIndexForCashFlow=forexIndex;fCashFlowFXSettlementDate = cashFlowFXSettlementDate;};

			inline int					GetForexIndexForUnderlyingCashFlow() const {return fForexIndexForUnderlyingCashFlow;};
			// settlement date of fx needed to convert in option currency at cash flow fixing date
			inline long					GetUnderlyingCashFlowFXSettlementDate() const {return fUnderlyingCashFlowFXSettlementDate;};
			inline void					SetForexIndexForUnderlyingCashFlow(int forexIndex, long cashFlowFXSettlementDate) {fForexIndexForUnderlyingCashFlow=forexIndex;fUnderlyingCashFlowFXSettlementDate = cashFlowFXSettlementDate;};
			
			virtual void				RegisterIndicator(CSRGenericIndicatorServer& genericIndicator);

			inline int					GetIndicatorCompute() const {return fIndicatorCompute;};

			/** Store all the data needed to initialise a CSRClauseBuilderClause in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring clause definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRClauseBuilderClause with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create clause on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRClauseBuilderClause.
			* @version 6.1
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);


			/**
			* Method to know clause cash flow type {@see eClausePaymentType}. Default value is eCLB_CashOptionCurrency.
			* @return clause cash flow type.
			*/
			virtual eClausePaymentType GetClausePaymentType() const;


			/**
			* Method to know if clause implementation directly create cash flow. 
			* Only relevant for clause with payment date.Default value is false and in such case 
			* {@see CSRClauseBuilderPayoffServer} will create cash folw depending on value returned.
			* @return true when clause implementation directly create cash flow. 
			*/
			virtual bool IsCashFlowManagedDirectlyByClause() const;



			virtual bool IsPhysicallyDeliveredClause() const {return false;};

			virtual double ComputePhysicalTicket(	double	& quantityByNotionalUnit,
													int		& underlyinfIndexInGUI,
													double	& cashPriceByNotionalUnit) const;


			enum eBarrierType
			{
				eBarrierUp,
				eBarrierDown
			};
			struct SSBarrierDescription
			{
				eBarrierType type;
				double		level;
			};
			/** Method to change barrier level on a clause. Default implementation update strike value;
			* @param newBarrierLevel is the new barrier level.
			* @version 6.3.3
			*/
			virtual void UpdateBarrierLevel(const _STL::vector<SSBarrierDescription> & newBarrierLevel);

			/** Method to give the barrier level on a clause. Default implementation return strike value;
			* @param newBarrierLevel is the new barrier level.
			* @version 6.3.3
			*/
			virtual void GetBarrierLevel(_STL::vector<SSBarrierDescription> & contractualBarrierLevel) const;

			/** Method to apply barrier shift on a clause.
			*	The method will look on property clause defined on this clause, and call [@see CSRMCClauseBarrierShift::ApplyBarrierShift} 
			*	on any clause inheriting from CSRMCClauseBarrierShift;
			*	@param barrierData is a pointer on a class allowing to retrieve market data. 
			* @version 6.3.3
			*/
			void ApplyBarrierShift(const market_data::CSRBarrierData * barrierData);


			inline int GetFixingEventDateIndex() const {return fFixingEventDateIndex;};
			//inline long GetFixingValueDate() const {return fFixingValueDate;};
			inline int GetFixingValueDateIndex() const {return fFixingValueDateIndex;};

			void InitializeFixingDates();

			virtual void InitAdditionalVariableID(CSRCLBStateVariable & locCLBStateVariable);

			struct SSUnderlingCodeAndlevel
			{
				long underlyingCode;
				double barrierLevel;
			};

			struct SSOneMultiUnderlyingBarrier
			{
				_STL::vector<SSUnderlingCodeAndlevel> barrierList;
				bool isUp;
				bool toReachCount;
				int indexInGui;
				_STL::string	fName;
			};

			virtual bool GetUnderlyingToMonitor(SSOneMultiUnderlyingBarrier& barrier);

		protected:

			/** 
			*	This method compute the clause. 
			*	The Method is called by {@link CSRClauseBuilderPayoffServer::ComputeClause} which is the
			*	method to call to compute children clause in order to properly manage calendar gap risk.
			*
			*  Standard clause results are in fraction of notional.
			*  In order to have an unified management of clauses for an absolute clause the absolute results is divided by option notional.
			*
			*	@return the computed value.
			*	@version 6.1
			*/
			virtual double				ComputeClause() const;

			/**
			*	Clause payment date set up in the GUI.
			*	@version 6.1
			*/
			long							fPaymentDate;	

			/**
			*	Clause payment value fixing date set up in the GUI.
			*	This is the index in the simulation manager date list.
			*	@version 6.3.2
			*/
			int								fFixingEventDateIndex;	
			int								fFixingValueDateIndex;

			/**
			* @return true when clause value depends on its child clause value. Default value is false;
			*/
			virtual bool IsValueDependOnChildClauses() const;

			/**
			* @return true when clause trigger child clause payoff (e.g. like exit clause, child clause will only be relzevant). Default value is false;
			*/
			virtual bool IsATriggerForChildClauses() const;

			/**
			* @return true when child clause hierarchically depend on current clause (it is the not the case for clause like Memory or MemoryLookback
			*			which only use child clause value to update coupon). Default value is true;
			*/
			virtual bool IsHierarchicalNodeForChildClauses() const;

			/**
			*	Vector of start fixing indexes set up in the GUI.
			*	@version 6.1
			*/
			_STL::vector<int>				fStartFixing;
			mutable int fStartFixingOptimizer;

			/**
			*	Vector of end fixing indexes set up in the GUI.
			*	@version 6.1
			*/
			_STL::vector<int>				fEndFixings;
			mutable int fEndFixingOptimizer;

			/**
			*	Vector of children clauses.
			*	@version 6.1
			*/
			_STL::vector<CSRClauseBuilderClause*>	fChildren;

			/**
			*	Vector of property clauses.
			*	@version 6.1
			*/
			_STL::vector<CSRClauseBuilderClause*>	fProperties;

			/**
			*	Vector of continuation clauses.
			*	@version 7.1.3
			*/
			_STL::vector<CSRClauseBuilderClause*>	fContinuations;

			/**
			*	true for a property clauses, false otherwise.
			*	@version 6.1
			*/
			bool						fIsProperty;

			/**
			*	true for an exit event clauses, false otherwise.
			*	@version 6.1
			*/
			bool						fIsExitEvent;

			/**
			*	true for a payoff clauses, false otherwise.
			*	@version 6.1
			*/
			bool						fIsPayoff;

			/**
			*	true for an absolute clause, false for a clause in percentage.
			*	@version 7.1.2
			*/
			bool						fIsOnAbsoluteValues;

			/** the underlying index in GUI of the forex used to convert a cashflow into the option currency.
			*	(If the forex is not defined in the underlying list defined by the user, the forex was added to the underlying list for payoff.)
			*	-1 if the cashFlow is paid in option currency
			*  @version 7.1.2                                                                   
			*/
			int							fForexIndexForCashFlow;
			long						fCashFlowFXSettlementDate;
			int							fForexIndexForUnderlyingCashFlow;
			long						fUnderlyingCashFlowFXSettlementDate;

			int							fIndicatorCompute;
			int							fCashFlowIndicator;

			/**
			* Set up the clause manager managing all clause.
			* @param clauseManager is the clause manager.
			* @version 6.1
			*/
			virtual void	SetClauseManager(CSRHierarchicalClauseManager* clauseManager);

			/**
			* Pointer to the Clause manager dedicated to manage Clause Builder Clauses.
			*/
			CSRClauseBuilderClauseManager* fClauseManager;

		public:
			/** Accessor to the simulation manager.
			*	@return a reference on the simulation manager.
			*	@version 6.1
			*/
			CSRSimulationManager&					GetSimulationManager()			const;
		};

		//--------------------------------------------------------------------------------

		/**
		* Base class for property clauses.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCClauseProperty : public CSRClauseBuilderClause
		{

		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCClauseProperty ();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCClauseProperty() ;

			/** Validation method to check that the clause is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool			EnsureClauseCoherence(_STL::string &errorMsg)	const;

		};

		/**
		*  Enum to handle chained event condition like if "on any observation period".
		*/
		enum eConditionTrigger
		{
			eConditionNotReached = 0, 
			eConditionReached,
			eLastConditionTriggerForSophis = 100
		};

		struct SOPHIS_MONTECARLO_SERVER SSOneEvent 
		{
			int clauseID;
			eConditionTrigger eventTrigger;
			double locEventProbability;

			SSOneEvent(int clauseID, eConditionTrigger eventTrigger, double proba = 1);

			const SSOneEvent& operator=(const SSOneEvent& other);
		};

		
		/**
		* Object to locally register an event, event will only be valid in the object scope.  
		*/		
		class SOPHIS_MONTECARLO_SERVER CSRLocalEvent
		{
		public:
			/**
			* Constructor to locally register an event. Do nothing when eventChain is NULL;
			*/
			CSRLocalEvent(CSRChainedEvent* eventChain, int clauseID, eConditionTrigger eventTrigger, double locProbability);
			virtual ~CSRLocalEvent();

		protected:
			CSRChainedEvent* fEventChain;
		};

		/**
		* Class to handle a chain of event, at given time 
		*/
		class SOPHIS_MONTECARLO_SERVER CSRChainedEvent
		{
		public:
			CSRChainedEvent();
			CSRChainedEvent(const CSRChainedEvent& other);

			const CSRChainedEvent& operator=(const CSRChainedEvent& other);

			virtual ~CSRChainedEvent();

			/**
			* Get the relevant number of event 
			*/
			inline int GetEventCount() const {return fEventCount;};

			/**
			* Get the event vector
			*/
			inline const _STL::vector<SSOneEvent>& GetEvents() const {return fEvents;};

			/** Method to define the tooltip help associated to the clause.
			* @return the tooltip help string.
			* @version 7.1.3
			*/
			virtual _STL::string	GetToolTipHelp()	const;

		protected:
			friend class CSRLocalEvent;
			void AddEvent(int clauseID, eConditionTrigger eventTrigger, double locEventProbability);
			void RemoveEvent();

			/**
			* Number of event
			*/
			int fEventCount;

			/**
			*	Vector storing events, there can be modre event in vector than the relevant number {@see fEventCount} due to optimization
			*/
			_STL::vector<SSOneEvent> fEvents;
		};

		class SOPHIS_MONTECARLO_SERVER CSRMCClauseBarrierShift : public CSRMCClauseProperty
		{

			DECLARATION_CLAUSEBUILDER_CLAUSE(CSRMCClauseBarrierShift )
		public:
			/** Constructor.
			* @version 6.3.3
			*/
			CSRMCClauseBarrierShift ();

			/** Destructor.
			* @version 6.3.3
			*/
			virtual ~CSRMCClauseBarrierShift() ;

			/** Method to shift a barrier clause.
			*	@param clause is a clause to shift {@see CSRClauseBuilderClause::GetBarrierLevel} and {@see CSRClauseBuilderClause::UpdateBarrierLevel}.
			*	@param barrierData is a pointer on a class allowing to retrieve market data.
			* @version 6.3.3
			*/
			virtual void ApplyBarrierShift(CSRClauseBuilderClause& clause,const market_data::CSRBarrierData * barrierData);

			/** Initialise fIsInPercent from the value field. Will be true when value is "precent" or "%".
			* @version 6.3.3
			*/
			virtual void InitSpecificData();

			/** Method to define the tooltip help associated to the clause.
			* @return the tooltip help string.
			* @version 7.1.3
			*/
			virtual _STL::string	GetToolTipHelp()	const;

		protected:
			bool fIsInPercent;
			bool fIsAbsolute;
		};


		/**
		*	Class to handle pruning of future simulation dates. 
		*	Used in Barrier clause to reduce the number of simulation dates in order to increase computation speed.
		*	Default implementation will use daily
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCClauseTimePruning : public CSRMCClauseProperty
		{

			DECLARATION_CLAUSEBUILDER_CLAUSE(CSRMCClauseTimePruning )
		public:
			/** Constructor.
			* @version 6.3.2
			*/
			CSRMCClauseTimePruning ();

			/** Destructor.
			* @version 6.3.2
			*/
			virtual ~CSRMCClauseTimePruning() ;

			/** Method to select dates needed for simulation.
			*	@param today is the current date.
			*	@param contractualDates is the vector of date contractually needed.
			*	@param simulationDates is the number of future date which will be used during simulation.
			* @version 6.3.2
			*/
			void InitializeFutureSimulationDates(	long today,
													const _STL::vector<long> & contractualDates,
													_STL::vector<long> & simulationDates)const;

			/** Initialise fDailyPeriodInWeek from the value field. Default value is 0.
			* @version 6.3.2
			*/
			virtual void InitSpecificData();
			
			/** Store all the data needed to initialise a CSRMCClauseTimePruning in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring clause definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.3.2
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRMCClauseTimePruning with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create clause on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRMCBasketManipulationClause.
			* @version 6.3.2
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Method to define the tooltip help associated to the clause.
			* @return the tooltip help string.
			* @version 7.1.3
			*/
			virtual _STL::string	GetToolTipHelp()	const;

		protected:
			int fDailyPeriodInWeek;

		};

		//--------------------------------------------------------------------------------
		/**
		* Base class for operation clauses.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCClauseOperation : public CSRClauseBuilderClause
		{

		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCClauseOperation ();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCClauseOperation() ;

			/** return true if the clause can manage absolute value on the basket underlying instead of performance
			*  @version 7.1.2                                                                   
			*/
			virtual bool IsCompatibleWithAbsoluteValues() const;

			/** Validation method to check that the clause is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool			EnsureClauseCoherence(_STL::string &errorMsg)	const;

		protected:
			virtual bool IsValueDependOnChildClauses() const;
		};

		//--------------------------------------------------------------------------------
		/**
		* Base class for payoff clauses.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCClausePayoff : public CSRClauseBuilderClause
		{
		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCClausePayoff ();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCClausePayoff();

			/** Give a pointer to the clause underlying basket.
			* @return the pointer to the clause underlying basket.
			* @see CSRMCBasketBase
			* @version 6.1
			*/
			CSRMCBasketBase*			GetUnderlyingBasket() const;

			/** Compute basket performance between the start fixing and the last end fixing. For an absolute clause performance is the end fixing value out of option notional.
			* @return the computed basket performance.
			* @version 6.1
			*/
			double						GetBasketPerformance()							const;

			/** Compute basket performance between the start fixing and a given end fixing. For an absolute clause performance is the end fixing value out of option notional.
			* @param endFixingIndex identify the end fixing to use. It must be less than the number of end fixing defined in the clause.
			* @return the computed basket performance. 
			* @version 6.1
			*/
			double						GetBasketPerformance(int endFixingIndex)		const;

			/**
			*	Set the underlying of the clause by using its identifier in the basket manager.
			*	It also set up the pointer fUnderlying.
			*/
			void						SetUnderlying(int indexInBasketMgr);

			int							GetUnderlying(){return fUnderlyingIndex;};

			/** return true if the clause can manage absolute value on the basket underlying instead of performance
			*  @version 7.1.2                                                                   
			*/
			virtual bool IsCompatibleWithAbsoluteValues() const;

			/** Validation method to check that the clause is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool				EnsureClauseCoherence(_STL::string &errorMsg)	const;

			/** Store all the data needed to initialise a CSRMCClausePayoff in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring clause definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRMCClausePayoff with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create clause on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRMCClausePayoff.
			* @version 6.1
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);

			/**
			* Optimisation method called to initialise pointer fProperties and fChildren on other clauses in base class and fUnderlying pointer. 
			* @version 6.1
			*/
			virtual void				InitialisePtr();

			/**
			* When a 
			*/
			virtual bool IsInGapArea(	double gapRiskFactor, 
										double triggerValue,
										double & greaterAboveValueWeight, 
										double & greaterBelowTriggerValueWeight) const {return false;};

		protected:

			/**
			* The clause underlying basket index in the basket manager.
			*/
			int							fUnderlyingIndex;

			/**
			* Pointer to the clause underlying basket.
			*/
			mutable CSRMCBasketBase*			fUnderlying;
		};

		//--------------------------------------------------------------------------------
		/**
		* Base class for payoff clauses handling exit event.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCExitEventClause : public CSRMCClausePayoff
		{

		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCExitEventClause ();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCExitEventClause() ;

			/** Validation method to check that the clause is properly set up.
			* @param errorMsg is the error message to fill when set up is not a valid one.
			* @return true for a valid basket, false otherwise.
			* @version 6.1
			*/
			virtual bool			EnsureClauseCoherence(_STL::string &errorMsg)	const;

			/**
			* Optimisation method called to initialise pointer fProperties and fChildren on other clauses in base class and fUnderlying pointer. 
			* @version 6.1
			*/
			virtual void InitialisePtr();

			/**
			*	Method to apply an exit event to the rate leg. 
			*	
			* @param exitTimeIndex is the exit event date index in simulation manager.
			* @param paymentTime is the rate coupon payment time. Default value = 0 means that accrued paid on exitTime anf other coupon on their payment date.
			* @param exitProbability is weighting probability of the exit case. It must be between 0. and 1. and is used 
					to handle exit probability in continuous barrier or smoothing of calendar gap risk.
			* @version 6.1
			*/
			void ResetRateLeg(int exitTimeIndex, long paymentTime = 0, double exitProbability = 1.) const;

			inline eRateLegType GetExitRateLegType() const {return fRateLegType;};
		protected:

			virtual bool IsATriggerForChildClauses() const;

			/**	Rate led type set up by a property "RateLeg", it identify the rate leg behavior in case of exit.
			*/
			eRateLegType	fRateLegType;
		};



		//--------------------------------------------------------------------------------
		/**
		* Base class for Basket Manipulation Clauses.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCBasketManipulationClause : public CSRMCClausePayoff
		{

		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCBasketManipulationClause ();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCBasketManipulationClause();

			/** Initialise fSelectBestComponent from the value field. Default value is best of, but can be changed to "WorstOf".
			* @version 6.1
			*/
			virtual void InitSpecificData();
			
			/** Store all the data needed to initialise a CSRMCBasketManipulationClause in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to bring clause definition from client side to server side.
			*
			*	@param archive is the archive in which we store data.
			* @version 6.1
			*/
			virtual void							GetStaticData(sophis::tools::CSRArchive& archive)		const;

			/** Initialise the CSRMCBasketManipulationClause with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order create clause on server side from data on client side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRMCBasketManipulationClause.
			* @version 6.1
			*/
			virtual void							SetStaticData(const sophis::tools::CSRArchive& archive);

			/**
			* Optimisation method called to initialise
			* @version 6.1
			*/
			virtual void InitialisePtr();

		protected:
			/** 
			*	This method compute the clause. 
			*	The Method is called by {@link CSRClauseBuilderPayoffServer::ComputeClause} which is the
			*	method to call to compute children clause in order to properly manage calendar gap risk.
			*	This method propagate the lock and remove and call {@link ManageBasketAndComputeClauseValue} which is the method to overload.
			*	then it call child computation which will take into account of remove and lock.
			*	to locally manage basket.
			*	@return the computed value.
			*	@version 6.1
			*/
			virtual double			ComputeClause()			const;

			/**	This method compute the clause value and may be lock or remove a basket component by calling
			*	{@link CSRMCBasketBase::Lock} and {@link CSRMCBasketBase::Remove}.
			*	@return the computed value.
			*	@version 6.1
			*/
			virtual double			ManageBasketAndComputeClauseValue() const = 0;

		protected:
			/** True when clause select the best performer, false when it select the worst performer.
			*/ 
			bool fSelectBestComponent; 

			/** Vector of basket lock and remove.
			* @see CSRMCBasketBase::BasketLock
			*/
			mutable _STL::vector<CSRMCBasketBase::BasketLock>	fBasketLocksSubstitute;  
		};


//--------------------------------------------------------------------------------
		/**
		* Base class to get an underlyingIndex from a date to calculate a fixing.
		* default case correspond to a constant function (a fixing is calculated on only one underlying)
		* useful for commo (fixing calculated on first nearby future)
		*/

		class  SOPHIS_MONTECARLO_SERVER CSRUnderlyingIndexProvider
		{
		public:
			CSRUnderlyingIndexProvider();
			virtual ~CSRUnderlyingIndexProvider();
			virtual int		GetUnderlyingIndex(int dateIndex) const  = 0;
			virtual int		GetUnderlyingIndexFromDate(long date) const  = 0;
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive)	const = 0;
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) = 0;
		};


		/**
		* Base class to handle a fixing definition like Asian, minimum or maximum.
		*/
		class  SOPHIS_MONTECARLO_SERVER CSRMCFixingBase
		{
		public:
			/** Constructor.
			* @version 6.1
			*/
			CSRMCFixingBase();

			/** Destructor.
			* @version 6.1
			*/
			virtual ~CSRMCFixingBase();

			/** Initialisation method.
			*	@param id is the fixing identifier.
			*	@param fixingType is the fixing type
			*	@param dates is the set of date indexes used to compute the fixing value.
			* @version 6.1
			*/
			void	InitFixing(	int id,
								long fixingType,
								_STL::set<int>& dates);

			/** Give the fixing name. Do not overload this method, it is defined by using macro DECLARATION_CLAUSEBUILDER_FIXING.
			* @return the fixing name.
			* @version 6.1
			*/
			virtual const _STL::string	& GetName() const	=0;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRMCFixingBase* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRMCFixingBase for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			* @version 6.1
			*/
			typedef	sophis::tools::CSRPrototype<CSRMCFixingBase, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Get the fixing identifier.
			*	@return the fixing identifier.
			* @version 6.1
			*/
			inline const int				GetId()			const			{ return fId; };

			/** Set the fixing identifier.
			*	@param id is the fixing identifier.
			* @version 6.1
			*/
			inline void				SetId(const int id) 					{ fId		= id; } ;


			/** Get the fixing type.
			*	@return the fixing type.
			* @version 6.1
			*/
			inline const int				GetFixingType()			const		{ return fFixingType; };

			/** Set the fixing type.
			*	@param id is the fixing type.
			* @version 6.1
			*/
			inline void				SetFixingType(const int fixingType) 		{ fFixingType		= fixingType; } ;

			/** Get the vector of date indexes.
			*	@return used to compute fixing value.
			* @version 6.1
			*/
			inline const _STL::set<int>&	GetDates()		const			{ return fDates;};

			/** Get the number of date used to compute fixing value.
			*	@return the number of date used to compute fixing value.
			* @version 6.1
			*/
			inline const int				GetDateCount()	const			{ return (int)fDates.size();};

			/** Set the vector of date indexes .
			*	@param dates is the vector of date indexes.
			* @version 6.1
			*/
			inline void				SetDates(const _STL::set<int>& dates) 	{ fDates	= dates; };

			/**	Compute the fixing value.
			*	@param underlyingIndex is the single stock underlying identifier.
			*	@param simulationMgr is the simulation manager {@link CSRSimulationManager} managing simulated underlying values.
			*	@param fxCompoIndex identify the forex to use if needed in a compo basket {@link CSRMCBasketBase::GetQuantoType()}.
			*	@param reverse is a boolean which is false if the component spot must be multiplied by the forex spot and true if it must be divided. 
			*	@param underlyingIndexProvider is the single stock underlying identifier provider {@link CSRUnderlyingIndexProvider}.
			*	@return the computed fixing value.
			* @version 6.1
			*/
			virtual double			GetFixingValue( int		underlyingIndex, 
													const	CSRSimulationManager* simulationMgr,
													int		fxCompoIndex = -1,
													bool	reverseOrder = false,
													const CSRUnderlyingIndexProvider*	underlyingIndexProvider = 0) const {return 0.;};

		protected:
			/**	 Fixing identifier.
			* @version 6.1
			*/
			int 					fId;

			/**	 Fixing type.
			* @version 6.3.2.9			
			*/
			long 					fFixingType;

			/**
			* Vector of date indexes used to compute fixing value.
			* @version 6.1
			*/
			_STL::set<int>			fDates;
		};


	}// end of finance
}// end of sophis

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::CSRSimulationManager::SSCLBFixingClauseDescription & fixingClause);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::CSRSimulationManager::SSCLBFixingClauseDescription & fixingClause);

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSOneSimulationFixing & simulFixing);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSOneSimulationFixing & simulFixing);



SPH_EPILOG
#endif //__MCClauseBase_H__