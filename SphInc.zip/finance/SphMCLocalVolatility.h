/********************************************************************
*	@date:		4/12/2006.
*	
*	@file:	 	SphMCLocalVolatility.h
*
*	@author		:	Martial Millet
*					Copyright (C) 2006 SOPHIS
*	
*	@purpose:	
*
*/
#ifdef WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPH_MCLocalVolatility_H_
#define _SPH_MCLocalVolatility_H_

/**
* System includes
*/
#include "SphInc/SphMacros.h"
//#include "SphTools/base/CommonOS.h"

/**
* Application includes
*/
#include "SphInc/finance/SphNewMonteCarlo.h"
#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/finance/SphMCLocalVolatilityServer.h"
#include "SphInc/finance/SphSmileModel.h"

/**
* defines
*/

/**
* typedef and classes
*/

/**
* forward declarations of classes
*/

SPH_PROLOG



namespace sophis
{
	namespace finance
	{
	
		/** Base class for local volatility path generator on client side. The aim of this class is to manage local volatility on Server side by using
			only one base class (by integration method) to handle all local volatility definition (parametric local volatility, parametric implied volatility surface,
			volatility defined by using interpolation rules on implied volatilities smile or on vanilla prices...).

			The local volatility computation is managed by class {@link finance::CSRLocalVolatilityDiffusionParameter}, and class inherited from it. 
			The diffusion parameter class are instantiated by factory {@link new_CSRDiffusionParameter} and are initialized in method {@link InitialiseDiffusionParameter}.
			For each type of volatility there is a generic Base class:
				- parametric local volatility : CSRMCVolatilitySurfaceParametricVolatilityClient : the CSRLocalVolatilityDiffusionParameter is initialized with a class inhereted from CSRVolatilitySurfaceParametric witch corresponds to the parametric local volatility model (e.g Hyperbolic, Parabolic, SVI) 
				- local volatility defined by using interpolation rules on implied volatilities can directly inherit from CSRMCDupireTermStructureVolatilityClient (e.g. CSRKahaleVolatilityClient, CSRVannaVolgaVolatilityClient
				- all local volatility surface can be approximate by a grid thanks to a CSRMCVolatilitySurfaceClient
		See financial documentation
		@see sophis::finance::CSRMCLocalVolatilityServer
		
		@version 6.3.3
		*/
		class SOPHIS_MONTECARLO CSRMCLocalVolatilityClient : public virtual CSRLocalPathGeneratorClient
		{
		public:
			/**
			* Constructor.
			*/
			CSRMCLocalVolatilityClient();

			/**
			* Copy Constructor.
			*/
			CSRMCLocalVolatilityClient(const CSRMCLocalVolatilityClient& client);

			/**
			* Destructor.
			*/
			virtual ~CSRMCLocalVolatilityClient();

			/** 
			* This method has to be implemented in order to return the name used for the prototype registration 
			* on the client and server side.

			@return  name used for the prototype registration on server side.

			* @see CSRLocalPathGeneratorServer
			* @see INITIALISE_PATHGENERATOR_CLIENT
			* @see INITIALISE_PATHGENERATOR_SERVER
			*/
			virtual _STL::string GetLocalPathGeneratorServerID() const;


			/**
			* Method called to know if the path generator is able to handle some specific feature is the path
			* generation.
			*
			*	@param feature is the feature identifier for which we want to know if it is handle by the path generator.
			*
			*	@see sophis::finance::eUnderlyingPathFeature
			*/
			virtual bool	IsPathFeatureHandled(eUnderlyingPathFeature feature) const;

			/**	Called when all fixing dates needed by payoff are know. This method can add some new dates if needed by the integration schemes.
			*
			*	@param model is the current Monte Carlo metamodel handling computation.
			*	@param instrument is the computed derivative, its allow to get specific parameters like discretization length.
			*/
			virtual	void	AddFixingForSDEIntegration(	const finance::CSROptionMonteCarloMetaModel	*model,
														const instrument::CSRInstrument				&instrument);

			/** Tell us if we must aggregate underlying and forex as a single underlying for compo diffusion.
			*	This will impact the forward prices and volatilities stored.
			*	Moreover, when we do not aggregate we need to diffuse the corresponding forex.
			* 
			*	When an underlying is compo, the true option's underlying is
			*	the spot S multiplied by the forex rate FX. In Black and Scholes
			*	framework S*FX is treated as a one dimentional processus with forward
			*	equal to the underlying forward multiplied by FX forward and with volatility
			*	given by {@link CSRMarketData::GetCompoVolatility}.
			* 
			*	@return true if we must aggregate, false else. 
			*/
			virtual bool	AggregateFXForCompoDiffusion() const {return false;};

			/** Tell us if we adjust the forward of quanto underlying by using Black and Scholes
			*	quanto adjustment. In this case quanto diffusion is only modified by constant
			*	quanto adjustment. In order to take into account of smile in the quanto drift
			*	we must return false then manage quanto drift change during integration.
			* 
			*	@return true if we must adjust forward stored, false else.
			*/
			virtual bool	UseBSQuantoForward() const {return false;};

			/** Give the number of normal law needed for an underlying to simulate one step integration. 
			*	Default implementation return 1 for Euler-Maruyama SDE integration.	
			*
			*	@return the number of normal law needed for an underlying to simulate one step integration. 
			*/
			virtual int		GetNormalLawSizeByUnderlyingForOneStep() const;


			/** Give the number of uniform law needed for an underlying to manage a path feature on one step integration. 
			*
			*	@param feature is the feature type for which we want to add fixings.
			*
			*	@return the number of uniform law needed for an underlying to manage a path feature on one step integration. 
			*/
			virtual int		GetUniformLawNeededForOneStep(eUnderlyingPathFeature	feature) const;

			/**  Store in an archive {@link sophis::tools::CSRArchive} the result of the Monte Carlo simulation. These data can be used to initialise
			*	another Server output or a Client output.
			*	@param archive is the archive storing the data needed to initialise the CSRClientOutput in order to finalise computation.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/** Store all the data needed to initialise a CSRServerOutput in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRServerOutput for the Monte Carlo loop on the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** Factory for initialization of parameters for the volatility model.

			@return a pointer on a new {@link CSRDiffusionParameter} used to store diffusion 
			parameters needed by the model on the server side.
			*/
			virtual CSRDiffusionParameter* new_CSRDiffusionParameter() const = 0;

			/** Initialise diffusion parameters corresponding to a market data.

			@param diffusionParameter is a pointer on the  {@link CSRDiffusionParameter} to initialize.
			@param param is the {@link CSRMarketData} to use for initialization.
			@param nthUnderlying is the index of the diffused underlying for which diffusion parameter must be initialized.
			@param model is a pointer on the metamodel needing such diffusion parameter. 
			@param instrument is the instrument to price.
			@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 

			@return true when everything is fine, false otherwise.
			*/
			virtual bool	InitialiseDiffusionParameter(	CSRDiffusionParameter				*diffusionParameter,
															const market_data::CSRMarketData	&param,
															int									nthUnderlying, 
															const CSROptionMonteCarloMetaModel	*model,
															const instrument::CSRInstrument		&instrument,
															const SSBumpKey						&bumpKey) const;

			
			/** A method to know if diffusion will need NLU coefficient a and b for underlyings.
				In local volatility model volatility is dependent on the spot level, so we usualy need NMU coeffcients.

			@return true if NMU coefficient are needed, false otherwise. Default implementation return the same result as {@link UseCashVolatility}.
			*/
			virtual bool	UseNMUCoefficient() const {return true;};

			/** Optimization method called after setting time grid and size of uniform laws needed in order to initialise 
			only once some data with the relevant data size.
			*/ 
			virtual void	InitialiseDimension();

			/** This method is called for each price computed in order to set variables:
			{@link fStoreMarketDataDependantInfo}, {@link fStoreCorrelation}, {@link fIsThetaComputation} 
			and {@link fIsBasicComputation}. 

			@see StoreMarketDataDependantInfo
			@see StoreCorrelation

			@param param is the market data.
			@param option is the option to price.
			@param model is the Monte Carlo meta-model used.
			@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 

			*/
			virtual void	InitialiseData(	const market_data::CSRMarketData	&param,
											const instrument::CSRInstrument*					instr,
											const CSROptionMonteCarloMetaModel	*model,
											const SSBumpKey						&bumpKey) ;

			void InitializeStrikeGrid(	const market_data::CSRMarketData		&param,
										const CSROptionMonteCarloMetaModel		*model,
										int										nthUnderlying,
										NSREnums::eVolatilityType				volType,
										_STL::map<long, _STL::vector<double>>	&smileMap) const;

			/*Initialize bias for predictor corrector diffusion method used on server side
			*/
			void InitializeBiasForPredictorCorrector(	int										nthUnderlying,
														CSRLocalVolatilityDiffusionParameter&	localVoldiffParameter,
														long									computationDate, 
														_STL::map<long, _STL::vector<double> >	&smileMap) const;

			
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;

		protected:

			void Initialize(const CSRMCLocalVolatilityClient& client);

			/**	Method to add some fixing in time grid in order to manage specific features.
			*	Default implementation add start and end dates.
			*	
			*	@param feature is the feature type for which we want to add fixings.
			*	@param startDate is the start date for the corresponding feature period.
			*	@param endDate is the end date for the corresponding feature period.
			*	@param level identify the level for the specific feature (eg example for a barrier this is the barrier level).
			*/
			virtual void	AddFixingForFeatureToManage(	eUnderlyingPathFeature	feature,
															long					startDate,
															long					endDate,
															double					level);
		};

		

		/** Client side base class for local volatility path generator computing local volatility by using Dupire's formula from implied volatility 
		defined by smiles given from several maturities.

		@see sophis::finance::CSRMCLocalVolatilityClient

		@version 5.3.3
		*/
		class SOPHIS_MONTECARLO CSRMCDupireTermStructureVolatilityClient : public virtual CSRMCLocalVolatilityClient
		{
		public:
			/**
			* Constructor.
			*/
			CSRMCDupireTermStructureVolatilityClient();

			/**
			* Copy Constructor.
			*/
			CSRMCDupireTermStructureVolatilityClient(const CSRMCDupireTermStructureVolatilityClient& client);

			/**
			* Destructor.
			*/
			virtual ~CSRMCDupireTermStructureVolatilityClient();

			/** Initialise diffusion parameters corresponding to a market data. There is no need to overload this method. One must overload 
				{@link InitialiseSmile} to initialise vanilla price intrepolator.

			@param diffusionParameter is a pointer on the  {@link CSRDiffusionParameter} to initialize.
			@param param is the {@link CSRMarketData} to use for initialization.
			@param nthUnderlying is the index of the diffused underlying for which diffusion parameter must be initialized.
			@param model is a pointer on the metamodel needing such diffusion parameter. 
			@param instrument is the instrument to price.
			@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 

			@return true when everything is fine, false otherwise.
			*/
			virtual bool	InitialiseDiffusionParameter(	CSRDiffusionParameter				*diffusionParameter,
															const market_data::CSRMarketData	&param,
															int									nthUnderlying, 	
															const CSROptionMonteCarloMetaModel	*model,
															const instrument::CSRInstrument		&instrument,
															const SSBumpKey						&bumpKey) const;

			

		protected:
			void Initialize(const CSRMCDupireTermStructureVolatilityClient& client);

			bool InitializeSmileMap(	CSRDiffusionParameter						*diffusionParameter,
										const market_data::CSRMarketData			&param,
										int											nthUnderlying, 	
										const CSROptionMonteCarloMetaModel			*model,
										const instrument::CSRInstrument				&instrument,
										const SSBumpKey								&bumpKey,
										/*out*/long									&underlyingCode,
										/*out*/long									&computationDate,
										/*out*/NSREnums::eVolatilityType			&volType,
										/*out*/CSRVolatilitySurfaceTermStructure*	&dupireTermStructure) const;

			/** 
			* 
			*/
			mutable _STL::map<long, _STL::vector<double> > fSmileMap;
		};

	} // end of namespace

}// end of namespace sophis



/**
* Globals
*/

/**
* Inline Methods
*/

SPH_EPILOG

#endif // _SPH_MCLocalVolatility_H_