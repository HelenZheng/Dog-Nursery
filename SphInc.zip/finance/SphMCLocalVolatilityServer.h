/********************************************************************
*	@date:		4/12/2006.
*	
*	@file:	 	MCLocalVolatilityServer.h
*
*	@author		:	Martial Millet
*					Copyright (C) 2006 SOPHIS
*	
*	@purpose:	
*
*/
#ifdef WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPH_MCLocalVolatilityServer_H_
#define _SPH_MCLocalVolatilityServer_H_

/**
* System includes
*/
#include "SphInc/SphMacros.h"
//#include "SphTools/base/CommonOS.h"

/**
* Application includes
*/
#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/finance/SphVolatilitySurface.h"
#include "SphMathTools/SphInterpolation.h"

namespace sophis {
	namespace finance {
		class CSRVolatilitySurface;
		class CSRLocalVolatilityDiffusionParameter;
	}
}

/**
* defines
*/

/**
* typedef and classes
*/
//class CSROptionMonteCarloMetaModel;
//class CSRCallInterpolationVolatilityClient;

/**
* forward declarations of classes
*/

SPH_PROLOG



namespace sophis
{
	namespace finance
	{

		class CSRMCLocalVolatilityServer;

		class SOPHIS_MONTECARLO_SERVER CSRForwardFromPathGenerator : public sophis::finance::CSRForwardPriceCalculator
		{
			DECLARATION_FORWARDPRICECALCULATOR(CSRForwardFromPathGenerator)
		public:
			CSRForwardFromPathGenerator();
			virtual ~CSRForwardFromPathGenerator();

			/**
			*  Set the callback to {@link CSRMCLocalVolatilityServer} and the number of the diffused underlying
			* @since 6.3.3
			*/
			void Initialize(const CSRMCLocalVolatilityServer & localvolatilityserver, int NthUnderlying);

			/**
			*  Get the spot of the nth diffused underlying of the localVolatilityServer
			* @since 6.3.3
			*/
			virtual double GetSpot() const;
			

			/**
			* Get the forward Price stored in the localVolatilityServer, for the nth Underlying and the nthDate corresponding to maturityInDay
			* Found the nthDate thanks to {@link GetIndexFromDate}
			* @since 6.3.3
			*/
			virtual double	GetForwardPrice(double maturity) const;
			
			/** Get the drift stored in the localVolatilityServer, for the nth Underlying and the nthDate corresponding to maturity
			* Found the nthDate thanks to {@link GetIndexFromDate}
			* @param maturity is the maturity in day
			* @result is the drift of the forward price at the nthDate corresponding to maturity
			* @since 6.3.3
			*/
			virtual double GetDrift(double maturity) const;
			
			/**	Get the forward for the maturity {@param maturity} and a reference value {@param spotLevel} at a null maturity
			@param spotLevel is a reference value at a null maturity
			@param maturity is the maturity in day

			@return the forward value for this maturity and spot value
			@since 6.3.3
			*/
			virtual double GetForwardForVolatility(double spotLevel,double maturity) const;
			/**
			* Compute the drift between the computation date @param computationDate and the first simulation date and between two consecutive simulations dates @param dates
			* Called by {@link CSRMCLocalVolatilityServer::SetData}
			* @since 6.3.3
			*/
			void FillDriftVector(	const double					computationDate,
									const double					spot,
									const _STL::vector<long>		&dates,
									const _STL::vector<double>		&forward, 
									/*out*/ _STL::vector<double>	&drift);

		protected:
			const CSRMCLocalVolatilityServer* fLocalVolatilityServer;
			int fNthUnderlying;


		};

		/** Base class for local volatility model path generator on server side
		* 
		*/
		class SOPHIS_MONTECARLO_SERVER CSRMCLocalVolatilityServer : public virtual CSRLocalPathGeneratorServer
		{
		public:
			DECLARATION_PATHGENERATOR_SERVER(CSRMCLocalVolatilityServer)
			/** 
			* Constructor.
			*/
			CSRMCLocalVolatilityServer();

			/** 
			* Destructor.
			*/
			virtual ~CSRMCLocalVolatilityServer();

			/** Generate the underlying sampling by using last uniform law sample.
			*/
			virtual void GenerateSampling();

			/**
			* Method called to know if the path generator is able to handle some specific feature is the path
			* generation.
			*
			*	@param feature is the feature identifier for which we want to know if it is handle by the path generator.
			*
			*	@see sophis::finance::eUnderlyingPathFeature
			*/
			virtual bool IsPathFeatureHandled(eUnderlyingPathFeature feature) const;

			/** Return true is antithetic sampling can be used, else return false.
			*/
			virtual bool CanUseAntitheticSampling() const {return true;};

			/** This method compute the equivalent local volatility for a payoff for underlying by assuming
			*	local log normal diffusion of the underlyings in order to compute path feature.
			*
			*	@param underlyingIndexForpayOff is the index of the underlyings for payoff.
			*	@param timeStepIndex is an index between 0 and fTimeCount-1.
			*	@param	antitheticSamplingIndex is the number ID for the antithetic sampling.
			*
			*	@return the equivalent local volatility for a payoff for underlying by assuming local log normal diffusion of the underlyings.
			*/
			virtual double GetVolatilityForPayoffUnderlying(int underlyingIndexForpayOff, int timeStepIndex,  int antitheticSamplingIndex) const;
			
			/** This method return the stochastic volatility of the path
			*	local log normal diffusion of the underlyings in order to compute path feature.
			*
			*	@param nthUnderlying is the index of the underlying
			*	@param nthdate is an index between 0 and fTimeCount-1.
			*	@param nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the equivalent local volatility for a payoff for underlying by assuming local log normal diffusion of the underlyings.
			*/

			virtual double GetVolatilityPathOfDiffusedUnderlying(int nthUnderlying, int nthdate, int nthAntitheticSampling) const;
			
			/** Initialise the CSRLocalPathGeneratorServer with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order to create one or several payoff object on the server side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRLocalPathGeneratorServer
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Initialise the market data dependent data in CSRLocalPathGeneratorServer with the data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRClientOutput.
			*	When called fCurrentTask is settled to the relevant value so that market data dependent data can be stored and accessed relevantly according to the current task durring computation.
			*
			*	@param archive is the archive storing the data needed to initialise market data dependent data in CSRLocalPathGeneratorServer.
			*	@since 6.3.3
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			
			/** Give the forward price at a date potentially different from the fixing date of the path generator time grid fFixingDateMap
			*	Called by GetLocalVolatility to estimated the implied vol time derivative by finite difference : the forward need to be evaluated at date t_i + h
			*	The forward is interpolated between two fixing date with a constant exponential drift 
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param maturityInDay is a maturity expressed in day (from date computationDate) at which we need forward price.
			*	
			*	@return the forward price of underlying really diffused for maturity maturityInDay. 
			*	@since 6.3.3
			*/
			double GetForwardPriceAllMaturity(int nthUnderlying, double maturityInDay)const;
			
			/** Give the forward price at a date potentially different from the fixing date of the path generator time grid fFixingDateMap, and for a spot value different from the real spot of the underlying
			*	Called by GetMoneynessLevel to build the volatility surface. Use the nmu coefficient a and b to calculate the forward with the new spot spotlevel
			*	The forward is interpolated between two fixing date with a constant exponential drift 
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param spotLevel is a value of the spot from which you need to calculate the forward
			*	@param maturityInDay is a maturity expressed in day (from date computationDate) at which we need forward price.
			*	
			*	@return the forward price of underlying really diffused for maturity maturityInDay and spot value spotLevel. 
			*	@since 6.3.3
			*/
			double GetForwardForMoneyness(int nthUnderlying,double spotLevel, double maturityInDay)const;
			
			/** Give the drift of the forward price at a date corresponding to a fixing date of the path generator time grid fFixingDateMap, zero otherwise
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param maturityInDay is a maturity expressed in day (from date computationDate) at which we need forward price.
			*	
			*	@return the drift forward price of underlying really diffused for maturity maturityInDay. 
			*	@since 6.3.3
			*/
			double CSRMCLocalVolatilityServer::GetDrift(int nthUnderlying, double maturityInDay)const;

		protected: 
			_STL::vector< _STL::vector<double> > fDriftBuffer;

			_STL::vector<CSRForwardFromPathGenerator> fForwardPriceCalculator;
			
		};

		enum eLocalVolDiffusionMethod
		{
			eEulerScheme = 1,
			ePredictorCorrector,
			eVarianceDiscreteForward
		};

		/**
		* Generic class handling local volatility diffusion parameters.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRLocalVolatilityDiffusionParameter : public virtual CSRDiffusionParameter
		{
		public:
			DECLARATION_DIFFUSION_PARAMETER(CSRLocalVolatilityDiffusionParameter)
			/**
			* Constructor.
			*/
			CSRLocalVolatilityDiffusionParameter();

			/**
			* Destructor.
			*/
			virtual ~CSRLocalVolatilityDiffusionParameter();

			/** Method to compute the local volatility.
			
			@param maturityIndex is the index of the time step in the path generator
			@param computation_date is the date corresponding to a null maturity
			@param spot	is the spot at beginning of the time step
			@param localVolDerivative is an output : the derivative of local volatility

			@return local volatility for a given time step.
			*/
			virtual double GetLocalVolatility(	int		maturityIndex, 
												double	computation_date,
												double	spot,
												double	*localVolDerivative = NULL) const ;

			virtual _STL::string	GetDiffusionParameterID() const;

			/** Method called on client side to know if in the current computation we need to initialise 
			*	volatility model parameter or if we can use the same as the one used in basic theoretical 
			*	price computation. 
			* 
			*	@param dataToUseType is an input vector with index corresponding to enum {@link sophis::finance::eMCDataType}
			*	allowing to know for the current computation which basic data are changed.
			*
			*	@return true if we can use basic price parameters and false if we must use specific diffusion parameters.
			*/

			virtual bool	IsSameAsBasicOne(const _STL::vector<eDataToUseType>& forwardToUseType) const;


			/** Store volatility model data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRDiffusionParameter with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRDiffusionParameter::GetData}.
			*
			*	@param archive is the archive storing the data needed for volatility model initialisation.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			
			/** Method called on server side just after {@link CSRDiffusionParameter::SetData} in order to allow some optimisation.
			*/
			virtual void InitialiseOptimisation();
			
			/* Set the CSRForwardPriceCalculator in the fVolatilitySurface object
			@param forwardPriceCalculator is the forward price calculator to be set
			*/
			void SetForwardPriceCalculator(CSRForwardPriceCalculator* forwardPriceCalculator);
			
			/* @return the index of the underlying in the CSRLocalPathGeneratorServer object
			*/
			inline int GetUnderlyingIndex() const {return fUnderlyingIndex;};
			
			/* @param underlyingIndex is the index of the underlying in the CSRLocalPathGeneratorServer object to be sete
			*/
			inline void SetUnderlyingIndex(int underlyingIndex) {fUnderlyingIndex = underlyingIndex;};
			
			/* @param maturityVector is the vector of maturity (in day) to be stored
			*/
			inline void SetMaturityVector(const _STL::vector<double> &maturityVector) {fMaturityVector = maturityVector;};

			/* @param maturityVector is the vector of maturity (in day) to be stored
			*/
			inline const _STL::vector<double> & GetMaturityVector() {return fMaturityVector;};
			
			/* @return the volatility surface object
			*/
			inline CSRVolatilitySurface* GetVolatilitySurface() {return fVolatilitySurface;};
			
			/* @param volsurface is the volatility surface object to be stored
			*/
			void SetVolatilitySurface(CSRVolatilitySurface* volsurface);
			
			eLocalVolDiffusionMethod GetDiffusionMethod() const {return fDiffusionMethod;};

			void SetDiffusionMethod(eLocalVolDiffusionMethod diffusionMethod){fDiffusionMethod = diffusionMethod;};

			double GetDriftCorrection(int nthdate,double sportStart) const;

			void resizeGrid(long size);

			void AddSmile(int timeStep,const _STL::vector<double> &strikes,_STL::vector<double>& expectation);
			
			inline void SetOverVolatility(double overVolatility) {fOverVolatility = overVolatility;};
		protected:
			CSRVolatilitySurface* fVolatilitySurface;

			// to handle overvolatility
			CSRVolatilitySurface* fBasicVolatilitySurface;
			
			_STL::vector<math::CSRInterpolation*> fExpectationsGrid;

			_STL::vector<double> fMaturityVector;


			/** Additive over volatility of the instrument according to user preferences.
			*/
			double fOverVolatility; // 

			/** Index of underlying in the path generator.   
			*/
			int fUnderlyingIndex;
			eLocalVolDiffusionMethod fDiffusionMethod;
		};
		
			
	} // end of namespace

}// end of namespace sophis



/**
* Globals
*/

/**
* Inline Methods
*/

SPH_EPILOG

#endif // _SPH_MCLocalVolatilityServer_H_
