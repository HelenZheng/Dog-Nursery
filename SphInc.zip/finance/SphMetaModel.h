/*
 	File:		SphMetaModel.h
 
 	Contains:	Class for the handling of a meta model
 
 	Copyright:	� 2004 Sophis.
*/

/*! \file SphMetaModel.h
	\brief For the handling of a meta model.
*/

#pragma once


#ifndef _SPH_META_MODEL_
#define _SPH_META_MODEL_

#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(memory)

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/gui/SphNewDialog.h"
#include "SphInc/gui/SphDialog.h"
#include "SphInc/SphPreferenceEnums.h"
#include "SphInc/instrument/SphSwap.h"
#include "SphInc/instrument/SphCapFloor.h" //BR-30.11.2006 CLR
#include "SphInc/SphMacros.h"
#include "SphInc/SphComputationResults.h"
#include "SphInc/instrument/SphInstrumentEnums.h"
#include "SphInc/market_data/SphVolatility.h"
//#include "finance_v2/classefinanrisque.h"


#define DECLARATION_META_MODEL(derivedClass)							\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRMetaModel)	\
	public: derivedClass();

#define CONSTRUCTOR_META_MODEL(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_META_MODEL(derivedClass)
#define	INITIALISE_META_MODEL(derivedClass, name)	\
	INITIALISE_PROTOTYPE(derivedClass,  name) \
	{ sophis::finance::CSRMetaModel* __protModel = const_cast<sophis::finance::CSRMetaModel*>( sophis::finance::CSRMetaModel::GetPrototype().GetData(name) ); \
	__protModel->SetName(name); }

static bool __badMetaModelAssert = true;
#if _DEBUG
	#define BAD_META_MODEL if (__badMetaModelAssert) ASSERT("Bad meta model.");
#else
	#define BAD_META_MODEL ;
#endif

#if (!defined(WIN32)&&!defined(_WIN64))
#include "SphInc/instrument/SphOption.h"
#endif


SPH_PROLOG
namespace sophis {
	namespace instrument {
		
		class CSRInstrument;
		class CSROption;
		class CSRCoxTreeGraphics;
		enum eGreekParameterType;
		enum eUnderlyingComputationType;
		struct SSParametersOfDerivation;
		
		//struct SSCaplet; //BR-30.11.2006 CLR
	}

	namespace market_data	{
		class CSRMarketData;
	}
	namespace finance
	{
		class SSMetaModelHandler;


		/**
		 * Internal method. It is used to generate versioning on calibration results.
		 * Return the next calibration ID.
		 */
		SOPHIS_FIT long GetNewCalibrationID();

		/** Interface to define a meta model.
		It is used to define a model which will be applied to the instrument.
		It implements an ISRNewDialog in case your extraction needs extra data.
		To add a new meta model, derive that class and install it in the prototype.
		@since 5.0
		*/
		class SOPHIS_FIT CSRMetaModel : public gui::ISRNewDialog
		{
		public:
			//virtual void ForceOverride() = 0;

			/** Trivial constructor.
			Note that the constructor has no parameter, which means that at the opposite of other classes,
			you cannot get your own parameters in the constructor; you can do it in the Initialise. 
			@see Initialise
			*/
			CSRMetaModel();

			/** Copy constructor.
			*/
			CSRMetaModel(const CSRMetaModel &model);

			/** Assignation.
			*/
			CSRMetaModel & operator =(const CSRMetaModel &model);

			/** Destructor.
			*/
			virtual ~CSRMetaModel();


			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_META_MODEL.
			@see tools::CSRPrototype
			*/
			virtual CSRMetaModel* Clone() const = 0;

			/** Clone method called to create the object to be used for pricing.
			Default implementation returns a clone.
			@see tools::CSRPrototype
			*/
			virtual CSRMetaModel* CloneForPricing(const instrument::CSRInstrument& instrument) const;

			/**
			 * This method instances a way to compute risk sources for an instrument.
			 * available for caps/floors uniquely.
			 */
			//virtual instrument::CSRGreekValues* new_GreekValues(const instrument::CSRInstrument& instrument) const;

			/**
			 * This method returns the name of this model.
			 @version 7.1.3.2
			 */
			std::string GetName() const;
			void SetName(const char* name);


			/** Use this method to store useful data for pricing of an instrument 
			* in the meta model linked with an instrument. @see CSRInstrument::GetMetaModel.
			* @return false if the initialisation of data has failed.
			*/
			virtual bool InitialiseDataFromInstrument(	const instrument::CSRInstrument		&instrument,
														const market_data::CSRMarketData	&marketData,
														bool								computeGreeks);

			/** Initialisie the meta model of this instrument.
			* Use this method to store the meta model in the instrument to avoid initialising when calculating greeks by finite difference.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param computeGreeks is asking for greek context loading (parameter gived to {@link InitialiseDataFromInstrument}.
			@param forceLoading is a boolean to force the loading and go to optimise mode.
			* @return false if the initialisation of data has failed.
			* @see CSRInstrument::GetMetaModel.
			*/
			virtual bool InitialiseMetaModel(const instrument::CSRInstrument	&instrument,
									const market_data::CSRMarketData	&marketData,
									bool computeGreeks, bool forceLoading = false) const;

			/** Release the meta model if no optimisation.
			Call that method at the end of your calculation.
			@param instrument is the instrument to price.
			@param forceLoading is a boolean to force the release and go to non-optimise mode.
			*/
			virtual void ReleaseMetaModel(const instrument::CSRInstrument & instrument, bool forceRelease = false) const;

			/** Run calibration if needed and store result. It is called by the calibration scenario.
			By default this method does nothing.
			@param instrument is the instrument to price.
			@param context is the market data to use for calibration.
			@param alreadyCalibrated is a set to allow not to calibrate 2 times the same underlying for a given metamodel.
					It must be filled during calibration.
			@return true is the calibration was run successfully and results saved. By default return false.
			@since 5.3
			*/
			virtual bool	RunCalibration(	const instrument::CSRInstrument				&instrument, 
											const sophis::market_data::CSRMarketData	&context,
											_STL::set<long>*							alreadyCalibratedUnderlying);


			/** Run calibration if needed and store result. It is called by the calibration scenario.
			By default this method does nothing.
			@param instrument is the instrument to price.
			@param context is the market data to use for calibration.
			@param alreadyCalibrated is a set to allow not to calibrate 2 times the same underlying for a given metamodel.
			@param calibrationID is the ID of the versioning for calibration. It is used to optimize calibration {@see fCalibrationID}.
			It must be filled during calibration.
			@return true is the calibration was run successfully and results saved. By default return false.
			@since 5.3
			*/
			bool	RunCalibrationWithID(   const instrument::CSRInstrument				&instrument, 
											const sophis::market_data::CSRMarketData	&context,
											_STL::set<long>*							alreadyCalibratedUnderlying,
											long										calibrationID);

			/** Set a pointer to the computation results
			By default this method does nothing. It is used for optimisation for the display of swaps.
			@param results is the computation results
			@since 7.1.2
			*/
			virtual void	SetComputationResults(sophis::CSRComputationResults& results) const;

			/** Get the forward prices.
			@param futureDate is an array of expiries of the forward, in number of days from 1/1/1904.
			@param val is an output array for the values, which must be effectively allocated.
			@param dateCount is the number of dates in the array.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			@param const instrument::CSRInstrument*			initialForward = NULL when we arrived from a forward
			This method is used in model option with NMU, to give the drift
			of the underlying. As there is normally more than one forward to calculate
			and a significant optimisation to calculate a list of forwards,
			this method is called for each expiry date.
			The default implementation is to call it for each expiry date.
			@see GetForwardPrice(long futureDate, eTaxCreditPercentageType forEvaluation, const market_data::CSRMarketData& context)
			@since 3.6
			*/
			virtual void	GetForwardPrice(const instrument::CSRInstrument&			instrument, 
											long*										futureDates,
											double*										val,
											short										dateCount,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData&			context,
											const instrument::CSRInstrument*			initialForward = NULL) const;

			/** Get the forward price.
			@param futureDate is the expiry of the forward, in number of days from 1/1/1904.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param context is the market data.
			This method is used in model option where NMU is used to give the drift
			of the underlying. It may not be the forward of the spot but of another underlying.
			The real value of the spot will be calculated by GetValue.
			By default, if there is an arbitrage with underlying model, check with the arbitrage, otherwise
			return the cash value.
			@see GetValue
			@see GetLinearValue
			*/
			virtual double	GetForwardPrice(const instrument::CSRInstrument				&instrument, 
											long 										futureDate,
											market_data::eTaxCreditPercentageType		forEvaluation,
											const market_data::CSRMarketData			&context,
											const instrument::CSRInstrument*			initialForward = NULL) const;
			double	GetForwardPrice(const instrument::CSRInstrument				&instrument,
									double 										futureDate,
									market_data::eTaxCreditPercentageType		forEvaluation,
									const market_data::CSRMarketData			&context,
									const instrument::CSRInstrument*			initialForward = NULL)const;

			static void GetFRAFromInitialForward(	const DTitre*						futur,	 
													long								futureDate, 
													const market_data::CSRMarketData	&param, 
													const instrument::CSRInstrument		&instr, 
													double								&val );

			/** Get the forward quanto prices.
			@param futureDate is an array of expiries of the forward, in number of days from 1/1/1904.
			@param val is an output array for the values, which must be effectively allocated.
			@param dateCount is the number of dates in the array.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param strikeCurrency is the strike currency.
			@param overVolatility is an over volatility added to the standard volatility of the underlying coming from the option.
			@param volatType is the volatility curve to use.
			@param put is a boolean to use the put or call volatility.
			@param context is the market data.
			This method is used in model option with NMU, to give the drift
			of the underlying fixed by the quanto effect. As there is normally more than one forward to calculate
			and a significant optimisation to calculate a list of forwards,
			this method is called for each expiry date.
			The default implementation is to call GetForwardPrice and to apply the classical drift on each forward.
			@since 5.0.4
			*/
			virtual void	GetForwardQuantoPrice(	const instrument::CSRInstrument& instr,
													long					 *futureDates,
													double					 *val,
													int					 dateCount,
													market_data::eTaxCreditPercentageType forEvaluation,
													long strikeCurrency,
													double overVolatility,
													NSREnums::eVolatilityType volatType,
													bool put,
													const market_data::CSRMarketData		 &context) const;

			/** Get the fair value of the instrument.
				@param instrument is the instrument to price.
				@param context is a market data.
				@return the fair value in the same unit as the last, but with accrued coupon included
				so that the total value of the position is GetQuotity()*GetTheoriticalValue().
				This is the main method to overload, to implement a meta model. All other methods have
				a default implementation by finite difference of that function. This function is also directly
				called in most of the scenarios. Note that the fair value displayed, generally differs from the
				result of this one by a possible accrued coupon.
				The fair value must be calculated using the P&L volatility, assuming the delivery is in
				{@link GetSettlementDate}.
				By default, call the version with a graph.
			*/
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;

			/** Get the fair value of the instrument building a graph if needed.
				@param instrument is the instrument to price.
				@param context is a market data.
				@param graph is a pointer which may be null to fill eventually the graphic points. 
				@return the fair value in the same unit as the last, but with accrued coupon included
				so that the total value of the position is GetQuotity()*GetTheoriticalValue().
				It is called directly when a graph is wanted for a pricing or by default for the version without graph.
				The fair value must be calculated using the P&L volatility, assuming the delivery is in
				{@link GetSettlementDate}.
				By defauls throw NotImplemented
			*/
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, instrument::CSRCoxTreeGraphics *graph) const ;

			/**
			 * By default calls GetTheoreticalValue without info vector and does not fill it.
			 */
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument			&instrument, 
												const market_data::CSRMarketData		&context, 
												_STL::vector<instrument::SSCaplet>		*vectorToFill,
												instrument::CSRCashFlowInformationList* explanation, 
												int										startFlowIndex = -1,
												int										endFlowIndex   = -1) const;

					/** Get the delta of one instrument risk source.
					@param instrument is the instrument to price.
					@param context is a market data.
					@param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
					@return the delta expressed in the currency of the instrument as a variation
					of the fair value, for a variation 1 of the underlying.
					The delta must be calculated using the Risk volatility.
					By default, calls {@link GetPriceDeltaGamma}
				*/

			virtual double GetFirstDerivative(const instrument::CSRInstrument& instrument, const market_data::CSRMarketData &context, int undlCode) const;


					/** Get the gamma of the risk source for two instruments.
						@param instrument is the instrument to price.
						@param context is a market data.
						@param undlCode1 is the first underlying code.
						@param undlCode2 is the second underlying code.
						@return the gamma or crossed gamma expressed in the currency of the instrument as a variation
						of the delta of one instrument, for a variation 1 of the others.
						The gamma must be calculated using the risk volatility.
						By default, calls {@link GetPriceDeltaGamma} if which1 equals which2, otherwise it calculates
						by finite difference, using the smile calculation hypotheses.
						@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
						to a code (sicovam, currency, ...)
					*/
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int undlCode1, int undlCode2) const;

			/** Get the price, delta and gamma of one risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param price is an output paramater the fair value.
			@param delta is the output parameter for the delta expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1 of the underlying spot.
			@param gamma is the output parameter for the gamma expressed in the currency of the instrument as a variation
			of the delta, for a variation of 1 of the underlying spot.
			@param undlCode is the underlying code
			All, including price must be calculated using the Risk volatility.
			The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}.
			This method is called By CSRInstrument::RecomputeAll to save calculation,
			by the method CSRInstrument::GetFirstDerivative and GetSecondDerivative,
			as well as scenarios like risk matrix, asking for price, delta and gamma.
			By default, the algorithm is:
			- Ask {@link GetDerivationParameters} with gpDelta to get the selected bump.
			- Ask {@link GetSmileInDeltaGamma} to get the desired method for taking the smile into account.
			- Creates a new market data, switching the volatility
			- Bumps {@link CSRMarketData::GetSpot} or {@link CSRMarketData::GetForex} if it is an FX.
			- Bumps also {@link CSRMarketData::GetSpotForVolatility} if the smile has to be included in delta and/or gamma.
			- Do the finite difference.
			- Calculates the finite difference calling {@link GetTheoriticalValue}.
			@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
			to a code (sicovam, currency, ...)
			@version 4.4 In case the underlying is a currency and CSRPreference::ForexFinancing is on,
			the delta and gamma are corrected to be expressed in the function of the day spot, rather than on the
			spot delivery in two days.
			@version 4.1.1 The algorithm has been reviewed so that the smile effect is always included
			in that function. That is why {@link GetPriceSmiledDeltaGamma} has been deprecated.
			*/
			virtual void	GetPriceDeltaGamma(	const instrument::CSRInstrument & instrument,
												const market_data::CSRMarketData& context,
												double				*price,
												double				*delta,
												double				*gamma,
												int 				undlCode) const;

			/** Get the delta and gamma of one risk source.
			This method is called by RecomputeAll for the second risk souces to save calculation
			of the fair value..
			@param context is a market data.
			@param delta is the output parameter for the delta expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1 of the underlying spot.
			@param gamma is the output parameter for the gamma expressed in the currency of the instrument as a variation
			of the delta, for a variation of 1 of the underlying spot.
			@param undlCode is the underlying code
			By default, check if GetPriceDeltaGamma has been overloaded; if yes, call it else
			do the same finite difference as the default algorithm for GetPriceDeltaGamma excepting that the
			fair value already computed {@link fManagementTheoreticalValue} is used for the fair value.
			@since 4.6 Introduced for commodity as there is a lot of number of risk sources.
			@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
			to a code (sicovam, currency, ...)
			@see GetPriceDeltaGamma
			@see RecomputeAll
			*/
			virtual void	GetDeltaGamma(	const instrument::CSRInstrument & instrument,
											const market_data::CSRMarketData& context, 
											const sophis::CSRComputationResults& results,
											double				*delta, 
											double				*gamma, 
											int 				undlCode) const;

			/** Get delta and gamma to display in the pricing window.
			@param context is a market data.
			@param price is the fair value (coming from RecomputeAll).
			@param delta is the delta expressed in the currency of the instrument (coming from RecomputeAll).
			@param gamma is the gamma expressed in the currency of the instrument (coming from RecomputeAll).
			@param which is index between 0 (included) and GetUnderlyingCount() (excluded).
			@param deltaOut is the delta expressed in the currency of the instrument to show in the pricing window.
			@param gammaOut is the gamma expressed in the currency of the instrument to show in the pricing window.
			*/
			virtual void	GetDeltaGammaInPricingWindow(	const instrument::CSRInstrument& instr,
															const market_data::CSRMarketData& context,
															const sophis::CSRComputationResults& results,
															double							price,
															double							delta,
															double							gamma,
															int								which,
															double							&deltaOut,
															double							&gammaOut) const;


				/** Get the rho of one currency risk source.
				@param instrument is the instrument to price.
				@param context is a market data.
				@param currency is the currency.
				@return the rho expressed in the currency of the instrument as a variation
				of the fair value, for a variation of 1% of the zero coupon curve.
				The rho must be calculated using the risk volatility.
				The rho is supposed to be partial assuming that the underlying risk source (even if it is a future)
				does not move.
				The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}.
				The fact that the user can choose to display the rho for a bump of one basis point
				is not part of this method, but part of the GUI.
				This method may be called during a scenario (for instance a risk matrix of rho).
				By default, the algorithm is:
				- Ask {@link GetDerivationParameters} with gpRho to get the bump choosed.
				- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
				- Calculates the finite difference calling {@link GetTheoriticalValue}.
				- Expresses the result for 1% variation.
				@version 7.1 The third int parameter was changed from an index (between 0 and GetUnderlyingCount)
				to a code (sicovam, currency, ...)
			*/
			virtual double	GetRho(const instrument::CSRInstrument & instrument,const market_data::CSRMarketData &context, int currency, instrument::eRhoBumpType rhoBumpType) const;

				/** Get the convexity of one currency risk source.
				@param instrument is the instrument to price.
				@param context is a market data.
				@param which is in index between 0 (included) and GetRhoCount() (excluded).
				@return the convexity expressed in the currency of the instrument as a variation
				of the rho, for a variation of 1% of the zero coupon curve.
				The convexity must be calculated using the Risk volatility.
				The convexity is supposed to be partial assuming the underlying risk sources (even if it is a future)
				does not move.
				The meaning of a bump of of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}
				The fact that the user can choose to display the convexity for a bump of one basis point
				is not part of this method, but part of the GUI.
				This method may be called during a scenario.
				By default, the algorithm is:
				- Ask {@link GetDerivationParameters} with gpRho to get the selected bump.
				- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
				- Calculates the finite difference calling {@link GetTheoriticalValue}.
				- Expresses the result for a 1% variation..
			*/
			virtual double	GetConvexity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const;

						/** Get the rho and the convexity of one currency risk source.
						@param instrument is the instrument to price.
						@param context is a market data.
						@param price is the fair value calculated using the risk volatility.
						@param rho is the output parameter for the rho expressed in the currency of the instrument as a variation
						of the fair value, for a variation of 1% of the zero coupon curve.
						@param convexity is the output parameter for the convexity expressed in the currency of the instrument as a variation
						of the rho, for a variation of 1% of the zero coupon curve.
						@param currency is the currency.
						The rho and convexity must be calculated using the risk volatility.
						They are supposed to be partial, assuming the underlying risk source (even if it is a future)
						does not move.
						The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}
						The fact that the user can choose to display the rho and the convexity for a bump of one basis point
						is not part of this method, but part of the GUI.
						This method is called By CSRInstrument::RecomputeAll to save calculation.
						By default, the algorithm is:
						- Ask {@link GetDerivationParameters} with gpRho to get the selected bump.
						- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
						- Calculates the finite difference calling {@link GetTheoriticalValue}.
						- Expresses the result for 1% variation.
						@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
						to a code (sicovam, currency, ...)
					*/
			virtual void	GetRhoConvexity(const instrument::CSRInstrument & instrument,
											const market_data::CSRMarketData &context,
											double 				 price,
											double 				 *rho,
											double 				 *convexity,
											int 									 currency,
											instrument::eRhoBumpType				 rhoBumpType) const ;

					/** Calculate the second derivative $\f \frac{\partial^2}{\partial S \partial \rho} $\f
					when the instrument risk source has a rho that is not null.
					@param instrument is the instrument to price.
					@param context is a market data.
					@param deltaUndlCode is underlying code for delta.
					@param currency is the currency.
					@return the crossed derivative expressed in the currency of the instrument as a variation
					of the delta, for a variation 1% of the yield curve.
					The crossed derivative must be calculated using the risk volatility.
					The meaning of a bump of of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}.
					This method may be called during a scenario (for instance a risk matrix of vega).
					It is called also by {@link CSRInstrument::RecomputeAll} via {@link CSRInstrument::RecomputeRho}.
					This greek is necessary in the case of a future, because the rho is partial so we are able to aggregate.
					By default, the algorithm is:
					- return 0 if the underlying is a share, an index or a currency.
					- Ask {@link GetDerivationParameters} with gpRho to get the bump choosed.
					- Creates a new market data switching the volatility and bumping it using {@link CSRMarketData::GetVolat}.
					- Switch the smile preference to partial.
					- Calculates the finite difference calling {@link GetFirstDerivate}.
					@version 7.1 The last two int parameters were changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
					*/
			virtual double	GetCrossedDeltaRho(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int deltaUndlCode, int currency, instrument::eRhoBumpType rhoBumpType) const;

					/** Get the vega of one instrument risk source.
					If the instrument is a currency, the risk is supposed to be with the forex instrument/currency volatility.
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undCode is the underlying code.
					@return the vega expressed in the currency of the instrument as a variation
					of the fair value for a variation 1 of the underlying.
					The vega must be calculated using the Risk volatility.
					This method may be called during a scenario (for instance a risk matrix of vega).
					It is called also by {@link CSRInstrument::RecomputeAll}.
					By default, the algorithm is
					- Ask {@link GetDerivationParameters} with gpVega to get the bump choosed.
					- Creates a new market data switching the volatility and bumping it using {@link CSRMarketData::GetVolat}
					- Calculates the finite difference calling {@link GetTheoriticalValue}
					- Expresses the result for 1% variation.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
					*/

			virtual double	GetVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int undlCode) const;

					/** Get the crossed vega (sensibility to a correlation) of one instrument risk source.
					If the instrument is a currency, the source risk is supposed to be the forex instrument/currency.
					@param instrument is the instrument to price.
					@param context is a market data.
					@param whichUnderlying is in index between 0 included and GetUnderlyingCount() excluded.
					@return the vega expressed in the currency of the instrument as a variation
					of the fair value for a variation 1 of the underlying.
					The crossed vega must be calculated using the Risk volatility.
					This method may be called during a scenario (for instance a risk matrix of vega).
					It is called also by {@link CSRInstrument::RecomputeAll} if crossed vega preference is ticked on.
					By default, the algorithm is
					- Ask {@link GetDerivationParameters} with gpVega to get the bump choosed.
					- Creates a new market data switching the volatility and bumping the correlation using {@link CSRMarketData::GetCorrelation}
					- Calculates the finite difference calling {@link GetTheoriticalValue}
					- Expresses the result for 1% variation.
					*/
			virtual double	GetCrossedVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int which1, int which2) const;

				/** Get the theta.
					@param instrument is the instrument to price.
					@param context is a market data.
					@return the theta for one day (according the preference {@link CSRPreference::GetThetaDateType}.
					The default algorithm is :
					- Ask for theta preferences using {@link CSRPreference::GetThetaCorrection}.
					- Ask for a theta market data using {@link new_ThetaComputationContext}
					- if null retun 0
					- else calculate the finite difference calling twice {@link GetTheoreticalValue}.
					- check if {@link CSRPreference::IntegrateCouponInTheta()} is on to integrate the amount using {@link CERIntrument::GetCouponAmount}.
					*/
			virtual double	GetTheta(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;
			
				/** Get the epsilon (sensibility to the dividend risk).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					@return the epsilon for an increase of 10% of dividends.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference 
					calling twice GetTheoreticalValue
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double	GetEpsilon(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int undlCode) const ;

									/** Get the global epsilon.
						@return the epsilon expressed in the same unit and currency as the instrument.
						This method is never called in Sophis but is present for completeness sake.
						By default, it checks whether one underlying is an equity and if yes, it bumps all of
						the dividend factors.
					*/
			virtual	double			GetGlobalEpsilon(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& context) const;

			/** Get the vanna (spot-vol crossed derivative of the price).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetVanna(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Get the vanna (second derivative of the price with respect to the volatility).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetVolga(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Get the speed (third derivative of the price with respect to the spot).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetSpeed(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Get the zomma (spot-spot-vol crossed derivative of the price).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetZomma(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Get the DVegaDTime (time-vol crossed derivative of the price).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetDVegaDTime(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Get the delta bleed (time-spot crossed derivative of the price).
					@param instrument is the instrument to price.
					@param context is a market data.
					@param undlCode is the underlying code.
					By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference.
					@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
					to a code (sicovam, currency, ...)
				*/
			virtual double GetDeltaBleed(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int undlCode) const;

			/** Method to fill risk sources
			@param instr is the instrument to price.
			@param rs is the computation result to initialize with risk source code.
			@param	bitFlag is a bit flag to set up which risk source type must be initialized. {@see sophis::finance::eRiskSourceType} enum define the bit flag to use,
					{@link sophis::finance::IsRiskSourceTypeInBitFlag} method . 
					Default parameter is the initialization of all risk source type. It allow to call mother method by adding/removing initialization of some greeks by using binary xor 
					with the type to add/remove.
			@since 7.1
			*/
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag = 0xFFFFFFFF) const;
			virtual void GetForwardRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag = 0xFFFFFFFF) const;
			void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			void GetVegaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			void GetEpsilonRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			void GetInflationRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;
			void GetCreditRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& parent, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRCapFloor& parent, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRSwap& parent, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRBond& parent, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentVegaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const;
			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const;

			virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRForexFuture& parent, /*out*/ sophis::CSRComputationResults& rs) const;


		//	virtual void GetParentRhoRiskSources(const instrument::CSRInstrument& underlyer, const sophis::CSRTitrePh & parent, /*out*/ sophis::CSRComputationResults& rs) const;

			/** Get a new context when bumping a spot.
				When bumping a spot to calculate a greek or to price, when the underlying is a basket,
				the software must actually bump the underlyings, not the basket. This is the aim
				of that method. Instead of just bumping the spot, it calls the method and if the return is
				not null, it will price with that context.
				@param context is the context data to modify, in order to bump the spot.
				@param basketValue is the basket value to retrieve for the new context.
				@param smile indicates how GetSpotForVolatility must be overloaded; if true it is
				overloaded as GetSpot, otherwise, it is overloaded as the original GetSpot; this is used to calculate all of the possibile values of delta/gamma.
				@return a new market data (value can be null), which decorates a context, bumping certain spots,
				and must be deleted using Delete. By default, returns 0 if no deprecated method is used.
			*/
			virtual market_data::CSRMarketData* new_ComputationContext(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context, 
																		const sophis::CSRComputationResults& riskSources,
																		double basketValue, 
																		bool smile) const;
			/** Get a user parameter.
			It is possible to add for all instruments some user parameters as Vega, Gamma
			It is not called by Sophis.
			Using that method to get the user parameters gives you the possibility to enhance the
			CSRInstrument interface to tailor your needs.
			@param instrument is the instrument to price.
			@param whichParameter is an enumeration of the user parameters.
			@param input is an address on a structure to get the user parameter.
			@param output is an address on a structure for the result of the user parameter.
			@return true if correct.
			By default, call @link sophis::misc::GetUserParameter which should be the default
			for all instruments.
			*/
			virtual bool GetUserParameter(const instrument::CSRInstrument & instrument, int whichParameter, void *input, void *output) const;

			/** Calls ComputeAllCore and performs additional computation through CSRAdditionalComputation
			@version 7.0
			*/
			void	ComputeAll(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const;


			virtual void		ComputeForexGreeks(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results) const;
		public:
			/** Recompute the fair value and all of the greeks.
			@param instrument is the instrument to price.
			@param context is a market data.
			This method calculates all of the values and starts them so they can be retrieved using
			the method GetTheoreticalValue(), GetFirstDerivative(int), etc.
			This method is called when recalculating the book. It is called also during the risk matrix
			when the user asks for all of the greeks.
			The default implementation assumes that {@link InitialiseRecomputeAll} has been called
			so it can save the values in these structures.
			Here is the algorithm :
			- It calculates fAccruedCoupon using {@link CSRInstrument::GetAccruedCoupon(long)}.
			- It calculates the floating factor using {@link CSRInstrument::GetFloatingNotionalFactor(long)}.
			- if fDeltaEpsilon is null, it calculates fManagementTheoreticalValue
			and fTheoreticalValue using GetTheoreticalValue.
			- It puts fUseManagement to true.
			- for the first underlying risk source, it calls {@link GetPriceDeltaGamma} and puts the price in
			fManagementTheoreticalValue.
			- for all other underlying risk source, it calls {@link GetDeltaGamma}.
			- If the preference epsilon is on, for each underlying risk souces which is an equity, it calculates the epsilon
			by bumping the dividend as in {@link GetEpilon} but duplicating the code to save one calculation.
			- for each underlying risk source, it calls {@link GetVega}
			- for each pair of underlying risk souces, it calls {@link GetSecondDerivative}.
			- If the preference crossed vega is on, for each pair of underlying risk souces, it calls
			{@link GetCrossedVega}.
			- If there is an underlying, compare the volatility preference to check whether
			the P&L and risk volatility are different. If this is the case, call again GetTheoreticalValue.
			- Ask the computation context for the theta using {@link new_ThetaComputationContext}
			- If null, call {@link GetTheta} else apply the same algoritm as in the GetTheta.
			- It calculates the rho using {@link RecomputeRho}
			- it calculates different yields to maturity calling {@link RecomputeYTM]
			- It calculates the credit risk sensitivity (version 4.1.2) using {@link GetCreditRiskSensitivity}
			and assigns fCreditRiskSensitivity.
			- It calculates the recovery rate sensitivity (version 4.1.2) using {@link GetRecoveryRateSensitivity}
			and assigns fRecoveryRateSensitivity.
			- It calculates the yield to maturity sensitivity  using {@link GetYTMSensitivity}
			and assigns fYTMSensitivity.
			- It calculates the duration using {@link GetDuration} and assigns fDuration.
			- It calculates the modified duration using {@link GetModDuration} and assigns fModDuration.
			- It calculates the sensitivity to inflation using {@link RecomputeInflationSensitivities}
			and assigns fInflationSensitivity and fInflationConvexity.
			@since 5.2 Introduction of the floating notional for inflation bond.
			@since 5.2 Introduction of inflation risk
			*/
			virtual void	ComputeAllCore(instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const;
		public:
			/** Get the modified duration.
			@param context is a market data.
			@param ytm is the yield to market (0.01 for 1%). If ytm is NOTDEFINED, it is recomputed.
			@return the modified duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fModDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetModDurationByYTM.
			@since 6.0
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double GetModDuration(	const instrument::CSRInstrument& instr,
											const market_data::CSRMarketData&context,
											double							ytm	= NOTDEFINED) const;

			/** Get the value of the cash from the future without linear formula.
			@param computationDate is the date for the cash.
			@param futureDate is the expiry date for the cash.
			@param futureValue is the future value.
			@param settlementType is the settlement type of the option.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param spot is the cash value.
			@param b is an output coefficient to a term to add to the future.
			@param rate is an output coefficient corresponding to a compound factor to get the pay-off.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			If the GetLinearValue returns an output a to 0, the model assumes there is no linear formula
			and calls for each point of the tree to get the spot.
			By default, if there is an arbitrage with an underlying model, consult the arbitrage, otherwise
			return spot = futureValue.
			@see GetForwardPrice
			@see GetLinearValue
			*/
			virtual	void	GetValue(	const instrument::CSRInstrument& instr,
										double 					 computationDate,
										long 					 futureDate,
										double 					 futureValue,
										instrument::eSettlementType 		 settlementType,
										market_data::eTaxCreditPercentageType forEvaluation,
										double 					 *spot,
										const market_data::CSRMarketData 	 &context) const;

			/** Get the cash flow diagram used to compute duration and modified duration.
			By default returns new_CashFlowDiagram(context)
			It is overloaded for example in CSROption to include only the bond part
			@param context is a market data
			@return a new cash flow diagram.
			@since 6.0
			@see CSRCashFlowDiagram
			*/
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagramForDuration(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;

			virtual double			ComputeValueSecondLeg(const instrument::CSRInstrument& instr, const market_data::CSRMarketData & context) const;


			virtual long	GetVolatilityFamilyCodeFromInstrument(	const instrument::CSRInstrument& instr,	
																	const market_data::CSRMarketData& context) const;
			/** in the hull & white model, gives the swaption vector to hedge volatility risk **/
			virtual void	GetCalibrationSwaptionFromInstrument(const instrument::CSRInstrument& instr,	
																const market_data::CSRMarketData& context,
																_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;

			static void  GetMaturitiesAndStrikeFormVolatilityMatrix(	const instrument::CSRInstrument*		swapForCalibration, 
																		const instrument::CSRInstrument*		swaptionInSwaptionvector,
																		bool									isSmile,
																		_STL::vector<long>		&				swapMaturitiesVol,
																		_STL::vector<long>		&				optionMaturitiesVol,
																		bool									isVegaAndWeightsAreComputed);

			static  sophis::instrument::CSRSwap* new_SwapforCalibration(const sophis::market_data::CSRMarketData &context, 
																		long									 family, 
																		long									 currency, 
																		long									 issue_date,
																		long									 end_date);
			static long GetSwaptionVolatilityCodeForFamily(	long										family, 
															long										currency,
															sophis::market_data::eVolatilityCurveType&	volType);

		protected :
			virtual long	GetVolatilityFamilyCodeFromInstrumentImpl(	const instrument::CSRInstrument& instr,	
																	const market_data::CSRMarketData& context) const;


			virtual long	GetVolatilityFamilyCodeFromOption(	const instrument::CSROption& option,	
																const market_data::CSRMarketData& context) const;
			virtual long	GetVolatilityFamilyCodeFromBond(	const instrument::CSRBond& bond,
																const market_data::CSRMarketData& context) const;
			virtual long	GetVolatilityFamilyCodeFromSwap(	const instrument::CSRSwap& swap,
																const market_data::CSRMarketData& context) const ;
			virtual long	GetVolatilityFamilyCodeFromFuture(	const instrument::CSRFuture& future,
																const market_data::CSRMarketData& context) const;
				


			virtual void	GetCalibrationSwaptionFromInstrumentImpl(	const instrument::CSRInstrument& instr,	
																		const market_data::CSRMarketData& context,
																		_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;

			/** Gives the swaption vector to hedge volatility risk (implemented for only for swaptions)**/
			virtual void	GetCalibrationSwaptionFromOption(	const instrument::CSROption& option,
																const market_data::CSRMarketData							&context,
																_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;

			/** in the hull & white model, gives the caplet vector to hedge volatility risk **/
			virtual void	GetCalibrationSwaptionFromSwap(	const instrument::CSRSwap& swap,
															const market_data::CSRMarketData							&context,
															_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;

			/** in the hull & white model, gives the swaption vector to hedge volatility risk (implemented for regular bermudan swaptions)**/
			virtual void	GetCalibrationSwaptionFromBond(	const instrument::CSRBond& bond,
															const market_data::CSRMarketData							&context,
															_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;
			/** in the hull & white model, gives the swaption vector to hedge volatility risk (implemented for regular bermudan swaptions)**/
			virtual void	GetCalibrationSwaptionFromFuture(	const instrument::CSRFuture& future,
																const market_data::CSRMarketData							&context,
																_STL::vector<sophis::instrument::SSSwaptionInstrumentData*>	&swaptionVector) const;
		public:


			/** in the hull & white model, gives the caplet vector to hedge volatility risk **/
			virtual void	GetCalibrationCapletFromInstrument(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context,
																		_STL::vector<sophis::instrument::CSRCapletValuation*>	&capletVector) const;
		protected:
			virtual void	GetCalibrationCapletFromInstrumentImpl(	const instrument::CSRInstrument& instr,
																		const market_data::CSRMarketData& context,
																		_STL::vector<sophis::instrument::CSRCapletValuation*>	&capletVector) const;
			virtual void	GetCalibrationCapletFromOption(	const instrument::CSROption& option,
																const market_data::CSRMarketData							&context,
																_STL::vector<sophis::instrument::CSRCapletValuation*>	&swaptionVector) const;

			/** in the hull & white model, gives the caplet vector to hedge volatility risk **/
			virtual void	GetCalibrationCapletFromSwap(	const instrument::CSRSwap& swap,
															const market_data::CSRMarketData							&context,
															_STL::vector<sophis::instrument::CSRCapletValuation*>	&swaptionVector) const;

			/** in the hull & white model, gives the swaption vector to hedge volatility risk (implemented for regular bermudan swaptions)**/
			virtual void	GetCalibrationCapletFromBond(	const instrument::CSRBond& bond,
															const market_data::CSRMarketData							&context,
															_STL::vector<sophis::instrument::CSRCapletValuation*>	&swaptionVector) const;
			/** in the hull & white model, gives the swaption vector to hedge volatility risk (implemented for regular bermudan swaptions)**/
			virtual void	GetCalibrationCapletFromFuture(	const instrument::CSRFuture& future,
																const market_data::CSRMarketData							&context,
																_STL::vector<sophis::instrument::CSRCapletValuation*>	&swaptionVector) const;
		
public:

			virtual double ComputeDirtyPrice(	const instrument::CSRInstrument& instr,
												long							transactionDate,
												long							settlementDate,									
												long							ownershipDate,									
												const market_data::CSRMarketData&context,										
												double							*sensibility	  = 0,							
												const sophis::static_data::CSRDayCountBasis			*basis			  = 0,		
												short							adjustedDates	  = kUseDefaultValue,			
												short							valueDates		  = kUseDefaultValue,			
												const sophis::static_data::CSRDayCountBasis			*dayCountBasis	  = 0,		
												const sophis::static_data::CSRYieldCalculation		*yieldCalculation = 0,		
												_STL::vector<instrument::SSRedemption>		*redemptionArray  = 0,							
												_STL::vector<instrument::SSBondExplication>	*explicationArray = 0) const;

			double			ComputeDirtyPriceDeprecated(	const instrument::CSRInstrument& instr,
															long							transactionDate,
															long							settlementDate,								
															long							ownershipDate,								
															const market_data::CSRMarketData	&context,								
															double							*sensibility	  = 0,						
															const sophis::static_data::CSRDayCountBasis			*basis			  = 0,	
															short							adjustedDates	  = kUseDefaultValue,		
															short							valueDates		  = kUseDefaultValue,		
															const sophis::static_data::CSRDayCountBasis			*dayCountBasis	  = 0,	
															const sophis::static_data::CSRYieldCalculation		*yieldCalculation = 0,	
															_STL::vector<instrument::SSRedemption>		*redemptionArray  = 0,						
															_STL::vector<instrument::SSBondExplication>	*explicationArray = 0) const;

			bool			GetImpliedSpreadDeprecated(	const instrument::CSRInstrument& instr,
														long						transactionDate,
														long						settlementDate,
														long						ownershipDate,
														double						theoreticalPrice,
														instrument::eSpreadType				spreadType,
														const market_data::CSRMarketData	&context,
														double						&value,
														short						adjustedDates	  = kUseDefaultValue,
														short						valueDates		  = kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
														const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			bool		ComputePriceBySpreadDeprecated(	const instrument::CSRInstrument& instr,
														long						transactionDate,
														long						settlementDate,
														long						ownershipDate,
														const market_data::CSRMarketData&context,
														instrument::eSpreadType				spreadType,
														double						spread,
														double						&value,
														short						adjustedDates	  = kUseDefaultValue,
														short						valueDates		  = kUseDefaultValue,
														const sophis::static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
														const sophis::static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			bool  GetPriceDeltaGammaBySpreadDeprecated(	const instrument::CSRInstrument& instr,
														const market_data::CSRMarketData&context,
														double						*price,
														double						*sensitivity,
														double						*convexity,
														long						transactionDate,
														long						settlementDate,
														long						ownershipDate,
														instrument::eSpreadType				spreadType,
														double						spread,
														short						adjustedDates	  = kUseDefaultValue,
														short						valueDates		  = kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
														const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			/** Get the duration.
			@param context is a market data.
			@return the duration as a number of years.
			This method is called during {@link CSRInstrument::RecomputeAll} to assign fDuration
			which will be shown in a Portfolio column.
			By default, use the cash flow diagram calling new_CashFlowDiagram::GetDurationByZC.
			@since 4.1.3
			@see new_CashFlowDiagram
			@see CSRCashFlowDiagram
			*/
			virtual double GetDuration(const instrument::CSRInstrument & instrument,
						   const market_data::CSRMarketData& context,
						   const sophis::CSRComputationResults* results = 0) const;

			/** Get the theoretical value of each leg.
			*	available for swap uniquely.
			@param context is a set of market data where the leg has to be evaluated.
			@param which designs the leg and the value is 0 or 1.
			@return the leg value, accrued included, in percentage. It retuns 0 in case of badly defined swap.
			This method is not supposed to work for equity swap with floating nominal.
			*/
			virtual double	GetLegTheoreticalValue(const instrument::CSRInstrument & swap, const market_data::CSRMarketData& context, int which) const;

			/** Get the preferences to calculate the greeks by finite difference.
			@param instrument is the instrument to price.
			@param greekParameterType is the greek for which the preference is selected.
			@param pref is a valid pointer for the output.
			This method is called for all greek calculations to define the step to use.
			The default implementation is to call the instrument to get the data.
			It uses 1 basis point.
			*/
			virtual void	GetDerivationParameters(const instrument::CSRInstrument & instrument, instrument::eGreekParameterType greekParameterType,instrument::SSParametersOfDerivation *pref) const;

			/** Get the way to include the smile in delta gamma.
			This is used in GetPriceDeltaGamma (see financial documentation).
			@param instrument is the instrument to price.
			@return the method type.
			The default implementation is to call the instrument to get the smile type.
			*/
			virtual eSmileInDeltaGamma GetSmileInDeltaGamma(const instrument::CSRInstrument & instrument) const;

			/** Create the theta context to calculate the theta.
			It is called by {@link CSRMetaModel::GetTheta(const CSRMarketData &)} to get
			the theta by finite difference.
			It is also called by {@link CSRMetaModel::RecomputeAll} to check if the theta is
			calculated by finite difference. If the return is 0, it calls GetTheta(const CSRMarketData &)
			otherwise it calculates the finite difference, to save one calculation.
			@param instrument is the instrument whose theta context is wanted.
			@param context is the original context to decorate to get the theta context.
			@return the new theta context so that /f$ \theta = f(theta_context) - f(context) /f$
			By default, call @link CSRInstrument::new_ThetaComputationContext.
			*/
			virtual market_data::CSRMarketData*	new_ThetaComputationContext(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

			/** Create the credit risk sensitivity context .
			It is called by {@link CSRMetaModel::RecomputeCreditRisk} to get
			the credit risk sensitivity by finite difference.
			@param instrument is the instrument whose credit risk sensitivity context is wanted.
			@param context is the original context to decorate to get the credit risk sensitivity context.
			@param isPositiveBump to indicate is the bump is positive or negative.
			@return the new credit risk sensitivity context.
			By default, call @link CSRInstrument::new_CreditRiskSensitivityComputationContext.
			@version 4.5.2.2 New parameter isPositiveBump for calculation of credit risk convexity.
			*/
			virtual market_data::CSRMarketData*	new_CreditRiskSensitivityComputationContext(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, bool isPositiveBump ) const;

			/** Get the credit risk convexity.
				@param context is market data.
				@return the credit risk convexity expressed in the currency of the instrument, as a variation of the CDS curve of 1%.
				1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
				It is called by {@link CSRInstrument::RecomputeAll}.
				Here is the default algorithm:
				- test if it has some issuer dependency calling {@link GetIssuerArray }.
				- if no, return 0.
				- if yes, create a new market data bumping all the cds curve using {@link CSRCreditRisk::CurveShift}.
				- calculate the finite difference $\f \frac{f(x+h)-f(h)}{2h} $\f
				using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
				@since 4.5.2.2
			*/
			virtual double	GetCreditRiskConvexity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;

				/** Get the credit risk sensitivity and convexity from the reference price and individual sensitivities.
						@param context is market data.
						@param refPrice is the derivative price without any bump.
						@param sensitivity is for the output computed sensitivity.
						@param convexity is for the output computed convexity.
						@param creditGreeks is structure to store credit delta and gamma according to each credit risk source (can be set to NULL pointer to avoid computation
						@param computeCrossedGammas is to tell if crossed credit greeks are to be computed (computeSingleDeltaGamma is mandatory for this)
					*/
			virtual void			ComputeCreditRiskSensitivities(	const instrument::CSRInstrument		&instrument,
																	const market_data::CSRMarketData	&context, 
																	const sophis::CSRComputationResults	&results,
																	double								refPrice,
																	double								&sensitivity,
																	double								&convexity,
																	bool								computeCrossedGammas,
																	bool								computeAllCreditDeltaGamma = true) const;

						

			/** Create the recovery rate sensitivity context .
			It is called by {@link CSRMetaModel::RecomputeCreditRisk} to get
			the recovery rate sensitivity by finite difference.
			@param instrument is the instrument whose recovery rate sensitivity context is wanted.
			@param context is the original context to decorate to get the recovery rate sensitivity context.
			@return the new recovery rate sensitivity context.
			By default, call @link CSRInstrument::new_CreditRiskSensitivityComputationContext.
			*/
			virtual market_data::CSRMarketData*	new_RecoveryRateSensitivityComputationContext(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

			/** Calculate all rho of the currency risk sources.
			@param instrument is the instrument whose recovery rate sensitivity context is wanted.
			@param context is a market data.
			@param price is the fair value calculated with the risk volatility.
			The algoritm is:
			- for each currency risk source, call {@link GetRhoConvexity} and fill the structure fRho,
			- for each currency risk source, for each underlying risk source,
			 call {@link GetCrossedDeltaRho} and fill crossed risk/rho calling 
			 {@link CSRInstrument::SetCrossedDeltaRho} if {@link CSRInstrument::IsCrossedRiskRhoToBeComputed} is true.
			*/
			virtual void	RecomputeRho(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results, double price) const;
		

			/** Compute diffente yields to maturity.
			This is used during the RecomputeAll.
			@param instrument is the instrument whose recovery rate sensitivity context is wanted.
			@param context is a market data.
			@param price is the fair value calculated with the risk volatility.
			If the preference {@link CSRPreference::CalculationWithoutFixedIncome()} is on,
			- It calculates the yield to maturity at the fair value using {@link GetYTMByDirtyPrice}
			and assigns fYTM.
			- If there is a last, It calculates the yield to maturity at the last using {@link GetYTMByDirtyPrice}
			and assigns fYTMMtoM.
			*/
			virtual void	RecomputeYTM(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results, double price) const;

			/** Compute credit risk sensitivities.
			This is used during the RecomputeAll.
			@param instrument is the instrument whose recovery rate sensitivity context is wanted.
			@param context is a market data.
			@param price is the fair value calculated with the risk volatility.
			If the preference {@link CSRPreference::CalculationWithoutCreditRisk()} is on,
			- It gets a market data calling  {@link new_CreditRiskSensitivityComputationContext}.
			- if not null, it calculates the credit risk sensitivity by finite difference
			and assigns fCreditRiskSensitivity.
			- It gets a market data calling  {@link new_RecoveryRateSensitivityComputationContext}.
			- if not null, it calculates the recovery rate sensitivity by finite difference
			and assigns fRecoveryRateSensitivity.
			*/
			virtual void	RecomputeCreditRisk(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results, double price) const;


			/** computes the first and second sensitivities to a uniform shift of the continuous yields
			*	in the inflation curve
			*	if inflationCode1 = inflationCode2,
			*		sensitivity is the first order derivative and convexity is the second derivative
			*	otherwise
			*		sensitivity is set to 0 and convexity is the crossed derivative
			*	@param instrument is the instrument whose inflation sensitivities context is wanted.
			*	@param context if the pricing context
			*	@param sensitivity is the first derivative is inflationCode1 = inflationCode2, 0 otherwise
			*	@param convexity is the second derivative with respect to inflationCode1 and inflationCode2
			*	@inflationCode1 is the code of the first inflation curve
			*	@inflationCode2 is the code of the second inflation curve
			*	@since	5.2
			*/
			virtual void ComputeInflationSensitivities(	const instrument::CSRInstrument	&instrument,
														const market_data::CSRMarketData&context,
														double							&sensitivity,
														double							&convexity,
														long							inflationCode1,
														long							inflationCode2) const;

			/** computes the first sensitivity to a uniform shift of of the inflation volatility
			*	@param instrument is the instrument whose inflation vega context is wanted.
			*	@param context is the pricing context
			*	@param which is the index of the inflation source
			*	@return the inflation vega
			*	@since	5.3.4
			*/
			virtual double ComputeInflationVega(const instrument::CSRInstrument	&instrument,
												const market_data::CSRMarketData&context,
												int 							which) const;

			/** computes the first and second derivatives of the theoretical value
			*	for a parallel shift of the zero-coupon yields in the inflation curve
			*	sensitivities are computed for every inflation source, including crossed convexities
			*
			*	default implementation is calling {@link ComputeInflationSensitivities} {@link ComputeInflationVega}
			*	then set @link{instrument.fInflationSensitivity} to the output sensitivity and
			*			 @link{instrument.fInflationConvexity} to the output convexity
			*
			*   @param instrument is the instrument for which the inflation risk is computed
			*	@param context is the context for pricing
			*	@since 5.2
			*/
			virtual void RecomputeInflationSensitivities(	instrument::CSRInstrument& instrument,
															const market_data::CSRMarketData& context,
															sophis::CSRComputationResults& results) const;
		


			/** Get the vega equity.
			@param instrument is the instrument.
			@param context is a market data.
			@return the vega expressed in the same unit and currency as the instrument.
			This method is called, for instance, by the risk matrix to show the vega
			when only this option is ticked.
			By default, it checks if one underlying is an equity and if yes, it bumps all
			the volatilities of equity underlying.
			*/
			virtual	double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;


			/** Get the vega equity displayed in the portfolio.
			@param instrument is the instrument.
			*/
			virtual double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const;

			/** Test if a graphic is availbale for that instrument and that model.
			This is called when a tree graphic is asked.
			@param instrument is the instrument to explain the fair value.
			By default, return false.
			*/
			virtual bool AvailableCoxTreeGraphics(const instrument::CSRInstrument & instrument) const;

			/** Get the credit risk sensitivity.
			@param instrument is the instrument.
			@param context is market data.
			@return the credit risk sensitivity expressed in the currency of the instrument, as a variation of the CDS curve of 1%.
			1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
			It is called by {@link CSRInstrument::RecomputeAll}.
			Here is the default algorithm:
			- test if it has some issuer dependency calling {@link GetIssuerArray }.
			- if no, return 0.
			- if yes, create a new market data bumping all the cds curve using {@link CSRCreditRisk::CurveShift}.
			- calculate the finite difference $\f \frac{f(x+h)-f(h)}{h} $\f
			using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
			*/
			virtual double	GetCreditRiskSensitivity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

			/** Get the recovery rate sensibility.
			@param instrument is the instrument.
			@param context is a market data.
			@return the recovery rate sensibility expressed in the currency of the instrument as a variation of the recovery rate of 1%.
			1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
			It is called by {@link CSRInstrument::RecomputeAll}.
			The default algorithm is as follows:
			- test whether it has any issuer dependency calling {@link GetIssuerArray}.
			- if no, return 0.
			- if yes, create a new market data bumping all CDS curves using {@link CSRCreditRisk::RecoveryRateShift}.
			- calculate the finite difference $\f \frac{f(x+h)-f(h)}{h} $\f
			using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
			@since 4.1.3
			*/
			virtual double	GetRecoveryRateSensitivity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

			/** Get the credit risk sensitivity according to one source.
			@param instrument is the instrument.
			@param context is market data.
			@param source is the credit source to bump.
			@return the credit risk sensitivity expressed in the currency of the instrument, as a variation of the CDS curve of 1%.
			1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
			Here is the default algorithm:
			- test if it has some sensitivity according to the source {@link GetUniversalCreditRiskSources }.
			- if no, return 0.
			- if yes, create a new market data bumping all the cds curve using {@link CSRCreditRisk::CurveShift}.
			- calculate the finite difference $\f \frac{f(x+h)-f(h)}{h} $\f
			using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
			*/
			virtual double GetCreditRiskDelta(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &source) const;

			/** Get the credit risk convexity according to one source.
			@param instrument is the instrument.
			@param context is market data.
			@param source1 is the credit first source to bump.
			@param source2 is the credit second source to bump.
			@return the credit risk sensitivity expressed in the currency of the instrument, as a variation of the CDS curve of 1%.
			1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
			Here is the default algorithm:
			- test if it has some sensitivity according to the source {@link GetUniversalCreditRiskSources }.
			- if no, return 0.
			- if yes, create a new market data bumping all the cds curve using {@link CSRCreditRisk::CurveShift}.
			- calculate the finite difference 
			using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
			*/
			virtual double GetCreditRiskGamma(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const instrument::SSCreditRiskSource &source1, const instrument::SSCreditRiskSource &source2) const;

			/** Get the implied volatility.
			This is called in the general dialog of options and caps/floors to calculate the implied volatility.
			@param instrument is the option or cap/floor beeing edited.
			@param context is the market data of the dialog.
			@param premium is the option premium.
			@param accuracy is the default accuracy for the implied calculation.
			@return the implied volatility (.2 for 20%); return NOT_DEFINED if no implied volatility.
			By default, assume the fonction is monotone, and try to find a volatility by 15 iterations maximum
			between 0 and 150%; see financial documentation for more information.
			*/
			virtual double GetImpliedVolatility(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData & param, const sophis::CSRComputationResults& results, double premium, double accuracy = NOTDEFINED) const;
		
			virtual double GetImpliedVolatilityAfterRecomputeAll(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, const sophis::CSRComputationResults& results, double premium, double accuracy = NOTDEFINED) const;

			/**
			* This method gives the instrument code from which a specific volatility may be opened
			* @param instrument the calling instrument code
			* @return the code of the instrument that bears the specific volatility matrix, such as swaption volatility, if any
			* returns 0 otherwise
			* @since 6.1
			*/
			virtual long	GetCodeForSpecificVolatility(const instrument::CSRInstrument & instrument) const;

			/**
			* This method returns the spread computed from the theoreticalPrice.
			* @param	transactionDate		transaction date
			* @param	settlementDate		the settlement date
			* @param	ownershipDate		the ownership date
			* @param	theoreticalPrice	the benchmarked theoreticalPrice computed with the same conventions as CSRInstrument::GetTheoreticalPrice
			* @param	spreadType			the spread type to be computed
			* @param	context				the computation market data
			* @param	value				the value to be returned
			* @param	adjustedDates		ytm computed on adjusted date
			* @param	valueDates			ytm computed on value date
			* @param	dayCountBasis		ytm day count basis type
			* @param	yieldCalculation	ytm yield calculation type
			* @return true if the spread exists, false if not.
			*/
			virtual bool	GetImpliedSpread(	const instrument::CSRInstrument& instr,
												long						transactionDate,
												long						settlementDate,
												long						ownershipDate,
												double						theoreticalPrice,
												instrument::eSpreadType				spreadType,
												const market_data::CSRMarketData		&context,
												double						&value,
												short						adjustedDates	  = kUseDefaultValue,
												short						valueDates		  = kUseDefaultValue,
												const static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
												const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			void			RecalculeCompo(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,long codePanier, sophis::CSRComputationResults& results) const;			
			void			RecalculeQuanto(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context,long codePanier, sophis::CSRComputationResults& results) const;
			double	GetDeltaPanierQuanto(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int whichUnderlying, long codePanier) const;
			virtual double	GetBasketVega(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			double	GetGammaPanierQuanto(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which1, int which2, long codePanier) const;
			double	GetDeltaPanierCompo(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int whichUnderlying, long codePanier) const;
			double	GetGammaPanierCompo(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, int which1, int which2, long codePanier) const;

			/** Get the value of the cash from the future as a linear formula.
			@param computationDate is the date for the cash.
			@param futureDate is the expiry date for the cash.
			@param settlementType is the settlement type of the option.
			@param forEvaluation is the tax credit percentage type to take into account.
			@param a is an output coefficient corresponding to a factor to multiply the future.
			@param b is an output coefficient to a term to add to the future.
			@param rate is an output coefficient corresponding to a compound factor to get the pay-off.
			This method is called with a NMU model to get the cash value as well as the pay-off.
			The spot will be $\f a F + b $\f and the pay-off with a strike $\f K $\f will be
			$\f \frac{a F + b - K}{\mbox{rate}} $\f. Note that if 'a' is null, meaning that the
			cash is not a linear formula in the future, the algorithm calls GetValue.
			By default, if there is an arbitrage with underlying model, ask the arbitrage else
			return a = 1, b = 0 and rate = 1.
			@see GetForwardPrice
			@see GetValue
			*/
			virtual	void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const;
			void	GetLinearValue(	const instrument::CSRInstrument& instr,
											double					 computationDate,
											double 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const;


			virtual	void	SetVegaCompo(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results) const;

			virtual	void	DebutPanier(instrument::CSRInstrument& instr) const;
			virtual	void	FinPanier(instrument::CSRInstrument& instr, sophis::CSRComputationResults& results, double delta, double gamma) const;

			virtual	void	GetPrixDeltaGammaPanier(const instrument::CSRInstrument& instr,
													const market_data::CSRMarketData& context,
													double				*price,
													double				*delta,
													double				*gamma,
													long				codePanier) const;

			virtual	double	GetTheoriquePanier(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;

			/** Get the implied spread.
			@param instrument is the instrument.
			@param context is a market data.
			@param premium is the option premium.
			@param accuracy is the default accuracy for the implied calculation.
			@return the implied volatility (.02 for 2%); return 0 if no implied spread.
			*/
			virtual double	GetImpliedCreditSpread(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double premium, double accuracy) const;

			/** When calculating the implied credit risk after a RecomputeAll, call this method. */
			virtual double GetImpliedCreditSpreadAfterRecomputeAll(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& context, const sophis::CSRComputationResults& results, double premium, double accuracy) const;

			/** Test if the meta model knows to price this kind of instrument.
			@return true if the instrument is valid for this model.
			By default, use the basic test implemented in 4.5.1
			*/
			virtual bool	ValidInstrument(const instrument::CSRInstrument & instrument) const;

			/** Creates a new CDS Pricer from a Credit Risk
			@param creditRisk is the credit risk of the issuer
			@param context is the market data which can modify the credit risk structure
			@return CDS Pricer structure from the credit risk of the issuer
			*/
			virtual sophis::finance::CSRCDSPricer* new_CDSPricer(const instrument::CSRInstrument & instrument, const sophis::market_data::CSRCreditRisk* creditRisk, const market_data::CSRMarketData &context) const;

			/** Generates a (possibly modified) credit risk structure.
			@param context is the market data which can modify the credit risk structure.
			@return a credit risk structure from the credit risk of the issuer and possibly from the specific parameters
			of the instrument (credit spread, etc). The pointer, if not null, must be deleted after use.
			*/
			virtual market_data::CSRCreditRisk*	new_CreditRisk(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;

			virtual bool  GetPriceDeltaGammaBySpread(	const instrument::CSRInstrument& instr,
														const market_data::CSRMarketData		&context,
														double						*price,
														double						*sensitivity,
														double						*convexity,
														long						transactionDate,
														long						settlementDate,
														long						ownershipDate,
														instrument::eSpreadType		spreadType,
														double						spread,
														short						adjustedDates	  = kUseDefaultValue,
														short						valueDates		  = kUseDefaultValue,
														const static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
														const static_data::CSRYieldCalculation	*yieldCalculation = 0) const;

			/**
			* This method returns the dirty price computed from a spread value and a spread type.
			* @param	transactionDate		transaction date
			* @param	settlementDate		settlement date
			* @param	ownershipDate		ownership date
			* @param	adjustedDates		ytm computed on adjusted date
			* @param	valueDates			ytm computed on value date
			* @param	dayCountBasis		ytm day count basis type
			* @param	yieldCalculation	ytm yield calculation type
			* @param	context				computation market data
			* @param	spreadType			spread type
			* @param	spread				spread value
			* @param	value				dirty price computed from a spread value and a spread type
			* @return	true if able to compute.
			* @see		eSpreadType
			*/
			bool ComputePriceBySpread(const instrument::CSRInstrument & instrument,
										long							transactionDate,
										long						settlementDate,
										long						ownershipDate,
										const market_data::CSRMarketData	&context,
										instrument::eSpreadType				spreadType,
										double						spread,
										double						&value,
										short						adjustedDates	  = kUseDefaultValue,
										short						valueDates		  = kUseDefaultValue,
										const sophis::static_data::CSRDayCountBasis		*dayCountBasis	  = 0,
										const sophis::static_data::CSRYieldCalculation	*yieldCalculation = 0) const;
			
			/** Force a default behaviour for an option.
			By default, this method returns ucNotDefined. You can force the default behaviour of the option
			by overloading this method.
			@see CSROption::GetNMUFlag
			@see CSROption::GetUnderlyingComputationType
			*/
			virtual instrument::eUnderlyingComputationType GetUnderlyingComputationType() const;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRMetaModel, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_META_MODEL.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Get specific element of the metamodel, when you add a dialog.
			@param NRE_element is the element ID in your CSRDialog.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_Element is not found.
			*/
			bool LoadSpecificElement(int NRE_Element,void *address) const;

			/** Get specific element in a list of the metamodel, when you add a dialog.
			@param NRE_List is the element id of your CSREditList in your CSRDialog.
			@param lineNumber from 0 to GetSpecificLineCount()-1 is the line number in your CSREditList.
			@param NRC_Colomn is the column number.
			@param address is a pointer on the field, which must have the right size.
			@return false in case of error : for instance if NRE_List is not found.
			*/
			bool LoadSpecificElement(int NRE_List, int lineNumber,int NRC_Colomn,void *address) const;

			/** Get the number of lines in a list of the metamodel, for when you add a dialog.
			@param NRE_List is the element ID of your CSREditList in your CSRDialog.
			@return the line count. Returns 0 in case of errors.
			*/
			int	GetSpecificLineCount(int NRE_Liste) const;

			bool	SaveSpecificElement(	int 	ERId_Element,
											void	*address) const;
			bool	SaveSpecificElement(	int 	ERId_List,
											int 	lineNumber,
											int 	CNb_Column,
											void	*address) const;
			bool	SaveSpecificLineCount(	int   ERId_List, int newLineCount);

			/** Create an instance of the meta model with the parameters.
			Read the data from the database, then Call Initialise for user initialisation.  
			@param meta_model is the meta model name.
			@param id is the id in the table META_MODEL; if 0, there is no linked data.
			@return a new instance not null which must not be deleted.
			@throws CSRPrototype::ExceptionNotFound is meta_model is not a meta model name.
			@throws OracleException if the query is not correct
			*/
			static CSRMetaModel * CreateInstance(const char * meta_model, long id);


			/** Edit the class throw a modal dialog.
			@return true if the data has been modified.
			*/
			bool	OpenDialogInWriteMode();


			/** Show the data throw a modal dialog.
			*/
			void	OpenDialogInReadMode(const instrument::CSRInstrument * instrument) const;

			/** Fill dialog opened in read mode with some specific metamodel results.
			@param dlg the dialog to initialise
			@param instrument the instrument for which we initilaise the dialog
			@since 6.0
			*/
			virtual void InitialiseResultsInDialog(gui::CSRFitDialog *dlg,const instrument::CSRInstrument * instrument) const;

			/** Save the infos user in the table META_MODEL.
			Does not commit.
			@param id is the id in the table META_MODEL.
			@throws OracleExeception
			@since 5.2.2 : this method is virtual for toolkit purpose
			*/
			virtual void Save(long id);

			/** Save the infos user in the table META_MODEL creating a new id.
			Does not commit.
			@param metaModel the metamodel for which data must be saved.
			@param id is the new id in the table META_MODEL that hes been used.
			@throws OracleExeception
			@since 5.3 : this method calls the virtual Save
			@see Save(long id)
			*/
			static bool SaveMetaModelData(CSRMetaModel *metaModel, long &usedID);

			/** 
			 * For versioning of meta model modification.
			 */
			static void SetVersion(int version);

			/** 
			 * For versioning of meta model modification.
			 */
			static int GetVersion();

			/** Get the delta and gamma of one risk source by finite difference.
			It is not virtual and essentially for internal usage, but may be called to calculate it
			by finite difference assuming the fair value is already calculated in the management value.
			@param context is a market data.
			@param delta is the output parameter for the delta expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1 of the underlying spot.
			@param gamma is the output parameter for the gamma expressed in the currency of the instrument as a variation
			of the delta, for a variation of 1 of the underlying spot.
			@param undlCode is the underlying code.
			By default, check if GetPriceDeltaGamma has been overloaded; if yes, call it else
			do the same finite difference as the default algorithm for GetPriceDeltaGamma excepting that the
			fair value already computed {@link fManagementTheoreticalValue} is used for the fair value.
			@see GetDeltaGamma
			@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
			to a code (sicovam, currency, ...)
			*/
			virtual void	GetDeltaGammaByFiniteDifference(	const instrument::CSRInstrument & instrument,
											const market_data::CSRMarketData& context, 
											const sophis::CSRComputationResults& results,
											double				*delta, 
											double				*gamma, 
											int 				undlCode) const;



			/** Get the cash flow diagram if implemented.
			@return true if the cash flow diagram is computed at the metamodel level. False by default
			@param instrument the instrument for which the cash flow must be computed
			@param context is a market data
			@param diag is a pointer to the cash flow diagram created
			This is used for the scenario cash flow diagram. It is also used to calculate the duration.
			@since 5.3
			@see CSRCashFlowDiagram
			*/
			virtual bool new_CashFlowDiagram(	const instrument::CSRInstrument&			instrument,
												const market_data::CSRMarketData&			context,
												sophis::instrument::CSRCashFlowDiagram*&	diag) const;

			// INTERNAL.
			// @version 5.3
			void			SetInfosUser( infos_user * infosUser , bool todelete = false) const;

			// INTERNAL.
			// @version 5.3
			infos_user *	GetInfosUser() const;

			/** Get the vega Market of one instrument risk source.
			If the instrument is a currency, the risk is supposed to be with the forex instrument/currency volatility.
			@param context is a market data.
			@param undlCode is the underlying code.
			@return the vega Market expressed in the currency of the instrument as a variation
			of the fair value for a variation 1 of the underlying.
			The vega must be calculated using the Risk volatility.
			This method may be called during a scenario (for instance a risk matrix of vega when preference bump market plot is set).
			It is called also by {@link CSRInstrument::RecomputeAll}.
			By default, the algorithm is
			- if vega market is available for the volatility of the underlying(CSRVolatility::isVegaMarketAvailable)
			- Ask {@link GetDerivationParameters} with gpVega to get the bump choosed.
			- Creates a new market data switching the volatility and bumping it's market plot using {@link CSRMarketData::GetCSRVolatilityComputation}
			- Calculates the finite difference calling {@link GetTheoriticalValue}
			- Expresses the result for 1% variation.
			- else call GetVega(context, whichUnderlying)
			@since 5.3.6
			@version 7.1 The last int parameter was changed from an index (between 0 and GetUnderlyingCount)
			to a code (sicovam, currency, ...)
			*/
			virtual double	GetVegaMarket(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int undlCode) const;

			/** Get the vega market equity.
			@param instrument is the instrument.
			@param context is a market data.
			@return the vega market expressed in the same unit and currency as the instrument.
			This method is called, for instance, by the risk matrix to show the vega
			when only this option is ticked.
			By default, it checks if one underlying is an equity and if yes, it bumps all
			the volatilities of equity underlying.
			@since 5.3.6
			*/
			virtual	double	GetEquityGlobalVegaMarket(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context) const;


			/** Get the vega market equity displayed in the portfolio.
			@param instrument is the instrument.
			@since 5.3.6
			*/
			virtual double	GetEquityGlobalVegaMarket(const sophis::instrument::CSRInstrument & instrument, const sophis::CSRComputationResults& results) const;


			bool GetDataToDelete() const;

			/**	Check if the model is able to price a given instrument.
			This method is used to filter the models, therefore, it should return quickly.
			@param toCheck is the instrument to check.
			@param message is optional (may be null) and is to describe the reason why it cannot be priced.
			@return true if the model is able to price the instrument, false otherwise.
				By default, this method always returns true.
			@version 6.0
			*/
			virtual bool	IsAbleToPrice( const instrument::CSRInstrument & toCheck, _STL::string *message ) const;

			// "Private" class to ensure market category scope

			virtual void PreviousResultsCleanup(sophis::CSRComputationResults& previousResults) const;
			virtual void UpdateRhoSourcesCrossCcyDiscounting(const sophis::instrument::CSRInstrument & instr, const sophis::market_data::CSRMarketData &param, /*out*/ sophis::CSRComputationResults& results) const;
		
			class SOPHIS_FIT ResultsStatistics
			{
			public:				
				ResultsStatistics();
				virtual ~ResultsStatistics();
			};

			virtual ResultsStatistics* ResultsStatisticsCollect(const sophis::CSRComputationResults& results) const;
			virtual void ResultsStatisticsUpdate(const ResultsStatistics* stats,sophis::CSRComputationResults& results) const;
			
			
			class SOPHIS_FIT OtherSetting
			{
			public:
				virtual ~OtherSetting();
			};

			class SOPHIS_FIT SSMMHandler_
			{
			protected:
				SSMMHandler_();	// dummy

			private:
				SSMMHandler_(const finance::CSRMetaModel & metamodel, const instrument::CSRInstrument& instr,OtherSetting* otherSetting);

				SPH_BEGIN_NOWARN_EXPORT
				_STL::shared_ptr<sophis::instrument::CSRMarketCategoryHandle> fMarketCategoryHandle;
				_STL::shared_ptr<OtherSetting> fOtherSettingHandle;
				SPH_END_NOWARN_EXPORT

				const CSRMetaModel& model;

				SSMMHandler_& operator=(const SSMMHandler_&);
				friend class CSRMetaModel;
				friend class SSMetaModelHandler;
			};
			/**
			* Method to get the metamodel to use to price an instrument by using the priority rules:
			*	- first use Forced metamodel if any {@link CSRInstrument::GetForceMetamodel},
			*	- second use the one defined in the pricer category if any,
			*	- otherwise use the default metamodel for this instrument {@link CSRInstrument::GetDefaultMetamodel}.
			* Retrieve the model through SSMetamodelHandler
			*/
			static SSMMHandler_ GetMetaModelByPriority(const instrument::CSRInstrument& instr);
		
			/*Data used for pricing per position. Key is stored at position level see TViewMvts::metaModelId*/
			/*Generate a unique key for a couple(metamodel name, data id)*/
			static long GenerateKey(_STL::string metaModelName, long dataId);
			/*Has a such key in map ?*/
			static bool HasKey(long key);
			/*Get the name of the metamodel*/
			static _STL::string  GetNameByKey(long key);
			/*get the data id of the meta model*/
			static long GetDataIdByKey(long key);
			/*Register MetaModel in global map*/
			static void RegisterModel(CSRMetaModel* instance,long key);
			/*Get MetaModel by key*/
			static const CSRMetaModel* GetModel(long key);
		
			/*Struct to describe meta Model (metamodel name + model id)*/
			struct SOPHIS_FIT MetaModelDescription
			{
				MetaModelDescription()
				{
					pDataId= 0;
				}
				_STL::string pName;
				long pDataId;
				bool operator < (const  MetaModelDescription& right) const;
			};

			/*Accessors to key to descritpion and descritption to key maps*/
			static const _STL::map<long, MetaModelDescription>& GetRegisteredModelsKey(){return fKeyToDescription;}
			static const _STL::map<MetaModelDescription,long>& GetRegisteredModelsDescriptions(){return fDescriptionToKey;}
			static void CleanRegisteredModels();
		protected:
			/** Initialisation.
			Used for user parameter, because the constructor has no parameter.
			By default does nothing.
			@see CreateInstance.
			*/
			virtual void Initialise();
			void Initialize(const CSRMetaModel &model);

		public:
			/** This method returns the "id" which was used for saving the CSRMetamodel.
			@return the "id" which was used for saving the CSRMetamodel.
			@see Save.
			@see fId.
			@since 5.2.2
			*/
			int GetID() const {return fId;}

			/** Name of the no meta model.
			@since 6.0.1
			*/
			static const char * gNoMetaModelName;
		protected:
			static _STL::map<long,CSRMetaModel*> pkey2Model;

			static int		fVersion;
			
			mutable infos_user *	fInfosUser;
			mutable bool			fDataToDelete;
			static _STL::map<long, MetaModelDescription> fKeyToDescription;
			static _STL::map<MetaModelDescription,long> fDescriptionToKey;
		protected:
			/**
			 *	Identifier of a calibration used to optimize calibration scenario. During a calibration this member 
				can be checked in order to know if stored calibration data are already.
			 * 
			 @since 5.3.1 
			 */
			int fId;
			long		fCalibrationID;
			std::string fName;

		private:
			//DEPRECATION
			DEPRECATED_SIGNATURE virtual void	RecomputeAll(instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;
			DEPRECATED_SIGNATURE virtual void GetDeltaGamma(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double *delta, double *gamma, int whichUnderlying) const;
			DEPRECATED_SIGNATURE virtual void	RecomputeRho(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double price) const;
			DEPRECATED_SIGNATURE virtual void	RecomputeYTM(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double price) const;
			DEPRECATED_SIGNATURE virtual void	RecomputeCreditRisk(instrument::CSRInstrument & instrument, const market_data::CSRMarketData& context, double price) const;
			DEPRECATED_SIGNATURE virtual void RecomputeInflationSensitivities(	instrument::CSRInstrument& instrument,const market_data::CSRMarketData& context) const;
			DEPRECATED_SIGNATURE virtual double	GetEquityGlobalVega(const instrument::CSRInstrument & instrument) const;
			DEPRECATED_SIGNATURE virtual double GetImpliedVolatility(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData & param,double premium, double accuracy = NOTDEFINED) const;
			DEPRECATED_SIGNATURE virtual double	GetEquityGlobalVegaMarket(const instrument::CSRInstrument & instrument) const;
			DEPRECATED_SIGNATURE virtual bool	IsAbleToPrice( const instrument::CSRInstrument & toCheck ) const;
			DEPRECATED_SIGNATURE virtual void GetDeltaGammaInPricingWindow(const instrument::CSRInstrument& instr,const market_data::CSRMarketData& context,double price,double delta,double gamma,int which,double &deltaOut,double &gammaOut) const;
			DEPRECATED_SIGNATURE virtual	void	SetVegaCompo(instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const;
			DEPRECATED_SIGNATURE virtual	void	FinPanier(instrument::CSRInstrument& instr, double delta, double gamma) const;

			DEPRECATED_RISKSOURCES virtual void GetAdditionalDeltaVegaSources(const instrument::CSRInstrument& instrument, _STL::vector<long> &additionalSources) const;
			DEPRECATED_RISKSOURCES virtual int GetUnderlyingCount(const instrument::CSRInstrument& instrument) const;
			DEPRECATED_RISKSOURCES virtual long GetUnderlying(const instrument::CSRInstrument& instrument, int which) const;
			DEPRECATED_RISKSOURCES virtual int GetRhoCount(const instrument::CSRInstrument& instrument) const;
			DEPRECATED_RISKSOURCES virtual long GetRhoCurrency(const instrument::CSRInstrument& instrument, int which) const;
			DEPRECATED_RISKSOURCES virtual void GetInflationSources(const instrument::CSRInstrument& instrument, _STL::set<long> &codeList) const;
			DEPRECATED_RISKSOURCES virtual void GetCreditRiskSources(const instrument::CSRInstrument& instrument, _STL::set<instrument::SSCreditRiskSource> &outCreditRiskSources) const;
			DEPRECATED_RISKSOURCES virtual bool	IsADeltaUnderlying(const instrument::CSRInstrument& instrument, int whichUnderlying) const;
			DEPRECATED_RISKSOURCES virtual bool	IsAVegaUnderlying(const instrument::CSRInstrument& instrument, int whichUnderlying) const;
			DEPRECATED_RISKSOURCES virtual bool	IsAnEpsilonUnderlying(const instrument::CSRInstrument& instrument, int whichUnderlying) const;
			DEPRECATED_RISKSOURCES virtual Boolean	IsARhoCurrency(const instrument::CSRInstrument& instrument, long currency, int *whichUnderlying=0) const;

			DEPRECATED_OBSOLETE virtual double	GetTheoreticalValue_Private(const instrument::CSRInstrument &instrument, const market_data::CSRMarketData &context, _STL::vector<instrument::SSCaplet>*vectorToFill,int startFlowIndex = -1,int endFlowIndex   = -1) const;
			DEPRECATED_OBSOLETE virtual void ComputeCreditRiskSensitivities_Private(const instrument::CSRInstrument& instr,const market_data::CSRMarketData &context,double refPrice,double &sensitivity,double &convexity) const;

			_SOPHIS_DEPRECATED("Obsolete - Use ComputeInflationSensitivities instead") virtual void GetInflationSensitivities(const instrument::CSRInstrument	&instrument,const market_data::CSRMarketData&context,double &sensitivity,double &convexity,long inflationCode1,long inflationCode2) const;
			_SOPHIS_DEPRECATED("Obsolete - Use ComputeInflationVega instead") virtual double GetInflationVega(const instrument::CSRInstrument	&instrument,const market_data::CSRMarketData&context,int which) const;

			_SOPHIS_DEPRECATED("Obsolete - Call ComputeAll and override ComputeAllCore") virtual void	RecomputeAll(instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const;

		};


		// Scoped object which should be alive as long as the model is needed
		class SOPHIS_FIT SSMetaModelHandler
		{
		public:
			// To retrieve model from GetMetaModelByPriority
			SSMetaModelHandler(const CSRMetaModel::SSMMHandler_& h);
			~SSMetaModelHandler();
			const CSRMetaModel& model;
		private:
			SPH_BEGIN_NOWARN_EXPORT
			_STL::shared_ptr<sophis::instrument::CSRMarketCategoryHandle> fMarketCategoryHandle;
			_STL::shared_ptr<CSRMetaModel::OtherSetting> fOtherSettingHandle;
			SPH_END_NOWARN_EXPORT

			SSMetaModelHandler(SSMetaModelHandler & source);
			SSMetaModelHandler& operator = (const SSMetaModelHandler& a);
		};

		class SOPHIS_FIT SSMetaModelScope : public SSMetaModelHandler
		{
		public:
			SSMetaModelScope(const sophis::instrument::CSRInstrument& instr);
			~SSMetaModelScope();
		private:
			SSMetaModelScope(const SSMetaModelScope&);
			SSMetaModelScope& operator = (const SSMetaModelScope&);
		};
	}
}

SPH_EPILOG



#endif
