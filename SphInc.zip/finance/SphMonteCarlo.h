/*
*    File:       SphMonteCarlo.h
*
*    Contains:   The "Monte Carlo" pricing model and how to overload it
*
*    Copyright:  � 1995-2000 Sophis.
*
*/

/*! \file SphMonteCarlo.h
	\brief Monte Carlo pricing model.
*/

#ifndef _SphMonteCarlo_H_
#define _SphMonteCarlo_H_

#include "SphInc/instrument/SphClause.h"
#include "SphInc/instrument/SphOption.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/finance/SphDefaultMetaModelOption.h"
//#include "SphInc/instrument/SphInstrumentCompatibility.h"

BOOST_INCLUDE_BEGIN
#include BOOST_INCLUDE_PATH(numeric\ublas\matrix.hpp)
BOOST_INCLUDE_END

#include __STL_INCLUDE_PATH(vector)


#include "SphInc/SphMath.h"




SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace sophis
{
	namespace finance
	{

/**	This structure class contains the basic underlying information used by the class.
*	CSRMonteCarlo for sampling paths.
*/
struct SOPHIS_FINANCE SSMCUnderlying
{
/**	Default Constructor. Set all internal variables to zero.
*/
    SSMCUnderlying();
/**	Destructor.
*/
    ~SSMCUnderlying();
/**	Underlying code.*/
    long    fUnderlyingCode;
/**	Quanto Compo flag.*/
	sophis::instrument::eQuantoType fQuantoCompo;
/**	Underlying currency code.*/
    long    fCurrency;
/**	Specifies the number of dates used to sample a trajectory.*/
    int     fNbPoints;
/**	Array of sampling dates. Dimension is SSMCUnderlying::fNbPoints.*/
    double  *fDate;
/**	Array of underlying forward prices at dates fDates. Dimension is SSMCUnderlying::fNbPoints.*/
    double  *fForwardPrice;
/**	Array of underlying volatility at dates fDates. Dimension is SSMCUnderlying::fVolatility.*/
    double  *fVolatility;
/**	Array of underlying linear value at dates fDates (S = aF+b) . Dimension is SSMCUnderlying::fVolatility.*/
    double  *fa;
/**	Array of underlying linear value at dates fDates (S = aF+b) . Dimension is SSMCUnderlying::fVolatility.*/
    double  *fb;
/**	Initializing internal data from another underlying.*/
    SSMCUnderlying & operator =(const SSMCUnderlying &);
};
/**	An interface class to implement an uniform generator.
*	This is an almost virtual class. Overload it to define your own
*	uniform law generator.
*/
class SOPHIS_FINANCE CSRUniformGenerator
{
public:
/**	Default Constructor.*/
	CSRUniformGenerator(){};
/**	Default Destructor.*/
	virtual ~CSRUniformGenerator(){};
/**	Destructor. Useful, when managing is necessary.*/
	virtual void Delete(){};
/** Retrieve the next sampling of uniform law.
*	Sample a N dimensional vector of uniform law.
*	@param Vector is a double * structure (must be initialized).
*	@param dimension is the size of Vector.*/
	virtual void GetNextUniformVector(int dimension, double* Vector) ;
/** Reset the generator to its first sample.
*   @param seed. If seed = -1, the generator has to be reset to its first value.
*	Other parameters of Seed are allowed if the generator is able
*	to reset its sequence to one other than its original.
*/
	virtual void ResetSequence(long Seed=-1);
};
/**	Sampling path computation class.
*	A class that handles sampling of vector of normal law with a
*	given correlation matrix. This class uses a CSRUniformGenerator member
*	to sample a given uniform law generator member.
*/
class SOPHIS_FINANCE CSRRandomGenerator
{
public:
/**Default Constructor.*/
	CSRRandomGenerator();
/** Dtor.*/
	virtual ~CSRRandomGenerator();
/** Constructor specifying the maximum dimension pricing as well as the uniform generator used.
*	The Uniform Generator pointer UniformGenerator is deleted in the destructor.
*	@param NbPoints specifies the number of dates over which the trajectory is to be sampled.
*	@param NbVariables specifies the number of underlyings.
*	@param UniformGenerator. Specifies the uniform generator to be used for sampling.
*	If no special generator is specified (UniformGenerator = 0), the default uniform generator is a Sobol one.
*	NbPoints*NbVariables samples of independent uniform law may be necessary to sample a single trajectory.
*	Thus the uniform generator used should be capable of generating vector of independent NbPoints*NbVariables uniform law at once.
*/
	CSRRandomGenerator(int NbPoints,int NbVariables,CSRUniformGenerator* UniformGenerator = 0);
/** Retrieve the next sampling of uniform law.
*	Sample a N dimensional vector of uniform law.
*	@param Vector is a double * structure (must be initialized).
*	@param dimension is the size of Vector (should be less than fNbPoints*fNbVariables).*/
	void GetNextUniformVector(int dimension,double* UniformVector);
/** Retrieve the next sampling of normal law.
*	Sample a N dimensional vector of normal law.
*	@param Vector is a double * structure (must be initialized)
*	@param dimension is the size of Vector (should be less than fNbPoints*fNbVariables).*/
	void GetNextNormalVector( int dimension,double* NormalVector);
/** Set the correlation matrix.
*	This method sets the correlation matrix. It is used to calculate a correlated normal sampling.
*	@param VarCoVarMatrix is a symmetric variance/covariance matrix or a correlation one.
*	The matrix dimension must be symmetric of dimension CSRRandomGenerator::fNbVariables square.
*	@see GetNextCorrelatedNormalValue
*/
	void   SetCorrelationMatrix(UblasMatrixSymDb & VarCoVarMatrix);
/**	Calculates a correlated normal sample vector using the correlation matrix.
*	@param NormalVector is a normal sample vector of dimension CSRRandomGenerator::fNbVariables.
*	@see SetCorrelationMatrix.
*/
	void	GetNextCorrelatedNormalValue(double *NormalVector);

	/**	Calculates a correlated normal sample vector using the correlation matrix.
	*	@param NormalVector is a normal sample vector of dimension CSRRandomGenerator::fNbVariables.
	*	@param OutputVector is the vector filled with correlated gaussian sampling, the vector should 
	*	be resized at the proper size before the method is used (CSRRandomGenerator::fNbVariables).
	*	@see SetCorrelationMatrix.
	*/
	void	GetNextCorrelatedNormalValue(double *NormalVector, _STL::vector<double>& outputVector);

/**	Calcalates a normal sample with a given correlation matrix.
*	@param  lequelSJ :		underlying number.
*	@param  lequelSample :	number corresponding to the point of the path where the sample has to be retrieved.
*	@param  VecteurNormal : independant Normal Vector. Must be initialized of dimension fNbPoints*fNbVariables.
*	@return CorrelatedNormalValue.
*	@see GetNextCorrelatedNormalValue.
*	@see NbPoints.
*	@see NbVariables.
*/
	void  GetCorrelatedNormalValue(int lequelSJ, int lequelSample,const double *VecteurNormal, double &CorrelatedNormalValue);
/**	To set a user defined uniform generator.
*	@param UniformGenerator is a uniform law generator.
*	The pointer UniformGenerator is deleted by the class Destructor.
*	@see class CSRUniformGenerator.
*/
	void SetRandomGenerator(CSRUniformGenerator* UniformGenerator);
/**	To get the uniform generator used for sampling.
*	@see class CSRUniformGenerator.
*/
	CSRUniformGenerator* GetRandomGenerator();

	void SetForcedCholeskyMatrix(const UblasMatrixDb* matrixIn);

	static void GetCholeskyMatrixFromCorrelationMatrix(const UblasMatrixSymDb& matrixIn, UblasMatrixDb& matrixOut);
protected :
/** Number of dates necessary to generate a trajectory on one underlying.*/
	int			fNbPoints;
/** Number of underlyings.*/
	int			fNbVariables;
/** Number of dates necessary to generate a trajectory on one underlying.*/
	double * fUniformVector;
/** Cholesky Matrix retrieved from the correlation matrix.*/
	UblasMatrixDb  fCholeskyMatrix;

	const UblasMatrixDb* fCholeskyMatrixPtr;
private :
	static void FromCovarianceToCorrelation(UblasMatrixDb& matrixOut);
/**	Pointer to the uniform generator used for sampling.
*	This pointer is deleted by the class destructor.
*	@see class CSRUniformGenerator.
*/
	CSRUniformGenerator*				fUniformGenerator;
	_STL::vector<double>				fTemp;
	friend class CSRMonteCarlo;
};
/** Used for Monte Carlo Simulation.
*	Then used during calculation to sample the paths.*/
class SOPHIS_FINANCE CSRMonteCarlo
{
public:
/** Constructor.
*	Build a CSRRandomGenerator with no specified generator and
*	stores it into the variable CSRMonteCarlo::fRandomGenerator.
*	@param NbPoints is the number of points to generate a trajectory on each underlying.
*	@param NbVariables is the number of underlyings.
*	Thus NbPoints*Nbvariables independent samples are necessary to generate a trajectory.
*/
    CSRMonteCarlo(int NbPoints,int NbVariables, const market_data::CSRMarketData& context);
/** Destructor.*/
    ~CSRMonteCarlo();
/** retrieve the next independent uniform law sample vector from the generator
*	CSRMonteCarlo::fRandomGenerator.
*	@param NormalVector is a vector of dimension dimension. It must be initialized with a dimension greater than Dimension.
*/
    virtual void    GetNextNormalVector(int dimension, double *NormalVector);
/** Retrieve the next independent normal law sample vector from the generator
*	CSRMonteCarlo::fRandomGenerator.
*	@param UniformVector is a vector of dimension Dimension.
*	UniformVector must be initialized.
*/
    virtual void    GetNextUniformVector(int dimension,double *UniformVector);
/** For compatibility with previous version. Populates Normal Vector and Uniform vector with
*	normal and uniform vector of dimension Dimension. We do not recommend using this
*	method if independancy between the two samples is required.
*/
	void	GetNextRandomVector(int dimension,
							double *NormalVector,
							double *UniformVector);
/**	Sample N Path for a given underlying.
*	@param which is the underlying number.
*	@param NbPoints	is the number of sampling dates required (must be less than fNbPoints).
*	@param VecteurNormal is a normal sample retrieved from CSRMonteCarlo::GetNextNormalVector.
*	@return Spots is a double * vector that contains the sample paths (must be initialized of size NbPoints).
*	@return AntitheticSpots is * vector that contains the antithetic sample paths (must be initialized of size NbPoints).
*	variables ithSimulation,double spotForSimulation
*	are useless but kept for historical compatibility.
*/
    virtual void    GetSampleValues(int which,const double *VecteurNormal,double *Spots, double *AntitheticSpots,int NbPoints,int ithSimulation,double spotForSimulation);
/**	Fill the correlation matrix from the option data's underlying.
*	@param Option contains the underlying datas.
*	@see CSRRandomGenerator::SetCorrelationMatrix.
*/
    void    SetCorrelationMatrix(const sophis::instrument::CSROption *option) const;
/**	Initialize the class SSMCUnderlying data vector.
*	@param Option contains the underlying datas vector.
*	@see SSMCUnderlying.
*/
    void    SetData(SSMCUnderlying *data);
/**	Accessor to the variable CSRMonteCarlo::fRandomGenerator.
*/
    inline CSRRandomGenerator  *GetRandomGenerator(){return fRandomGenerator;};
/**	Accessor to the variable CSRMonteCarlo::fRandomGenerator.
*/
    inline void  SetRandomGenerator(CSRRandomGenerator  * RandomGenerator){fRandomGenerator=RandomGenerator;};
protected :
/** The number of points necessary to generate a trajectory on one underlying.
*/
    int                     fNbPoints;
/** The number of underlyings.
*/
    int                     fNbVariables;
/** Pointer to the sampling class generator.
*	This Pointer is deleted by the class destructor.
*	@see class CSRRandomGenerator.
*/
    CSRRandomGenerator*     fRandomGenerator;
/** Pointer to the underlying class vector.*/
    SSMCUnderlying*         fSSMCalPtr;
/** Pointer to the market data.*/
    const   market_data::CSRMarketData*  fMarketData;
};

class CSROptionMonCar;

class SOPHIS_FINANCE SSMCUnderlyingList{
public:
    SSMCUnderlyingList();
    ~SSMCUnderlyingList();
    void Initialise(int N,int NbRho);
    SSMCUnderlying *fMCUPrice;
    SSMCUnderlying *fMCUDeltaPlus;
    SSMCUnderlying *fMCUDeltaMinus;
    SSMCUnderlying *fMCURhoPlus;
    SSMCUnderlying *fMCURhoMinus;
    SSMCUnderlying *fMCUEpsilon;
};


struct SSShare{
    long    code;
    long    currency;
    sophis::instrument::eQuantoType type;
};

struct SSPoint
{
    double fDate;
    double fVolatility;
    double fForwardPrice;
    SOPHIS_FINANCE void operator =(const SSPoint&) ;
};


class CSRControlVariate;

typedef double  *(CSROptionMonCar::*MonteCarloPayoff)(SSMCUnderlying &data,double **S,double start_date,double end_date) const;

class CSRMonteCarloGraphics	
{
public:
	virtual void ProblemWithGraph()=0;
	virtual int Initialise( int				pointCount,
	                        int				numberOfValuesByPoint=1,
							char			*name="")=0;
	virtual void SetPoint(	double			value,
							short			nthPointValue=0  // 0 <= nthPointValue < numberOfValuesByPoint
							)=0;
	virtual void Done()=0;
	void         SetErrorCode( long code ){ fErrorCode = code ;}  
	long         GetErrorCode() const { return fErrorCode ;}  
protected:
	CSRMonteCarloGraphics() : fErrorCode(0) {}
	long fErrorCode ;
};

class SOPHIS_FINANCE CSRDefaultMetaModelOptionMonCar : public virtual CSRDefaultMetaModelOption
{
public:
	DECLARATION_META_MODEL(CSRDefaultMetaModelOptionMonCar);
	virtual ~CSRDefaultMetaModelOptionMonCar();
	
	virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
	//virtual void GetDeltaRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
	//virtual void GetRhoRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;

	/**	@see GetTheoreticalValue(const market_data::CSRMarketData & context).*/
	virtual double  GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData & context) const OVERRIDE;

	/**	Calculates the theoretical value and delta gamma greeks of the option using a Monte Carlo simulation.
	*	Optimized for greeks computations.
	*/
	virtual void	GetPriceDeltaGamma(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, double *price,double *delta, double *gamma,int whichUnderlying) const OVERRIDE;

	virtual void    RecomputeAllSmile(CSROptionMonCar& option, const market_data::CSRMarketData& context, sophis::CSRComputationResults& results) const;

protected:
	virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;
};

/** Option based on Monte Carlo pricer.
*	This Monte Carlo simulation is capable of antithetic sampling, control
*	variationb, and to take the volatility structure (avallaneda method).
*/
class SOPHIS_FINANCE CSROptionMonCar : public virtual sophis::instrument::CSROption
{
    DECLARATION_OPTION(CSROptionMonCar)
public:
/** Destructor.
*/
    virtual ~CSROptionMonCar();
	virtual const sophis::finance::CSRMetaModel* GetForceMetaModel() const OVERRIDE;

/** Calculates the theoretical value of the option by a Monte Carlo simulation.*/
    virtual double  GetTheoreticalValue(const market_data::CSRMarketData & context, CSRMonteCarloGraphics *graph) const;
/** This methods builds the MonteCarlo Pricer. This method creates a new CSRMonteCarlo.
*	Overload this method to set your own uniform generator.
*	@param NbPoints specifies the number of sample point to make a trajectory.
*	@param NbVariables specifies the number of underlying.
*	@param context specifies Market Data class.
*	@see class CSRMonteCarlo, class CSRUniformGenerator.
*/
    virtual CSRMonteCarlo*  GetNewCSRMonteCarlo(int NbPoints,int NbVariables, const market_data::CSRMarketData& context) const;
/**	Returns the underlying asset's code.
*	@param which is the underlying number.
*/
    //virtual long    GetUnderlying(int which) const;
/** This method returns the currency code of the which-th security's rho.
*/
    //virtual long    GetRhoCurrency(int which) const;
/**	This method calculates the theoretical value using the Monte Carlo Pricer.
*	The pricing consists of averaging the value over the number of sampling paths
*	in the following procedure :
*	1) Sample the underlying path.
*	@see  CSRMonteCarlo ::GetSampleValues.
*   2) Evaluate the option payoff over this sample.
*	@see  CSRMonteCarlo ::fMonPayOff.
*	@param context : Market Data.
*	@param number_paths : Number of sampling paths used for the Monte Carlo Simulation.
*	@param data			: NbVariables vector of underlying structure.
*	@param start_date	: Starting date of the simulation.
*	@param end_date		: Ending date of the simulation.
*	@param today		: Today's date.
*	@param pay_date		: Current date of the equity.
*	@param alpha		: Alpha coefficient of the control variate.
*	@param graph		: If graphics are available.
*	@return Paiement.	: Theoretical Value.
*	@see SSMCUnderlying.
*	@see fNbVariables.
*	@see fAlpha.
*/
    virtual void            MonteCarloPricer(	const market_data::CSRMarketData& context,
												int number_paths,
												SSMCUnderlying *data,
												double *Paiement,
												double start_date,
												double end_date,
												double today,
												double pay_date,
												double& alpha,
												CSRMonteCarloGraphics * graph) const;
/** Calculate the theoretical value and the sensitivities of the option using
*	the same set of path.
*/
	void            MonteCarloRecomputeAll(const market_data::CSRMarketData& context, sophis::CSRComputationResults& results);
/** Check if the instrument can be handled by the pricer.*/
    virtual         Boolean ValidInstrument() const ;
/** Fill a string chain, identifying the pay off formula.*/
    void            GetPayOffFormula(char *result) const;
/** Const SSMCUnderlyingList *GetListeDonnees() const{ return &fDListe;}*/
/** Returns the number of average clauses. */
    short           GetNbClauseAverage() const
                    {   return fNbAverage   ;}
/** Returns the number of departure averaged clauses.*/
    short           GetNbClauseAverageStart() const
                    { return fNbAverageStart;}
/** Returns the number of baskets used as underlyings. */
    short           GetNbClauseBasket() const
                    { return fNbBasket;}
/** Returns the number of cliquet clauses.
*/
    short           GetNbClauseCliquet() const
                    { return fNbCliquet;}
/** Returns the number of performance clauses.
*/
    short           GetNbClausePerformance() const
                    {return fNbPerformance;}
	const sophis::instrument::SSClause* GetClausePerformance() const
					{return fClausePerformance;}

	short			GetNbFloor() const
					{return fNbFloor;}
	const sophis::instrument::SSClause* GetClauseFloor() const
					{return fClauseFloor;}

	short			GetNbCap() const
					{return fNbCap;}
	const sophis::instrument::SSClause* GetClauseCap() const
					{return fClauseCap;}

	short			GetNbForwardStart() const
					{return fNbForwardStart;}
	const sophis::instrument::SSClause* GetClauseForwardStart() const
					{return fClauseForwardStart;}

	short			GetNbCliquet() const
					{return fNbCliquet;}
	int				GetNbUnderlyings() const
					{return fNbUnderlyings;}
	double			GetMCSmile() const
					{return fMCSmile;}
	MonteCarloPayoff GetMonPayOff() const
					{return fMonPayOff;}
	bool			GetUseVariateControl() const
					{return fUseVariateControl;}
	void			SetUseVariateControl(bool b) const
					{fUseVariateControl=b;}
	double			GetComputationDate() const
					{return fComputationDate;}
	void			SetComputationDate(double d)
					{fComputationDate=d;}
	void			SetCreditSpread(double d)
					{fsignature=d;}
	void			ClearNormalVector();

/** True if variate control is possible for the intrument (for asian and cliquet options), false else.
*/
    bool            UseVariateControl() const;
/** True if antithetic sampling is available for the intrument (only one underlying) false else (smiled monte carlo).
*/
    virtual bool    UseAntitheticSampling() const;
/** True if an uniform sampling vector is needed (lookback, extremum and barrier options), false else.
*/
    virtual bool    UseUniformVector() const;
/** True  : delta and gamma calculations are required.
*/
	virtual bool ComputeDeltaGamma() 	const;
/** True  : epsilon calculations are required.
*/
	virtual bool ComputeEpsilon() 	 	const;
/** True  : crossed gamma calculations are required.
*/
	virtual bool ComputeCrossedGamma()	const;
/** True  : FX delta and gamma computations are required.
*/
	virtual bool ComputeDeltaGammaFX()	const;
/** True  : Vega calculations are required.
*/
	virtual bool ComputeVega()			const;
/** True  : crossed vega calculations are required.
*/
	virtual bool ComputeCrossedVega()	const;
/** True  : Rho convexity calculations are required.
*/
	virtual bool ComputeRhoConvexity()	const;
/** Specific methods for Lookback and extremum options may be overwritten.
*	This method calculates the Brownian bridge associated with the minimum of the spot,
*	during a time interval, knowing the spot values at the time interval boundaries.
*	@param SBegin. Spot value at begin date.
*	@param SEnd. Spot value at end date.
*	@param delta_t. Length of the time interval in year.
*	@param VarU. Uniform sampling (must be independent of the normal sample). Used to test whether the
*	the barrier is reached or not.
*	@param sigma. Volatility of the underlying.
*/
    virtual double  GetMinimum(
								double SBegin,
								double SEnd,
								double delta_t,
								double VarU,
								double sigma) const;
/** Specific methods for Lookback and extremum options may be overwritten.
*	This method calculates the Brownian bridge associated with the maximum of the spot,
*	during a time interval, knowing the spot values at the time interval boundaries.
*	@param SBegin. Spot value at begin date.
*	@param SEnd. Spot value at end date.
*	@param delta_t. Length of the time intervall in year.
*	@param VarU. Uniform sampling (must be independent of the normal sample). Used to test whether the
*	the barrier is reached or not.
*	@param sigma. Volatility of the underlying.
*/
    virtual double  GetMaximum(double SBegin, double SEnd, double delta_t, double VarU, double sigma) const;
/** Expiry date of the equity.
*/
    long    fDateFinExercice;
//    long    fCodeSousJacent;
/** Currency Code.
*/
    long    fDeviseExercice;
//    double  fExercice;
/** Starting date of the equity.
*/
    double  fDateDebutOption;
/** Boolean Vector of size NbVariables. Indicates if DataBase historical spots are available.
*/
    bool    *fBaseRemplie;
/** Methods to initialize the Pointer of SSMCUnderlying structure.
*	@param mc_underlying. SSMCUnderlying vector of dimension NbVariables (must be initialized).
*	@param context. Market Data.
*	@param Code.	Underlying code.
*	@param NumSj.	Number of the underlying to be initiliazed (less than NbVariables).
*/
    void    InitialiseSSMCUnderlying(SSMCUnderlying *mc_underlying,const market_data::CSRMarketData& context,long Code,int NumSj) const;
public:
/**	Valid Instrument for Smiled Monte Carlo.
*	@see ValidInstrument.
*/
	virtual         Boolean ValidInstrumentSmile() const ;
/**	This method calculates the theoretical value using the smiled MonteCarlo pricer.
*	The pricing consists of averaging the payoff value over the sampling paths.
*	It is a loop of the following procedure:
*	1) Sample the underlying path.
*	@see  CSRMonteCarlo ::GetSampleValues.
*   2) Evaluate the option payoff over this sample.
*	@see  CSRMonteCarlo ::fMonPayOff.
*	@param context		: Market Data.
*	@param number_paths : Number of sampling path used for the Monte Carlo Simulation.
*	@param data			: NbVariables vector of underlying structure.
*	@param start_date	: Starting date of the simulation.
*	@param end_date		: Ending date of the simulation.
*	@param today		: Today's date.
*	@param pay_date		: Current date of the equity.
*	@param alpha		: Alpha coefficient of the control variation.
*	@param graph		: If graphics are available.
*	@return Paiement.	: Theoretical Value.
*	@see SSMCUnderlying.
*	@see fNbVariables.
*	@see fAlpha.
*/
	virtual void    MonteCarloPricerSmile(	const market_data::CSRMarketData& context,
											int number_paths,
											SSMCUnderlying *data,
											double *Paiement,
											double start_date,
											double end_date,
											double today,
											double pay_date,
											double& alpha,
											CSRMonteCarloGraphics * graph) const;
/**	For Smiled Monte Carlo : Initialises the strike vector used for the calibration.
	@param context. Market Data.
	@param fVectStrike. Strike to be initialised.
*/
	virtual void	CollectAllCalibrationStrike(const market_data::CSRMarketData& context,
												_STL::vector<double>& fVectStrike);
/** For Smiled Monte Carlo : Maximum number of entered Calibration Dates. Default is 10.
*/
	virtual int		GetMaximalCalibrationCount() const;
/** For Smiled Monte Carlo : Minimum of days between end and start date option. Default is 60 days.
*/
	virtual double	GetMinimalDayCount() const;

protected:
/**	For Smiled Monte Carlo : calibration Dates array. Of size CSROptionMonCar::fdatecalibrationcount.*/
	long            *fdatecalibration;
/**	For Smiled Monte Carlo : maps the element of CSROptionMonCar::fdatecalibration into those of CSROptionMonCar::fDates. Array of size CSROptionMonCar::fdatecalibrationcount.*/
	int				*findicedatecalibration;
/**	For Smiled Monte Carlo : gives the number of dates used in the calibration.*/
    int             fdatecalibrationcount;
/** For Smiled Monte Carlo : fills the array CSROptionMonCar::fdatecalibration.*/
    virtual void    CollectAllCalibrationDates(const market_data::CSRMarketData& context, long startDate,long endDate);
/** For Smiled Monte Carlo : adds to CSROptionMonCar::fdate the calibration dates.*/
	void			CompleteDatesArray();
/** For Smiled Monte Carlo : Number of strikes used in the calibration.*/
	int				fstrikecount;
/**	Switch between smiled MonteCarlo method and the conventional MonteCarlo one. True is a smiled MonteCarlo simulation.*/
	bool			fMCSmile;
/**	For Smiled Monte Carlo. Calculate the weight CSROptionMonCar::fWeights assigned
*	and the Lagrange Multipliers CSROptionMonCar::flambdacalibration.
*	Collects in CSROptionMonCar::fPaths all sample paths generated
*	by the Monte Carlo simulation of the prior guess. */
	void			ComputeWeight(const market_data::CSRMarketData& context, const SSMCUnderlying *data) const;
/**	For Smiled Monte Carlo. Contains all sample paths generated by Monte Carlo of the prior guess.*/
	mutable _STL::vector<double>		fPaths;
/**	For Smiled Monte Carlo. Probabilities assigned to each path to the simulation. */
	mutable _STL::vector<double>		fWeights;
public:
/**	For Smiled Monte Carlo. Lagrange Multipliers used in the calculation of fWeights. */
	mutable _STL::vector<double>		flambdacalibration;

/**	For Smiled Monte Carlo. Optimisation variable. Set to true if CSROptionMonCar::flambdacalibration is already calculated.*/
	mutable bool					fUseLambdaCalibration;
private:
/**	For Smiled Monte Carlo. Number of already computed Lagrange Multipliers CSROptionMonCar::flambdacalibration.
*   If already calculated (fCompteur>0), the array CSROptionMonCar::flambdacalibration is used as an initial guess to calculate the new Lagrange multipliers.*/
	mutable int						fCompteur;
//--------------------------------------------------------------------

protected:
	// To ensure coherency between product and an instance of a derived class of 
	// CSROption parameters when we call SetStrikeInProduct
	virtual	void			RefreshOptionWithStrikeInProduct();

public:
/*	Pointer on active Cliquet clause.*/
    sophis::instrument::SSClause        *fClauseCliquet;    
/*	Pointer on active Extremum clause.*/
    sophis::instrument::SSClause        *fClauseExtremum;   
/*	Pointer on active Average clause.*/
    sophis::instrument::SSClause        *fClauseAverage;
/*	Pointer on active Forward start clause.*/
    sophis::instrument::SSClause        *fClauseForwardStart;
/*	Pointer on active Asian (average spot) fixings.*/
    sophis::instrument::SSClause        *fClauseAverageStart;
/*	Pointer on active Barrier clause.*/
    sophis::instrument::SSBarrier       *fClauseBarrier;
/*	Pointer on active Cap clause.*/
    sophis::instrument::SSClause        *fClauseCap;
/*	Pointer on active Floor clause.*/
    sophis::instrument::SSClause        *fClauseFloor;
/*	Pointer on active Performance clause.*/
    sophis::instrument::SSClause        *fClausePerformance;
/*	Pointer on active Cliquet clause.*/
    sophis::instrument::SSClause        *fClauseFirst;
    short           fNbBasket;      // panier;
    short           fNbCliquet;     /*  Nombre de clauses   */
    short           fNbBarrier;
    short           fNbExtremum;
    short           fNbAverage;
    short           fNbAverageStart;
    short           fNbForwardStart;
    short           fNbCap;
    short           fNbFloor;
    short           fNbPerformance;
    short           fNbFirst;
    int             fNbUnderlyings;


	long fDate_payment_dernier_cliquet;

    /** This function populates the array fdate with all dates needed in the simulation.
    Populates the array by collecting the characteristic dates of each clause. */
    long            *fdate;
    int             fdatecount;
    virtual void    CollectAllDates(long startDate,long endDate, const static_data::CSRHistoricalData &histoData);

    /** In order to introduce a custom payoff, define a method of type MPayoff and set fMonPayoff to the adress of this method, in the constructor of your child class. */
    MonteCarloPayoff    fMonPayOff;
    double  *MPayOffBestOfCallCall(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfPutPut(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfPutCall(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfCallPut(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfCallCallPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfPutPutPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfPutCallPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffBestOfCallPutPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffPanier(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfCallCall(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfCallPut(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfPutCall(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfPutPut(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfCallCallPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfCallPutPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfPutCallPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffWorstOfPutPutPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffSpread(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffSpreadPerformance(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPayOffDuoDigit(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MCliquetSimple(SSMCUnderlying &data,double **S,double start_date,double end_date, sophis::instrument::SSClause  *clq,int Niemecliquet) const;
    double  *MCliquet(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MCallEtremum(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MPutEtremum(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MBarriere(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MFirstAndSecondMin(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *MStandardAsianCallPut(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *PayOffLookback(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *PayOffExtremum(SSMCUnderlying &data,double **S,double start_date,double end_date) const;
    double  *PayOffLookbackPartiel(SSMCUnderlying &data,double **S,double start_date,double end_date) const;

    void    SetFuturePrices(const market_data::CSRMarketData& context, long UnderlyingCode, int NumSj, int nbDates, long datesFutures[], double * prixFuturs, double* a, double* b) const;
    void    SetVolatilities(const market_data::CSRMarketData& context, long UnderlyingCode, int NumSj, int nbMaturites, long maturites[], double * volatilites) const;
    double  GetUnderlyingForwardPrice(const market_data::CSRMarketData& context,int which,long date,
                            double *future_prices,int nb_dates) const;

    //without control variate
    double  GetPrice(SSMCUnderlying &data,double start_date,
                    double end_date,double datepaiement,
                    double *facteur,double **S,double **R,
                    CSRMonteCarloGraphics *graph=0) const;

    //with control variate
    void    GetPrice(SSMCUnderlying &data,double start_date,
                    double end_date,double datepaiement,
                    double *facteur,double **S,double **R,
                    double& MC1, double& MC2,
                    CSRMonteCarloGraphics *graph=0) const;

	//to gather both calls from control variate and
	void	GetPricePtr(SSMCUnderlying &data,double start_date,
						double end_date,double datepaiement,
						double *facteur,double **S,double **R,
						double* MC1, double* MC2,
						CSRMonteCarloGraphics *graph=0) const;

    void	GetValeurGammaCroiseActionChange(long codesj,long codesk,
											double **R,double **S,
											double * FXPlus,double *FXTampon,
											int NbPoints);

	void	GetValeurChange(long codesj,double **R,double **S,
						double * FXPlus,double *FXTampon,int NbPoints);

    void    GetValeurRho(double **R,double **S,
                        int which,SSMCUnderlying *D,
                        SSMCUnderlying *D0,int NbPoints);

	void    GetValeurPlusMinus( double *ArrayS1,
								double *ArrayS2,
								double *ArrayS3,
								double *ArrayR1,
								double *ArrayR2,
								double *ArrayR3,
								const double *S,
								const double *R,
								int lequel,
								SSMCUnderlying *D1,
								SSMCUnderlying *D2,
								SSMCUnderlying *D3,
								SSMCUnderlying *D0,
								int NbPoints);

    double  GetSensibiliteObligataire(const market_data::CSRMarketData & context) const;
//  void    GetValeursCorrigeesControleVariate(const market_data::CSRMarketData & context,SSMCUnderlyingList *Liste);

    double  ftaux1;
    double  ftaux2;
    double  fK1;
    double  fq1;
    double  fK2;
    double  fKK1,fKK2;
    double  fStrikeLookBack;
    double  fq2,fprop;
    double  fquantocambo1;
    double  fquantocambo2;
    double  *fbase;
    double  *fRendement;
    double  *fPaiement;
    double  *fCVPayoff;
    double  *fvaleur;
    double  *fpayoff;
    double  *fValeurSI;
    mutable double  *fVariableUniforme;
    mutable double  *fPasDeTemps;
    long    *fListeDeviseSJ;
    int     fNbDeviseSJ;
    mutable double  fpayoffsimple;
    long    fDateDebutEmprunt;
    double  fComputationDate;
    double  fsignature;
    double  fNominal;
    SSShare *fShare;
    int     fNBFx;
    SSMCUnderlyingList					fDListe;
    sophis::instrument::CSROption		*fOptionDeControle;
    sophis::instrument::eDerivativeType ftypeprod;
    //used to optimize variate control
    mutable bool    fUseVariateControl;
    mutable double  fAlpha; //used in GetTheoretical value for interpolation in control variate
	mutable _STL::vector<double*>	fNormalVector;
	mutable int		findicedatedebutasian;
	mutable int		findicedatefinasian;
	int*			fIndiceAsianDate;
	int*			fIndiceAsianStartDate;
	int*			fIndiceDateDebutCliquet;
	int*			fIndiceDateFinCliquet;
private:
    friend  class CSRControlVariate;
INHERITED(sophis::instrument::CSROption)

private:
	DEPRECATED_METAMODEL virtual void    RecomputeAllSmile(const market_data::CSRMarketData& context);

public:
	std::vector<sophis::instrument::SSDeltaEpsilon> fDeltaEpsilon;
	std::vector<sophis::instrument::SSRho> fRho;
	int fUnderlyingCount;
	int fRhoCount;
};

}	//	namespace finance

}	//	namespace sophis

SPH_END_NOWARN_EXPORT
SPH_EPILOG


#endif _SphMonteCarlo_H_
