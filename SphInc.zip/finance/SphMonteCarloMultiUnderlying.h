

/*! \file SphMonteCarloMultiUnderlying.h
	\brief Multi-underlying Interface.
*/

#ifndef __GENERIC_MultiMC_H__
#define __GENERIC_MultiMC_H__

#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphButton.h"
#include "SphInc/gui/SphCheckBox.h"
#include "SphInc/scenario/SphScenario.h"

#include "SphInc/finance/SphNewMonteCarlo.h"
#include "SphInc/finance/SphMonteCarloMultiUnderlyingServer.h"
#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc\portfolio\SphPosition.h"
#include "SphInc\portfolio\SphTransaction.h"
#include "SphInc/static_data/SphHistoricalData.h"

#include "SphInc/SphMacros.h"

#include "SphInc/gui/SphInstrumentDialog.h"
#include "SphInc/gui/SphCustomMenu.h"



#define DECLARATION_MULTIUNDERLYING_CLIENT_PAYOFF(derivedClass)			DECLARATION_PROTOTYPE(derivedClass,sophis::finance::MultiUnderlyingsClientPayoff)
#define	INITIALISE_MULTIUNDERLYING_CLIENT_PAYOFF(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass,  name)

SOPHIS_MONTECARLO void* Init_newMCDialog();

#define	INITIALISE_DERIVE_MULTI_UNDERLYING_INTERFACE(derivedClass, name)								\
	{																									\
		static SphInstrumentFactoryNewT<derivedClass, produit **> _constructor;							\
		::NewDeriveSophis(&_constructor, name, sophis::finance::MultiUnderlyingsInterface::sReserve);	\
	}

#define	INITIALISE_MULTI_UNDERLYING_DIALOG()																				\
	{																														\
		static SphDialogFactoryT<sophis::finance::NewMultiMCOptionDialog> _constructorDialog;								\
		static SphInstrumentFactoryNewT<sophis::finance::MultiUnderlyingsInterface, produit **> _constructorInstrument;		\
		::NewDialogueTitreSophis(&_constructorDialog,&_constructorInstrument, sophis::instrument::kMainDialogId);			\
	}

#define	INITIALISE_MULTI_UNDERLYING_DIALOG_WITH_MULTI_UNDERLYING_INTERFACE() INITIALISE_MULTI_UNDERLYING_DIALOG()

class CSRSheetBufferKey;
class CSRPayoffSheetManager;

SPH_PROLOG
namespace sophis {

	namespace instrument {
		struct SSAlert;
	}
	namespace finance {

/** A class handling multi underlying options in the new monte carlo framework.
*/
class SOPHIS_MONTECARLO MultiUnderlyingsInterface : public virtual CSROptionMonteCarloInterface
{
	friend class CSROptionMonteCarloMetaModel;

public:
	//DECLARATION_OPTION(MultiUnderlyingsInterface)

	MultiUnderlyingsInterface(produit ** h,bool initialiseRecomputeAll = true);

	protected :

		/** Default constructor.
		This is for internal use only.
		*/
		MultiUnderlyingsInterface();
		/** Used by a constructor to initialize an object.
		This is for internal use only.
		*/
		void Initialize(produit ** h,bool initialiseRecomputeAll = true);

	public:

	// 
	//void InitialiseRecomputeAll();

	/** Destructor.
	*/
	virtual ~MultiUnderlyingsInterface();

	/** Test if the instrument is in the right state to be priced.
	*	@return true if the instrument is valid.
	*/
	 virtual	Boolean	ValidInstrument() const;

	/** Get the metamodel forced for this instrument.
	This allows you, once implemented a meta model, to force a meta model for
	an instrument just by deriving the class and overloading this method.
	The default implementation is to return fMultiMMMetaModel.
	@return a pointer which will not be deleted and may be null.
	@since 5.3
	*/
	virtual const finance::CSRMetaModel* GetForceMetaModel() const;

	/** Return true for an exotic payoff, false otherwise.
	*/
	virtual bool		ExoticPayment() const { return true; }

	/** Return option starting date.
	*/
	virtual	long		GetStartDate() const;

	/** Get the pay-off formula.
	*	@param name is an output character chain.
	*/
	virtual void		GetPayOffFormula(char *name) const;

	/** Return option's settlement date.
	*/
	virtual long		GetSettlementDate(long transactionDate) const;

	/** 
	*	@return true if Use antithetic sampling is ticked in the multiunderlying option dialog, false otherwise.
	*/
	virtual bool UseAntitheticSampling() const;

	virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const;

	/**
	*	GetEquityUnderlyingCount returns the number of "pure equity" underlyings.
	*	This differs from GetUnderlyingCount, which returns the number of "pure equity"
	*	underlyings + the number of foreign exchange underlyings.
	*/
	virtual int			GetEquityUnderlyingCount() const;

	/** Return a fixing for a given underlying at a given date.
	*	@param date is the date for which we want to get a fixing.
	*	@param code is the underlying's code.
	*/
	double	GetFixingFromDatabase(long date,long code, const market_data::CSRMarketData		&contextGeneral) const;

	/** Complete a list with relevant parameters associated with the option's underlyings {@link SSMultiUnderlying}.
	*	@param underlyingList is a list of underlying parameter.
	*/
	virtual  void	FillUnderlyingList(_STL::vector<SSMultiUnderlying> & underlyingList) const;

	/**
	*	GetInitialEquityUnderlyingCount returns the number of "pure equity" underlyings at the option's start date.
	*	Differs from GetUnderlyingCount, which returns the number of equity underlyings + the number of forex underlyings
	*/
	int		GetInitialEquityUnderlyingCount() const;

	/**
	*	GetInitialForexUnderlyingCount returns the number of forex underlyings at the option's start date.
	*	Differs from GetUnderlyingCount, which returns the number of equity underlyings + the number of forex underlyings
	*/
	int		GetInitialForexUnderlyingCount() const;

	/** Return sicovam code for the ith initial option's underlying.
	*/
	long	GetInitialUnderlying(int i) const;
	
	/** Return discratization length in days for the diffusion.
	*/
	virtual int		GetDiscratizationLength() const;

	sql::errorCode	SaveAuxiliaryData(long sicoHisto) const;
	void			AfterSuccessfullSaving();

	/** A method to set a missing fixing. The method set the value in Multi underlying instance
	*	but do not write in database. To permanently save the corresponding fixing call {@ink CSRInstrument::Save}.
	* 
	*	@param date is the absolute date of missing fixing.
	*	@param code is the sicovam code of the underlying.
	*	@param fixing is the fixing to set.
	*
	*	@return true if there is a fixing for the underlying at the corresponding date, false else.
	*/
	bool SetMissingFixingFromDatabase(long date,long code, double fixing);


	/** Automatic ticket to create.
	During the forecast, this method is called before doing the
	standard Sophis automatic ticket.
	According the return, the automatic tickets will be inserted into prevision
	table (used for cash in the future) when the date is in the future else
	in automatic ticket.
	This works also for instruments in package. If your forecast needs some
	information from the position like the average price, you must use the
	special automatic ticket {@link GetAutomaticTicketByReporting}.
	@param date is the forecast date.
	@param list is the automatic ticket list.
	@since 4.6
	@see AutomaticTicket
	@see eAutomaticTicketType
	*/
	virtual eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<AutomaticTicket> &list) const;

	/** Automatic ticket to create by reporting.
	During the forecast, this method is called to know if a reporting has to be done
	to be able to generate the forecast. The main difference with the
	version {@link GetAutomaticTicket} is that you get the position and you specify
	all the fields of the trade you want to create. But it does not work for instruments
	and It is of course much longer.
	in package and does not allow to create deals in the future in automatic ticket.
	The algorithm consists to generate an extraction by counterpart, entity, depositary
	on this underlying with a reporting date equals to the return; then calling {@link CreateAutomaticTicket} 
	for each position to get a list of transaction. Then it will save
	in prevision and mvt_auto table according the transaction dates.
	If the instrument has a special reporting (@link SpecialReporting} and needs to know
	that you try to generate the automatic ticket, you can use AddSpecialReportingForAutomaticTicket
	to tell it.
	@param date is the forecast date. 
	@param eoy specifies if this is for an end of year (not yet implemented).
	@param filter is a sql filter string for the where of the extraction, generally used to filter some transaction type;
	it is empty by default and if modified, must be for instance "and type = 1".
	@return the reporting date to generate the position (generally the day itself or the date before);
	if the return is null, nothing will be done.
	By default, return 0.
	@version 5.1 the extraction is not anymore grouped by depositary; the depositary fields contains only the depositary of the first transaction in the position.
	@since 4.6
	@see CreateAutomaticTicket
	@see AddSpecialReportingForAutomaticTicket
	*/
	virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

	/** Called by each position when a special automatic ticket.
	@param eoy tells if this is for the end of year; not implemented yet.
	@param calculation_date is the date of the forecast.
	@param position is the position in the special extraction.
	@param list is the output list of transactions to generate.
	@param port is the description of the position by counterpart, entity and depositary.
	By default does nothing.
	@see GetAutomaticTicketByReporting
	@see AddSpecialReportingForAutomaticTicket
	*/
	virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const portfolio_automatic_ticket &port) const;


	/** Call back of the special extraction created for automatic ticket.
	Can be used if a special reporting needs to know if this is for a forecast.
	By default, return false 
	@since 4.6
	@see CSRExtraction::AddSpecialReporting
	*/
	virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;

	/**
	* INTERNAL
	*/
	void ForceAntithetic(bool useAntithetic = true);

	gui::CSRFitDialog *	new_FixingDialog(long date_fixing) const;

	void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);
	void GetDescription(sophis::tools::dataModel::DataSet& dataSet) const;


	virtual sophis::portfolio::CSRBarrierMonitor* ProvideBarrierMonitor() const;


protected :
	/** Check if the underlying define in the GUI are the same as the one defined at the basket level.
	@since 6.0
	*/
	bool CheckUnderlyingCoherencyWithBasket(_STL::string& errorMess) const;

	/** Factory for the creation of a specific multiunderlying pay-off. Do not overload it:
	*	in order to use a specific payoff, you must Initialise the client pay-off prototype.
	*/
	virtual	CSRClientPayoff* new_CSRClientPayoff() const;

private:

	/**
	* INTERNAL
	*/
	bool fForceAntithetic;
	bool fUseForceAntithetic;

	/*
		DateAndInfo is a structure that contains two details (see MUUtils.h):
			- date corresponds to a date
			- info indicates all important information associated with the date.
				info is binary-coded, as follows:

				0				1					1		0		0			1
				eClauseMultiEnd	eClauseMultiStart	eAveDep eAsian	eMaturity	eDeparture

				In this example, info indicates that the corresponding date is:
					- the start date
					- one date for an asing-in fixing
					- the start date of one MUclause

		IsThisInfoRelevant has been implemented not to deal with such binary data.
		IsThisInfoRelevant returns true if the first parameter info contains the specific information i.

		In our example:
			- IsThisInfoRelevant(info,InfoDateEnum::eDeparture)	returns true
			- IsThisInfoRelevant(info,InfoDateEnum::eAveDep)		returns true
			- IsThisInfoRelevant(info,InfoDateEnum::eClauseMultiStart) returns true
			- IsThisInfoRelevant(info,InfoDateEnum::eMaturity)	returns false
			- IsThisInfoRelevant(info,InfoDateEnum::eAsian)		returns false
	*/
	bool				IsThisInfoRelevant(int info,short i) const;

	/** True if there is a problem with an underlying, false otherwise.
	*/

	mutable bool		fUnderlProblem;

protected:
	/** True for an existing prototype, false otherwise.
	*/
	mutable bool		fPayoff_present;

	/** Number of initial equity underlyings.
	*/
	mutable int			fInitialEquityUnderlyingCount;

	/** Number of initial forex underlyings.
	*/
	mutable int			fInitialForexUnderlyingCount;

	/** STL vector of initial rho sources.
	*/
	_STL::vector<long>	fInitialRhoSources;

	/** STL vector of initial risk sources.
	*/
	_STL::vector<long>	fInitialRiskSources;

private:

	friend class	NewMultiMCOptionDialog;

protected:
	/** Char associated with a client multiunderlying pay-off prototype.
	*/
	mutable char	fMuType[256];
};

/**
*	Generic multiunderlying client pay-off. Used on the client side to initialise the server pay-off object.
*/
class SOPHIS_MONTECARLO MultiUnderlyingsClientPayoff : public virtual CSRClientPayoff
{
public:
	/**	Default constructor.
	 */
	MultiUnderlyingsClientPayoff();

	/** Destructor.
	*/
	virtual ~MultiUnderlyingsClientPayoff();

	/** Intitialise pay-off for a given option.
	*	@param option is the computed option.
	*/
	virtual void	Initialise(const instrument::CSRInstrument* instr);

	/** Method to know if payoff is always cash or if it can be paid in share.
	*	By default the method return false;
	*	@return true if the option can paid in share, otherwise return false.
	*/
	virtual bool CanHandleNotCashPayment() const {return false;};

	/** Test if the payoff is in the right state to be priced.
	It is called in order to know if option is valid.
	@return true if the payoff is valid.
	*/
	virtual Boolean		ValidInstrument(bool isInInitialisation = true) const;	

	virtual void	InitDates(const market_data::CSRMarketData	&contextGeneral);

	/** Get equity and forex underlying really used to define corresponding payoff
	*	@param equityAndForexRiskSources is an output vector containing codes of the equity and forex risk sources in payoff definition. 
	*		These code must be sorted : first equity codes then forex ones.
	*	@param equityCount is the number of equity underlying in the corresponding vector.
	*	In the case of a multi-underlying, all underlyings are equity and equityCount is the same as the equityAndForexRiskSources size.
	*/
	virtual void GetPayoffUnderlying(	_STL::vector<long>	&equityAndForexRiskSources,
										int					&equityCount) const;

	virtual int GetPayoffUnderlyingCount() const;

	/** Fill the initial risk and rho sources of the option.
	*	@param initialRiskSources is the STL vector of risk sources to fill.
	*	@param initialRhoSources is the STL vector of rho sources to fill.
	*/
	void GetInitialRiskSources(	_STL::vector<long>	&initialRiskSources,
								_STL::vector<long>	&initialForeignCurrencyRiskSources,
								_STL::vector<long>	&initialRhoSources) const;

	/** Get foreign currency risk sources.
	*	@param foreignSources is an output vector containing codes of foreign currencies.
	*/
	virtual void GetForeignCurrencyRiskSources(_STL::vector<long>& foreignSources) const;	

	/** Get the type (quanto, compo...) associated to an underlying.
	*	@param	nth is an index between 0 (included) and result of {@link  CSRClientPayoff::GetPayoffUnderlyingCount} (excluded).
	and diffused underlying are ordered in the same order as the one returned by 
	{@link CSRClientPayoff::GetPayoffUnderlying}.
	*	@return the type of paiement (quanto, compo...) associated to an underlying.
	*	{@see sophis::instrument::eQuantoType}
	*/
	virtual sophis::instrument::eQuantoType GetQuantoCompoRiskSource(int nth) const;

	/** Return the number of fixing dates for a sampling path.
			*/
	int				GetDateCount()	const;


	/** Return the ith fixing date.
	 *	@param i is an index between 0 (included) and GetDateCount() (excluded) corresponding to the ith fixing date.
	 *	@return the ith fixing dates in sophis convention {@link about_date}.
	 */
	long			GetNthDate(int i) const;


	virtual const FixingsMap& GetObsDateFixing(const market_data::CSRMarketData	&contextGeneral);

											
	/** 
	*	 Populates the array by collecting the characteristic dates of each clause. 
	*	@param param is the market data.
	*/
	virtual void	 InitialiseMarketDependentData(	const market_data::CSRMarketData	&param,
													const CSROptionMonteCarloMetaModel	*model,
													const instrument::CSRInstrument		&instrument);


	void	 RefreshSpot(const market_data::CSRMarketData	&param);

	/** Fill a vector with the relevant strike needed to find volatilities at the fixing dates for a given underlying.
			 * @param indexDiffused is the index of the underlying.
			 * @param param is the market data.
			 * @param option is the computed option.
			 * @param dates is a vector of absolute date.
			 * @param strikeVector is the STL vector of strike to fill.
			 */
	virtual void	GetStrikeForVolatilityArray(int									indexDiffused, 
												const market_data::CSRMarketData	&param, 
												const sophis::instrument::CSROption	*option,
												const _STL::vector<long>			&dates,
												_STL::vector<double>				&strikeVector) const;

	/** Return the number of market data dependent information but not dependent on the simulation.
	 */
	virtual int		GetMarketDataDependentInfoCount() const;

	/** Gives the market data dependent information, but not dependent on the simulation.
	*	@param option is a pointer on the computed option.
	*	@param marketData is the market data.
	*	@param marketDataInfos is the vector of market dependant data to fill.
	*/
	virtual void	GetMarketDataDependentInfo(	const sophis::instrument::CSRInstrument	*instr, 
												const CSROptionMonteCarloMetaModel	*model,
												const market_data::CSRMarketData	&marketData, 
												_STL::vector<double>				&marketDataInfos) const;

	/** Return the strike associated with a given underlying.
	*	*@param nth is the index of the underlying.
	*/
	virtual double	GetStrike(int nth) const;

	/** Update the strike associated with a given underlying.
	*	*@param nth is the index of the underlying.
	*/
	virtual void	UpdateUnderlyingStrike( long underCode, double strike ) ;

	/** Update the strike associated with the product.
	*/
	virtual void	UpdateStrike( double strike );

	/** Stores all the data needed to initialise a CSRServerPayoff in an archive {@link sophis::tools::CSRArchive}.
	*	This is done in order to create one or several CSRServerPayoff for the Monte Carlo computation on the server side.
	*	@param archive is the archive in which we store data
	*/
 	virtual void	GetData(sophis::tools::CSRArchive& archive) const;

	/**
	* Returns the registered name of the server pay-off containing the valuation procedure.
	*/
	virtual _STL::string GetServerPayoffID() const;


	/** Returns the number of payment dates.
	*/
	virtual int		GetPaymentCount() const;

	/** Return the absolute date corresponding to a payment date.
	*	@param nth is the index of the nth payment date.
	*/
	virtual long	GetNthPaymentDate(int nth) const;

//-----------------------------------------------------------------------------

	/** Initialisation of the pay-off.
	This is performed at the end of the constructor of the option and can be used
	to initialise static data for pay-off. If you need to remove elements from the
	basket, you must do it here.
	By default, does nothing.
	*/
	virtual void ManageDroppedUnderlyings() ;

	/** Get the pay-off formula.
	It is called by the CSROption::GetPayOffFormula to get the formula.
	@param name is an output string stl.
	*/
	virtual	void GetPayOffFormula(_STL::string &name) const;


	/** Get the dates needed for the path.
	It is called by {@link CSROptionMonCar::CollectAllDates} to collect the dates needed for the path.
		@param date is the set of dates including the past, which contains the end date by default.
		By default, does nothing.
	*/
	virtual void CollectAllDates(	const sophis::instrument::CSROption	*option,
									_STL::set<long>						&date, 
									const market_data::CSRMarketData	&contextGeneral);


	/**	At the beginning of a pricing this method is called in order to set all static data
	*	which depend only on gApplicationContext such as todays date. 
	*	This function must find all dates needed in the simulation, and populates a structure so that method 
	*	{@link CSRClientPayoff::GetNthDate} return the nth dates needed for payoff evaluation in sophis convention.
	*	
	*	@param option is the option priced by Monte Carlo simulation.
	*	@param contextGeneral is the basic context used by Monte Carlo simulation to compute basic price.
	*/
	virtual void InitialiseStaticData(	const instrument::CSRInstrument*	instr,
										const market_data::CSRMarketData	&contextGeneral);

	/** The key for the prototype is a string C.
	@see CSRPrototype
	*/
	typedef tools::CSRPrototype<MultiUnderlyingsClientPayoff, const char *, tools::less_char_star> prototype;

	/** Access to the singleton containing all of the derived classes of CSRBundleMarketData.
	It is populated when using the macro INITIALISE_MONTECARLO_PAYOFF.
	*/
	static prototype & GetPrototype();

	/** Clone function used by prototype.
	Generally created by the macro DECLARATION_MONTECARLO_PAYOFF.
	By default, generate an exception, usually signifying that the macro has been implemented.
	*/
	virtual MultiUnderlyingsClientPayoff * Clone() const;

	virtual	bool	CanBeConfigured() const;
	virtual void	Configure();

	/**
	*  Return the number of fixing date in the past (today included if its a fixing date)
	*/
	inline int GetPastDatesCount() const {return (int) fPastDates.size();};

	/**
	*  Return the number of fixing date in the past (today included if its a fixing date)
	*/
	inline long GetNthPastDate(int nth) const {return fPastDates[nth];};

	/** Get the alert list.
	It is called by {@link ValidInstrument} in order to add specific payoff alert list.
	@param forecastDate is the date of forecast.
	@param nb is a valid address to set the count of alerts.
	@return an array of alerts, which is deleted by delete [].
	This method is called during the forecast for all instruments in
	open positions and is used to fill the alert books.
	Note that this list is added to the conventional alerts directly managed by the forecasts.
	The default implementation is to return NULL.
	*/
	virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const;


	/** Automatic ticket to create.
	During the forecast, this method is called before doing the
	standard Sophis automatic ticket.
	According the return, the automatic tickets will be inserted into prevision
	table (used for cash in the future) when the date is in the future else
	in automatic ticket.
	This works also for instruments in package. If your forecast needs some
	information from the position like the average price, you must use the
	special automatic ticket {@link GetAutomaticTicketByReporting}.
	@param date is the forecast date.
	@param list is the automatic ticket list.
	@since 4.6
	@see AutomaticTicket
	@see eAutomaticTicketType
	*/
	virtual instrument::CSRInstrument::eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<instrument::CSRInstrument::AutomaticTicket> &list) const;

	/** Automatic ticket to create by reporting.
	During the forecast, this method is called to know if a reporting has to be done
	to be able to generate the forecast. The main difference with the
	version {@link GetAutomaticTicket} is that you get the position and you specify
	all the fields of the trade you want to create. But it does not work for instruments
	and It is of course much longer.
	in package and does not allow to create deals in the future in automatic ticket.
	The algorithm consists to generate an extraction by counterpart, entity, depositary
	on this underlying with a reporting date equals to the return; then calling {@link CreateAutomaticTicket} 
	for each position to get a list of transaction. Then it will save
	in prevision and mvt_auto table according the transaction dates.
	If the instrument has a special reporting (@link SpecialReporting} and needs to know
	that you try to generate the automatic ticket, you can use AddSpecialReportingForAutomaticTicket
	to tell it.
	@param date is the forecast date. 
	@param eoy specifies if this is for an end of year (not yet implemented).
	@param filter is a sql filter string for the where of the extraction, generally used to filter some transaction type;
	it is empty by default and if modified, must be for instance "and type = 1".
	@return the reporting date to generate the position (generally the day itself or the date before);
	if the return is null, nothing will be done.
	By default, return 0.
	@version 5.1 the extraction is not anymore grouped by depositary; the depositary fields contains only the depositary of the first transaction in the position.
	@since 4.6
	@see CreateAutomaticTicket
	@see AddSpecialReportingForAutomaticTicket
	*/
	virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

	/** Called by each position when a special automatic ticket.
	@param eoy tells if this is for the end of year; not implemented yet.
	@param calculation_date is the date of the forecast.
	@param position is the position in the special extraction.
	@param list is the output list of transactions to generate.
	@param port is the description of the position by counterpart, entity and depositary.
	By default does nothing.
	@see GetAutomaticTicketByReporting
	@see AddSpecialReportingForAutomaticTicket
	*/
	virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const instrument::CSRInstrument::portfolio_automatic_ticket &port) const;


	/** Call back of the special extraction created for automatic ticket.
	Can be used if a special reporting needs to know if this is for a forecast.
	By default, return false 
	@since 5.3
	@see CSRExtraction::AddSpecialReporting
	*/
	virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;



	/** Compute the price of the instrument with the results of the Monte Carlo simulation stored in the buffer resultVector.
	This method is called once before Monte Carlo simulation (with {@link CSROptionMonteCarloMetaModel::GetMonteCarloComputationState} is equal to emccsCreateArchive) 
	in order to initialize some data needed to finalize price computation but not needed on server side. 
	Such result can be stored on archive {@link CSROptionMonteCarloMetaModel::GetPreResultArchive()}.

	After Monte Carlo simulation we call again this method (with {@link CSROptionMonteCarloMetaModel::GetMonteCarloComputationState} is equal to emccsAggregateResults)
	to compute price with the simulation results.

	@param	isBasicPrice is true if the current price to compute is the basic one, false if it is computed for greeks.
	@param	resultVector is the result vector for this computation. The first {@link GetIndicatorSizeForDifference}
	index are computed as difference and the other ones (respectively {@link GetSupplementaryIndicatorSizeForPrice} for basic price and 
	{@link GetSupplementaryIndicatorSizeForGreeks} for price for greeks).
	@param	param is the market data we used for the simulation.
	@param	option is the option for which we made the simulation.
	@param	model is the meta-model used to compute price.
	@param	weightedSamplingCount is the number of Monte Carlo Sampling path used for the simulation.
	@param	bumpKey is a SSBumpKey allowing to know which computation is currently done.
	*/
	virtual double	CalculatePrice(	bool								isBasicPrice,
									const _STL::vector<double>			&vectorToFill,
									const market_data::CSRMarketData	&param, 
									const instrument::CSRInstrument		&instr,
									const CSROptionMonteCarloMetaModel  *model,
									int									samplingCount,
									double								weightedSamplingCount,
									double								squareWeightedSamplingCount,
									const SSBumpKey						&bumpKey) const;

protected:


	/**
	* Method to retrieve the value of a fixing. When fixing is in the past:
	*	
	*	
	*/
	virtual double GetMissingFixing(int		nthUnderlying,
									long		date,
									const sophis::instrument::CSROption &option,
									const market_data::CSRMarketData		&contextGeneral) const;

	/** Collect the fixing.
		CollectFixings collects the fixings for the corresponding date and stores
		them in the member variable fObsDateFixing.
		@param date is the date to collect the fixing.
	*/
	void	CollectFixings(	const sophis::instrument::CSROption *option,
							long								date,
							const market_data::CSRMarketData	&contextGeneral);

	/** Get the fixing from database.
		@param date is the date to get the fixing.
		@param code is the instrument ID.
		@returns the fixing for the corresponding date and instrument code.
		It searches in the fixing list first, then if no fixing is found and if
		the date corresponds to the Start Date of the product, it looks in the Basis field
		from the underlying list. This is for consistency with the standard forward start option.
		WARNING: This method does not directly access the value from the fObsDateFixing, but from the dialog and its data. This method is slower than GetMUFixing !!!
	@see GetFixingFromMap
	*/
	double	GetFixingFromDatabase(long date,long code, const market_data::CSRMarketData		&contextGeneral) const;

	/** Get the fixing from database.
	This is the optimised version.
		@param date is the date to collect the fixing.
		@param code is the instrument ID.
		@returns the fixing for the corresponding date and instrument code.
		It searchs in the fixing list first, then if no fixing is found and if
		the date corresponds to the Start Date of the product, it looks in the Basis field
		from the underlying list. This is for consistency with the standard forward start option.
		If no fixing is found, and if the date correspond to today, it returns the current
		spot of the instrument.
	@see GetFixingFromDatabase
	*/
	double GetFixingFromMap(long date,int nth) const;

	/** Computation date. 
	*/
	//double	fComputationDate;
	/** List of equities, which must not be paid.
	This must be done in the Initialise.
	*/
	_STL::set<long> fOutOfBasket;

	virtual int GetAntitheticSamplingCount() const;

	friend class MultiUnderlyingsInterface;
	friend class NewMultiMCOptionDialog;

	/** List of underlying parameters relevant for path generation.
	*/
	_STL::vector<SSMultiUnderlying>	fUnderlyingList;

	/** Store position of underlying is in fUnderlyingList in risk sources and -1 if underlying is out of basket.
	*/
	_STL::vector<int>	fRiskSourcesIndex;

	/** Vector of current rho sources.
	*/
	_STL::vector<long>				fRhoSources;

	/** Vector of initial rho sources.
	*/
	_STL::vector<long>				fInitialRhoSources;

	/** Get the discretization for underlyings.
	*	This feature come from old multi underlying implementation. This is not discretization 
	*	of path for stochastic differential equation integration (which is defined in the Monte Carlo
	*	specific dialog).
	*/
	int		fDiscratizationLength;

	/** Today's date.
	* until 5.3 menber of CSRClientPayoff
	*/
	//long	fToday;

	/** Begining date of the option.
	*/
	long	fStartDate;

	/** End date of the option.
	*/
	long	fEndDate;

	/** Number of relevant fixing dates.
	*/
	int		fdatecount;

	/** Number of initial equity underlying.
	*/
	int		fInitialEquityUnderlyingCount;

	/** Number of initial forex underlying.
	*/
	int		fInitialForexUnderlyingCount;

	/** Number of remaining underlying.
	*/
	int		fPayoffUnderlyingCount;

	/** STL Vector of intermediate payment dates.
	*/
	mutable _STL::vector<long> fIntermediatePaymentDate;

	/** Call back on the option.
	*/
	sophis::instrument::CSROption * fOption;
		

	public:

		/**
		* vector containing fixing dates in the past (today included if its a fixing date)
		*/
		_STL::vector<long> fPastDates;
	protected:

		bool fUseAntitheticSampling;

		/** List of fixings.
		@see CollectAllDates.
		*/
		FixingsMap	fObsDateFixing;

		/** List of ordered dates for the MonteCarlo path.
		*/
		_STL::vector<long> fDates;
		bool fDatesInit;

	

};

/**
* Dialog for multi Underlying Product
*/
class CUMultiUnderlyingList;

class CSRReinitialiseListener : public  gui::CSRBasicButton::CSRListener 
{
public:
	CSRReinitialiseListener();
	virtual void OnButtonAction( const  gui::CSRBasicButton& iButton );
};

class SOPHIS_MONTECARLO NewMultiMCOptionDialog	: public gui::CSRInstrumentDialog
{
public:
	DECLARATION_INSTRUMENT_DIALOG(NewMultiMCOptionDialog)
	virtual	~NewMultiMCOptionDialog();
	virtual void	ReInitialise();
	virtual void	ElementValidation(int EAId_Modified);
	virtual void	AfterRecompute(const instrument::CSRInstrument &title, const sophis::CSRComputationResults& results) OVERRIDE;
	virtual	void	Open(void);
	virtual	void	OpenAfterInit(void);
	virtual	Boolean	Close(void);
	virtual bool	Save();
	virtual void	OnGotFocus();	
	void			ReInitialiseUnderlyingsFromBasket();

	virtual void BeforeRecompute(const instrument::CSRInstrument &security);

	_STL::vector<long>		fUnderlyingCode;
	_STL::vector<double>	fDeltaOption;
	_STL::vector<double>	fGammaOption;
	_STL::vector<double>	fVegaOption;
	CSRPayoffSheetManager* fCloseManagerXL;

	struct SimpleFixing{
		long code;
		double fixing;
	};

protected:
	CSRReinitialiseListener fReinitialiseListener;
	void			ForceCashPayment();
	void			ReInitialiseUnderlyingList(	CUMultiUnderlyingList *listund,_STL::vector<long> &underlyinglist);
	void			ReInitialiseCurrencyList(const _STL::vector<long> &underlyinglist);
	void			ReInitialiseFixingList(const _STL::vector<long> &underlyinglist);
	CSRSheetBufferKey *	fKey;
	
};


class NewCUGreeksButton: public gui::CSRButton
{
public:
	NewCUGreeksButton(gui::CSRFitDialog *dialog, int ERId_Element);
	virtual	void	Action();
private:
	NewMultiMCOptionDialog *fdialog;
};

class NewCUPayOffMenu : public gui::CSRCustomMenu{
public:
	NewCUPayOffMenu(	gui::CSRFitDialog	 	*dialog, 
		int 				ERId_Menu,
		short 				listValue, 
		const char 			*columnName);

	virtual void SetValueFromList(); 
	virtual void SetListFromValue();
};

	}
}

SPH_EPILOG


#endif //__GENERIC_MultiMC_H__