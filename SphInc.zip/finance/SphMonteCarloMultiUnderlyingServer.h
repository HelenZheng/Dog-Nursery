

/*! \file SphMonteCarloMultiUnderlyingServer.h
	\brief Multi-underlying Interface.
*/

#ifndef __GENERIC_MultiMC_SERVER_H__
#define __GENERIC_MultiMC_SERVER_H__

#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/instrument/SphOption.h"


#define DECLARATION_MULTIUNDERLYING_SERVER_PAYOFF(derivedClass)			DECLARATION_SERVER_PAYOFF(derivedClass)
#define	INITIALISE_MULTIUNDERLYING_SERVER_PAYOFF(derivedClass, name)	INITIALISE_SERVER_PAYOFF(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace finance {



		/** Map of fixings for one date.
		The key is an instrument ID, the data is the spot value.
		*/
		typedef _STL::map<long , double> FixingsVect;

		/** List of fixings.
		The key is the data, which is the list of fixings for that date.
		*/
		typedef _STL::map<long , FixingsVect> FixingsMap;

	/** Defines the list of underlyings.
	*/
	struct SOPHIS_MONTECARLO_SERVER SSMultiUnderlying
	{
		/** Instrument ID. */
		long					fCode;
		/** Quanto or Compo. */
		instrument::eQuantoType	fType;
		/** Strike saved in the database. */
		double					fStrike;
		/** Current Spot of the underlying */
		double					fSpot;
	};

		/** Map of fixings for one date.
	The key is an instrument ID, the data is the spot value.
	*/
	typedef _STL::map<long , double> FixingsVect;

	/** List of fixings.
	The key is the data, which is the list of fixings for that date.
	*/
	typedef _STL::map<long , FixingsVect> FixingsMap;


	struct SOPHIS_MONTECARLO_SERVER SSMultiUnderlyingsServerPayoffMarketDependentData : public SSServerPayoffMarketDependentData
	{
		SSMultiUnderlyingsServerPayoffMarketDependentData();
		/** STL vector of dropped equity underlying code.
		*/
		_STL::set<long>					fOutOfBasket;

		/** Vector of current rho sources.
		*/
		_STL::vector<long>				fRhoSources;

		/** List of fixings.
		@see CollectAllDates.
		*/
		FixingsMap						fObsDateFixing;

		/** STL Vector of intermediate paiement dates.
		@deprecated since 5.3.2
		*/
		_STL::vector<long>				fIntermediatePaymentDate;

		/** List of relevant parameters for diffusion {@link SSMultiUnderlying}.
		*/
		_STL::vector<SSMultiUnderlying>	fUnderlyingList;

		/** Begining date of the option.
		*/
		long	fStartDate;

		/** End date of the option.
		*/
		long	fEndDate;

	};

/**
*	Generic multiunderlying server pay-off managing pay-off computation for a given underlying path during	Monte Carlo simulation.
*/
class SOPHIS_MONTECARLO_SERVER MultiUnderlyingsServerPayoff : public virtual CSRServerPayoff
{
	/**	Prototyped declaration.
	 */
	DECLARATION_SERVER_PAYOFF(MultiUnderlyingsServerPayoff)

	/** Default constructor.
	*/
	MultiUnderlyingsServerPayoff();

	/** Destructor.
	*/
	virtual ~MultiUnderlyingsServerPayoff();

	 /** Compute the option pay-off associated with the underlying path and fill a temporary buffer in the CSRServerOutput object.
	* @param path is an input parameter corresponding to the underlying paths that are used to compute pay-off
	* @param output is an output parameter corresponding to a buffer object in which we write the results of a pay-off computation.
	*/
	virtual void	operator() (const CSRLocalPath * path, CSRServerOutput * output) const;

	/** Initialise the CSRServerPayoff with the data stored in an archive {@link sophis::tools::CSRArchive}.
	*	This is done in order to create one or several pay-off objects on the server side.
	*	@param archive is the archive storing the data needed to initialise the CSRServerPayoff
	*/
 	virtual void	SetData(const sophis::tools::CSRArchive& archive);

	/** Return the computation date.
	*/
 	//virtual double	GetComputationDate() const;

	/** Compute pay-off for one path corresponding to a given antithetic sampling.
	*	@param nthAntitheticSampling is the index for the nth antithetic sampling.
	*	@param path is an input parameter corresponding to the underlying paths that are used to compute the pay-off.
	*	@param output is an output parameter corresponding to a buffer object in which we write the results of a payoff computation.
	*/
		/** Return the pay off for one path.
	The result is aggregated and discounted.
	@param input is a matrix of spot giving the values for the patch; the first index is
	for the equity from 0 included to fEquityList.size() excluded; the second is for dates.
	@param output is the paid amount not discounted in the unit of the option.
	*/
	virtual void GetPayOffForOnePath(	const CSRLocalPath	*path,
										int					nthAntitheticSampling,
										CSRServerOutput		*serverOutput) const;


	/** Get the fixing from database.
	This is the optimised version.
		@param date is the date to collect the fixing.
		@param nth is the nth fixing.
		@returns the fixing for the corresponding date and instrument code.
		It searchs in the fixing list first. Then, if there is no fixing in it and if 
		the date corresponds to the Start Date of the product, it looks in the Basis field 
		from the underlying list (to be consistent with the standard forward start option)
		If no fixing is found, and if the date correspond to today, it returns the current
		spot of the instrument.
	@see GetFixingFromDatabase
	*/
	double GetFixingFromMap(long date,int nth) const;

	 virtual void	FillOptimisation(const CSRLocalPathGeneratorServer& pathGenerator);

protected:

	virtual SSServerPayoffMarketDependentData* new_SSServerPayoffMarketDependentData() const;

	/** Computation date.
	*/
	//double							fComputationDate;

	/** Get the discretization for underlyings.
	Essentially used for barriers.
	*/
	//int								fDiscratizationLength;

	/** Today's date.
	* in CSRServerPayoff since 5.3
	*/
	// long							fToday;

	

	/** Number of relevant fixing dates.
	*/
	//int		fdatecount;
};
	}
}

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSMultiUnderlying & ssmultiUnderlying);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSMultiUnderlying & ssmultiUnderlying);

SPH_EPILOG


#endif //__GENERIC_MultiMC_H__