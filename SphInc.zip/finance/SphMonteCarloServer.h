/*
*    File:       SphMonteCarlo.h
*
*    Contains:   The "New Monte Carlo" pricing model and how to overload it
*
*    Copyright:  � 1995-2000 Sophis.
*
*/
#ifndef __MONTECARLO_INTERFACE_SERVER_H__
#define __MONTECARLO_INTERFACE_SERVER_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/instrument/SphOption.h"
#include "SphInc/finance/SphYieldCurveLight.h"
#include "SphTools/SphExceptions.h"

#ifndef GCC_XML
	#include "SphMathTools/SphMatrixMKL.h"
	#include "SphMathTools/SphVectorMKL.h"
	#include "SphMathTools/SphFunctionWrapper.h"
#endif

	
BOOST_INCLUDE_BEGIN
#include BOOST_INCLUDE_PATH(numeric\ublas\matrix.hpp)
#ifndef GCC_XML 
	#include BOOST_INCLUDE_PATH(unordered_map.hpp)
#endif
BOOST_INCLUDE_END



#ifdef GCC_XML
	#include __STL_INCLUDE_PATH(unordered_map)
#endif

#if (defined(WIN32)||defined(_WIN64))
#	ifdef SOPHIS_MONTECARLO_SERVER_EXPORTS
#		define SOPHIS_MONTECARLO_SERVER __declspec(dllexport)
#	else
#		define SOPHIS_MONTECARLO_SERVER __declspec(dllimport)
#	endif
#else
#	define SOPHIS_MONTECARLO_SERVER
#endif

// Macro declaration for server payoff classes computing payoff from an underlying path
#define DECLARATION_SERVER_PAYOFF(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRServerPayoff)
// Macro instantiation for server payoff classes computing payoff from an underlying path
#define INITIALISE_SERVER_PAYOFF(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for server output classes storing payoff computation results
#define DECLARATION_SERVER_OUTPUT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRServerOutput)
// Macro instantiation for server output classes storing payoff computation results
#define INITIALISE_SERVER_OUTPUT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for uniform generator classes
#define DECLARATION_GENERATOR(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRUniformRandomGenerator)
// Macro instantiation for uniform generator classes
#define INITIALISE_GENERATOR(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for method computing independent normal law from uniform ones
#define DECLARATION_GAUSSIAN_INVERTION(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRGaussianInvertion)
// Macro instantiation for method computing independent normal law from uniform ones
#define INITIALISE_GAUSSIAN_INVERTION(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for method computing a brownian path from normal law
#define DECLARATION_BROWNIAN_CONTRUCTION(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRBrownianPathConstruction)
// Macro instantiation for method computing a brownian path from normal law
#define INITIALISE_BROWNIAN_CONTRUCTION(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for method computing correlated normal law from uncorrelated ones
#define DECLARATION_SERVER_CORRELATION(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRServerCorrelation)
// Macro instantiation for method computing correlated normal law from uncorrelated ones
#define INITIALISE_SERVER_CORRELATION(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for class generating underlying sample

#define DECLARATION_PATHGENERATOR_SERVER(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLocalPathGeneratorServer)
// Macro instantiation for class generating underlying sample
#define INITIALISE_PATHGENERATOR_SERVER(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for class generating underlying sample for interest rate
#define DECLARATION_INTEREST_RATE_PATHGENERATOR_SERVER(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRInterestRateLocalPathGeneratorServer)
// Macro instantiation for class generating underlying sample for interest rate
#define INITIALISE_INTEREST_RATE_PATHGENERATOR_SERVER(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for class handling underlying diffusion parameters
#define DECLARATION_DIFFUSION_PARAMETER(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRDiffusionParameter)
// Macro instantiation for class handling underlying diffusion parameters
#define INITIALISE_DIFFUSION_PARAMETER(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for class handling regression for American Monte Carlo
#define DECLARATION_REGRESSION_SERVER(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRRegressionServer)
// Macro instantiation for class handling regression for American Monte Carlo
#define INITIALISE_REGRESSION_SERVER(className, name) INITIALISE_PROTOTYPE(className, name)

SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSRArchive;
	}

	namespace math {
		class CSRYieldCurveInterface;
	}

	namespace finance {
		// Some forward class declaration
		class CSRServerPayoff;
		class CSRServerOutput;
		class CSRUniformRandomGenerator;
		class CSRServerCorrelation;
		class CSRLocalPath;
		class CSRLocalPathGeneratorServer;

		class CSRBrownianPathConstruction;
		class CSRGaussianInvertion;	
		class CSRUniformRandomGenerator;

		/** Base class to handle exception on server side.
		*	It is devoted to internal use in order to bring back information
		*	on client side when errors are detected on server side.
		*/
		class SOPHIS_MONTECARLO_SERVER ServerSideException : public sophisTools::base::ExceptionBase
		{
		public:
			ServerSideException(const char * name,const char * msg)
			: sophisTools::base::ExceptionBase(name, msg)
			{};

			ServerSideException(const char * msg)
			:  sophisTools::base::ExceptionBase("Monte Carlo Server Side Exception", msg)
			{};


		protected:
				
		};
		// Deprecated
//		enum eGreekComputationType
//		{
//			eMgrAll,
//			eMgrPrice,
//			eMgrDelta,			// Deprecated
//			eMgrGamma,			// Deprecated
//			eMgrDeltaGamma,		// Deprecated
//			eMgrEpsilon,		// Deprecated
//			eMgrRho,			// Deprecated
//			eMgrConvexity,		// Deprecated
//			eMgrRhoConvexity,	// Deprecated
//			eMgrGenericGreek
//		};

		/** Structure identifying an underlying really diffused in MonteCarlo simulation 
		*/
		struct SOPHIS_MONTECARLO_SERVER SSDiffusedUnderlying
		{
			/** Default constructor for proper initialization.
			*/
			SSDiffusedUnderlying()
			{
				fCode				= 0;
				fCurrency			= 0;
				fFirstCurrency		= 0;
				fType				= instrument::qNeitherCompoNorQuanto;
				fQuantoCompoFXCode	= 0;
			};

			/** Diffused underlying sicovam code. 
			*/
			long	fCode;
			
			/** Currency of corresponding underlying
			*/
			long    fCurrency;

			/** Only relevant for a forex. This is the first currency of the forex.
			*/
			long    fFirstCurrency;

			/** This correspond to the Quanto type of the underlying diffused.
			*	This is only relevant when fCurrency is different from the option strike currency.
			*/
			instrument::eQuantoType	fType;

			/**  fQuantoCompoFXCode is the code of Forex used for quanto/Compo. 
			*/
			long fQuantoCompoFXCode;
		};

		/**		Enumeration to identify a data Type needed for price and greeks computation.
		*		This is used in order to identity if the corresponding data is different from 
		*		the one used during management theoretical value computation.
		*/
		enum eMCDataType		
		{
			eSpotPrice,				// spot price of underlying.
			eForwardPrice,			// forward price of underlying.
			eImpliedVolatility, 	// implied volatility of underlying.
			eNMUCoefficient,		// NMU coefficients linking forward and spot.
			eQuantoFactor,			// Quanto factor of the underlying
			eDividend,				// dividend of an equity underlying
			eLastForSophis			// Not a data type. This is used in order to know the enum size.
		};

		/**	Enumeration Identifying the use of current price computation.
		*	According to preference this allow to know which data are different in greeks computation
		*	from the one used for theoretical price computation. Consequently we optimize data storage
		*	and data exchanged between client and server.
		*/
		enum eBumpComputationType
		{
			eUnknown = -1,		// unknown bump type, nothing optimized
			eBasicPrice,		// no bump: this is management theoretical value computation
			eTheoreticalPrice,	// Theoretical price computation (the volatility can be different for theoretical value and greeks computation).
			eBumpSpot,			// One or two underlying spot are bumped (delta or gamma computation).
			eBumpDividend,		// An equity underlying dividend is bumped (epsilon computation).
			eBumpYieldCurve,	// A yield curve is bumped (rho computation).
			eBumpVolatility,	// An underlying volatility is bumped (vega computation).
			eBumpCorrelation,	// A correlation between two underlying is bumped (crossed vega computation).
			eComputationDate,	// Computation date is changed (theta computation).
			eBumpCredit,		// Credit risk is changed (credit sensitivities).
			eBumpRecovery		// Recovery rate sentitivity
		};

		/**
		 *	Enumeration identifying if a bump is positive or negative. Other type can be added
		 *	to manage size.
		 */
		enum eBumpDirectionType
		{
			eNone,
			ePlus,
			eMinus,
			ePlusPlus,
			ePlusMinus,
			eMinusPlus,
			eMinusMinus
		};

		/** Structure identifying one bump. It is used in order to know which
		 *	data are changed from basic computation. This allow to optimize
		 *	data exchange between client and server, memory consumption and
		 *  time on client side.
		 */
		struct SOPHIS_MONTECARLO_SERVER SSBumpKey 
		{
			/** Default constructor for proper initialization.
			*/
			SSBumpKey()
			{
				fBumpType		= eBasicPrice;
				fBumpDirection	= eNone;
				fUnderlying1	= 0;
				fUnderlying2	= 0;
			};

			/** Comparison operator to allow structure to be a key in a map.
			*/
			bool operator< (const SSBumpKey & otherKey) const 
			{ 
				return fBumpType<otherKey.fBumpType 
					|| (fBumpType == otherKey.fBumpType && fBumpDirection<otherKey.fBumpDirection)
					|| (fBumpType == otherKey.fBumpType && fBumpDirection == otherKey.fBumpDirection && fUnderlying1<otherKey.fUnderlying1)
					|| (fBumpType == otherKey.fBumpType && fBumpDirection == otherKey.fBumpDirection && fUnderlying1 == otherKey.fUnderlying1 && fUnderlying2<otherKey.fUnderlying2); 
			};

			/** Affectation operator to allow structure copy.
			*/
			SSBumpKey& operator= (const SSBumpKey & otherKey) 
			{ 
				fBumpType		= otherKey.fBumpType;
				fBumpDirection	= otherKey.fBumpDirection;
				fUnderlying1	= otherKey.fUnderlying1;
				fUnderlying2	= otherKey.fUnderlying2;
				
				return *this;
			};


			/*	Which basic quantity is bumped.
			 */
			eBumpComputationType	fBumpType;
			
			/*	In which direction this quantity is bumped.
			 */
			eBumpDirectionType		fBumpDirection;
			
			/*	Which underlying is bumped. The order used is the same as in 
			 *	{@link CSROptionMonteCarlointerface::GetUnderlying}.
			 *	This index must be coherent with the bump type. As an example when 
			 *	using eBumpDividend the corresponding index must be an equity one.
			 */
			int						fUnderlying1;

			/*	Only relevant for crossed greeks, this is the second underlying bumped. Else we must set fUnderlying2 = fUnderlying1.
			*
			*	@see SSBumpKey::fUnderlying1
			*/
			int						fUnderlying2;
		};

		/**	This enum identify features needed to compute payoff. Example: for a barrier option we need to know
		*	if the underlying had reached the barrier level during barrier activation period.
		*/
		enum	eUnderlyingPathFeature
		{
			eLevelTouch,	// Need to know if underlying reach a barrier between two dates, typically for barrier.
			eLevelTouchProbability,	// Need to know probability that underlying had reached a barrier between two dates, typically for barrier.
			eExtremum,		// Need to know an extremal value between two dates.
			// Not currently managed
			eTimeTouch,		// Need to know when underlying reach a barrier between two dates, typically for barrier with an immediate rebate.
			eOccupationTime // Need to know percentage of time below/above a specific level .
		};

		/** Enum used to know if we use the same data as the one used during management theoretical value or if we
		*	need specific data. Example: during delta computation we change the spot and forward price of the underlying.
		*
		*	Note that during basic price computation we need the corresponding data so we use eUseMyself!
		*/
		enum eDataToUseType
		{
			eUseBasicOne,		// Use the same data as the one used during basic price computation.
			eUseMyself			// Use specific data.
		};



		class SOPHIS_MONTECARLO_SERVER CSRYieldCurveLightServer : public virtual CSRYieldCurveLight
		{
		public:
			CSRYieldCurveLightServer();
			virtual ~CSRYieldCurveLightServer();

			virtual double GetForwardZeroCoupon(long dateStart,long dateEnd) const;

			inline void SetPathGenerator(CSRLocalPathGeneratorServer* pathgenerator) {fLocalPathGenerator = pathgenerator;};
		
			/**
			* Method to initialize yield curve simulated at a given date index in the path generator time grid.
			*/
			virtual void InitializeFromSimulation(int dateIndexOfPathGenratorTimeGrid);

		protected:

			/** Current absolute maturity  initialized in {@link InitializeFromSimulation}
			*/
			long fAbsoluteMaturityStart;

			CSRLocalPathGeneratorServer	*fLocalPathGenerator;

		};
		
		/**
		* The basic implementation which use a map of zero coupon for all asked dates.
		* In case of a compound factor asked at a not expected date the discount factor are 
		* interpolated by using {@link GetInterpolatedZeroCoupon}
		*/
		class SOPHIS_MONTECARLO_SERVER CSRYieldCurveLightWithAllZeroCoupon : public virtual CSRYieldCurveLightServer
		{
		public:

			DECLARATION_YIELDCURVELIGHT_SERVER(CSRYieldCurveLightWithAllZeroCoupon)
			CSRYieldCurveLightWithAllZeroCoupon();
			virtual ~CSRYieldCurveLightWithAllZeroCoupon();

			virtual double GetDiscountFactor(long relativeMaturity) const;

			/** 
			* Default implementation is a linear interpolation of the zero coupon rate in ACT/365F.
			*/
			virtual double GetInterpolatedZeroCoupon(	long	absoluteMaturity,
														long	absoluteMaturityDown,
														double	zeroCouponDown,
														long	absoluteMaturityUp,
														double	zeroCouponUp) const;

			virtual void	SetData(const sophis::tools::CSRArchive& archive);

			virtual void InitializeFromSimulation(int dateIndexOfPathGenratorTimeGrid) ;
		protected:
			_STL::map<long,double> fZeroCouponMap;

			// to optimize access
			mutable GCC_UNORDORED_NS::unordered_map<long,double> fZeroCouponHashMap;
		};


		/** Base class for all object handling volatility model parameters for an underlying diffusion.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRDiffusionParameter
		{
		public:
			/** Default constructor. 
			*/
			CSRDiffusionParameter();
			
			/** virtual destructor. 
			*/
			virtual ~CSRDiffusionParameter();

			/** Store volatility model data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const = 0;

			/** Method called on client side to know if in the current computation we need to initialise 
			*	volatility model parameter or if we can use the same as the one used in basic theoretical 
			*	price computation. 
			* 
			*	@param dataToUseType is an input vector with index corresponding to enum {@link sophis::finance::eMCDataType}
			*	allowing to know for the current computation which basic data are changed.
			*
			*	@return true if we can use basic price parameters and false if we must use specific diffusion parameters.
			*/
			virtual bool IsSameAsBasicOne(const _STL::vector<eDataToUseType>& dataToUseType) const = 0;

			/** Returns the registered name of this CSRDiffusionParameter object (e.g. the one used in macro INITIALISE_DIFFUSION_PARAMETER).
			*	This allow to identify which class to use on server side.
			*	
			*	@return a string corresponding to the identifier of the class inherited from CSRDiffusionParameter.
			*/
			virtual _STL::string	GetDiffusionParameterID() const = 0;

			/** Initialise the CSRDiffusionParameter with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRDiffusionParameter::GetData}.
			*
			*	@param archive is the archive storing the data needed for volatility model initialisation.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive) = 0;

			/** Method called on server side just after {@link CSRDiffusionParameter::SetData} in order to allow some optimisation.

				Here it is used to initialize fMaturityMap in order to make quick temporal interpolation..
			*/
			virtual void InitialiseOptimisation() {};

			/** Clone for this object. Used for prototype construction of the object, don't implement this method in any child class,
			*	this is done by using INITIALISE_DIFFUSION_PARAMETER macro.
			*
			@return A pointer on the clone created by the method.
			*/
			virtual CSRDiffusionParameter* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRDiffusionParameter for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRDiffusionParameter, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/**	Set the path generator object which will generate underlying sampling.
			*	This method is called just after creation from prototype.
			*
			*	@param pathGenerator is the CSRLocalPathGeneratorServer object which will be used.
			*/
			inline void SetPathGenerator(const CSRLocalPathGeneratorServer * pathGenerator) { fLocalPathGenerator = pathGenerator;};
			
			/**	Return a pointer on the path generator object which will generate underlying sampling.
			*/
			inline const CSRLocalPathGeneratorServer * GetPathGenerator() const {return fLocalPathGenerator;};
		
		protected:
			/** Pointer on the path generator object which will generate underlying sampling.
			*/
			const CSRLocalPathGeneratorServer * fLocalPathGenerator;

		};

		// This is the pieceWise NMU implied volatility
		class SOPHIS_MONTECARLO_SERVER CSRDiffusionParameterRisk : public virtual CSRDiffusionParameter
		{
		public:
			DECLARATION_DIFFUSION_PARAMETER(CSRDiffusionParameterRisk);
			CSRDiffusionParameterRisk() {};
			virtual ~CSRDiffusionParameterRisk() {};

			virtual bool IsSameAsBasicOne(const _STL::vector<eDataToUseType>& dataToUseType) const;
			virtual void			GetData(sophis::tools::CSRArchive& archive) const;
			virtual void			SetData(const sophis::tools::CSRArchive& archive);
			virtual _STL::string	GetDiffusionParameterID() const;


		public :
			_STL::vector<double> fVolatility;

		};

		/** Basic structure to store component of an underlying with reference to a basis.
		*	Such structure is useful when dealing with many forex underlyings: 
		*	Due to arbitrage relation when there is N+1 currency involved in forex underlying there
		*	is at most N independant real forex underlying which is used as basis for forex
		*	(e.g all other forex are reconstructed from the basis forex). 
		*
		*/
		struct SSBasisComponent 
		{
			// Index in the diffused underlying basis
			int		indexInBasis;

			// Useful for forex A/B. True if in the basis we use B/A, false if we use A/B.
			bool	reverse;
		};

		/** Structure identifying an underlying needed for payoff computation.
		*/
		struct SSUnderlingForPayoff
		{
			/**	Underlying sicovam code.
			*/
			long							fCode;

			/** Basis component vector defining how to compute underlying for payoff spot from 
			*	spot of underlying really diffused. Example, if the payoff need spot of a forex
			*	A/B and underlying really diffused basis we have forex A/C and B/C
			*	the fComponent vector will have to component:
			*	(index(A/C);  reverse = false) and ( index(B/C);  reverse = true)
			*	so that spot(A/B) = spot(A/C) / spot(B/C)
			*/
			_STL::vector<SSBasisComponent>	fComponent;

			/**	True if underlying for payoff need to be diffused compo, false else.
			*/
			bool							fIsCompo; 

			/** Basis component vector defining how to compute forex for compo from underlying diffused basis.
			*
			*	@see SSUnderlingForPayoff::fComponent
			*/
			_STL::vector<SSBasisComponent>	fComponentCompoForex;
		};



		//------------------------------------------------------------------------------
		// CSRGenericIndicatorServer
		//------------------------------------------------------------------------------
		struct SSGenericIndicator
		{
			SSGenericIndicator()
			{
				CleanGenericIndicator();
			}

			void CleanGenericIndicator()
			{
				fWeight = fValue = fWeightedValue = 0.0;
				fCount = 0;
				fIsInThePast = false;
			}

			SSGenericIndicator & operator+=(const SSGenericIndicator& other)
			{
				fWeight			+= other.fWeight;
				fValue			+= other.fValue;
				fWeightedValue	+= other.fWeightedValue;
				fCount			+= other.fCount;
				fIsInThePast	|= other.fIsInThePast;
				return *this;
			}

			SSGenericIndicator & operator=(const SSGenericIndicator& other)
			{
				if(&other == this)
					return *this;

				fWeight			= other.fWeight;
				fValue			= other.fValue;
				fWeightedValue	= other.fWeightedValue;
				fCount			= other.fCount;
				fIsInThePast	= other.fIsInThePast;
				return *this;
			}

			double	fWeight;
			double	fValue;
			double  fWeightedValue;
			int		fCount;
			bool	fIsInThePast;
		};

		struct SSCashFlowIndicator : public SSGenericIndicator
		{
			SSCashFlowIndicator()
			{
				CleanCashFlowIndicator();
			}

			SSCashFlowIndicator(int clauseId,int forexId, long date)
			{
				CleanCashFlowIndicator();
				fClauseId = clauseId;
				fForexId = forexId;
				fDate = date;
			}

			void CleanCashFlowIndicator()
			{
				CleanGenericIndicator();
				fValueCashFlowCurrency  = fPresentValueOptionCurrency = 0.0;
				fClauseId = fForexId = -1;
				fDate  = fCurrency = 0;
				fInPast = false;
				fCashFlowType = "";
			}

			SSCashFlowIndicator & operator+=(const SSCashFlowIndicator& other)
			{
				fWeight							+= other.fWeight;
				fValueCashFlowCurrency			+= other.fValueCashFlowCurrency;
				fPresentValueOptionCurrency		+= other.fPresentValueOptionCurrency;
				fCount							+= other.fCount;
				return *this;
			}

			SSCashFlowIndicator & operator=(const SSCashFlowIndicator& other)
			{
				if(&other == this)
					return *this;

				fWeight			= other.fWeight;
				fValueCashFlowCurrency			= other.fValueCashFlowCurrency;
				fPresentValueOptionCurrency		= other.fPresentValueOptionCurrency;
				fCount			= other.fCount;
				fForexId		= other.fForexId;
				fDate			= other.fDate;
				fClauseId		= other.fClauseId;
				fInPast			= other.fInPast;
				fCurrency		= other.fCurrency;
				fCashFlowType	= other.fCashFlowType;
				return *this;
			}
			double	fValueCashFlowCurrency;
			double  fPresentValueOptionCurrency;

			int		fClauseId;
			long	fForexId;
			long	fDate;
			bool	fInPast;
			long	fCurrency;

			_STL::string fCashFlowType;
		};
		class SOPHIS_MONTECARLO_SERVER CSRGenericIndicatorServer
		{
		public:
			CSRGenericIndicatorServer();
			virtual ~CSRGenericIndicatorServer();

			bool IsIndicatorRegistered(const _STL::string& indicatorStringID, int & integerID) const;
			bool IsCashFlowIndicatorRegistered(int clauseID, int forexId, long date, int & integerID) const;

			size_t RegisterIndicator(const _STL::string& indicatorStringID, int clauseID=0);
			size_t RegisterCashFlowIndicator(int clauseID, int forexId, long date);
			
			void AddIndicatorValue(size_t integerID, double val = 0.0, double weight = 1.0, bool isInThePast = false);
			void AddCashFlowIndicatorValue(int clauseID,int forexId, long date, double valueInCashFlowCurrency, double PVInOptionCurrency, double weight);
			
			inline const _STL::map< _STL::string, size_t> & GetRegisteredIndicatorMap() const {return fNamedIndicatorMap;};
			inline const _STL::vector< _STL::map< int, _STL::map<long,size_t> > >	& GetRegisteredCashFlowIndicatorVectOfMap() const {return fCashFlowIndicatorVectOfMapMap;};
			inline const _STL::vector< _STL::map< int, _STL::map<long,size_t> > >	& GetRateLegRegisteredCashFlowIndicatorVectOfMap() const {return fRateLegCashFlowIndicatorVectOfMapMap;};

			inline const SSGenericIndicator & GetNthGenericIndicator(size_t integerID) const {return fGenericIndicatorVector[integerID];};
			inline const SSCashFlowIndicator & GetNthCashFlowIndicator(size_t integerID) const {return fCashFlowIndicatorVector[integerID];};
			inline const _STL::vector<SSCashFlowIndicator> & GetCashFlowIndicatorVector() const {return fCashFlowIndicatorVector;};
			void FlushGenericIndicatorServer(const CSRGenericIndicatorServer & other);
			void RescaleResults(const double weightForRescalePrice);

			void Refresh();

			void Clean();

			sophis::tools::CSRArchive &  Serialize(sophis::tools::CSRArchive & archive) const;

			const sophis::tools::CSRArchive & DeSerialize (const sophis::tools::CSRArchive & archive);

			CSRGenericIndicatorServer & operator=(const CSRGenericIndicatorServer& other);
			
			const _STL::string  GetRegisteredIndicatorString(size_t integerID) const;

			void GetIndicatorIDListForClause(int clauseID, _STL::vector<int>& vectToFill, bool isCashFlowIndicator = false);
			void SetInPastCashFlow(int clauseId, int forexId, long date);
			inline void PastCashFlowsInitialised() {fPastCashFlowsInitialised = 1;};
			inline int GetPastCashFlowInitialised() const {return fPastCashFlowsInitialised;};

			void SetInPastClause(int clauseId, bool inPast);
			bool GetInPastClause(int clauseId) const;

			inline void SetSamplingCount(int samplingCount) {fSamplingCount = samplingCount;}; 
			inline int GetSamplingCount() const {return fSamplingCount;};
		protected:
			_STL::map< _STL::string, size_t> fNamedIndicatorMap;
			_STL::vector<SSGenericIndicator> fGenericIndicatorVector;

			_STL::vector< _STL::map< int , _STL::map<long,size_t> > > fCashFlowIndicatorVectOfMapMap;//<clauseId < forex id < dateCashFlow, index in fCashFlowIndicatorVector>>> (remember forexId = -1 for cashFlow paid in option currency)
			_STL::vector< _STL::map< int , _STL::map<long,size_t> > > fRateLegCashFlowIndicatorVectOfMapMap;
			_STL::vector<SSCashFlowIndicator> fCashFlowIndicatorVector;

			_STL::map< int, _STL::vector<int> > fIndicatorsPerClause;
			_STL::map< int, _STL::vector<int> > fCashFlowIndicatorsPerClause;
			_STL::map< int, _STL::vector<int> > fRateLegCashFlowIndicatorsPerClause;

			_STL::map< int, bool > fIsPastClause;

			int fPastCashFlowsInitialised;
			int fSamplingCount;
		};
//-----------------------------------------------------------------------------
		
		class CSRInterestRateLocalPathGeneratorServer;
		/** Interface for class which generate sample path. It handle the diffusion model and the algorithm used for path generatiion.
		 *
		 *
		 *	Make difference between "underlying for payoff" which are the underlying needed to compute by the payoff
		 *	and "really diffused underlying". Example: If we consider an option on a share S in USD compo in EUR 
		 *	the payoff will be a function (in EUR) of variable : S * USD/EUR
		 *	If the diffusion model is unable to aggregate compo diffusion the underlying for payoff will be "S compo EUR" 
		 *	but we need to diffuse 2 underlyings (risk neutral in EUR): S quanto EUR and forex USD/EUR.
		 *
		 *
		 *
		 *
		 *	@version 5.3.0
		 */
		class SOPHIS_MONTECARLO_SERVER CSRLocalPathGeneratorServer
		{
		public:
			/**		Default constructor.
			*/
			CSRLocalPathGeneratorServer();

			/**		Virtual destructor.
			*/
			virtual ~CSRLocalPathGeneratorServer();

			/** Give the last sample path generated.
			*
			*	@return a pointer on CSRLocalPath object initialized with the last sample generated.
			*/
			inline const CSRLocalPath*	GetLocalPath() const {return fLocalPath;}

			/**Set the local path to use.
			*/
			void SetLocalPath(CSRLocalPath* localPath);

			/**	
			*
			*	@param serverPayoff is the CSRServerPayoff object which will compute payoff with sample path
			*	stored in CSRLocalPath object returned by {@link CSRLocalPathGeneratorServer::GetLocalPath}
			*/
			void InitialiseLocalPath(CSRServerPayoff * serverPayoff);

			/** Return true is antithetic sampling can be used, else return false.
			*/
			virtual bool CanUseAntitheticSampling() const {return true;};


			/** Method handling the normal law generation with the relevant uniform generator, inversion algorithm and
			*	possibly the brownian generation. It is called before calling GenerateSampling().
			*
			*	@param nthSampling is the number of the normal law sampling  that we need.
			*/
			void ComputeNormalSampling(int nthSampling);

			/** Generate the underlying sampling by using last uniform law sample.
			*/
			virtual void GenerateSampling() = 0;

			/** Give the number of dates at which the path generator will simulate underlying spot values. 
			* 
			*	@Return the number of dates at which the path generator will simulate underlying spot values. 
			*/
			inline int GetDateCount() const	{return fTimeCount;};

			/** Give the nth absolute date at which the path generator will simulate underlying spot values.
			*	
			*	@param nth is an index between 0 and fTimeCount-1.
			*
			*	@Return the nth absolute date at which the path generator will simulate underlying spot values.
			*/
			inline long GetDate(int nth) const {return nth==-1 ? fToday : fDates[nth];};

			/** Give vector of absolute dates at which the path generator will simulate underlying spot values.
			*	Dates are stored increasingly.
			*	
			*	@param nth is an index between 0 and fTimeCount-1.
			*
			*	@Return the nth date at which the path generator will simulate underlying spot values.
			*/
			inline const _STL::vector<long>& GetDateVector() const 	{return fDates;};

			/** Method to identify an index in dates vector from absolute date.
			*
			*	@param date is an absolute date for which we want to know the corresponding index.
			*
			*	@return the index in dates at which the path generator will simulate underlying spot values.
			*/
			int GetIndexFromDate(long date) const;

			/**	Give the number of underlying really diffused in the Monte Carlo simulation.	
			*/
			inline int GetUnderlyingDiffusedCount() const	{return fUnderlyingDiffusedCount;};

			/**	Give structure identifying an underlying really diffused.
			*
			*	@param nth is the index of the underlying really diffused. It must be 
			*
			*	@return a structure identifying an underlying really diffused.
			*
			*	@see sophis::finance::SSDiffusedUnderlying 
			*/
			inline const SSDiffusedUnderlying& GetUnderlyingDiffused(int nth) const {return fUnderlyingDiffused[nth];}

			/**	Give the number of underlyings for payoff.	
			*/
			inline size_t GetUnderlyingForPayoffCount() const {return fUnderlyingForPayoff.size();}

			/**	Give structure identifying an underlyings for payoff.	
			*
			*	@param nth is the index of the underlyings for payoff.
			*
			*	@return a structure identifying an underlyings for payoff.
			*
			*	@see sophis::finance::SSUnderlingForPayoff 
			*/
			inline const SSUnderlingForPayoff& GetUnderlyingForPayoff(int nth) const {return fUnderlyingForPayoff[nth];};

			/**
			 * Method called to know if the path generator is able to handle some specific feature is the path
			 * generation.
			 *
			 *	@param feature is the feature identifier for which we want to know if it is handle by the path generator.
			 *
			 *	@see sophis::finance::eUnderlyingPathFeature
			 */
			virtual bool IsPathFeatureHandled(eUnderlyingPathFeature feature) const {return false;};

			/** This method compute the equivalent local volatility for a payoff for underlying by assuming
			*	local log normal diffusion of the underlyings in order to compute path feature.
			*
			*	@param underlyingIndexForpayOff is the index of the underlyings for payoff.
			*	@param timeStepIndex is an index between 0 and fTimeCount-1.
			*	@param	antitheticSamplingIndex is the number ID for the antithetic sampling.
			*
			*	@return the equivalent local volatility for a payoff for underlying by assuming local log normal diffusion of the underlyings.
			*/
			virtual double GetVolatilityForPayoffUnderlying(int underlyingIndexForpayOff, int timeStepIndex,  int antitheticSamplingIndex) const = 0;

			/** This method return the stochastic volatility of the path
			*	local log normal diffusion of the underlyings in order to compute path feature.
			*
			*	@param nthUnderlying is the index of the underlying
			*	@param nthdate is an index between 0 and fTimeCount-1.
			*	@param nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the equivalent local volatility for a payoff for underlying by assuming local log normal diffusion of the underlyings.
			*/

			virtual double GetVolatilityPathOfDiffusedUnderlying(int nthUnderlying, int nthdate, int nthAntitheticSampling) const = 0;

			/** This method return the number of diffused volatilities.
			*/
			virtual int GetDiffusedVolatilitiesCount() const {return 0;};


			/** Compute the minimum of the spot of an underlying for payoff on a given period.
			 
				Default implementation assume that the corresponding underlying for payoff is log normal
				on every time step between startDate and endDate with the volatility given by {@link GetVolatilityForPayoffUnderlying}.

				@param underlyingIndex is the index of the underlying for payoff for which we want the minimum.
				@param antithethicSampling is the antithetic sampling index.
				@param startDate is the period start date (it must be in the time grid).
				@param spotStart is the simulated spot on start date.
				@param endDate  is the period end date (it must be in the time grid).
				@param spotEnd is the simulated spot on end date.
				@param identifier identify the specific feature in the payoff.
			 */
			virtual double GetMinimum(	int		underlyingIndex,
										int		antithethicSampling,
										long	startDate,
										double	spotStart, 
										long	endDate,
										double	spotEnd,
										int		identifier) const;

			/** Compute the maximum of the spot of an underlying for payoff on a given period.

			Default implementation assume that the corresponding underlying for payoff is log normal
			on every time step between startDate and endDate with the volatility given by {@link GetVolatilityForPayoffUnderlying}.

			@param underlyingIndex is the index of the underlying for payoff for which we want the maximum.
			@param antithethicSampling is the antithetic sampling index.
			@param startDate is the period start date (it must be in the time grid).
			@param spotStart is the simulated spot on start date.
			@param endDate is the period end date (it must be in the time grid).
			@param spotEnd is the simulated spot on end date.
			@param identifier identify the specific feature in the payoff.
			*/
			virtual double GetMaximum(	int		underlyingIndex,
										int		antithethicSampling,
										long	startDate,
										double	spotStart, 
										long	endDate,
										double	spotEnd,
										int		identifier) const;

			/** Method to know if an underlying for payoff has reached a on a given period.

			Default implementation assume that the corresponding underlying for payoff is log normal
			on every time step between startDate and endDate with the volatility given by {@link GetVolatilityForPayoffUnderlying}.

			@param underlyingIndex is the index of the underlying for payoff.
			@param antithethicSampling is the antithetic sampling index.
			@param startDate is the period start date (it must be in the time grid).
			@param spotStart is the simulated spot on start date.
			@param endDate  is the period end date (it must be in the time grid).
			@param spotEnd is the simulated spot on end date.
			@param barrier is the level of the barrier.
			@param isUp is true for an up barrier, false else.
			@param tFirstTouch is the time at which the level is reached. Default implementation 
				is a rough approximation which assume that spot increase linearly between the start 
				date of the first time step at which barrier is reached and the simulated extrema 
				on this time step.
			@param identifier identify the specific feature in the payoff.

			*/
			virtual bool IsLevelReached(	int		underlyingIndex,
											int		antithethicSampling,
											long	startDate,
											double	spotStart, 
											long	endDate,
											double	spotEnd,
											double	barrier, 
											bool	isUp,
											double*	tFirstTouch,
											int		identifier) const;

			/** Compute the probability that an underlying for payoff reaches a given level on a given period.

			Default implementation assume that the corresponding underlying for payoff is log normal
			on every time step between startDate and endDate with the volatility given by {@link GetVolatilityForPayoffUnderlying}.

			@param underlyingIndex is the index of the underlying for payoff.
			@param antithethicSampling is the antithetic sampling index.
			@param startDate is the period start date (it must be in the time grid).
			@param spotStart is the simulated spot on start date.
			@param endDate  is the period end date (it must be in the time grid).
			@param spotEnd is the simulated spot on end date.
			@param barrier is the level of the barrier.
			@param isUp is true for an up barrier, false else.
			@param identifier identify the specific feature in the payoff.
			*/
			virtual double GetLevelReachedProbability(	int		underlyingIndex,
														int		antithethicSampling,
														long	startDate,
														double	spotStart, 
														long	endDate,
														double	spotEnd,
														double	barrier, 
														bool	isUp,
														int		identifier) const;

			/** Compute the probability that an underlying for payoff reaches a double barrieron a given period.

			Default implementation assume that the corresponding underlying for payoff is log normal
			on every time step between startDate and endDate with the volatility given by {@link GetVolatilityForPayoffUnderlying}.

			@param underlyingIndex is the index of the underlying for payoff.
			@param antithethicSampling is the antithetic sampling index.
			@param startDate is the period start date (it must be in the time grid).
			@param spotStart is the simulated spot on start date.
			@param endDate  is the period end date (it must be in the time grid).
			@param spotEnd is the simulated spot on end date.
			@param barrier is the level of the upper barrier.
			@param barrier is the level of the lower barrier.
			@param identifier identify the specific feature in the payoff.
			*/
			double GetDoubleLevelReachedProbability(	int		underlyingIndex,
														int		antithethicSampling,
														long	startDate,
														double	spotStart, 
														long	endDate,
														double	spotEnd,
														double	barrierUp, 
														double	barrierDown, 
														int		identifier) const;

			/**	Method to know if current task is the theoretical price computed by changing computation date
			*	in order to compute theta.
			*	
			*	@return true is we are computing price for theta, false else.
			*/
			inline bool IsThethaComputation() const {return fComputationDates[fCurrentTask]!=fBasicComputationDate;}

			/**	Internal. Method to set current task ID. It also set the relevant current computation date.
			*	
			*	@param currentTask is the task number.
			*/
			void SetCurrentTask(int currentTask);

			/**	Internal. Method to get current task ID.
			*	
			*	@Return currentTask is the task number.
			*/
			inline int GetCurrentTask() const {return fCurrentTask;};

			/**	Give the computation date for the current computation.
			*
			*	@return computation date for the current computation.
			*/
			inline double GetComputationDate() const {return fCurrentComputationDate;};
			
			/**	Internal. Fill a map allowing to identify index corresponding to an absolute date in the path generator time grid. 
			*/ 
			void	FillMapFromDatesVector();

			/** Internal. This method is called to use a specific correlation object which is initialised with data stored in archive.
			*	
			*	@param task is the task ID.
			*	@param archive is a CSRArchive storing data needed to initialise the specific correlation object.
			*/
			void	InitialiseServerCorrelation(int task, sophis::tools::CSRArchive& archive);

			/** Internal. This method is called to use the same correlation object as the one used for theoretical price.
			*/
			void	UseBasicServerCorrelationForTask(int task);

			/** Tell us if we must aggregate underlying and forex as a single underlying for compo diffusion.
			 *	This will impact the forward prices and volatilities stored.
			 *	Moreover, when we do not aggregate we need to diffuse the corresponding forex.
			 * 
			 *	When an underlying is compo, the true option's underlying is
			 *	the spot S multiplied by the forex rate FX. In Black and Scholes
			 *	framework S*FX is treated as a one dimentional processus with forward
			 *	equal to the underlying forward multiplied by FX forward and with volatility
			 *	given by {@link CSRMarketData::GetCompoVolatility}.
			 * 
			 *	@return true if we must aggregate, false else. 
			 */
			bool	AggregateFXForCompoDiffusion() const {return fAggregateFXForCompoDiffusion;};


			/** Tell us if we adjust the forward of quanto underlying by using Black and Scholes
			 *	quanto adjustment. In this case quanto diffusion is only modified by constant
			 *	quanto adjustment. In order to take into account of smile in the quanto drift
			 *	we must return false then manage quanto drift change during integration.
			 * 
			 *	@return true if we must adjust forward stored, false else.
			 */
			bool	UseBSQuantoForward() const {return fUseBSQuantoForward;};

			/**  Give the number of normal law size needed by the diffusion model to compute underlyings' spot from one step to the next one.
			*	Its value come from client side {@link sophis::finance::CSRLocalPathGeneratorClient::GetNormalLawSizeByStep}.
			*
			*	@return the number of normal law size needed by the diffusion model to compute underlying's spot from one step to the next one.
			*/
			inline int GetNormalLawSizeByStep() const {return fNormalLawSizeByStep;};

			/**	 Give the number of uniform law needed to simulate one sample and compute corresponding price (e.g. include thoses needed for path feature).
			*
			*	@return the number of uniform law needed to simulate one sample and compute corresponding payoff.
			*/
			inline int	GetUniformLawSize() const {return fUniformLawSize;};	

			/**	Accessors to uniform law buffer.
			*
			*	@return a pointer on uniform law buffer.
			*/
			const double*	GetCurrentUniformLaw() const;

			/**	Accessors to uniform laws needed to manage a specific feature.
			*
			*	@param underlyingIndex is the index of the underlying for payoff for which we want to manage a specific feature.
			*	@param feature identify the type of the specific feature.
			*	@param stepIndex is the time step index for which we need to manage specific feature.
			*	@param identifier identify the specific feature in the payoff.
			*	@param lawCount is an output parameter to know how many uniform law are reserved for the corresponding feature (eg. all law from index 0 to index lawCount-1 are reserved).
			*
			*	@return a pointer on uniform laws needed to manage the specific feature.
			*/
			const double*	GetSupplementaryUniformLaw(	int						underlyingIndex,
														eUnderlyingPathFeature	feature,
														int						stepIndex,
														int						identifier,
														int						&lawCount) const;

			/** Give the number of uncorrelated normal laws needed to generate one path, including those needed to simulate interest rate.
			*	
			*	@return the number of uncorrelated normal laws needed to generate one path, including those needed to simulate interest rate.
			*
			*	@see fUniformLawSize.
			*/
			inline int GetFullNormalLawSize() const {return fFullNormalLawSize;};

			/**	Accessors to  uncorrelated normal laws buffer.
			*
			*	@return a pointer on  uncorrelated normal laws buffer.
			*/
			inline const double*	GetUncorrelatedNormalLaw() const {return fUncorrelatedNormalLaw;};

			/**	Give the CSRServerCorrelation to use for the current task in order to correlate normal law samplings.
			*	
			*	@return a pointer on the CSRServerCorrelation to use for the current task.
			*/
			inline const CSRServerCorrelation* GetServerCorrelation() const{return fServerCorrelationToUse[fCurrentTask];};

			/** Initialise the CSRLocalPathGeneratorServer with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order to create one or several payoff object on the server side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRLocalPathGeneratorServer
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Initialise the market data dependent data in CSRLocalPathGeneratorServer with the data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRClientOutput.
			*	When called fCurrentTask is settled to the relevant value so that market data dependent data can be stored and accessed relevantly according to the current task durring computation.
			*
			*	@param archive is the archive storing the data needed to initialise market data dependent data in CSRLocalPathGeneratorServer.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);

			/** Give the number of antithetic sampling count generated (usually 0 or 1). 
			* 
			*	@return the number of antithetic sampling to generate.
			*/
			inline int GetAntitheticSamplingCount() const	{return fAntitheticSamplingCount;};

			/**	Give the number of equity underlying really diffused.
			*
			*	@return the number of equity underlying really diffused.
			*/
			inline int GetEquityDiffusedCount() const {return fEquityDiffusedCount;};

			/**	Give the number of forex underlying really diffused.
			*
			*	@return the number of forex underlying really diffused.
			*/
			inline int GetForexDiffusedCount() const {return fForexDiffusedCount;};

			/**	Set the number of task to manage durring monte carlo simulation.	
			*/
			void SetTaskCount(int taskCount);

			/**	Give the number of task to manage durring monte carlo simulation.	
			*/
			int GetTaskCount() const;

			/** Tell us if we can use NMU coefficient.
			*	Its value come from client side {@link sophis::finance::CSRLocalPathGeneratorClient::UseNMUCoefficient}.
			* 
			*	@return true if we can use NMU coefficient, false else.
			*/
			inline bool UseNMUCoefficient() const {return fUseNMUCoefficient;};

			/** Tell us if we use cash volatility.
			*	Its value come from client side {@link sophis::finance::CSRLocalPathGeneratorClient::UseCashVolatility}.
			* 
			*	@return true if we can use cash volatility, false else.
			*/
			inline bool UseCashVolatility() const {return fUseCashVolatility;};
		
			/**	Give the forward price (according to the current task) of an underlying for payoff at given date in time grid.
			*
			*	@param nthUnderlyingForPayoff is the index identifying underlying for payoff.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the forward price of underlying for payoff.
			*/
			double GetForwardForPayoffUnderlying(int nthUnderlyingForPayoff, int nthdate) const;

			/**	Give the forward price (according to the current task) of an underlying really diffused at given date in time grid.
			*
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the forward price of underlying really diffused.
			*/
			inline double GetForwardPrice(int nthUnderlying, int nthdate) const
			{
				size_t index = fForwardIndexToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying ];
				const _STL::vector<double>& currentForwardPrice = fForwardContainer[index];
				return currentForwardPrice[nthdate];
			};
			
			/**	Can only be called if UseNMUCoefficient is true.
			*	Give the NMU coefficient a (according to the current task) of an underlying really diffused at given date in time grid.
			*
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the NMU coefficient a of underlying really diffused.
			*/
			inline double GetNMUa(int nthUnderlying, int nthdate) const
			{
				size_t index = fNMUaIndexToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying ];
				const _STL::vector<double>& currentMNUaPrice = fNMUContainer[index];
				return currentMNUaPrice[nthdate];
			};

			/**	Can only be called if UseNMUCoefficient is true.
			*	Give the NMU coefficient b (according to the current task) of an underlying really diffused at given date in time grid.
			*
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the NMU coefficient b of underlying really diffused.
			*/
			inline double GetNMUb(int nthUnderlying, int nthdate) const
			{
				size_t index = fNMUbIndexToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying ];
				const _STL::vector<double>& currentMNUbPrice = fNMUContainer[index];
				return currentMNUbPrice[nthdate];
			};

			/**	Can only be called if UseBSQuantoForward is true.
			*	Give the Black and Scholes quanto correction multiplicative factors to use (according to the current task) for an underlying really diffused at given date in time grid.
			*
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the Black and Scholes quanto correction multiplicative factors for an underlying really diffused.
			*/
			inline double GetQuantoFactor(int nthUnderlying, int nthdate) const
			{
				size_t index = fQuantoFactorIndexToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying ];
				const _STL::vector<double>& currentQuantoFactor = fQuantoFactorContainer[index];
				return currentQuantoFactor[nthdate];
			};

			/**	Give spot to use (according to the current task) for an underlying really diffused.
			*
			*	@param nthUnderlying is the index identifying underlying really diffused.
			*	
			*	@return the spot of an underlying really diffused.
			*/
			inline double GetSpot(int nthUnderlying) const
			{
				size_t index = fSpotIndexToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying ];
				return fSpotContainer[index];
			};

			/**	Give spot to use (according to the current task) for an underlying for payoff.
			*
			*	@param nthUFP is the index identifying underlying for payoff.
			*	
			*	@return the spot of an underlying for payoff.
			*/
			double GetSpotOfUnderlyingForPayoff(int nthUFP) const;
			double GetBasicSpotOfUnderlyingForPayoff(int nthUFP) const;

			/** Vector of market data dependent info to use for the current task. 
			*
			*	@return the vector of market data dependent info to use for the current task.
			*/
			inline const _STL::vector<double>& GetMarketDataDependentInfo() const
			{
				const size_t& index = fMarketDataDependantInfoIndexToUse[fCurrentTask];
				return fMarketDataDependantInfoContainer[index];
			};

			/**
			* Accessors to a vector of yield curve light corresponding to the different cashFlow currency of the option. 
			*/
			#ifndef GCC_XML
			virtual const _STL::vector<CSRYieldCurveLightServer*>& GetYieldCurveLight() const;
			#endif // GCC_XML

			/**
			* Return the discount yield curve light corresponding to the option strike currency. 
			*/
			virtual CSRYieldCurveLightServer* GetYieldCurveLightForOptionCurrency() const;

			/** Give a pointer on diffusion parameters to use for the current task and a given underlying. 
			*
			*	@param	nthUnderlying is the number ID for the really diffused underlying.
			*	
			*	@return a pointer on diffusion parameters to use for the current task and a given underlying. 
			*/
			inline const CSRDiffusionParameter* GetNthDiffusionParameter(int nthUnderlying) const
			{
				if (fDiffusionParameterToUse.size()>fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying)
					return fDiffusionParameterToUse[fCurrentTask*fUnderlyingDiffused.size() + nthUnderlying];
				return 0;
			};


			/** Method called when fUnderlyingDiffusedCount, fTimeCount and fAntitheticSamplingCount are properly initialized.
			*	It must resize the buffers storing diffused variables to their relevant size.
			*	Default implementation set size of fPathOfDiffusedUnderlying to fUnderlyingDiffusedCount*fTimeCount*fAntitheticSamplingCount.
			*/
			virtual void InitialisePathOfDiffusedUnderlying();

			/**	Accessors on path of really diffused underlyings. 
			*
			*	@param	nthUnderlying is the number ID for the really diffused underlying.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return a reference on the simulated spot values for writing purpose.
			*/
			void SetPathOfDiffusedUnderlying(int nthUnderlying, int nthdate, int nthAntitheticSampling, double value);

			/**	Accessors on path of really diffused underlyings. 
			*
			*	@param	nthUnderlying is the number ID for the really diffused underlying.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the simulated spot values.
			*/
			double GetPathOfDiffusedUnderlying(int nthUnderlying, int nthdate, int nthAntitheticSampling) const;

			/**  Aggregate sample results for really diffused underlying to compute spot of underlying really asked by payoff.
			* 
			*	@param localPathToFill is the CSRLocalPath object which will store sample spot for underlying for payoff.
			*/
			virtual void FillSamplingForPayoff(CSRLocalPath*localPathToFill);

			/** Clone for this object. Used for prototypal construction of the object, don't implement this method in any child class.
			*/
			virtual CSRLocalPathGeneratorServer* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRLocalPathGeneratorServer for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLocalPathGeneratorServer, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/**
			* Give the first index of law used to generate equity path
			*/
			int GetFirstLawIndexForEquity() const;

			/**
			* Give the first index of law used to generate equity path
			*/
			int GetFirstLawIndexForInterestRate() const;

		public :
			/** Structure identifying uniforms law reserved fo a specific purpose. 
			*/
			struct SSUniformLawID
			{
				/**  Constructor for basic initialisation.
				*/
				SSUniformLawID() {firstToUse=numberReserved=0;};
				
				/** First law index reserved for a specific path feature. 
				*/ 
				int	firstToUse;

				/** Number law reserved for a specific path feature
				*/
				int	numberReserved;
			};

			/** Structure identifying a path feature asked to path generator.
			*/
// 			struct SSKeyForUniformLaw
// 			{
// 				/** Identifyier of the feature.	
// 				*/
// 				eUnderlyingPathFeature	feature;
// 
// 				/**	Double identifying the level for the corresponding feature (eg, for a barrier this is the level of the barrier).
// 				*/
// 				double					level;
// 
// 				/**	Comparaison operator between two key used to store tham in map.	
// 				*/
// 				bool operator< (const SSKeyForUniformLaw & otherKey) const 
// 				{ 
// 					return feature<otherKey.feature 
// 						|| (feature == otherKey.feature && level<otherKey.level); 
// 				};
//			};

			/** Give a vector containing (if relevant, eg if underlying currency is different from price currency) 
			*	components of quanto forex (underlying currency versus price currency) in diffused forex basis.
			*	
			*	@param nth is the index identifying really diffused underlying.
			*	
			*	@return a vector containing components of quanto forex in diffused forex basis.
			*/
			inline const _STL::vector<SSBasisComponent>& GetNthQuantoComponent(int nth) const {return fQuantoComponent[nth];};


			/**  Internal function called to know if at some point there is a mismatch between date at which we ask an underlying spot 
			*	 and date at which we are supposed to generate it.
			*/
			inline bool IsADateMismatch() const {return fIsADateMismatch;};


			/** Set the server side of the algorithm modifying standard normal law so that they are
			*	Brownian increment needed for path generation.
			*
			*	@param brownianPathConstruction is a pointer on the CSRBrownianPathConstruction object to use to generate Brownian path from standard normal sampling.
			*
			* @see CSRBrownianPathConstruction
			*/
			void SetBrownianPathConstruction(CSRBrownianPathConstruction* brownianPathConstruction);


			/** Set the server side of the object encapsulating the algorithm used to generate standard normal law
			*	from uniform ones.
			*
			*	@param gaussianInvertionAlgo is a pointer on the CSRGaussianInvertion object to use to generate standard normal sampling from uniform one.
			*
			* @see CSRGaussianInvertion  
			*/
			void SetGaussianInvertion(CSRGaussianInvertion	*gaussianInvertionAlgo);

			/** Set the server side of the uniform generator used to generate sample of uniform law.
			*
			*	@param uniformRandomGenerator is a pointer on the uniform random generator to use to generate uniform sampling.
			*
			* @see CSRUniformRandomGenerator
			*/
			void SetUniformRandomGenerator(CSRUniformRandomGenerator	*uniformRandomGenerator);


			inline CSRInterestRateLocalPathGeneratorServer & GetInterestRateLocalPathGeneratorServer() const {return *fInterestRateLocalPathGeneratorServer;};

			inline long GetTodayDate() const {return fToday;};


#ifndef GCC_XML
			inline	CSRGenericIndicatorServer *  GetGenericIndicatorServer() const {return fGenericIndicatorServer;};
			inline  void SetGenericIndicatorServer(CSRGenericIndicatorServer * indicServer) const {fGenericIndicatorServer = indicServer;};

		protected :
			mutable CSRGenericIndicatorServer * fGenericIndicatorServer;
#endif // GCC_XML

		protected :
			friend class CSRInterestRateLocalPathGeneratorServer;


			CSRInterestRateLocalPathGeneratorServer * fInterestRateLocalPathGeneratorServer;

			/**  Pointer on CSRLocalPath object storing the last sample generated.
			*/
			CSRLocalPath *fLocalPath;

			/** Vector of pointer on diffusion parameters for a given task and a given underlying. 
			*	For a given underlying many pointer can be the same for different task.
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetNthDiffusionParameter}.
			*/
			_STL::vector<CSRDiffusionParameter*> fDiffusionParameterToUse;

			/**	Vector of pointer storing all diffusion parameters needed for Monte Carlo simulation.
			*/
			_STL::vector<CSRDiffusionParameter*> fDiffusionParameterContainer;

			/** Vector of pointer on CSRServerCorrelation for a given task. 
			*	Many pointer can be the same for different task.
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetServerCorrelation}.
			*/
			_STL::vector<CSRServerCorrelation*> fServerCorrelationToUse;

			/**	Vector of pointer storing all CSRServerCorrelation needed for Monte Carlo simulation.
			*/
			_STL::vector<CSRServerCorrelation*> fServerCorrelationContainer;

			/** Vector of index identifying forward vector to use for a given task and a given underlying really diffused. 
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetForwardPrice}.
			*/
			_STL::vector< size_t >	fForwardIndexToUse;
			/** Vector storing forward vector to use for a given task and a given underlying really diffused.  
			*/
			_STL::vector< _STL::vector<double> >	fForwardContainer;

			/** Vector of index identifying vector of NMU coefficient a to use for a given task and a given underlying really diffused. 
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetNMUa}.
			*/
			_STL::vector< size_t >					fNMUaIndexToUse;
			/** Vector of index identifying vector of NMU coefficient b to use for a given task and a given underlying really diffused. 
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetNMUb}.
			*/
			_STL::vector< size_t >					fNMUbIndexToUse;
			/** Vector storing vector of NMU coefficient a and b to use for a given task and a given underlying really diffused.  
			*/
			_STL::vector< _STL::vector<double> >	fNMUContainer;

			/** Vector of index identifying vector Black and Scholes quanto correction multiplicative factors to use for a given task and a given underlying. 
			*	Only filled when aggregating quanto factor is possible {@link sophis::finance::CSRLocalPathGeneratorClient::UseBSQuantoForward}
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetQuantoFactor}.
			*/
			_STL::vector< size_t >					fQuantoFactorIndexToUse;
			/** Vector storing vector quanto correction multiplicative factors.  
			*/
			_STL::vector< _STL::vector<double> >	fQuantoFactorContainer;

			/** Vector of index identifying vector market data dependent info to use for a given task . 
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetMarketDataDependentInfo}.
			*/
			_STL::vector< size_t >					fMarketDataDependantInfoIndexToUse;
			/** Vector storing market data dependent info to use for a given task . 
			*/
			_STL::vector< _STL::vector<double> >	fMarketDataDependantInfoContainer;


			/** Vector of index identifying yield curve light to use for a given task . 
			*
			*/
			_STL::vector< size_t >					fYieldCurveLightIndexToUse;


			/** Vector storing the yield curve light vector (one YieldCurveLightServer per cashFlow currency) to use for a given task .
			*   (dim 1 = index to use for the task, dim 2 = yield curve index for cash flow)
			*/
			_STL::vector<CSRYieldCurveLightServer* >		fDiscountYieldCurveLightContainer;

			/** Vector storing the yield curve light vector (one YieldCurveLightServer per cashFlow currency) to use for a given task .
			*   (dim 1 = index to use for the task, dim 2 = yield curve index for cash flow)
			*/
			_STL::vector< _STL::vector<CSRYieldCurveLightServer*> >		fYieldCurveLightContainer;

			
			/** Vector of index identifying  spot to use for a given task and a given underlying. 
			*
			*	{@see sophis::finance::CSRLocalPathGeneratorClient::GetSpot}.
			*/
			_STL::vector< size_t >	fSpotIndexToUse;
			/** Vector storing spot for a given task and a given underlying. 
			*/
			_STL::vector<double> 	fSpotContainer;

			/** Today's date. This is the application context date at which computation is done.
			*/
			long fToday;

			/**  Number of normal law size needed by the diffusion model to compute one underlying spot from one step to the next one.
			*	Its value come from client side {@link sophis::finance::CSRLocalPathGeneratorClient::GetNormalLawSizeByStep}.
			*/
			int fNormalLawSizeByStep;

			/**  True if the diffusion model is able to diffuse the aggregated product of underlying spot and forex spot. 
			*/
			bool fAggregateFXForCompoDiffusion;

			/**  True if the diffusion model is able to handle quanto by adjusting underlying forward with Black and Scholes quanto correction.
			*/
			bool fUseBSQuantoForward;

			/**  True if the diffusion model need NMU coefficients.
			*/
			bool fUseNMUCoefficient;

			/**  True if the diffusion model need NMU coefficients.
			*/
			bool fUseCashVolatility;

			/** Number of price to compute in the Monte Carlo simulation. Usually there is one basic price and all theoretical value computed with bumped parameters to compute greeks. 
			*/
			int fTaskCount;
			
			/** Internal Structure storing for an underlying and a timestep (index in vector is the timestep*numberofUnderlying + underlying)
			*	the mapping of uniform law allowed to manage specific path feature.
			*/
			_STL::vector<_STL::map<int,SSUniformLawID> > fUniformLawMapping;

			/** Structure identifying underlying really diffused.
			*/
			_STL::vector<SSDiffusedUnderlying>	fUnderlyingDiffused;

			/** Structure identifying underlying for payoff.
			*/
			_STL::vector<SSUnderlingForPayoff>	fUnderlyingForPayoff;
						
			/** Vector storing for each underlying a vector containing (if relevant, eg if underlying currency is different from price currency) 
			*	components of quanto forex (underlying currency versus price currency) in diffused forex basis.
			*/
			_STL::vector<_STL::vector<SSBasisComponent> > fQuantoComponent;
			
			/**  Vector of future dates at which underlying spot must be simulated. 
			*/
			_STL::vector<long>		fDates;
			/**  Map between absolute date at which underlying spot must be simulated and and corresponding index in {@link sophis::finance::CSRLocalPathGeneratorServer::fDates}.
			*/
			_STL::map<long, int>	fFixingDateMap;
			
			/** Current task identifier (must be less than fTaskCount).
			*/
			int fCurrentTask;

			/** Computation date of each task (a theta calculation changes this date)
			*/
			_STL::vector<long> fComputationDates;

			/**  Number of the sampling currently computed.
			*/
			int fCurrentSampling;

			/**  Number of uniform law needed to simulate one sample and compute corresponding price (e.g. include thoses needed for path feature).
			*/
			int fUniformLawSize;	

			/** Number of uncorrelated normal laws, including those needed to simulate interest rate. 
			*	It must be an even number for compatibility with Box Muller algorithm. 
			*/
			int fFullNormalLawSize;	
			
			/**  Vector of uncorrelated normal laws. It size is {@link fFullNormalLawSize}.
			*/
			double	*fUncorrelatedNormalLaw;

			/**	Number of equity underlying really diffused.
			*/
			int fEquityDiffusedCount;	

			/**	Number of forex underlying really diffused.
			*/
			int fForexDiffusedCount;

			/**	Number of underlying really diffused.
			*/
			int fUnderlyingDiffusedCount;

			/**	Number of dates at which we need to simulate underlying spot. Must be equal to {@link sophis::finance::CSRLocalPathGeneratorServer::fDate} size.
			*/
			int fTimeCount;		

			/**  Number of antithetic sampling used.
			*/
			int fAntitheticSamplingCount;
			
			/** Vector storing path of really diffused underlying. Indexed so that nthUnderlying, nthdate, nthAntitheticSampling correspond to fPath[(nthAntitheticSampling*fUnderlyingDiffusedCount+nthUnderlying)*fTimeCount+nthdate].
			*/
			_STL::vector<double> fPathOfDiffusedUnderlying;// 

			/** Absolute computation date for current computation.	
			*/
			long fCurrentComputationDate;

			/** Absolute computation date for all price computation except theta.	
			*/
			long fBasicComputationDate;

			/** Server side of the algorithm modifying standard normal law so that they are
			*	Brownian increment needed for path generation.
			*
			* @see CSRBrownianPathConstruction
			*/
			CSRBrownianPathConstruction	*fBrownianPathConstruction;


			/** Server side of the object encapsulating the algorithm used to generate standard normal law
			*	from uniform ones.
			*
			* @see CSRGaussianInvertion  
			*/
			CSRGaussianInvertion	*fGaussianInvertionAlgo;

			/** Server side of the uniform generator used to generate sample of uniform law.
			*
			* @see CSRUniformRandomGenerator
			*/
			CSRUniformRandomGenerator	*fUniformRandomGenerator;
			
			/** A shift to apply to the uniform random generator: instead of using sampling
			*	from 1 to N the sampling used will be the one between 1+fSequenceShift and N+fSequenceShift.
			*/
			int fSequenceShift;

			// internal for error management
			mutable bool fIsADateMismatch;
			mutable long fMismatchDate;

		};

		class SOPHIS_MONTECARLO_SERVER CSRInterestRateLocalPathGeneratorServer
		{
		public:
			CSRInterestRateLocalPathGeneratorServer();
			virtual ~CSRInterestRateLocalPathGeneratorServer();
			
			void SetPathGenerator(const CSRLocalPathGeneratorServer& pathGenerator);

			/** Generate the underlying sampling by using last uniform law sample.
			*/
			virtual void GenerateSampling();

			/** Cache zero coupons for example.
			*/
			virtual void FillOptimisation(const CSRLocalPathGeneratorServer& pathGenerator, const CSRServerPayoff& serverPayoff);
			virtual const sophis::math::CSRYieldCurveInterface* GetYieldCurve(long startDate, int antitheticSampling, long familyID = -1) const;

			/** Give spot expectation on end date of the nth time step of the simulation, conditional on the 
			*	spot value at the start of this step.
			*
			*	@param nth is the time step identifier,
			*	@param spotStart is the simulated spot at the beginning of the time step,
			*	@param forwardStart is the current forward price with maturity equal to the beginning of the time step,
			*	@param forwardEnd  is the current forward price with maturity equal to the end of the time step,


				Default implementation is the deterministic interest rate case which return spotStart*forwardEnd/forwardStart
			*/
			virtual double GetDriftAdjustedExpectation(	size_t nth, 
														double spotStart,
														double forwardStart,
														double forwardEnd,
														int nthAntitheticSampling) const;


			/** Give the numeraire with the discrete spot numeraire Nn of the simulation
			*	Nn = 1/[ prod_i=0^i=n-1 P(Ti, Ti, Ti+1) ]
			*	
			*	Default implementation is Nn = 1/ B(T0, T0, Tn)
			*/
			virtual double GetNumeraireOnEndDate(	size_t	nth,
													int		nthAntiTheticSampling) const;

			/** For a payment with amount fixed at the end date Tn of the nth step, with a given payment Tp date this method return 
			*	the discount factor P(Tn, Tn, Tp) and fill the numeraire with the discrete spot numeraire Nn of the simulation
			*	Nn = 1/[ prod_i=0^i=n-1 P(Ti, Ti, Ti+1) ]
			*	
			*	Value of a cash flow Xn set up at time Tn, paid at Tp is equal to Xn / Nn *  P(Tn, Tn, Tp)
			*
			*	Default implementation is the deterministic interest rate case which return B(T0, Tn, Tp) and Nn = 1/ B(T0, T0, Tn)
			*/
			virtual double GetDiscountFactorAndSimulationNumeraireOnEndDate(	size_t	nth, 
																				long	paymentDate,
																				double	&numeraire,
																				int		nthAntitheticSampling) const;

			/** Same as {@link GetDriftAdjustedExpectation}, but with a sorted vactor of payment dates
			*	For a payment with amount fixed at the end date Tn of the nth step, with a given payment Tp date this method return 
			*	the discount factor P(Tn, Tn, Tp) and fill the numeraire with the discrete spot numeraire Nn of the simulation
			*	Nn = 1/[ prod_i=0^i=n-1 P(Ti, Ti, Ti+1) ]
			*	
			*	Value of a cash flow Xn set up at time Tn, paid at Tp is equal to Xn / Nn *  P(Tn, Tn, Tp)
			*
			*	Default implementation is the deterministic interest rate case which return B(T0, Tn, Tp) and Nn = 1/ B(T0, T0, Tn)
			*/
			virtual void FillDiscountFactorAndSimulationNumeraireOnEndDate(	size_t						nth, 
																			const _STL::vector<long>	&paymentDate,// chronologically sorted 
																			double						&numeraire,
																			_STL::vector<long>			&discountFactors, 
																			int							nthAntiTheticSampling) const;


			virtual double GetDiscountAdjustment(long familyID, long date) const;

			/** Initialise the Interest Rate Path Generator with static data stored in an archive {@link sophis::tools::CSRArchive}
			 *	This is done in order to create one or several CSRInterestRateLocalPathGeneratorServer object on the server side.
			 *
			 *	@param archive is the archive storing the data needed to initialise the CSRInterestRateLocalPathGeneratorServer
			 */
 			 virtual void	SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Initialise the CSRInterestRateLocalPathGeneratorServer with the market dependent data stored in an archive {@link sophis::tools::CSRArchive}
			*	
			*	This is done in order to create one or several Interest Rate Path Generator object on the server side.
			*	@param archive is the archive storing the data needed to initialise the CSRInterestRateLocalPathGeneratorServer
			*/
 			 virtual void	SetData(const sophis::tools::CSRArchive& archive);

			/** Clone for this object. Used for prototypal construction of the object, don't implement this method in any child class.
			*/
			virtual CSRInterestRateLocalPathGeneratorServer* Clone() const;

			/**	Static method allowing access to instance of class inherited from CSRLocalPathGeneratorServer for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRInterestRateLocalPathGeneratorServer, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();


			inline int GetInterestRateNormalLawSize() const {return fInterestRateNormalLawSize;};

			
			/**
			*	Set the greatest zero coupon date needed by the payoff. When using stochastic interest rate, 
			*	 yield curve must only be simulated up to this date.
			*/
			inline void SetYieldCurveUpperBoundary(long yieldCurveUpperBoundary) {fYieldCurveUpperBoundary = yieldCurveUpperBoundary;};

		protected:
			long fYieldCurveUpperBoundary;
			mutable _STL::map<long, sophis::math::CSRYieldCurveInterface*> fInitialYieldCurve;
			const CSRLocalPathGeneratorServer* fPathGenerator;
			int fInterestRateNormalLawSize;

		};


		/** Interface for a class storing Monte Carlo paths of the underlyings needed to compute the derivatives payoff.
		*	
		*/
		class SOPHIS_MONTECARLO_SERVER CSRLocalPath
		{
		public:
			/** Constructor.
			*
			*	@param	pathGenerator is the CSRLocalPathGeneratorServer which will generate Monte Carlo simulation.
			*	@param	underlyingForPayoffCount is the number of underlying asked by payoff in the Monte Carlo Simulation.
			*	@param	timeCount is the number of step in the diffusion of underlyings.
			*	@param	antitheticSamplingCount is the number of antithetic sampling used in the pricing.
			*/
			CSRLocalPath(	const CSRLocalPathGeneratorServer	&pathGenerator, 
							int									underlyingForPayoffCount,
							int									timeCount, 
							int									antitheticSamplingCount);

			/** Destructor.
			*/
			virtual ~CSRLocalPath();

			/** Give the spot of an underlying in the Monte Carlo sampling corresponding to a given date and a given antithetic sampling.
			*
			*	@param	nthUnderlyingForPayoff is the number ID for the underlying asked by payoff.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the simulates spot value of an underlying for payoff in the Monte Carlo sampling. By default return the spot when nthDate is equal to -1;
			*/
			double GetSamplingValue(int nthUnderlyingForPayoff, int nthdate, int nthAntitheticSampling) const;

			/** Set the spot of an underlying in the Monte Carlo sampling corresponding to a given date and a given antithetic sampling.
			*
			*	@param	nthUnderlyingForPayoff is the number ID for the underlying asked by payoff.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*	@param	value is the spot value.
			*/
			void SetSamplingValue(int nthUnderlyingForPayoff, int nthdate, int nthAntitheticSampling, double value) const;

			/** Give the spot of an underlying in the Monte Carlo sampling corresponding to a given date and
			*	a given antithetic sampling.
			*
			*	@param	nthUnderlyingForPayoff is the number ID for the underlying asked by payoff.
			*	@param	date is the absolute date.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the spot of an underlying for payoff in the Monte Carlo sampling.
			*/
			double GetSamplingValueFromDate(int nthUnderlyingForPayoff, long date, int nthAntitheticSampling) const;

			const sophis::math::CSRYieldCurveInterface* GetYieldCurve(long startDate, int antitheticSampling, long familyID = -1) const;


			/** Gives the discrete numeraire at a simulation date, which is 1 euro capitalized discretely between each 
			*	simulation date.
			*
			*	@param simulationDateIndex is the date at which the numeraire is requested
			*	@return 1/[ prod_i=0^i=n-1 P(Ti, Ti, Ti+1) ]
			*	
			*	Default implementation is Nn = 1/ B(T0, T0, Tn)
			*/
			double GetNumeraire(size_t	simulationDateIndex,
								int		nthAntiTheticSampling) const;

			/** After fixingDateIndex, make all interest rates realize at their forward values 
			*	during the Monte Carlo simulation.
			*
			*	@param fixingDateIndex date after which the interest rates fix at their forward prices.
			*	
			*/
			inline void ForwardFreeze(int fixingDateIndex);
			inline void ForwardRelease(); // inverse of ForwardFreeze

			/** Give the forward price of an underlying at a given date.
			*
			*	@param	nthUnderlying is the number ID for the underlying for payoff. 
			*	@param	nthDate	is the number ID for the date.
			*
			*	@return the forward price.
			*/
			inline double GetForwardPrice(int nthUnderlyingForPayoff, int nthdate) {return fPathGenerator.GetForwardPrice(nthUnderlyingForPayoff, nthdate);};

			/** Give the spot price of an underlying for payoff.
			*
			*	@param	nthUnderlying is the number ID for the underlying for payoff. 
			*
			*	@return the spot price of an underlying for payoff.
			*/
			double GetSpot(int nthUnderlying) const;

			/** Set the spot price of an underlying for payoff.
			*
			*	@param	nthUnderlying is the number ID for the underlying for payoff. 
			*	@param spot is the spot price of an underlying for payoff.
			*/
			void SetSpot(int nthUnderlying, double spot);

			/**	Give the market dependent information like discount factors for the pricing corresponding to a given date.
			*	The first stored are discount factor, other one can have been stored by user.	
			*
			*	@param	nthInfo is the number ID for the market data dependent info.
			*
			*	@return the nth market data dependent info.
			*/
			inline double GetMarketDataDependentInfo(int nthInfo) const {return fPathGenerator.GetMarketDataDependentInfo()[nthInfo];};

			/** Give the number of underlyings needed to compute payoff.
			*
			*	@return the number of underlyings needed to compute payoff.
			*/
			inline int GetUnderlyingForPayoffCount() const {return fUnderlyingForPayoffCount;};

			/** Give the number of step in the diffused path.
			*
			*	@return the number of step in the diffused path.
			*/
			inline int GetTimeCount() const {return fTimeCount;};

			/** Give the number of antithetic sampling associated to a Monte Carlo Sampling stored in the path.
			*
			*	@return the number of antithetic sampling associated to a Monte Carlo Sampling stored in the path
			*/
			inline int GetAntitheticSamplingCount() const {return fAntitheticSamplingCount;};

			/** Give the local path generator used to generate underlying's paths.
			*
			*	@return a reference on the path generator.
			*/
			inline const CSRLocalPathGeneratorServer & GetLocalPathGenerator() const {return fPathGenerator;};
			
			/** internal. Method called when initializing path in order to force computation of spot
			*	according to the current task.
			*/
			inline	void ForceSpotForPayoffToBeSettled() const {fSpotForPayoffSettled = false;};

			/** Give the coefficients NMU b of an underlying in the Monte Carlo sampling corresponding to a given date and a given antithetic sampling.
			*
			*	@param	nthUnderlyingForPayoff is the number ID for the underlying asked by payoff.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*
			*	@return the coefficients NMU b of an underlying for payoff in the Monte Carlo sampling.
			*/
			double GetNMUb(int nthUnderlyingForPayoff, int nthdate, int nthAntitheticSampling) const;

			/** Set the coefficients NMU b of an underlying in the Monte Carlo sampling corresponding to a given date and a given antithetic sampling.
			*
			*	@param	nthUnderlyingForPayoff is the number ID for the underlying asked by payoff.
			*	@param	nthDate	is the number ID for the date. This id is the one in path generator time grid.
			*	@param	nthAntitheticSampling is the number ID for the antithetic sampling.
			*	@param	value is the coefficients NMU b value.
			*/
			void SetNMUb(int nthUnderlyingForPayoff, int nthdate, int nthAntitheticSampling, double value) const;

			/** Return true if coefficients NMU b for underlying for payoff are stored, false otherwise.
			*/
			inline bool IsNMUbStored() const {return fNMUbStored;};

			/** Get the number of simulated credit defaults
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@since 6.0
			*/
			int GetDefaultCount(int nthAntitheticSampling) const;

			/** Set the number of simulated credit defaults
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@param value is the number of defaults to be set.
			@since 6.0
			*/
			void SetDefaultCount(int nthAntitheticSampling, int value);

			/** Get the date of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@since 6.0
			*/
			long GetDefaultDate(int nthDefault, int nthAntitheticSampling) const;

			/** Set the date of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@param value is the date to be set.
			@since 6.0
			*/
			void SetDefaultDate(int nthDefault, int nthAntitheticSampling, long value);

			/** Get the underlying code of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@since 6.0
			*/
			long GetDefaultUnderlying(int nthDefault, int nthAntitheticSampling) const;

			/** Set the underlying code of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@param value is the code to be set.
			@since 6.0
			*/
			void SetDefaultUnderlying(int nthDefault, int nthAntitheticSampling, long value);

			/** Get the loss of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@since 6.0
			*/
			double GetDefaultLoss(int nthDefault, int nthAntitheticSampling) const;

			/** Set the loss of the nth simulated default
			@param nthDefault is the default ID for this sample.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@param value is the loss to be set.
			@since 6.0
			*/
			void SetDefaultLoss(int nthDefault, int nthAntitheticSampling, double value);

			/** Get the weight of the sample, for importance sampling. 1 by default.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@since 6.0
			*/
			double GetWeight(int nthAntitheticSampling) const;

			/** Set the  weight of the sample, for importance sampling. 1 by default.
			@param nthAntitheticSampling is the number ID for the antithetic sampling.
			@param value is the weight to be set.
			@since 6.0
			*/
			void SetWeight(int nthAntitheticSampling, double value);

		protected :

			/** Internal. Optimization flag used to know if spot are settled according to the task.
			*/
			mutable bool fSpotForPayoffSettled;

			/**  Vector storing spot of underlying for payoff. 
			*/
			mutable _STL::vector<double> fSpotForPayoff;

			/** Vector storing path of underlying for payoff. Indexed so that nthUnderlying, nthdate, nthAntitheticSampling 
			*	correspond to fPath[(nthAntitheticSampling*fUnderlyingForPayoffCount+nthUnderlying)*fTimeCount+nthdate].
			*/
			mutable _STL::vector<double> fPathForPayoff;

			/** Boolean to know if coefficients NMU b for underlying for payoff are stored.
			*	It is useful for managing barrier with cash dividends when "cash volatility on"
			*	preference is true: in this case we force the date before ex-div date to be in 
			*	path generator time grid and NMUb coefficient must be removed from simulated spot 
			*	before one step diffusion.
			*/
			bool fNMUbStored;
			
			/** Vector storing NMU coefficient b for payoff. Indexed so that nthUnderlying, nthdate, nthAntitheticSampling 
			*	correspond to fPath[(nthAntitheticSampling*fUnderlyingForPayoffCount+nthUnderlying)*fTimeCount+nthdate].
			*/
			mutable _STL::vector<double> fNMUbForPayoff;


			/**
			 * Callback reference on  on the CSRLocalPathGeneratorServer used to generate this path
			 */
			const CSRLocalPathGeneratorServer & fPathGenerator;

			/** fUnderlyingForPayoffCount is the number of underlying in the local path.
			*	These underlying are those asked by payoff.
			*/
			int		fUnderlyingForPayoffCount;
			
			/** fTimeCount is the number of step in the diffusion of underlyings.
			*	Corresponding time are those used by path genereator.
			*/
			int		fTimeCount;

			/** fAntitheticSamplingCount is the number of antithetic sampling used in the pricing.
			*/
			int		fAntitheticSamplingCount;

			/** Vector storing default count
			*/
			_STL::vector<int>					fDefaultCount;

			/** Vector storing default dates
			*/
			_STL::vector<_STL::vector<long> >	fDefaultDate;

			/** Vector storing default underlyings
			*/
			_STL::vector<_STL::vector<long> >	fDefaultUnderlying;

			/** Vector storing default losses
			*/
			_STL::vector<_STL::vector<double> >	fDefaultLoss;

			/** Vector storing weights, for importance sampling
			*/
			_STL::vector<double>				fWeight;

			public :// DEPRECATED METHODS

				/**	 Assignment operator between two CSRLocalPath.
				*/
				//virtual CSRLocalPath& operator= (const CSRLocalPath & source) {return *this;};

				/** 
				* @deprecated since 5.3.0 use correlation object
				*/
				//virtual void SetCholeskyMatrix(boost::numeric::ublas::matrix<double> * choleskyMatrix) {};

				/** Multiply a point of an Underlying path by a constant. 	
				*	@param	nthUnderlying is the ID number of the underlying we want to modify.
				*	@param	nthTime is the point we want to modify.
				*	@param	constant is the value by which we multiply the point on the path.	
				*	
				*	@deprecated Signature change in 5.3.0
				*/
				//virtual void MultiplyByConstant(int		nthUnderlying, 
				//								int		nthTime, 
				//								double	constant) = 0;

				/** Multiply all points of an Underlying path by a constant. 	
				*	@param	nthUnderlying is the ID number of the underlying we want to modify.
				*	@param	constant is the value by which we multiply all points on the path.
				*	
				*	@deprecated Signature change in 5.3.0
				*/
				//virtual void MultiplyByConstant(int nthUnderlying, double constant) = 0;

				/** Set actualization factors needed to compute actualized payoff when we will compute delta 
				*	and Gamma for a given sampling path.
				*	@param mgrData is a _STL::vector<_STL::vector<double> >.It is used to
				*	set relevant market data dependant information like actualization factor. 
				*	
				*	@deprecated Signature change in 5.3.0
				*/
				// virtual void SetCurrentData(_STL::vector<double>* mgrData) = 0;

				/**	
				*	@deprecated since 5.3. now a specific object manage path generation;
				*/
				//virtual void GenerateSampling(int kthSampling) = 0;

				/** 
				*	
				*	@deprecated since 5.3;
				*	
				*/
				//virtual	double GetForwardVolatility(int nthUnderlying, int nthdate) = 0;

				/** Return a reference on the forward price of an underlying at a given date when you need to write its value.
				*	@param	nthUnderlying is the number ID for the underlying.
				*	@param	nthDate	is the number ID for the date.
				*	@deprecated since 5.3. 
				*/
				//virtual	double& GetForwardPriceForWriting(int nthUnderlying, int nthdate) = 0;

				/** Return a reference on the forward volatility of an underlying at a given date when you need to write its value.
				*	@param	nthUnderlying is the number ID for the underlying.
				*	@param	nthDate	is the number ID for the date.
				*	
				*	@deprecated since 5.3. Now volatility are part of diffusion processes.
				*/
				//virtual	double& GetForwardVolatilityForWriting(int nthUnderlying, int nthdate) =0;

				int fForwardFreezeDateIndex;

			private:
				// INTERNAL
				CSRLocalPath &	operator = (const CSRLocalPath & toSet);



		};

		/** A price together with a trajectory index. Used for control variates when the server
		*   needs to output a price vector instead of an average only. */
		struct SOPHIS_MONTECARLO_SERVER SSResultBySampling
		{
			SSResultBySampling(int	samplingIndex = -1, double	resultValue = 0.)
			{
				this->samplingIndex	= samplingIndex;
				result				= resultValue;
			}
			int		samplingIndex;
			double	result;
		};
		/** Outputs object are interface Buffer class correspond to the output of a payoff.
		*	It Got 2 main type of method :
		*		- On the server side : the Set... method take the last result of a computation done by the CSRServerPayoff object
		*		  in a temporary buffer and store it in a global buffer.
		*		- On the client side : the calculate... methods compute a price or a greek from the result stored in the buffer CSRClientOutput.
		*/

		/** CSRServerOutput : buffer object storing computation results on the server side.
		*/
		class	SOPHIS_MONTECARLO_SERVER CSRServerOutput
		{
		public :
			DECLARATION_SERVER_OUTPUT(CSRServerOutput);
			/** Default constructor
			*/
			CSRServerOutput();

			/**	Destructor 
			*/
			virtual ~CSRServerOutput();

			/** Store the result of a computation done by the CSRServerPayoff object (stored in temporary buffer)
			*	in the part of the global buffer corresponding to a task.
			*
			*	@param task is the task Id of the current computation.
			*/
			virtual void	StoreTemporaryResults(int task);

			/**  Store in an archive {@link sophis::tools::CSRArchive} the result of the Monte Carlo simulation. These data can be used to initialise
			*	another Server output {@link sophis::finance::CSRServerOutput::SetDataFromServerOutput} or a Client output {@link sophis::finance::CSRClientOutput::SetData}.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRClientOutput in order to finalise computation.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;
			
			/** Initialise the CSRServerOutput with the data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRClientOutput.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRServerOutput.
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive);

			/** Initialise the CSRServerOutput with the data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRServerOutput.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRServerOutput.
			*/
			virtual void	SetDataFromServerOutput(const sophis::tools::CSRArchive& archive);

			
			/** Add a weight to the results
			*	@param weightForRescalePrice weight for rescale the price
			*	@param weightForRescaleUV weight for rescale the matrix U and the vector V of the least square
			*	This algorithm does a number of iterations so the firsts trajectories are "wrong" and must have a small weight
			*/
			virtual void	RescaleResults(const double weightForRescalePrice, const double weightForRescaleUV);
			
			/** Add in this buffer the results stored in a source buffer.
			*
			*	@param src is a source buffer we want to add in this buffer.
			*/
			virtual void	FlushResults(const CSRServerOutput& src);

			/** Add in this buffer the results stored in a CSRArchive.
			*
			*	@param archive is a CSRArchive storing the source buffer we want to add in this buffer.
			*/
			virtual void	FlushResults(const sophis::tools::CSRArchive& archive);

			/** Reset the buffers.
			*/
			virtual void	Refresh();

			/** Accessors to the temporary Buffer in which the server payoff store results of its current computation.
			*
			*	@return a reference on the temporary buffer.
			*/
			virtual _STL::vector<double>& GetTemporaryBufferElement() {return fTemporaryBuffer;};

			bool fIsAmerican;

#ifndef GCC_XML
			_STL::vector<_STL::vector<sophis::math::MatrixD> >& GetULeastSquare() {return fULeastSquare;};

			_STL::vector<_STL::vector<sophis::math::VectorD> >& GetVLeastSquare() {return fVLeastSquare;};
#endif // GCC_XML

			/** Give the size of the temporary buffer.
			*
			*	@return the size of the temporary buffer.
			*/
			virtual int		 GetTemporaryBufferSize() const;

			/** Give the registered name of this server computation object.
			*
			*	@return the registered name of this server computation object.
			*/
			virtual _STL::string GetServerOutputID() const;

			/** Set  the number of price computed in Monte Carlo simulation.
			*/
			virtual void SetTaskSize(int taskSize);
			inline int GetTaskSize(){return fTaskSize;}
			virtual void SetTaskId(int id) { fTaskId = id;  }
			virtual int GetTaskId() { return fTaskId;}

			inline void SetCurrentSamplingIndex(int currentSamplingIndex) { fCurrentSamplingIndex = currentSamplingIndex;  };
			inline int GetCurrentSamplingIndex() { return fCurrentSamplingIndex;};

			/** Accessors to the global Buffer in which the server payoff store aggregated results.
			*
			*	@return a constant reference on the global buffer.
			*/
			virtual const _STL::vector<double>& GetGlobalBuffer() const {return fResultsBuffer;};


			void SetForwardAtMaturity(int nthUnderlying, double samplingValue);

			void ClearControlVariatesServerOutput();

			inline _STL::vector<CSRServerOutput*>	&	GetCVServerOutput() {return fCVServerOutput;};

		protected:

			_STL::vector<CSRServerOutput*>		fCVServerOutput;

			bool fMustStoreResultsBySampling;
			_STL::vector<SSResultBySampling> fResultBySampling;
			/** Number of price computed in Monte Carlo simulation. The first one is the theoretical price. Other ones are for greeks.
			*/
			int		fTaskSize;
			int		fTaskId;
			int		fCurrentSamplingIndex;

			/** Size of temporary buffer. This is the greater between fSizeForBasicPrice and fSizeForGreeks;
			*/
			int		fTemporaryBufferSize;

			/** Size of temporary buffer. This is the on in which {@link sophis::finance::CSRServerPayoff} write computation results.
			*/
			_STL::vector<double> fTemporaryBuffer;
	
			/** fBufferSize		= fSizeForBasicPrice + (fTaskSize-1)*fSizeForGreeks;
			*/
			int		fBufferSize;

			/** Just compute and initialise member fBufferSize.
				fBufferSize		= fSizeForBasicPrice + (fTaskSize-1)*fSizeForGreeks;
			*/
			void InitializeBufferSize();

			/** Size of temporary buffer. This is the on in which {@link sophis::finance::CSRServerPayoff} write computation results.
			*/
			_STL::vector<double> fResultsBuffer;

			/** This is the result of the last theoretical price computation (identified by task == 0). It is used
			*	for greeks evaluation to compute differences path by path and summing these differences to compute greeks.
			*/
			_STL::vector<double> fBasicSampleResults;
			
			/** Number of indicator computed for theoretical price computation. 
			*/
			int		fSizeForBasicPrice;

			/** Number of indicator computed for greeks computation.
			*/
			int		fSizeForGreeks;

			/** Number of indicator computed for greeks computation which must be computed as difference from theoretical price results
			*	in order to minimize roundoff error. Must be less or equal to {@linf fSizeForGreeks}.
			*/
			int		fIndicatorSizeForDifferences;

			/** After computation give the real number of sampling computed.
			*/
			int fSamplingCount;

			/** After computation give the real number of sampling computed, may be weighted in case of american monte carlo.
			*/
			double  fWeightedSamplingCount;

			/** After computation give the real number of sampling computed, may be weighted in case of american monte carlo.
			*/
			double  fSquareWeightedSamplingCount;


			bool fComputeStandardDeviation;
			int fInternalBufferSize;
			_STL::vector<double> fInternalBuffer;

#ifndef GCC_XML
			mutable  _STL::vector<_STL::vector<sophis::math::MatrixD> >		fULeastSquare;
			mutable _STL::vector<_STL::vector<sophis::math::VectorD> >		fVLeastSquare;
#endif // GCC_XML

#ifndef GCC_XML
		public:
			inline CSRGenericIndicatorServer & GetGenericIndicatorServer() const {return fGenericIndicatorServer;};
		protected:
			mutable CSRGenericIndicatorServer fGenericIndicatorServer;
#endif // GCC_XML

		public:
			/**	Static method allowing access to instance of class inherited from CSRServerOutput for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRServerOutput, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

		public : // DEPRECATED METHODS
			/** 
			*	@deprecated since 5.3.0
			*/
			virtual void	SetEpsilon(int which)	{};

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual void	SetDeltaGamma(int which, double weight )	{};

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual void	SetGamma(int j, int k, double weight)		{};

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual void	SetRhoConvexity(int which, double weight)	{};
		};

#ifndef GCC_XML
		/** Class CSRRegressionFunction handle the regression function with the base functions
		*/ 
		class SOPHIS_MONTECARLO_SERVER CSRRegressionFunction
		{
		public:
			/** Default constructor
			*/
			CSRRegressionFunction();

			/**	Destructor 
			*/
			virtual ~CSRRegressionFunction();

			/** Get the value of the regression function for a given spot value X.
			*	@param iBlock is the number of block
			*	@param iBaseFunction is the number of base function that are needed for the regression
			*	@param iFunction is the number of base function that are needed for the regression
			*	@param X is the the spot values
			*	@return the value of the regression function evaluated at X, for a given block and for a given base function.
			*/			

			virtual double Value(int iBlock, int iBaseFunction, sophis::math::VectorD const & X) const = 0;

		protected:
			mutable int 																	fParamCount;
			mutable	_STL::vector<int>														fBlockSize;
			mutable _STL::vector<int>														fBaseFuncSize;
			mutable _STL::vector<_STL::shared_ptr<sophis::math::FonctionMultiParam> >		fBaseFunctions;
		};

		class SOPHIS_MONTECARLO_SERVER CSRPolynomials : public CSRRegressionFunction
		{
		public:
			/** Default constructor
			*/
			CSRPolynomials();

			/**	Destructor 
			*/
			virtual ~CSRPolynomials();

			/** Get the value of the regression function for a given spot value X.
			*	@param iBlock is the number of block
			*	@param iBaseFunction is the number of base function that are needed for the regression
			*	@param X is the the spot values
			*	@return the value of the regression function evaluated at X, for a given block and for a given base function.
			*/			
			double Value(int iBlock, int iBaseFunction, sophis::math::VectorD const & X) const;
			void Init(	int const				& nbUnderlings,
						int const				& nbVolatilities,
						int const				& nbRgressionVariables,
						_STL::vector<int> const & blockSize,
						_STL::vector<int> const & baseFuncSize);
		};

		/** Class CSRRegressionServer handle the regression used in the American Monte Carlo
		*	on the server side.
		*	-	fill the matrix U and the vector V and sent them to the client class
		*	-	computing the regression value using the base functions and the coefficients 
		*		given by the client class. 
		*/ 
		class	SOPHIS_MONTECARLO_SERVER CSRRegressionServer
		{
		public :
			DECLARATION_REGRESSION_SERVER(CSRRegressionServer);
			/** Default constructor
			*/
			CSRRegressionServer();

			/**	Destructor 
			*/
			virtual ~CSRRegressionServer();

			/** Get intermediate data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRRegressionClient.
			*	Those data are the coefficients which are the result of the LS Method computed on the client side.
			*
			*	@param archive is the intermediate archive storing the data from the client side.
			*/
			virtual void	SetIntermediateData(const sophis::tools::CSRArchive& archive);

			_STL::string GetRegressionServerID() const;

			/** Initialise the CSRRegressionServer with the data stored in an archive {@link sophis::tools::CSRArchive} created by a CSRRegressionClient.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRRegressionServer.
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive);					

			/** Get the number of the current iteration
			*/
			int Iteration();
			
			/** Get the coefficients  which are the result of the least square method 
			*	for a task and a bloc number.
			*/
			sophis::math::VectorD & Coeff(const int block);

			/** Get the number of regression variables			
			*/
			virtual int & NbRegressionVariables();

			/** Get the number of dates per block in a vector			
			*/
			virtual _STL::vector<int> & BlockSize();

			/**	Get the number of Base Functions for each block in a vector
			*/
			virtual _STL::vector<int> & BaseFuncSize();

			/** Get the boundary
			*	for all tasks and all bloc number.
			*/
			_STL::vector<sophis::math::VectorD> & Boundary();

			/** Get the base functions for the regression
			*/
			virtual	_STL::shared_ptr<CSRRegressionFunction> & Regressionfunction();

			/** Get the Matrix of the regression function evaluated on X
			*	for a task and a bloc number.
			*/
			sophis::math::MatrixD & RegressionFunc(const int block);

			/** Get the Matrix of the regression values evaluated on X
			*	for a task and a bloc number.
			*/
			sophis::math::VectorD & RegressedValues(const int block);

			/** Set the number of task (global task to compute)
			*
			*	@param		nbTask is the number of task
			*/

			virtual void	SetNbTasks(const int nbTasks);

			/** Set the current task
			*
			*	@param		iTask is the number of task
			*/
			virtual void	SetCurrentTask(const int task);

			/** Set the vector X for each block and fill the matrix of the regression function for each block
			*
			*	@param		X[i] is the underlying values (X1, ..., Xn) and this for all bloc dates.
			*/
			virtual void	SetXAndComputefX(_STL::vector<sophis::math::VectorD> const & X);


			/** Summing the Matrix U and the Vector V needed for the least square method.
			*
			*	@param		X[i] is the underlying values (X1, ..., Xn) and this for all bloc dates.
			*	@param		Y[i] is the sum of each base function computed at state X multiplied by the coefficient. 
			*				It's the regression value. This is computed for all bloc dates.
			*/
			virtual void	FillUandVLeastSquare(	sophis::math::VectorD const & Y, 
													sophis::math::VectorD const & weight,
													int task,
													_STL::vector<_STL::vector<sophis::math::MatrixD> >	&	uLeastSquare,
													_STL::vector<_STL::vector<sophis::math::VectorD> >	&	vLeastSquare);

			/** Give the regression value computed thanks to the least square method using the bases functions.
			*
			*	@param		X[i] is the underlying values (X1, ..., Xn) and this for all bloc dates.
			*	@param		Y[i] is the sum of each base function computed at state X multiplied by the coefficient. 
			*				It's the regression value. This is computed for all bloc dates. It is the output.
			*/
			virtual void	ComputeRegressionValues(sophis::math::VectorD & Y);

			/** Initialization
			* Initialize the matrix U and the vector V of the least square method
			*/

			virtual void	Init();
			
		protected:

			/** The result of the Least Square Method: U * Coefficient = V.
			*/
			_STL::vector<_STL::vector<sophis::math::VectorD> >						fCoeff;

			/** The boundary : the choice to continue or to stop
			*/
			_STL::vector<sophis::math::VectorD>										fBoundary;

			/** Regression Function
			*/
			_STL::shared_ptr<CSRRegressionFunction>									fRegressionFunction;			

			/**  The paths : The underlying spots and the time, for each time, for each task
			*/
			_STL::vector< _STL::vector< _STL::vector<sophis::math::VectorD> > >		fX;

			/**  The Regressed values for each block, for each task
			*/
			_STL::vector<_STL::vector<sophis::math::VectorD> >						fYRegressedValues;

			/**  Regression Function in a matrix evaluated for each bloc for each task
			*/
			_STL::vector<_STL::vector<sophis::math::MatrixD> >						fRegressionFunc;

			/**  Number of task that we are working at
			*/
			int																		fTask;	

			/**  Number of tasks in global
			*/
			int																		fNbTasks;		

			
			/** Number of regression Values. It corresponds to the size of X 
			*	where X is defined such as f(X) = E[Y|X]
			*/
			int																		fNbRegressionVariables;

			/**  Number of blocks (usually blocks of dates)
			*/
			int																		fNbBlocks;

			/** Number of functions per Bloc (number of points per bloc)
			*/
			_STL::vector<int>														fBlockSize;

			/** Number of base functions of regression (number of points per bloc)
			*/
			_STL::vector<int>														fBaseFuncSize;

			mutable int																fIteration; // Current iteration
			bool																	fInitialized;
		public:
			/**	Static method allowing access to instance of class inherited from CSRServerOutput for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRRegressionServer, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

		};
#endif // GCC_XML

/**
*	Structure
*
*/	
		struct SOPHIS_MONTECARLO_SERVER SSServerPayoffMarketDependentData
		{
		public:
			SSServerPayoffMarketDependentData();
			virtual ~SSServerPayoffMarketDependentData();


			/** 
			It is used to compute the present value of a settlement at time {@link GetNthPaymentDate} from the simulated forward price.
			When there are Np payment dates, the i-th underlying simulated spot value at the j-th payment 
			date is Sj then the(i*Np+j)-th element of the vector contains the NMU coefficient a so that a * Sj + b is the
			present value of the physical settlement at that time.
			*/
			_STL::vector<double> fSpotToPhysica;

			/** 
			It is used to compute the present value of a settlement at time {@link GetNthPaymentDate} from the simulated forward price.
			When there are Np payment dates, the i-th underlying simulated spot value at the j-th payment 
			date is Sj then the(i*Np+j)-th element of the vector contains the NMU coefficient b so that a * Sj + b is the
			present value of the physical settlement at that time.
			*/
			_STL::vector<double> fSpotToPhysicb;
		};
		
		/** Class CSRServerPayoff computing payoff for a given underlying path.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRServerPayoff
		{
		public:
			/**	Default constructor
			*/
			CSRServerPayoff();

			/**	Destructor
			*/
			virtual ~CSRServerPayoff();

			/** Compute the option payoff associated with the underlying path and fill a temporary buffer in CSRServerOutput abject. 
			*
			* @param path is an input parameter corresponding to the underlying paths which are used to compute payoff
			* @param output is an output buffer corresponding in which we write result of a payoff computation.
			*/
			 virtual void operator() (const CSRLocalPath * path, CSRServerOutput * output) const;

			/** Say if the payoff computation is thread safe.
			*
			*	Note : the returned value only affects local threads. A non-threadsafe CSRServerPayoff can be used
			*	with calculation servers.
			*	By default, return true.
			*
			*	@return true if the payoff computation is thread safe, false otherwise.
			*/
			 virtual bool	IsThreadSafe() const;

			 /** Give the number of underlying needed by CSRServerPayoff object in order to compute payoff.
			 *
			 *	@return the number of underlying needed by CSRServerPayoff object in order to compute payoff.
			*/
			 virtual int	GetUnderlyingForPayoffCount() const;

			 /** Return the number of uniform law needed for the pricing (other than those needed for normal law computation). Return 0 in default implementation.
			 *	@deprecated since 5.3.0 
			 *	Supplementary uniform law are managed by class {@link CSRPathGenerator}.
			 */
			 virtual int	GetUniformLawCount()		const;

			 /** Give the number of antithetic sampling used for pricing;
			 *	1 if no antithetic sampling is used (Default implementation)
			 *  2 for a basic one dimension antithetic sampling
			 *	and so on.
			 *	Note that while architecture allowing more than 1 antithetic sampling to be used 
			 *	there is only implementation for useful case 1 an 2. 
			 *
			 *	@param pathGenerator is a pointer on the path generator used in order to know 
			 *	if using antithetic sampling is relevant for this generator.
			 *
			 * @return the number of antithetic sampling used for pricing;
			 */
			 virtual int GetAntitheticSamplingCount(const CSRLocalPathGeneratorServer & pathGenerator) const;

			 /** Factory for creation of a {@link CSRLocalPath} object. Since 5.3.0 there no trivial reason to overload it.
			 *	
			 *	@param pathGenerator is the CSRLocalPathGeneratorServer which will be used to generate path.
			 *
			 *	@return a pointer on the CSRLocalPath object created.
			 */
			 virtual CSRLocalPath*	new_CSRLocalPath(const CSRLocalPathGeneratorServer & pathGenerator) const;

			 /** Initialise the CSRServerPayoff with static data stored in an archive {@link sophis::tools::CSRArchive}
			 *	This is done in order to create one or several payoff object on the server side.
			 *
			 *	@param archive is the archive storing the data needed to initialise the CSRServerPayoff
			 */
 			 virtual void	SetStaticData(const sophis::tools::CSRArchive& archive, const CSRLocalPathGeneratorServer* pgs);

			/** Initialise the CSRServerPayoff with the market dependent data stored in an archive {@link sophis::tools::CSRArchive}
			*	
			*	This is done in order to create one or several payoff object on the server side.
			*	@param archive is the archive storing the data needed to initialise the CSRServerPayoff
			*/
		 
 			 virtual void	SetData(const sophis::tools::CSRArchive& archive);

			/** Give the number of fixing dates needed by CSRServerPayoff to compute payoff.
			*
			* @return  the number of fixing dates needed by CSRServerPayoff to compute payoff.
			*/
			 virtual int	GetDateCountForPayoff()	const;

			 /** Return the ith  Give the number of fixing dates needed by CSRServerPayoff to compute payoff.
			 *
			 *	@param i is an index between 0 (included) and GetDateCountForPayoff() (excluded) corresponding to the ith fixing date.
			 *
			 *	@return the ith fixing dates (absolute date) {@link about_date}.
			 */
			 virtual long	GetNthDateForPayoff(int i) const;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			 virtual CSRServerPayoff* Clone() const = 0;

			 /** Return a STL string filled with the ID of the uniform Random generator used for the Monte Carlo simulation.
			*
			*	@deprecated since 5.3.0
			*/
			// const _STL::string & GetGeneratorID() const;

			 /**	This method is called after CSRServerPayoff and CSRLocalPathGeneratorServer have been initialized 
			 *		in order to allow optimisation during payoff computation. Default implementation optimisation is to 
			 *		store in {@link fIndexMapping } the index in time grid of path generator corresponding to fixing dates 
			 *		needed by CSRServerPayoff to compute payoff in order to allow call to {@link CSRLocalPath::GetSamplingValue}
			 *		instead of {@link CSRLocalPath::GetSamplingValue} during payoff computation.
			 *		
			 *	@param pathGenerator is the CSRLocalPathGeneratorServer which will be used to generate path.
			 */
			 virtual void	FillOptimisation(const CSRLocalPathGeneratorServer& pathGenerator);

			 /**	To optimize, fill the dates where discount factors will have to computed.
			 *	@param toFill : fixing date -> maturity dates
			 */
			 virtual void	FillDiscountFactorDates(/*out*/ _STL::map<long, _STL::set<long> >& toFill) const;

			 inline int		GetPaymentCount() const {return fPaymentCount;};
			 
			 inline long	GetNthPaymentDate(int nth) const {return fPaymentDateVector[nth];};
			 inline long	GetNthPaymentFixingDate(int nth) const {return fPaymentFixingDateVector[nth];};

			 inline long	GetLastPaymentdate() const {return fLastPaymentdate;};
			 
			 /** Return the notional of the option. Used for clause (e.g. on forex) compute on absolute underlying level & absolute amount instead of underlying performance & percentage of notional
			 * @since version 7.1.2
			 */
			 inline double	GetNotional() const {return fNotional;};
			 inline void	SetNotional(double notional) {fNotional  = notional;};
#ifndef GCC_XML
			 virtual void	GetDataForRegression(	int										& nbRegressionVariables,
													_STL::vector<int>						& blockSize,
													_STL::vector<int>						& baseFuncSize,
													_STL::shared_ptr<CSRRegressionFunction>	& regressionFunction) const;

			 CSRRegressionServer* & GetRegressionServer()const {return fRegressionServer;}
			 void SetRegressionServer(CSRRegressionServer* regressionServer) const {fRegressionServer = regressionServer;}
#endif // GCC_XML

			 void ClearControlPayoff();

			 _STL::vector<CSRServerPayoff*>&  GetControlVariateServerPayoff() const {return fCVServerPayoff;};

			 virtual void	SetGlobalData(void* globalDataToFill);
			 virtual void*	new_GlobalData(const sophis::tools::CSRArchive& globalDataArchive) const;

			/**
			*	Return the market dependent data structure created by method {@link new_SSServerPayoffMarketDependentData}
			*/
			 SSServerPayoffMarketDependentData& GetMarketDependentData() const;

			 void ClearMarketDependentData();


			 /**	Internal. Method to set current task ID. It also set the relevant current computation date.
			 *	
			 *	@param currentTask is the task number.
			 */
			 void SetCurrentTask(int currentTask);
			 int  GetCurrentTask() const{return fCurrentTask;};

			 virtual void ComputePayoffVector(CSRLocalPath* path, int nthAntithetic, _STL::vector< double > & payoffVector) const;

			/**
			* @return the greatest zero coupon date needed by the payoff. When using stochastic interest rate, yield curve will only be simulated up to this date.
			*/
			 inline long GetYieldCurveUpperBoundary() const {return fYieldCurveUpperBoundary;};


	public:
			struct  SSMCPaymentCurrency
			{
				long	currency;
				int	fxIndex; // -1 for option currency (useful when
			};

			/** Returns the set of cashFlow currencies  .
			*/
			inline const _STL::vector<CSRServerPayoff::SSMCPaymentCurrency>& GetCashFlowCurrencyData() const { return fCashFlowCurrencyData;};

		protected :

			/**  Internal. The foreign currency list for which we must discount cashflow.
			*	 First one is option currency
			*/
			_STL::vector<CSRServerPayoff::SSMCPaymentCurrency> fCashFlowCurrencyData;


			int fCurrentTask;

			virtual SSServerPayoffMarketDependentData* new_SSServerPayoffMarketDependentData() const;
			mutable _STL::vector<SSServerPayoffMarketDependentData*> fMarketDependantData;

			mutable _STL::vector<CSRServerPayoff*> fCVServerPayoff;

#ifndef GCC_XML
			mutable CSRRegressionServer*					fRegressionServer;
#endif // GCC_XML

 			/** Number of cash flow
			 */
			int		fPaymentCount;

			/** Greatest payment date
			*/
			long fLastPaymentdate;

			/** Cash flow date vector
			*/
			_STL::vector<long> fPaymentDateVector;

			/** Cash flow fixing date vector
			*/
			_STL::vector<long> fPaymentFixingDateVector;

			_STL::vector<int> fPaymentFixingDateIndexes;
			

			/** STL Vector of relevant dates for the computation.
			*/
			_STL::vector<long>	fSimulationDatesForPayoff;

			/** Filled by {@link  FillOptimisation} this vector store  the index in time grid of path generator corresponding to fixing dates 
			*	needed by CSRServerPayoff to compute payoff.
			*/
			_STL::vector<int> fIndexMapping;

			/**  This is the application date. It can be different from computation date (theta computation,...).
			*/
			 long		fToday;

			 /**  The notional of the option.
			*/
			 double fNotional;

			/** ID of the uniform Random generator used for the Monte Carlo simulation.
			*/
			//_STL::string fGeneratorID;

			 /** Number of underlyings needed to compute payoff.
			*/
			 int		fUnderlyingForPayoffCount;

			 /** Number of antithetic sampling which can reduce payoff variance.
			 */
			 int fAntiTheticSamplingCount;

			 /** True when the settlement type of the option is different from cash, false otherwise.
			 *	@deprecated since 6.0
			 */
			 //bool fNotCashDelivery;

			 /**
			* Greatest zero coupon date needed by the payoff. When using stochastic interest rate, yield curve will only be simulated up to this date.
			*/
			 long fYieldCurveUpperBoundary;

		

		public:
			/**	Static method allowing access to instance of class inherited from CSRServerPayoff for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRServerPayoff, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

		};

//-----------------------------------------------------------------------------

		/**  Base class for algorithm handling normal law computation from independent uniform law samplings.
		*/
		class SOPHIS_MONTECARLO_SERVER CSRGaussianInvertion 
		{
		public:
			/** Initialise the CSRGaussianInvertion with static data stored in an archive {@link sophis::tools::CSRArchive}
			*	This is done in order to create the gaussian inversion object object on the server side.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRGaussianInvertion
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) {;};

			/**
			* Method computing 2 independent Gaussian random variables from 2 uniform independent random variables.
			* We use 2 variable in order to allow compatibility with Box Muller Algorithm.
			*
			*	@param uniform1 is the first uniform law in ]0, 1[.
			*	@param uniform2 is the second uniform law in ]0, 1[.
			*	@param normal1 must be filled with the first is normal law. 
			*	@param normal2 must be filled with the second is normal law. 
			*/
			virtual void ComputeGaussianVariable(double uniform1, double uniform2, double &normal1, double &normal2) const = 0;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRGaussianInvertion* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRGaussianInvertion for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRGaussianInvertion, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};

//-----------------------------------------------------------------------------

		/** Class to handle Brownian diffusion. This allow easy switch between different Brownian path construction:
		*	{@link CSRLocalPathGeneratorServer::GetFullNormalLawSize} give the number Nbrown of brownian diffusion W_t^i
		*	with i in {1,...,Nbrown} and {@link CSRLocalPathGeneratorServer::GetDateVector} give path generator time 
		*	grid {t_0, t_1, ... , t_n}.
		*	CSRLocalPathGeneratorServer implementation use n * Nbrown uncorrelated normal laws (following N(0,1)) to 
		*	generate underlying sample path. More specifically , if the euclidian division of j by Nbrown is 
		*	j = d_j * Nbrown + r_j, then the jth normal law Z_j will be used to generate the (d_j)th increment of 
		*	the (r_j)th brownian path and this increment will be :
		*	Z_j * sqrt[ d_j - d_(j-1) ]
		*	with convention d_(-1) = computation date.
		*	
		*	Risk give 2 implementations for this class. The first one do not change normal sample while second one 
		*	change them so that broanian increment are generated by usin Brownian bridge construction in order
		*	to reduce effective dimension of Monte Carlo simutation.
		*/
		class  SOPHIS_MONTECARLO_SERVER CSRBrownianPathConstruction
		{
		public:
			/** Initialise the CSRBrownianPathConstruction with static data stored in an archive {@link sophis::tools::CSRArchive}
			*	This is done in order to create the brownian path generator object on the server side.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRBrownianPathConstruction
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) {;};

			/** Initialisation from path generator. This allow to know path generator time grid {@link CSRLocalPathGeneratorServer::GetDateVector} 
			*	and the number of independent Brownian path {@link CSRLocalPathGeneratorServer::GetNormalLawSize}.
			*/
			virtual void Initialize(const CSRLocalPathGeneratorServer& pathGenerator) = 0;

			/** Method allowing modification of uncorrelated normal law.
			* 
			*	@param normalLaw is the buffer of uncorrelated normal law. We can overwrite input values with new ones
			*	in order to change Brownian path construction.
			*/
			virtual void FillBrownianPath(double * normalLaw) const = 0;

			/**  Destructor.
			*/
			virtual ~CSRBrownianPathConstruction(){};


			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRBrownianPathConstruction* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRBrownianPathConstruction for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRBrownianPathConstruction, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};

//---------------------------------------------------------------------------------------

		/** An interface class for the uniform Random Generator used for the Monte Carlo simulation.
		*	
		*/ 
		class SOPHIS_MONTECARLO_SERVER CSRUniformRandomGenerator 
		{
		public:
			/** Default constructor.
			*/
			CSRUniformRandomGenerator();

			/** Copy constructor.
			 */
			CSRUniformRandomGenerator(const CSRUniformRandomGenerator& source);

			/** Destructor.
			*/
			virtual ~CSRUniformRandomGenerator();

			/** Initialise the CSRUniformRandomGenerator with static data stored in an archive {@link sophis::tools::CSRArchive}
			*	This is done in order to create uniform random generator object on the server side.
			*
			*	@param archive is the archive storing the data needed to initialise the CSRUniformRandomGenerator
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) {;};


			/** Give the maximum number of independent dimensions that the generator can simultaneouslly generate. 
			*	Default implementation return 0, which is understood as no limit in the number of dimension.
			*
			*	@return the maximum number of independent dimensions. 
			*/
			virtual int	GetMaximalDimensionAllowed()const {return 0;};

			/** Give the dimension of the generator. 
			*
			*	@return the dimension of the generator. 
			*/
			inline int	GetTotalLawSize()const	{return fTotalLawSize;};

			/** Give the number of dimension which will be used to generate normal sampling.
			*
			*	@return the number of dimension which will be used to generate normal sampling.
			*/
			inline int	GetUniformLawForNormalSize() const {return fUniformLawForNormalSize;};

			/** Give the last generated sample of uniform law. This sample must has size equal to {@link GetTotalLawSize}
			*	and the {@link GetUniformLawForNormalSize} ones are the first used to generate supplementary uniform law 
			*	not  used to generate normal sample.
			*
			*	@return the last generated sample of uniform law.
			*/
			inline const double* GetUniformLawSample() const {return fBufferLaw;};

			/** Method to initialize generator size. it will set fTotalLawSize=normalLawSize+uniformLawCount, fUniformLawForNormalSize=normalLawSize
			*	and resize fBufferLaw then call virtual method {@link InitialiseGeneratorSize}.
			*
			*	@param normalLawSize is the number of dimension which will be used to generate normal sampling..
			*	@param uniformLawCount is the number of supplementary uniform law needed.
			*/
			void SetBufferSize(	int	normalLawSize,
								int	uniformLawCount);

			/** Give the current sampling Id (1 for the first, 2 for the second and so on). 
			* 
			*	@return the current sampling Id.
			*/
			inline int	GetCurrentSamplingID() const {return fCurrentSampling;};

			/** Method computing a uniform sample identified by one ID.
			*	This method is called  when a sampling is needed and:
			*		- do nothing if fCurrentSampling  == nthSampling,
			*		- else call {@link ComputeNextUniformSampling} if fCurrentSampling  == nthSampling-1,
			*		- else call {@link ComputeDirectlyNthUniformSampling}.
			*
			*	@param nthSampling is the ID of the sampling we want to be computed.
			*/
			void	ComputeNthUniformSampling(int nthSampling);

			/**
			* Method to set up fBufferLaw and fTotalLawSize
			*/
			virtual void RefreshBufferLaw(int totalSize = 0);

		protected :

			/** Method computing the next uniform sampling. In some algorithm like Sobol ones
			*	this method is far most efficient than directly computing the nth sampling.
			*/
			virtual void	ComputeNextUniformSampling() = 0;

			/** Method computing a uniform sample identified by one ID.
			*
			*	@param nthSampling is the ID of the sampling we want to be computed.
			*/
			virtual void	ComputeDirectlyNthUniformSampling(long nthSampling) = 0;

			/**  Virtual method to initialize generator dimension.
			*
			*	@param normalLawSize is the number of dimension which will be used to generate normal sampling..
			*	@param uniformLawCount is the number of supplementary uniform law needed.
			*/
			virtual void	InitialiseGeneratorSize(	int	normalLawSize,
														int	uniformLawCount) = 0;

			/**  Current sampling Id (1 for the first, 2 for the second and so on).
			*/
			long	fCurrentSampling;

			/** Dimension of the generator. 
			*/
			int		fTotalLawSize;

			/** Number of dimension which will be used to generate normal sampling.
			*	Must be less or equal to {@link fTotalLawSize}.
			*/
			int		fUniformLawForNormalSize;

			/** Buffer of size {@link fTotalLawSize} storing  uniform law sample generated.
			*/
			double	*fBufferLaw;

		public:

			/** Real Clone for this object. Used to create many identical random generator in multi threaded environments.
			*/
			virtual CSRUniformRandomGenerator* Copy() const = 0;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRUniformRandomGenerator* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRBrownianPathConstruction for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRUniformRandomGenerator, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};


		/** A class handling correlation between Brownian motion. 
		*/
		class SOPHIS_MONTECARLO_SERVER CSRServerCorrelation
		{
		public:
			/** Default constructor. 
			*/
			CSRServerCorrelation();

			/**	Virtual constructor;	
			*/
			virtual ~CSRServerCorrelation();

			/**	Set the path generator object which will generate underlying sampling.
			*
			*	@param pathGenerator is the CSRLocalPathGeneratorServer object which will be used for path generation.
			*/
			inline void SetPathGenerator(const CSRLocalPathGeneratorServer* pathGenerator) {
						fPathGenerator = pathGenerator;
						if(fPathGenerator)
						{
							CSRInterestRateLocalPathGeneratorServer & irPG = fPathGenerator->GetInterestRateLocalPathGeneratorServer();
							fNormalLawSizeForOneStep = fPathGenerator->GetNormalLawSizeByStep() + irPG.GetInterestRateNormalLawSize();
						}
						else
							fNormalLawSizeForOneStep = 0;
			};

			/**	Return a pointer on the path generator object which will generate underlying sampling.
			*/
			inline const CSRLocalPathGeneratorServer*  GetPathGenerator() const {return fPathGenerator;};

			/** Method called when the current step index is settled by {@link SetStepIndex} in order to optimize
			*	the research of relevant correlation parameters.
			*/
			virtual void OptimizeCurrentIndex() = 0;

			/** Set the current step index in the integration.
			*	Must be called by method {@link CSRLocalPathGeneratorServer::GenerateSampling} 
			*	in order to set the relevant correlation parameters to use when computing correlated
			*	normal law for a given step in the SDE integration.
			*
			*	@param stepIndex is the current step index in the integration.
			*/
			void	SetStepIndex(int stepIndex) const;

			/**  Give a correlated normal value for a given dimension and a given time step.
			*
			*	@param	diffusedeVariableIndex identify the dimension of the correlated normal law needed.
			*	@param  stepIndex identify the time step.
			*	@param  periodBegin is the absolute start date of the time step.
			*	@param  periodEnd is the absolute end date of the time step.
			*
			*	@return the correlated normal value.
			*/
			double GetCorrelatedNormalValue(	int		diffusedeVariableIndex, 
												double	periodBegin,
												double	periodEnd) const;

			/**  Give the correlation between two dimensions for a given time step.
			*
			*	@param	diffusedeVariableIndex1 is the first dimension.
			*	@param	diffusedeVariableIndex2 is the second dimension.
			*	@param  stepIndex identify the time step.
			*	@param  periodBegin is the absolute start date of the time step.
			*	@param  periodEnd is the absolute end date of the time step.
			*
			*	@return the correlation to apply between two dimensions for a given time step.
			*/
			virtual double GetCorrelation(	int		diffusedeVariableIndex1, 
											int		diffusedeVariableIndex2, 
											double	periodBegin,
											double	periodEnd) const =0;


			/** Initialise the CSRServerCorrelation with static data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This is done in order to create one or several correlation objects on the server side.
			*
			*	@param archive is the archive storing the static data needed to initialise the CSRLocalPathGeneratorServer
			*/
			virtual void	SetStaticData(const sophis::tools::CSRArchive& archive) {;};

			/** Initialise the CSRServerCorrelation with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRClientCorrelation::GetData}.
			*
			*	@param archive is the archive storing the data needed for volatility model initialisation.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive) = 0;

		protected:

			/** Give the normal law vector to use for compuuting correlated normal law for the current step.
			*/
			const double* CSRServerCorrelation::GiveUnCorrelatedNormalLaw() const;

			/**  Compute a correlated normal value for a given dimension and a given time step from a vector of uncorrelated normal values.
			*
			*	@param	diffusedeVariableIndex identify the dimension of the correlated normal law needed.
			*	@param  stepIndex identify the time step.
			*	@param  periodBegin is the absolute start date of the time step.
			*	@param  periodEnd is the absolute end date of the time step.
			*	@param  uncorrelatedNormalLaw is a normal sample vector (first value pointed is the first relevant dimension for the time step asked).
			*
			*	@return the correlated normal value.
			*/
			virtual  double GetCorrelatedNormalValue(	int				diffusedeVariableIndex, 
														double			periodBegin,
														double			periodEnd,
														const double	*uncorrelatedNormalLaw) const = 0;

			/** CSRLocalPathGeneratorServer object which will be used for path generation.
			*/
			const CSRLocalPathGeneratorServer* fPathGenerator;

			/** Current step index in the integration.
			*/
			mutable int fStepIndex;

			/** Current step index for the law used in the integration.
			*/
			//mutable int fLawStepIndex;

			int fNormalLawSizeForOneStep;

		public:
			
			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRServerCorrelation* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRDiffusionParameter for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRServerCorrelation, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};
	

	}	//namespace finance
}//		 namespace sophis


SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSDiffusedUnderlying & diffusedUnderlying);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSDiffusedUnderlying & diffusedUnderlying);

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::CSRLocalPathGeneratorServer::SSUniformLawID & uniformLawID);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::CSRLocalPathGeneratorServer::SSUniformLawID & uniformLawID);

// SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::CSRLocalPathGeneratorServer::SSKeyForUniformLaw & keyForUniformLaw);
// SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::CSRLocalPathGeneratorServer::SSKeyForUniformLaw & keyForUniformLaw);

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSBumpKey & bumpKey);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSBumpKey & bumpKey);


SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSBasisComponent & basisComponent);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSBasisComponent & basisComponent);

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSUnderlingForPayoff & underlingForPayoff);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSUnderlingForPayoff & underlingForPayoff);

SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::SSResultBySampling & resultBySampling);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::SSResultBySampling & resultBySampling);


SOPHIS_MONTECARLO_SERVER sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & archive, const sophis::finance::CSRServerPayoff::SSMCPaymentCurrency & mcPaymentCurrency);
SOPHIS_MONTECARLO_SERVER const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & archive, sophis::finance::CSRServerPayoff::SSMCPaymentCurrency & mcPaymentCurrency);


SPH_EPILOG

#endif 
