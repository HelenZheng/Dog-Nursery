/*
 	File:		SphMonteCarloPayoff.h

 	Contains:	Class for the handling of a payoff for Montecarlo.

 	Copyright:	� 2004 Sophis.
*/

/*! \file SphMonteCarloPayoff.h
	\brief Handling monte carlo payoff.
*/

#ifndef _SphMonteCarloPayoff_H_
#define _SphMonteCarloPayoff_H_

#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"

#if (defined(WIN32)||defined(_WIN64))
namespace sophis {
	namespace instrument {
		enum eQuantoType;
		struct SSAlert;
	}
}
#else
#include "SphInc/instrument/SphOption.h"
#endif

#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"


#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(set)


#define DECLARATION_MONTECARLO_PAYOFF(derivedClass)			DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRMonteCarloPayOff)
#define CONSTRUCTOR_MONTECARLO_PAYOFF(derivedClass)
#define WITHOUT_CONSTRUCTOR_MONTECARLO_PAYOFF(derivedClass)
#define	INITIALISE_MONTECARLO_PAYOFF(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace market_data {
		class CSRMarketData;
	}
	namespace static_data {
		class CSRHistoricalData;
	}
	namespace finance {

		class CSROptionMonCar;


		/** Interface for handling a special Monte Carlo pay off.
		To integrate a new pay-off, derive this method.
		@see CSRSupport
		@version 4.7
		*/
		class SOPHIS_FINANCE CSRMonteCarloPayOff
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRMonteCarloPayOff();

			/** Define the list of underlyings.
			*/
			struct SSMultiUnderlying
			{
				/** Instrument ID. */
				long		fCode;

				/** Quanto or Compo. */
				instrument::eQuantoType	fType;


				/** Strike saved in the database.
				*/
				double		fStrike;

			};

			/** Map of fixing for one date.
			The key is an instrument ID, the data is the spot value.
			*/
			typedef _STL::map<long , double> FixingsVect;

			/** List of fixings.
			The key is a data, the data is the list of fixing for that date.
			*/
			typedef _STL::map<long , FixingsVect > FixingsMap;

			/** Define the type of random to use.
			*/
			enum	typeRandomGenerator
			{
				eSobol,
				eRand2
			};

			/** Define the type of random to use.
			@return the type of random to use.
			By default, eRand2
			@see typeRandomGenerator.
			*/
			virtual typeRandomGenerator	GetRandomGeneratorType() const;

			/** Initialisation of the pay off.
			It is done at the end of the constructor of the option and can be used
			to initialze static data for pay off. If you need to put some elements of the
			basket out, it must be done here.
			By default, does nothing.
			*/
			virtual void Initialise() ;

			typedef double ** CSRInput;
			typedef double CSROutput;

			/** Return the pay off for one path.
			This is the main method to overload. This is called for each patch that is generated.
			The result is averaged and discounted.
			@param input is a matrix of spot giving the values for the patch; the first index is
			for the equity from 0 included to fEquityList.size() excluded; the second if for dates
			from 0 until fDates.size() - 1.
			@param output is the paid amount not discounted in the unit of the option.
			*/
			virtual void	GetPayOffForOnePath( const CSRInput & input, CSROutput &output) const;

			/** Get the pay off formula.
			It is called by the CSROption::GetPayOffFormula to get the formula.
			@param name is an output string stl.
			*/
			virtual	void GetPayOffFormula(_STL::string &name) const;

			/** Get the strike to use for the nth underlying.
			The method {@link CSROption::GetVolatilityStrike} calls this method to know what volatility to
			use to generate paths. This value is also shown in the main dialog.
			@param option is the montecarlo option.
			@param which is an interger from 0 included to fUnderlyingCount excluded.
			@return the strike in amount.
			By default, returns strike if not forward, or the forward if it is not in the past. Otherwise, returns the strike multiplied by the fixing.
			*/
			virtual double	GetVolatilityStrike( const market_data::CSRMarketData & param, int which) const;


			/** Get the dates needed for the path.
			It is called by {@link CSROptionMonCar::CollectAllDates} to collect the dates needed for the path.
				@param date is the set of dates including the past which contains the end date by default.
				By default, does nothing.
			*/
			virtual void 	CollectAllDates(_STL::set<long> &date, const static_data::CSRHistoricalData &histoData);

			/** The key for the prototype is a string C.
			@see CSRPrototype
			*/
			typedef tools::CSRPrototype<CSRMonteCarloPayOff, const char *, tools::less_char_star> prototype;

			/** Access to the singleton containing all the derived classes of CSRBundleMarketData.
			It is populated when using the macro INITIALISE_MONTECARLO_PAYOFF.
			*/
			static prototype & GetPrototype();

			/** Clone function used by prototype.
			It is generally created by the macro DECLARATION_MONTECARLO_PAYOFF.
			By default, generate an exception. In this case, it generally means
			that the macro has been implemented.
			*/
			virtual CSRMonteCarloPayOff * Clone() const;

			/** Test if the payoff is in the right state to be priced.
			It is called by MultiUnderlying in order to know if option is valid.
			@return true if the payoff is valid.
			By default, return true.
			*/
			virtual	Boolean		ValidInstrument() const	;

			/** Get the alert list.
			It is called by MultiUnderlying in order to add specific payoff alert list.
			@param forecastDate is the date of forecast.
			@param nb is a valid address to set the count of alerts.
			@return an array of alerts, which is deleted by delete [].
			This method is called during the forecast for all instruments in
			open positions and is used to fill the alert books.
			Note that this list is added to the conventional alerts directly managed by the forecasts.
			The default implementation is to return NULL.
			*/
			virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const;

			const _STL::vector<SSMultiUnderlying>& GetUnderlyingList() const {return fUnderlyingList;}

		protected:
			/** List of underlyings. */
			typedef _STL::vector<SSMultiUnderlying> MultiUnderlyingList;

			/** Equity count for path generation.
			*/
			MultiUnderlyingList	fUnderlyingList;

			/** Pointer on the option where the pay-off is used.
			*/
			const CSROptionMonCar * fOption;

			/** List of fixings.
			@see CollectAllDates.
			*/
			FixingsMap	fObsDateFixing;


			/** Collect the fixing.
				CollectFixings collects the fixing for the corresponding date and stores
				them in the member variable fObsDateFixing.
				@param date is the date to collect the fixing.
			*/
			void	CollectFixings(long date,const sophis::static_data::CSRHistoricalData &histoData);

			/** Get the fixing from database.
				@param date is the date to get the fixing.
				@param code is the instrument ID.
				@returns the fixing for the corresponding date and instrument code.
				It searchs in the fixing list first. Then, if no fixing is found and if
				the date corresponds to the Start Date of the product, it looks in the Basis field of  the underlying list, to be consistent with the standard forward start option.
				WARNING: This method does not directly access the value from the fObsDateFixing, but the	dialog and its data. This method is not as fast as GetMUFixing.
			@see GetFixingFromMap
			*/
			double	GetFixingFromDatabase(long date,long code,const static_data::CSRHistoricalData &histoData) const;

			/** Get the fixing from database.
			This is the optimised version.
				@param date is the date to collect the fixing.
				@param code is the instrument ID.
				@param date is the date to get the fixing.
				@param code is the instrument ID.
				@returns the fixing for the corresponding date and instrument code.
				It searchs in the fixing list first. Then, if no fixing is found and if
				the date corresponds to the Start Date of the product, it looks in the Basis field
				of the underlying list, to be consistent with the standard forward start option.
				If no fixing is found, and if the date correspond to today, it returns the current
				spot of the instrument.
			@see GetFixingFromDatabase
			*/
			double GetFixingFromMap(long date,long code) const;


			/** List of equities which must not be paid.
			This must be done in the Initialize.
			*/
			_STL::set<long> fOutOfBasket;

			/** List of ordered dates for the Monte Carlo path.
			*/
			_STL::vector<long> fDates;

			friend class MultiUnderlyings;
			friend class MultiMCOptionDialog;

			/** Get the discretization for underlyings.
			Used essentially for barriers.
			*/
			int		fDiscratizationLength;

		};


	}
}
SPH_EPILOG
#endif
