#ifndef _SphMultiCurrencyBasket_H_
#define _SphMultiCurrencyBasket_H_

#ifndef _SphEquity_H_
#include "SphInc/instrument/SphEquity.h"
#endif

#ifndef _SphDialog_H_
#include "SphInc/gui/SphInstrumentDialog.h"
#endif


SPH_PROLOG
namespace sophis {
	namespace market_data {
		class CSRVolatilityComputation;
	}
	namespace static_data {
		class CSRHistoricalData;
	}
}

namespace sophis {
	namespace finance {

		typedef struct TDateList {
			long		Date;
		} *PDateList, **HListDate;

		typedef struct TFixingInfo {
			long		Date;
			long		UnderlyingCode;
			double		Spot;
		} *PFixingInfo, **HFixingInfo;

		typedef struct TSpotFixing {
			long		UnderlyingCode;
			double		Spot;
			short		InCurrency;
		}  *PSpotFixing, **HSpotFixing;

		typedef struct TCompoFixingInfo {
			long		UnderlyingCode;
			long		PivotCurrency;
			short		Conversion;
		}  *PCompoFixingInfo, **HCompoFixingInfo;

		enum eMCBasketConversionType {
			mcbcQuanto = 1,
			mcbcCompo
		};

		enum eMCBasketComputationType {
			mcbcNormal = 1,
			mcbcAverageForward
		};

		/* old version
		enum eMCBasketVolatilityComputationType {
			mcbvcWithEquitySmile=1,
			mcbvcWithBasketSmilePlus,
			mcbvcWithBasketSmileMult,
			mcbvcNoAndAccountForScenarioAdd,
			mcbvcNoAndAccountForScenarioMult,
			CalculDeLaVolAvecSmileActionsGM,
			CalculDeLaVolAvecSmilePanierAddGM,
			CalculDeLaVolAvecSmilePanierMultGM,
			NonCalculVolEtTenirCompteScenarioAddGM,
			NonCalculVolEtTenirCompteScenarioMultGM,
			OnlyBasketVol
		};
		*/

		enum eMCBasketVolatilityComputationType {
			mcbvcTheoreticalVariance=1,
			mcbvcATMPlusBasketSmileVariance,		
			mcbvcATMMultBasketSmileVariance,		
			mcbvcAdditiveOverVolatilityVariance,		
			mcbvcMultiplicativeOverVolatilityVariance,		
			mcbvcTheoreticalGeometric,
			mcbvcATMPlusBasketSmileGeometric,		
			mcbvcATMMultBasketSmileGeometric,		
			mcbvcAdditiveOverVolatilityGeometric,		
			mcbvcMultiplicativeOverVolatilityGeometric,		
			mcbvcBasketVolatilityOnly
		};

		struct SSOrderedPair
		{
			SSOrderedPair(long sico1, long sico2)
			{
				if(sico1 < sico2)
				{
					fSico1 = sico1;
					fSico2 = sico2;
				}
				else
				{
					fSico1 = sico2;
					fSico2 = sico1;
				}
			}

			bool operator< (const SSOrderedPair & ref) const
			{
				if(ref.fSico1<fSico1
					|| (fSico1==ref.fSico1 && ref.fSico2<=fSico2))
					return false;

				return true;
			}

			long fSico1, fSico2;
		};

		typedef struct {
			long				Code;
			long				Currency1;
			long				Currency2;
			eMCBasketConversionType	CompoQuanto;
			double				NbOfSecurities;
			double				Factor;
			double				Currency1Spot;
			double				Currency1Foward;
			double				Currency1Volatility;
			long				GetCurrency1() const; // returns component currency or the currency itself (when component is a forex where quotation currency is basket currency)
			long				GetCurrency2() const;
			bool				IsForex() const	;
		} TBasketComponent, *PBasketElement, **HBasketElement;

		class SOPHIS_FINANCE CSRMultiCurrencyBasket : public virtual instrument::CSREquity
		{
			DECLARATION_EQUITY(CSRMultiCurrencyBasket)

		public:
			~CSRMultiCurrencyBasket();

			// safe as it is a virtual method in CSRInstrument, worst case is toolkit which does not use the overloaded method.
			virtual Boolean ValidInstrument() const;
			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

			eMCBasketConversionType				GetMCBasketConversionType() const {return fMCBasketConversionType;}
			eMCBasketComputationType			GetMCBasketComputationType() const {return fMCBasketComputationType;}
			eMCBasketVolatilityComputationType	GetMCBasketVolatilityComputationType() const {return fMCBasketVolatilityComputationType;}

			bool	SetMCBasketConversionType(eMCBasketConversionType conversion);
			bool	SetMCBasketComputationType(eMCBasketComputationType computation);
			bool	SetMCBasketVolatilityComputationType(eMCBasketVolatilityComputationType volComputation);

			int		GetFixingCount() const { return fFixingCount; }			
			bool	GetNthFixingDate(int n, long& date) const;
			void	GetNthBasketComponent(int i, TBasketComponent& component) const;
			bool	GetNthFixingOfMthComponent(int n, int m, TFixingInfo& fixingInfo) const;
			bool	GetComponentPercentage(double& percent, long code) const;
			int		GetMCBasketForexCount() const {return fCurrencyCount;}
			bool	GetNthFixingOfMthForex(int n, int m, TFixingInfo& underlyingFixing) const;
			bool	GetBasketAverageFowardValue(double& basketValue) const;
			Boolean AddBasketComponent(TBasketComponent basketComponent, int position = -1);
			Boolean AddBasketComponent(_STL::vector<TBasketComponent > basketComponentVector);
			eQuantoCompoPossible 	QuantoCompoPossible() const ;

			/** returns the fixing of a component in a basket at a past fixing date
			*	using the table FixingMultiDev
			*	a buffer is used to minimize the calls to the database
			*	@param swapCode is the code of the swap
			*	@param underlyingCode is the code of the underlying in the basket
			*	@param fixingDate is the date for the fixing
			*	@param fixing is the fixing of the underlying (NOTDEFINED in case of error)
			*	@return true if the fixing is correctly defined
			*	@since 5.3.0
			*/
			static bool	GetComponentFixing(long swapCode, long underlyingCode, long fixingDate, double& fixing, const sophis::static_data::CSRHistoricalData &histoData);
			/** erases the buffer used by GetComponentFixing
			*	use this method if you expect the past fixings in FixingMultiDev to change
			*	@param swapCode is the code of the swap for which the buffer should be erased
			*		if swapCode is -1, the buffers for every swap are erased
			*	@since 5.3.0 
			*/
			static void	ResetFixingBuffer(long swapCode=-1);

			void	NotAnInstrumentInTheDatabase(TBasketComponent*& basket, int i) const;  // internal
			
			virtual	double	GetEquityGlobalDelta(const market_data::CSRMarketData& context) const;

			// Internal
			TBasketComponent* GetBasketComponentArray(bool duplicate = false) const;
			void InitialiseVolatility(TBasketComponent*& basket,
									  const market_data::CSRMarketData& context,
									  double moneynessPct,
									  double startDate,
									  double endDate,
									  NSREnums::eVolatilityType volType,
									  Boolean Put,
									  bool noSIMUL=false) const;	
			void InitialiseForward(TBasketComponent*& basket, long t, long T, const market_data::CSRMarketData& context, int basketIndex = -1) const;
			void InitialiseSpot(TBasketComponent*& basket, const market_data::CSRMarketData& context, bool forVolatility) const;
			void InitialiseSpotForVolatility(TBasketComponent*& basket, const market_data::CSRMarketData& context) const;
			void InitialiseNbOfSecurities(TBasketComponent*& basket, const market_data::CSRMarketData& context) const;
			void InitialiseFactor(TBasketComponent*& basket, const market_data::CSRMarketData& context, long t, long T) const;
			
			double**FillLocalMatrix(TBasketComponent* basket, const market_data::CSRMarketData& context, eMCBasketConversionType compoQuantoBasket, long t, long T) const;
			double**FillLocalMatrix(TBasketComponent* basket, const market_data::CSRMarketData& context, eMCBasketConversionType compoQuantoBasket, long t, long T, double moneynessLevel) const;
			void	ModifyCovariance1(double **cov, double elapseTime, int nb) const;
			void	ModifyCovariance2(double **cov) const;
			void	ModifyLocalMatrix(double* covariancendexI, double* covarianceIndexJ, TBasketComponent* basket, const market_data::CSRMarketData& context,eMCBasketConversionType compoQuantoBasket, long t, long T, int which1, int which2) const ;
			double	ComputeFowardComponentValue(TBasketComponent component, const market_data::CSRMarketData& context, long t, long T, eMCBasketConversionType compoQuantoBasket,const CSRInstrument *instrument=0) const;
			double	ComputeFowardFactors(double &forex, TBasketComponent component, const market_data::CSRMarketData& context, double t0, double t, double T, eMCBasketConversionType compoQuantoBasket) const;
			double	ComputeComponentSpot(TBasketComponent component, const market_data::CSRMarketData& context, eMCBasketConversionType compoQuantoBasket) const;
			double	ComputeBasketVolatility(TBasketComponent* basket, const market_data::CSRMarketData& context,eMCBasketConversionType compoQuantoBasket, long t, long T) const;
			double	ComputeBasketVolatility(TBasketComponent* basket, const market_data::CSRMarketData& context,eMCBasketConversionType compoQuantoBasket, long t, long T, double moneynessLevel) const;
			double	BasketVolatility1(double vol, double elapseTime) const;
			double	BasketVolatility2(double vol) const;

			// Correction computation for the delta and gamma depending on the basket only 
			virtual void GetEquityDeltaGammaCorrection(sophis::instrument::CSRInstrument* instr, TBasketComponent* basket,const market_data::CSRMarketData& context, double t, _STL::map<long, double> & mapToFill) const;
			virtual void GetCrossedEquity1Correction(TBasketComponent* basket, const market_data::CSRMarketData& context, _STL::map<long, double> & mapToFill) const ;
			virtual void GetCrossedEquity2Correction(TBasketComponent* basket, const market_data::CSRMarketData& context, _STL::map<long, double> & mapToFill) const ;
			void GetForexSpotDeltaGammaCorrection(TBasketComponent* basket, const market_data::CSRMarketData& context, long* currencyList, int LongueurcurrencyList, long optionExpiry, _STL::map<long, double> & mapToFill, sophis::instrument::CSROption* optionBase =0) const;
			void GetDeltaFactorInFXGammaCorrection(TBasketComponent* basket, const market_data::CSRMarketData& context, long* currencyList, int currencyListSize, long optionExpiry, _STL::map<SSOrderedPair, double> & deltaFactorInFXGammaCorrection) const;
			void GetAFactor(TBasketComponent* basket,const market_data::CSRMarketData& context,double t, double T, _STL::map<long, double> & mapAFactorToFill) const;
			void GetAFactor(TBasketComponent* basket,const market_data::CSRMarketData& context,double t, double *T, int nbFixings, _STL::map<long, double> & mapAFactorToFill) const;
			void GetAFactorCurrency1(TBasketComponent* basket,const market_data::CSRMarketData& context,double t, double *T, int nbFixings, _STL::map<long, double> & mapAFactorToFill,_STL::map<long, double> & mapQuantoSensitivityToFill) const;
			virtual void GetCorrectionDeltaActionArray(TBasketComponent* basket, const market_data::CSRMarketData& context, double t, long* T, int nbDates, _STL::map<long, double> & mapAFactorToFill, _STL::map<long, double> & mapQuantoSensitivityToFill) const;
			double** GetABucketedFactorCurrency1(TBasketComponent* basket,const market_data::CSRMarketData &context,double t, long *T, int nbFixings) const;
			double* GetSpotFactorCurrency1(TBasketComponent* PANIER,const market_data::CSRMarketData &param) const;

			/** Called by GetForwardPrice herited from CSREquity
			 * @param valPerComponent to get the futures by components.
			 * First key is the underlying code, second key is the forward date (ie valPerComponent[code][date]).
			 * @since 5.3.4
			 */
			virtual void  GetForwardPrice(	long									*fowardDate, 
											double									*val,
											short									dateCount,
											market_data::eTaxCreditPercentageType	forEvaluation,
											const market_data::CSRMarketData		&context,
											_STL::map<long, _STL::map<long, double> >	*valPerComponent) const ;

			virtual bool	HasAVolatilityFormula() const;
			virtual bool	HasAFormulaForSpot() const;

			virtual double	GetVolatility(	double 						startDate,
											double 						endDate,  
											double 						strike,
											NSREnums::eVolatilityType  	volatType,
											Boolean 					put,
											const market_data::CSRMarketData	&context) const;


			virtual double	GetEquivalentDividendYield(	
											long 						startDate,
											long 						endDate,
											sophis::instrument::eSettlementType	which,
											const market_data::CSRMarketData			&context) const;
			
			virtual double	GetRepoMargin(double date1, double date2) const;

			virtual	double			GetDerivativeSpot(const market_data::CSRMarketData& context) const;
			virtual double GetNthBasketValue(const market_data::CSRMarketData& context, int which) const;

			virtual sophis::instrument::SSAlert * NewAlertList(long forecastDate, int *nb) const;
			// use Delete to delete the returned array

			virtual	sophis::instrument::CSROption* new_Splitter(sophis::instrument::CSROption* option, bool optionInPortfolio) const;

			// corporate action
			virtual sophis::gui::CSRFitDialog	*new_FixingDialog(long fixingDate) const;
			virtual sophis::instrument::eSplitActionType	Split(long splitDate, long underlyingCode) const;
			virtual	bool				SplitDone(long splitDate, long underlyingCode, double factor) const;
			virtual bool				Merge(long mergeDate, long oldUnderlyingCode) const;
			virtual	bool				MergeDone(long mergeDate, long oldUnderlyingCode, long newUnderlyingCode) const;

			/** Calculate dividend Amount between two dates.
			Dividends are discounted to calculation_date.
			This method is used in an equity swap when paying dividends.
			@param context is a market data.
			@param start_date is the start of the period for dividend in ex-div.
			@param end_date is the end of the period for dividend in ex-div.
			@param paye_date is payment date of dividend; if may be a number of days
			@param base is the criterion to include dividend dates: ex-div, record or payment date
			@param divData hold the dividend amount per currency (used for the multi-currency basket)
			when they are paid immediately.
			@since 4.5.1.1.20 the method is not virtual and links in SphFinance so that 20 is a patch.
			@version 5.3 added the base parameter
			@version 5.3.4 not to be overloaded anymore and calls GetGrossDividendAmountForTRS
			@see GetGrossDividendAmountForTRS
			*/
			double GetGrossDividendAmount(	const market_data::CSRMarketData & context,
											long start_date,
											long end_date,
											long paye_date,
											instrument::eDividendBase base = instrument::_dbExDivDate,
											MapDivCurrencyAmount * divData = NULL) const;
			
			// delete with delete []
			virtual instrument::SSDividendArray *new_DividendArray(	long 				beginDate, // delete with delete []
														long 				endDate,
														instrument::eSettlementType		settlementType,
														const market_data::CSRMarketData& context,
														market_data::eTaxCreditPercentageType toEvaluate,
														int					*elementsCount) const;

			/** Calculate dividend Amount between two dates.
			Dividends are discounted to calculation_date.
			This method is used in an equity swap when paying dividends.
			@param context is a market data.
			@param start_date is the start of the period for dividend in ex-div.
			@param end_date is the end of the period for dividend in ex-div.
			@param paye_date is payment date of dividend; if may be a number of days
			@param base is the criterion to include dividend dates: ex-div, record or payment date
			@param divData hold the dividend amount per currency per component (used for the basket swaps)
			when they are paid immediately.
			@since 4.5.1.1.20 the method is not virtual and links in SphFinance so that 20 is a patch.
			@version 5.3 added the base parameter
			*/
			typedef _STL::map<long, _STL::pair<double, MapDivCurrencyAmount> > MapDivCurrencyAmountPerComponent;
			virtual double GetGrossDividendAmountForTRS(const market_data::CSRMarketData	&context,
														long								start_date,
														long 								end_date,
														long 								paye_date,
														instrument::eDividendBase			base = instrument::_dbExDivDate,
														MapDivCurrencyAmountPerComponent	*divData = NULL) const;

			/** Calculates the redeemed amount of the instrument redemption table between two dates
			This allows treatment of partial redemptions for Total Return Swaps
			on bonds and bond baskets
			@param context is the computation context
			@param startDate is the date from which the redemptions are to be taken into account (excluded)
			@param endDate is the date until which the redemptions are to be taken into account (included)
			@param paymentDate is the date at which the flows will be paid (can be a relative date)
			@param discounted tells whether the amount must be discounted and take the credit risk into account
			@since 5.3
			*/
			virtual double GetRedeemedDividendAmount(const market_data::CSRMarketData	&context,
													long								startDate,
													long								endDate,
													long								paymentDate,
													bool								discounted) const;

			/** Calculate the coupon amount which is going to be distributed over a period.
			@param startDate is the start of the period. It is excluded.
			@param endDate is the end of the period. It is included.
			@param context is the market data.
			@param discounted asks for discount of the coupons.
			This function is called during theta calculation and P&L attributions
			to compare the previous day's trades P&L with the expected coupon amount.
			@since 5.3
			@see GetTheta
			*/
			virtual double	GetCouponAmount(	long							startDate,
												long							endDate,
												const market_data::CSRMarketData&context,
												bool							discounted) const;

			// internal: used to compute sensitivities to the mean of future prices for Asian begin/Asian end
			void ResetSensitivityData() const;
			mutable double fTempsDepart, fTempsFin, fBumpDepart, fBumpFin;

			virtual sophis::market_data::CSRVolatilityComputation *new_CSRVolatilityComputation() const;
			/** 
			return true
			*/
			virtual bool ConsideredAsBasketIfUnderlyingOfOption() const;

		protected:
			
			/** the global buffer used by GetComponentFixing
			*	use ResetFixingBuffer to erase
			*/
			typedef _STL::pair<long, long> FixingKey;
			typedef _STL::map<FixingKey, double> BasketFixingBuffer;
			SPH_BEGIN_NOWARN_EXPORT
			static _STL::map<long, BasketFixingBuffer> sGlobalFixingBuffer;
			SPH_END_NOWARN_EXPORT
		private:
			HFixingInfo			fFixingMatrix;				// spot lists - stores the data
			HCompoFixingInfo	fCurrencyMatrix;			// pivot currency list - stores the data
			HListDate			fDatesMatrix;				// fixing date list, used to retreive nth fixing date 
			HSpotFixing			fSpotMatrix;				// list to retreive Nth forex change's code
			mutable TBasketComponent	*fBasketComponentArray;		// component list to retreive nth component code
			// mutable because some elements (vol) are stored
			bool IsSamePrimaryCurrency(long code1, long code2) const;
			//internal use for Forward/Average Basket
			void InitialiseNbOfSecuritiesForwardAnalysis(TBasketComponent*& basket, const market_data::CSRMarketData& context) const;


			int		fFixingCount;
			int		fCurrencyCount;
			double	fBasketValue;

			mutable bool				fVolVariance;
			mutable bool				fGetCoursDeriveeForVolatility;

			eMCBasketConversionType				fMCBasketConversionType;
			eMCBasketComputationType			fMCBasketComputationType;
			eMCBasketVolatilityComputationType	fMCBasketVolatilityComputationType;

			void CreateBasketComponentInfo();
			void CreateBasketDateInfo();
			void CreateBasketCurrencyInfo();

		};

	} // namespace finance
} // namespace sophis

enum eMCBasketDialogElements {
	mcbdeOk = 1,
	mcbdeCompoQuanto,
	mcbdeAverageFoward,
	mcbdeVolatilityComputation,
	mcbdeBasketValue,
	mcbdeFixing,
	mcbdeComposition,
	mcbdeCancel,
	mcbdeMatrix = 13
};

const int kMultiCurrencyBasketDialogId = 500;
const int kMultiCurrencyBasketDialogElemCount=11;

class SOPHIS_FINANCE CSRMultiCurrencyBasketDialog : public sophis::gui::CSRInstrumentDialog
{
	DECLARATION_INSTRUMENT_DIALOG(CSRMultiCurrencyBasketDialog)

	virtual	void	Open(void);
	virtual	Boolean	Close(void);

			void BuildCurrencyMatrix();
			void BuildMatrix();

	sophis::finance::HFixingInfo			fMatrix;
	sophis::finance::HCompoFixingInfo	fCurrenciesMatrix;
	sophis::finance::HSpotFixing			fMatrixSpot;
	sophis::instrument::CSREquity			*fBasket;
};

SPH_EPILOG


#endif
