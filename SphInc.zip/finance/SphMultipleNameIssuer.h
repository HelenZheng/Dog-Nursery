#ifndef _MULTIPLE_ISSUER_
#define _MULTIPLE_ISSUER_

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/finance/SphCDSPricer.h"
#include "SphInc/market_data/SphMarketData.h"
//#include "SphInc/finance/SphNewMonteCarlo.h"
#include "SphInc/finance/SphMonteCarlo.h"


SPH_PROLOG
namespace sophis
{
	namespace math
	{
		class CSRCopula;
	}
	namespace finance
	{
		class CSRBufferNormalSample;
		class CSRRandomGenerator;
		class CSRUniformRandomGenerator;

		struct SSIssuerInfos
		{
			long issuerCode;
			long currencyCode;
			long seniority;
			long defaultEvent;
		};

		/** for a given correlation level the series of permuted cholesky matrices**/
		typedef _STL::vector<UblasMatrixDb>	MatrixVect;

		/** for a different set of correlation level, the series of permuted cholesky matrices**/
		typedef _STL::vector<MatrixVect>			MatrixVectList;

		/**
		* This class handles multiple name simulation of credit default time.
		* It uses a Monte Carlo generator to simulate credit events.
		* It uses stratified sampling in order to have at least one default per sample path
		*/
		class SOPHIS_FINANCE CSRMultipleNameGenerator
		{
		public:
			/**
			* Constructor.
			* @param maximalDate the default events are simulated between today date and maximalDate-1day
			* @param trueIssuerList is the list of independent issuer to be considered.
			* @param correspondingCDSPricer list corresponding to the one above with for each independent issuer the list of CSRCDSPricer involved.
			* @param copula is the copula used for correlation.
			* @param context market data used for single name initialise credit risk data
			*/
			CSRMultipleNameGenerator(	double															maximalDate,
										const _STL::vector<long>										&trueIssuerList,
										const _STL::vector<_STL::vector<const finance::CSRCDSPricer*> >	&correspondingCDSPricer,
										sophis::math::CSRCopula*										copula,
										short															randomGeneratorID,
										const market_data::CSRMarketData&								context);

			/*
			 *	Destructor.
			 */
			virtual ~CSRMultipleNameGenerator();
			
			/**
			* This is an accessor to the random generator object.
			* @return a pointer on the random generator object.
			*/

			const CSRUniformRandomGenerator* GetRandomGenerator() const;

			/**
			* This method gives back the time of credit default events on the set of issuers knowing that all
			* issuers with an index prior to indexRef is suppose to default at fMaxMaturity because of the stratified sampling.
			* @param stoppingTimeVect is filled with the associated default time. Dimension is the one of the number of CSRCDSPricer involved.
			* It is ordered as follow for each true issuer the cds pricer is rolled over (I11,...,I1k_1, ... , In1,...,Ink_n) where Iij is the j-th CSRCDSPricer of the i-th true issuer.
			* @param correlatedSampling is for input the set of simulated Gaussian law. Dimension is the one of the true issuer list.
			* @param indexRef is the first issuer index which is suppose and must default before fMaxMaturity.
			* @see GetCorrelatedNormalValue
			* @see fMaxMaturity
			*/
			void	GetConditionalStoppingTime(_STL::vector<double>& stoppingTimeVect, const _STL::vector<double>& correlatedSampling, int indexRef) const;

			/**
			 * This method launches the computation of the next simulation run
			 */
			 void	LaunchNextSimulationRun();

			 /**
			 * This method gives back the correlated Gaussian sampling values. And verifies if the path is valid for the stratified sampling.
			 * @param issuerIndex is the first issuer index which is suppose and must default before fMaxMaturity. It is used to get the correct Cholesky matrix.
			 * @param matrixIndex is the first issuer index of the corralation to consider.
			 * @param validPath is set to true if the sample is valid for the stratified sampling. If one true issuer with index lower than issuerIndex is going to default,
			 * the it is set to false.
			 * @see fCholeskyMatrixVect
			 * @see fDefaultGaussianTrigger
			 */
			 _STL::vector<double>& GetCorrelatedStoppingTime(	int		issuerIndex,
																int		matrixIndex,
																bool	&validPath) const;

			 /**
			 * This method gives the default amount associated to each issuer (1 - recovery rate).
			 * @return the default amount associated to each CSRCDSPricer for a notional of 1.
			 * It is ordered as follow for each true issuer the cds pricer is rolled over (I11,...,I1k_1, ... , In1,...,Ink_n) where Iij is the j-th CSRCDSPricer of the i-th true issuer.
			 */
			 _STL::vector<double>& GetDefaultAmount() const;

			 /**
			 * This method gives the default probability associated to each issuer between today and fMaxMaturity.
			 * @return the default probability associated to each CSRCDSPricer for a notional of 1.
			 * It is ordered as follow for each true issuer the CSRCDSPricer is rolled over (I11,...,I1k_1, ... , In1,...,Ink_n) where Iij is the j-th CSRCDSPricer of the i-th true issuer.
			 * @see fMaxMaturity
			 */
			 _STL::vector<double>& GetDefaultProbability() const;

			 /**
			 * This method gives the flat CSRCDSPricer list ordered as follow: (I11,...,I1k_1, ... , In1,...,Ink_n) where Iij is the j-th CSRCDSPricer of the i-th true issuer.
			 * @return the full CSRCDSPricer list ordered as explained.
			 */
			 const _STL::vector<const finance::CSRCDSPricer*>& GetCDSPricerFlatList() const;

		private:
			/**
			* This method a list of cholesky matrix from the correlation matrix for the stratified sampling.
			* It is called by GetConditionalStoppingTime.
			* @param index is the index of the CSRCDSPricer to consider in GetCDSPricerFlatList.
			* @param factor will be compare to 1./(survival proba) to invert the curve and get the stopping time.
			* @see GetCDSPricerFlatList
			* @see GetConditionalStoppingTime
			*/
			double	ComputeMaturity(int index,double factor) const;

			double															fMaxMaturity;
			_STL::map<double,long>											*fCreditRiskFactorIssuers;
			short															fRandomGeneratorID;
			mutable sophis::finance::CSRUniformRandomGenerator*				fUniformRandomGenerator;
			mutable int														fNthSampling;

			sophis::math::CSRCopula*										fCopula;

			const _STL::vector<long>										&fTrueIssuerList;
			const _STL::vector<_STL::vector<const finance::CSRCDSPricer*> >	&fCorrespondingCDSPricer;
			_STL::vector<const finance::CSRCDSPricer*>						fCDSPricerFlatList;

			mutable _STL::vector<double> 	fDefaultAmount;
			mutable _STL::vector<double> 	fDefaultProbability;
			int								fNbUniform;
			double*						 	fSamplingUniform;
			mutable _STL::vector<double> 	fCorrelatedSampling;
			mutable _STL::vector<double> 	fStoppingTimeSampling;

			int							 	fRealIssuerCount;
			bool						 	fOptimMatrice;//this boolean is used to trigger simplified matrix computation for gaussian copula
		};

	}
}
SPH_EPILOG

#endif
