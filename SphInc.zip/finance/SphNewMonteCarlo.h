/*
*    File:       SphMonteCarlo.h
*
*    Contains:   The "New Monte Carlo" pricing model and how to overload it
*
*    Copyright:  � 1995-2000 Sophis.
*
*/
#ifndef __MONTECARLO_INTERFACE_H__
#define __MONTECARLO_INTERFACE_H__

#include "SphInc/instrument/SphOption.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/finance/SphMonteCarloServer.h"
#include "SphInc/gui/SphInstrumentDialog.h"
#include "SphInc/market_data/SphVolatility.h"
#include "SphTools/SphExceptions.h"
#include "SphInc/finance/SphDefaultMetaModelOption.h"
#include "SphInc/gui/SphInstrumentDialogWithTabs.h"
#include "SphInc/market_data/SphDataIntegrityManager.h"
#include "SphInc/finance/SphCopula.h"
#include "SphInc/finance/SphCopulaData.h"
#include "SphInc/SphMath.h"
#include "SphInc/static_data/SphHistoricalData.h"
#include "SphInc/instrument/SphInstrumentEnums.h"

#include "SphMathTools/SphLiborMarketModelData.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)


#if (defined(WIN32)||defined(_WIN64))
#	ifdef SOPHIS_MONTECARLO_EXPORTS
#		define SOPHIS_MONTECARLO __declspec(dllexport)
#	else
#		define SOPHIS_MONTECARLO __declspec(dllimport)
#	endif
#else
#	define SOPHIS_MONTECARLO
#endif


/** Macro used to initialise a class derived from  CSROptionMonteCarloInterface 
*
*	static void * CreateMyMonteCarloOption(produit **h)
*	{
*			return new MyMonteCarloOption(h);
*	}
*
*	INITIALISE_DERIVE_OPTION_MONTECARLO_INTERFACE(CreateMyMonteCarloOption,"My Monte Carlo")
*
*/
#define	INITIALISE_DERIVE_OPTION_MONTECARLO_INTERFACE(derivedClass, name)									\
	{																										\
		static SphInstrumentFactoryNewT<derivedClass, produit **> _constructor;								\
		::NewDeriveSophis(&_constructor, name, sophis::finance::CSROptionMonteCarloInterface::sReserve);	\
	}

// Macro declaration for client correlation classes managing correlation between Brownian diffusion
#define DECLARATION_CLIENT_CORRELATION(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRClientCorrelation)
// Macro instantiation for client correlation classes managing correlation between Brownian diffusion
#define INITIALISE_CLIENT_CORRELATION(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client path generator classes generating underlying path
#define DECLARATION_PATHGENERATOR_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLocalPathGeneratorClient)
// Macro instantiation for client path generator classes generating underlying path
#define INITIALISE_PATHGENERATOR_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client interest rate path generator classes generating underlying path
#define DECLARATION_INTEREST_RATE_PATHGENERATOR_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRInterestRateLocalPathGeneratorClient)
// Macro instantiation for client interest rate path generator classes generating underlying path
#define INITIALISE_INTEREST_RATE_PATHGENERATOR_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client LMM front parametric interpolation classes generating underlying path
#define DECLARATION_LMM_FRONT_PARAMETRIC_INTERPOLATION_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLiborMMFrontParametricInterpolation)
// Macro instantiation for client LMM front parametric interpolation classes generating underlying path
#define INITIALISE_LMM_FRONT_PARAMETRIC_INTERPOLATION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client LMM back parametric interpolation classes generating underlying path
#define DECLARATION_LMM_BACK_PARAMETRIC_INTERPOLATION_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLiborMMBackParametricInterpolation)
// Macro instantiation for client LMM back parametric interpolation classes generating underlying path
#define INITIALISE_LMM_BACK_PARAMETRIC_INTERPOLATION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client LMM principal components classes generating underlying path
#define DECLARATION_LMM_PRINCIPAL_COMPONENTS_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLiborMMPrincipalComponents)
// Macro instantiation for client LMM principal components classes generating underlying path
#define INITIALISE_LMM_PRINCIPAL_COMPONENTS_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client CSRLiborMMInstrumentSelection classes generating underlying path
#define DECLARATION_LMM_INSTRUMENT_SELECTION_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLiborMMInstrumentSelection)
// Macro instantiation for client LMM principal components classes generating underlying path
#define INITIALISE_LMM_INSTRUMENT_SELECTION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client CSRLiborMMCalibrationObjectiveFunction classes generating underlying path
#define DECLARATION_LMM_CALIB_OBJ_FUNCTION_CLIENT(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRLMMObjectiveFunction_Factory)
// Macro instantiation for client LMM principal components classes generating underlying path
#define INITIALISE_LMM_CALIB_OBJ_FUNCTION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client uniform generator classes
#define DECLARATION_GENERATOR_CLIENT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRUniformRandomGeneratorClient)
// Macro instantiation for client uniform generator classes
#define INITIALISE_GENERATOR_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client method computing independent normal law from uniform ones
#define DECLARATION_GAUSSIAN_INVERTION_CLIENT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRGaussianInvertionClient)
// Macro instantiation for client method computing independent normal law from uniform ones
#define INITIALISE_GAUSSIAN_INVERTION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client method computing a brownian path from normal law
#define DECLARATION_BROWNIAN_CONTRUCTION_CLIENT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRBrownianPathConstructionClient)
// Macro instantiation for client method computing a brownian path from normal law
#define INITIALISE_BROWNIAN_CONTRUCTION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)


// Macro declaration for client method computing a brownian path from normal law
#define DECLARATION_YIELD_CURVE_LIGHT_CLIENT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRYieldCurveLightClient)
// Macro instantiation for client method computing a brownian path from normal law
#define INITIALISE_YIELD_CURVE_LIGHT_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client class handling regression for American Monte Carlo
#define DECLARATION_REGRESSION_CLIENT(derived) DECLARATION_PROTOTYPE(derived, sophis::finance::CSRRegressionClient)
// Macro instantiation for client class handling regression for American Monte Carlo
#define INITIALISE_REGRESSION_CLIENT(className, name) INITIALISE_PROTOTYPE(className, name)

// Macro declaration for client class handling regression for American Monte Carlo
#define DECLARATION_SOLVER(derived) DECLARATION_PROTOTYPE(derived, sophis::math::Solver)
// Macro instantiation for client class handling regression for American Monte Carlo
#define INITIALISE_SOLVER(className, name) INITIALISE_PROTOTYPE(className, name)



//	Some default value for algorithm

/**   Identifier for the default diffusion model used to compute underlying paths.
*/
#define DEFAULT_PATH_GENERATOR			"PieceWise NMU"

/**   Identifier for the default diffusion model used to compute underlying paths.
*/
#define DEFAULT_INTEREST_RATE_PATH_GENERATOR "Deterministic Interest Rate"

/** Identifier for the default libor market model front parametric interpolation model.
*/
#define DEFAULT_LMM_FRONT_PARAMETRIC_INTERPOLATION "Simple"

/** Identifier for the default libor market model back parametric interpolation model.
*/
#define DEFAULT_LMM_BACK_PARAMETRIC_INTERPOLATION "Simple"

/** Identifier for the default libor market model principal component model.
*/
#define DEFAULT_LMM_PRINCIPAL_COMPONENTS "Standard Correlation PCA"

#define DEFAULT_LMM_INSTRUMENT_SELECTION "Standard"

#define DEFAULT_LMM_CALIB_OBJ_FUNCTION "Standard"


/** Identifier for the default algorithm used to generate a Brownian path from normal law sample.
*/
#define DEFAULT_BROWNIAN_PATH_METHOD	"Forward construction"

/**	Identifier for the default algorithm used to generate compute law from uniform ones.
*/
#define DEFAULT_ALGO_NORMAL_LAW			"Box Muller"

/**	Identifier for the default algorithm used to correlate Brownian motion.
*/
#define DEFAULT_CORRELATION_METHOD		"Cholesky at Maturity"

SPH_PROLOG
namespace sophis {
	namespace math {
		class CSRLMMInstrument;
		class CSRLMMObjectiveFunction;
		class Solver;
	}
	namespace tools {
		class CSRArchive;
	}
	namespace gui {
		class CSRMonteCarloDefaultSpecificDialog;
		class CSRMonteCarloMMDialog;
		class CSRFitDialog;

		/** Monte Carlo metamodel dialog.
		* 
		*/
		class SOPHIS_MONTECARLO CSRMonteCarloGeneralTab : public gui::CSRInstrumentTabPage
		{
		public:
			/** Constructor.
			*/
			CSRMonteCarloGeneralTab(CSRMonteCarloMMDialog &globalDialog);

			/** Enum mapping elements of the general Monte Carlo metamodel dialog.
			*	Start after 1000 when you add tab with toolkit.
			*/
			enum eOptionMonteCarloGeneralDialog 
			{
				qMCBrownianPathMethod = 10,
				qMCstepSize,			
				qMCCorrelationMethod,	
				qMCNormalAlgorithm,
				qMCUniformAlgorithm,
				qMCPathGeneratorMethod,
				qMCSamplingCount,
				qMCChooseGreeksForSimulation,
				qMCSequenceShift,
				qMCInterestRatePathGeneratorMethod,

				// To choose greeks in simulation
				eMCDeltaGammaForSimulation = 40,
				eMCDeltaEpsilonForSimulation,
				eMCCrossedGammaForSimulation,
				eMCDeltaGammaFXForSimulation,
				eMCVegaForSimulation,
				eMCCrossedVegaForSimulation,
				eMCRhoConvexityForSimulation,
				eMCThetaForSimulation,
				eMCTickUntickAll,
				eMCCreditDeltaGammaForSimulation = 1060,
				eMCCreditCrossedGammaForSimulation,
				eMCRecoveryRateSensitivityForSimulation,

				eMCStandardDeviationCheck = 1051,
				eMCUnderlyingForwardPriceCheck,
				eMCIndicatorList,
				eMCStandardDeviation,

				eMCLMMCurrency = 22122,
				eMCLMMReferenceLibor,
				eMCLMMFrontParamInterp,
				eMCLMMBackParamInterp,
				eMCLMMPrincipalComponents,
				eMCLMMPCADimension,
				eMCLMMGlobalShift,

				eMCLMMLambdaFrequency = 22222,
				eMCLMMLambdaTenorFrequency,
				eMCLMMLambdaInterpOrder,
				eMCLMMInstrumentSelection,
				eMCLMMCalibObjFunc,
				eMCLMMSkewList,
				eMCLMMLambdaList,
				eMCLMMMeanReversion,
				eMCLMMVolOfVol,
				eMCLMMDEIter,
				eMCLMMBFGSIter,
				eMCLMMLocalCalib,

				eMCLMMInstrSelSwapLoad = 22322,
				eMCLMMInstrSelSwapList,
				eMCLMMInstrSelCapLoad,
				eMCLMMInstrSelCapList,
				eMCLMMInstrSelMaxMaturity,

				eMCLMMObjFunVegaScaling = 22422,
				eMCLMMObjFunWeightSwap,
				eMCLMMObjFunWeightCap,
				eMCLMMObjFunWeightdGdMat,
				eMCLMMObjFunWeightdGdTenor,
				eMCLMMObjFunWeightd2GdMat2,
				eMCLMMObjFunWeightd2GdTenor2,
				eMCLMMObjFunChi2Swap,
				eMCLMMObjFunChi2Cap,
				eMCLMMObjFunChi2dGdMat,
				eMCLMMObjFunChi2dGdTenor,
				eMCLMMObjFunChi2d2GdMat2,
				eMCLMMObjFunChi2d2GdTenor2,

				eMCLocalVolatilityDiffusionMethod = 22400,
				eMCLocalVolatilityGridType,
				eMCLocalVolatilityPointCount,
				eMCLocalVolatilityMinPointCount,
				eMCLocalVolatilityMaxPointCount,
				eMCLocalVolatilityGrowFactor,
				//eMCLocalVolatilityStandardDeviationFactor,
				eMCLocalVolatilityExtremeMin = eMCLocalVolatilityGrowFactor+2,
				eMCLocalVolatilityExtremeMax,
				eMCLocalVolatilityExtremePointModulo,

				qMCNextDialogElem = 60
			};

			/**Validates an element in the context.
			When selection moves from one element of the dialog to another one, the method CSRElement::Validation()
			of the current element is called and (if the call ends succesfully) so is CSRFitDialog::ElementValidation().
			You override the method in order to :
			- check the coherence of the current setting
			- take an appropriate action with respect to the current context.
			@param EAId_Modified is the absolute ID of the modified element
			*/
			virtual	void	ElementValidation(int EAId_Modified);


			/**
			* @Return the maximal step size in days enabled.
			*/
			static int GetMaxStepSizeInDays();

			/**
			* @Return the maximal sampling count to use in sophis convention (e.g the real one is 50 times greater).
			*/
			static int GetMaxSamplingCount();

		protected:
			/** Internal obect to manage tab dialog.
			*/
			CSRMonteCarloMMDialog &fGlobalDialog;
		};

		/** American Monte Carlo dialog.
		* 
		*/
		class SOPHIS_MONTECARLO CSRAmericanMonteCarloTab : public gui::CSRInstrumentTabPage
		{
		public:
			/** Constructor.
			*/
			CSRAmericanMonteCarloTab(CSRMonteCarloMMDialog &globalDialog);

			/** Enum mapping elements of the general Monte Carlo metamodel dialog.
			*	Start after 1000 when you add tab with toolkit.
			*/
			enum eAmericanMonteCarloDialog
			{
				eAMCNbIterations = 500,
			};

			/**
			* @Return the minimum number of iteration to use in sophis convention.
			*/
			static int GetMinNbIterations();
			
			/**
			* @Return the maximal number of iteration to use in sophis convention.
			*/
			static int GetMaxNbIterations();


		};
	}



	namespace finance {
		class CSRVolPointForCalibrationData;

		/**	Some forward declaration
		*/
		class CSROptionMonteCarloInterface;
		class CSRServerPayoff;
		class CSRLocalPath;
		class CSRClientPayoff;
		class CSRLocalPathGeneratorClient;
		class CSRServerOutput;
		class CSRClientOutput;
		class CSRUniformRandomGenerator;
		class MonteCarloGridAdapter;
		class CSRClientComputationObject;
		class CSROptionMonteCarloMetaModel;
		class CSRVolPointForCalibrationData;

		struct eUnderlyingType
		{
			bool isAForex;
			bool isAVegaUnderlying;
			bool isADeltaUnderlying;
		};

		/** Enumeration for greeks we want to compute
		*/
		enum eGreeksToCompute
		{
			eGTCDeltaGamma,			// computation of delta and diagonal gamma
			eGTCDeltaEpsilon,		// computation of epsilon
			eGTCCrossedGamma,		// computation of crossed gamma
			eGTCDeltaGammaFX,		// computation of FOREX delta and gamma
			eGTCVega,				// computation of vega
			eGTCCrossedVega,		// computation of crossed vega (sega)
			eGTCRhoConvexity,		// computation of rho and convexity
			eGTCTheta,				// computation of theta
			eGTCCreditDeltaGamma,	// computation of credit sensitivities and convexities
			eGTCCreditCrossedGamma,	// computation of credit crossed sensitivities
			eGTCRecoverySensitivity,	// computation of recovery rate sensitivities
			eGTCAdvancedGreeks		// computation of vanna, volga, speed, zomma and DVegaDTime
		};

		/** Internal Use. An enum for different types of computation :
		* 	emccsStandAlone			= stand alone computation : Deprecated since 5.3.0
		*	emccsCreateArchive		= Create archive in order to initialize object needed for distributed computation
		*	emccsAggregateResults	= Aggregate results from archive storing results of the distributed Monte Carlo simulation
		*/
		enum eMonteCarloComputationState
		{
			emccsStandAlone,		// stand alone computation.
			emccsCreateArchive,		// Archive creation before remote computation
			emccsAggregateResults	// Result aggregation after remote computation
		};
				 
		/**
		*	An interface class collecting computation results in order to display them after distributed computation.
		*/
		class SOPHIS_MONTECARLO CSRDisplayInformation
		{
		public:
			/**
			*	Default constructor
			*/
			CSRDisplayInformation(){};

			/**
			*	Accessor to a computation results : the two parameters are filled in output.
			*	@param greekName is a STL string storing result ID (theoretical, delta and so on).
			*	@param greekValue store the result value.
			*/
			virtual void GetGreekInformation(_STL::string& greekName, double& greekValue) const = 0;
		};

		//------------------------------------------------------------------------------
		// CSRYieldCurveLight
		//------------------------------------------------------------------------------
		class SOPHIS_MONTECARLO CSRYieldCurveLightClient
		{
		public:
			CSRYieldCurveLightClient();
			virtual ~CSRYieldCurveLightClient();

			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			virtual void Initialise(const market_data::CSRMarketData	&marketData,
									const instrument::CSRInstrument		*instr,
									const CSROptionMonteCarloMetaModel	*model,
									long								exerciseCurrency);

			virtual _STL::string GetServerSideID() const = 0;

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRYieldCurveLightClient* Clone() const = 0;

			/** Internal for prototypal instantiation.
			 */
			typedef	sophis::tools::CSRPrototype<CSRYieldCurveLightClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

		protected:
			long fToday;
			/**
			* Boolean value to know if we must extrapolate after the last zero coupon
			*/
			bool fMustExtrapolate;
		};

		/**
		* The basic implementation which use a map of zero coupon for alla asked dates.
		* In case of a compound factor asked at a not expected date the discount factor are 
		* interpolated by using {@link GetInterpolatedZeroCoupon}
		*/
		class SOPHIS_MONTECARLO CSRYieldCurveLightWithAllZeroCouponClient : public virtual CSRYieldCurveLightClient
		{
		public:
			DECLARATION_YIELD_CURVE_LIGHT_CLIENT(CSRYieldCurveLightWithAllZeroCouponClient)
			CSRYieldCurveLightWithAllZeroCouponClient();
			virtual ~CSRYieldCurveLightWithAllZeroCouponClient();

			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			virtual void Initialise(const market_data::CSRMarketData	&marketData,
									const instrument::CSRInstrument		*instr,
									const CSROptionMonteCarloMetaModel	*model,
									long								exerciseCurrency);

			virtual _STL::string GetServerSideID() const ;

		protected:
			_STL::map<long,double> fZeroCouponMap;
		};

		/**
		* Basis structure containing specific information for Monte Carlo model.
		*/
		struct SOPHIS_MONTECARLO SSMonteCarloSpecificParameter 
		{
			/**  Identifier of the path generator model.
			*	For compatibility with oracle table this string must be less than 40 characters long.
			*
			*	@see sophis::finance::CSRLocalPathGeneratorClient
			*/
			_STL::string	pathGeneratorID;

			/**  Identifier of the interest rate path generator model.
			*	For compatibility with oracle table this string must be less than 40 characters long.
			*
			*	@see sophis::finance::CSRInterestRateLocalPathGeneratorClient
			*/
			_STL::string	interestRateLocalPathGeneratorID;

			/**  Discretization size in days for algorithm needing small time step size.
			*/
			int				stepSize;

			/**  Sampling count to use in the simulation.
			*/
			int				samplingCount;

			/**  Identifier of algorithm .
			*	For compatibility with oracle table this string must be less than 40 characters long.
			*
			*	@see sophis::finance::CSRGaussianInvertion
			*/
			_STL::string	algoNormalLaw;
			
			/**  ID of the path generator model.
			*	For compatibility with oracle table this string must be less than 40 characters long.
			*
			*	@see sophis::finance::CSRClientCorrelation
			*/
			_STL::string	algoCorrelation;
			
			/**  ID of the path generator model.
			*	For compatibility with oracle table this string must be less than 40 characters long.
			*
			*	@see sophis::finance::CSRBrownianPathConstruction
			*/
			_STL::string	brownianPathMethod;

			/**  ID of the uniform law generator model.
			*/
			_STL::string   uniformLawMethod;

			/** A shift to apply to the uniform random generator: instead of using sampling
			*	from 1 to N the sampling used will be the one between 1+fSequenceShift and N+fSequenceShift.
			*/
			int sequenceShift;

			/** For the American Monte Carlo
			*	The number of iterations of the algorithm
			*/
			int nbIterations;

		};


		/** Metamodel for the New Monte-Carlo.
		*	This class contains all pricing methods specific to the New Monte-Carlo model
		*	which were in CSROptionMonteCarloInterface in version 5.2
		*	@since 5.3
		**/
		class CSRControlInstrument;
		class SOPHIS_MONTECARLO CSROptionMonteCarloMetaModel : public virtual CSRMetaModel
		{
		public:
			DECLARATION_META_MODEL(CSROptionMonteCarloMetaModel)

			/** Copy constructor.
			*/
			CSROptionMonteCarloMetaModel(const CSROptionMonteCarloMetaModel &model);

			/** Assignation.
			*/
			CSROptionMonteCarloMetaModel & operator =(const CSROptionMonteCarloMetaModel &model);

			/** Destructor.
			*/
			virtual ~CSROptionMonteCarloMetaModel();

			virtual void GetRiskSources(const sophis::instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
			virtual void SetComputationResults(sophis::CSRComputationResults& results) const OVERRIDE;

			/** Creation of the associated dialog for supplementary data.
			The dialog does not need to be fitted with the derived class, only with the default values.
			@return a new dialog which will be deleted later on. Returns 0 if no supplementary data.
			@since 5.3
			*/
			virtual gui::CSRFitDialog * new_Dialog() const;

			/** Creation of the associated dialog for displaying data.
			@parameter instrument is the instrument where the dialog is opened
			@return a new dialog which will be deleted later on. Returns 0 if no supplementary data.
			@since 5.3
			*/
			virtual gui::CSRFitDialog * new_ReadDialog(const instrument::CSRInstrument * instrument) const;

			/** Retrieves the parameters of the metamodel (such as step size, brownian generation method...)
			*	If fInitParameters is true, it will read those parameters from the database using LoadSpecificElement
			*   and store them in fParameters
			*	otherwise it will simply return fParameters
			*	@return the parameters of the metamodel
			*/
			SSMonteCarloSpecificParameter& GetParameters() const;

			//--------------------------------	Inherited from CSRMetaModel	---------------------------------------------

			/** Initializes the metamodel prior to a RecomputeAll, GetTheoreticalValue or Greek computation
			*	this method is called by InitialiseMetaModel
			*	default implementation does the following:
			*	- register the client payoff from the instrument
			*	- initializes the client payoff and diffused underlyings
			*	- fills the mappings vector fUnderlyingInOption and fUnderlyingInModel
			*	- fills fEquityCount, fForexCount, fCurrencyCount and fForexQuantoChangeCorrection
			*	@parameter instrument is the instrument to which the metamodel is applied
			*	@parameter marketData is the computation data used
			*	@parameter computeGreeks is true when the model will be used to compute at least one greek
			*	after initialization
			*	@return true if the initialization succeeded
			*/
			virtual bool InitialiseDataFromInstrument(	const instrument::CSRInstrument		&instrument,
														const market_data::CSRMarketData	&marketData,
														bool								computeGreeks);

			/** Initializes the meta model of this instrument.
			* Creates a clone of this, assigns it to instrument->GetMetaModel() and calls InitialiseDataFromInstrument
			* For optimization, if fIsInitialized is true and forceLoading is false, and if the payoff has been correctly registered,
			*	this method will not attempt to reinitialize the model
			@param instrument is the instrument to price.
			@param marketData is a market data.
			@param computeGreeks is asking for Greek context loading (parameter given to {@link InitialiseDataFromInstrument}.
			@param forceLoading is a boolean to force the loading and go to optimise mode.
			* @return false if the initialization of data has failed.
			* @see CSRInstrument::GetMetaModel.
			*/
			virtual bool InitialiseMetaModel(	const instrument::CSRInstrument		&instrument,
												const market_data::CSRMarketData	&marketData,
												bool								computeGreeks,
												bool								forceLoading = false) const;

		public:
			/** Release the meta model if no optimisation.
			Call that method at the end of your calculation.
			@param instrument is the instrument to price.
			@param forceLoading is a boolean to force the release and go to non-optimise mode.
			*/
			virtual void ReleaseMetaModel(	const instrument::CSRInstrument		&instrument,
											bool								forceRelease = false) const;

			/** Test if the meta model knows to price this kind of instrument.
			@return true if the instrument is valid for this model.
			By default, use the basic test implemented in 4.5.1
			*/
			virtual bool	ValidInstrument(const instrument::CSRInstrument & instrument) const;

			/** Get the fair value of the instrument.
			@param instrument is the instrument to price.
			@param context is a market data.
			@return the fair value in the same unit as the last, but with accrued coupon included
			so that the total value of the position is GetQuotity()*GetTheoriticalValue().
			This is the main method to overload, to implement a meta model. All other methods have
			a default implementation by finite difference of that function. This function is also directly
			called in most of the scenarios. Note that the fair value displayed, generally differs from the
			result of this one by a possible accrued coupon.
			The fair value must be calculated using the P&L volatility, assuming the delivery is in
			{@link GetSettlementDate}.
			By default, call the version with a graph.
			*/
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;

			/** Computes the value and fills in the explanation (for caps and floors)
			*/
			virtual double	GetTheoreticalValue(const instrument::CSRInstrument			&instrument, 
									const market_data::CSRMarketData		&context, 
									_STL::vector<instrument::SSCaplet>		*vectorToFill,
									instrument::CSRCashFlowInformationList* explanation, 
									int										startFlowIndex = -1,
									int										endFlowIndex   = -1) const;

			virtual double	ComputeDirtyPrice(	const instrument::CSRInstrument				&instr,
											long							transactionDate,
											long							settlementDate,		
											long							ownershipDate,
											const market_data::CSRMarketData				&param,
											double							*derivee,
											const static_data::CSRDayCountBasis			*base,
											short							adjustedDates,
											short							valueDates,
											const static_data::CSRDayCountBasis			*dayCountBasis,
											const static_data::CSRYieldCalculation		*yieldCalculation,
											_STL::vector<instrument::SSRedemption>		*redemptionArray,
											_STL::vector<instrument::SSBondExplication>	*explicationArray) const;

			/** Get delta and gamma to display in the pricing window.
			@param context is a market data.
			@param price is the fair value (coming from RecomputeAll).
			@param delta is the delta expressed in the currency of the instrument (coming from RecomputeAll).
			@param gamma is the gamma expressed in the currency of the instrument (coming from RecomputeAll).
			@param which is index between 0 (included) and GetUnderlyingCount() (excluded).
			@param deltaOut is the delta expressed in the currency of the instrument to show in the pricing window.
			@param gammaOut is the gamma expressed in the currency of the instrument to show in the pricing window.
			*/
			virtual void	GetDeltaGammaInPricingWindow(	const instrument::CSRInstrument& instr,
															const market_data::CSRMarketData& context,
															const sophis::CSRComputationResults& results,
															double							price,
															double							delta,
															double							gamma,
															int							which,
															double							&deltaOut,
															double							&gammaOut) const OVERRIDE;


			/** Get the epsilon (sensibility to the dividend risk).
			@param instrument is the instrument to price.
			@param context is a market data.
			@param whichUnderlying is in index between 0 included and GetUnderlyingCount() excluded.
			@return the epsilon for an increase of 10% of dividends.
			By default, return 0 for a risk sources different from a share or an index otherwise calculate a finite difference 
			calling twice GetTheoreticalValue
			*/
			virtual double	GetEpsilon(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which) const ;

			/** Get the rho of one currency risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param which is in index between 0 (included) and GetRhoCount() (excluded).
			@return the rho expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1% of the zero coupon curve.
			The rho must be calculated using the risk volatility.
			The rho is supposed to be partial assuming that the underlying risk source (even if it is a future)
			does not move.
			The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}.
			The fact that the user can choose to display the rho for a bump of one basis point
			is not part of this method, but part of the GUI.
			This method may be called during a scenario (for instance a risk matrix of rho).
			By default, the algorithm is:
			- Ask {@link GetDerivationParameters} with gpRho to get the bump choosed.
			- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
			- Calculates the finite difference calling {@link GetTheoriticalValue}.
			- Expresses the result for 1% variation.
			*/
			virtual double	GetRho(const instrument::CSRInstrument & instrument,const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const;

			/** Get the convexity of one currency risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param which is in index between 0 (included) and GetRhoCount() (excluded).
			@return the convexity expressed in the currency of the instrument as a variation
			of the rho, for a variation of 1% of the zero coupon curve.
			The convexity must be calculated using the Risk volatility.
			The convexity is supposed to be partial assuming the underlying risk sources (even if it is a future)
			does not move.
			The meaning of a bump of of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}
			The fact that the user can choose to display the convexity for a bump of one basis point
			is not part of this method, but part of the GUI.
			This method may be called during a scenario.
			By default, the algorithm is:
			- Ask {@link GetDerivationParameters} with gpRho to get the selected bump.
			- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
			- Calculates the finite difference calling {@link GetTheoriticalValue}.
			- Expresses the result for a 1% variation..
			*/
			virtual double	GetConvexity(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const;

			/** Get the rho and the convexity of one currency risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param price is the fair value calculated using the risk volatility.
			@param rho is the output parameter for the rho expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1% of the zero coupon curve.
			@param convexity is the output parameter for the convexity expressed in the currency of the instrument as a variation
			of the rho, for a variation of 1% of the zero coupon curve.
			@param which is in index between 0 (included) and GetRhoCount() (excluded).
			The rho and convexity must be calculated using the risk volatility.
			They are supposed to be partial, assuming the underlying risk source (even if it is a future)
			does not move.
			The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}
			The fact that the user can choose to display the rho and the convexity for a bump of one basis point
			is not part of this method, but part of the GUI.
			This method is called By CSRInstrument::RecomputeAll to save calculation.
			By default, the algorithm is:
			- Ask {@link GetDerivationParameters} with gpRho to get the selected bump.
			- Creates a new market data switching the volatility and bumping {@link CSRMarketData::GetOverRate}.
			- Calculates the finite difference calling {@link GetTheoriticalValue}.
			- Expresses the result for 1% variation.
			*/
			virtual void	GetRhoConvexity(const instrument::CSRInstrument		&instrument,
											const market_data::CSRMarketData	&context,
											double 				 				price,
											double 				 				*rho,
											double 				 				*convexity,
											int 									 				which,
											instrument::eRhoBumpType								rhoBumpType) const;


			/** Get the price, delta and gamma of one risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param price is an output paramater the fair value.
			@param delta is the output parameter for the delta expressed in the currency of the instrument as a variation
			of the fair value, for a variation of 1 of the underlying spot.
			@param gamma is the output parameter for the gamma expressed in the currency of the instrument as a variation
			of the delta, for a variation of 1 of the underlying spot.
			@param which is index between 0 (included) and GetUnderlyingCount() (excluded).
			All, including price must be calculated using the Risk volatility.
			The meaning of a bump of 1% is defined by {@link CSRPreference::GetDayCountBasisTypeForRho} and {@link CSRPreference::GetYieldCalculationTypeForRho}.
			This method is called By CSRInstrument::RecomputeAll to save calculation,
			by the method CSRInstrument::GetFirstDerivative and GetSecondDerivative,
			as well as scenarios like risk matrix, asking for price, delta and gamma.
			By default, the algorithm is:
			- Ask {@link GetDerivationParameters} with gpDelta to get the selected bump.
			- Ask {@link GetSmileInDeltaGamma} to get the desired method for taking the smile into account.
			- Creates a new market data, switching the volatility
			- Bumps {@link CSRMarketData::GetSpot} or {@link CSRMarketData::GetForex} if it is an FX.
			- Bumps also {@link CSRMarketData::GetSpotForVolatility} if the smile has to be included in delta and/or gamma.
			- Do the finite difference.
			- Calculates the finite difference calling {@link GetTheoriticalValue}.
			@version 4.4 In case the underlying is a currency and CSRPreference::ForexFinancing is on,
			the delta and gamma are corrected to be expressed in the function of the day spot, rather than on the
			spot delivery in two days.
			@version 4.1.1 The algorithm has been reviewed so that the smile effect is always included
			in that function. That is why {@link GetPriceSmiledDeltaGamma} has been deprecated.
			*/
			virtual void	GetPriceDeltaGamma(	const instrument::CSRInstrument & instrument,
												const market_data::CSRMarketData& context,
												double				*price,
												double				*delta,
												double				*gamma,
												int 				whichUnderlying) const;

			/** Get the delta of one instrument risk source.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
			@return the delta expressed in the currency of the instrument as a variation
			of the fair value, for a variation 1 of the underlying.
			The delta must be calculated using the Risk volatility.
			By default, calls {@link GetPriceDeltaGamma}
			*/
			virtual double			GetFirstDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int whichUnderlying) const;

			/** Get the gamma of the risk source for two instruments.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param which1 is in index between 0 (included) and GetUnderlyingCount() (excluded).
			@param which2 is in index between 0 (included) and GetUnderlyingCount() (excluded).
			@return the gamma or crossed gamma expressed in the currency of the instrument as a variation
			of the delta of one instrument, for a variation 1 of the others.
			The gamma must be calculated using the risk volatility.
			By default, calls {@link GetPriceDeltaGamma} if which1 equals which2, otherwise it calculates
			by finite difference, using the smile calculation hypotheses.
			*/
			virtual double	GetSecondDerivative(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context, int which1, int which2) const;

			/** Get the vega of one instrument risk source.
			If the instrument is a currency, the risk is supposed to be with the forex instrument/currency volatility.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param whichUnderlying is in index between 0 included and GetUnderlyingCount() excluded.
			@return the vega expressed in the currency of the instrument as a variation
			of the fair value for a variation 1 of the underlying.
			The vega must be calculated using the Risk volatility.
			This method may be called during a scenario (for instance a risk matrix of vega).
			It is called also by {@link CSRInstrument::RecomputeAll}.
			By default, the algorithm is
			- Ask {@link GetDerivationParameters} with gpVega to get the bump choosed.
			- Creates a new market data switching the volatility and bumping it using {@link CSRMarketData::GetVolat}
			- Calculates the finite difference calling {@link GetTheoriticalValue}
			- Expresses the result for 1% variation.
			*/
			virtual double	GetVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int whichUnderlying) const;

			/** Get the crossed vega (sensibility to a correlation) of one instrument risk source.
			If the instrument is a currency, the source risk is supposed to be the forex instrument/currency.
			@param instrument is the instrument to price.
			@param context is a market data.
			@param whichUnderlying is in index between 0 included and GetUnderlyingCount() excluded.
			@return the vega expressed in the currency of the instrument as a variation
			of the fair value for a variation 1 of the underlying.
			The crossed vega must be calculated using the Risk volatility.
			This method may be called during a scenario (for instance a risk matrix of vega).
			It is called also by {@link CSRInstrument::RecomputeAll} if crossed vega preference is ticked on.
			By default, the algorithm is
			- Ask {@link GetDerivationParameters} with gpVega to get the bump choosed.
			- Creates a new market data switching the volatility and bumping the correlation using {@link CSRMarketData::GetCorrelation}
			- Calculates the finite difference calling {@link GetTheoriticalValue}
			- Expresses the result for 1% variation.
			*/
			virtual double	GetCrossedVega(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context,int which1, int which2) const;

			/** Get the theta.
			@param instrument is the instrument to price.
			@param context is a market data.
			@return the theta for one day (according the preference {@link CSRPreference::GetThetaDateType}.
			The default algorithm is :
			- Ask for theta preferences using {@link CSRPreference::GetThetaCorrection}.
			- Ask for a theta market data using {@link new_ThetaComputationContext}
			- if null retun 0
			- else calculate the finite difference calling twice {@link GetTheoreticalValue}.
			- check if {@link CSRPreference::IntegrateCouponInTheta()} is on to integrate the amount using {@link CERIntrument::GetCouponAmount}.
			*/
			virtual double	GetTheta(const instrument::CSRInstrument & instrument, const market_data::CSRMarketData &context) const;

			virtual double GetVanna(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;
			virtual double GetVolga(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;
			virtual double GetSpeed(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;
			virtual double GetZomma(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;
			virtual double GetDVegaDTime(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;
			virtual double GetDeltaBleed(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const;

			virtual double GetLegTheoreticalValue(const sophis::instrument::CSRInstrument& instrument, const sophis::market_data::CSRMarketData& context, int which) const OVERRIDE;

			/** Get the credit risk sensitivity and convexity from the reference price and individual sensitivities.
			@param context is market data.
			@param refPrice is the derivative price without any bump.
			@param sensitivity is for the output computed sensitivity.
			@param convexity is for the output computed convexity.
			@param creditGreeks is structure to store credit delta and gamma according to each credit risk source (can be set to NULL pointer to avoid computation
			@param computeCrossedGammas is to tell if crossed credit greeks are to be computed (computeSingleDeltaGamma is mandatory for this)
			*/
			virtual void	ComputeCreditRiskSensitivities(	const instrument::CSRInstrument		&instrument,
															const market_data::CSRMarketData	&context, 
															const sophis::CSRComputationResults &results,
															double								refPrice,
															double								&sensitivity,
															double								&convexity,
															bool								computeCrossedGammas,
															bool								computeAllCreditDeltaGamma = true) const OVERRIDE;

			/** Get the recovery rate sensibility.
			@param instrument is the instrument.
			@param context is a market data.
			@return the recovery rate sensibility expressed in the currency of the instrument as a variation of the recovery rate of 1%.
			1% has to be understood using CSRPreference::GetDayCountBasisTypeForRho() && CSRPreference::GetYieldCalculationTypeForRho().
			It is called by {@link CSRInstrument::RecomputeAll}.
			The default algorithm is as follows:
			- test whether it has any issuer dependency calling {@link GetIssuerArray}.
			- if no, return 0.
			- if yes, create a new market data bumping all CDS curves using {@link CSRCreditRisk::RecoveryRateShift}.
			- calculate the finite difference $\f \frac{f(x+h)-f(h)}{h} $\f
			using {@link GetTheoreticalValue} with $\f h $\f is 0.01 percent.
			@since 4.1.3
			*/
			virtual double	GetRecoveryRateSensitivity(	const instrument::CSRInstrument&	instrument, 
														const market_data::CSRMarketData&	context) const;


			//--------------------------------	Specific methods to MonteCarlo MetaModel	---------------------------------------------
			/**	Stores the archives required for a theoretical price or a price difference in Greeks and returns 0
			*	when the Monte-Carlo computation state is emccsCreateArchive,
			*	or returns the theoretical price or price difference
			*	when the Monte-Carlo computation state is emccsAggregateResults
			*	@parameter task is the task number in the computation sequence, from 0 to fTaskCompteur
			*	@parameter context is the market data
			*	@parameter instrument is the instrument to which the model is applied
			*	@parameter clientOutput is the output object to fill when computation state is emccsAggregateResults
			*   @parameter bumpKey is a SSBumpKey allowing to know which computation is currenctly done.
			*	@return 0 when archiving, of the theoretical price when retrieving a price from the server
			*		or a price difference in the strike currency when retrieving a Greek from the server
			*	@version 5.3 moved this method from class CSRClientComputationObject to class CSROptionMonteCarloMetaModel
			*/
			virtual double  FinalizeResults(	int									task,
												const market_data::CSRMarketData	&context,
												const instrument::CSRInstrument		&instrument, 
												CSRClientOutput						*clientOutput,
												const SSBumpKey						&bumpKey) const;

			/** Sets the payoff to use by the metamodel
			*   @parameter payoff is the payoff object to use
			*	@parameter todelete tells whether payoff must be deleted after computations
			*	@since 5.3
			*/
			void	RegisterClientPayoff(CSRClientPayoff* payoff, bool todelete);

			/** Returns the payoff used
			*	it is initialized in InitialiseDataFromInstrument
			*	and deleted in the destructor of CSROptionMonteCarloMetaModel if needed
			*	@since 5.3
			*/
			CSRClientPayoff*	GetRegisteredClientPayoff() const;

			/** This method is used to define risk sources. If we need to add a forex in the diffusion 
			*	like for quanto/compo effect we can prefer to add liquid pair where volatility data are reliable.
			*	If we need to add a forex A/B we will add A/Pivot and Pivot/B. Default implementation returns 
			*	strike currency, unless when pricing a quanto forex outside the class CSROptionMonteCarloInterface,
			*	in which case this is the option currency
			*	@parameter instrument is the instrument to which the metamodel is applied
			*	@return the pivot currency for the deltas and vegas
			*/
			virtual long GetPivotCurrency(const instrument::CSRInstrument &instrument) const;

			/** This is the generic method to call in order to compute greeks.
			*	The theoretical price is computed if necessary and price for greeks are
			*	returned as the difference from this reference price.
			*	@param basicContext is the basic market data used to compute basic price.
			*	@param contextForGreeks is a vector of context for which difference in price from basic context will be computed.
			*	@param basicTheoreticalValue is an output parameter corresponding to the basic price.
			*	@param differencePriceForGreeks is is an output parameter corresponding tothe vector of difference in price.
			*	@param bumpKeyVector is a vector of {@link SSBumpKey} identifying computation done in order to compute greeks. This allow optimisation
			*		   of memory/bandwidth cunsumption.
			*/
			void	ComputeDifferencePriceForGreeks(const instrument::CSRInstrument						&instrument,
													const market_data::CSRMarketData					&basicContext,
													sophis::CSRComputationResults& results,
													_STL::vector<const market_data::CSRMarketData *>	&contextForGreeks, 
													double												&basicTheoreticalValue, 
													_STL::vector<double>								&differencePriceForGreeks,
													const _STL::vector<SSBumpKey>&						bumpKeyVector) const;

			/** Give a pointer on client path generator object dedicated to the option in order to generate underlying path.
			*/
			CSRLocalPathGeneratorClient*	GetPathGenerator(const instrument::CSRInstrument &instrument) const;

			/**
			* Erase path generator in order to force reloading. Internal Use
			*/
			void CleanPathGenerator();

			/**	Returns the registered name of the uniform generator used for 
			*		Monte Carlo Simulation (Default implementation is one of the Sophis sobol generator ID or a ran4 generator
			*		according to the preference UseOldSobolGenerator).
			*/
			virtual _STL::string GetUniformGeneratorID() const;

			/**
			* Returns the registered name of the method used to generate a brownianPath from independent increment.
			*/
			virtual _STL::string GetBrownianPathGenerationID() const;

			/**
			* Returns the registered name of the Gaussian cumulative invertion algorithm used for 
			* Monte Carlo Simulation (Default implementation is the Box Muller or the Moro's Algorithm ID
			* according to the preference UseMoroNInv).
			*/
			virtual _STL::string GetInvertionAlgorithmID() const;

			/** Internal.  Set the step size to use for time discretization.
			*/
			void SetStepSize(int stepSize);

			/**  Internal.  Give the step size to use for time discretization.
			*/
			int GetStepSize() const;

			/**  Internal.  Give the sequence shift to use for path generation.
			*/
			int GetSequenceShift() const;

			/**  Internal.  Give the number of iterations given from the user
			*/
			int GetNbIterationsFromUser() const;

			/**  Internal.  Give the number of iterations after knowing if it is an American
			*	option or an European one. (European = 1 iteration)
			*/
			int GetNbIterations() const;

			/** Give the current type of computation.
			*
			*	@return the current type of computation.
			*
			*	@see eMonteCarloComputationState.
			*/
			inline eMonteCarloComputationState GetMonteCarloComputationState() const {return fState;};

			/** Set the type of computation to be done 
			*
			*	@param state is the state.
			*
			*	@see eMonteCarloComputationState.
			*/
			inline void SetMonteCarloComputationState(eMonteCarloComputationState state) const {fState = state;};

			/** Check if a greek should be computed
			*	@param	resultToCompute is the greek we want to know if it should be computed.
			*	@see eGreeksToCompute
			*	@return true if the greek should be computed, else return false.
			*/	
			virtual bool		ComputeResults(	const instrument::CSRInstrument	&instrument,
												eGreeksToCompute				resultToCompute) const;

			/**	Set a pointer on the archive in which we store data needed to create objects on server side and 
			*		reference on a compteur storing the number of computation embedded in one distributed Monte Carlo 
			*		computation.
			*		@param	informationArchive is a pointer on the archive in which we store data needed to create objects on server side.
			*		@param	cpt store the number of computation embedded in one distributed Monte Carlo computation.
			*/
			void SetInformationArchive(const sophis::tools::CSRArchive* informationArchive, int* cpt) const;
			void SetStaticInformationArchive(const sophis::tools::CSRArchive* informationArchive, int* cpt) const;

			/**	Return a pointer on the archive in which we store data needed to create objects on server side.
			*/
			sophis::tools::CSRArchive*	GetInformationArchive() const;
			sophis::tools::CSRArchive*	GetStaticInformationArchive() const;

			/**	Set a pointer on the archive in which we had stored results of the distributed Monte Carlo simulation.
			* 		@param archiveResults is a pointer on the archive in which we store results of the distributed Monte Carlo simulation.
			*/
			void				SetResultArchive(const sophis::tools::CSRArchive* archiveResults) const;

			/**	Set a pointer on the archive in which we store part of the result independent of the Monte Carlo simulation
			*		needed to finalize price and greeks computation.(These data are filled before launching distributed Monte Carlo simulation).
			*/
			void				SetPreResultArchive(const sophis::tools::CSRArchive* preResultArchive) const;

			/**	Return a pointer on the archive in which we store part of the result independent of the Monte Carlo simulation
			*		needed to finalize price and greeks computation (when results of the distributed computation come back
			*		we don't have anymore the option or the market data for which we have done a Monte Carlo Simulation).
			*		@param preResultArchive is a pointer on the archive in which we store this data.
			*/
			sophis::tools::CSRArchive*	GetPreResultArchive() const;

			/**
			* Initialise some market data dependents info used for displaying results after parallel computation
			*/
			void InitialiseDataForDisplay(  const market_data::CSRMarketData&param,
											const instrument::CSRInstrument	&instrument,
											const CSRComputationResults& rs);

			/**	Method called by ShowResultsOnClientSide
			*	Fill a vector of results we want to display after performing a distributed computation
			*	for 1 instrument via the calculation server.
			*	@param displayInformation is the vector of information to display.
			*	@see CSRDisplayInformation
			*/
			virtual void FillInformationVector( const instrument::CSRInstrument		&instrument,
												const sophis::CSRComputationResults& results,
												_STL::vector<CSRDisplayInformation*>&displayInformation) const;

			/**
			*	Display the Graphic User Interface linked with the results coming back from distributed computation.
			*/
			virtual void ShowResultsOnClientSide(	const instrument::CSRInstrument &instrument,
													const market_data::CSRMarketData&param,
													const sophis::CSRComputationResults& results) const;

			/**
			* Internal method called before launching computation sequence in order to store static datas.
			*	@param contextGeneral is the global context for the pricing.
			*/
			void InitialiseStaticObject(const market_data::CSRMarketData&contextGeneral,
										const instrument::CSRInstrument	&instrument) const;

			/**
			*	If true, ConstructAgain will return true whenever fConstructionDate is not equal to gDateFinBase()
			*/
			bool ReConstructWhenApplicationDateChange() const;

			/**
			*  true when the instrument whould be contructed again
			*  @see CSROption::ContructAgain
			*/
			bool OptionToConstructAgain() const;

			/**
			*	Tells whether the product should be constructed again whenever fConstructionDate is not equal to gDateFinBase()
			*/
			void SetReConstructWhenApplicationDateChange(bool reConstructWhenApplicationDateChange);

			/** Return the underlying index in the option corresponding to an index in the model. 
			*	This is used because the model has specific assumptions on the order of risk sources
			*	for delta and vega
			*/
			//int GetOptionUnderlyingIndex(int modelUnderlyingIndex) const;

			/** Return the underlying index in the model corresponding to an index in the option. 
			*	This is used because the model has specific assumptions on the order of risk sources
			*	for delta and vega
			*/
			//int GetModelUnderlyingIndex(int optionUnderlyingIndex) const;

			/** Returns the number of equities that are to be considered as delta or vega risk sources
			*	Initialized in InitialiseDataFromInstrument
			*/
			//inline int GetEquityCount() const {return fEquityCount;};

			/** Returns the number of forex spots that are to be considered as delta or vega risk sources
			*	Initialized in InitialiseDataFromInstrument
			*/
			//inline int GetForexCount() const {return fForexCount;};

			/** Returns the number of currencies that are to be considered as delta or vega risk sources
			*	Initialized in InitialiseDataFromInstrument
			*/
			//inline int GetCurrencyCount() const {return fCurrencyCount;};
			
			/**  Internal. This buffer store spots values in order to take Gamma in percentage preference into account in distributed computation.
			*/
			mutable _STL::vector<double> fSpotForGamma;

			/**  Internal. To disable display from package.
			*/
			void	SetAllowDisplay(bool allowDisplay) const;

			/**  Internal. To disable display from package.
			*/
			bool	IsDisplayAllowed() const;

			/** Run calibration if needed and store result. It is called by the calibration scenario.
			By default this method does nothing.
			@param instrument is the instrument to price.
			@param context is the market data to use for calibration.
			@param alreadyCalibrated is a set to allow not to calibrate 2 times the same underlying for a given metamodel.
						It must be filled during calibration.
			@return true is the calibration was run successfully and results saved. By default return false.
			@since 5.3
			*/
			virtual bool RunCalibration(	const instrument::CSRInstrument				&instrument, 
											const sophis::market_data::CSRMarketData	&context,
											_STL::set<long>*							alreadyCalibratedUnderlying);

			/** Get the cash flow diagram if implemented.
			@return true if the cash flow diagram is computed at the metamodel level. False by default.
			@param instrument the instrument for which the cash flow must be computed
			@param context is a market data
			@param diag is a pointer to the cash flow diagram created
			This is used for the scenario cash flow diagram. It is also used to calculate the duration.
			@since 5.3
			@see CSRCashFlowDiagram
			*/
			virtual bool new_CashFlowDiagram(	const instrument::CSRInstrument&			instrument,
												const market_data::CSRMarketData&			context,
												sophis::instrument::CSRCashFlowDiagram*&	diag) const;
			//void GetCashFlowChart(const CSRClientOutput	*clientOutput, long optionCurrency, _STL::vector<SSCashFlowIndicator>& cashFlowVect) const;

			/** Fill dialog opened in read mode with some specific metamodel results.
			@param dlg the dialog to initialise
			@param instrument the instrument for which we initilaise the dialog
			@since 6.0
			*/
			virtual void InitialiseResultsInDialog(gui::CSRFitDialog *dlg,const instrument::CSRInstrument * instrument) const;

			/** Static method to know is the instrument is a derivative.
			*	Return true if instrument is of type Derivative or CPPI
			*/
			static bool IsDerivative(const instrument::CSRInstrument& instrument);

			/** Static method to know is the instrument can be an underlying but not a forerx one.
			*	Return true if instrument is of type equity, basket, fund and commodity future.
			*/
			static bool IsANotForexUnderlying(const instrument::CSRInstrument& instrument);

			friend class CSRClientComputationObject;
			friend class MonteCarloGridAdapter;
		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData & param, sophis::CSRComputationResults& results) const OVERRIDE;

			void Initialize(const CSROptionMonteCarloMetaModel &model);

			void	ComputeDifferencePriceForGreeksInternal(const instrument::CSRInstrument						&instrument,
														const market_data::CSRMarketData					&basicContext,
														sophis::CSRComputationResults& results,
														_STL::vector<const market_data::CSRMarketData *>	&contextForGreeks, 
														double												&basicTheoreticalValue, 
														_STL::vector<double>								&differencePriceForGreeks,
														const _STL::vector<SSBumpKey>&						bumpKeyVector) const;

			/** Return a new instance of the pass generator client. Overload this method to change the path generator.
			* @param instrument the instrument that is to price
			* @return a new instance of the pass generator client.
			*/
			virtual CSRLocalPathGeneratorClient*	new_PathGeneratorClient(const instrument::CSRInstrument &instrument) const;

			/**Return true is theoretical value is already computed, false else;
			*/
			inline bool IsTheoreticalValueComputed() const {return fIsTheoreticalValueComputed;};

			/**
			*  Use parallel calculation server, this method returns :
			*	- true if always is selected in user preferences.
			*	- true if OnDemand is selected and if we are in a portfolio computation.
			*	- Ask the user if OnDemand is selected and we are int he pricing window.
			*	- false else.
			*	This method can be derived to change access to parallel computation.
			*/
			bool UseCalculationServer(const instrument::CSRInstrument *instrument) const;

			/**
			*	Called at the end of the RecomputeAllStandAlone.
			*	This method computes specific greeks and stores them in specific members of the derived class
			*	Use this method to compute specific greek
			*/
		public:
			virtual void RecomputeAllSpecificGreeks(instrument::CSRInstrument		&instrument,
													const market_data::CSRMarketData& context, 
													sophis::CSRComputationResults& results) const;

		protected:
			/**
			*	Stand alone sequence of computation
			*/
			void	RecomputeAllStandAlone(	instrument::CSRInstrument		 &instrument,
											const market_data::CSRMarketData &param,
											sophis::CSRComputationResults& results) const;

			/** Compute the fair value of the derivative by Monte Carlo simulation.
			*	@param param is a market data.
			*	@param price is the output fair value.
			*  @param bumpKey is a SSBumpKey allowing to know which computation is currenctly done.
			*/
			void	GetTheoreticalValueStandAlone(	const instrument::CSRInstrument		&instrument,
													const market_data::CSRMarketData	&param,
													double								&price,
													const SSBumpKey						&bumpKey) const;


			/**
			* Sequence handling computation of basic price and difference price for greeks. 
			*/
			void	GenericGreekComputerStandAlone(	const instrument::CSRInstrument						&instrument,
													const market_data::CSRMarketData					&basicContext,
													const sophis::CSRComputationResults* results,
													_STL::vector<const market_data::CSRMarketData *>	&contextForGreeks, 
													double												&basicTheoreticalValue, 
													_STL::vector<double>								&differencePriceForGreeks,
													const _STL::vector<SSBumpKey>						&bumpKeyVector) const;

			/**  Store underlying spot of underlying in {@link fSpotForGreeks). They are needed to compute delta and gamma.
			*/
			void InitialiseSpotForGreeks(	const market_data::CSRMarketData&param,
											const instrument::CSRInstrument	&instrument,
											const CSRComputationResults& rs) const;

			/**   A boolean in order to compute theoretical value only once.
			*/
			mutable bool					fIsTheoreticalValueComputed;

			/** A boolean in order to call  {@link InitialiseSpotForGreeks} only once to store spot for delta and gamma.
			*/
			mutable bool					fSpotForGreeksStored;

			/** Store the forex change correction in case of quanto option on a FX rate.
			*/
			mutable bool	fForexQuantoChangeCorrection;

			/** Store the basic price forex change in case of quanto option on a FX rate.
			*/
			mutable double	fBasicForexQuantoChange;

			/** Store the basic price in strike currency in case of quanto option on a FX rate.
			*/
			mutable double	fBasicPriceInStrikeCurrency;

			/** A boolean in order to call  {@link InitialiseSpotForGreeks} only once to extract spot for delta and gamma..
			*/
			mutable bool					fSpotForGreeksExtracted;

			/**  Map storing underlying spot to compute
			*/
			mutable _STL::map<long, double>	fSpotForGreeks;

			/**  Speficic parameter for the metamodel
			*/
			mutable SSMonteCarloSpecificParameter	fParameters;

			/**  True if the parameters fParameters is to be initialized from the database
			*	 @see GetParameters
			*/
			mutable bool fInitParameters;

			/**  True if the metamodel has been initialized
			*	 @see InitialiseMetaModel
			*/
			mutable bool fIsInitialized;

			// internal use.
			bool fIsNewMultiUnderlying;
			friend class MultiUnderlyingsInterface;

			// American Payoff
			bool fIsAmerican;

			// bool use distribution : internal flag
			void	SetForceStandAloneCall(bool b) const;

			/** Give the first sampling of the simulation.
			*	The rule is that if {@link GetForcedBeginSampling()} return a positive value we use it.
			*	Otherwise we use 1;
			*/
			int GetBeginSampling(const instrument::CSRInstrument* instr) const;

			/** Give the last sampling of the simulation.
			*	The rule is that if {@link GetForcedLastSampling()} return a positive value we use it.
			*	Otherwise we use ;
			*/
			int GetLastSampling(const instrument::CSRInstrument* instr) const;

			/** For the American Monte Carlo. The intermediate vector contains the intermediates samplings 
			*	between the first and the last sampling. Each block of sampling is one iteration.
			*	Otherwise we use ;
			*/
			void GetIntermediateSampling(	const instrument::CSRInstrument* instr,
											int firstSampling, 
											int lastSampling, 
											_STL::vector<int> & sampling) const;


		protected :
			/** Give the number of sampling asked by user.
			*	If there is a positive number of sampling settled at the Monte Carlo Metamodel level we use  it
			*	otherwise we use the number of sampling settled in the option GUI {@link CSROption::GetPointCount}.
			*	
			*	Note that we use the convention the the real sampling count is 50 times the number 
			*	really settled in the metamodel or in the option GUI.
			*/
			virtual int GetAskedSamplingCount(const instrument::CSRInstrument* instr) const;

		public:

			// bool is it an American Payoff
			bool IsAmerican() const;

			/** Set the value to force the first sampling in the simulation.
			*	Must be useful for convergence scenario.
			*/
			void SetForcedBeginSampling(int forcedBeginSampling);

			/** Get the value of the forced first sampling in the simulation.
			*	Return 0 if not used.
			*
			*	@see CSROptionMonteCarloMetaModel::GetBeginSampling
			*/
			int GetForcedBeginSampling() const;

			/** Set the value to force the last sampling in the simulation.
			*	Must be useful for convergence scenario.
			*/
			void SetForcedLastSampling(int forcedLastSampling);

			/** Get the value of the forced first sampling in the simulation.
			*	Return 0 if not used.
			*
			*	@see CSROptionMonteCarloMetaModel::GetLastSampling
			*/
			int GetForcedLastSampling() const;


			void SetForceScaledStandardDeviationComputation(bool forceComputeStandardDeviation);

			bool ComputeStandardDeviation() const;

			bool ComputeUnderlyingForward() const;

			void SaveIndicatorsInProduct(instrument::CSRInstrument & instr);
			void ReadIndicatorsInProduct(const instrument::CSRInstrument & instr) const;

			void SaveGenericIndicatorsInResults(CSRComputationResults& results) const;

			/** Used when there is a control payoff ; most of the time, returns a closed formula price
			*   for it. However this function could call a PDE for more complex control payoffs.
			*	@return price of optionToPrice according to context
			*
			*	@since 6.1
			*/
			double QuickPriceForControlVariates(const CSRControlInstrument& controlInstrumentToPrice, const market_data::CSRMarketData	&context) const;


			inline _STL::string GetYieldCurveModelToUseName() const {return fYieldCurveModelToUseName;};
			inline void SetYieldCurveModelToUseName(const _STL::string & newName) {fYieldCurveModelToUseName = newName;};

		protected:

			/**  Used when there are control payoffs, these are their weights in the final price formula.
			*    The weights and the basic prices are calculated at the end of the first pricing, then stored
			*    to be reused for the computation of the Greeks.
			*/
			mutable _STL::vector<double> fControlWeights;
			mutable _STL::vector<double> fBasicPriceForControlVariates;

			/** Forced first sampling in the simulation.
			*/
			int fForcedBeginSampling;

			/** Forced last sampling in the simulation.
			*/
			int	fForcedLastSampling;

			/** Forced computation of the scaled standard deviation.
			*/
			bool fForceComputeStandardDeviation;

			/** First sampling in the simulation.
			*/
			int	fFirstSampling;

			/** Last sampling in the simulation.
			*/
			int	fLastSampling;
			
			/** Intermediate sampling for the American Monte Carlo
			*/
			mutable _STL::vector<int> fIntermediateSampling;

			/** Number of Iteration for the American Monte Carlo
			*/
			int fNbIterations;

			/**
			* Internal
			*/
			mutable bool fAllowDisplay;

		private:
			/**  Internal object managing computation sequence on server side.
			*/
			mutable CSRClientComputationObject *fClientComputationObject;

			/**  Results buffer object aggregating Monte Carlo simulation results on client side.
			*/
			mutable CSRClientOutput				*fClientOutput;

			//-----------------------------------------------------------------------------
			// Some internal methods and members.
			int		GetPacketCount(const instrument::CSRInstrument &instrument) const;

			/** Internal.
			 */
			CSRLocalPathGeneratorClient*	InitialisePathGeneratorClient(const instrument::CSRInstrument &instrument) const;

			/** Internal.
			*/
			CSRClientComputationObject* GetComputationObject() const;
			
			/** Internal.
			*/
			CSRClientComputationObject* InitialiseComputationObject()	const;

			mutable sophis::tools::CSRArchive		*fInformationArchive;
			mutable sophis::tools::CSRArchive		*fStaticInformationArchive;
			mutable sophis::tools::CSRArchive		*fDynamicInformationArchive;
			mutable sophis::tools::CSRArchive		*fResultArchive;
			mutable sophis::tools::CSRArchive		*fPreResultArchive;
			mutable	int								*fCpt;
			mutable	int								fTaskCompteur;
			mutable eMonteCarloComputationState		fState; 


			bool fReConstructWhenApplicationDateChange;
			long fConstructionDate;

			_STL::string fYieldCurveModelToUseName;

			/** One element in the computation sequence of the theoretical value and greeks
			*	Called by GetTheoreticalValueStandAlone
			*	@parameter instrument is the instrument to which the meta model is applied
			*	@parameter context is the market data
			*	@parameter bumpKey contains the data for the currency bump to apply to the price
			*	@return 0  and stores archives when Monte-Carlo computation type is emccsCreateArchive,
			*		otherwise return the price for a Theoretical Price Computation or the price difference
			*		for a Greek computation
			*/
			double   UseOneMonteCarlo(	const instrument::CSRInstrument		&instrument,
										const market_data::CSRMarketData	&context, 
										const SSBumpKey						&bumpKey) const;

			/**
			* Sequence handling distribution of computation
			*/
			void	ParallelComputation(	const instrument::CSRInstrument		&instrument,
											sophis::CSRComputationResults		&results,
											MonteCarloGridAdapter				*mcGridAdapter,
											const market_data::CSRMarketData	&param,
											bool								asynchronousTreatment) const;

			/** Path generator object dedicated to the option in order to generate underlying path. Created by prototypal instanciation 
			*	from specific parameter window.
			*/
			mutable CSRLocalPathGeneratorClient	*fPathGeneratorClient;

			/**
			* Sequence handling local computation
			*/
			void	LocalComputation(	const instrument::CSRInstrument		&instrument,
										sophis::CSRComputationResults& results,
										MonteCarloGridAdapter				*mcGridAdapter,
										const market_data::CSRMarketData	&param) const;

			// bool use distribution : internal flag
			mutable bool	fForceStandAloneCall;

			// bool flag telling us if we are in recomputeAll or not.
			mutable bool	fIsInRecomputeAll;

			// Underlying index in option from index in model
			//_STL::vector<int> fUnderlyingInOption;

			// Underlying index in model from index in option
			//_STL::vector<int> fUnderlyingInModel;
			//int fEquityCount;
			//int fForexCount;
			//int	fCurrencyCount;

			CSRClientPayoff*	fRegisteredPayoff;
			bool				fDeleteRegisteredPayoff;
			public:

				const CSRVolPointForCalibrationData* GetVolPointsForCalibration(long underlyingCode, bool pnl) const;
				

				inline double	GetStandardDeviation() const {return fStandardDeviation;};

				/**
				*	Method to retrieve sampling by sampling net present value. In order to have it computed one must
				*	overload {@link CSRClientPayoff::new_CSRClientOutput} in order to call {@link CSRClientOutput::SetMustStoreResultsBySampling},
				*	then one can use it in overloaded {@link CSRClientPayoff::CalculatePrice} when GetMonteCarloComputationState()==emccsAggregateResults;
				*	@since 7.1.3.10
				*/
				const _STL::vector<SSResultBySampling>&	GetResultBySampling() const;

			protected:
				mutable _STL::map<long, CSRVolPointForCalibrationData* > fVolPointsMap;
				mutable _STL::map<long, CSRVolPointForCalibrationData* > fVolPointsMapPnL;

				/**
				 INTERNAL.
				@since 6.0
				*/
				mutable double					fStandardDeviation;
				mutable _STL::vector<double>	fForwardSimulated;
				mutable _STL::vector<double>	fForwardExpected;
				mutable long fInstrumentCode;// currently priced instrumentCode

				mutable sophis::CSRComputationResults* fOptimResults;
			private:
				DEPRECATED_SIGNATURE virtual void ShowResultsOnClientSide(const instrument::CSRInstrument &instrument,const market_data::CSRMarketData&param) const;
				DEPRECATED_SIGNATURE virtual void FillInformationVector(const instrument::CSRInstrument &instrument,_STL::vector<CSRDisplayInformation*>&displayInformation) const;
		};

		/** CSRPayoffOption deprecated since 7.1 when new_CSRClientPayoff() and GetClientPayoff() where move on instrument
		*/
		///**	Interface to implement for objects using a {@link CSRClientPayoff}.
		//*	@version 6.0
		//*/
		//class SOPHIS_MONTECARLO CSRPayoffOption : public virtual sophis::instrument::CSROption
		//{
		//public:
		//	/** Constructor
		//	*	
		//	*	@param	prod is a low level structure.
		//	*	@version 6.0
		//	*/
		//	CSRPayoffOption(produit ** prod);

		//	/**	Trivial destructor.
		//	*	@version 6.0
		//	*/
		//	virtual ~CSRPayoffOption();


		//	virtual bool IsStandardOptionValidationToCheck() const {return true;};

		//	/** Returns a pointer on the CSRClientPayoff object dedicated to the object,
		//	*	generally in order to compute payoff for a given underlying path in Monte Carlo pricing.
		//	*	@return a pointer to the {@link CSRClientPayoff} object to use.
		//	*	@version 6.0
		//	*/
		//	CSRClientPayoff *	GetClientPayoff() const;

		//	virtual	CSRClientPayoff*	new_CSRClientPayoff() const = 0;
		//protected :
		//	/**
		//	* Erase client payoff in order to force reloading. Internal Use
		//	*/
		//	 void CleanClientPayoff();

		//	/** Factory for creation of a {@link CSRClientPayoff} object. Overload it to use you own payoff.
		//	*/
		//	

		//	/** CSRClientPayoff object created by factory {@link new_CSRClientPayoff}.
		//	*/
		//	 mutable CSRClientPayoff				*fCSRClientPayoff;

		//	/** Default Constructor. Internal Use Only.
		//	*	
		//	*	@version 6.0
		//	*/
		//	CSRPayoffOption();

		//	/** Initialization operation to be used by virtual child 
		//	*	
		//	*	@param	prod is a low level structure.
		//	*	@version 6.0
		//	*/
		//	void Initialize(produit ** prod);
		//};

		/**	Instrument used as a control variate in a Monte Carlo pricing. A Monte Carlo instrument obviously cannot
		*   be a control instrument, which partly motivated this class's creation.
		*	@version 6.1
		*/
		class SOPHIS_MONTECARLO CSRControlInstrument : public virtual sophis::instrument::CSRInstrument
		{
		};

		/** Class Managing Monte Carlo computation for an Instrument 
		*	The class contains interfaces for describing:
		*	- How to get risk sources after the risk analysis has been done in the payoff.
		*
		*  In order to manage your own Monte Carlo simulation with the sophis Monte Carlo architecture 
		*  you need to:
		*	- If you want to use your own random number generator and override the class {@link CSRUniformRandomGenerator} 
		*	and declare it with the macro INITIALISE_GENERATOR(className, name). Then  override the method 
		*	{@link CSROptionMonteCarloInterface::GetUniformGeneratorID} so that it return the same name as in the 
		*	declaration macro.
		*
		*	- if you want to use your own payoff, you should override
		*	the factory {@link CSROptionMonteCarloInterface::new_CSRClientPayoff} and the {@link CSRClientPayoff} class. 
		*/
		class SOPHIS_MONTECARLO CSROptionMonteCarloInterface : public virtual sophis::instrument::CSROption
		{
		public:
			/** Internal. Static method to create instance of a CSROptionMonteCarloInterface object. 
			 *	@see macro INITIALISE_DERIVE_OPTION_MONTECARLO_INTERFACE
			 */
			static sophis::instrument::CSRInstrument* NewDeriveSophis(const void *x);

			/** Constructor
			*	
			*	@param	prod is a low level structure.
			*	@param	initialiseRecomputeAll is a boolean saying if {@link InitialiseRecomputeAll} must be called in constructor. This
			*			is done in order that virtual function call in InitialiseRecomputeAll take into account the most overloaded version.
			*/
			CSROptionMonteCarloInterface(produit ** prod, bool initialiseRecomputeAll=true);

			/** Destructor.
			*/
			 virtual		~CSROptionMonteCarloInterface();

		protected :

			/** Constructor - for internal use only
			*	
			*/
			CSROptionMonteCarloInterface();

			/** Used by a constructor to initialize an object.
			This is for internal use only.
			*/
			void Initialize(produit ** prod, bool initialiseRecomputeAll=true);

		public:

//--------------------------------	Inherited from CSROption	---------------------------------------------

			 /** Get the metamodel forced for this instrument.
			 This allows you, once implemented a meta model, to force a meta model for
			 an instrument just by deriving the class and overloading this method.
			 The default implementation is to return fMMMetaModel.
			 @return a pointer which will not be deleted and may be null.
			 @since 5.3
			 */
			 virtual const finance::CSRMetaModel * GetForceMetaModel() const;

			 /** Called to initialise the greek structure.
			*	This method must be called only once and before calling RecomputeAll.
			*	Generally, it is called in the constructors of the first level derivate of CSRInstrument,
			*	but if the overload instrument modifies the instrument, you have a boolean parameter
			*	to avoid an initialization.
			*	The default implementation is to call the following methods:
			*	- {@link CSROptionMonteCarloInterface::GetUnderlyingCount}
			*	- {@link CSROptionMonteCarloInterface::GetUnderlying}
			*	- {@link CSROptionMonteCarloInterface::GetRhoCount}
			*
			*  - {@link CSROptionMonteCarloInterface::GetRhoCurrency}
			*	to allocate fDeltaEpsilon and fRhoDelta.
			*	@see CSROptionMonteCarloInterface::RecomputeAll
			*
			*	For Monte Carlo Simulation we must sort differents type of risk sources 
			*	according to the rule:
			*		- first we store Equity underlying,
			*		- then we store Forex currency.
			*	Because we got one less forex risk sources than rho risk sources it is then easy to know 
			*	if a risk sources is an equity or a Forex Rates with the 2 methods GetUnderlyingCount 
			*	and GetRhoCount.
			*/
			 //virtual	void	InitialiseRecomputeAll();
			 
			/** Get the number of instrument risk sources.
			*	It is used to aggregate the greeks by underlying.
			*	By default, return fUnderlyingCount.
			*/
			 //virtual	int		GetUnderlyingCount() const;
			 
			/** Get the number of interest rate risk sources.
			*	It is used to aggregate the rho by currency.
			*	By default, return fRhoCount.
			*/
			 //virtual	int		GetRhoCount() const;

			 /** Checks whether the object has to be built again.
			 This method is called internally when requesting an instrument via CreateInstance.
			 Default implementation return true if todays date {@link CSRClientPayoff::fToday} had changed.
			 */
			 virtual bool ConstructAgain() const;
			 
			/** Get the nth underlying risk sources.
			*	@param which is an index between 0 (included) and GetUnderlyingCount() (excluded).
			*	@return the ID of the instrument.
			*	By default, return the sources read in fDeltaEpsilon. If null, return the 
			*	value read in fRiskSources.
			*/
			 //virtual	long	GetUnderlying(int which) const;

			 /** Ask if the risk source is a vega source.
			 This is used when changing the currency to add a support for forex vega.
			 @param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
			 @since 5.3.0
			 */		
			 //virtual bool	IsAVegaUnderlying(int whichUnderlying) const;

			 /** Ask if the risk source is a delta source.
			 This is used for forex risk sources when using currency code as delta risk sources and forex code
			 as vega risk sources.
			 @param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
			 @since 5.3.0
			 */			
			 //virtual bool	IsADeltaUnderlying(int whichUnderlying) const;
			 
			/** Get the nth currency risk sources.
			*	@param which is an index between 0 included and GetRhoCount() excluded.
			*	@return the currency in format '3GBP'.
			*	By default, return the sources read in fRho. If null, return the value read in fRhoSources.
			*/
			 //virtual	long	GetRhoCurrency(int which) const;
			 

			/** Test if the instrument is in the right state to be priced.
			*	@return true if the instrument is valid.
			*/
			 virtual	Boolean	ValidInstrument() const;
			
			/** Return the payoff formula for the instrument.
			*	@param result is an output string for the payoff formula. 
			*/
			 virtual	void    GetPayOffFormula(char *result) const;

			 /** Get the cash flow diagram.
			 @return a new cash flow diagram.
			 This is used for the scenario cash flow diagram and for cash balance.
			 It is also used to calculate the duration.
			 @param param is a market data.
			 @see CSRCashFlowDiagram
			 */
			 virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagram(const market_data::CSRMarketData& context) const;

			 /** Returns the list of Credit Risk sources on which the instrument depends
			 *  Credit risk sources have an impact on the theoritical value of the instrument, for obvious reasons or because of the model.
			 *  For example, the Issuer/Currency/Seniority of a Bond affect it's theoritical value because of the consequences in case of default (recovery rate)
			 *  The "default event" of the Bond is used to decide which default probability curve to use.
			 *  Thus, the 4-uple (Issuer,Currency,Seniority,DefaultEvent) is a credit risk source for the Bond.
			 *  This method has to be overloaded for toolkit instruments with credit risk sources
			 *	@param outCreditRiskSources is the list of credit risk sources to be filled
			 *	have several time the same credit source comming from different underlyings.
			 */
			 //virtual void GetCreditRiskSourcesImpl(_STL::set<instrument::SSCreditRiskSource> &outCreditRiskSources) const;
			 
//------------------------------	Specific methods of Monte Carlo Option	-----------------------------------------------

			 /**
			  * Erase specific parameters, client payoff and path generator then force reconstruction 
			  *	with database stored parameter. Internal Use
			  */
			 void RefreshSpecificParameter();

			 /**
			 * Erase specific parameters in order to force reloading. Internal Use
			 */
			 void CleanSpecificParameter();
		
			 /** Refresh the strike value in CSRClientPayoff with those stored in Sophis structure produit.
			 *	this function call the method RefreshStrike of CSRClientPayoff.
			 */
			 virtual	void	RefreshOptionWithStrikeInProduct();

			/** Give the instrument code at which specific Monte Carlo parameters are attached.
			*	Default implementation return {@link CSRInstrument::GetCode}.
			*/
			virtual long GetSicovamForParameters() const;

			/** Static method to know if foreign currency code must be understood as a FX delta sources.
			*	Always return true;
			*/
			static bool ComputeFXDeltaOnForeignCurrency(const sophis::instrument::CSROption* option);

			/** Static method to know if foreign currency code must be understood as a FX vega sources.
			*	Return false when using New Monte Carlo model and true when using Monte Carlo metamodel
			*/
			static bool ComputeFXVegaOnForeignCurrency(const sophis::instrument::CSROption* option);
			
			/** Static method to know if forex code must be understood as a FX delta sources.
			*	Return false when using New Monte Carlo model and true when using Monte Carlo metamodel
			*/
			static bool ComputeFXDeltaOnForexCode(const sophis::instrument::CSROption* option);
			
			/** Static method to know if foreign currency code must be understood as a FX vega sources.
			*	Always return true;
			*/
			static bool ComputeFXVegaOnForexCode(const sophis::instrument::CSROption* option);


			/**
			* Call back on {@see CSRInstrument::GetClientPayoff}
			*/
			sophis::finance::CSRClientPayoff *	GetClientPayoffOptionMonteCarloInterface() const;

		protected :
			//_STL::vector<eUnderlyingType> fUnderlyingType;

			/** Factory for creation of a {@link CSRClientPayoff} object. Overload it to use you own payoff.
			*/
			virtual	CSRClientPayoff*	new_CSRClientPayoff() const;

		protected: // SOME internal data and methods

			/** Vector storing risk sources.
			*/
			//_STL::vector<long>	fRiskSources;

			/** Vector storing rho sources.
			*/
			//_STL::vector<long>	fRhoSources;

		private:

			CSROptionMonteCarloMetaModel fMMMetaModel;
//-----------------------------------------------------------------------------
	 public:// DEPRECATED METHOD
			 /** 
			 * @deprecated since 5.3
			 */
			 void	GetEpsilonStandAlone(const market_data::CSRMarketData &param, int which, double &epsilon) const throw (sophisTools::base::ExceptionBase);
			 
			 /** 
			 * @deprecated since 5.3
			 */
			 void	GetRhoStandAlone(const market_data::CSRMarketData &param, int which, double & rho) const throw (sophisTools::base::ExceptionBase);

			 /** 
			 * @deprecated since 5.3
			 */
			 void	GetConvexityStandAlone(const market_data::CSRMarketData &param, int which, double & convexity) const throw (sophisTools::base::ExceptionBase);

			 /** 
			 * @deprecated since 5.3
			 */
			 void	GetRhoConvexityStandAlone(	const market_data::CSRMarketData &param,
												double 							 &rho,
												double 							 &convexity,
												int 							 which) const throw (sophisTools::base::ExceptionBase);

			 /** 
			 * @deprecated since 5.3
			 */
			void	GetPriceDeltaGammaStandAlone(	const market_data::CSRMarketData &param,
													double				&price,
													double				&delta,
													double				&gamma,
													int 				whichUnderlying) const throw (sophisTools::base::ExceptionBase);

			/** 
			 * @deprecated since 5.3
			 */
			void  GetPartialDeltaStandAlone(	const market_data::CSRMarketData	&param, 
												int									which, 
												double								&delta) const throw (sophisTools::base::ExceptionBase);

			/** 
			 * @deprecated since 5.3
			 */
			void  GetPartialGammaStandAlone(const market_data::CSRMarketData &param, 
											int								 which1, 
											int								 which2, 
											double							 &crossedGamma) const throw (sophisTools::base::ExceptionBase);

			/** 
			 * @deprecated since 5.3
			 */
			 virtual void		GetPriceTotalDeltaTotalGamma(	const market_data::CSRMarketData &context,
																double				*price,
																double				*delta,
																double				*gamma,
																int 				whichUnderlying) const throw (sophisTools::base::ExceptionBase);

			 /** 
			 * @deprecated since 5.3
			 */
			 virtual double		GetTotalFirstDerivative(	const market_data::CSRMarketData	&context, 
															int									whichUnderlying,
															double								*gamma) const throw (sophisTools::base::ExceptionBase);
			/** 
			 * @deprecated since 5.3
			 */
			 virtual double		GetTotalSecondDerivative(const market_data::CSRMarketData	&context, 
														int									which1, 
														int									which2) const throw (sophisTools::base::ExceptionBase);

		};


		class CSRInterestRateLocalPathGeneratorClient;
		class CSRClientCorrelation;
/**  Interface for class which generate sample path. 
*	 We must make distinction between diffused underlying and those defining derivatives payoff.
* 
*	Typical initialization will follow the sequence :
*	1)	Initialise underlying to diffuse by calling {@link CSRLocalPathGeneratorServer::SetUnderlyingToDiffuse}.
*	2)	For each fixing date (in the future at gApplicationContext date settled) needed by the payoff 
*		we will add the corresponding date by calling {@link CSRLocalPathGeneratorClient::AddFixingNeeded}.
*	3)	For each feature your payoff will need we call {@link CSRLocalPathGeneratorClient::AddFeatureToManage} with parameter fixingAreKnow value
*		set at false (the feature can need some supplementary fixings, so all fixing are not know at this level).
*	4)	Now that all fixing needed by the payoff are know we can generate those specifically needed by the SDE
*		integration method (as an example when using a fixed time step we can add fixing dates so that no integration step is
*		greater than the corresponding time step. This is done by calling {@link CSRLocalPathGeneratorClient::AddFixingForSDEIntegration}.
*	5)	Now that all fixing are known we can compute the number of normal law needed to generate such a sampling with the spot value at
*		every fixing date for every underlying by calling {@link CSRLocalPathGeneratorClient::ComputeNormalLawSize()}.
*	6)	Now for each feature managed we can add some uniform law if	needed by calling {@link CSRLocalPathGeneratorServer::AddFeatureToManage} with parameter fixingAreKnow 
*		value set at true. The typical example is the use of Brownian bridge in Black and Scholes framework for a continuous barrier: we have added the start and end date of the 
*		barrier an may be some other fixing dates between them. So, when the barrier is active, for two consecutive fixings dates we will know the spot value and the real 
*		payoff depend on the fact that the spot as reached the barrier between this two dates. If the underlying process allow us to know the probability to have reached the barrier 
*		conditioned by spot values at fixing dates we can improve Monte Carlo convergence by using one more uniform law and assuming that spot have reached barrier level if the 
*		uniform law is less than the probability.
*
*/
		class SOPHIS_MONTECARLO CSRLocalPathGeneratorClient
		{
		public:

			/** Constructor.
			*/
			CSRLocalPathGeneratorClient();

			/** Copy Constructor.
			*/
			CSRLocalPathGeneratorClient(const CSRLocalPathGeneratorClient &);

			/** virtual destructor.
			*/
			virtual ~CSRLocalPathGeneratorClient();

			/**  Set today's date.
			*	
			*	@param today is the todays date.
			*/
			inline void	SetToday(long today)	{fToday = today;};


			inline long	GetTodayDate() const {return fToday;};

			/**  Method called after risk analysis to set the underlying really diffused by Monte Carlo simulation.
			*	 Fill {@link CSRLocalPathGeneratorClient::fUnderlyingDiffused} vector.
			* 
			*	@param underlyingToDiffuse is the vector of underlyings to diffuse.
			*	@param nbEquity is the number of equity underlyings to diffuse.
			*/
			void	SetUnderlyingToDiffuse(const _STL::vector<SSDiffusedUnderlying>	&underlyingToDiffuse,
										   int										nbEquity);

			/**	Give structure identifying an underlying really diffused.
			*
			*	@param nth is the index of the underlying really diffused. It must be 
			*
			*	@return a structure identifying an underlying really diffused.
			*
			*	@see sophis::finance::SSDiffusedUnderlying 
			*/
			inline const SSDiffusedUnderlying& GetUnderlyingDiffused(int nth) const {return fUnderlyingDiffused[nth];};

			/** Give the number of underlying really diffused during Monte Carlo simulation. 
			* 
			*	@return the number of underlying really diffused during Monte Carlo simulation. 
			*/
			inline int GetUnderlyingDiffusedCount() const {return (int) fUnderlyingDiffused.size();};

			/** Fill a map in order to quickly identify an underlying for payoff from its sicovam. 
			*/
			inline	void InitialiseUnderlyingIndexForPayoffMap()
			{
				size_t i = 0, underlyingForPayoffSize = fUnderlyingForPayoff.size();
				fUnderlyingForPayoffIndexMap.clear();
				for(;i<underlyingForPayoffSize; i++)
					fUnderlyingForPayoffIndexMap[fUnderlyingForPayoff[i].fCode]	= (int) i;
			}

			/** give index identifying an underlying for payoff from its sicovam.
			*
			*	@return index of an underlying for payoff in 
			*/
			inline	int	GetUnderlyingForPayoffIndex(long code) const
			{
				_STL::map<long, int>::const_iterator underlyingIndexMapIter	= fUnderlyingForPayoffIndexMap.find(code);
				_STL::map<long, int>::const_iterator underlyingIndexMapLast	= fUnderlyingForPayoffIndexMap.end();

				if(underlyingIndexMapIter != underlyingIndexMapLast)
					return underlyingIndexMapIter->second;

				return -1;
			};

			/**	Give structure identifying an underlying asked by payoff.
			*
			*	@return a vector of structure identifying an underlying really diffused.
			*
			*	@see sophis::finance::SSUnderlingForPayoff 
			*/
			inline _STL::vector<SSUnderlingForPayoff>&	GetUnderlyingForPayoff() {return fUnderlyingForPayoff;};

			/**	Give the number of underlying asked by payoff.
			*
			*	@return  the number of underlying asked by payoff.
			*/
			inline int GetUnderlyingForPayoffCount() const {return (int) fUnderlyingForPayoff.size();};


			/** This method return the number of diffused volatilities.
			*/
			virtual int GetDiffusedVolatilitiesCount() const {return 0;};


			/**	Give the forward price (according to the current task) of an underlying for payoff at given date in time grid.
			*
			*	@param nthUnderlyingForPayoff is the index identifying underlying for payoff.
			*	@param nthdate is index in path generator time grid identifying date at which we need forward price.
			*	
			*	@return the forward price of underlying for payoff.
			*/
			double GetForwardForPayoffUnderlying(int nthUnderlyingForPayoff, int nthdate) const;

			/**
			* Method called to know if the path generator is able to handle some specific feature is the path
			* generation.
			*
			*	@param feature is the feature identifier for which we want to know if it is handle by the path generator.
			*
			*	@see sophis::finance::eUnderlyingPathFeature
			*/
			virtual bool IsPathFeatureHandled(eUnderlyingPathFeature feature) const {return false;};

			/** Add a fixing date in path generator time grid.
			*
			*	@param fixingDate is an absolute date to add in time grid.
			*/
			void AddFixingNeeded(long fixingDate);

			/** Clean path generator time grid.
			*/
			void CleanFixingNeeded();

			/** This method add a feature to be managed by path generator.
			*	Method called by {@link CSRClientPayoff::AddFeatureToManage}.
			*
			*	@param underlyingCode is the underlying sicovam code for which we add a feature to manage.	
			*	@param feature is the feature identifier.
			*	@param startDate is the start date for the corresponding feature period.
			*	@param endDate is the end date for the corresponding feature period.
			*	@param identifier identify the the specific feature in the payoff definition.
			*	@param allFixingDatesAreKnow is true if time grid is already settled, false else.
			*	@param optionCode is the sicovam code for the option.
			*/ 
			void AddFeatureToManage(	long						underlyingCode,	
											eUnderlyingPathFeature	feature,
											long					startDate,
											long					endDate,
											int						identifier,
											bool					allFixingDatesAreKnow,
											long					optionCode);		

			/** Fill a vector with dates at which diffusion parameter change. It is relevant to force these dates in
			*	the discretization grid.
			*	In stochastic volatility models correlation between spot and volatility process change at these dates
			*	so we must call it to initialise properly correlation objects.
			*	Default implementation do nothing.
			*
			*	@param option is a pointer on the computed option.
			*	@param changingParametersDate is the vector of dates to fill.
			*
			* @version 5.3.0. 
			*/
			virtual void	FillChangingParametersDate(	const finance::CSROptionMonteCarloMetaModel	*model,
														const instrument::CSRInstrument				&instrument,
														_STL::set<long>							&changingParametersDate) const;


			/** Fill the correlation matrix for an option in a given context.
			*	Default implementation will fill a matrix with underlying diffused spot correlations.
			*
			*	@param param is the market data.
			*	@param option is a pointer on the computed option.
			*	@param correlationMatrix is the correlation matrix to fill.
			*	@param startDate is the startDate for the period during which we want to get implied correlation.
			*	@param endDate is the endDate for the period during which we want to get implied correlation.
			*	@param correlBoundary must be in interval )-1., 1.[. This is a boundaries to apply
			to not diagonal elements in correlation matrix in order to get definite positive matrix.

			* @version 5.3.0. 
			*/
			virtual void FillCorrelationMatrix(	::boost::numeric::ublas::matrix<double>	&correlationMatrix,
												const market_data::CSRMarketData		*param, 
												const instrument::CSRInstrument			*instr,
												const CSROptionMonteCarloMetaModel		*model,
												long									startDate,
												long									endDate,
												long											yieldCurveFamily,
												const _STL::vector<math::SSLiborPeriod>		&liborData,
												::boost::numeric::ublas::matrix<double>	&liborEquityCorrelationMatrix,
												double									correlBoundary	= 0.999) const;


			/** Return true if the pathgenerator can handle multiunderlying diffusion.
			 *  Default implementation return true;
			 */
			virtual bool CanHandleMultiUnderlyingDiffusion() const;

			/** Return true if the path generator is valid.
			 *  Default implementation return true if the number of underlying is positive.;
			 *	@param code is the code of the option
			 *	@payOff is the registered client pay-off
			 *	@version 6.0
			 */
			virtual bool IsValid(const instrument::CSRInstrument	*instr, CSRClientPayoff* payOff = 0) const;


			/** Used for control payoffs.
			*   @return the metamodel to price optionToPrice.
			*   @since 6.1
			*/
			virtual const CSRMetaModel* GetQuickPricingModel(const CSRControlInstrument &controlInstrumentToPrice);
			
			/**
			* Internal. To handle yield curves on Monte Carlo Simulation.
			*/
			inline void SetYieldCurveModelToUseName(const _STL::string & newName) {fYieldCurveModelToUseName = newName;};


			/**
			* Methos to initiliase risk sources in pa	th generator calibration. Default implementation will call Interest rate path generator one.
			*/
			virtual void GetSpecificRiskSources(	const instrument::CSRInstrument& instr, 
													const finance::CSROptionMonteCarloMetaModel& model, 
													/*out*/ sophis::CSRComputationResults& rs, 
													unsigned long bitFlag ) const;
			
		protected:

			/**
			* Internal. Yield curve identifier.
			*/
			_STL::string fYieldCurveModelToUseName;

			/**
			* 
			*/
			void Initialize(const CSRLocalPathGeneratorClient &);

			/**	Method to add some fixing in time grid in order to manage specific features.
			*	Default implementation add start and end dates.
			*	
			*	@param feature is the feature type for which we want to add fixings.
			*	@param startDate is the start date for the corresponding feature period.
			*	@param endDate is the end date for the corresponding feature period.
					*	@param identifier identify the the specific feature in the payoff definition.
			*/
			virtual void AddFixingForFeatureToManage(	eUnderlyingPathFeature	feature,
														long					startDate,
														long					endDate,
														int						identifier);

			/**	Method to add some fixing in time grid in order to manage specific features.
			*	For each time step concerned by feature we call {@link CSRLocalPathGeneratorClient::GetUniformLawNeededForOneStep}
			*	in order to know how many supplementary uniform laws are needed to manage such feature for one step.
			*	
			*	@param underlyingCode is the underlying sicovam concerned by path feature.
			*	@param feature is the feature type for which we want to add fixings.
			*	@param startDate is the start date for the corresponding feature period.
			*	@param endDate is the end date for the corresponding feature period.
			*	@param identifier identify the the specific feature in the payoff definition.
			*/
			void AddLawForFeatureToManage(	long					underlyingCode,
											eUnderlyingPathFeature	feature,
											long					startDate,
											long					endDate,
											int						identifier);

	public:
			/**
			* Factory to create a yieldcurve light client. 
			*/
			virtual CSRYieldCurveLightClient* new_CSRYieldCurveLightClient() const;

	

			/** Give yieldcurve light client vector corresponding to the different currencies of the payoff cashflows. 
			*/
			CSRYieldCurveLightClient* GetDiscountYieldCurveLightClient() const;

			/** Give yieldcurve light client vector corresponding to the different currencies of the payoff cashflows. 
			*/
			_STL::vector<CSRYieldCurveLightClient*> & GetCSRYieldCurveLightClient() const;

			/** Fill a vector in order to know during greeks computation which data are different from the basic one used 
			*	for theoretical price computation for a given underlying.
			* 
			*	It must be filled with index corresponding to enum {@link sophis::finance::eMCDataType} with value 
			*	{@link sophis::finance::eDataToUseType::eUseBasicOne} if the corresponding data is the same as 
			*	the one used in theoretical price computation or with {@link sophis::finance::eDataToUseType::eUseMyself}
			*	if the corresponding data has changed.
			*
			*	@param nthUnderlying is the underlying index for which we want to know whose data are modified during greeks computation.
			*	@param bumpKey is a {@link sophis::finance::SSBumpKey} allowing to know which computation is currently done.
			*	@param option  is the option for which we handle Monte Carlo simulation.
			*	@param dataToUseType is the output vector. 
			*/
			virtual void FillModifiedData(	int									nthUnderlying,
											const SSBumpKey						&bumpKey,
											const instrument::CSRInstrument		*instr,
											const CSROptionMonteCarloMetaModel	*model,
											_STL::vector<eDataToUseType>		&dataToUseType) const;

			/**	Called when all fixing dates needed by payoff are know. This method can add some new dates if needed by the integration schemes.
			*
			*	@param option is the option its allow to get specific parameters like discretization length.
			*/
			virtual	void AddFixingForSDEIntegration(const finance::CSROptionMonteCarloMetaModel	*model,
													const instrument::CSRInstrument				&instrument);

			/** Fill {@link CSRLocalPathGeneratorClient::fDates} vector storing time grid for path generator.
			*/
			void	FillDatesVectorFromMap();

			/** Called when all fixing dates and all date needed for the specific integrationSchemes are known. 
			*	Compute the number of law needed to generate normal sampling needed and store it in {@link fNormalLawSize}.
			*	 
			*	Default implementation for a nFactor = {@link CSRLocalPathGeneratorClient::GetNormalLawSizeByStep} factor model, when we diffuse
			*	nUnderlying = {@link CSRLocalPathGeneratorClient::GetUnderlyingDiffusedCount} on nTimeStep = {@link CSRLocalPathGeneratorClient::GetDateCount} time steps
			*	we need nFactor * nUnderlying * nTimeStep independent normal law.
			*/
			virtual	void ComputeNormalLawSize(const CSRClientPayoff * clientPayoff, const CSRClientCorrelation* clientCorrelation);

			/** Tell us if we must aggregate underlying and forex as a single underlying for compo diffusion.
			*	This will impact the forward prices and volatilities stored.
			*	Moreover, when we do not aggregate we need to diffuse the corresponding forex.
			* 
			*	When an underlying is compo, the true option's underlying is
			*	the spot S multiplied by the forex rate FX. In Black and Scholes
			*	framework S*FX is treated as a one dimentional processus with forward
			*	equal to the underlying forward multiplied by FX forward and with volatility
			*	given by {@link CSRMarketData::GetCompoVolatility}.
			* 
			*	@return true if we must aggregate, false else. 
			*/
			virtual bool AggregateFXForCompoDiffusion() const {return true;};

			/** Tell us if we adjust the forward of quanto underlying by using Black and Scholes
			*	quanto adjustment. In this case quanto diffusion is only modified by constant
			*	quanto adjustment. In order to take into account of smile in the quanto drift
			*	we must return false then manage quanto drift change during integration.
			* 
			*	@return true if we must adjust forward stored, false else.
			*/
			virtual bool	UseBSQuantoForward() const {return true;};

			/** Give the number of normal law needed for an underlying to simulate one step integration. 
			*	Default implementation return 1.	
			*
			*	@return the number of normal law needed for an underlying to simulate one step integration. 
			*/
			virtual int		GetNormalLawSizeByUnderlyingForOneStep() const {return 1;};

			/** Give the number of uniform law needed for an underlying to manage a path feature on one step integration. 
			*	Default implementation return 0.	
			*
			*	@param feature is the feature type for which we want to add fixings.
			*
			*	@return the number of uniform law needed for an underlying to manage a path feature on one step integration. 
			*/
			virtual int		GetUniformLawNeededForOneStep(eUnderlyingPathFeature	feature) const {return 0;};

			/**
			*	Total number of normal law needed for simulation including those needed to simulate underluings,
			*	those needed to simulate interest rate and those needed for special feature.
			*/
			inline size_t			GetUniformLawSize() const {return fUniformLawSize;};	

			// number of normal law size needed to simulate one step for all underlying
			inline size_t			GetNormalLawSizeByStep() const {return fNormalLawSizeByStep;};

			/**
			* Give the real number of normal law needed to generate one path, including the interest rate path generator.
			*/
			size_t			GetFullNormalLawSize() const ;

			/** 
			* This method has to be implemented in order to return the name used for the prototype registration 
			* on the client and server side.
			* @see CSRLocalPathGeneratorServer
			* @see INITIALISE_PATHGENERATOR_CLIENT
			* @see INITIALISE_PATHGENERATOR_SERVER
			*/
			virtual _STL::string GetLocalPathGeneratorServerID() const = 0;


			/** Set the market data computation date.
			*                                                                      
			*/
			void SetComputationDate(const market_data::CSRMarketData &param );

			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRLocalPathGeneratorClient* Clone() const = 0;

			/** Internal for prototypal instantiation.
			 */
			typedef	sophis::tools::CSRPrototype<CSRLocalPathGeneratorClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/**  Store in an archive {@link sophis::tools::CSRArchive} the result of the Monte Carlo simulation. These data can be used to initialise
			*	another Server output or a Client output.
			*	@param archive is the archive storing the data needed to initialise the CSRClientOutput in order to finalise computation.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/** Store all the data needed to initialise a CSRServerOutput in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRServerOutput for the Monte Carlo loop on the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** Return the number of date in time grid {@link fDates}.
			*/
			inline int GetDateCount() const {return (int) fDates.size();};

			/** Return the nth date in time grid {@link fDates}.

				@param nth is the index of the date in time grid. Must be between 0 and {@link GetDateCount}-1.
			*/
			inline long GetDate(int nth) const {return fDates[nth];};

			/** Return a reference on the time grid vector.
			 */
			inline const _STL::vector<long>& GetDateVector() const 	{return fDates;};

			/** Return the number of not-forex underlying to diffuse in the simulation. 
			 */
			inline int GetEquityDiffusedCount() const {return fEquityDiffusedCount;};

			/** Return the number of forex underlying to diffuse in the simulation. 
			*/
			inline int GetForexDiffusedCount() const {return fForexDiffusedCount;};

			/** This method fill a set of all the ex-dividend dates of equity underlyings between
				the today's date (settled in {@link CSRClientPayoff::InitialiseStaticData}) and the 
				option expiry date.

				@param context is the market data.
				@param option is the option to price
				@param isCash is the boolean that defines the cash or not.
				@param dividendExDivDateSet is the set of dates to be filled in outpout.
			*/
			void FillDividendExDivDate(	const market_data::CSRMarketData		&context,
										const instrument::CSRInstrument			*instr,
										_STL::set<long>							&dividendExDivDateSet);

			
			/** Factory for initialization of parameters for the volatility model.

				@return a pointer on a new {@link CSRDiffusionParameter} used to store diffusion 
				parameters needed by the model on the server side.
			*/
			virtual CSRDiffusionParameter* new_CSRDiffusionParameter() const = 0;

			/** Initialise diffusion parameters corresponding to a market data.

				@param diffusionParameter is a pointer on the  {@link CSRDiffusionParameter} to initialize.
				@param param is the {@link CSRMarketData} to use for initialization.
				@param nthUnderlying is the index of the diffused underlying for which diffusion parameter must be initialized.
				@param model is a pointer on the metamodel needing such diffusion parameter. 
				@param instrument is the instrument to price.
				@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 
			 
			 */
			virtual bool	InitialiseDiffusionParameter(	CSRDiffusionParameter				*diffusionParameter,
															const market_data::CSRMarketData	&param,
															int									nthUnderlying, 
															const CSROptionMonteCarloMetaModel	*model,
															const instrument::CSRInstrument		&instrument,
															const SSBumpKey						&bumpKey) const = 0;

			/** Give a pointer on the diffusion parameter of the n-th underlying.

				@param nth is the index of th n-th underlying diffused.

				@return a pointer on the diffusion parameter of the n-th underlying.
			 */
			inline CSRDiffusionParameter* GetNthDiffusionParameter(int nth) {return fDiffusionParameter[nth];};

			/** Internal used. This is called once in order to store parameter of the basic computation in order to 
				optimise the initialization and the quantity of data transported on server side.
			  
			 */
			void SaveBasicParameter();

			/** Give a pointer on the diffusion parameter of the n-th underlying used for basic price computation (only initialized during other price computation).

				@param nth is the index of the n-th underlying diffused.

				@return a pointer on the diffusion parameter of the n-th underlying used for basic price computation.
			*/
			inline const CSRDiffusionParameter* GetNthBasicDiffusionParameter(int nth) const {return fBasicDiffusionParameter[nth];};

			/** Run calibration if needed and store result. It is called by the calibration scenario.
			By default this method does nothing.
			@param instrumentMetaModel is the metamodel used to calibrate
			@param modelToSave is the basic metamodel in whoic
			@param instrument is the instrument to price.
			@param context is the market data to use for calibration.
			@param alreadyCalibrated is a set to allow not to calibrate 2 times the same underlying for a given metamodel.
					It must be filled during calibration.
			@return true is the calibration was run successfully and results saved. By default return false.
			@since 5.3.0
			*/
			virtual bool RunAndSaveCalibration(	CSROptionMonteCarloMetaModel				&instrumentMetaModel,
												CSROptionMonteCarloMetaModel				&modelToSave,
												const instrument::CSRInstrument				&instrument, 
												const sophis::market_data::CSRMarketData	&context,
												_STL::set<long>*							alreadyCalibratedUnderlying);

			/** When model use a global calibration scenario the flag {@link fIsInGlobalCalibration} is used to know if
				when we are is scenario and when we are not.

				@return true is we are in global calibration scenario, false otherwise.
			 */
			inline bool IsInGlobalCalibration() const {return fIsInGlobalCalibration;};

			/** Method used to set the flag {@link fIsInGlobalCalibration}.

				@param isInGlobalCalibration is the value at which we set the flag {@link fIsInGlobalCalibration}.
			*/
			inline void SetIsInGlobalCalibration(bool isInGlobalCalibration, long calibrationID) {fIsInGlobalCalibration = isInGlobalCalibration; fCalibrationID = calibrationID;};

			/**	Give the vector to identify which data are different from those used in basic price computation. 
				@see FillModifiedData

				@return the vector to identify which data are different from those used in basic price computation. 
			*/
			inline _STL::vector<_STL::vector<eDataToUseType> >& GetLocalDataToUseTypeVector() const {return fLocalDataToUseTypeVector;};

			/** Method to know if in current computation the forward prices of the nth underlying have changed.

				@return true if in current computation the forward prices of the nth underlying have changed, false otherwise.
			 */
			bool IsSameForwardAsBasicOne(int nthUnderlying) const;

			/** A method to know if diffusion will need NLU coefficient a and b for underlyings.

				@return true if NMU coefficient are needed, false otherwise. Default implementation return the same result as {@link UseCashVolatility}.
			*/
			virtual bool UseNMUCoefficient() const;

			/** A method to know if diffusion parameters are supposed to be the ones for Forward price at meturity as in NMU model or
				if they are those for spot price as in Black and Scholes model. Difference is only relevant when dealing with cash dividend.
			 
				@return true if the volatility is a cash volatility, false otherwise. Default implementation return true if preference "Cash volatility" is ticked, false otherwise.
			 */
			virtual bool UseCashVolatility() const;

			/**	Set the spot value of an underlying. 

				@param nthUnderlying is the index of the diffused underlying.
				@param spot is the spot value to set.
			*/
			inline void	 SetNthSpot(int nthUnderlying, double spot) {fSpotVector[nthUnderlying] = spot;};


			/**	Get the spot value of an underlying. 

				@param nthUnderlying is the index of the diffused underlying.
				@param spot is the spot value to set.
			*/
			inline double GetNthSpot(int nthUnderlying) const {return fSpotVector[nthUnderlying];};

			/** Give the forward prices of an underlying on the time grid.

				@return the vector of forward prices of an underlying on the time grid.
			 */
			inline _STL::vector<double> & GetNthForwardVector(int nthUnderlying) const {return fForward[nthUnderlying];};

			/** Give the NMU coefficient a of an underlying on the time grid (only filled if {@link UseNMUCoefficient} return true).

			@return the vector of forward prices of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetNthNMUaVector(int nthUnderlying) const {return fNMUa[nthUnderlying];};

			/** Give the NMU coefficient b of an underlying on the time grid (only filled if {@link UseNMUCoefficient} return true).

			@return the vector of forward prices of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetNthNMUbVector(int nthUnderlying) const {return fNMUb[nthUnderlying];};

			/** Give the quanto factor of an underlying on the time grid.

			@return the vector of forward prices of an underlying on the time grid.
			*/
			inline _STL::vector<double>	& GetNthQuantoFactorVector(int nthUnderlying) const {return fQuantoFactor[nthUnderlying];};

			/** Give  the market data dependent infos of an underlying on the time grid.

			@return the vector of market data dependent infos of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetMarketDataDependantInfoVector() const {return fMarketDataDependantInfo;};

			/** Give the forward prices used for basic price computation (only initialized during other price computation) 
				of an underlying on the time grid.

			@return the vector of forward prices used for basic price computation  of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetNthBasicForwardVector(int nthUnderlying) const {return fBasicForward[nthUnderlying];};

			/** Give the NMU coefficient used for basic price computation (only initialized during other price computation) 
				a of an underlying on the time grid (only filled if {@link UseNMUCoefficient} return true).

			@return the vector of forward prices used for basic price computation of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetNthBasicNMUaVector(int nthUnderlying) const {return fBasicNMUa[nthUnderlying];};

			/** Give the NMU coefficient b used for basic price computation (only initialized during other price computation)
				of an underlying on the time grid (only filled if {@link UseNMUCoefficient} return true).

			@return the vector of forward prices used for basic price computation of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetNthBasicNMUbVector(int nthUnderlying) const {return fBasicNMUb[nthUnderlying];};

			/** Give the quanto factor used for basic price computation (only initialized during other price computation) 
				of an underlying on the time grid.

			@return the vector of forward prices used for basic price computation of an underlying on the time grid.
			*/
			inline _STL::vector<double>	& GetNthBasicQuantoFactorVector(int nthUnderlying) const {return fBasicQuantoFactor[nthUnderlying];};

			/** Give  the market data dependent infos used for basic price computation (only initialized during other price computation) 
				of an underlying on the time grid.

			@return the vector of market data dependent infos used for basic price computation of an underlying on the time grid.
			*/
			inline _STL::vector<double> & GetBasicMarketDataDependantInfoVector() const {return fBasicMarketDataDependantInfo;};

			/** Optimization method called after setting time grid and size of uniform laws needed in order to initialise 
				only once some data with the relevant data size.
			*/ 
			virtual void InitialiseDimension();

			/** This method is called for each price computed in order to set variables:
				{@link fStoreMarketDataDependantInfo}, {@link fStoreCorrelation}, {@link fIsThetaComputation} 
				and {@link fIsBasicComputation}. 

				@see StoreMarketDataDependantInfo
				@see StoreCorrelation

				@param param is the market data.
				@param option is the option to price.
				@param model is the Monte Carlo meta-model used.
				@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 

			 */
			virtual void InitialiseData(	const market_data::CSRMarketData	&param,
											const instrument::CSRInstrument		*instr,
											const CSROptionMonteCarloMetaModel	*model,
											const SSBumpKey						&bumpKey) ;

			/** Method called to know if market data dependent infos must be stored. 
				It is the case for basic price computation and when market data dependent infos are 
				different from the one used for basic price.

				@return true if market data dependent infos must be stored, false otherwise.
			 */
			inline bool StoreMarketDataDependantInfo() const {return fStoreMarketDataDependantInfo;};

			/** Method called to know if there is correlation calibrated by the model as it is done
				in stochastic volatility model. If true then fStoreCorrelation will be set at
				true when implied volatility change (vega or total delta/gamma computation).
				Default implementation return false.

				@see StoreCorrelation

				@return true if some correlations are calibrated by the model, false otherwise.
			 */
			virtual bool IsCorrelationCalibrated () const {return false;}

			/** Method called to know if correlation object must be stored. 
				It is the case for basic price computation and when correlations are 
				different from the one used for basic price.

			@return true if correlation object must be stored, false otherwise.
			*/
			inline bool StoreCorrelation() const {return fStoreCorrelation;};

			/** Give a reference on the quanto component of the nth diffused underlying. It is called in order
				to fill the decomposition of the corresponding forex on the base of the diffused ones.
			 
			 @return a reference on the quanto component of the nth diffused underlying.
			 */
			inline _STL::vector<SSBasisComponent>& GetNthQuantoComponent(int nth) {return fQuantoComponent[nth];};

			/** Returned the number of strikes at a given maturity used for model calibration. 
			*	Return 0 when the model can be calibrated on an arbitrary number of strike or a 
			*	positive value when the model can only be calibrated on a specific number of strike per maturity.
			*	
			*/
			inline int GetFixedStrikeCount() const {return fFixedStrikeCount;};

			/** Set the sequence shift to use.
			*/
			inline void SetSequenceShift(int sequenceShift) {fSequenceShift = sequenceShift;};


			/** Set the credit underlying. (For credit payoff) 
			@param underlyingCode is the code of the underlying, an issuer or a credit basket
			@param startDate is the start date for defaults to be considered
			@param endDate is the end date for defaults to be considered
			@param currency is the currency for which defaults must be computed
			@param seniority is the seniority for which defaults must be computed
			@param defaultEvent is the default event for defaults must be computed
			@since 6.0
			*/
			virtual void SetCreditUnderlying(	long	underlyingCode,
												long	startDate,
												long	endDate,
												double	quantity = 1.,
												long	currency = 0,
												long	seniority = 0,
												long	defaultEvent = 0);

			/** Set the credit copula used to correlate default events. (For credit payoff) 
			@param copula is a pointer to the copula to be used (it must be cloned it is modified)
			@param isCorrelationUniform tells if the correlation is uniform, otherwise it is a matrix
			@since 6.0
			*/
			virtual void SetCreditCopulaData(const math::CSRCopulaData* copula, bool isCorrelationUniform);

			/** This method is called for each price computed after InitialiseData
			@param param is the market data.
			@param option is the option to price.
			@param model is the Monte Carlo meta-model used.
			@param bumpKey is a SSBumpKey allowing to know which computation is currently done. 
			@since 6.0
			@see InitialiseData
			*/
			virtual void InitialiseCreditData(	const market_data::CSRMarketData&	param,
												const instrument::CSRInstrument*	instr,
												const CSROptionMonteCarloMetaModel*	model,
												const SSBumpKey&					bumpKey) ;

			/** Return the number of credit underlyings
			@since 6.0
			*/
			virtual int GetCreditUnderlyingCount() const;

			/** Return the maximal number of antithetic samplings.
			@since 6.0
			*/
			virtual int GetAntitheticSamplingMaximalCount() const;

			/** Elements to be displayed in the Monte Carlo Metamodel dialog
			@param elementsToUse output, map with true or false for each element of eOptionMonteCarloGeneralDialog
			if true, the element is diplayed, if false it is hidden.
			@since 6.0
			*/
			virtual void DialogComponents(_STL::map<gui::CSRMonteCarloGeneralTab::eOptionMonteCarloGeneralDialog,bool>& elementsToUse) const;

		protected :

			/** True during global calibration, false otherwise.
			*/
			bool fIsInGlobalCalibration;

			/** Id of the current calibration.
			 */
			long fCalibrationID;

			/** Fixed number of strikes at a given maturity used for calibration. Default value is 0.
			*	Must be settled in constructor of inherited path generator when needed.
			*/
			int fFixedStrikeCount;

			/**	True if market data dependent infos must be stored. False otherwise.
				Initialized in method {@link InitialiseData(}
			*/
			bool fStoreMarketDataDependantInfo;

			/**	True if market data dependent infos must be stored. False otherwise.
				Initialized in method {@link InitialiseData(}

				@see IsCorrelationCalibrated() 
			*/
			mutable bool fStoreCorrelation;
			
			/** Vector of underlying's diffusion parameters.
			 */
			_STL::vector<CSRDiffusionParameter*> fDiffusionParameter;

			/** Internal. Store basic diffusion parameters to ensure that current diffusion parameters
				are properly initialized.
			 */
			_STL::vector<CSRDiffusionParameter*> fBasicDiffusionParameter;

			/** Spot of diffused underlyings.
			 */
			_STL::vector<double>				fSpotVector;
			
			/** Forward price of diffused underlying on the time grid.
			 */
			mutable _STL::vector< _STL::vector<double> > fForward;

			/** NMU coefficient a of diffused underlying on the time grid.
			*/
			mutable _STL::vector< _STL::vector<double> > fNMUa;

			/** NMU coefficient b of diffused underlying on the time grid.
			*/
			mutable _STL::vector< _STL::vector<double> > fNMUb;

			/** Quanto multiplicative factor for diffused underlying on the time grid.
			*/
			mutable _STL::vector< _STL::vector<double> > fQuantoFactor;

			/** Market data dependent infos.
			*/
			mutable _STL::vector<double> fMarketDataDependantInfo;


			/**	Yield curve light handling zero coupon computation on server side for discounting in Option currency. 
			*/
			mutable CSRYieldCurveLightClient* fDiscountYieldCurveLightClient;

			/**	Vector of Yield curve light handling zero coupon computation on server side. 
			*	One yield curve light per cash flow currency and one for option currency in order to compute FX forward.
			*/
			mutable _STL::vector<CSRYieldCurveLightClient*> fCSRYieldCurveLightClientVect;

			/** Forward price of diffused underlying on the time grid used for basic price computation.
			*/
			mutable _STL::vector< _STL::vector<double> > fBasicForward;
			
			/** NMU coefficient b of diffused underlying on the time grid used for basic price computation.
			*/
			mutable _STL::vector< _STL::vector<double> > fBasicNMUa;

			/** NMU coefficient b of diffused underlying on the time grid used for basic price computation.
			*/
			mutable _STL::vector< _STL::vector<double> > fBasicNMUb;

			/** Quanto multiplicative factor for diffused underlying on the time grid used for basic price computation.
			*/
			mutable _STL::vector< _STL::vector<double> > fBasicQuantoFactor;

			/** Market data dependent infos used for basic price computation.
			*/
			mutable _STL::vector<double> fBasicMarketDataDependantInfo;

			/** Date of the market data used for basic price computation.
				It is different from computation date during theta computation.
			 */
			long fToday;

			/** Internal. Vector storing the mapping between underlying for payoff, timestep and path feature 
				with the index of uniform law used. Index in vector is the timestep*numberOfUnderlying + underlying
			 */
			_STL::vector<_STL::map<int,CSRLocalPathGeneratorServer::SSUniformLawID> > fUniformLawMapping;

			/** Vector of diffused underlying infos.

			@see finance::SSDiffusedUnderlying
			 */
			_STL::vector<SSDiffusedUnderlying>	fUnderlyingDiffused;

			/** Map between underlying for payoff code and its index in {@link fUnderlyingForPayoff} in order to 
				quickly identify an underlying for payoff from its sicovam code.  
			 */
			_STL::map<long,int>					fUnderlyingForPayoffIndexMap;

			/** Vector of underlying for payoff infos.

			@see finance::SSUnderlingForPayoff
			*/
			_STL::vector<SSUnderlingForPayoff>	fUnderlyingForPayoff;


			/**	Vector to identify which data are different from those used in basic price computation. 

				There are stored by underlying to diffuse and initialized by method {@link FillModifiedData}.
			*/
			mutable _STL::vector<_STL::vector<eDataToUseType> > fLocalDataToUseTypeVector;


			/** Vector storing time grid (absolute dates).
			 */
			_STL::vector<long>		fDates;

			/** Map inverting the vector storing time grid (absolute dates).
			*/
			_STL::map<long, int>	fFixingDateMap;
	
			/**  Quanto component of the nth diffused underlying. It is called in order
			to fill the decomposition of the corresponding forex on the base of the diffused ones.
			 */
			_STL::vector<_STL::vector<SSBasisComponent> > fQuantoComponent;


			/** Number of uniform law needed to generate one path(eg transformed in normal law) and to manage
				path features.
			*/ 
			int				fUniformLawSize;	

			/** Number of normal law needed to generate one step for the underlying.
			 */ 
			int	fNormalLawSizeByStep;	

			/** Number of not-forex underlying to diffuse in the simulation. 
			*/
			int fEquityDiffusedCount;	

			/** Number of forex underlying to diffuse in the simulation. 
			*/
			int fForexDiffusedCount;

			/** Current computation date.
			 */
			long fComputationDate;
			
			/** True if current computation is done for theta.
			*/
			bool fIsThetaComputation;
			
			/** True if current computation is the basic one.
			*/
			bool fIsBasicComputation;

			/** A shift to apply to the uniform random generator: instead of using sampling
			*	from 1 to N the sampling used will be the one between 1+fSequenceShift and N+fSequenceShift.
			*/
			int fSequenceShift;

			/**
			* Internal.
			*/
			SSBumpKey	fLastInitializedBumpKey;

			/**
			* Pointer on the client class handling yield curve diffusion.
			*/
			CSRInterestRateLocalPathGeneratorClient * fInterestRateLocalPathGenerator;




		// GUI elements
		public:

			/**
			*	Set the pointer on the client class handling yield curve diffusion. It is initialized from the one set up in the Monte Carlo Model parameters.
			*/
			void SetInterestRateLocalPathGenerator(CSRInterestRateLocalPathGeneratorClient* interestRateLocalPathGenerator);

			/**
			*	Accessor on class handling yield curve diffusion. 
			*/
			inline CSRInterestRateLocalPathGeneratorClient * GetInterestRateLocalPathGenerator() {return fInterestRateLocalPathGenerator;};

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
		};


		/**
		*	Client class to handle the yield curve diffusion during Monte Carlo. Current implementation available
		*	are deterministic interest rate and Stochastic volatility Displaced Diffusion Libor Market Model.
		*/
		class SOPHIS_MONTECARLO CSRInterestRateLocalPathGeneratorClient
		{
		public:
			/**
			* Constructor.
			*/
			CSRInterestRateLocalPathGeneratorClient();

			/**
			* Destructor.
			*/
			virtual ~CSRInterestRateLocalPathGeneratorClient();
			
			/**
			* Initialize the call back on the path generator class. Simulation parameters like dates will remains on the 
			*/
			void SetPathGenerator(const CSRLocalPathGeneratorClient& pathGenerator);

			/** 
			* This method has to be implemented in order to return the name used for the prototype registration 
			* on the client and server side.
			* @see CSRInterestRateLocalPathGeneratorServer
			* @see DECLARATION_INTEREST_RATE_PATHGENERATOR_CLIENT
			* @see DECLARATION_INTEREST_RATE_PATHGENERATOR_SERVER
			*/
			virtual _STL::string GetServerID() const;

				/** Initialise the Interest Rate Path Generator with static data stored in an archive {@link sophis::tools::CSRArchive}
			 *	This is done in order to create one or several CSRInterestRateLocalPathGeneratorClient object on the Client side.
			 *
			 *	@param archive is the archive storing the data needed to initialise the CSRInterestRateLocalPathGeneratorClient
			 */
 			 virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** Initialise the CSRInterestRateLocalPathGeneratorClient with the market dependent data stored in an archive {@link sophis::tools::CSRArchive}
			*	
			*	This is done in order to create one or several Interest Rate Path Generator object on the Client side.
			*	@param archive is the archive storing the data needed to initialise the CSRInterestRateLocalPathGeneratorClient
			*/
 			 virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/** Clone for this object. Used for prototypal construction of the object, don't implement this method in any child class.
			*/
			virtual CSRInterestRateLocalPathGeneratorClient* Clone() const;

			/**	Static method allowing access to instance of class inherited from CSRInterestRateLocalPathGeneratorClient for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRInterestRateLocalPathGeneratorClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();


				/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
	

			virtual void InitialiseStaticData(	const CSROptionMonteCarloMetaModel	*model,
												const instrument::CSRInstrument		&instrument,
												const market_data::CSRMarketData	&contextGeneral);

			virtual void FillSimulationDateNeeded(_STL::vector<long>& fixingDates) const;

			virtual void InitialiseData(	const market_data::CSRMarketData	&param,
											const CSROptionMonteCarloMetaModel	*model,
											const instrument::CSRInstrument		&instrument,
											const SSBumpKey						&bumpKey);
			
			virtual bool RunAndSaveCalibration( CSROptionMonteCarloMetaModel		&instrumentMetaModel,
												CSROptionMonteCarloMetaModel		&modelToSave,
												const instrument::CSRInstrument		&instrument, 
												const market_data::CSRMarketData	&context,
												_STL::set<long>*					alreadyCalibratedUnderlying);

			virtual	void ComputeNormalLawSizeByStep(const _STL::vector<long> & dateVector);

			inline int	GetInterestRateNormalLawSizeByStep() const {return fNormalLawSizeByStep;};


			virtual void	FillChangingParametersDate(	const finance::CSROptionMonteCarloMetaModel	*model,
														const instrument::CSRInstrument				&instrument,
														_STL::set<long>							&changingParametersDate) const;


			virtual void FillLiborDataForCorrel(_STL::vector<math::SSLiborPeriod> & liborData) const;


			/**
			* When there are N libor data with n living libor (startDate<fixingData.fixingDate)
			* and M equity, and we need k factor in IR model:
			*	- equityCorrelationMatrix is M x M in input and (M+k) x (M+k) in output
			*	- liborEquityCorrelationMatrix is M x n in input	
			*/
			virtual void CompleteCorrelationMatrix(	const market_data::CSRMarketData & param,
													_STL::vector<math::SSLiborPeriod>		&liborData,
													long											startDate,
													::boost::numeric::ublas::matrix<double>	&equityCorrelationMatrix,
													::boost::numeric::ublas::matrix<double>	&liborEquityCorrelationMatrix) const;

			virtual void CompleteCorrelationMatrixForGlobalPCA(	const market_data::CSRMarketData				&param,
																_STL::vector<math::SSLiborPeriod>				&liborData,
																long											startDate,
																::boost::numeric::ublas::matrix<double>	&equityCorrelationMatrix, 
																::boost::numeric::ublas::matrix<double>	&equityLiborCorrelationMatrix) const;

			long GetFamilyID() const	{return fFamilyID;};


			virtual void GetSpecificRiskSources(	const instrument::CSRInstrument& instr, 
													const finance::CSROptionMonteCarloMetaModel& model,
													/*out*/ sophis::CSRComputationResults& rs, 
													unsigned long bitFlag ) const;

		protected:
			const CSRLocalPathGeneratorClient* fPathGenerator;

			int fNormalLawSizeByStep;
			long fFamilyID;
		};

		class SOPHIS_MONTECARLO CSRLiborMMFrontParametricInterpolation
		{
		public:
			CSRLiborMMFrontParametricInterpolation();
			virtual ~CSRLiborMMFrontParametricInterpolation();

			virtual CSRLiborMMFrontParametricInterpolation* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRLiborMMFrontParametricInterpolation for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLiborMMFrontParametricInterpolation, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
		};

		class SOPHIS_MONTECARLO CSRLiborMMBackParametricInterpolation
		{
		public:
			CSRLiborMMBackParametricInterpolation();
			virtual ~CSRLiborMMBackParametricInterpolation();

			virtual CSRLiborMMBackParametricInterpolation* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRLiborMMParametricInterpolation for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLiborMMBackParametricInterpolation, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
		};


		class SOPHIS_MONTECARLO CSRLiborMMPrincipalComponents
		{
		public:
			CSRLiborMMPrincipalComponents();
			virtual ~CSRLiborMMPrincipalComponents();

			virtual CSRLiborMMPrincipalComponents* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRLiborMMParametricInterpolation for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLiborMMPrincipalComponents, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
		};

		class CSRLiborMarketModelClient;

		class SOPHIS_MONTECARLO CSRLiborMMInstrumentSelection
		{
		public:
			CSRLiborMMInstrumentSelection();
			virtual ~CSRLiborMMInstrumentSelection();

			virtual CSRLiborMMInstrumentSelection* Clone() const;


#ifndef GCC_XML
			//called in FillInstruments. Create new CSRLMMInstrument for which memory must be handled.
			virtual void FillLMMInstruments(	const sophis::finance::CSROptionMonteCarloMetaModel& model,
												_STL::vector< math::CSRLMMInstrument* > & vI, 
												_STL::vector< bool > & activatedInstr) const;
#endif // GCC_XML

			virtual void FillInstruments(_STL::vector<math::CSRLMMInstrumentForCalibration>& v,
										const finance::CSRLiborMarketModelClient& libor,
										const instrument::CSRInstrument& instrument,
										const finance::CSROptionMonteCarloMetaModel& model,
										const market_data::CSRMarketData& context) const;

			virtual long GetEndDate(const sophis::finance::CSRLiborMarketModelClient& libor,
									const sophis::instrument::CSRInstrument& instrument,
									const sophis::finance::CSROptionMonteCarloMetaModel& model,
									const sophis::market_data::CSRMarketData& context) const;

			virtual void UpdatePrices(	const sophis::finance::CSROptionMonteCarloMetaModel& model,
										_STL::vector<sophis::math::CSRLMMInstrumentForCalibration> calibInstr) const;

			/**	Static method allowing access to instance of class inherited from CSRLiborMMInstrumentSelection for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLiborMMInstrumentSelection, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Create the list of tab elements for CSRLiborMMInstrumentSelection. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;
		};

		class SOPHIS_MONTECARLO CSRLMMObjectiveFunction_Factory
		{
		public:
			CSRLMMObjectiveFunction_Factory();
			virtual ~CSRLMMObjectiveFunction_Factory();

			virtual CSRLMMObjectiveFunction_Factory* Clone() const;

			virtual math::CSRLMMObjectiveFunction* GetObjectiveFunction(const sophis::finance::CSROptionMonteCarloMetaModel& model, 
																		const sophis::instrument::CSRInstrument &instrument,
																		const math::CSRLiborMarketModel* lmm) const;

			/**	Static method allowing access to instance of class inherited from CSRLiborMMCalibrationObjectiveFunction for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRLMMObjectiveFunction_Factory, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			/** Create the list of tab elements for CSRLiborMMCalibrationObjectiveFunction. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const;

			virtual void SetResults(sophis::finance::CSROptionMonteCarloMetaModel& model,
									const sophis::math::CSRLMMObjectiveFunction* fun) const;

		};


		//---------------------------------------------------------------------------

		/** Outputs object are interface Buffer class correspond to the output of a payoff.
		*	It Got 2 main type of method :
		*		- On the server side : the Set... method take the last result of a computation done by the CSRServerPayoff object
		*		  in a temporary buffer and store it in a global buffer.
		*		- On the client side : the calculate... methods compute a price or a greek from the result stored in the buffer CSRClientOutput.
		*/
	
		class CSRGenericIndicatorServer;
		/** Buffer Object on the client side.
		*/
		class	SOPHIS_MONTECARLO CSRClientOutput
		{
		public :

			/** Default constructor.
			*/
			CSRClientOutput();

			/**	Destructor.
			*/
			virtual ~CSRClientOutput();

			/** Fill the rough result vector with aggregated result coming from simulation.
			*	@param task is an input. It is the number of the task for which we want results.
			*	@param vectorToFill is an output. It is the vector in which we store results.
			*	@param weightedSamplingCount is an output. It is the real number of sampling computed.
			*	@param squareWeightedSamplingCount is an output. It is the real number of sampling computed with square weight
			 */
			virtual void	FillResults(	int						task, 
											_STL::vector<double>	&vectorToFill,
											int						&samplinCount,
											double					&weightedSamplingCount,
											double					&squareWeightedSamplingCount);


			/** Create an archive storing all the data needed to initialise a CSRServerOutput on the server side.
			 *	@return CSRArchive storing all the data needed to initialise a CSRServerOutput.
			 */
			const sophis::tools::CSRArchive& CreateStaticServerArchive() const;

			/** Store all the data needed to initialise a CSRServerOutput in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRServerOutput for the Monte Carlo loop on the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** Initialise the CSRClientOutput with the data stored in an archive {@link sophis::tools::CSRArchive}
			*	After computation during Monte Carlo loop we initialise CSRClientOutput in order to finalize computation.
			*	@param archive is the archive storing the data needed to initialise the CSRClientOutput
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);

			/** Give the registered name of the server computation object containing the valuation procedure.
				
				@return the registered name of the server computation object containing the valuation procedure.
			*/
			virtual _STL::string GetServerOutputID() const;

			/** Set the buffer size.

				@param indicatorSizeForDifference is the number of values computed as well as when computing basic price
						and when computing price for greeks. In the last case the difference to the basic value is stored.
				@param supplementaryIndicatorSizeForPrice is the number of values computed only when computing basic price.
				@param supplementaryIndicatorSizeForGreeks is the number of values computed only when computing price for greeks. 
			 */
			void SetBufferSize(	int indicatorSizeForDifference, 
								int supplementaryIndicatorSizeForPrice,
								int supplementaryIndicatorSizeForGreeks);

			void SetInternalBufferSize(int internalBufferSize,  bool computeStandardDeviation);

			void	FillStandardDeviation(_STL::vector<double>& vectorToFill);


			void	FillUnderlyingForward(_STL::vector<double>& vectorToFill);

			inline void SetMustStoreResultsBySampling(bool mustStoreResultsBySampling) {fMustStoreResultsBySampling = mustStoreResultsBySampling;};

			inline void SetIsAmerican(bool isAmerican) {fIsAmerican = isAmerican;};

			inline const _STL::vector<SSResultBySampling>&	GetResultBySampling() const {return fResultBySampling;};
			inline _STL::vector<CSRClientOutput*>&	GetControlVariatesClientOutput() {return fCVClientOutput;};

			void ClearControlVariatesClientOutput();

		protected :
			/**
			 * Number of task initialised after computation by {@link CSRClientoutput::SetData}.	
			 */
			int	fTaskSize;

			/** Temporary buffer size.
			 */
			int	fTemporaryBufferSize;

			/** Number of values computed as well as when computing basic price and when computing price for greeks. 
			 */
			int fIndicatorSizeForDifferences;

			/** Number of values computed for basic price.
			 */
			int fSizeForBasicPrice;

			/**  Number of values computed for price for greeks. 
			 */
			int	fSizeForGreeks;

			
			/** After computation give the real number of sampling computed.
			 */
			int fSamplingCount;

			/** After computation give the real number of sampling computed, may be weighted in case of american monte carlo.
			 */
			double fWeightedSamplingCount;

			/** After computation give the real number of sampling computed, may be squareweighted in case of american monte carlo.
			 */
			double fSquareWeightedSamplingCount;

			// to manage greeks coherently with price computation
			mutable _STL::vector<double>  fResultsBuffer;

			/** CSRArchive storing Data needed to initialize Server object
			*/
			mutable sophis::tools::CSRArchive* fServerArchive;

			bool	fComputeStandardDeviation;
			int		fInternalBufferSize;
			mutable _STL::vector<double>  fInternalBuffer;

			bool fIsAmerican;

#ifndef GCC_XML
			mutable _STL::vector<_STL::vector<sophis::math::MatrixD> > 		fULeastSquare;
			mutable _STL::vector<_STL::vector<sophis::math::VectorD> > 		fVLeastSquare;
#endif // GCC_XML

			/** If true the monte carlo server will produce as many prices as trajectories, not only the average of them.
			*   Those prices will be calculated in the first pricing and stored in fResultBySampling, to be reused in the
			*   calculation of the Greeks. */
			bool fMustStoreResultsBySampling;

			_STL::vector<SSResultBySampling>	fResultBySampling;
			_STL::vector<CSRClientOutput*>		fCVClientOutput;


#ifndef GCC_XML
		public:
			inline double GetSamplingCount()const {return fSamplingCount;};
			inline double GetWeightedSamplingCount() const {return fWeightedSamplingCount;};
			inline double GetSquareWeightedSamplingCount() const {return fSquareWeightedSamplingCount;};
			inline	CSRGenericIndicatorServer & GetGenericIndicatorServer() const {return fGenericIndicatorServer;};
		protected:
			mutable CSRGenericIndicatorServer fGenericIndicatorServer;
#endif // GCC_XML

		public:
			/** 
			*	@deprecated since 5.3
			*/
			virtual double	CalculatePrice(	const market_data::CSRMarketData	&param, 
											const sophis::instrument::CSROption *option,
											int									samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculatePrice not implemented anymore. Use CSROptionMonteCarloInterface::GetTheoreticalValue to compute theoretical price.");
			}
			/** 
			*	@deprecated since 5.3
			*/
			virtual double	CalculateEpsilon(const market_data::CSRMarketData	 &param, 
											 const sophis::instrument::CSROption *option, 
											 int								 which, 
											 int								 samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculateEpsilon not implemented anymore. Use CSROptionMonteCarloInterface::ComputeDifferencePriceForGreeks to compute greeks.");
			}

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual double	CalculateDelta(	const market_data::CSRMarketData	&param, 
											const sophis::instrument::CSROption *option, 
											double								hdelta, 
											int									which, 
											int									samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculateEpsilon not implemented anymore. Use CSROptionMonteCarloInterface::ComputeDifferencePriceForGreeks to compute greeks.");
			}

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual double	CalculateGamma(	const market_data::CSRMarketData	&param, 
											const sophis::instrument::CSROption *option, 
											double								hdelta, 
											int									j, 
											int									k, 
											int									samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculateEpsilon not implemented anymore. Use CSROptionMonteCarloInterface::ComputeDifferencePriceForGreeks to compute greeks.");
			}

			/**  			
			*	@deprecated since 5.3.0
			*/
			virtual double	CalculateRho(	const market_data::CSRMarketData	&param, 
											const sophis::instrument::CSROption *option, 
											double								hRho, 
											int									which, 
											int									samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculateEpsilon not implemented anymore. Use CSROptionMonteCarloInterface::ComputeDifferencePriceForGreeks to compute greeks.");
			}

			/**  
			*	@deprecated since 5.3.0
			*/
			virtual double	CalculateConvexity(	const market_data::CSRMarketData	&param, 
												const sophis::instrument::CSROption *option, 
												double								hRho, 
												int									which, 
												int									samplingCount)const
			{
				throw sophisTools::base::GeneralException("Deprecated method CalculateEpsilon not implemented anymore. Use CSROptionMonteCarloInterface::ComputeDifferencePriceForGreeks to compute greeks.");
			}



			/** 
			*	@deprecated since 5.3.0
			*/
			const sophis::tools::CSRArchive& CreateServerArchive() const
			{
				throw sophisTools::base::GeneralException("Deprecated method CreateServerArchive not implemented anymore. Now output are static objects.");
			}

			/** 
			*	@deprecated since 5.3.0
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const 
			{
				throw sophisTools::base::GeneralException("Deprecated method GetData not implemented anymore. Now output are static objects.");
			}

		};

		/** Class CSRRegressionClient handle the regression used in the American Monte Carlo
		*	on the client side.
		*	-	get the matrix U and the vector V from the server side.
		*	-	computing the coefficients using the bases functions and the U and V given by the server side.
		*	-	sent the coefficients on the server side.
		*/ 
#ifndef GCC_XML
		class	SOPHIS_MONTECARLO CSRRegressionClient
		{
		public :
			DECLARATION_REGRESSION_CLIENT(CSRRegressionClient);
			/** Default constructor	
			*/
			CSRRegressionClient();

			/**	Destructor 
			*/
			virtual ~CSRRegressionClient();

			/** Store all the data needed to initialise a CSRRegressionServer in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create the CSRRegressionServer for the server side.
			*
			*	@param archive is the archive in which we store data
			*/

			_STL::string GetRegressionClientID() const;
			virtual void	SetStaticData(_STL::vector<long> & dates);
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;
		
			/** Store intermediate date in an archive {@link sophis::tools::CSRArchive}.
			*	Those data are the coefficients which are the result of the LS Method.
			*
			*	@param iteration is the number of the current iteration
			*	@param archive is the intermediate archive storing the data needed to be sent to the server side.
			*/
			virtual void	GetIntermediateData(sophis::tools::CSRArchive& archive) const;
				
			/** Get intermediate data CSRRegressionserver.
			*	Those data are the matrix U and the vector V which are needed to compute the coefficient of the LS method.
			*
			*	@param archive is the intermediate archive storing the data from the client side.
			*/
			virtual void	SetIntermediateOutput(_STL::vector<_STL::vector<sophis::math::MatrixD> >	uLeastSquare,
												  _STL::vector<_STL::vector<sophis::math::VectorD> >	vLeastSquare);
			/** Set the number of tasks
			*/
			virtual void	SetNbTasks(const int nbTask);

			/** Set the current task
			*
			*	@param		iTask is the number of task
			*/
			virtual void	SetCurrentTask(const int task);

			/** Set the current iteration
			*/
			virtual void	SetIteration(const int iteration);

			/** Get the current iteration
			*/
			virtual int&	Iteration();

			/** Get the number of dates per block in a vector			
			*/
			virtual _STL::vector<int> & BlockSize();

			/**	Get the number of Base Functions for each block in a vector
			*/
			virtual _STL::vector<int> & BaseFuncSize();

			/** Get and change the boundary using a payoff method
			*/
			virtual _STL::vector<sophis::math::VectorD> & Boundary();
			
			/** Get the matrix U of the least square method for a task and a bloc number.
			*/
			sophis::math::MatrixD & ULeastSquare(const int task, const int block);

			/** Get the vector V of the least square method for a task and a bloc number.
			*/
			sophis::math::VectorD & VLeastSquare(const int task, const int block);

			/** Get the coefficients  which are the result of the least square method 
			*	for a task and a bloc number.
			*/
			sophis::math::VectorD & Coeff(const int task, const int block);

			/** Get the coefficients  which are the result of the least square method 
			*	for all the task and all the blocks
			*/
			_STL::vector<_STL::vector<sophis::math::VectorD> > & CoeffVector();
			
			/** Compute the coefficients of the regression.
			*	Aggregate the matrix U and the vector V
			*	Compute the coefficients for each date bloc U * coeff = V
			*/
			virtual void	ComputeCoefficients(CSRServerOutput * serverOutPut);



			/** return the weight for the price for the current iteration
			*/
			virtual double	WeightForRescalePrice() const;

			/** return the weight for the Matrix U and the vector V for the current iteration
			*/

			virtual double	WeightForRescaleUV() const;

			virtual void	Init();
		
			bool CSRRegressionClient::TestSolver() const;	//CALA

		protected:

			/** Solver to resolve the least square U * coefficient  = V
			*/
			sophis::math::Solver *													fSolver;
			
			/** Matrix U and Vector V needed for the Least Square Method.
			*/
			_STL::vector<_STL::vector<sophis::math::MatrixD> > 						fULeastSquare;
			_STL::vector<_STL::vector<sophis::math::VectorD> >						fVLeastSquare;

			/** The result of the Least Square Method: U * Coefficient = V.
			*/
			_STL::vector<_STL::vector<sophis::math::VectorD> >						fCoeff;

			/** The Boundary function for each block date, each task
			*/
			_STL::vector<sophis::math::VectorD>										fBoundary;

			double																	fWeightPriceSlope;
			double																	fWeightPriceZero;
			double																	fWeightUVSlope;
			double																	fWeightUVZero;


			/** Number of the iteration
			*/
			int																		fIteration;	


			/** Number of task that we are working at
			*/
			int																		fCurrentTask;	

			/** Number of tasks in global
			*/
			int																		fNbTasks;		

			/** Current task
			*/
			int																		fTask;		

			/** Date of simulations
			*/
			_STL::vector<long>														fDates;

			/** Number of blocks (usually blocks of dates)
			*/
			int																		fNbBlocks;

			/** Number of functions per Bloc (number of points per bloc)
			*/
			_STL::vector<int>														fBlockSize;

			/** Number of base functions of regression (number of points per bloc)
			*/
			_STL::vector<int>														fBaseFuncSize;

			bool																	fInitialized;
		public:
		/**	Static method allowing access to instance of class inherited from CSRRegressionClient for prototype instantiation.
		*
		*	@see sophis::tools::CSRPrototype
		*/
			typedef	sophis::tools::CSRPrototype<CSRRegressionClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};
#endif // GCC_XML

//-----------------------------------------------------------------------------

		/** Class CSRClientPayoff handle risk sources analysis and ServerPayoff creation.
		*
		*	When computing price and greeks at a given date we consider as "static" every data 
		*	which not depend on Market data. Making difference between static which are stored 
		*	once by calling {@link CSRClientPayoff::GetStaticData} and not static datas which 
		*	are stored at every price computation in the procedure by callying {@link CSRClientPayoff::GetData}
		*	improve memory and bandwidth cunsumption. 
		*
		*/
		class SOPHIS_MONTECARLO CSRClientPayoff
		{
		public :
			/**	Default Constructor
			*/
			 CSRClientPayoff();
	 
			 static CSRClientPayoff* CreateInstance(const sophis::instrument::CSRInstrument& instr);
			 static void InitializeClientPayoff(CSRClientPayoff* po, const sophis::instrument::CSRInstrument& instr); 
			 static void CleanInstance(CSRClientPayoff* payoff);
	 
			/**	Initialise the payoff for a given option. You should call it in any derived class to 
			*	initialize properly fGeneratorID. 
			*
			*	@param	option is the option for which this object handle actualized payoff computation
			*/
			 virtual void Initialise(const instrument::CSRInstrument* instr);


			 /**	Method to set up the family ID of yield curves needed for pricing.
			 *	@param	instrument is the instrument for which this object handle actualized payoff computation
			 *	@param	familyID is vector of family code to fill
			 *
			 *	Default implementation fill by using the instrument discount family code.
			 */
			 virtual void FillYieldCurveFamilyID(const instrument::CSRInstrument& instr, _STL::vector<long>& familyID);


			 /** Test if the payoff is in the right state to be priced.
			 It is called by {@link MultiUnderlyingInterface::ValidInstrument} in order to know if option is valid.
			 @return true if the payoff is valid.
			 By default, return true.
			 */
			 virtual	Boolean		ValidInstrument(bool isInInitialisation = true) const	;


			 /** Initialise the future fixing dates needed by payoff. 
			 */
			virtual void	InitDates(const market_data::CSRMarketData	&contextGeneral);

			virtual void GetFixingDates(_STL::set<long>& fixingDates) const;
			/** Must Initialise fYieldCurveUpperBoundary to the greatest zero coupon date needed by the payoff.
			*	Default implementation call {@link GetExpiryForRho} on instrument
			*
			*	@param instr is the instrument priced by Monte Carlo simulation.
			*	@param contextGeneral is the basic context used by Monte Carlo simulation to compute basic price.
			*/
			virtual void	InitYieldCurveUpperBoundary(const instrument::CSRInstrument*	instr,
														const market_data::CSRMarketData	&contextGeneral);
		
			virtual bool InitialisePathGeneratorForInstrumentManagement(const sophis::instrument::CSRInstrument* instr,
																		const market_data::CSRMarketData	&context, 
																		CSRLocalPathGeneratorServer			*&pathGeneratorToCreate) const;
			virtual instrument::CSRInstrument::eAutomaticTicketType GetAutomaticTicket(long date, std::vector<instrument::CSRInstrument::AutomaticTicket> &list) const;
		
	
		public:

			/** Check payoff definition. It is called when initializing Monte Carlo meta model in method {@link CSROptionMonteCarloMetaModel::InitialiseDataFromInstrument}.
			*
			* @Return true if the payoff definition is correct, false otherwise.
			*/
			virtual bool IsValidPayoffDefinition(_STL::vector< _STL::pair<_STL::string , sophis::dataIntegrity::EMessageLevel > > & errorMessageVector) const;


			/**	At the beginning of a pricing this method is called in order to set all static data
			*	which depend only on gApplicationContext such as todays date. 
			*	This function must find all dates needed in the simulation, and populates a structure so that method 
			*	{@link CSRClientPayoff::GetNthDate} return the nth dates needed for payoff evaluation in sophis convention.
			*	
			*	@param option is the option priced by Monte Carlo simulation.
			*	@param contextGeneral is the basic context used by Monte Carlo simulation to compute basic price.
			*/
			 virtual void InitialiseStaticData(	const instrument::CSRInstrument*	instr,
												const market_data::CSRMarketData	&contextGeneral);

			 /**	Destructor
			 */
			 virtual ~CSRClientPayoff();

			 /** After risk analysis this give real risk sources (equity, forex) and rho sources
			 *
			 */
			 void GetRiskAndRhoSources(	_STL::vector<long>	&RiskSources,
										_STL::vector<long>	&rhoSources);

			 /** Get foreign currency risk sources.
			 *	@param foreignSources is an output vector containing codes of foreign currencies.
			 */
			 virtual void GetForeignCurrencyRiskSources(_STL::vector<long>& foreignSources) const= 0;

			/** Check if a greek should be computed
			*	@param	resultToCompute is the greek we want to know if it should be computed.
			*	@see eGreeksToCompute
			*	@return true if the greek should be computed, else return false.
			*	@since 6.0
			*/	
			virtual bool ComputeResults(eGreeksToCompute resultToCompute) const;

			/** 
			*	 Populates the array by collecting the characteristic dates of each clause. 
			*	@param param is the market data.
			*/
			 virtual void	 InitialiseMarketDependentData(const market_data::CSRMarketData	&param,
															const CSROptionMonteCarloMetaModel	*model,
															const instrument::CSRInstrument		&instrument);
			 
			 /**	Refresh the strike of the option with those stored in the structure produit.
			 *		This function is called when we want to compute implied Strike.                                                                    
			 *	@param option is the option for which we handle Monte Carlo simulation.
			 */
			 virtual void RefreshStrike(const instrument::CSROption*option);

			/** Factory for creation of a {@link new_CSRClientOutput} object.
			*	@param option is the option for which we handle Monte Carlo simulation.
			*	@return a pointer on the new_CSRClientOutput object created.
			*/
			 virtual CSRClientOutput*	new_CSRClientOutput(const CSROptionMonteCarloMetaModel	*option) const;

			 /** Get equity and forex underlyings really used to define corresponding payoff.
			 *
			 *	When computing an option value in strike option currency we need to convert payment in other currencies
			 *	when the are paid. If the amount F(T_f,T_p) is known at fixing date T_f and is paid at settlement 
			 *	date T_p. To compute the correponding NPV in option strike currency we discount on the foreign currency
			 *	curve from T_p to T_f, convert in option currency by using simulated forex rate and discount on 
			 *	option currency curve from T_f to current date.
			 *
			 *	@param equityAndForexRiskSources is an output vector containing codes of the equity and forex risk sources in payoff definition. 
			 *		These code must be sorted : first equity codes then forex ones.
			 *	@param equityCount is the number of equity underlying in the corresponding vector.
			 *	In the case of a multi-underlying, all underlyings are equity and equityCount is the same as the equityAndForexRiskSources size.
			 */
			 virtual void GetPayoffUnderlying(	_STL::vector<long>	&equityAndForexRiskSources,
												int					&equityCount) const =0;

			 /**  Give the number of equity and forex underlyings really used to define corresponding payoff.
			 */
			 virtual int GetPayoffUnderlyingCount() const = 0;	

			/** Get the type (quanto, compo...) associated to an underlying.
			*	@param	nth is an index between 0 (included) and result of {@link  CSRClientPayoff::GetPayoffUnderlyingCount} (excluded).
						and diffused underlying are ordered in the same order as the one returned by 
						{@link CSRClientPayoff::GetPayoffUnderlying}.
			*	@return the type of paiement (quanto, compo...) associated to an underlying.
			*	{@see sophis::instrument::eQuantoType}
			*/
			virtual sophis::instrument::eQuantoType GetQuantoCompoRiskSource(int nth) const = 0;
			
			/** Return the number of step in a sampling path (e.g. the number of future dates at which we need spot simulation to compute payoff).
			*/
			virtual int	GetDateCount()	const = 0;
			 
			/** Return the ith fixing date.
			*	@param i is an index between 0 (included) and GetDateCount() (excluded) corresponding to the ith fixing date.
			*	@return the ith fixing dates in sophis convention {@link about_date}.
			*/
			virtual long	GetNthDate(int i) const = 0;

			/** Returns the number of user intermediate payments.
			*/
			virtual int		GetPaymentCount() const = 0;

			/** Return the date corresponding to a user intermediate payment.
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentDate(int nth) const = 0;

			/** Return the date corresponding to the absolute date at which the nth user intermediate payment amount is known.
			*	Default implementation return the payment date
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentFixingDate(int nth) const;

			/** Return the currency of the nth user intermediate payment.
			*	Default implementation return the option currency.
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentCurrency(int nth) const;

			virtual void	GetDiscountFactorDates(/*out*/ _STL::map<long, _STL::set<long> >& dates); // start date -> end dates

			 /** Return the number of antithetic sampling used for pricing :
			 *	1 if no antitheticsampling is used (Default implementation)
			 *  2 for a basic one dimension antitheticsampling 
			 *	and so on.
			 */
			 virtual int GetAntitheticSamplingCount() const;

			 /** Fill a vector with the relevant strike needed to find volatilities at the fixing dates for a given underlying.
			 * @param indexDiffused is the index of the underlying.
			 * @param param is the martket data.
			 * @param option is the computed option.
			 * @param dates is a vector of absolute date.
			 * @param strikeVector is the STL vector of strike to fill.
			 */
			 virtual void GetStrikeForVolatilityArray(	int									indexDiffused, 
														const market_data::CSRMarketData	&param, 
														const sophis::instrument::CSROption *option, 
														const _STL::vector<long>			&dates,
														_STL::vector<double>				&strikeVector) const = 0;

			 /** Return the number of market data dependent information but not dependent on the simulation.
			 */
			 virtual int GetMarketDataDependentInfoCount() const = 0;
			 
			 /** Gives the market data dependent information but not dependent on the simulation.
			 *	@param option is a pointer on the computed option.
			*	@param marketData is the market data.
			*	@param marketDataInfos is the vector of market dependant data to fill.
			 */
			 virtual void GetMarketDataDependentInfo(	const sophis::instrument::CSRInstrument	*instr, 
														const CSROptionMonteCarloMetaModel		*model,
													 	const market_data::CSRMarketData		&marketData, 
													 	_STL::vector<double>					&marketDataInfos) const = 0;

			 /** Create an archive storing all static data needed to initialise a CSRServerPayoff
			 *	@return CSRArchive storing all static data needed to initialise a CSRServerPayoff
			 */
			 const sophis::tools::CSRArchive& CreateStaticServerArchive() const;

			/** Create an archive storing all the market data dependent data needed to initialise a CSRServerPayoff
			 *	@return CSRArchive storing all the market data dependent data needed to initialise a CSRServerPayoff
			 */
			 const sophis::tools::CSRArchive& CreateServerArchive() const;

			 /** This method is called after calling {@link CSRClientPayoff::Initialise}.
			  * It store in vector {@link CSRClientPayoff::fUnderlyingToDiffuse) the code of underlying to 
			  * diffuse by storing first the equity codes then the forex one in the same order as the one
			  * returned by {@link CSRClientPayoff::GetPayoffUnderlying}. 
			  * finally fUnderlyingToDiffuse is set at its corresponding value.
			  */
			 virtual void InitialiseUnderlyingToDiffuse(const instrument::CSRInstrument*	 instr,
														const CSROptionMonteCarloMetaModel*  model);

			  /**	Return the number of equity underlying diffused for the Monte Carlo Computation
			*/
			 inline int GetEquityUnderlyingCount() const {return fEquityUnderlyingCount;};


		public:
			struct  SSMCPaymentCurrency
			{
				long	currency;
				int	fxIndex; // -1 for option currency (useful when
			};

			/** Returns the set of cashFlow currencies  .
			*/
			inline const _STL::vector<CSRServerPayoff::SSMCPaymentCurrency>& GetCashFlowCurrencyData(){ return fCashFlowCurrencyData;};

			/**	This function store only static data needed to initialise a CSRServerPayoff in an archive {@link sophis::tools::CSRArchive}. 
			*	Static data are the one depending only on gApplicationContext and will be shared by all serverpayoff on server side in order to
			*	minimize bandwith occupation.
			*	In any derived class call the mother GetStaticData.
			*	@param archive is the archive in which we store statics data
			* @version  5.3			  
			*/
			 virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			 /** Use of GetData had changed since version 5.3. 
			 *	Now this function only store market data dependent data.  
			*	needed to initialise a CSRServerPayoff in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRServerPayoff for the Monte Carlo computation on the server side.
			*	In any derived class call the mother GetData.
			*	@param archive is the archive in which we store data
			*/
 			 virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			 /** Fill a vector of forward price at fixing dates for a given underlying. 
			 *	@param indexDiffused is the index of the underlying.
			 *	@param param is the market data.
			 *	@param option is a pointer on the computed option.
			 *	@param dates is a vector of absolute dates at which we want future price.
			 *	@param futureVector is the vector to fill.
			 */
			 virtual void GetFuturePrices(	const CSRLocalPathGeneratorClient	*pathGenerator,
											int									indexDiffused,
											const market_data::CSRMarketData	&param,
											const instrument::CSRInstrument		*instr,
											const CSROptionMonteCarloMetaModel*  model,
											const _STL::vector<long>			&dates,
											const SSBumpKey						&bumpKey,
											_STL::vector<double>				&futureVector,
											_STL::vector<double>				&quantoFactor) const;

			  /** Fill a vector of forward volatilities between fixing dates for a given underlying. 
			 *	@param indexDiffused is the index of the underlying.
			 *	@param param is the market data.
			 *	@param option is a pointer on the computed option.
			 *	@param dates is a vector of absolute dates at which we want implied volatility.
			 *	@param volatilityVector is the vector to fill.
			 *  @param bumpKey is a SSBumpKey allowing to know which computation is currently done.
			 */
			virtual void GetVolatilities(	const CSRLocalPathGeneratorClient	*pathGenerator,
											int									indexDiffused,
											const market_data::CSRMarketData	&param, 
											const instrument::CSROption			*option,
											const CSROptionMonteCarloMetaModel	*model,
											const _STL::vector<long>			&dates,
											_STL::vector<double>				&volatilityVector,
											const SSBumpKey						&bumpKey) const;

			/** Fill the correlation matrix for an option in a given context.
			*	@param param is the market data.
			*	@param option is a pointer on the computed option.
			*	@param correlationMatrix is the correlation matrix to fill.
			*	@param maturity is the maturity at which we want to get implied correlation. If we let
					maturity equal to zero we use option exercice date.
			*	@param correlBoundary must be in interval )-1., 1.[. This is a boundaries to apply
					to not diagonal elements in correlation matrix in order to get definite positive matrix.

			* Deprecated since 5.3.0. Such method are now in CSRClientCorrelation
			*/
			virtual void GetCorrelationMatrix(	::boost::numeric::ublas::matrix<double>	&correlationMatrix,
												const market_data::CSRMarketData		*param, 
												const instrument::CSROption				*option,
												const CSROptionMonteCarloMetaModel		*model,
												long									maturity		= 0,
												double									correlBoundary	= 0.999) const;

			/**
			* Returns the registered name of the server payoff containing the valuation procedure.
			*/
			virtual _STL::string GetServerPayoffID() const = 0;

			/**
			* Returns true if it is an American payoff
			*/
			virtual bool IsAmerican() const;

			/**
			* Get the number of dates per block (blockSize) 
			* and the number of base functions per block (baseFuncSize)
			*/
			virtual void GetBlockSizeForRegression(	_STL::vector<int> & blockSize,
													_STL::vector<int> & baseFuncSize) const;

			/**
			* Get the exercise in case of an American Payoff
			* return true if there is an boundary
			* if so, fill the boundary vector
			*/
#ifndef GCC_XML
			virtual bool GetBoundary(_STL::vector<_STL::vector<sophis::math::VectorD> >	const & coeff,
									 _STL::vector<sophis::math::VectorD>				& boundary) const;
#endif // GCC_XML

			/**
			* Set static data from the path generator
			*/
			virtual void SetStaticDataFromPathGenerator(const CSRLocalPathGeneratorClient* pathGenerator) {};

			CSRServerPayoff&  GetServerPayoff() const;

			/** Give the number of indicators computed by CSRServerPayoff during a payoff computation.
			*	During price computation these indicators will be stored in difference from the one
			*	computed during theoretical computation to improve numerical accuracy.
			*	Default implementation return 1 for the discounted price computation.
			*
			*	@return the number of indicators computed during a payoff computation.
			*/
			virtual int	GetIndicatorSizeForDifference() const			{return 1;};

			/** Give the number of supplementary indicators computed by CSRServerPayoff during price computation.
			*	Default implementation return 0.
			*
			*	@return the number of supplementary indicators computed during price computation.
			*/
			virtual int	GetSupplementaryIndicatorSizeForPrice() const	{return 0;};
			
			/** Give the number of supplementary indicators computed by CSRServerPayoff during greeks computation.
			*	Default implementation return 0.
			*
			*	@return the number of supplementary indicators computed during greeks computation.
			*/
			virtual int	GetSupplementaryIndicatorSizeForGreeks() const	{return 0;};


			/** Compute the price of the instrument with the results of the Monte Carlo simulation stored in the buffer resultVector.
				This method is called once before Monte Carlo simulation (with {@link CSROptionMonteCarloMetaModel::GetMonteCarloComputationState} is equal to emccsCreateArchive) 
				in order to initialize some data needed to finalize price computation but not needed on server side. 
				Such result can be stored on archive {@link CSROptionMonteCarloMetaModel::GetPreResultArchive()}.
				
				After Monte Carlo simulation we call again this method (with {@link CSROptionMonteCarloMetaModel::GetMonteCarloComputationState} is equal to emccsAggregateResults)
				to compute price with the simulation results.

				@param	isBasicPrice is true if the current price to compute is the basic one, false if it is computed for greeks.
				@param	resultVector is the result vector for this computation. The first {@link GetIndicatorSizeForDifference}
						index are computed as difference and the other ones (respectively {@link GetSupplementaryIndicatorSizeForPrice} for basic price and 
						{@link GetSupplementaryIndicatorSizeForGreeks} for price for greeks).
				@param	param is the market data we used for the simulation.
				@param	option is the option for which we made the simulation.
				@param	model is the meta-model used to compute price.
				@param	weightedSamplingCount is the number of Monte Carlo Sampling path used for the simulation.
				@param	bumpKey is a SSBumpKey allowing to know which computation is currently done.
			*/
			virtual double	CalculatePrice(	bool								isBasicPrice,
											const _STL::vector<double>			&resultVector,
											const market_data::CSRMarketData	&param, 
											const instrument::CSRInstrument		&instr,
											const CSROptionMonteCarloMetaModel  *model,
											int									samplinCount,
											double								weightedSamplingCount,
											double								squareWeightedSamplingCount,
											const SSBumpKey						&bumpKey) const;

			virtual double	CalculateStandardDeviation( const CSROptionMonteCarloMetaModel  *model,
														const _STL::vector<double>			&vectorForPrice, 
														const _STL::vector<double>			&vectorForSquare, 
														int									samplingCount,
														double								weightedSamplingCount,
														double								squareWeightedSamplingCount) const;


			/** Give today's date at which the computation is asked. 
			*
			*	@return today's date.
			*/
			inline long	GetTodayDate() const {return fToday;};

			/** Get the cash flow diagram for an option.
			@return a new cash flow diagram.
			This is used for the scenario cash flow diagram and for cash balance.
			It is also used to calculate the duration.
			Default implementation returns nothing.
			@param param is a market data.
			@param option is a pointer on the calling option
			@see CSRCashFlowDiagram
			*/
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagram(const market_data::CSRMarketData&	context,
																				const instrument::CSROption*		option) const;

			/** Method called in order to know from the payoff object which feature must be managed by path generator in order
				to compute payoff. For each feature needed by payoff we must call {@link CSRLocalPathGenerator::AddFeatureToManage}.
			  
				@param localPathGenerator is the client side of the generator which will generate underlying paths.
				@param allFixingknow is true if all fixing are already known, false otherwise. The boolean value must be given as parameter to method {@link CSRLocalPathGenerator::AddFeatureToManage}.
				@param option is a pointer on the calling option.
			  
			 */
			virtual void AddFeatureToManage(	CSRLocalPathGeneratorClient& localPathGenerator, 
												bool allFixingknow, 
												const instrument::CSRInstrument* instr) const {};

			/** Internal use. This map is used for optimisation when computing delta and gamma on a Forex.
			*/
			inline const _STL::map<long, _STL::vector<SSBasisComponent> >&	GetbasisComponentMap() const {return fbasisComponentMap;};

			/** Internal use. Give the forex risk sources code vector. When FX delta are computed by forex currency this vector will be empty. 
			*/
			inline  const _STL::vector<long>& GetForexRiskSources() const {return fForexRiskSources;};

			/** Returns the list of Credit Risk sources on which the payoff depends
			Credit risk sources have an impact on the theoretical value of the instrument, for obvious reasons or because of the model.
			For example, the Issuer/Currency/Seniority of a Bond affect it's theoretical value because of the consequences in case of default (recovery rate)
			The "default event" of the Bond is used to decide which default probability curve to use.
			Thus, the 4-uple (Issuer,Currency,Seniority,DefaultEvent) is a credit risk source for the Bond.
			This method has to be overloaded for toolkit payoff with credit risk sources

			@param outCreditRiskSources is the list of credit risk sources to be filled
			*/
			virtual void	GetCreditRiskSources(_STL::set<instrument::SSCreditRiskSource>& outCreditRiskSources) const;

			/** For credit payoff, this method can be overloaded in order to use a uniform correlation.
			By default, returns 1.
			@param	param is a market data
			@return the credit correlation
			@since 6.0
			*/
			virtual double	GetCreditCorrelationUniform(const market_data::CSRMarketData& param) const;

			/** Gives the credit underlyings of the payoff.
			@param	creditUnderlyings is the output, it contains credit underlying codes.
			@since 6.0
			*/
			virtual void	GetCreditUnderlyings(_STL::vector<long>& creditUnderlyings) const;

			virtual _STL::string GetPayoffType() const;

			
			/** Fill options used for variate control. Must be overloaded for each payoff
			@since 6.1
			@return Nothing but modifies fControlInstruments.
			*/ 
			virtual void FillControlInstruments() {return;};
			inline const _STL::vector<CSRControlInstrument*>& GetControlInstruments() const {return fControlInstruments;};

			void ClearControlInstruments();


			virtual const sophis::tools::CSRArchive& CreateGlobalDataArchive() const;

			/**
			*	Method to add information in generic indicator on client side
			*/
			virtual void FinalizeIndicator(CSRGenericIndicatorServer	* genericIndicator, 
											int							samplingCount,
											double						weightedSamplingCount,
											double						squareWeightedSamplingCount,
											long						instrumentCurrency) const;

		protected :
			mutable CSRServerPayoff* fServerPayoff;

			mutable sophis::tools::CSRArchive* fGlobalDataArchive;
			/** ID of the uniform Random generator used for the Monte Carlo simulation.
			*/
			_STL::string fGeneratorID;

			/** CSRArchive storing static Data needed to initialize Server object
			*/
			mutable sophis::tools::CSRArchive* fStaticServerArchive;

			/** CSRArchive storing Data needed to initialize Server object
			*/
			mutable sophis::tools::CSRArchive* fServerArchive;


			/** Today's date. The one of gApplicationContext
			*/
			long	fToday;

			/** Option notional. Initialized from the option
			*/
			double	fNotional;

			/** Computation's date. Initialized from the current CSRMarketData
			*/
			double  fComputationDate;

			/**
			* Greatest zero coupon date needed by the payoff. When using stochastic interest rate, yield curve will only be simulated up to this date.
			*/
			long fYieldCurveUpperBoundary;

			 _STL::vector<long>	fRhoSources;

			 /**  Internal. This is equity risk sources code.
			 */
			 _STL::vector<long> fEquityRiskSources;

			 /** Number of not Forex risk sources .
			 */
			 int fEquityUnderlyingCount;

			 /**  Strike currency of the option.
			 */
			long fOptionStrikeCurrency;

			 /**  Internal. This is foreign currency risk sources code.
			 */
			 _STL::vector<long> fForexRiskSources;
			 // number of foreign currency risk sources
			 int fForexUnderlyingCount;

			/**  Internal. The foreign currency list for which we must discount cashflow.
			*	 First one is option currency
			*/
			_STL::vector<CSRServerPayoff::SSMCPaymentCurrency> fCashFlowCurrencyData;

			/** Internal use. This map is used for optimisation when computing delta and gamma
			*	on a Forex.
			*/
			 _STL::map<long, _STL::vector<SSBasisComponent> >	fbasisComponentMap;

			/**  Internal. This is the theoretical bond value of swapped option.
			*/
			mutable double fBondPart;

			/** If there are instrument in this vector, they will be used as control variates. */
			_STL::vector<CSRControlInstrument*> fControlInstruments;

		  /** True when the settlement type of the option is different from cash, false otherwise.
		   *	@deprecated since 6.0
		  */
			//bool fNotCashDelivery;

			/**  
				It is used to compute the present value of a settlement at time {@link GetNthPaymentDate} from the simulated forward price.
				When there are Np payment dates, the i-th underlying simulated spot value at the j-th payment 
				date is Sj then the(i*Np+j)-th element of the vector contains the NMU coefficient a so that a * Sj + b is the
				present value of the physical settlement at that time.
			*/
			_STL::vector<double> fSpotToPhysica;

			/** 
				 It is used to compute the present value of a settlement at time {@link GetNthPaymentDate} from the simulated forward price.
				When there are Np payment dates, the i-th underlying simulated spot value at the j-th payment 
				date is Sj then the(i*Np+j)-th element of the vector contains the NMU coefficient b so that a * Sj + b is the
				present value of the physical settlement at that time.
			*/
			_STL::vector<double> fSpotToPhysicb;


			/**
			* A boolean to know if the payoff is valid;
			*/
			bool fIsValid;

		};

		
		/** Client side of the class handling correlations to use in Monte carlo simulation.
		 *	
		 *	Default implementation use constant correlation matrix between underlying until option maturity.
		 */
		class SOPHIS_MONTECARLO CSRClientCorrelation
		{
		public:
			CSRClientCorrelation();
			virtual ~CSRClientCorrelation();

			virtual void InitialiseCorrelationData(	const CSRLocalPathGeneratorClient		*pathGenerator,
													const market_data::CSRMarketData		*param,
													const CSROptionMonteCarloMetaModel		*model,
													const instrument::CSRInstrument			&instrument) = 0;


			/** Store all the data needed to initialise a CSRClientCorrelation in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create the CSRClientCorrelation for the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(	sophis::tools::CSRArchive				&archive,
											const CSROptionMonteCarloMetaModel		&model) const {;};

			/** Store all the data needed to initialise a CSRClientCorrelation in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create one or several CSRClientCorrelation for the Monte Carlo loop on the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const = 0;

			virtual int GetNormalLawSize() const = 0;
			virtual bool UseOneMoreTime(bool toSet = false) {return false;};
			/**
			* Returns the registered name of the server payoff containing the valuation procedure.
			*/
			virtual _STL::string GetServerCorrelationID() const = 0;

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const {;};
		public:
			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRClientCorrelation* Clone() const = 0;

			typedef	sophis::tools::CSRPrototype<CSRClientCorrelation, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};


		/** Client side of the class handling uniform random generation on client side.
		*/
		class SOPHIS_MONTECARLO CSRUniformRandomGeneratorClient
		{
		public:
			/** Default constructor.
			 */
			CSRUniformRandomGeneratorClient();

			/** Destructor.
			*/
			virtual ~CSRUniformRandomGeneratorClient();

			virtual void	InitialiseFromModel(const CSROptionMonteCarloMetaModel		&model) {;};

			/** Store all the data needed to initialise a CSRUniformRandomGenerator in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create the CSRUniformRandomGenerator for the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(	sophis::tools::CSRArchive				&archive,
											const CSROptionMonteCarloMetaModel		&model) const {;};

			/**
			* Returns the registered name of the server CSRUniformRandomGenerator.
			*/
			virtual _STL::string GetServerUniformRandomGeneratorID() const = 0;

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const {;};

			/** Give the maximum number of independent dimensions that the generator can simultaneouslly generate. 
			*	Default create the server side generator and ask for corresponding maximal dimension.
			*
			*	@return the maximum number of independent dimensions. 
			*/
			virtual int	GetMaximalDimensionAllowed()const;

		public:
			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRUniformRandomGeneratorClient* Clone() const = 0;

			typedef	sophis::tools::CSRPrototype<CSRUniformRandomGeneratorClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};

		/** Client side of the class handling transformation of uniform law to gaussian law.
		*/
		class SOPHIS_MONTECARLO CSRGaussianInvertionClient
		{
		public:
			/** Default constructor.
			*/
			CSRGaussianInvertionClient();

			/** Destructor.
			*/
			virtual ~CSRGaussianInvertionClient();

			/** Store all the data needed to initialise a CSRGaussianInvertion in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create the CSRGaussianInvertion for the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(	sophis::tools::CSRArchive				&archive,
				const CSROptionMonteCarloMetaModel		&model) const {;};

			/**
			* Returns the registered name of the server CSRGaussianInvertion.
			*/
			virtual _STL::string GetServerGaussianInvertionID() const = 0;

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const {;};

		public:
			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRGaussianInvertionClient* Clone() const = 0;

			typedef	sophis::tools::CSRPrototype<CSRGaussianInvertionClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};

		/** Client side of the class handling transformation of gaussian law so that they are directly used to
			generate Brownian increments.
		*/
		class SOPHIS_MONTECARLO CSRBrownianPathConstructionClient
		{
		public:
			/** Default constructor.
			*/
			CSRBrownianPathConstructionClient();

			/** Destructor.
			*/
			virtual ~CSRBrownianPathConstructionClient();

			/** Store all the data needed to initialise a CSRBrownianPathConstruction in an archive {@link sophis::tools::CSRArchive}. 
			*	This is done in order to create the CSRBrownianPathConstruction for the server side.
			*	@param archive is the archive in which we store data
			*/
			virtual void	GetStaticData(	sophis::tools::CSRArchive				&archive,
				const CSROptionMonteCarloMetaModel		&model) const {;};

			/**
			* Returns the registered name of the server CSRBrownianPathConstruction.
			*/
			virtual _STL::string GetServerBrownianPathConstructionID() const = 0;

			/** Create the list of tab elements for path generator data. Default implementation does nothing.
			*	@param tabDialogs is the list into which specific tabs must be inserted. For toolkit relative IDs of 
			*	elements must start at 1000 and must be different for every tab dialog.
			*/
			virtual void GetTabDialogs(_STL::vector<gui::CSRMetaModelTabButton::SSTabElementMM> &tabDialogs) const {;};

		public:
			/** Clone for this object. Used for prototypal construction of the object.
			*/
			virtual CSRBrownianPathConstructionClient* Clone() const = 0;

			typedef	sophis::tools::CSRPrototype<CSRBrownianPathConstructionClient, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();
		};

	}	//namespace finance

}//		 namespace sophis

SPH_EPILOG
#endif 
