/*
File:		SphNotionnelFuture.h

Contains:	Class for the handling of a notionnel future

Copyright:	� 1995-2002 Sophis.

*/
#ifdef WIN32
#pragma once
#endif


#ifndef __SPH_NOTIONNEL_FUTURE_H
#define __SPH_NOTIONNEL_FUTURE_H

#include "SphInc/instrument/SphFuture.h"
#include "SphInc/gui/SphInstrumentDialog.h"
#include "SphTools/SphCommon.h"
#include "SphInc/static_data/SphMarket.h"
#include "SphInc/static_data/SphDayCountBasis.h"
#include "SphInc/static_data/SphYieldCalculation.h"
#include "SphInc/market_data/SphMarketData.h"
#include __STL_INCLUDE_PATH(map)

#include "SphInc/instrument/SphInstrument.h"



SPH_PROLOG
namespace sophis	{
	namespace finance	{

		/*
		** Class CSRNotionalFuture
		* @since 5.2.3
		*/
		class SOPHIS_FINANCE CSRNotionalFuture : public virtual instrument::CSRFuture
		{
		public:
			DECLARATION_FUTURE(CSRNotionalFuture)

			~CSRNotionalFuture();

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

			/**
			@return the payment date of the notional future in absolute or relative to the expiry.
			@see CSREditDate::RelativedateInAbsolute
			@since 5.2.3
			*/
			virtual long GetPaymentDate() const;

			virtual double			GetYTMByDirtyPrice(	long 	transactionDate,
														long 	settlementDate,
														long	pariPassuDate,
														double 	dirtyPrice,
														double	startPoint = NOTDEFINED) const OVERRIDE;

			static const char * MODEL_NAME;

			/**
			@return the YTM used for the concordance factor computation
			@see fNotionalRate
			@since 5.2.3
			*/
			double GetNotionalRate() const;

			/**
			@param value is the YTM we want to use for the concordance factor computation
			@return true if the notional rate has been modified
			@see fNotionalRate
			@since 5.2.3
			*/
			virtual bool SetNotionalRate(const double value);

			/**
			@return the absolute date for computing the concordance factor, or an relative date to add to the maturity of the future.
			@see fConcondanceDate
			@see GetConcordanceFactor
			@see CSREditDate::RelativedateInAbsolute
			@since 5.2.3
			*/
			long GetConcordanceDate() const;

			/**
			@param date is the absolute date for computing the concordance factor, or an relative date to add to the maturity of the future.
			@return true if the concordance date has been modified
			@see GetConcordanceFactor
			@see GetExpiryInProduct
			@see CSREditDate::RelativedateInAbsolute
			@since 5.2.3
			*/
			virtual bool SetConcordanceDate(long date);

			/**
			@return the CSRMarket to consider for the YTM rules for the concordance factor computation. If NULL, it uses default values from the bond.
			@see fMarket
			@see SetCSRMarketCodeForYTM
			@since 5.2.3
			*/
			const sophis::static_data::CSRMarket * GetCSRMarketForYTM() const;

			/**
			@return the market code to consider for the YTM rules for the concordance factor computation. If there is no specific market returns 0.
			@see fMarket
			@see GetCSRMarketForYTM
			@see SetMarketCodeForYTM
			@since 5.2.3
			*/
			long GetMarketCodeForYTM() const;

			/**
			@param market is the specific market to consider for the YTM rules for the concordance factor computation. It can be NULL if one wants to use default bond markets.
			@see fMarket
			@see GetCSRMarketCodeForYTM
			@since 5.2.3
			*/
			void SetCSRMarketForYTM(const sophis::static_data::CSRMarket *market);

			/**
			@param code is the specific market code to consider for the YTM rules for the concordance factor computation. It can be 0 if one wants to use default bond markets.
			@see fMarket
			@see GetMarketCodeForYTM
			@since 5.2.3
			*/
			void SetMarketCodeForYTM(long code);

			/** Add a bond code to the underlying basket
			@param code the bond to add sicovam code. 
			@param data an empty or a computed SSCalcul structure. If the bond is already in the list, its data will be overwriten.
			@return true if the operation succeeded, false if not.
			@see fBondList
			@see SSCalcul
			@see GetConcordanceFactor
			@since 5.2.3
			*/
			bool AddBondToList(long code, sophis::instrument::SSCalcul data);

			/** Add a bond code to the underlying basket
			@param code the bond to add sicovam code.
			@see fBondList
			@since 5.2.3
			*/
			void AddBondToList(long code);

			/** Get the data of a bond in the list.
			@param code the bond sicovam code.
			@param data the data to be filled with the bond one.
			@see fBondList
			@since 5.2.3
			*/
			void GetBondFromList(long code, sophis::instrument::SSCalcul &data) const;

			/** Delete a a bond in the list.
			@param code the bond sicovam code.
			@see fBondList
			@since 5.2.3
			*/
			void DeleteBondFromList(long code);

			/** Clear all the bond list.
			@see fBondList
			@since 5.2.3
			*/
			void ClearList();

			/**
			@return the number of bonds in the basket
			@see fBondList
			@since 5.2.3
			*/
			int GetBondNumber();

			/** This method give you the possibility to get a copy of the bond list with their corresponding data.
			@param bondList is the map to fill
			@see fBondList
			@since 5.2.3
			*/
			void GetBondList(_STL::map<long, sophis::instrument::SSCalcul> &bondList) const;

			/** Method to test if a bond is in the list.
			@param code is the sicovam code to test
			@return true if the corresponding instrument is in the bond basket.
			@see fBondList
			@since 5.2.3
			*/
			bool Belongs(long code);

			/** Rebuild fBondList with the user information
			@see fBondList
			@since 5.2.3
			*/
			void ResetBondList();

			/** This method is not implemented
			@param dataSet is an object that contains data which this instrument can be built by. A DataSet can be built from an XML file for instance.
			@param code is usually the underlying code.
			@since 5.2.3
			*/
			virtual void DescribeUnderlyer(sophis::tools::dataModel::DataSet& dataSet, long code) const;


			/** Get the yield to maturity sensibility.
				@param ytm is a yield to maturity (.07 for 7%) where the sensibility is wanted.
				@param context is a market data.
				@return the fair value variation expressed in the currency of the instrument
				for a variation of 1% of the yield to maturity.
				It is called by RecomputeAll.
				By default, the algorithm is:
				- Ask {@link GetDerivationParameters} with gpRho to get the desired bump.
				- Calculates the finite difference calling {@link GetDirtyPriceByYTM}.
				- Expresses the result for 1% variation.
				@since 6.1
			*/
			virtual double			GetYTMSensitivity(double ytm, const market_data::CSRMarketData& context) const;

			/** This method returns the cheapest to deliver once the bond list has been computed. For instance after a GetTheoreticalValue.
			@return the sicovam code of cheapest to deliver from fBondList.
			@see fBondList
			@see GetCheapest
			@since 5.2.3
			*/
			long GetCheapest() const;

			/**
			@param bondList the bond list where the data SSCalcul must heve been computed
			@return the sicovam code of cheapest to deliver from bondList.
			@see GetConcordanceFactor
			@see SSCalcul
			@since 5.2.3
			*/
			virtual long GetCheapest(const _STL::map<long, sophis::instrument::SSCalcul> &bondList) const;

			/** This method compute the data (SSCalcul) of a given bond and especially the concordance factor.
			@param context is the market data.
			@param code is the bond sicovam code.
			@param data is the data to compute.
			@param absoluteDate is the concordance factor date for computation.
			@param negociationDate is the computation date.
			@param valueDate is the payment date of the future if there is one else it is the expiry.
			@param dayCountBasis is the day count basis object for the YTM. If NULL it will be set to the one define in the bond.
			@param yieldCalMode is the yield calculation mode object for the YTM. If NULL it will be set to the one define in the bond.
			@param computationOnAdjustedDates is to say if YTM is computed on adjusted date. If kUseDefaultValue it will be set to the one define in the bond.
			@param computationOnValueDates is to say if YTM is computed on settlement date. If kUseDefaultValue it will be set to the one define in the bond.
			@param roundingType is the rounding rule according to market
			@see CSRBond::InitDefaultValue
			@since 5.2.3
			@version 5.3.3: added the parameter "roundingType"
			*/
			virtual void GetConcordanceFactor(	const sophis::market_data::CSRMarketData &context, long code, sophis::instrument::SSCalcul &data,
												long absoluteDate,
												long negociationDate,
												long valueDate,
												const sophis::static_data::CSRDayCountBasis	*dayCountBasis /*= 0*/,
												const sophis::static_data::CSRYieldCalculation	*yieldCalMode /*= 0*/,
												short computationOnAdjustedDates /*= kUseDefaultValue*/,
												short computationOnValueDates	 /*= kUseDefaultValue*/,
												sophis::static_data::eNotionalFutureRoundingType roundingType /*= sophis::static_data::nfrNoRounding*/) const;

			/** This method compute the data (SSCalcul) of a given bond and especially the concordance factor using the market and the future definition.
			@param context is the market data.
			@param code is the bond sicovam code
			@param data is the data to compute.
			@see GetConcordanceFactor
			@see fMarket for all YTM computation rules.
			@see GetPaymentDate
			@since 5.2.3
			*/
			void GetConcordanceFactor(	const sophis::market_data::CSRMarketData &context, long code, sophis::instrument::SSCalcul &data) const;


			/** This method fill SSCalcul of a list by calling {@link GetConcordanceFactor}
			@param context is the market data.
			@param bondList the bond list where the data SSCalcul must have been computed
			@see GetConcordanceFactor
			@see SSCalcul
			@since 7.3.1.3
			*/
			void FillConcordanceFactor(const sophis::market_data::CSRMarketData &context, _STL::map<long, sophis::instrument::SSCalcul> &bondList) const;


			/** Automatic ticket to create.
			During the forecast, this method is called before doing the
			standard Sophis automatic ticket.
			According the return, the automatic tickets will be inserted into prevision
			table (used for cash in the future) when the date is in the future else
			in automatic ticket.
			This works also for instruments in package. If your forecast needs some
			information from the position like the average price, you must use the
			special automatic ticket {@link GetAutomaticTicketByReporting}.
			@param date is the forecast date.
			@param list is the automatic ticket list.
			@since 5.2.7
			*/
			virtual eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<AutomaticTicket> &list) const;

			/** This method return the date after which the notional future is not anymore sensible to the yield curve.
			@return the maximum of the expiry for rho of the bond list.
			@see CSRBond::GetExpiryForRho
			@since 5.2.3
			*/
			virtual long	GetExpiryForRho() const;

			/** Name of the root in the xml description.
			@return "notionalFuture"
			@since 5.2.3
			*/
			virtual const char * GetXMLRootName() const;

			virtual bool	UseSpecialUSFormatForPrice() const;
			virtual short	GetSpecialUSFormatForPrice() const;


			/** INTERNAL.
			@version 5.3
			*/
			virtual void			GetTransparencyBreakDown(_STL::vector<SSTransparencyBreakDown> &components,
				sophis::portfolio::PSRExtraction extraction,
				const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
				const sophis::portfolio::eLookthroughType fSplitByComponents,
				double* evalInstrument,
				double* evalLookthroughDeals) const;

			virtual bool HasTransparencyBreakDown(sophis::portfolio::PSRExtraction extraction) const;

			/** This method returns the Mnemo of the Listed Market Contract Class
			@returns 0 if not defined.
			@see GetListedMarketId in SphFuture.h
			@since 5.3.5
			*/
			long GetListedMarketClass() const;

			/** This method sets the Listed Market Contract Class
			@param mnemo is the Mnemo code of the Contract class in the Listed Market.
			@see SetListedMarketId in SphFuture.h
			@since 5.3.5
			*/
			void SetListedMarketClass(long mnmemo);

			/** Retrieve a description from an instrument.
			* @param dataSet is the description to be filled with this instrument.
			* @throw GeneralException this instrument is invalid : the description cannot be built from it.
			* It is called by the data service in view of updating the instrument using a XML provided by an external source. 
			* @since 5.3.6 to describe the listed market class
			*/
			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			/// Initialize this instrument from a description
			/** Overriden from {@link CSRInstrument::UpdateFromDescription}
			*/
			void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			/** Return flags indicating if the model associated to this class is meaningful for the IR Futures dialog
			  * For flags : see AVAIL_FOR_GUI... defines
			@since 6.1
			*/
			virtual short ModelAvailabilityForIRFutureDialog() const;

			/** Returns the list of Credit Risk sources on which the instrument depends
			 *  Credit risk sources have an impact on the theoritical value of the instrument, for obvious reasons or because of the model.
			 *  For example, the Issuer/Currency/Seniority of a Bond affect it's theoritical value because of the consequences in case of default (recovery rate)
			 *  The "default event" of the Bond is used to decide which default probability curve to use.
			 *  Thus, the 4-uple (Issuer,Currency,Seniority,DefaultEvent) is a credit risk source for the Bond.
			 *  This method has to be overloaded for toolkit instruments with credit risk sources
			 *	@param outCreditRiskSources is the list of credit risk sources to be filled
			 *	@deprecated 5.2.2 to get the credit risk sources use GetUniversalCreditRiskSources instead. because it may
			 *	have several time the same credit source comming from different underlyings.
			 */
			//virtual void GetCreditRiskSources(_STL::set<sophis::instrument::SSCreditRiskSource> &outCreditRiskSources) const;

			/** Creates the credit risk sensitivity context.
			It is called by {@link finance::CSRMetaModel::new_CreditRiskSensitivityComputationContext} to get
			the credit risk sensitivity by finite difference.

			@param context
			is the original context to decorate to get the credit risk sensitivity context.

			@param isPositiveBump
			to indicate is the bump is positive or negative.

			@return
			the new credit risk sensitivity context.

			*/
			virtual sophis::market_data::CSRMarketData*	new_CreditRiskSensitivityComputationContext(const sophis::market_data::CSRMarketData& context, bool isPositiveBump) const;

						/** Creates the recovery rate sensitivity context.
			It is called by {@link finance::CSRMetaModel::new_RecoveryRateSensitivityComputationContext} to get
			the recovery rate sensitivity by finite difference.

			@param context
			is the original context to decorate to get the recovery rate sensitivity context.

			@return
			the new recovery rate sensitivity context.
			*/
			virtual sophis::market_data::CSRMarketData*	new_RecoveryRateSensitivityComputationContext(const sophis::market_data::CSRMarketData& context) const;

			virtual long				GetUnderlyingCode() 	const;
			virtual void				EnumerateUnderlyingCodes(_STL::vector<long>& underlyings) const;

		protected:

			/** computes the maturity of the future to be used during computation of the Concordance factor
			*	@param futureMaturity the maturity of the notional future as an absolute date
			*	@param bondMaturity the expiry date of the underlying bond
			*	@param roundingType the rounding rule to be used
			*	@return the rounded maturity of the future as an absolute date
			*	@see CSRMarket::GetNotionalFutureRoundingType()
			*	@since 5.3.3
			*/
			long	GetFutureMaturityForConcordanceFactor(long futureMaturity, long bondMaturity, sophis::static_data::eNotionalFutureRoundingType roundingType) const;


			/** This is the bond list with its associated computation data
			@see AddBondToList
			@see AddBondToList
			@see GetBondFromList
			@see DeleteBondFromList
			@see GetBondNumber
			@see GetBondList
			@see Belongs
			@see ResetBondList
			@since 5.2.3
			*/
			mutable _STL::map<long, sophis::instrument::SSCalcul> fBondList;

			/** The YTM storage element for the YTM used for the concodance factor computation
			@see SetNotionalRate
			@see GetNotionalRate
			@since 5.2.3
			*/
			double fNotionalRate;

			/** The date storage element for the YTM used for the concodance factor computation
			@see SetConcordanceDate
			@see GetConcordanceDate
			@since 5.2.3
			*/
			long fConcordanceDate;

			/** The specific market for the concordance factor computation.
			@see GetCSRMarketForYTM
			@see GetMarketCodeForYTM
			@see GetMarketCodeForYTM
			@see SetCSRMarketForYTM
			@since 5.2.3
			*/
			const sophis::static_data::CSRMarket *fMarket;

		private:
			/** For log purpose
			@since 5.2.3
			*/
			static const char* __CLASS__;
		};
		class SOPHIS_FINANCE CSRNotionalFutureDialog : public sophis::gui::CSRInstrumentDialog
		{
		public:

			DECLARATION_INSTRUMENT_DIALOG(CSRNotionalFutureDialog)

				/**Validates an element in the context.
				When selection moves from one element of the dialog to another one, the method CSRElement::Validation()
				of the current element is called and (if the call ends succesfully) so is CSRFitDialog::ElementValidation().
				You override the method in order to :
				- check the coherence of the current setting
				- take an appropriate action with respect to the current context.
				@param EAId_Modified is the absolute ID of the modified element
				@since 4.5.2
				*/
				virtual	void	ElementValidation(int EAId_Modified);

			/** Method called after recalculations.
			This method is called automatically after the recalculations have taken place.
			It allows you to carry out supplementary calculations and to display the relevant results as, for instance,
			barrier sensibilities.
			You can override this in order to meet requirements with respect to the CSRInstrument security.
			@param security is a reference to a CSRInstrument-derived object that is the security in question.
			@since 4.5.2
			*/
			virtual void AfterRecompute(const instrument::CSRInstrument &security, const sophis::CSRComputationResults& results);

			/**Called automatically before launching a dialog.
			CSRFitDialog::Open() calls CSRElement::Open() for all the dialog's elements.
			If you want to initialise your dialog globally, you must overload this virtual method.
			@since 4.5.2
			*/
			virtual void	Open(void);

			enum eDialogElement {
				edmOk = 1,
				edmCancel,
				edmBondList,
				edmMarketCode,
				edmConcordanceDate,	// 5
				edmNotionalRate,
				edmNotional,
				edmDateButton,
				edmElementsNumber=edmDateButton,
				edmTheoretical  = 11,
				edmConcordanceFactorFrame=11
			} ;

			enum eBondListElement
			{
				clgRef =0,
				clgName,
				clgMaturity,
				clgLast,
				clgBondPrice,
				clgNotionalFutureValue,
				clgConcordanceFactor,
				clgElementNumber
			} ;

		protected :
			CSRNotionalFuture * fNotionalFuture;

			char fName[41];

		private:

			/** For log purpose
			@since 5.2.3
			*/
			static const char* __CLASS__;
		};
	}
}
SPH_EPILOG

#endif //!__SPH_NOTIONNEL_FUTURE_H
