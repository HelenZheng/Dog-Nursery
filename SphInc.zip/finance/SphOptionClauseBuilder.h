#ifndef _SphOptionClauseBuilder_H_
#define _SphOptionClauseBuilder_H_

#include "SphInc/SphMacros.h"
#include "SphInc/instrument/SphOption.h"
#include "SphInc/finance/SphNewMonteCarlo.h"
#include "SphInc/finance/SphMCClauseBase.h"
//#include "SphLLInc/newmontecarlo/SphLowLevelMonteCarloServer.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

#define OPTION_NMC_CLAUSE_NAME "Clause Builder"
#define OPTION_FLOW_EXOTICS_NAME "Flow Exotics"

SPH_PROLOG

namespace sophis
{
	namespace finance
	{
		class SOPHIS_MONTECARLO CSRClausePayoffClient : public virtual CSRClientPayoff
		{
		public:
		
			CSRClausePayoffClient();

			/**	Destructor
			*/
			virtual ~CSRClausePayoffClient();

			/**	Initialise the payoff for a given option. You should call it in any derived class to 
			*	initialize properly fGeneratorID. 
			*
			*	@param	option is the option for which this object handle actualized payoff computation
			*/
			virtual void Initialise(const instrument::CSRInstrument* instr);

		

			/**	At the beginning of a pricing this method is called in order to set all static data
			*	which depend only on gApplicationContext such as todays date. 
			*	This function must find all dates needed in the simulation, and populates a structure so that method 
			*	{@link CSRClientPayoff::GetNthDate} return the nth dates needed for payoff evaluation in sophis convention.
			*	
			*	@param option is the option priced by Monte Carlo simulation.
			*	@param contextGeneral is the basic context used by Monte Carlo simulation to compute basic price.
			*/
			virtual void InitialiseStaticData(	const instrument::CSRInstrument*	instr,
												const market_data::CSRMarketData	&contextGeneral);


			/** Get foreign currency risk sources.
			*	@param foreignSources is an output vector containing codes of foreign currencies.
			*/
			virtual void GetForeignCurrencyRiskSources(_STL::vector<long>& foreignSources) const;

		

			/** Get equity and forex underlyings really used to define corresponding payoff.
			*
			*	When computing an option value in strike option currency we need to convert payment in other currencies
			*	when the are paid. If the amount F(T_f,T_p) is known at fixing date T_f and is paid at settlement 
			*	date T_p. To compute the correponding NPV in option strike currency we discount on the foreign currency
			*	curve from T_p to T_f, convert in option currency by using simulated forex rate and discount on 
			*	option currency curve from T_f to current date.
			*
			*	@param equityAndForexRiskSources is an output vector containing codes of the equity and forex risk sources in payoff definition. 
			*		These code must be sorted : first equity codes then forex ones.
			*	@param equityCount is the number of equity underlying in the corresponding vector.
			*	In the case of a multi-underlying, all underlyings are equity and equityCount is the same as the equityAndForexRiskSources size.
			*/
			virtual void GetPayoffUnderlying(	_STL::vector<long>	&equityAndForexRiskSources,
												int					&equityCount) const;

			/**  Give the number of equity and forex underlyings really used to define corresponding payoff.
			*/
			virtual int GetPayoffUnderlyingCount() const ;	

			/** Get the type (quanto, compo...) associated to an underlying.
			*	@param	nth is an index between 0 (included) and result of {@link  CSRClientPayoff::GetPayoffUnderlyingCount} (excluded).
			and diffused underlying are ordered in the same order as the one returned by 
			{@link CSRClientPayoff::GetPayoffUnderlying}.
			*	@return the type of paiement (quanto, compo...) associated to an underlying.
			*	{@see sophis::instrument::eQuantoType}
			*/
			virtual sophis::instrument::eQuantoType GetQuantoCompoRiskSource(int nth) const ;

			/** Return the number of step in a sampling path (e.g. the number of future dates at which we need spot simulation to compute payoff).
			*/
			virtual int	GetDateCount()	const ;

			/** Return the ith fixing date.
			*	@param i is an index between 0 (included) and GetDateCount() (excluded) corresponding to the ith fixing date.
			*	@return the ith fixing dates in sophis convention {@link about_date}.
			*/
			virtual long	GetNthDate(int i) const ;

			/** Returns the number of user intermediate payments.
			*/
			virtual int		GetPaymentCount() const ;

			/** Return the date corresponding to a user intermediate payment.
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentDate(int nth) const ;

			/** Return the date corresponding to the absolute date at which the nth user intermediate payment amount is known.
			*	Default implementation return the payment date
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentFixingDate(int nth) const;

			/** Return the currency of the nth user intermediate payment.
			*	Default implementation return the option currency.
			*	@param nth is the index of the nth intermediate payments.
			*/
			virtual long	GetNthPaymentCurrency(int nth) const;

			/** Return the number of antithetic sampling used for pricing :
			*	0 if no antitheticsampling is used (Default implementation)
			*  1 for a basic one dimension antitheticsampling 
			*	and so on.
			*/
			virtual int GetAntitheticSamplingCount() const;

			/** Fill a vector with the relevant strike needed to find volatilities at the fixing dates for a given underlying.
			* @param indexDiffused is the index of the underlying.
			* @param param is the martket data.
			* @param option is the computed option.
			* @param dates is a vector of absolute date.
			* @param strikeVector is the STL vector of strike to fill.
			*/
			virtual void GetStrikeForVolatilityArray(	int									indexDiffused, 
														const market_data::CSRMarketData	&param, 
														const sophis::instrument::CSROption *option, 
														const _STL::vector<long>			&dates,
														_STL::vector<double>				&strikeVector) const ;

			/** Return the number of market data dependent information but not dependent on the simulation.
			*/
			virtual int GetMarketDataDependentInfoCount() const ;

			/** Gives the market data dependent information but not dependent on the simulation.
			*	@param option is a pointer on the computed option.
			*	@param marketData is the market data.
			*	@param marketDataInfos is the vector of market dependant data to fill.
			*/
			virtual void GetMarketDataDependentInfo(	const sophis::instrument::CSRInstrument	*instr, 
														const CSROptionMonteCarloMetaModel		*model,
														const market_data::CSRMarketData		&marketData, 
														_STL::vector<double>					&marketDataInfos) const ;

			/**			  
			*/
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** 
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/**
			*/
			virtual int	GetIndicatorSizeForDifference() const;

			/** 
			*/
			virtual int	GetSupplementaryIndicatorSizeForPrice() const;	

			/** 
			*/
			virtual int	GetSupplementaryIndicatorSizeForGreeks() const;


			virtual	Boolean			ValidInstrument(bool isInInitialisation = true) const	;

			_STL::vector<int>		GetUnderlyingIndexMapping() const {return fIndexForPayoffFromIndexInGUI;};

			
			_STL::string			GetErrorMessage() const			{return fErrMessage;};

		
			double					GetItersDone()		const {return fItersDone;};

									/** Automatic ticket to create.
			*/
			virtual instrument::CSRInstrument::eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<instrument::CSRInstrument::AutomaticTicket> &list) const;

			/** Automatic ticket to create by reporting.
			*/
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

			/** Called by each position when a special automatic ticket.
			*/
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const instrument::CSRInstrument::portfolio_automatic_ticket &port) const;


			/** Call back of the special extraction created for automatic ticket.
			*/
			virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;

		

			virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const{if(nb)*nb=0;return NULL;};


			void SetUnderlyingCountInGUI(int underlyingCountInGUI) {fUnderlyingCountInGUI = underlyingCountInGUI;};


		protected:

			long fStrikeCurrency;


			/** List of ordered dates for the MonteCarlo path.
			*/
			_STL::vector<long> fDates;
			bool fDatesInit;

			// List of fixings.
			sophis::finance::FixingsList	fObsDateFixing;

			int		fLastIndexInThePast;

			_STL::vector<long>	fPaymentDateVector;

			sophis::instrument::CSROption * fOption;

			int		fPayoffUnderlyingCount;

			bool	fIsValid;

			/** List of underlying underlying codes
			*/
			_STL::vector<int>	fIndexForPayoffFromIndexInGUI;

			/** List of underlying quanto/compo type
			*/
			_STL::vector<sophis::finance::SSMultiUnderlying>	fUnderlyingDiffusionType;

			int		fEquityPayoffUnderlyingCount;

			mutable double  fItersDone;

			mutable _STL::string	fErrMessage;

			int fUnderlyingCountInGUI;

		};

		class SOPHIS_MONTECARLO CSRClauseBuilderPayoffClient : public virtual CSRClausePayoffClient
		{
		public:
		
			CSRClauseBuilderPayoffClient();

			/**	Destructor
			*/
			virtual ~CSRClauseBuilderPayoffClient();

			virtual void Initialise(const instrument::CSRInstrument* instr);

			virtual void	InitDates(const market_data::CSRMarketData	&contextGeneral);

			virtual void GetFixingDates(_STL::set<long>& fixingDates) const;

			virtual	Boolean			ValidInstrument(bool isInInitialisation = true) const	;


			CSRClauseBuilderPayoffServer&  GetClauseBuilderServerPayoff() const;


			void FillBarrierToMonitor(_STL::vector<CSRClauseBuilderClause::SSOneMultiUnderlyingBarrier> & barriers ) const;


				/** 
			*	 Populates the array by collecting the characteristic dates of each clause. 
			*	@param param is the market data.
			*/
			virtual void	 InitialiseMarketDependentData(const market_data::CSRMarketData	&param,
															const CSROptionMonteCarloMetaModel	*model,
															const instrument::CSRInstrument		&instrument);


			CSRMCRateLeg*			GetRateLeg();
			bool					GetRateLegStatus() const		{return fRateLegReferenced;};
			void					SetRateLegStatus(bool status)	{fRateLegReferenced = status;};


			/**	At the beginning of a pricing this method is called in order to set all static data
			*	which depend only on gApplicationContext such as todays date. 
			*	This function must find all dates needed in the simulation, and populates a structure so that method 
			*	{@link CSRClientPayoff::GetNthDate} return the nth dates needed for payoff evaluation in sophis convention.
			*	
			*	@param option is the option priced by Monte Carlo simulation.
			*	@param contextGeneral is the basic context used by Monte Carlo simulation to compute basic price.
			*/
			virtual void InitialiseStaticData(	const instrument::CSRInstrument* instr,
												const market_data::CSRMarketData	&contextGeneral);

			void					NeedGapRiskError();

			double					GetGapRiskError()	const {return fGapRiskError;};

			/**			  
			*/
			virtual void	GetStaticData(sophis::tools::CSRArchive& archive) const;

			/** 
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/**
			* Returns the registered name of the server payoff containing the valuation procedure.
			*/
			virtual _STL::string GetServerPayoffID() const;

			/** 
			*/
			virtual double	CalculatePrice(	bool								isBasicPrice,
											const _STL::vector<double>			&resultVector,
											const market_data::CSRMarketData	&param, 
											const instrument::CSRInstrument		&instr,
											const CSROptionMonteCarloMetaModel  *model,
											int									samplingCount,
											double								weightedSamplingCount,
											double								squareWeightedSamplingCount,
											const SSBumpKey						&bumpKey) const;


				/** Probably needed to have new features
			*/
 			virtual void AddFeatureToManage(	CSRLocalPathGeneratorClient& localPathGenerator, 
 												bool allFixingknow, 
 												const instrument::CSRInstrument* instr) const;


						/** Automatic ticket to create.
			*/
			virtual instrument::CSRInstrument::eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<instrument::CSRInstrument::AutomaticTicket> &list) const;

			/** Automatic ticket to create by reporting.
			*/
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

			/** Called by each position when a special automatic ticket.
			*/
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const instrument::CSRInstrument::portfolio_automatic_ticket &port) const;


			/** Call back of the special extraction created for automatic ticket.
			*/
			virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;

		
			/** Get the cash flow diagram for an option.
			*/
			virtual	sophis::instrument::CSRCashFlowDiagram* new_CashFlowDiagram(const market_data::CSRMarketData&	context,
																				const instrument::CSROption*		option) const;

			//struct SSPaymentCashFlows 
			//{	

			//	SSPaymentCashFlows()
			//	{
			//		paymentDate = 0;
			//		clauseAmount = rateLegAmount = 0.;
			//	}

			//	~SSPaymentCashFlows()
			//	{

			//	}

			//	long		paymentDate;
			//	double		clauseAmount;
			//	double		rateLegAmount;

			//	_STL::vector<SSPhysicalExchange> fPhysicalExchange;
			//};

			//const _STL::vector<SSPaymentCashFlows>&	GetPaymentCashFlows() const {return fPaymentCashFlows;};
			void									FillPaymentCashFlows(const market_data::CSRMarketData	&context);

			virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const;

			virtual bool InitialisePathGeneratorForInstrumentManagement(const sophis::instrument::CSRInstrument* instr,
																const market_data::CSRMarketData	&context, 
																CSRLocalPathGeneratorServer			*&pathGeneratorToCreate) const OVERRIDE;



			void ApplyBarrierShift(); 

			bool MustApplyBarrierShift() const;

			virtual void FinalizeIndicator(CSRGenericIndicatorServer	* genericIndicator,
											int							samplingCount,
											double						weightedSamplingCount,
											double						squareWeightedSamplingCount,
											long						instrumentCurrency) const;

			virtual void FinalizeCashFlowInDump();

			virtual double	CalculateStandardDeviation( const CSROptionMonteCarloMetaModel  *model,
														const _STL::vector<double>			&vectorForPrice, 
														const _STL::vector<double>			&vectorForSquare,
														int									samplingCount,
														double								weightedSamplingCount,
														double								squareWeightedSamplingCount) const;

		protected:
			// rate leg data
			CSRMCRateLeg*	fRateLeg;

			/** To check if we need to compute rate leg value on server side
			*/
			bool    fRateLegReferenced;
			/** To check if we need to compute gap risk error
			*/
			bool    fNeedGapRiskError;

			/*Datas for the GUI*/
			mutable double  fGapRiskError;

			//_STL::vector<SSPaymentCashFlows>	fPaymentCashFlows;

			bool fApplyBarrierShift;

		};

		class SOPHIS_MONTECARLO CSROptionClauseBuilder : public virtual sophis::instrument::CSROption
		{
		public:

			CSROptionClauseBuilder(produit ** h, bool initialiseRecomputeAll = true);

			/**	INTERNAL
				@version 6.1
			*/
			CSROptionClauseBuilder( long dummy );

			virtual ~CSROptionClauseBuilder();

			//virtual bool IsStandardOptionValidationToCheck() const {return false;};

			static sophis::instrument::CSRInstrument* NewDeriveSophis(const void *x);

			const finance::CSRMetaModel * GetDefaultMetaModel() const;

			const finance::CSRMetaModel * GetForceMetaModel() const;

			/** Called to initialise the greek structure.
			*	This method must be called only once and before calling RecomputeAll.
			*	Generally, it is called in the constructors of the first level derivate of CSRInstrument,
			*	but if the overload instrument modifies the instrument, you have a boolean parameter
			*	to avoid an initialization.
			*	The default implementation is to call the following methods:
			*	- {@link CSROptionClauseBuilder::GetUnderlyingCount}
			*	- {@link CSROptionClauseBuilder::GetUnderlying}
			*	- {@link CSROptionClauseBuilder::GetRhoCount}
			*
			*  - {@link CSROptionClauseBuilder::GetRhoCurrency}
			*	to allocate fDeltaEpsilon and fRhoDelta.
			*	@see CSROptionClauseBuilder::RecomputeAll
			*
			*	For Monte Carlo Simulation we must sort different type of risk sources 
			*	according to the rule:
			*		- first we store Equity underlying,
			*		- then we store Forex currency.
			*	Because we got one less forex risk sources than rho risk sources it is then easy to know 
			*	if a risk sources is an equity or a Forex Rates with the 2 methods GetUnderlyingCount 
			*	and GetRhoCount.
			*/
			//virtual	void	InitialiseRecomputeAll();

			/** Get the number of instrument risk sources.
			*	It is used to aggregate the greeks by underlying.
			*	By default, return fUnderlyingCount.
			*/
			//virtual	int		GetUnderlyingCount() const;

			/** Get the number of interest rate risk sources.
			*	It is used to aggregate the rho by currency.
			*	By default, return fRhoCount.
			*/
			//virtual	int		GetRhoCount() const;

			/** Get the nth underlying risk sources.
			*	@param which is an index between 0 (included) and GetUnderlyingCount() (excluded).
			*	@return the ID of the instrument.
			*	By default, return the sources read in fDeltaEpsilon. If null, return the 
			*	value read in fRiskSources.
			*/
			//virtual	long	GetUnderlying(int which) const;

			/** Get all the underlyings contained in the clause builder
			*/
			virtual void	EnumerateUnderlyingCodes(_STL::vector<long>& underlyings) const;

			/** Ask if the risk source is a vega source.
			This is used when changing the currency to add a support for forex vega.
			@param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
			@since 5.3.0
			*/		
			//virtual bool	IsAVegaUnderlying(int whichUnderlying) const;

			/** Ask if the risk source is a delta source.
			This is used for forex risk sources when using currency code as delta risk sources and forex code
			as vega risk sources.
			@param whichUnderlying is in index between 0 (included) and GetUnderlyingCount() (excluded).
			@since 5.3.0
			*/			
			//virtual bool	IsADeltaUnderlying(int whichUnderlying) const;

			/** Get the nth currency risk sources.
			*	@param which is an index between 0 included and GetRhoCount() excluded.
			*	@return the currency in format '3GBP'.
			*	By default, return the sources read in fRho. If null, return the value read in fRhoSources.
			*/
			//virtual	long	GetRhoCurrency(int which) const;

			/** Method to check if an option can be purchased.
			This is used when purchasing an option.
			@param reason is an output parameter to tell the reason why it cannot be bought.
			@return a boolean telling if it can be purchased.
			*/
			virtual bool CanBePurchased(_STL::string & reason) const;

			/** Test if the instrument is in the right state to be priced.
			*	@return true if the instrument is valid.
			*/
			virtual	Boolean	ValidInstrument() const;

			/** 	used in the forecasts to return a list of alerts for special clauses
				@param forecastDate is the date of forecast.
				@param nb is a valid address to set the count of alerts.
				@return an array of alerts, which is deleted by delete [].
				@see CSRInstrument::NewAlertList
			*/
			virtual instrument::SSAlert *	NewAlertList(long forecastDate, int *nb) const;

			/** Automatic ticket to create.
			*/
			virtual instrument::CSRInstrument::eAutomaticTicketType GetAutomaticTicket(long date, _STL::vector<instrument::CSRInstrument::AutomaticTicket> &list) const;

			/** Automatic ticket to create by reporting.
			*/
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const;

			/** Called by each position when a special automatic ticket.
			*/
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const instrument::CSRInstrument::portfolio_automatic_ticket &port) const;


			/** Call back of the special extraction created for automatic ticket.
			*/
			virtual bool AddSpecialReportingForAutomaticTicket(bool eoy, long type, void * input, void * output) const;

			/// Initialize this instrument from a description
			/** Overriden from {@link CSROption::UpdateFromDescription}*/
			void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			/** Method used to reaggregate vega risk on the relevant currency for FX when one of the pair currencies
			*	is the option strike currency.
			*/
			void InitialiseRiskSources(	const _STL::vector<long> &riskSourceFromPayoff,
										const _STL::vector<long> &rhoSourceFromPayoff,
										/*out*/ CSRComputationResults& rs) const;

		protected :

			/** Constructor - for internal use only
			*	
			*/
			CSROptionClauseBuilder();

			/** Used by a constructor to initialize an object.
				This is for internal use only.
				@version 6.1
			*/
			void Initialize(produit ** prod, bool initialiseRecomputeAll=true);

			/** INTERNAL
				@version 6.1
			*/
			void Initialize(long dummy);

		public:
			/** INTERNAL
				@version 6.1
			*/
			virtual bool	UseSpecificData() const;

			// useful for C# side
			void	LaunchRecomputeAll(const market_data::CSRMarketData & context, sophis::CSRComputationResults& results);

			virtual const char *		GetXMLRootName() const; 
			
			int							GetUnderlyingInOptionCount() const {return fUnderlyingInOption;};

			void						SetUnderlyingInOptionCount(int count) { fUnderlyingInOption = count; };

			bool						FillClausesAndBasketDefinition(	CSRClauseBuilderClauseManager& clauseManager	,
																		_STL::vector<long> &	underlyingList	,
																		_STL::vector<long> &	currencyList	,
																		_STL::vector<CSRServerPayoff::SSMCPaymentCurrency> &	cashFlowCurrencyData);

			//fill fixing list with code = index in underlying list and dates = payoff date index
			void						FillObsFixing(FixingsList&	obsDateFixing, long today,const market_data::CSRMarketData &contextGeneral, const _STL::vector<long>& allDates );

			void						SetFixingDates(	_STL::vector<long>&					dates,
														_STL::vector< CSRSimulationManager::SSCLBFixingClauseDescription >& fixingDescription,
														CSRClauseBuilderClauseManager*		clauseManager = NULL);

			void                        ModifyFixingDate (long oldDate, long newDate); 

			void						ModifyFixingValue (long oldDate, long underlying, double newFixingValue);

			int							ParseUnderlying(const _STL::string& underlyingName) const;

			void						SetSingleStocksAndBaskets(	CSRMCBasketManager& basketMgr,
																	_STL::vector<long>& underlyingList,
																	_STL::vector<long>& list);

			virtual void				SetOptionClauses(CSRHierarchicalClauseManager&	clauseManager);

			const _STL::vector<int>		&GetRootIds() const {return fRootIds;};

			bool						NeedGapRiskError() const;

			int							GetBasketCount() const { return fBasketCount; };

			virtual void				DescribeUnderlyer(tools::dataModel::DataSet& dataSet, long code) const;


			void						SetIndicators(const CSRMetaModel* model );

			double						GetStandardDeviation() const { return fStandardDeviation; };

			bool						IsRateLegPaid() const;
			void						SetRateLegPaid(bool paid = false);

			bool						IsNotDeliverable() const;
			void						SetIsNotDeliverable(bool isNotDeliverable = false);

			double GetFixingFromHisto(const CSRInstrument* instr, long fixingDate, int fixingType, const market_data::CSRMarketData	&contextGeneral) const;
			
			double GetFixingFromHisto(long forexCode, long fixingDate, int fixingType, const market_data::CSRMarketData	&contextGeneral) const;
			
			double GetSpotFixing(	long	code,
									bool	isCompo,
									long	fixingDate,
									 long	fixingType,
									const market_data::CSRMarketData	&contextGeneral) const;

			double GetSpotFixing(	long	code,
									bool	isCompo,
									long	fixingDate,
									long	fixingType,
									const market_data::CSRMarketData	&contextGeneral,
									bool & isHistorical) const;

			double GetHistoricalFixing( long	code,
										bool	isCompo,
										long	fixingDate,
										 long	fixingType,
										const market_data::CSRMarketData	&contextGeneral) const;

			double GetMissingFixing(long	code,
									long	fixingDate,
									 long	fixingType,
									const market_data::CSRMarketData &contextGeneral) const;

			double GetMissingFixing(long	code,
									long	fixingDate,
									long	fixingType,
									const market_data::CSRMarketData &contextGeneral,
									bool & isHistorical) const;


			virtual CSROption* CloneOptionWithBarrierShift() const;



			virtual sophis::portfolio::CSRBarrierMonitor* ProvideBarrierMonitor() const;

			/**
			* Call back on {@see CSRInstrument::GetClientPayoff}
			*/
			sophis::finance::CSRClientPayoff *	GetClientPayoffClauseBuilder() const;


			/**
			* Open set up dialog for pricing dump then ru scenario to create the corresponding dump.
			*/
			void GeneratePricingDump() const;


			static void (*ClauseBuilderPricingDump)(const CSROptionClauseBuilder & clbToDump);

			void ReloadCommoWorksheets();

		protected:

			double GetFirstFixingBefore(const CSRInstrument* instr, int fixingDate, int fixingType, const market_data::CSRMarketData	&contextGeneral) const;

			/** Factory for the creation of a specific multiunderlying pay-off. Do not overload it:
			*	in order to use a specific payoff, you must Initialise the client pay-off prototype.
			*/
			virtual	CSRClientPayoff*	new_CSRClientPayoff() const;

			void CleanData();

			int							fUnderlyingInOption;
			int							fBasketCount;
			_STL::vector<int>			fRootIds;
			double						fStandardDeviation;

		protected: //Internal data and methods

			/** Vector storing risk sources.
			*/
			//_STL::vector<long>	fRiskSources;

			/** Vector storing rho sources.
			*/
			//_STL::vector<long>	fRhoSources;

			//_STL::vector<eUnderlyingType> fUnderlyingType;

		private:

			finance::CSROptionMonteCarloMetaModel fMMMetaModel;

		};

		class SOPHIS_MONTECARLO CSRClauseBuilderGenericContainer : public CSRGenericContainer
		{
		public:
			CSRClauseBuilderGenericContainer();
			CSRClauseBuilderGenericContainer(const CSRGenericIndicatorServer & gis);
			const CSRGenericIndicatorServer & GetGenericIndicatorServer() const {return fGenericIndicatorServer;};

			virtual CSRGenericContainer* Clone() const;
			virtual const char* GetName() const									;
			virtual void WriteToArchive(sophis::tools::CSRArchive& a) const		;
			virtual void ReadFromArchive(const sophis::tools::CSRArchive& a)	;

			static long key;
		private:
			CSRGenericIndicatorServer fGenericIndicatorServer;
		};
	}
}
SPH_EPILOG
#endif
