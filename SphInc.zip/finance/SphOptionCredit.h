#ifndef _SphOptionCredit_H_
#define _SphOptionCredit_H_

#include "SphInc/instrument/SphOption.h"
#include "SphInc/finance/SphMonteCarloMultiUnderlying.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

#define OPTION_CREDIT_MODEL_NAME "Credit Derivative"

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		class SOPHIS_MONTECARLO CSROptionCredit : public virtual MultiUnderlyingsInterface
		{
		public:

			CSROptionCredit(produit ** h, bool initialiseRecomputeAll = true);
			virtual ~CSROptionCredit();

			static CSRInstrument*	NewDeriveSophis(const void *x);

			_STL::string	GetPayoffName() const;
			void			SetPayoffName( const _STL::string & payoffName );
			
			/** Test if the instrument is in the right state to be priced.
			*	@return true if the instrument is valid.
			*/
			virtual	Boolean	ValidInstrument() const;

			virtual void	GetRealCreditUnderlyings(_STL::set<long> & underlyings) const;

		protected:
			CSROptionCredit();
			void Initialize(produit ** h, bool initialiseRecomputeAll = true);

			/** Factory for the creation of a specific multiunderlying pay-off. Do not overload it:
			*	in order to use a specific payoff, you must Initialise the client pay-off prototype.
			*/
			virtual	CSRClientPayoff* new_CSRClientPayoff() const;

		};
	}
}
SPH_EPILOG
#endif
