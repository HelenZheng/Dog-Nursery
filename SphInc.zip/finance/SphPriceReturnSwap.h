#ifndef _SPH_PRICERETURNSWAP_H_
#define _SPH_PRICERETURNSWAP_H_

#include "SphInc/finance/SphBasketSwap.h"

SPH_PROLOG

/**
 * For registering CSRPriceReturnSwap derived implementation.
 * @version 7.1.1
 */
#define	INITIALISE_PRICE_RETURN_SWAP(derivedClass,name)\
	INITIALISE_SWAP(derivedClass,name)\
	sophis::finance::CSRBasketSwap::GetBasketSwapModels().insert(_STL::string(name));\
	sophis::finance::CSRPriceReturnSwap::GetPriceReturnSwapModels().insert(_STL::string(name));

namespace sophis{
namespace finance{


class SOPHIS_FINANCE CSRPriceReturnSwap : public virtual CSRBasketSwap
{
public:

#ifndef GCC_XML
	/**
	 * INTERNAL. Used for storing collection of CSRPriceReturnSwap derived instruments.
	 */
	static _STL::set<_STL::string>& GetPriceReturnSwapModels();
#endif

	/**
	Swap declaration.
	@version 5.3
	*/
	DECLARATION_SWAP( CSRPriceReturnSwap);
	
private:

	void InitialiseItself(SW_Donne **sw);

};



}
}
SPH_EPILOG

#endif