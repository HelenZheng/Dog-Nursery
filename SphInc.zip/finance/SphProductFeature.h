/*
 	File:		SphProductFeature.h
 
 	Contains:	Class for the handling of a product feature
 
 	Copyright:	� 2005 Sophis.
*/

/*! \file SphBond.h
	\brief For the handling of a product type.
*/

#pragma once


#ifndef _SPH_PRODUCT_FEATURE_
#define _SPH_PRODUCT_FEATURE_

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphMacros.h"

#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_PRODUCT_FEATURE(derivedClass)			DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRProductFeature) 
#define CONSTRUCTOR_PRODUCT_FEATURE(derivedClass)		
#define WITHOUT_CONSTRUCTOR_PRODUCT_FEATURE(derivedClass)
#define	INITIALISE_PRODUCT_FEATURE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)

SPH_PROLOG
namespace sophis {
	namespace instrument {
		
		class CSRSwap;
		class CSRBond;
		class CSROption;
		class CSRCapFloor;
		class CSRFuture;
		class CSRLoanAndRepo;
		class CSRForexSpot;
		class CSREquity;
		class CSRForexFuture;
		class CSRPackage;
		class CSRDebtInstrument;
		class CSRCommission;
		class CSRContractForDifference;
	}
		
	namespace finance {
		class ISRProductTypeSubject;
		

		/** Interface to define a product type.
		It is used to define a model for a product type.
		To add a new product type, derive that class and install it in the prototype.
		@since 5.0
		*/
		class SOPHIS_FIT CSRProductFeature
		{
		public:

			/** Trivial destructor.
			*/
			virtual ~CSRProductFeature();

			/** Test if a swap belongs to this product type.
			@param swap is a swap.
			@return true if the swaps belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRSwap &swap) const; 

			/** Test if a bond belongs to this product type.
			@param bond is a bond.
			@return true if the bond belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRBond &bond) const; 

			/** Test if a option belongs to this product type.
			@param option is an option.
			@return true if the option belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSROption &option) const;

			/** Test if a cap/floor belongs to this product type.
			@param capFloor is an cap/floor.
			@return true if the capFloor belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRCapFloor &capFloor) const;

			/** Test if a future belongs to this product type.
			@param future is a future.
			@return true if the future belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRFuture &future) const; 

			/** Test if a stock loan belongs to this product type.
			@param loan is a loan.
			@return true if the loan belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRLoanAndRepo &loan) const; 

			/** Test if a Forex Spot belongs to this product type.
			@param fxspot is a forex spot.
			@return true if the forex spot belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRForexSpot &fxspot) const; 


			/** Test if a Forex Future belongs to this product type.
			@param fxfuture is a forex future.
			@return true if the forex future belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRForexFuture &fxfuture) const; 

			/** Test if a Package belongs to this product type.
			@param package is a package.
			@return true if the package belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRPackage &package) const; 

			/** Test if a Debt Instrument belongs to this product type.
			@param debtInstrument is a Debt Instrument.
			@return true if the Debt Instrument belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRDebtInstrument &debtInstrument) const; 

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_PRODUCT_FEATURE.
			@see tools::CSRPrototype
			*/
			virtual CSRProductFeature* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRProductFeature, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_PRODUCT_TYPE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/** Test if an Equity belongs to this product type.
			@param equity is a equity.
			@return true if the equity belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSREquity &equity) const;

			/** Test if a Commission belongs to this product type.
			@param commission is a commission.
			@return true if the commission belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRCommission &commission) const;

			/** Test if a cfd belongs to this product type.
			@param cfd is a contract for difference.
			@return true if the cfd belongs to this product type.
			The default implementation is to return false.
			*/
			virtual bool BelongsTo(const instrument::CSRContractForDifference &cfd) const;

			/** Test if a product feature subject belongs to this product feature.
			 *  @param subject is an implementation of ISRProductTypeSubject.
			 *  @return true if the subject belongs to this product type.
			 *  Calls ISRProductTypeSubject::HasFeature().
			 */
			virtual bool BelongsTo(const ISRProductTypeSubject &subject) const;
		};
	}
}
SPH_EPILOG
#endif // _SPH_PRODUCT_FEATURE_

