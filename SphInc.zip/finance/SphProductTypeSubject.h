#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_FINANCE_SPHPRODUCTTYPESUBJECT_H__
#define __SOPHIS_FINANCE_SPHPRODUCTTYPESUBJECT_H__

#include "SphTools/SphCommon.h"
#include "SphInc/SphMacros.h"
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		class CSRProductType;
		class CSRProductFeature;

		/**
		 *  Interface to allow products defined outside Risk to use the product type mechanism.
		 */
		class ISRProductTypeSubject
		{
		public:
			virtual bool IsOfType(const CSRProductType &type, const _STL::string &typeName) const = 0;
			virtual bool HasFeature(const CSRProductFeature &feature, const _STL::string &featureName) const = 0;
			virtual bool IsThisAllotment(long isThisAllot) const = 0;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const = 0;
		};
	}
}
SPH_EPILOG

#endif // __SOPHIS_FINANCE_SPHPRODUCTTYPESUBJECT_H__