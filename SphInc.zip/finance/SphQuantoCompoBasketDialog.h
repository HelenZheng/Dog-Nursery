
#ifndef _SphQuantoCompoBasketDialog_H_
#define _SphQuantoCompoBasketDialog_H_


#include "SphInc/gui/SphInstrumentDialog.h"


SPH_PROLOG
namespace sophis	{

	namespace finance	{

		const int kQuantoCompoBasketDialogId = 394;
		const int kQuantoCompoBasketDialogElemCount	= 5;

		enum eQuantoCompoDialogElementType {
			qcdeOk				= 1,
			qcdeCorrelation,
			qcdeCall,
			qcdePut,
			qcdeVolatility,
			qcdeMaturity,
			qcdeFrame			= 9,
			qcdeFixedCorrel		= 1001,
			qcdeFixedCorrelValue
		};

		class SOPHIS_FINANCE CSRQuantoCompoBasketDialog : public sophis::gui::CSRInstrumentDialog
		{
			DECLARATION_INSTRUMENT_DIALOG(CSRQuantoCompoBasketDialog)

		public:
			CSRQuantoCompoBasketDialog(sophis::instrument::CSRInstrument* instrument, bool initialiseElement = true);
			void Initialize(sophis::instrument::CSRInstrument* instrument = 0, bool initialiseElement = true);

			virtual void Open(void);
			virtual	void ElementValidation(int EAId_Modified);
		};

	}
}
SPH_EPILOG

#endif
