/*
File:		SphRangeAccruals.h

Contains:	Classes for range acrruals data of interest rate legs (fixed, floating).

Copyright:	� 1995-2005 Sophis.

*/

/*! \file SphRangeAccruals.h
\brief Classes for range acrruals data of interest rate legs (fixed, floating).
*/

#pragma once


#ifndef _SphRangeAccrual_H__
#define _SphRangeAccrual_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"
#include "SphSDBCInc/tools/SphBaseTypes.h"
#include "SphInc/static_data/SphHistoricalData.h"


#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis	{
	namespace instrument	
	{
		struct SSFlow;
		class CSRLeg;
		class CSRInstrument;
	}

	namespace market_data
	{
		class CSRMarketData;
	}
}

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}

	namespace sql
	{
		class CSRSqlQuery;
		class CSRStructureDescriptor;
	}
}

class CSDialogRangeAccrual;
class CSRRangeList;

namespace sophis	{
	namespace finance	{

		struct SSFixingData
		{
			SSFixingData() : fFixingDate(0), fRate(0), fRate2(0), fWeight(1), fInRange(false)
			{}

			long	fFixingDate;

			/** Fixing rate; if 0, it is not fixed.*/
			double	fRate;

			double	fRate2;

			int		fWeight;

			bool	fInRange;
		};


		class SOPHIS_BASIC_DATA CSRFixingList : public _STL::vector<SSFixingData>	
		{
		public:

			/** Sum of the weight which is the denominator.
			*/
			long	GetTotalWeight() const;

			/** Sum of the weight of fixings in range, which is the numerator.
			*/
			long	GetAccrualWeight() const;

			/** Sum of the weight of fixings in range with fixing date before the calculation_date(included), which is the numerator.
			*	In that case, the denominator is the "weight_already_fixed" returned by CSRFixingList::FirstIndexNotFixed
			*/
			long	GetAccrualWeight(long calculation_date) const;

			/** return the position of the first fixing in the future.
			*/
			const_iterator	FirstIndexNotFixed(long calculation_date, long * weight_already_fixed) const;

		};


		enum eAccrualFrequency
		{
			afUndefined,
			afOneDay,
			afOneWeek,
			afOneMonth,
			afThreeMonth
		};

		enum eCutOffPeriod
		{
			cpCarryLast = 1,	// last reset is used until the end of the period
			cpShorten,			// average period has less days than the interest period
			cpContiguous		// Only the start of the first averaging period is defined by the start offset. Subsequent averaging periods start just after the end of the preceding period
		};

		enum eAccrualWeighting
		{
			awUnweighted = 1,	// All resets have a weight equal to 1 
			awWeighted			// Every reset has a weight equal to the number of days to the next reset (like the TAG index)
		};

		struct SSRange
		{
			SSRange() : fStartDate(0), fEndDate(0), fLowerBarrier(0), fUpperBarrier(0), fLowerBarrier2(0), fUpperBarrier2(0)
			{}
			long	fStartDate;
			long	fEndDate;
			/** Null if not minored
			*/
			double	fLowerBarrier;

			/** Null if not majored
			*/
			double	fUpperBarrier;
			/** Null if not minored or single range accrual
			*/
			double	fLowerBarrier2;

			/** Null if not majored or single range accrual
			*/
			double	fUpperBarrier2;
		};

		struct AccrualReadParam
		{
			AccrualReadParam() : fRateIndex(0), fFrequency(0), fStartOffset(0), fCutOffLag(0), fCutOffPeriod(0), fWeighting(0), fRollOverDate(0), fRateIndex2(0)
			{}

			long	fRateIndex;
			short	fFrequency;
			short	fStartOffset;
			short	fCutOffLag;
			short	fCutOffPeriod;
			short	fWeighting;
			long	fRollOverDate;
			long	fRateIndex2;
		};

		struct AccrualWriteParam : public AccrualReadParam
		{
			long	fSicovam;
			short	fLeg;
		};

		struct RangeWriteParam : public SSRange
		{
			long	fSicovam;
			short	fLeg;
		};

		struct AccrualQueryParam
		{
			long	fSicovam;
			short	fLeg;
		};

		class SOPHIS_BASIC_DATA CSRRangeAccrual {
		public:
			virtual ~CSRRangeAccrual();
			CSRRangeAccrual(const CSRRangeAccrual& source);

			/**
			*	"virtual copy constructor"
			*	@return : a copy of the object
			*/
			virtual CSRRangeAccrual*	Clone() const;

			long GetRateIndex() const;
			void SetRateIndex(long rate);

			eAccrualFrequency GetFrequency() const;
			void SetFrequency(eAccrualFrequency freq);

			short GetStartOffset() const;
			void SetStartOffset(short offset);

			short GetCutOffLag() const;
			void SetCutOffLag(short lag);

			eCutOffPeriod GetCutOffPeriod() const;
			void SetCutOffPeriod(eCutOffPeriod period);

			eAccrualWeighting GetWeighting() const;
			void SetWeighting(eAccrualWeighting weight);

			long GetRollOverDate() const;
			void SetRollOverDate(long date);

			void GetRangeList(_STL::vector<SSRange>& rList) const;
			void SetRangeList(const _STL::vector<SSRange>& rList);

			//For Dual Range accrual
			long GetRateIndex2() const;
			void SetRateIndex2(long rate);

			/**
			*	Get the range corresponding to the input flow
			*	if not found return a range with null Start Date
			*	@param flow : instrument flow for which range is asked 
			*/
			virtual SSRange GetRange(const sophis::instrument::SSFlow &flow) const;

			/**
			*	Generate range accrual fixings
			*	@param flow : instrument flow for which fixings are generated 
			*	@param output : the generated fixing list
			*	@param first_start_date : first flow start date, to handle the contiguous cutoff period
			*	@param calculationDate : computation date.
			*	@param histoData : is the object to get historical fixings.
			*   @since 6.1 : no more CSRMarketData but calculation date and CSRHistoricalData instead.
			*/
			virtual void GenerateRangeData(const sophis::instrument::SSFlow &flow, CSRFixingList & output, long first_start_date, long calculationDate, const static_data::CSRHistoricalData &histoData) const;

			void SortRangeList();

			/**
			*	The method returns the (probability) weight of the not fixed elements(with null fixing rate) of the fixings list
			*	@param begin : position of the first not fixed element of the fixings vector (@see CSRFixingList::FirstIndexNotFixed).
			*	@param end : the fixings vector end.
			*	@param minimum : lower barrier of the range associated to the selected flow.
			*	@param maximum : upper barrier of the range associated to the selected flow.
			*	@param instr : the instrument having the range accrual leg.
			*	@param leg : the range accrual leg which pays that flow.
			*	@param whichFlow : index of the flow to be selected.
			*	@param context : computation market data.
			*	@see CSRFixingList
			*	@see CSRRangeAccrual
			*   @deprecated : use the one below
			*/
			virtual double GetAccrualWeight(CSRFixingList::const_iterator begin,
																CSRFixingList::const_iterator end,
																double minimum,
																double maximum,
																const sophis::instrument::CSRInstrument* instr,
																const sophis::instrument::CSRLeg* leg,
																int whichFlow,
																const sophis::market_data::CSRMarketData& context) const;

			/**
			*	The method returns the (probability) weight of the not fixed elements(with null fixing rate) of the fixings list
			*	@param begin : position of the first not fixed element of the fixings vector (@see CSRFixingList::FirstIndexNotFixed).
			*	@param end : the fixings vector end.
			*	@param minimum : lower barrier of the range associated to the selected flow.
			*	@param maximum : upper barrier of the range associated to the selected flow.
			*	@param flow : flow te be selected.
			*   @param flowRateCode : underlying rate code for floating coupon bonds, unused for fixed coupon bonds.
			*	@param context : computation market data.
			*	@see CSRFixingList
			*	@see CSRRangeAccrual
			*/
			virtual double GetAccrualWeight( CSRFixingList::const_iterator	              begin,
											 CSRFixingList::const_iterator	              end,
											 double							              minimum,
											 double							              maximum,
											 const sophis::instrument::SSFlow	          &flow,
											 long                                         flowRateCode,
											 const sophis::market_data::CSRMarketData	  &context) const;

			/**
			*   Returns the factor that should multiply the vanilla flow price to account for the range accrual clause.
			*   @param calculation_date : the calculation_date.
			*	@param productStartDate : swap/bond 's first flow's start date.
			*   @param flow : flow to price.
			*   @param flowRateCode : underlying rate code for floating coupon bonds, unused for fixed coupon bonds.
			*   @param context : computation market data.
			*   @param missingFixings : returns whether there are missing fixings.
			*/
			double GetAccrualRatio( long calculation_date,
									long productStartDate,
									const sophis::instrument::SSFlow& flow,
									long flowRateCode,
									const sophis::market_data::CSRMarketData& context,
									bool *missingFixings = 0) const;

			/**
			*	For current coupon : multiply by this value to get the correct accrued
			*/
			double GetAccruedRatio( long productStartDate,
									long accruedCouponDate,
									const sophis::instrument::SSFlow& flow, 
									const sophis::market_data::CSRMarketData& context) const;

			static CSRRangeAccrual * (*CreateInstance)();


			/***********
			*   SQL   *
			***********/

			/**
			*	Save the range accrual data into the database
			*	@param sico : sicovam of the instrument which contains this range accrual leg
			*	@param leg : index of the leg in the swap (0 or 1)
			*/
			 sophis::sql::errorCode		WriteToDatabase(long sico, int leg);

			/**
			*	Load the range accrual data from the database
			*	@param sico : sicovam of the instrument which contains this range accrual leg
			*	@param leg : index of the leg in the swap (0 or 1)
			*/
			sophis::sql::errorCode		ReadFromDatabase(long sico, int leg);

			/**************
			*   static   *
			**************/

			/**
			*	Associate the new sico with the range accruals (of the 2 legs).
			*	The histo is stored in the same sql table.
			*	simply replace sico by newSico in the table
			*	@param sico : sico of the swap
			*	@param newSico : sico of the archived swap
			*/
			static sophis::sql::errorCode	Historize(long sico, long newSico);

			// Do not use (for archiving)
			static tools::CSRArchive & WriteToArchive(tools::CSRArchive & ar, const CSRRangeAccrual *ra );
			static const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &ar , CSRRangeAccrual *&ra );

			/***************
			*   Friends   *
			***************/
			friend tools::CSRArchive & WriteToArchive(tools::CSRArchive & far, const CSRRangeAccrual *fra );
			friend const tools::CSRArchive & ReadFromArchive(const tools::CSRArchive &far , CSRRangeAccrual *&fra );
			
			friend class CSDialogRangeAccrual;
			friend class CSRRangeList;

		protected:
			CSRRangeAccrual();

			friend CSRRangeAccrual * CreateStandardRangeAccrual();

		private:
			/*********************** 
			* Range accruals Data *
			**********************/
			long					fRateIndex;
			eAccrualFrequency		fFrequency;
			short					fStartOffset;
			short					fCutOffLag;
			eCutOffPeriod			fCutOffPeriod;
			eAccrualWeighting		fWeighting;
			long					fRollOverDate;
			_STL::vector<SSRange>	fRangeList;
			//For Dual range accrual
			long					fRateIndex2;

		};
	}
}

// For archives
extern SOPHIS_BASIC_DATA sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::finance::CSRRangeAccrual * accrual);
extern SOPHIS_BASIC_DATA const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::finance::CSRRangeAccrual *& accrual);

SPH_EPILOG

#endif //!_SphRangeAccrual_H__
