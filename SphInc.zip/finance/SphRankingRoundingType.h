/*
 	File:		SphRankingRoundingType.h
 
 	Contains:	Class for the handling of a ranking rounding type
 
 	Copyright:	� 2010 Sophis.
*/

/*! \file SphRankingRoundingType.h
	\brief For the handling of a ranking rounding type.
*/

#pragma once

#ifndef _SPH_RANKING_ROUNDING_TYPE_
#define _SPH_RANKING_ROUNDING_TYPE_

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(string)

#include "SphTools/SphPrototype.h"
#include "SphInc/SphMacros.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/portfolio/SphPosition.h"


#define DECLARATION_RANKING_ROUNDING_TYPE(derivedClass)							\
	DECLARATION_PROTOTYPE(derivedClass,sophis::finance::CSRRankingRoundingType)	\
	public: derivedClass();

#define CONSTRUCTOR_RANKING_ROUNDING_TYPE(derivedClass)			derivedClass::derivedClass() {}
#define WITHOUT_CONSTRUCTOR_RANKING_ROUNDING_TYPE(derivedClass)
#define	INITIALISE_RANKING_ROUNDING_TYPE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass,  name)


SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		/** Interface to define a ranking rounding type.
		It is used to determine the average ranking.
		To add a new method, derive that class and install it in the prototype.
		@since 6.2
		*/
		class SOPHIS_FIT CSRRankingRoundingType
		{
		public:

			/** Trivial constructor.
			@see Initialise
			*/
			CSRRankingRoundingType();

			/** Copy constructor.
			*/
			CSRRankingRoundingType(const CSRRankingRoundingType &method);

			/** Assignation.
			*/
			CSRRankingRoundingType & operator =(const CSRRankingRoundingType &method);

			/** Destructor.
			*/
			virtual ~CSRRankingRoundingType();

			/** Clone method needed by the prototype.
			Usually, it is done automatically by the macro DECLARATION_RANKING_ROUNDING_TYPE.
			@see tools::CSRPrototype
			*/
			virtual CSRRankingRoundingType* Clone() const = 0;

			/** Typedef for the prototype (the key is a string).
			*/
			typedef sophis::tools::CSRPrototype<CSRRankingRoundingType, const char*, sophis::tools::less_char_star> prototype;

			/** Access to the prototype singleton.
			To add an amount to this singleton, use INITIALISE_RANKING_ROUNDING_TYPE.
			@see tools::CSRPrototype
			*/
			static prototype& GetPrototype();

			/* This method is used to find the ranking value by rounding the input ranking level.
			@param value is the ranking level to round.
			@param lowerValue is the lower ranking value.
			@param upperValue is the upper ranking value
			@return the number of days to close the position.
			@since 6.2
			*/
			virtual double GetRoundedValue(double value, double lowerValue, double upperValue) const = 0;

			virtual _STL::string GetName() const = 0;
		};
	}
}
SPH_EPILOG

#endif