#pragma once

#include "SphTools/SphCommon.h"
#include "SphInc/SphMath.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)
#include "SphTools/SphArchive.h"


namespace sophis	{
	namespace finance	{
		class CSRVolatilitySurfaceParametric;
	}
}
namespace sophis
{
	namespace finance
	{

		//Global interface for smile model. Only the maturity is defined here.
		class SOPHIS_MATH CSRSmileModel
		{
		public:
			CSRSmileModel();
			
			CSRSmileModel(const CSRSmileModel & smile);

			virtual ~CSRSmileModel();

			/** Store CSRSmileModel data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRSmileModel with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRForwardPriceCalculator::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRForwardPriceCalculator initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			
			/** Get the maturity associated with this smile
			@return is the maturity associated with this smile
			@since 6.3.3
			*/
			double GetMaturity() const;
			
			/** Set a maturity to this smile
			@param is the maturity to be associated with this smile 
			@since 6.3.3
			*/
			void SetMaturity(const double maturity);

		protected:
			double fMaturity;
		};

		/** Interface which handle strike expressed as a ratio of the forward Price at the maturity associated with the smile.
		*/
		class SOPHIS_MATH CSRSmileForwardInterpolation : public sophis::finance::CSRSmileModel
		{
		public:
			CSRSmileForwardInterpolation();

			/**	Get the implied volatility and its first and second derivatives versus strike. 
			*	The strike can be absolute or relative compared to the forward price fForwardPrice
			@param strike is the strike at witch the implied volatility must be calculated. It can be an absolute or relative (a ratio of forward price) value
			@param firstStrikeDerivative if nonzero, return the first strike derivative
			@param secondStrikeDerivative if nonzero, return the second strike derivative
			@param absoluteStrike if true the strike is an absolute value, false if is relative to the forward price

			@return the implied volatility
			@since 6.3.3
			*/
			double GetImpliedVolatilityAndStrikeDerivatives(double			strike,
															/*out*/ double	*firstStrikeDerivative,
															/*out*/ double	*secondStrikeDerivative, 
															bool			absoluteStrike) const;
			
			/**
			*   Get the implied volatility and its first and second derivatives versus strike. Strike is expressed here as an absolute value.    
			@param strike is the strike at witch the implied volatility must be calculated. It must be an absolute value.
			@param firstStrikeDerivative if nonzero, return the first strike derivative
			@param secondStrikeDerivative if nonzero, return the second strike derivative

			@return the implied volatility
			@since 6.3.3
			*/
			virtual double GetImpliedVolatilityAndStrikeDerivatives(double			strike,
																	/*out*/ double	*firstStrikeDerivative,
																	/*out*/ double	*secondStrikeDerivative) const = 0;

			/** Store CSRSmileForwardInterpolation data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRSmileForwardInterpolation with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRForwardPriceCalculator::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRForwardPriceCalculator initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			
			/** Get the forward Price associated with this smile
			@return the forward Price associated with this smile
			@since 6.3.3
			*/
			double GetForwardPrice()const;
			
			/** Set a forward Price to this smile
			@param forwardPrice is the forward price to be attached to this smile
			@since 6.3.3
			*/
			void SetForwardPrice(double forwardPrice){fForwardPrice = forwardPrice;};
		protected:
			double fForwardPrice;
		};

		/** Interface which handle smile for which the price and its derivatives versus the strike are known (@link function GetTimeValueAndDerivate)
		*	The implied volatility is deduced by an inversion of the Black-Scholes formula with an accuracy determined by fAccuracy
		*	Implied volatility derivatives versus strike are deduced from the price derivative versus strike and Black Scholes partial derivative with K and Sigma.
		*/
		class SOPHIS_MATH CSRSmileCallPrice : public sophis::finance::CSRSmileForwardInterpolation
		{
		public:
			CSRSmileCallPrice();

			/**
			*   Get the implied volatility and its first and second derivatives versus strike. Strike is expressed here as an absolute value.
			The implied volatility is deduced by an inversion of the Black-Scholes formula with an accuracy determined by fAccuracy
			Implied volatility derivatives versus strike are deduced from the price derivative versus strike and Black Scholes partial derivative with K and Sigma.

			@param strike is the strike at witch the implied volatility must be calculated. It must be an absolute value.
			@param firstStrikeDerivative if nonzero, return the first strike derivative
			@param secondStrikeDerivative if nonzero, return the second strike derivative

			@return the implied volatility
			@since 6.3.3
			*/
			virtual double GetImpliedVolatilityAndStrikeDerivatives(	double			strike,
																		/*out*/ double	*firstStrikeDerivative,
																		/*out*/ double	*secondStrikeDerivative) const;
			
			/** Get the undiscounted call price and its first and second strike derivatives for the maturity and forward associated to this smile.
			*   This function must be overload in classes constructed with this interface 
			@param strike is the strike at witch the undiscounted price must be calculated. It must be an absolute value.
			@param firstStrikeDerivative if nonzero, return the first strike derivative of the undiscounted price
			@param secondStrikeDerivative if nonzero, return the second strike derivative of the undiscounted price

			@return of the undiscounted price of a call for the maturity and forward associated to this smile.
			@since 6.3.3
			*/
			virtual double GetTimeValueAndDerivate(double strike, double* firstDerivate, double* secondDerivate) const = 0;

			/** Store CSRSmileCallPrice data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRSmileCallPrice with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRForwardPriceCalculator::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRForwardPriceCalculator initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			/*
			enum eCallInterpolation
			{
				eAccuracy = 0,
				eMaturity,
				eForwardPrice,
				eCallInterpolationParameterCount
			};
			*/
		protected:
			double fAccuracy;
		};

		/**	Interface of smile for parametric volatility model
		*	The smile has a callback to the data (set of parameters by maturity and fixed parameters) of the parametric volatility model
		*	Abstract method SetInterpolatedParameters defines the set of parameters corresponding to this smile (ie to the maturity fMaturity).
		*	After the call of SetInterpolatedParameters, this smile object is able to calculate implied volatility, and its strike and time derivative for every strike.
		*/

		class SOPHIS_MATH CSRSmileVolParametric : public sophis::finance::CSRSmileModel
		{
		public:
			CSRSmileVolParametric();
			CSRSmileVolParametric(const CSRSmileVolParametric& smile);
			virtual ~CSRSmileVolParametric();

			/**	Get the implied volatility, its first and second derivatives versus strike and time derivative  
			@param strike is the strike at witch the implied volatility must be calculated. It must be an absolute value.
			@param firstStrikeDerivative if nonzero, return the first strike derivative
			@param secondStrikeDerivative if nonzero, return the second strike derivative
			@param timeDerivative if nonzero, return the first time derivative

			@return the implied volatility
			@since 6.3.3
			*/
			virtual double GetImpliedVolatilityAndDerivatives(	double						strike,
																/*out, optional*/ double	*firstStrikeDerivative,
																/*out, optional*/ double	*secondStrikeDerivative,
																/*out, optional*/ double	*timeDerivative)const = 0;
			/**
			*	Defines the set of parameters corresponding to this smile (ie to the maturity fMaturity).
			*	Use the callback fParametricModel to access the data stored in the CSRVolatilitySurfaceParametricData object
			@param withDeriv determines if the time derivative of parameters must be calculated and stored in the smile. (it is the case to calculate implied vol time derivative if finite difference is not used)
			@since 6.3.3
			*/
			virtual void SetInterpolatedParameters(bool withDeriv) = 0;

			/** Get the callback on the CSRVolatilitySurfaceParametric object fParametricModel
			@return the callback on the CSRVolatilitySurfaceParametric object fParametricModel
			@since 6.3.3
			*/
			const CSRVolatilitySurfaceParametric* GetParametricModel() const;

			/** Set the callback on the CSRVolatilitySurfaceParametric object fParametricModel
			@param dupirePametric is the callback on the CSRVolatilitySurfaceParametric object fParametricModel to be set
			@since 6.3.3
			*/
			void SetParametricModel(const CSRVolatilitySurfaceParametric* dupirePametric) ;

		protected:
			const CSRVolatilitySurfaceParametric* fParametricModel; //callback to CSRVolatilitySurfaceParametric
		};
	}
}