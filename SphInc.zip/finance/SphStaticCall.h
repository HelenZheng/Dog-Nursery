 /*
 	File:		SphStaticCall.h

 	Contains:	Handling code in a static call in order to optimize Managed Native transition

 	Copyright:	� 2012 Sophis.

*/

/*! \file SphStaticCall.h
	\brief Handling code in a static call in order to optimize Managed Native transition.
*/

#pragma once
#ifndef _SphStaticCall_H_
#define _SphStaticCall_H_

#include "SphInc/SphMacros.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/market_data/SphYieldCurve.h"

SPH_PROLOG
namespace sophis {
	namespace finance {

		class SOPHIS_FINANCE CSRStaticCall
		{
		public:
			static long GetYieldPointMaturity(	const market_data::CSRMarketData & context,
												const market_data::SSYieldPoint& ycPoint,
												long familyCode);
		};

	}
}

SPH_EPILOG
#endif