#ifndef _SphSwapDerives_H_
#define _SphSwapDerives_H_

#ifndef _SphSwap_H__
	#include "SphInc/instrument/SphSwap.h"
#endif

#include "SphInc/finance/SphDefaultMetaModelSwap.h"

SPH_PROLOG
namespace sophis
{
	namespace finance
	{
		class SOPHIS_FINANCE CSRDefaultMetaModelSwapRediscount : public virtual CSRDefaultMetaModelSwap
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelSwapRediscount);
			virtual ~CSRDefaultMetaModelSwapRediscount();
			virtual double GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
			virtual double GetLegTheoreticalValue(const instrument::CSRInstrument & swap, const sophis::market_data::CSRMarketData& context, int which) const OVERRIDE;
		};
		SOPHIS_FINANCE sophis::instrument::CSRSwap* CreateSwapFromRate(	const sophis::static_data::CSRInterestRate	*interestRate,
																		long						fixingDate,
																		const sophis::market_data::CSRMarketData		&context, 
																		long						forceMaturity);

		class SOPHIS_FINANCE CSRSwapRediscount : public virtual sophis::instrument::CSRSwap
		{
			DECLARATION_SWAP(CSRSwapRediscount)

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;
		};

		class SOPHIS_FINANCE CSRSwapWithoutNominalIncrease : public virtual sophis::instrument::CSRSwap
		{
			DECLARATION_SWAP(CSRSwapWithoutNominalIncrease)

			virtual bool			SpecialReporting() const;

		};

		class SOPHIS_FINANCE CSRDefaultMetaModelSwapMarkedToMarket : public virtual CSRDefaultMetaModelSwap
		{
		public:
			DECLARATION_META_MODEL(CSRDefaultMetaModelSwapMarkedToMarket);
			virtual ~CSRDefaultMetaModelSwapMarkedToMarket();
			virtual double GetTheoreticalValue(const instrument::CSRInstrument& instr, const market_data::CSRMarketData& context) const OVERRIDE;
		};

		class SOPHIS_FINANCE CSRSwapMarkedToMarket : public virtual CSRSwapWithoutNominalIncrease
		{
			DECLARATION_SWAP(CSRSwapMarkedToMarket)

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const;

		};

		class SOPHIS_FINANCE CSRSwapNominalIncrease : public virtual CSRSwapRediscount
		{
			DECLARATION_SWAP(CSRSwapNominalIncrease)

			virtual bool			SpecialReporting() const;

		};
	}	//	namespace finance
}	//	namespace sophis
SPH_EPILOG
#endif
