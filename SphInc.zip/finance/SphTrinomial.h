/*
 	File:	SphTrinomial.h

 	Contains:	The Trinomial model and how to customize it

 	Copyright:	� 1999-2000 Sophis.

*/

/*! \file SphTrinomial.h
	\brief Customising the trinomial model.
*/


/***********************

  The class CSRTrinomial implements a general-purpose trinomial tree.
The user can instantiate it by overriding the following virtual methods:

  virtual bool Intervention(double t) const;
			// should we do something special at time t
  virtual void Intervention(double t, double spot, double &option, ePointColorType & pt) const;
            // do something special at time t (take into accout barrier or asian clauses for example),

  Another mean to instantiate the trinomial is to use closures. A closure is
a pointer on a method. At initialization time, the pointer is set to the
address of the right method. At computation time, the pointer is used to call
this method. This allow a great flexibility at a little CPU cost. The same class
can implement a wide variety of pay-off types

  double (*fPayoff)(double s, double t)	const
			// the payoff depending on spot and time
			// t is measured in days since fStartDate

  double (*fSmoothPayoff)(double f, double k, double sig, double mat) const
			// gives the value of an option with strike k, volatility sig and
			// maturity mat. f is the future value with maturity mat
			// this must be multiplied by the ZC to get the value at start time
			// WARNING !
			// If mat is in years, sigma must be in % per year
			// if mat is in days and sigma must be in % per day

  bool (*fExercise)(double t) const
			// t is in days since fToday
			// returns true if the option can be exercised at date t

  void (*fComputeLocalVol)();
  double (*fBareValue)(double t) const;
			// value of the product if the option is not exercised
			// =0 if the product pays no coupons (e.g. plain vanilla call)

 double (*fQuantoFactor)(double t) const;
			// returns 1 except for quanto multi-currency options
			// in the latter case, returns something like
			// exp(-rho*sigma*sigma_FX*(t-fToday))


EXAMPLE: overriding the Payoff calculation
======================================

  There are several standard Payoff methods: PayoffCall, PayoffPut, and so on
  The user may use one standard payoff or define his/her own payoff.

1) To use the PayoffCall, one must put in the constructor of child class:

  fPayoff = &MyTrinomial::PayoffCall

2) To use a custom payoff, one must put in the constructor of child class:

  fPayoff = (PayoffType)&MyTrinomial::MyExoticPayoff

and define somewhere :

  MyTrinomial::MyExoticPayoff(double s, double t)
  {

  // put your code here

  }

3) The steps 1) or 2) were done in a child class of TrinomialParam,
in our example MyTrinomial. Then one must define:


	class CSRMyExoticOption : public CSROptionTrinomial
	{
		virtual TrinomialParam * GetNewTrinomial(market_data::CSRMarketData& param)
		{
			MyTrinomial * tr = new MyTrinomial(this, param);
			return tr;
        }
	}

**************************/

#ifndef _SphTrinomial_H_
#define _SphTrinomial_H_

#ifndef _SphOption_H_
#include "SphInc/instrument/SphOption.h"
#endif

#ifndef _SphEnums_H_
#include "SphInc/SphEnums.h"
#endif

#include "SphInc/market_data/SphMarketData.h"


#include __STL_INCLUDE_PATH(vector)


SPH_PROLOG


// ----------------------------------------------------------------------------------
// SSBarrier2
// ----------------------------------------------------------------------------------
struct SSBarrier2 : public sophis::instrument::SSBarrier
{
public:
	double true_barrier;
	double true_rebate;
	double discounted_rebate;
};

/** inserts x in the (already sorted) array a
 increments length by 0 if x was already in a, 1 otherwise
 do not insert if x is not in the interval [a[0], a[length-1]]
 @return the position where x was inserted or -1 when x cannot be inserted
 */
int SOPHIS_FINANCE insert (double x, double * a, int& length, int max_length);

namespace sophis
{
	namespace math
	{
		class CSRHighOrderPDE;
		class PDETimeOnlyVolatility;
	}
	
	namespace	market_data	{
		class CSRCreditRisk;
	}

	namespace finance
	{

class CSRTrinomialFS;
class CSROptionTrinomial;
class CSRDefaultMetaModelOptionTrinomial;

/** CSRTrinomial.
The normal usage sequence is:
1. CSRTrinomial * t = CSROptionTrinomial::GetNewTrinomial();
2. t->InitTimeSteps();
3. t->InitRateCurvess();
4. t->InitLocalVol();
5. t->GetValue() or t->GetValueDeltaGamma(); */
class SOPHIS_FINANCE CSRTrinomial {

public:
	double					fCreditSpread;
	CSRTrinomial();

	CSRTrinomial(const sophis::instrument::CSROption& option,
		      const market_data::CSRMarketData &param,
		      /** Number of time steps -- in general, equal to option.GetPointCount(). */
			  int number_time_steps,
			  NSREnums::eVolatilityType vol_type,
			  /** The actual number of starting points is 2*n+1. */
			  int number_starting_points =0);
	virtual ~CSRTrinomial();

	virtual void	InitialiseConstructor(const sophis::instrument::CSROption& option,
								 const market_data::CSRMarketData & param,
								 int number_time_steps,
								 NSREnums::eVolatilityType vol_type,
								 int number_starting_points =0);

	/** Selects the actual number of time steps.
	- updates fNbSteps
	- allocates the array fDate = new double[fNbSteps+1]
	- Selects the fDate[i] including events such as reset, coupons, clauses such that the distance between fDate[i] and fDate[i+1] is always <= fTimeStep. */
	virtual void InitTimeSteps();

	/** Source and target MUST have the same start date and end date. */
	virtual void MoveTimeSteps(CSRTrinomial* source);

	/** Calls SpotForwardCoefs() to fill fNMU_a[i], fNMU_b[i] and fNMU_c[i] and calls ForwardZercoupon(fStartDate,fDate[i]) to fill fZC[i]. */
	virtual void InitRateCurves();

	/** Source and target MUST have the same fDate[]. */
	virtual void MoveRateCurves(CSRTrinomial* source);

	/** Allocates and initialises FX (FX==0 for trinomial, used only by PDE model) sets up fUp, fIndexMin,  fIndexMax and fIndexRange. */
	virtual void InitSpaceSteps();

	double* InitAccruedCoupon(double * Date, int NbSteps) const;
	/** Source and targer MUST have the same fDate[] and rate curves. */
	virtual void MoveSpaceSteps(CSRTrinomial* source);

	/** This method calculates the right values of fUp, fIndexMin and fIndexMax then it allocates the necessary space for fLocalVol and calls (*fComputeLocalVol) to fill the local volatility table. */
	virtual void InitLocalVol();

	/** 'Source' and 'target' must have the same time steps, rate curves and space steps.
	After this operation 'source' and 'target' have:
	- the same value fUp
	- the same fIndexMin and fIndexMax and the local volatility table has been moved from 'source' to 'target'.
	After this operation, the object 'source' can be deleted without affecting 'target', but 'source' will not have a valid local volatility table. It is reversible: a call to 'MoveLocalVol(target, source)' will restore 'source' in its initial state. */
	virtual void MoveLocalVol(CSRTrinomial * source);

	virtual double GetValue(sophis::instrument::CSRCoxTreeGraphics *graph =0);
	virtual double GetValueDeltaGamma(double *delta, double *gamma, sophis::instrument::CSRCoxTreeGraphics *graph =0);

	double GetParity() const {return fParity;};
	double GetProportion() const {return fProportion;};
	double GetCurrentTimeIndex() const {return fCurrentTimeIndex;};
	double GetDate(int TimeIndex) const {return fDate[TimeIndex];};
	double GetForward() const {return fForward0;};
	double GetMaxLocalVol() const {return fMaxLocalVol;};
	double GetZeroCoupon(int i) const {return fZC[i];};
	int GetNbSteps() const {return fNbSteps;};
	double GetUp() const {return fUp;};

/**	Inline double GetUpCoeff() { return fUp; }; */
	double GetSpotFromLogForward(int DateIndex, double LogForward) const;
/** 1. Exercise type. */
	typedef bool	(CSRTrinomial::*ExerciseType)(double t) const;
	ExerciseType			fExercise;
	bool AmericanExercise(double t) const;
	bool EuropeanExercise(double t) const;
	bool BermudaExercise(double t) const;
	bool ExerciseClausePaiement(double t) const; // used if there is a CSRPayOffClause in the option

/** 2. Payoff */
	typedef double	(CSRTrinomial::*PayoffType)(double s, double t) const;
	PayoffType				fPayoff;
	double PayoffCall(double s, double t) const;
	double PayoffPut(double s, double t) const;
	double PayoffDigitalCall(double s, double t) const;
	double PayoffDigitalPut(double s, double t) const;
	double PayoffConvertible(double s, double t) const;
	double PayoffORA(double s, double t) const;
	double PayoffClausePaiement(double s, double t) const; // used if there is a CSRPayOffClause in the option

/** 3. Payoff smoothing */
	typedef double  (CSRTrinomial::*SmoothPayoffType)(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	SmoothPayoffType		fSmoothPayoff; // =0 if one wants no payoff smoothing
	double SmoothPayoffCall(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCall(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallUpOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallUpIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDownOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDownIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutUpOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutUpIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDownOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDownIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffRebateUpIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffRebateDownIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffRebateUpOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffRebateDownOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDoubleKnockOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDoubleKnockOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDoubleKnockIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDoubleKnockIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffWithConvolutionKernel(double spot, double forward, double strike, double sig, double mat, double discount) const;

	double SmoothPayoffDigitalCallUpOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallUpIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDownOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDownIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutUpOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutUpIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDownOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDownIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;

	double SmoothPayoffDigitalCallDoubleKnockOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDoubleKnockOut(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDoubleKnockIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDoubleKnockIn(double spot, double forward, double strike, double sigma, double mat, double discount) const;

	/* smoothing formulas used for european barriers at the last but one time step
		european barriers are such that their start and end date are both equal to the
		maturity of the option
		formulas are available for all combination of calls, put, digitals, with 1 or 2 barriers

		double knock-in means that the derivative is triggered whenever any of the barriers is reached
		double knock-out means that the derivative is cancelled whenever any of the barriers is reached

	   @param spot is the spot value in the tree
	   @param forward is the forward from the last but one time step to the maturity
	   @param strike is the strike with the same quotation unit as the spot
	   @param sigma is the local volatility (0.2 for 20%)
	   @param mat is the time difference between the last but one time step
		and the option maturity, expressed as a number of years
	   @param discount is the discount factor between the last but one time step and the option maturity
	   @return the theoretical derivative price
	   @since 522
	*/
	double SmoothPayoffCallUpOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallUpInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDownOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDownInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutUpOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutUpInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDownOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDownInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDoubleKnockOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDoubleKnockOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffCallDoubleKnockInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffPutDoubleKnockInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallUpOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallUpInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDownOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDownInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutUpOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutUpInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDownOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDownInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDoubleKnockOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDoubleKnockOutEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalCallDoubleKnockInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;
	double SmoothPayoffDigitalPutDoubleKnockInEuropean(double spot, double forward, double strike, double sigma, double mat, double discount) const;


/** 4. Quanto factor. */
	typedef double	(CSRTrinomial::*QuantoFactorType)(double t) const;
	QuantoFactorType		fQuantoFactor; // can be ==0
	/** t in number of days since fToday. */
	double DefaultQuantoFactor(double t) const; // simply returns 1.
	double NMUQuantoFactor(double t) const;	// flat vol, flat FX vol and flat correl
	double TDVQuantoFactor(double t) const;	// time-dependent vol, time-dependent FX vol and time-dependent correl

/** 5. Methods to calculate local volatility. */
	typedef void	(CSRTrinomial::*ComputeLocalVolType)();
	ComputeLocalVolType		fComputeLocalVol; // must be != 0
	/** These methods fill the local volatility using the method SetLocalVol() (the fLocalVol array is already allocated when the method is called) to overload it : add your own preferred method to the list and make fComputeLocalVol point to it in the constructor of your child class. */
	void ComputeFlatLocalVol();
	void TimeOnlyLocalVol();
	void ParametricLocalVol();
	void DupireTreeLocalVol();
	void ArrowDebewLocalVol();
	void SmallDimensionLocalVol();

	/** Use those methods if you write your own ComputeLocalVol() i between 0 and fNbSteps, j between fIndexMin and fIndexMax. */
	double GetLocalVol(int i, int j);
	void SetLocalVol(int i, int j, double vol);
	NSREnums::eVolatilityType GetVolType() const;

/** 6. Bare value (value of product if the option is not exercised). */
	typedef double	(CSRTrinomial::*BareValueType)(int i, double t) const;
	void SetBareValue(int i, double time); // calls this->*fBareValue to fill fCurrentBareValue
	BareValueType			fBareValue;    // =0 if the bare value is always 0
	double	ConvertibleBareValue(int i, double t) const;
	double  ORABareValue(int i, double t) const;

/** JMM 5/2 a generic optimized continuous computation of bare value : (use fCreditRisk). */
/** 7. Direct intervention in the tree. */
/** t==fDate[i] in days since 01/01/1904. */
	virtual bool Intervention(int i, double t);

#ifndef GCC_XML //or move struct definition outside of CSRTrinomial
	struct SSLocalDataForAmericanSmoothing{
		SSLocalDataForAmericanSmoothing(); 
		void Roll();

		_STL::vector<double> spot;
		_STL::vector<double> smooth_retro;
		_STL::vector<double> deri;
		double val_exercise_previous;
		double val_retropropagated_previous;
		
		bool stinemanInterpolation;
		double alpha,beta;
		
	};
#endif // GCC_XML

	struct SSAmericanSmoothing{
		bool call;
		double weight;
		double strike;
		int index;
		SSAmericanSmoothing() : call(true),weight(0.0),strike(0.), index(0) {;};
	};
	virtual void Intervention(int i,
							  int j,
							  /** t==fDate[i] */
							  double t,
							  /** forward==fForward0*pow(fUp,j) */
							  double forward,
							  /** spot==fNMU_a[i]*forward + fNMU_b[i] */
		                      double spot,
		                      /** square of local vol */
							  double local_vol,
							  /** probabilities pu=up move pd=down move */
							  double pu,
							  double pm,
							  double pd,
							  /** array size = fThickness. */
							  double val_u[],
							  double val_m[],
							  double val_d[],
							  double discount,
/** option[k] = discount*(pu*val_u[k] + pm*val_m[k] + pd*val_d[k]) + fCurrentBareValue, if there is no American exercise. */
    						  bool	exerciseable,
							  double *option,	// array size = fThickness
							  sophis::instrument::ePointColorType *pt);// array size = fThickness
	virtual void PostIntervention(int i,
								/** t==fDate[i] */
								  double t,
								  int	j_min,
								  int	j_max,
								  /** you can use option[j*fThickness+k] for j_min <= j <= j_max 0 <= k < fThickness */
								  double *option);

// 8. Delta and Gamma 'in the tree'.

	/** Delta and Gamma 'in the tree'.
	This method returns false if the Delta and Gamma cannot be extracted from the tree. In this case, GetValueDeltaGamma() returns a price but does not populate the values of *delta and *gamma. */
	virtual bool HasDeltaGammaInTree();

	/** Override this method if the default calculation of Delta/Gamma does not suit your requirements. In particular, this is the case for near-the-barrier options:
- option[0] = price at start point
- option[i*fThickness] = price at node i where -fStartingPoints <= i <= fStartingPoints. */
	virtual void DeltaGammaInTree(double * option, double & delta, double & gamma);


// 9. Spot price and Forward price

	/**
	Spot price and Forward price.
	Retrieve the spot value from the variable change spot=a(t1,t2)*SpotForward*exp(LogSpot)+b(t1,t2). */
	double GetSpotFromLogForward(double t1, double t2, double LogForward);

	/** converse function : retrieve the LogForward value from the variable change LogForward=(spot-b(t1,t2))/(a(t1,t2)*SpotForward). */
	double GetLogForwardFromSpot(double t1, double t2, double Spot);
	double GetLogForwardFromSpot(int DateIndex, double Spot) const;

    virtual double ForwardZeroCoupon(double t1, double t2) const;

	virtual void SpotForwardCoefsCompo(double t1, double t2, double * a, double *b, double *c);
	virtual void SpotForwardCoefs(double t1, double t2, double * a, double *b, double *c) const;
	
	/** Maturity is expressed in number of days from fToday. */
	virtual double GetVolatility(double strike, double maturity) const;

	/**	the index of the layer where the true option price lies
	*	this is fInBarrierLayer for a trinomial with "In" Barriers
	*	this is 0 otherwise
	*	@return the layer index between 0 and fThickness-1
	*/
	int GetTruePriceThickness() const;

protected:
/** Reserved, use GetLocalVol() and SetLocalVol() instead. */
	double *	fLocalVol;
	int			fLocalVol_width;
	int			fLocalVol_height;
	int			fLocalVol_offset;
	void		NewLocalVol(int width, int height, int offset); // also allocates fVolCache
	mutable int fCurrentTimeIndex;

#ifndef GCC_XML //or move struct definition outside of CSRTrinomial
	SSLocalDataForAmericanSmoothing *	fLocalDataForSmoothing;
#endif // GCC_XML
	_STL::vector<SSAmericanSmoothing>	fCallAndPutForSmoothing;
	_STL::vector<SSAmericanSmoothing>	fCallAndPutForSmoothingPrevious;


protected:
	double * fDate;
	/** Coefficients a b such that S = a[i]*F + b[i] at i-th time step. */
	double * fNMU_a;
	double * fNMU_b;
	/** Payoff for a call: Max(a[i]*F + b[i] - K, 0)/c[i]. */
	double * fNMU_c;
	/** Zero coupon from fToday to i-th time step. */
	double * fZC;
	/** space steps (used by PDE only). */
	double * fx;
	// t1, t2 in days since 01/01/1904
/**	Optimisation variable for linear value calculation
*/
	double fa,fb,fc,ft1,ft2;

protected:
	double fConvertibleBareValueValue;
	double fConvertibleBareValueTime;

	const market_data::CSRMarketData		*fParam;
	const sophis::instrument::CSRInstrument *fUnderlying;
	const sophis::instrument::CSROption		*fOption;
	market_data::CSRCreditRisk	*fCreditRisk;
//	double					fCreditSpread;
	NSREnums::eVolatilityType				fVolType;
	sophis::instrument::eSettlementType		fLivraison;
	long					fUnderlyingCode;
	long					fUnderlyingCurrency;
	long					fOptionCurrency;
	/** Convertible and swapped options. */
	long					fIssuerCode;
	long					fSeniority;
	double					fToday;
	double					fStartDate;
	long					fEndDate;
	/** For eBermudaStyle only. */
	long					fBermudaStartDate;
	/** to apply to risk-free rate. */
	double					fOverRate;
	double					fOverVolatility;
	bool					fPut;
	/** Forward price with maturity fEndDate. */
	double					fForward0;
	/** Spot price today. */
	double					fSpot0;
	/** Basis if start date in the past; Forward price with maturity fStartDate elsewhere. */
	double					fSpotBase0;
	/** For Compo options, spot of foreign exchange rate. */
	double					fFXrate0;
	double					fStrike;
	double					fStrikeForVolat;
	/** For IR Future Options */
	bool					fUnderlyingInHundredMinusRate;
	/** For Digital and Options in performance. */
	double					fNotional;
	double					fProportion;
	double					fParity;
	double					fMaxLocalVol;
	double					fAbsoluteMaxLocalVol;
	double					fAbsoluteMinLocalVol;
	long					fPremiumPaymentDate;
	long					fDeliveryDate;
	/** INVARIANT: fMaturity == fEndDate-fStartDate. */
	double					fMaturity;
	/** INVARIANT: fTimeStep == fMaturity/fNbSteps. */
	double					fTimeStep;
	int						fNbSteps;
	int						fThickness;
	int						fStartingPoints;
	double					fUp;
	int						fIndexMin;
	int						fIndexMax;
	/** INVARIANT: fIndexRange = fIndexMax-fIndexMin+1. */
	int						fIndexRange;
	sophis::instrument::eOptimisationType			fOptimizationType;
	sophis::instrument::eUnderlyingComputationType	fUcType;
	/** Value of cap clause, corrected of nominal for options in perf. */
	double					fCapValue;
	double					fFloorValue;
	double					fCurrentBareValue;
	double					fValRemboCall;
	double					fValRemboPut;
	bool					fUseCompo;
	double *				fCouponAcc;
	double *				fCouponPartialRedemption;
	double *				fRedemptionPartialRedemption;
	double *				fProbaPartialRedemption;
	bool					fIsConversionWithAccrued;

	// Barrier clauses
	int						fNbBarriers;
	SSBarrier2 *			fBarrier;
	int						fNbActiveBarriers;
	SSBarrier2 *			fActiveBarrier;
	SSBarrier2 *			fLastKnockInBarrier;
	/** Index of the layer of thick tree for "In barrier". */
	int						fInBarrierLayer;
	/** Index of the layer of thick tree for "Barrier with rebate". */
	int						fRebBarrierLayer;

	/** Chooser clause. */
	int								fChooserLayer;
	sophis::instrument::SSClause*	fChooserClause;
	bool							fActiveChooser;

	int								fNbBuyClauses;
	sophis::instrument::SSClause*	fBuyClause;
	int								fNbSellClauses;
	sophis::instrument::SSClause*	fSellClause;

	/** For Convertible bonds only. */
	int								fNbBearerPuts;
	sophis::instrument::SSClause*	fBearerPut;
	sophis::instrument::SSClause*	fActiveBearerPut;
	int								fNbIssuerCalls;
	sophis::instrument::SSClause*	fIssuerCall;
	sophis::instrument::SSClause*	fActiveIssuerCall;
	int								fNbParityChanges;
	sophis::instrument::SSClause*	fParityChange;
	int								fNbReset;
	sophis::instrument::SSClause*	fReset;
	double	*						fResetFactor;
	int								fIssuerCallWithoutAccrued;

	/** Intervention and Payment clauses. */
	int													fNbInterventionClauses;
	const sophis::instrument::CSRCoxTreeCustomisationClause	**fInterventionClause;
	int													fNbActiveInterventionClauses;
	sophis::instrument::CSRCoxTreeCustomisationClause	**fActiveInterventionClause;
	int													fNbPayoffClauses;
	const sophis::instrument::CSRPayOffClause			**fPayoffClause;
	mutable const sophis::instrument::CSRPayOffClause	*fActivePayoffClause;
/** JMM 1/3/02 To handle double type date (useful in PDE). */
	static double kErrorDates;
	static double kRoundingError;
	
private:	// do not use
	SPH_BEGIN_NOWARN_EXPORT
	_STL::vector<long> fIndexInterventionClause; 
	SPH_END_NOWARN_EXPORT

//	void AdjustProbasOut(double pu, double pm, double pd,
//						 double lamda,
//						 double& npu, double& npm, double& npd,
//						 double& alpha);
	double		GetResettedParity(double parity, int layer);
	double		fConstQuantoFactor;
	double		CallExpress(int n, int k, double vol, double *option);
	double		CallExpress2(double strike, double vol, double *option);
	int			fDirectionForDelta;

	/** Those functions evaluate the minumum and maximum strike. It is not beneficial to interpolate implied volatility above these values. They are selected such that 1% < Delta < 99% if Kmin < K < Kmax maturity in days since fToday. */
	int ChooseOptimalStrikeMin(double maturity) const;
	int ChooseOptimalStrikeMax(double maturity) const;

	static double kResizeCoeff;
	friend class CSRTrinomialFS;
	friend class math::CSRHighOrderPDE;
	friend class math:: PDETimeOnlyVolatility;

public : /** Accessor. */
	inline double	GetSpot()								const {return fSpot0;};
	inline int GetIndexRange()								const {return fIndexRange;}  ;
	inline int GetNbParityChanges()							const {return fNbParityChanges;};
	inline int GetNbBearerPuts()							const {return fNbBearerPuts;}  ;
	inline int GetNbIssuerCalls()							const {return fNbIssuerCalls;}  ;
	inline double GetCapValue()								const {return fCapValue;};
	inline double GetFloorValue()							const {return fFloorValue;};
	inline const sophis::instrument::SSClause* GetIssuerCall()	const {return fIssuerCall;};
	inline const sophis::instrument::SSClause* GetBearerPut()	const {return fBearerPut;};
	inline const sophis::instrument::SSClause* GetParityChange()const {return fParityChange;};
	inline double GetStrike()									const {return fStrike;};
	inline void SetParity(double Parity)					{fParity = Parity;};
	inline void SetParity()									{fParity = fOption->GetParity();};
	inline void SetProportion(double Proportion)			{fProportion = Proportion;};
	inline void SetProportion()								{fProportion = fOption->GetProportion();};
	inline void SetStrike(double Strike)					{fStrike = Strike;};
	inline void SetStrike()									{fStrike = fOption->GetStrikeInProduct();};
	inline const double GetStartDate()						{return fStartDate;};
	inline const double GetEndDate()						{return fEndDate;};
	inline void SetCreditRisk();
	inline market_data::CSRCreditRisk* GetCreditRisk()					{return fCreditRisk;};
	inline void SetCreditSpread()							{fCreditSpread = !fCreditRisk ? fParam->GetCreditSpread(fOption->GetCode(), market_data::diConvertibleBond, fEndDate) : 0;};
	inline double GetCreditSpread()							{return fCreditSpread;};
	inline const market_data::CSRMarketData * GetParam()					{return fParam;};
	inline double GetThickness()							const {return fThickness;};
	inline const sophis::instrument::CSROption*	 GetOption()const {return fOption;};
	inline double				GetPayoff(double Time, double Spot)		{return (this->*fPayoff)(Spot,Time);};
	inline bool					GetExercise(double Time)		{return (this->*fExercise)(Time);};
	inline double				GetSmoothPayoff(double spot, double forward, double strike, double sigma, double mat, double discount)
															{return (this->*fSmoothPayoff)(spot,forward,strike,sigma,mat,discount);};

	inline void SetDates(_STL::vector<double> &Dates)
	{
		fNbSteps = (int)Dates.size()-1;
		if (fDate)
			delete fDate;
		fDate = new double[fNbSteps+1];
		for (int i = 0;i<=fNbSteps;i++)
			fDate[i] = Dates[i];
	};

protected:


	friend class CSROptionTrinomial;

};

/** CSROptionTrinomial is a derivation of CSROption. The class uses CSRTrinomial (or one of its child classes) in its calculations. */
class SOPHIS_FINANCE CSROptionTrinomial : public virtual sophis::instrument::CSROption
{
public:
	typedef finance::CSRDefaultMetaModelOptionTrinomial DefaultMMClass;

	DECLARATION_OPTION(CSROptionTrinomial)
	CSROptionTrinomial(produit **h, bool initialiseRecomputeAll);

public:

	virtual const finance::CSRMetaModel * GetForceMetaModel() const;

	static CSROptionTrinomial* new_option_Trinomial(produit **h);
	virtual Boolean	AvailableCoxTreeGraphics() const;
	virtual Boolean	ValidInstrument() const;
	virtual void	CorrectDeltaBySmile(const market_data::CSRMarketData &param, sophis::CSRComputationResults& results) OVERRIDE;
	virtual void	GetModelName(char *nom) const;

	/** For compatibility with clauses of type CSRCoxTreeCustomisationClause. */
	virtual double	GetConversionValueInTree() const { return fConversionValueInTree; }
	virtual double	GetCallValueInTree() const {return fCallValueInTree; }
	virtual double	GetPutValueInTree() const {return fPutValueInTree; }
	virtual double	GetTriggerCallInTree() const {return fTriggerCallInTree; }
	virtual double	GetParityStockInTree() const {return fParityStockInTree; }
	virtual double	GetProportionDerivativeInTree() const { return fProportionDerivativeInTree; }
	virtual double	GetStrikeInTree() const {return fStrikeInTree; }
	virtual bool	GetIsExercableInTree() const {return fIsExercableInTree; }
	virtual	bool	DoTreeUpToDown() const { return fDoTreeUpToDown; }
	virtual	bool	DoFolioUpToDown() const { return fDoFolioUpToDown; }

	virtual void	SetConversionValueInTree(double item)		{fConversionValueInTree = item; }
	virtual void	SetCallValueInTree(double item)				{fCallValueInTree = item; }
	virtual void	SetPutValueInTree(double item)				{fPutValueInTree = item; }
	virtual void	SetTriggerCallInTree(double item)			{fTriggerCallInTree = item; }
	virtual	void	SetTreeUpToDown(bool item)					{fDoTreeUpToDown = item; }
    virtual void	SetParityStockInTree(double item)			{fParityStockInTree = item; }
    virtual void	SetProportionDerivativeInTree(double item)	{fProportionDerivativeInTree = item; }
    virtual void	SetStrikeInTree(double item)				{fStrikeInTree = item; }
    virtual void	SetIsExercableInTree(bool item)				{fIsExercableInTree = item;}
    virtual void	SetFolioUpToDown(bool item)					{fDoFolioUpToDown = item;}

	mutable double	fConversionValueInTree;
	mutable double	fCallValueInTree;
	mutable	double	fPutValueInTree;
	mutable double	fTriggerCallInTree;
	mutable double	fParityStockInTree;
	mutable double	fProportionDerivativeInTree;
	mutable double	fStrikeInTree;
	mutable bool	fIsExercableInTree;
	mutable bool	fDoTreeUpToDown;
	mutable bool	fDoFolioUpToDown;

	virtual bool IsSmoothGreeks() const;

	virtual void SetMinMaxImpliedVolatilityBound(double vol_0, double & min, double& max) const;

private:

};

class CSRTrinomialForwardStart : public CSROptionTrinomial
{
	DECLARATION_OPTION(CSRTrinomialForwardStart)
public:
	virtual const finance::CSRMetaModel * GetForceMetaModel() const OVERRIDE;
	virtual Boolean	AvailableCoxTreeGraphics() const OVERRIDE;
	virtual Boolean	ValidInstrument() const OVERRIDE;
};

}	//	namespace finance

}	//	 namespace sophis


SPH_EPILOG

#endif // _SphTrinomial_H_
