/*
File:		SphVaRBacktest.h

Contains:	Class for the handling backtesting of the VaR.

Copyright:	2007 Sophis.

*/

/*! \file SphVaRBacktest.h
\brief Class for the handling backtesting of the VaR.
*/
#pragma once

#ifndef SPH_VaR_BACKTEST_H
#define SPH_VaR_BACKTEST_H

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphInc/SphMath.h"

#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_VAR_BACKTEST(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, CSRVaRBacktest) 
#define CONSTRUCTOR_VAR_BACKTEST(derivedClass)		
#define WITHOUT_CONSTRUCTOR_VAR_BACKTEST(derivedClass)
#define	INITIALISE_VAR_BACKTEST(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)


/** Base Class for Value at Risk backtests in toolkit.
@since 6.2
*/
SPH_PROLOG
namespace sophis
{
	namespace math
	{

		class SOPHIS_MATH CSRVaRBacktest
		{
		public:
			/**
			* Trivial constructors
			*/
			CSRVaRBacktest();
			CSRVaRBacktest(const CSRVaRBacktest& source);
			virtual ~CSRVaRBacktest();

			/** Returns a test statistic calculated from a PNL and VaR time series. Derived classes will implement
			*	the concrete statistical formulas.
			*	@param pnls is the time series of pnls
			*	@param vars is the time series of values at risk
			*	@param varThreshold is the probability threshold defining the value at risk (between 0.0 and 1.0)
			*	@return the statistic value
			*	@since 6.2
			*/
			virtual double Statistic(_STL::vector<double>& pnls, _STL::vector<double>& vars, double varThreshold) const = 0;


			/** Returns a test statistic calculated from a PNL and VaR time series. Derived classes will implement
			*	the concrete statistical formulas.
			*	@param confidenceLevel is the probability that Statistic will fall into the confidence interval (between 0.0 and 1.0)
			*	@param varThreshold is the probability threshold defining the value at risk (between 0.0 and 1.0)
			*	@param dayCount is the number of days when the VaR was computed
			*	@param confLow returns the lower bound of the confidence interval
			*	@param confHigh returns the upper bound of the confidence interval
			*	@return nothing
			*	@since 6.3
			*/
			virtual void ConfidenceInterval(double confidenceLevel, double varThreshold, unsigned int dayCount, double& confLow, double& confHigh) const = 0;
			
			
			virtual CSRVaRBacktest* Clone() const = 0; // used by the prototype

			typedef sophis::tools::CSRPrototype<CSRVaRBacktest, const char*, sophis::tools::less_char_star> prototype;

			static prototype& GetPrototype();

			/**
			 *  Get  the list of available VaR Backtest by name.
			 *  This method is needed for the DotNet toolkit, 
			 *  as prototypes are not directly accessible through it.
			 */
			static _STL::vector<_STL::string> GetAvailableVaRBacktest();

			/** Get the VaR Backtest from the prototype by name.
			 * @param name VaR Backtest name.
			 * @return VaR Backtest object or 0 if out of bounds. */
			static const CSRVaRBacktest* GetVaRBacktest(_STL::string& name);
			
		};

	}
}
SPH_EPILOG
#endif // SPH_VaR_BACKTEST_H
