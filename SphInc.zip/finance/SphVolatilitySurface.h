/*
 	File:		SphVolatilitySurface.h

 	Contains:	Interface to describe a parametric model

 	Copyright:	� 2012 Sophis.

*/

/*! \file SphVolatilitySurface.h
	\brief An interface for describing a parametric model
*/

#pragma once

#ifndef _SPH_VOLATILITY_SURFACE_H_
#define _SPH_VOLATILITY_SURFACE_H_


#include "SphInc/SphMath.h"
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/SphMatrix.h"
#include "SphInc/finance/SphSmileModel.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)

#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(push)
#	pragma warning(disable:4103) // used #pragma pack to change alignment
#endif



#if (defined(WIN32)||defined(_WIN64))
#	pragma warning(pop)
#endif

#if (defined(WIN32)||defined(_WIN64))

#else
#	include "SphInc/market_data/SphVolatility.h"
#endif

/** 
*     Macro declaration for insurance prototyped classes inheriting from an abstract class
@version 6.0
*/    
#define DECLARATION_VOLATILITY_NAMED_OBJECT(className) \
	  public: static _STL::string  className::sRegistrationName; \
	  public: virtual const _STL::string & GetName() const {return className::sRegistrationName;}; \


#define DECLARATION_PROTOTYPE_NAMED_OBJECT(derived, baseAbstractClass) \
					DECLARATION_VOLATILITY_NAMED_OBJECT(derived) \
					DECLARATION_PROTOTYPE_WITHOUT_COPY_CONSTRUCTOR(derived, baseAbstractClass)

// Macro to define volatility object identifier : must be initialised in cpp file out of the entry point.
#define INITIALISE_OBJECTNAME(className, name) _STL::string className::sRegistrationName = name;


// Macro instantiation for named object classes
#define INITIALISE_PROTOTYPE_NAMED_OBJECT(className) INITIALISE_PROTOTYPE(className, className::sRegistrationName.c_str())



/** 
*     Macro declaration for volatility surfacve classes.
@version 6.0
*/    
#define DECLARATION_VOLATILITY_SURFACE(derived) DECLARATION_PROTOTYPE_NAMED_OBJECT(derived, sophis::finance::CSRVolatilitySurface)

/** 
*     Macro declaration for ForwardPriceCalculator classes.
@version 6.0
*/    
#define DECLARATION_FORWARDPRICECALCULATOR(derived) DECLARATION_PROTOTYPE_NAMED_OBJECT(derived, sophis::finance::CSRForwardPriceCalculator)

/** 
*     Macro declaration for MoneynessLevelCalculator classes.
@version 6.0
*/    
#define DECLARATION_MONEYNESSLEVELCALCULATOR(derived) DECLARATION_PROTOTYPE_NAMED_OBJECT(derived, sophis::finance::CSRMoneynessLevelCalculator)





namespace sophis	{
	namespace finance	{
		class CSRVolatilitySurface;
		class SOPHIS_MATH CSRForwardPriceCalculator
		{
		public: 
			virtual ~CSRForwardPriceCalculator();
			
			/** Get the drift of the forward price at maturity {@param maturity}.
			*  Compute the drift as the log variation of the forward {@link CSRForwardPriceCalculator::GetForwardPrice} for one day, normalized in an annual basis (implicit 365F convention)
			@param maturity is the maturity in day

			@return the drift of the forward price at this maturity
			@since 6.3.3
			*/
			virtual double GetDrift(double maturity) const;
			
			/** Get the forward price at maturity {@param maturity} witch must be taken into account in the definition of the volatility
			@param maturity is the maturity in day

			@return the forward price at maturity {@param maturity} witch must be taken into account in the definition of the volatility
			@since 6.3.3
			*/
			virtual double GetForwardPrice(double maturity) const = 0;

			/** Get the spot witch must be taken into account in the definition of the volatility
			@return the spot witch must be taken into account in the definition of the volatility
			@since 6.3.3
			*/
			virtual double GetSpot() const = 0;

			/**	Get the forward for the maturity {@param maturity} and a reference value {@param spotLevel} at a null maturity
			@param spotLevel is a reference value at a null maturity
			@param maturity is the maturity in day

			@return the forward value for this maturity and spot value
			@since 6.3.3
			*/
			virtual double GetForwardForVolatility(double spotLevel,double maturity) const = 0;

			/*Abstract method used for the prototype
			Normally built automatically by the macro DECLARATION_FORWARDPRICECALCULATOR.
			@since 6.3.3
			*/
			virtual const _STL::string & GetName() const = 0;

			/** Store CSRForwardPriceCalculator data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRForwardPriceCalculator with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRForwardPriceCalculator::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRForwardPriceCalculator initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);

			/** Defines the prototype with the key const char *.
			*/
			typedef tools::CSRPrototype<CSRForwardPriceCalculator, const char *, tools::less_char_star> prototype;

			/** Gives the address of the singleton containing all the triggers.
			 @see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

			/** Abstract clone method required by CSRPrototype.
			 Normally built automatically by the macro DECLARATION_PROTOTYPE_NAMED_OBJECT.
			 */
			virtual CSRForwardPriceCalculator* Clone() const = 0;
		};
		
		/**	Class to get a moneyness level according to two properties : 
		*	- fMoneynessType which defines the function of the moneyness with maturity: flat or with a growing rate equal to the forward drift
		*	- fSpotLevel which determine the moneyness for a null maturity
		*	fCallBack is a callback to the volatility surface object. It allow to reach the forward price calculator object
		*/
		class SOPHIS_MATH CSRMoneynessLevelCalculator
		{
		public:
			enum eMoneynessType
			{
				eSpot =0, //the moneyness is flat with maturity
				eForward, //the moneyness has a growing rate equal to the forward drift
				eAtm
			};
			CSRMoneynessLevelCalculator();
			CSRMoneynessLevelCalculator(const CSRMoneynessLevelCalculator &ref);
			~CSRMoneynessLevelCalculator();
			
			/**	Initialization of the moneyness calculator. 
			@param moneynessType is the moneynessType to be set
			@param spotLevel is the spotLevel to be set

			@see fMoneynessType and fSpotLevel
			@since 6.3.3
			*/
			void InitializeMoneynessCalculator(eMoneynessType moneynessType, double spotLevel);

			/**	Set the callback to the volatilitySurface object.
			@param volSurface is the the callback to the volatilitySurface object.
			@since 6.3.3
			*/
			inline void SetCallBack(CSRVolatilitySurface* volSurface){fCallBack = volSurface;};
			
			/**	Get the forward price calculator attached to the callback CSRVolatilitySurface fCallback
			@return he forward price calculator attached to the callback CSRVolatilitySurface fCallback
			@since 6.3.3
			*/
			CSRForwardPriceCalculator* GetForwardPriceCalculator() const;
			
			/**	Get the moneyness level at the maturity {@param maturity}. Main method of the class.
			@param maturity is the maturity in day
			@param timeDerivative : output, is the time derivative of the moneyness level.
			@return the moneyness level at the given maturity
			@since 6.3.3
			*/
			double GetMoneynessLevel(double maturity, double& timeDerivative)const;

			/**	Get the moneyness type fMoneynessType. 
			@return the moneyness type fMoneynessType. 
			@since 6.3.3
			*/
			eMoneynessType GetMoneynessType() const;

			/**	Get the spot level (reference value at null maturity) fSpotLevel. 
			@return the spot level (reference value at null maturity) fSpotLevel. 
			@since 6.3.3
			*/
			double GetSpotLevel() const;
			
			/** Store CSRMoneynessLevelCalculator data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			void	GetData(sophis::tools::CSRArchive& archive) const;
			
			/** Initialise the CSRMoneynessLevelCalculator with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRMoneynessLevelCalculator::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRMoneynessLevelCalculator initialization.
			*/
			void	SetData(const sophis::tools::CSRArchive& archive);
			
		protected:
			double fSpotLevel; //fSpotLevel which determine the moneyness for a null maturity
			eMoneynessType fMoneynessType; //defines the function of the moneyness with maturity: flat or with a growing rate equal to the forward drift
			CSRVolatilitySurface* fCallBack;
		};
		

		/**
		* Generic class handling local volatility diffusion parameters computed by using Dupire's formula.
		*/
		class SOPHIS_MATH CSRVolatilitySurface
		{
		public:
			/**
			* Constructor
			*/
			CSRVolatilitySurface();

			CSRVolatilitySurface(const CSRVolatilitySurface& volatilitySurface);
			
			virtual void InitializeVolatilitySurface(const CSRVolatilitySurface& volatilitySurface);
			/**
			* Destructor
			*/
			virtual ~CSRVolatilitySurface();

			/** Method to compute implied volatility.
			@param maturity is the absolute maturity in day.
			@param strike is the strike.
			
			@return implied volatility.
			*/

			double GetAbsoluteVolatility(	double	maturityInDay, 
											double	strike) const;

			/** Method to compute the local volatility. As it use Dupire's formula there is no need to overload this method. One must overload
			{@link GetImpliedVolatility} instead.
			
			@param maturityStartInYear is the absolute maturity in day.
			@param spot	is the spot at beginning of the time step,
			@param localVolDerivative is optional and return the local volatility derivative versus strike if it is filled,

			@return local volatility for a given time step.
			*/
			double GetLocalVolatility(	double  maturityStartInDay,
										double	spot,
										double *localVolDerivative = NULL,
										double *maturityEndInDay =  NULL) const;
			

			/** Defines the prototype with the key const char *.
			*/
			typedef tools::CSRPrototype<CSRVolatilitySurface, const char *, tools::less_char_star> prototype;

			/** Gives the adress of the singleton containing all the triggers.
			 @see tools::CSRPrototype
			*/
			static prototype & GetPrototype();

			/** Abstract clone method required by CSRPrototype.
			 Normally built automatically by the macro DECLARATION_VOLATILITY_SURFACE.
			 */
			virtual CSRVolatilitySurface* Clone() const = 0;
			
			
			/** return the name attached to this class in the protype initialized by using macro INITIALISE_OBJECTNAME 
				@return the key attached to this class in the protype map
				@since 6.3.3
			*/
			_STL::string	GetVolatilitySurfaceId() const;

			/** Virtual method to access identifier of volatility surface type. No need to implement in overloaded class, 
			it will be done by using macro DECLARATION_VOLATILITY_SURFACE.
			@return the identifier attached to this class
			@since 6.3.3
			*/
			virtual const _STL::string & GetName() const = 0;
			
			/** Store CSRVolatilitySurface data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRVolatilitySurface with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRVolatilitySurface::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRVolatilitySurface initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
			
			/** Initialization of the volatility surface object. Optimization called before the MC simulations on server side.
			*/
			virtual void InitializeOptimization();
			
			/** Get the forward price at maturity {@param maturity} witch must be taken into account in the definition of the volatility.
				Use the forward calculator object fForwardPriceCalculator.
				@param maturityInDay is the maturity in day

				@return is the forward price
				@since 6.3.3
			*/
			double GetForwardPrice(double maturityInDay)const;

			/** Get the drift at maturity {@param maturity} witch must be taken into account in the definition of the volatility.
				Use the forward calculator object fForwardPriceCalculator.
				@param maturityInDay is the maturity in day

				@return the drift expressed in an annual basis (implicit 365F convention)
				@since 6.3.3
			*/
			double GetDriftAtMaturity(double maturityInDay)const;

			/** Get the moneyness level at maturity {@param maturity} and its time derivative.
				Use the moneyness calculator object fMoneynessLevelCalculator.
				@param maturityInDay is the maturity in day
				@param timeDerivative (output) is the time derivative of the moneyness level (zero for a flat moneyness, equal to the forward drift otherwise)

				@return the moneyness level
				@since 6.3.3
			*/
			double GetMoneynessLevel(double maturityInDay, double& /*output*/ timeDerivative)const;
			
			/** Get the forward price calculator object
			@return the forward price calculator object
			@since 6.3.3
			*/
			inline CSRForwardPriceCalculator* GetForwardPriceCalculator() {return fForwardPriceCalculator;};

			/** Set the forward price calculator object
			@param the forward price calculator object to be stored
			@since 6.3.3
			*/
			virtual void SetForwardPriceCalculator(CSRForwardPriceCalculator* forwardCalculator);

			/*	Initialize the CSRMoneynessLevelCalculator object. 
			@param moneynessType is the moneynessType to be set
			@param spotLevel is the spotLevel to be set

			@see CSRMoneynessLevelCalculator::fMoneynessType and CSRMoneynessLevelCalculator::fSpotLevel for more details
			@since 6.3.3
			*/
			virtual void InitializeMoneynessCalculator(CSRMoneynessLevelCalculator::eMoneynessType moneynessType, double spotLevel);
			

			/** Method to compute implied volatility. By the way the method must fill the first derivative versus time and the first and second order
				derivatives versus strike needed to compute Dupire's formula.
			
			@param maturityInDay is the absolute maturity in day.
			@param strike is the strike.
			
			@param timeDerivate is first order derivative versus time.
			@param firstStrikeDerivative is first order derivative versus strike.
			@param secondStrikeDerivative is second order derivative versus strike.

			@return implied volatility.
			*/
			virtual double GetImpliedVolatilityAndDerivatives(	double			maturityInDay, 
																double			strike,
																/*out*/ double	*timeDerivative,
																/*out*/ double	*firstStrikeDerivative,
																/*out*/ double	*secondStrikeDerivative) const = 0;
			/**
			* If true the derivative in local volatility calculation will be done by finite difference
			*/
			virtual void SetFiniteDifference(const bool useFiniteDifference);
		protected:
			/**
			* Get first, second, and third strike derivatives, time derivative, and strike-time crossed derivative of implied volatility by finite difference  
			* (Five-point stencil for strikes derivatives, +classical finite difference for time derivative  + 2 other point for crossed derivative) 
			* used by predictor-corrector algorithme, called by {@link }
			@param maturityInDay is the absolute maturity in day.
			@param strike is the strike.

			@param firstStrikeDerivative is first order derivative versus strike.
			@param secondStrikeDerivative is second order derivative versus strike.
			@param thirdSrikeDerivative is third order derivative versus strike.
			@param timeDerivate is first order derivative versus time. 
			@param crossTimeStrikeDerivative is the crossed derivative versus time and strike

			@return the implied volatility
			@since 6.3.3
			*/
			double	GetDerivatives(double maturityInDay, double strike,double& firstStrikeDerivative, double& secondStrikeDerivative, double& thirdSrikeDerivative,double& timeDerivative, double &crossTimeStrikeDerivative) const;
			
			/**
			* Get the time derivative of implied volatility by finite difference 
			@param maturity is the maturity in day
			@param strike is the strike, it must be an absolute value
			@return the implied volatility time derivative
			@since 6.3.3
			*/
			double	GetTimeDerivative(double maturity, double strike) const;
			
			/**
			* Get first and second strike derivatives of implied volatility by finite difference and return the implied vol
			@param maturity is the maturity in day
			@param strike is the strike, it must be an absolute value
			@param firstStrikeDerivative is the first order derivative of implied vol versus strike 
			@param secondStrikeDerivative is the second order derivative of implied vol versus strike

			@return the implied volatility
			@since 6.3.3
			*/
			double	GetStrikeDerivatives(double maturity, double strike,double& firstStrikeDerivative, double& secondStrikeDerivative) const;
			
			/** Return true it the time and strike derivative in Dupire formula are calculated by finite difference
			*   If false exact formula are used in parametric case
			*/
			bool FiniteDifference()const{ return fUseFiniteDifference;} ;

			

			CSRForwardPriceCalculator* fForwardPriceCalculator;
			CSRMoneynessLevelCalculator* fMoneynessLevelCalculator;
			bool fUseFiniteDifference;
		};


		/**
		*	Generic class handling local volatility defined by a list of smile CSRSmileModel at different maturity
		*	and a rule of interpolation in time between smiles.
		*/
		class SOPHIS_MATH CSRVolatilitySurfaceTermStructure : public sophis::finance::CSRVolatilitySurface
		{
		public:
			/**
			* Constructor.
			*/
			CSRVolatilitySurfaceTermStructure();
			
			CSRVolatilitySurfaceTermStructure(const CSRVolatilitySurfaceTermStructure& dupireTermStructure);

			virtual void InitializeVolatilitySurface(const CSRVolatilitySurface& volatilitySurface);
			/**
			* Destructor.
			*/
			virtual ~CSRVolatilitySurfaceTermStructure();
			
			/** Initialize global parameters of the CSRVolatilitySurfaceTermStructure object. 
			*	@See fWithTimeExtrapolation, fTimeInterpolationRule, fVolatilityStartDate
			@since 6.3.3
			*/
			void Initialize(bool withTimeExtrapolation, short timeInterpolationRule, double volatilityStartDate);


			/** Method to compute implied volatility. By the way the method must fill the first derivative versus time and the first and second order
				derivatives versus strike needed to compute Dupire's formula.
			
			@param maturityInDay is the absolute maturity in day.
			@param strike is the strike.
			
			@param timeDerivate is first order derivative versus time.
			@param firstStrikeDerivative is first order derivative versus strike.
			@param secondStrikeDerivative is second order derivative versus strike.
			

			@return implied volatility.
			*/
			virtual double GetImpliedVolatilityAndDerivatives(	double			maturityInDay, 
																double			strike,
																/*out*/ double	*timeDerivative,
																/*out*/ double	*firstStrikeDerivative,
																/*out*/ double	*secondStrikeDerivative) const;

			/**	
				@param nth is the index of the smile to be extracted
				@return the Nth smile
				@since 6.3.3
				@See {@link CSRSmileForwardInterpolation}
			*/
			CSRSmileForwardInterpolation* GetNthSmile(int nth);
			

			
			/*************object construction******/
			/**
				Set up the number of smile in the volatility surface.
				@param smileCount is the size of the smile list to be created
				@since 6.3.3
			*/
			void SetSmileNumber(size_t smileCount);
			
			/** Method called on server side just after {@link CSRDiffusionParameter::SetData} in order to allow some optimisation.
				Here it is used to initialize fMaturityMap in order to make quick temporal interpolation.
			*/
			virtual void InitializeOptimization();

			/** factory to instanciate a new CSRSmile.
			@return a new CSRSmile.
			*/
			virtual CSRSmileForwardInterpolation* new_CSRSmile() const = 0;


			/*************Archive*******************/
			/** Store CSRVolatilitySurfaceTermStructure data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;


			/** Initialise the CSRVolatilitySurfaceTermStructure with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRVolatilitySurfaceTermStructure::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRVolatilitySurfaceTermStructure initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
		

		protected :

			/** Method to compute parameters needed by Dupire's formula.

			@param maturity is the absolute maturity in year at which we want to compute local volatility.
			@param strike is the strike equal to the spot at which we want to compute local volatility.
			@param forward is the forward price at this maturity.
			@param maturityMin is the closest maturity lower than the maturity at which we want to compute local volatility.
			@param volMin is the implied volatility of the option with a maturity equal to maturityMin and the same moneyness.
			@param d1Min is the first order derivative versus strike of the option with a maturity equal to maturityMin and the same moneyness.
			@param d2Min is the second order derivative versus strike of the option with a maturity equal to maturityMin and the same moneyness.
			@param maturityMax is the closest maturity greater than the maturity at which we want to compute local volatility.
			@param volMax is the implied volatility of the option with a maturity equal to maturityMax and the same moneyness.
			@param d1Max is the first order derivative versus strike of the option with a maturity equal to maturityMax and the same moneyness.
			@param d2Max is the second order derivative versus strike of the option with a maturity equal to maturityMax and the same moneyness.
			@param derivateR is the derivative of the linear weight, it is equal to 1/(maturityMax - maturityMin).

			@return linear weight equal to (maturity - maturityMin)/(maturityMax - maturityMin).
			*/
			double GetProportionBetweenPoints(	double	maturity,
												double	strike,
												double	forward,
												double& maturityMin,
												double& volMin,
												double* d1Min,
												double* d2Min,
												double& maturityMax, 
												double& volMax,
												double* d1Max,
												double* d2Max,
												double& derivateR) const;
			
			/**
			* Method to fill maturity vector with all the smiles maturities used to define volatility surface.
			@param maturities is the vector of smiles maturity in years filled by the method. 
			@since 6.3.3
			*/
			void FillMaturityMap(/*out*/ _STL::vector<double>& maturities) const;
			//---------------------------------------------------------------------

			/**
			True if the volatility surface must be extrapolated before first smile and after last smile, false otherwise.
			Its value come from the preference specified for volatility interpolation in Risque.
			*/
			bool	fWithTimeExtrapolation;

			/**
			ID to define the temporary interpolation method. The id are the same as in enum {@link market_data::eVolInterpolationMethod}.
			Its value come from the preference specified for volatility interpolation in Risque.
			*/
			short	fTimeInterpolationRule;

			/** 
			Absolute startDate for the volatility surface. It is needed when temporary interpolation is done in variance.
			Its value come from the preference specified for volatility interpolation in Risque.
			*/
			double	fVolatilityStartDate;
			
			/** Map to get the index of a smile from its maturity                                                                    
			*/
			_STL::map<double,int> fMaturityMap;

			/**	List of smile object. 
			@since 6.3.3
			@ See CSRSmileForwardInterpolation
			*/
			_STL::vector<CSRSmileForwardInterpolation*> fSmiles;

		};
		

		class SOPHIS_MATH CSRVolatilitySurfaceParametricData
		{
		public:
			CSRVolatilitySurfaceParametricData();
			CSRVolatilitySurfaceParametricData(const CSRVolatilitySurfaceParametricData& volatilitySurface);
			void InitializeParametricData(const CSRVolatilitySurfaceParametricData& volatilitySurface);
			~CSRVolatilitySurfaceParametricData() ;
			
			/** Initialize the CSRParametricVolatilityData object. A parametric volatility is defined by two matrix of parameters, for atm and skew parameters.
			* Each row correspond to a maturity. The number of row and the maturities of both matrix can be different. (So that this class can't heritate from CSRVolatilitySurfaceTermStructure)
			* The vectors {@param maturity_ATM} and {@param maturity_Smiles} define the maturities associated rescpectiveley with the row of {@param volatilityATM_Y} and {@param smile_Y}.
			@param 

			@return 
			@since 6.3.3
			*/
			void InitializeParametricData(	const _STL::vector<double>							&maturity_ATM,
											const boost::numeric::ublas::matrix<double>	&volatilityATM_Y,
											const _STL::vector<double>							&maturity_Smiles,
											const boost::numeric::ublas::matrix<double>	&smile_Y);

			enum eATMorSkew {
				eVolATM,
				eVolSkew
			};

			/** Get the linear interpolation of ATM or Skew parameters for a given maturity. 
			Before the first point or after the last one extrapolation is flat in the parameters
			//the output verifies maturity1 <= maturity < maturity2
			@param paramType precise if you want to interpolate ATM or Skew parameters
			@param maturity is the given maturity for which you want to get the interpolated parameters
			@parameters_array are the interpolated parameters
			@param_deriv are the time derivative (so linear slopes) of interpolated parameters. It can be null if this output isn't used

			@output is the ratio maturity-maturity1/(maturity2-maturity1) or NOTDEFINED (if there is no point or only 1)**/
			double GetLinearInterpolation(	eATMorSkew					paramType,
											double						maturity,
											/*out*/_STL::vector<double>	&parameters_array,
											/*out*/_STL::vector<double>	*param_deriv) const;
			
			
			/** Extract maturities and indexes in the parameter matrix witch surround the maturity {@param maturity}. 
			*	It can be asked for the Atm or Skew parameters matrix {@param paramType} stored in CSRVolatilitySurfaceParametricData
			*	It allows to interpolate the parameters after extracting the parameters at both indexes.
			@param paramType : choice eVolATM if you want to extract parameters from the ATM parameters matrix, eVolSkew otherwise
			@param maturity  : the maturity in day at witch you want to interpolate parameters
			@param lower_index : the index of the row of parameters which maturity is the greatest of maturities preceding param maturity
			@param upper_index : the index of the row of parameters which maturity is the lowest of maturities following param maturity
			@param lower_maturity : is the maturity corresponding to the row of parameters indexed by lower_index
			@param upper_maturity : is the maturity corresponding to the row of parameters indexed by upper_index
			@param flatInterpolation : if true, extrapolation before the first and after the last maturities will be flat. 
			If false, the lower and upper index will be the first two (resp. last two) to extrapolate before (resp. after) the first (resp. last) maturity.

			@return is the ratio maturity-maturity1/(maturity2-maturity1) or NOTDEFINED (if there is no point or only 1)
			@since 6.3.3
			*/
			double GetParametersForInterpolation(	eATMorSkew		paramType,
													double			maturity,
													/*out*/int		&lower_index,
													/*out*/int		&upper_index,
													/*out*/double	&lower_maturity,
													/*out*/double	&upper_maturity,
													bool			flatInterpolation) const;
			
			/**	Get the maturity of the last set of ATM parameters (corresponding to the last row of the ATM parameters matrix)
			@return the maturity of the last set of ATM parameters (corresponding to the last row of the ATM parameters matrix)
			@since 6.3.3
			*/
			double GetLastMaturity() const;
			
			/** Get the number of row in the ATM or Skew parameters matrix
			@param eVolATM if you want to count the number of row of the ATM parameters matrix, eVolSkew otherwise
			@return the number of row in the choosen matrix
			@since 6.3.3
			*/
			int PointCount(eATMorSkew ATMorSkew) const;

			/** Get the number of parameters in a set of skew parameters (corresponding to the number of column in the Skew matrix)
			@return the number of parameters in a set of skew parameters (corresponding to the number of column in the Skew matrix)
			@since 6.3.3
			*/
			int GetSkewCurvesCount() const;

			/** Extract the nth set of Atm Parameters.
			@param index is the number of the extracted row of parameters
			@param parameters_array : the set of Atm Parameters.
			@since 6.3.3
			*/
			void GetATMVolatilityNthPoint(size_t index, _STL::vector<double> &parameters_array) const;
			
			/** Extract the nth set of Skew Parameters.
			@param index is the number of the extracted row of parameters
			@param parameters_array : the set of Skew Parameters.
			@since 6.3.3
			*/
			void GetSkewNthPoint(size_t index, _STL::vector<double> &parameters_array) const;
			
			/** Extract a parameter in the ATM or Skew matrix at a intersection of row and column
			@param ATMorSkew precises in which matrix of parameters the parameter must be extracted
			@param row is the row of the extracted parameter
			@param column is the column of the extracted parameter
			@return is the extracted parameter
			*/
			double GetParam(eATMorSkew  ATMorSkew,int row, int column) const;

			/** Set a parameter in the ATM or Skew matrix at a given intersection of row and column
			@param ATMorSkew precises in which matrix of parameters the parameter must be set
			@param row is the row of the extracted parameter
			@param column is the column of the extracted parameter
			@param val is the value to be set
			*/
			void SetParam(eATMorSkew  ATMorSkew,int row, int column, double val);

			/** Store CSRVolatilitySurfaceParametricData data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/** Initialise the CSRVolatilitySurfaceParametricData with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRVolatilitySurfaceParametricData::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRVolatilitySurfaceParametricData initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);

		protected:
			/** Absolute maturity map (in days) for which we have ATM data paramaters.
				Second member is the index used for optimisation.
			*/
			_STL::map<double, int>		fMaturityMapATM;
			
			/** Matrix to describe the parameters of the volatility at the monney.
			- the row count is the size of fMaturityMapATM
			- the column count is defined by the parametric model {@link CSRVolatilitySurfaceParametricFactory::GetVolatilityATMCurvesCount}
			*/
			boost::numeric::ublas::matrix<double>	fVolatilityATM;

			/** Absolute maturity map (in days) for which we have smile parameters.
				Second member is the index used for optimisation.
			*/
			_STL::map<double, int>		fMaturityMapSmile;

			/** Matrix to describe the parameters of the smiles.
			- the row count is the size of fMaturityMapSmile
			- the column count is defined by the parametric model {@link CSRVolatilitySurfaceParametricFactory::GetSkewCurvesCount}
			*/
			boost::numeric::ublas::matrix<double>	fSmileParam; 
		};

		class SOPHIS_MATH CSRVolatilitySurfaceParametric : public sophis::finance::CSRVolatilitySurface
		{
		public:
			/** Constructor.
			*/
			CSRVolatilitySurfaceParametric();

			CSRVolatilitySurfaceParametric(const CSRVolatilitySurfaceParametric &vol);

			virtual void InitializeVolatilitySurface(const CSRVolatilitySurface& volatilitySurface);

			/** Destructor.
			*/
			virtual ~CSRVolatilitySurfaceParametric();

			void Reset();

			/** Method to compute implied volatility. By the way the method must fill the first derivative versus time and the first and second order
				derivatives versus strike needed to compute Dupire's formula.
			
			@param maturityInDay is the absolute maturity in day.
			@param strike is the strike.
			
			@param timeDerivate is first order derivative versus time.
			@param firstStrikeDerivative is first order derivative versus strike.
			@param secondStrikeDerivative is second order derivative versus strike.
			

			@return implied volatility.
			*/
			virtual double GetImpliedVolatilityAndDerivatives(	double			maturityInDay, 
																double			strike,
																/*out*/ double	*timeDerivative,
																/*out*/ double	*firstStrikeDerivative,
																/*out*/ double	*secondStrikeDerivative) const;

			virtual CSRSmileVolParametric* new_CSRSmile() const = 0;
			virtual CSRSmileVolParametric* new_CSRSmile(const CSRSmileVolParametric* smile) const = 0;
			void InitializeSmileMap(const CSRVolatilitySurfaceParametric &vol);
			/** Store CSRVolatilitySurfaceParametric data in an archive {@link sophis::tools::CSRArchive}. 
			*	This method is called on client side.
			*
			*	@param archive is the archive storing data we want to send on server side.
			*/
			virtual void	GetData(sophis::tools::CSRArchive& archive) const;

			/** Initialise the CSRVolatilitySurfaceParametric with the data stored in an archive {@link sophis::tools::CSRArchive}.
			*	This method is called on server side and must be coherent with {@link CSRVolatilitySurfaceParametric::GetData}.
			*
			*	@param archive is the archive storing the data needed for CSRVolatilitySurfaceParametric initialization.
			*/
			virtual void	SetData(const sophis::tools::CSRArchive& archive);
		
			virtual bool IsWithVolatilitySmile() const;

			CSRVolatilitySurfaceParametricData fParametricData;

		protected:
			mutable _STL::map<double,CSRSmileVolParametric*> fSmile;
		friend class CSRSmileModel;
		};

		

	}
}
#endif
