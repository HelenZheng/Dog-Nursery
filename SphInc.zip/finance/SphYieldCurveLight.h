/*
*    File:      %FILE_BASE%.%FILE_EXT%
*
*    Contains:   This class implement quick and light zero coupon computation. It is intended to be sent 
				on server side of New Monte Carlo simulation to discount cash flow.
*
*    Copyright:  c 2007 Sophis.
*
*/
#ifndef ____SphYieldCurveLight_H__
#define ____SphYieldCurveLight_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#include "SphTools/SphArchive.h"
#include "SphInc/SphMath.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)

/** Declaration macro for copulas.

@version 6.0
*/
#define DECLARATION_YIELDCURVELIGHT_SERVER(derived)		DECLARATION_PROTOTYPE(derived, sophis::finance::CSRYieldCurveLight)

/** Instantiation macro for copulas.

@version 6.0
*/
#define INITIALISE_YIELDCURVELIGHT_SERVER(className, name)	INITIALISE_PROTOTYPE(className, name)

SPH_PROLOG
namespace sophis {
	namespace  finance{

		//------------------------------------------------------------------------------
		// CSRYieldCurveLight
		//------------------------------------------------------------------------------
		class SOPHIS_MATH CSRYieldCurveLight
		{
		public:
			CSRYieldCurveLight();
			virtual ~CSRYieldCurveLight();

			// relativeMaturity is relative to fToday
			virtual double GetDiscountFactor(long relativeMaturity) const = 0;

			virtual double GetForwardZeroCoupon(long dateStart,long dateEnd) const;

			// continuous ACT/365F
			double GetYearlyForwardZeroCouponRate(long dateStart,long dateEnd) const;

			virtual void SetData(const sophis::tools::CSRArchive& archive);		


			/** Clone for this object. Used for prototype construction of the object, don't implement this method in any child class,
			*	this is done by using INITIALISE_YIELDCURVELIGHT_SERVER macro.
			*
			@return A pointer on the clone created by the method.
			*/
			virtual CSRYieldCurveLight* Clone() const = 0;

			/**	Static method allowing access to instance of class inherited from CSRYieldCurveLight for prototype instantiation.
			*
			*	@see sophis::tools::CSRPrototype
			*/
			typedef	sophis::tools::CSRPrototype<CSRYieldCurveLight, const char *, sophis::tools::less_char_star> prototype;
			static	prototype&	GetPrototype();

			inline long GetToday() const {return fToday;};

		protected:
			long fToday;
			/**
			* Boolean value to know if we must extrapolate after the last zero coupon
			*/
			bool fMustExtrapolate;
		};


		

		
	}// End of 
}// End of sophis
SPH_EPILOG

#endif //____SphYieldCurveLight_H__
