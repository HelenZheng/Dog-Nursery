#ifndef __SphForexVolatility_h__
#define __SphForexVolatility_h__

#include "SphTools/SphPrototype.h"
#include "SphInc/market_data/SphVolatility.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphTools/SphCommon.h"
#include "SphInc/tools/SphAlgorithm.h"

#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

#define DECLARATION_TIME_DENSITY_MODEL(derivedClass) \
	DECLARATION_PROTOTYPE(derivedClass,sophis::market_data::CSRTimeDensityModel) \
	public: virtual CSRTimeDensityModel* Create(long id) const{ return new derivedClass(id); }; \
			static const char* MODEL_NAME;

#define	INITIALISE_TIME_DENSITY_MODEL(derive) INITIALISE_PROTOTYPE(derive,derive.MODEL_NAME)

SPH_PROLOG
namespace sophis	{
	namespace market_data	{

		/** Interface class that models a time density function.
		*/
		class SOPHIS_FIT CSRTimeDensityModel
		{
		protected:
			CSRTimeDensityModel(const _STL::string& model, long id = 0);			

		public:

			struct SSTimeDensityModel
			{
				SSTimeDensityModel();
				SSTimeDensityModel(const SSTimeDensityModel& refModel);
				SSTimeDensityModel& operator=(const SSTimeDensityModel& refModel);
				void Clear();

				long fSico;
				char fModel[60];
				double fNormalizationConstant;
				char fComments[200];
			};

			CSRTimeDensityModel(const CSRTimeDensityModel& refDensity);
			virtual ~CSRTimeDensityModel();

			/** Returns the density of time of a period.

			@param startTime The period's start time.
			@param endTime The period's end time.
			@param pCalendar The calendar that specifies the business days.
			@return the density of time between {@var startTime} and the {@var endTime}.
			*/
			virtual double GetDensityOfPeriod(double startTime, double endTime, const sophis::static_data::CSRCalendar* pCalendar = NULL) const = 0;

			/** Returns the weight attributed to a given time.

			@param t The time.
			@param pCalendar The calendar that specifies the business days.
			@return The weight attributed to the time {@var t}.
			*/
			virtual double GetDensityOfTime(double t, const sophis::static_data::CSRCalendar* pCalendar = NULL) const = 0;

			/** Get the whoe data inner structure.
			*/
			const SSTimeDensityModel& GetSSTimeDensityModel() const;

			/** Get the density's Id.

			@returns The density's id.
			*/
			long GetId() const;

			/** Set the density's id.
			*/
			void SetId(long id);

			/** Tells if the object has been modified.
			*/
			virtual bool GetModified() const;

			/** Set the object's modified flag's value.
			*/
			virtual void SetModified(bool value);

			/** Give the density's model name.
			*/
			const char* GetModelName() const;

			/** Give the value of the density function's normalization constant.

			@return The value of the density function's normalization constant.
			*/
			virtual double GetNormalizationConstant() const;

			/** Set the value of the normalization constant.

			@param value The new value to set.
			*/
			virtual void SetNormalizationConstant(double value);

			/** Save method.
			This method calls the SaveSpecific virtual method that perform the saving of derived class data.

			@return TRUE if deletion was performed without error, FALSE otherwise.
			*/
			bool Save();

			/** Delete method.
			This method calls the DeleteSpecific virtual method that perform the deletion of derived class data.

			@return TRUE if deletion was performed without error, FALSE otherwise. 
			*/
			bool Delete();

			//Factory and Singleton methods

			/** Get the instance of a density by its id.

			@param id The density's SICO.
			@return the instance of the density whose SICO is {@var id}.
			*/
			static const CSRTimeDensityModel* GetInstance(long id);


			/** Typedef for the prototype.
			*/
			typedef tools::CSRPrototypeParameter<CSRTimeDensityModel, const char*, long, tools::less_char_star> prototype;
			/** Access to the prototype singleton.
			To add a model, use INITIALISE_TIME_DENSITY_MODEL.
			@see tools::CSRPrototype
			*/
			static prototype & GetPrototype();
						
			static bool LoadData(long id, SSTimeDensityModel& data);
			static CSRTimeDensityModel* CreateInstance(const _STL::string& model);
			static CSRTimeDensityModel* CreateInstance(long id);

			virtual CSRTimeDensityModel* Clone() const = 0;
			virtual CSRTimeDensityModel* Create(long id) const = 0;

		protected:

			/** Saving method.

			@param sicoMain SICO in the main table.
			@param sicoHisto SICO used in the historical table.
			*/
			virtual bool SaveSpecific(long sicoMain, long sicoHisto) = 0;

			/** Deleting method.
			This method is called after the whole data has been historized AND deleted from main table.
			Specific treatment can be perofmed in there.
			*/
			virtual bool DeleteSpecific() = 0;

			/** Historizing method for specific data in derived class.
			This method should put the data from the main table into an histo table and then delete it from the main table.

			@param sicoMain SICO in the main table.
			@param sicoHisto SICO used in the historical table.
			*/
			virtual bool HistorizeDataSpecific(long sicoMain, long sicoHisto) = 0;

			/** Load generic data.
			*/
			bool LoadData(long id);

			/** Historize generic data AND  delete them from the main table.
			Once generic data is saved, this method calls the HistorizeDataSpecific method.

			@param sicoMain SICO in the main table.
			@param sicoHisto SICO used in the historical table.
			*/
			void HistorizeData(long sicoMain, long sicoHisto)
				throw(sophisTools::base::GeneralException);
			

		private:

			/** Access to the static map of instances.			
			@see tools::CSRPrototype
			*/
			static _STL::map<long, CSRTimeDensityModel*> & GetMapOfInstances();

			/** Get the database table name in which are stored generic data on time density.
			*/
			static const char* GetInfoTableName();			

			/** Modified flag.
			*/
			bool fModified;		

			/** The model data.
			*/
			SSTimeDensityModel fData;
		};


		class SOPHIS_FIT CSRTimeDensityModelUniform : public CSRTimeDensityModel
		{
			DECLARATION_TIME_DENSITY_MODEL(CSRTimeDensityModelUniform)

		public:

			CSRTimeDensityModelUniform();
			CSRTimeDensityModelUniform(long id);			
			virtual ~CSRTimeDensityModelUniform();			

			/** Returns the density of time of a period.
			The density of the period is the integral along the time period of GetTimeDensity:
			\[ F(t_1,t_2) = \int_{t_1}^{t_2} f(s) ds\]

			@param startTime The period's start time.
			@param endTime The period's end time.
			@param pCalendar The calendar that specifies the business days.
			@return the density of time between {@var startTime} and the {@var endTime}.
			*/
			virtual double GetDensityOfPeriod(double startTime, double endTime, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			/** Returns the weight attributed to a given time.
			If any special event is associated to the time, then this method returns the weight defined in {@see fWeightDiscreteEvent}.
			Otherwise it calculate the time density at time {@var t} as:
			\[ f(t) = f_m(t) f_d(t) f_h(t).\]

			@param t The time.
			@param pCalendar The calendar that specifies the business days.
			@return The weight attributed to the time {@var t}.
			*/
			virtual double GetDensityOfTime(double t, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

		protected:			

			/** Save in database the data that is specific to the "Uniform density" model.
			Since no data is needed in this model, this method do nothing and always returns TRUE.

			@return Always TRUE.
			*/
			virtual bool SaveSpecific(long sicoMain, long sicoHisto);		

			/** Delete from database the data that is specific to the "Uniform density" model.
			
			@return Always TRUE.
			*/
			virtual bool DeleteSpecific();

			virtual bool HistorizeDataSpecific(long sicoMain, long sicoHisto);
		};


		class SOPHIS_FIT CSRTimeDensityModelMWH : public CSRTimeDensityModel
		{
			DECLARATION_TIME_DENSITY_MODEL(CSRTimeDensityModelMWH)

		public:

			CSRTimeDensityModelMWH();
			CSRTimeDensityModelMWH(long id);			
			virtual ~CSRTimeDensityModelMWH();
			CSRTimeDensityModelMWH& operator=(const CSRTimeDensityModelMWH& refDensity);			

			/** Returns the density of time of a period.
			The density of the period is the integral along the time period of GetTimeDensity:
			\[ F(t_1,t_2) = \int_{t_1}^{t_2} f(s) ds\]

			@param startTime The period's start time.
			@param endTime The period's end time.
			@param pCalendar The calendar that specifies the business days.
			@return the density of time between {@var startTime} and the {@var endTime}.
			*/
			virtual double GetDensityOfPeriod(double startTime, double endTime, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			/** Returns the weight attributed to a given time.
			If any special event is associated to the time, then this method returns the weight defined in {@see fWeightDiscreteEvent}.
			Otherwise it calculate the time density at time {@var t} as:
			\[ f(t) = f_m(t) f_d(t) f_h(t).\]

			@param t The time.
			@param pCalendar The calendar that specifies the business days.
			@return The weight attributed to the time {@var t}.
			*/
			virtual double GetDensityOfTime(double t, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

		protected:			
			/** Historize in database the data that is specific to the density model.
			*/
			virtual bool HistorizeDataSpecific(long sicoMain, long sicoHisto)
				throw(sophisTools::base::DatabaseException); 
			
			/** Save in database the data that is specific to the density model.
			*/
			virtual bool SaveSpecific(long sicoMain, long sicoHisto);		

			/** Specific delete treatment for MWH model.

			@return always TRUE
			*/
			virtual bool DeleteSpecific();

			/** Initialize the object's data.
			If called with a argument, it copies the data from the argument.

			@param pDensity Object to be copied.
			*/
			void InitializeData(const CSRTimeDensityModelMWH* pDensity = NULL);

			/** Loads specific data from database.
			This method is called in the constructor.

			@return TRUE if the data was correctly loaded, FALSE otherwise.
			*/
			bool LoadSpecific(long sico);

		public:

			enum eWeightType
			{
				eMonthTemplate,
				eWeekDay,
				eHour,
				eMonthSpecific,
				eDiscreteEvent
			};
			
			struct SOPHIS_FIT SSTimeDensityWeight
			{
				SSTimeDensityWeight();
				SSTimeDensityWeight(const SSTimeDensityWeight& refData);
				SSTimeDensityWeight& operator=(const SSTimeDensityWeight& refData);
				bool operator==(const SSTimeDensityWeight& refData) const;
				bool operator!=(const SSTimeDensityWeight& refData) const;
				void Clear();

				//data
				long fSico;
				long fTypeItem;
				long fItem;
				double fWeight;
				char fComments[200];
			};

			/** Give the month contribution in the weight of a given date.

			@param date The date.
			@return The month contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfMonth(long date) const;

			/** Tells if a month has a specific contribution due to its year.

			@param date The date.
			@param[out] weight The month's contribution in its year. {@var weight} is reset to 0 if the month has no specific definition in the date's year.
			@return TRUE if the month has a specific weight, FALSE otherwise.
			*/
			bool IsMonthSpecific(long date, double *weight = NULL) const;

			/** Give a month's contribution within its year.

			@param date The date.
			@return The month's contribution in its year. Returns 0 if the month has no specific definition in the date's year.
			*/
			double GetWeightOfMonthSpecific(long date) const;

			/** Set the weights for months.

			@return TRUE if the parameters was valid, FALSE otherwise.
			*/
			bool SetWeightOfMonthSpecific(const _STL::map<long, SSTimeDensityWeight>& weights);
			
			const _STL::map<long, SSTimeDensityWeight>& GetWeightOfMonthSpecific() const;

			/** Give the month's template contribution in the weight of a given date.
			The template contribution of a month is independent from the date's year.

			@param date The date.
			@return The month's template contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfMonthTemplate(long date) const;

			/** Set the weights for months.

			@return TRUE if the parameters was valid, FALSE otherwise.
			*/
			bool SetWeightOfMonthTemplate(const _STL::vector<SSTimeDensityWeight>& vWeights);
			const _STL::vector<SSTimeDensityWeight>& GetWeightOfMonthTemplate() const;


			/** Give the weekday contribution in the weight of a given date.

			@param date The date.
			@return The weekday contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfWeekDay(long date, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			const _STL::vector<SSTimeDensityWeight>& GetWeightOfWeekDay() const;
			bool SetWeightOfWeekDay(const _STL::vector<SSTimeDensityWeight>& weights);

			/** Give the weight attributed to a given hour in a day.

			@param hour The hour.
			@return The weight attributed to hour {@var hour}.
			*/
			virtual double GetWeightOfHour(unsigned int hour) const;
			bool SetWeightOfHour(const _STL::vector<SSTimeDensityWeight>& weights);
			const _STL::vector<SSTimeDensityWeight>& GetWeightOfHour() const;

			/** Tell if a discrete event is associated to a given date.			
			
			@param date The date.
			@param[out] weight The weight associated to the discrete event. {@var weight} is reset to 0 if no discrete event is associated to date {@var date}.
			@return TRUE is a discrete event is associated to the date {@var date}, FALSE otherwise.
			*/
			virtual bool IsDiscreteEvent(long date, double *weight = NULL) const;

			/** Get the weight of a discrete event associated to a given date.			

			@param date The date.			
			@return The weight associated to the discrete event. It returns 0 if no discrete event is associated to date {@var date}.
			*/
			double GetWeightOfDiscreteEvent(long date) const;

			const _STL::map<long, SSTimeDensityWeight>& GetWeightOfDiscreteEvent() const;
			bool SetWeightOfDiscreteEvent(const _STL::map<long, SSTimeDensityWeight>& weights);

			/** Give an item data by its index.

			@param type The item type from the enum eWeightType: eMonthTemplate, eWeekDay, etc...
			@param i The index.
			@param[out] data The data retrieved.
			@return The discrete event's weight. Returns 0 if the index {@var i} is out of bounds.
			*/
			bool GetItemByIndex(eWeightType weightType, int i, SSTimeDensityWeight& outData) const;

		protected:
			/** Return the database table in which are stored the weights' data.
			*/
			const char* GetWeightTableName() const;

			bool SaveContainerOfWeight(long sicoMain, long sicoHisto, eWeightType weightType, const _STL::map<long, SSTimeDensityWeight> *pMap, const _STL::vector<SSTimeDensityWeight> *pVector = NULL) const;
			bool FillContainerOfWeight(long sicoMain, eWeightType weightType, _STL::map<long, SSTimeDensityWeight> *pMap, _STL::vector<SSTimeDensityWeight> *pVector = NULL);

			/** The values already calculated of the density cumulative function.
			These are daily values. The remaining intra-day part of the density is computed at each call.
			*/
			mutable _STL::vector<double> fCumulatedDensityCalculated;

			unsigned long fFirstDayCalculated;
			unsigned long fLastDayCalculated;

			/** A twelve-sized vector containing the month's weights, in a chronological order.
			The weight for January is the first element, February the second element, and so on until twelve.
			*/
			_STL::vector<SSTimeDensityWeight> fWeightOfMonthTemplate;

			/** Map containing the weights for some pairs (month, year).
			*/
			_STL::map<long, SSTimeDensityWeight>  fWeightOfMonthSpecific;

			/** A eight-sized vector containing the day's weights in chronological order.
			Weight number 1 is for Sunday, number 2 is for Monday, and so on until number 7 for Saturday. 
			Weight number 8 is for non-business days.
			*/
			_STL::vector<SSTimeDensityWeight> fWeightOfWeekDay;

			/** Map containing the weights of hour ranges.
			*/
			_STL::vector<SSTimeDensityWeight> fWeightOfHour;

			/** Map containing the weights of discrete events.
			*/
			_STL::map<long, SSTimeDensityWeight> fWeightOfDiscreteEvent;
		};


		//---------------------------------------------------------------
		// CSRVolatilityComputationTimeDensity 
		//---------------------------------------------------------------
		class SOPHIS_FIT CSRVolatilityComputationTimeDensity : public CSRVolatilityComputation
		{
		public:
			CSRVolatilityComputationTimeDensity(const CSRVolatility*	volatility);

			virtual double	GetVolatility(	double								startDate,
											double								endDate,
											double								strike,
											const market_data::CSRMarketData	&context,
											NSREnums::eVolatilityType			volatType,
											Boolean								put=false) const;
		};

		//---------------------------------------------------------------
		// CSRVolatilityTimeDensity 
		//---------------------------------------------------------------
		class SOPHIS_FIT CSRVolatilityTimeDensity : public CSRVolatility
		{
		public:

			DECLARATION_VOLATILITY(CSRVolatilityTimeDensity)			

			CSRVolatilityTimeDensity(const CSRVolatility& );
			//CSRVolatilityTimeDensity(const CSRVolatilityTimeDensity& );
			~CSRVolatilityTimeDensity();

			static const char* GetModelName();
			static void  DeclarationVolatilityAction();

		protected:
			virtual sophis::market_data::CSRVolatilityComputation* new_CSRVolatilityComputation() const;

			//load-save to DB
//			virtual bool LoadInstance(long code, long histoCode,const SSForexVolatilityData& inData);
//			virtual bool SaveInstance(NSREnums::eParameterModificationType typeModif) const;

			//get-set inner data structure
//			void SetTimeDensityModel(CSRTimeDensityModel& inData);
			long GetTimeDensityCode() const;
			const CSRTimeDensityModel* GetTimeDensity() const;			

//			void		SetRealCodes(long code, long codeHisto);

			//empty profiles listes and monthly config
//			void		ClearVolatilityData();

			//virtual bool ConstructAgain() const; //default returns false

			//virtual void push(sophis::tools::CSRArchive &archive) const;			

			virtual bool DisplayVolatilityGraphs() const
			{ return false; }

		protected:

			//virtual CSRVolatilityTimeDensity* Clone() const;

			/** Time density model's SICO.
			*/
			long fSicoTimeDensity;
			
//			void					Construct(const CSRForexVolatility& src);

		};

		////---------------------------------------------------------------
		//// SSForexVolatilityDailyTemplate
		////---------------------------------------------------------------
		//struct SOPHIS_COMMODITY SSForexVolatilityDailyTemplate
		//{
		//public:
		//	SSForexVolatilityDailyTemplate() : fVolWD_future_code(0),fVolST_future_code(0),fVolBH_future_code(0){}
		//	long	fVolWD_future_code; // The Future with daily WD vol, the Price will be ignored
		//	long	fVolST_future_code; // The Future with daily ST vol, the Price will be ignored
		//	long	fVolBH_future_code; // The Future with daily BH vol, the Price will be ignored
		//};

		////---------------------------------------------------------------
		//// SSForexVolatilityHourlyTemplateItem
		////---------------------------------------------------------------
		//struct SOPHIS_COMMODITY SSForexVolatilityHourlyTemplateItem
		//{
		//public:
		//	SSForexVolatilityHourlyTemplateItem() : fFutureSico(0){}
		//	long fFutureSico;
		//};

		////---------------------------------------------------------------
		//// SSForexVolatilityHourlyTemplate
		////---------------------------------------------------------------
		//struct SOPHIS_COMMODITY SSForexVolatilityHourlyTemplate
		//{
		//public:		
		//	int			    fGranularity;	
		//	mutable long	fIdent;
		//	static const int NbHours = 25 ;
		//	void Clear()
		//	{
		//		fItems.clear();
		//		fItems.resize(NbHours * 6);
		//	};
		//	SSForexVolatilityHourlyTemplate() : fGranularity(1),fIdent(0)
		//	{
		//		Clear();
		//	};

		//	_STL::vector<SSForexVolatilityHourlyTemplateItem> fItems;
		//};
		////---------------------------------------------------------------
		//// SSForexVolatilityData
		////---------------------------------------------------------------
		//struct SOPHIS_COMMODITY SSForexVolatilityData
		//{
		//public:
		//	SSForexVolatilityData() : fModifiedMonthlyList(false),fModifiedDailyTemplateList(false),fModifiedHourlyTemplateList(false),sico(0), fHistoCode(0){}

		//	// long is a Future code representing a Monthly forward contract
		//	_STL::map <long, SSForexVolatilityMonthlyDataItem>			fMonthlyList;
		//	// the string is the daily template name
		//	_STL::map <_STL::string, SSForexVolatilityDailyTemplate>		fDailyTemplateList;
		//	// the string is the hourly templace name
		//	_STL::map <_STL::string, SSForexVolatilityHourlyTemplate>	fHourlyTemplateList;

		//	bool fModifiedMonthlyList;
		//	bool fModifiedDailyTemplateList;
		//	bool fModifiedHourlyTemplateList;
		//	long sico;
		//	static const int	MaxNamesLength = 40;
		//	static const long	MaxYear = 2050;
		//	static const long	MinYear = 1950;
		//	static const long	MaxMonth = 12;
		//	static const long	MinMonth = 1;
		//	static const long	MaxHour = 25;
		//	static const long	MinHour = 1;
		//	static const int    MaxVol = 500;
		//	static const int	MinVol = 0;
		//	static const int    Precision = 2;
		//	static const double MinStrike;
		//	static const double MaxStrike;

		//	void LinkItems();
		//	const SSForexVolatilityData& operator=(const SSForexVolatilityData& ref);
		//	SSForexVolatilityData(const SSForexVolatilityData& ref);
		//	_STL::string f_sHistoTitle;
		//	long fHistoCode;
		//protected:
		//	void CopyTo(const SSForexVolatilityData& from,SSForexVolatilityData& to);

		//};

		////---------------------------------------------------------------
		//// CSRForexVolatilityBreakdown
		////---------------------------------------------------------------

		//class SOPHIS_FIT CSRForexVolatilityCalculation
		//{
		//public:
		//	CSRForexVolatilityCalculation(const SSForexVolatilityData& data);

		//	void GetDailyRiskSources(const _STL::set<long> monthlyFutures, _STL::set<long> & dailyFutures);
		//	void GetHourlyRiskSources(const _STL::set<long> monthlyFutures, _STL::set<long> & hourlyFutures);

		//	virtual bool ComputeVolatility(const commodity::CSRDeliveryPeriod::DayAndHour& dayAndHour, const CSRMarketData* context, const char* deliveryLoad, double dtStart, double dtEnd, double strike, NSREnums::eVolatilityType volatilityType, Boolean put);

		//	double GetMonthlyVol() const
		//	{ return fMonthlyVol; }

		//	double GetDailyVol() const
		//	{ return fDailyVol; }

		//	double GetHourlyVol() const
		//	{ return fHourlyVol; }

		//	double GetVol() const
		//	{ return fVol; }

		//	long GetMonthlyVolSource() const
		//	{ return fMonthlyVolSource; }

		//	long GetDailyVolSource() const
		//	{ return fDailyVolSource; }

		//	long GetHourlyVolSource() const
		//	{ return fHourlyVolSource; }

		//protected:
		//	double fMonthlyVol;
		//	double fDailyVol;
		//	double fHourlyVol;
		//	double fVol;

		//	long	fMonthlyVolSource;
		//	long	fDailyVolSource;
		//	long	fHourlyVolSource;

		//	virtual double VolFormula(double dblVolMonth,double dblVolDay,double dblVolHour) const;

		//	const SSForexVolatilityData *fData;
		//};

	
	}
}
//archive operators
//sophis::tools::CSRArchive & operator << (sophis::tools::CSRArchive & ar, const sophis::market_data::SSForexVolatilityData& v);
//const sophis::tools::CSRArchive & operator >> (const sophis::tools::CSRArchive & ar, sophis::market_data::SSForexVolatilityData &v);

SPH_EPILOG
#endif

