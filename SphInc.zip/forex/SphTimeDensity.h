#ifndef __SPHTIMEDENSITY_H__
#define __SPHTIMEDENSITY_H__

#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

SPH_PROLOG
namespace sophis
{
	namespace tools {
		class CSREventVector;

		namespace dataModel	{
			class DataSet;
			class Data;
		}
	}

	namespace static_data
	{
		//forward declaration
		class CSRCalendar;

		/** Ranges for time density ids.
		- Risque native Time density models' ids are between 1 and TOOLKIT_TIME_DENSITY_MODEL_ID_BEGIN-1
		- Toolkit Time density models' ids are between TOOLKIT_TIME_DENSITY_MODEL_ID_BEGIN and TOOLKIT_TIME_DENSITY_MODEL_ID_END
		- Time density items' ids are greater than TOOLKIT_TIME_DENSITY_MODEL_ID_END
		*/
		#define TOOLKIT_TIME_DENSITY_MODEL_ID_BEGIN 100
		#define TOOLKIT_TIME_DENSITY_MODEL_ID_END 9999
		#define TIME_DENSITY_PARAMETRIC_ID_BEGIN TOOLKIT_TIME_DENSITY_MODEL_ID_END + 1

		/** Macros to help defining a toolkit time density models.
		*/
		#define DECLARATION_TIME_DENSITY_MODEL(derivedclass) \
				DECLARATION_PROTOTYPE(derivedclass,CSRTimeDensity) \
				public: virtual const char* GetModelName() const; \
				public: virtual long GetId() const;
				
			
		#define INITIALISE_TIME_DENSITY_MODEL(derivedclass, name) INITIALISE_PROTOTYPE(derivedclass, name)

		/** Abstract class to manage time density.

		The CSRTimeDensity class serves as an interface for two types of time density models:
		<ul>
		<li>
		Single instance time density models that enable only one set of parameters: 
		once the parameters are choosen, any instance of the model returns the same time density function.
		The GetId() method returns the id identifying the model.
		This id is bewteen 1 and TOOLKIT_TIME_DENSITY_MODEL_ID_BEGIN - 1 for Risque native models, and
		between TOOLKIT_TIME_DENSITY_MODEL_ID_BEGIN and TOOLKIT_TIME_DENSITY_MODEL_ID_END for Toolkit models.
		</li>
		<li>
		Multiple instances density models that enable several sets of parameters (stored in the database) {@see CSRTimeDensityParametric}: 
		one can define different sets of parameters, and with each of them a different time density function.
		The GetId() method returns the id identifying the underlying set of parameters.
		So that one can distinguish between single and multiple model, this id is greater than TOOLKIT_TIME_DENSITY_MODEL_ID_END.
		One can get the base model of a such time density item calling the GetModelName() method.
		</li>
		</ul>
		*/
		class SOPHIS_FIT CSRTimeDensity
		{
		public:

			virtual ~CSRTimeDensity();
			virtual CSRTimeDensity* Clone() const = 0;
			virtual long GetId() const = 0;
			virtual const char* GetModelName() const = 0;

			/** Get the time density name.
			*/
			virtual const char* GetName() const;

			/** Get the density of a given time.

			@param dateTime The time.
			@param pCalendar The calendar to use to determine non-business days.
			@return The density at time {@var dateTime}.
			*/
			virtual double GetDayCountOfPeriod(double startTime, double endTime, const sophis::static_data::CSRCalendar* pCalendar = NULL) const = 0;

			virtual double AddNumberOfDays(double startTime, double numberOfDays, const sophis::static_data::CSRCalendar* pCalendar = NULL) const = 0;

			/** Get the density of a given period.

			@param startDateTime The period's start time.
			@param endDateTime The period's end time.
			@param pCalendar The calendar to use to determine non-business days.
			@return The density at period between {@var startDateTime} and {@var endDateTime}.
			*/
			virtual double GetDensityOfTime(double t, const sophis::static_data::CSRCalendar* pCalendar = NULL) const = 0;

			/** Prototype for factory/singleton management.
			*/
			typedef sophis::tools::CSRPrototypeWithId<CSRTimeDensity, const char*, sophis::tools::less_char_star> prototype;

			/** Get the factory/singleton prototype.
			*/
			static prototype& GetPrototype();

			/** Get the instance of a time density model (resp.item) given its id.

			@param id The model's (resp. item's) id.
			@return the instance of a given time density model
			*/
			static const CSRTimeDensity* GetInstance(long id);

			/** Get the instance of a time density model (resp. item) given its name.

			@param id The model's (resp. item's) name.
			*/
			static const CSRTimeDensity* GetInstance(const char* name);

			/** Name of the root in the xml description.
			* @return a string C which must not be deleted.
			*/
			virtual const char * GetXMLRootName() const;

			/** Retrieve a description from a time density.
			  * This is public and not virtual.
			  * It calls GetDescription.
			  * @param dataSet is the description to be filled with this time density.
			  * @throw GeneralException this time density is invalid : the description cannot be built from it.
			  * It is called by xml copy in view of creating a XML describing the time density in the clipboard.
			  */
			void GetDescription_API(tools::dataModel::DataSet& dataSet) const;

			/** Initialize this time density from a description
			  * This is public and not virtual.
			  * It calls UpdateFromDescription.
			  * @param dataSet is an objet that contains data which this time density can be built by.
			  *        A DataSet can be built from an XML file for instance.
			  * @throws DataModelException the dataSet is invalid : the time density cannot be built from it.
			  * It is called by the data service in view of updating the time density using a XML provided by an external source. 
			*/
			void UpdateFromDescription_API(const tools::dataModel::DataSet& dataSet);

			/** Create this time density from a description.
			  * - Call UpdateFromDescription_API.
			  * - return the time density ready to be saved.
			  * @param dataSet is an objet that contains data which this time density can be built by.
			  *        A DataSet can be built from an XML file for instance.
			  * @return a new time density ready to be saved which must be deleted.
			*/
			static CSRTimeDensity * CreateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);


			virtual bool Save(){return false;}
			virtual bool Save(sophis::tools::CSREventVector* ev) {return false;}

			/**
			 * describe time density identifiers
			 * @see volatility.xsd  : <xs:complexType name="TDIdentifier">
			 * @since 7.1.3
			 */
			static void DescribeIdentifiers(tools::dataModel::Data & timeDensityIdentifier,long ID,_STL::string name);
		protected:
			CSRTimeDensity();

			/** Retrieves a description from a time density.
			* This is protected to be overloaded by the class.
			* @param dataSet is the description to be filled.
			* It is called by xml copy in view of creating a XML describing the instrument in the clipboard. 
			* @see GetDescription_API
			*/
			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;

			/** Initialize this time density from a description
			* This is protected to be overloaded by the class.
			* @param dataSet is an objet that contains data wich which this time density can be built.
			*        A DataSet can be built from an XML file for instance.
			* @throw GeneralException the dataSet is invalid : the time density cannot be built from it.
			* It is called by the data service in view of updating the time density using a XML provided by an external source.
			* @see UpdateFromDescription_API
			*/
			virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);
		};
		

		#define TIME_DENSITY_PARAMETRIC_SIZE_MODEL 40
		#define TIME_DENSITY_PARAMETRIC_SIZE_NAME 60

		/** Macros to help defining a toolkit time density item model.
		*/
		#define DECLARATION_TIME_DENSITY_PARAMETRIC_MODEL(derivedclass) \
				DECLARATION_PROTOTYPE(derivedclass,CSRTimeDensity) \
				public: virtual const char* GetModelName() const;  \
				public: derivedclass(); \
				protected: derivedclass(long id); \
				protected: virtual CSRTimeDensityParametric* Create(long id) const { return new derivedclass(id); };

		/** Abstract class to manage time density models with several sets of parameters.

		An instance of CSRTimeDensityParametric is actually a time density model calibrated with a given set of parameters.
		*/
		class SOPHIS_FIT CSRTimeDensityParametric : public CSRTimeDensity
		{
		protected:
			CSRTimeDensityParametric();
			CSRTimeDensityParametric(long id);
			CSRTimeDensityParametric(const CSRTimeDensityParametric& refDensity);
			CSRTimeDensityParametric& operator=(const CSRTimeDensityParametric& refDensity);

		public:

			struct SOPHIS_FIT SSTimeDensityData
			{
				SSTimeDensityData();
				SSTimeDensityData(const SSTimeDensityData& refData);
				SSTimeDensityData& operator=(const SSTimeDensityData& refData);									
				void Clear();

				long fId;
				char fName[TIME_DENSITY_PARAMETRIC_SIZE_NAME+1];
				char fModel[TIME_DENSITY_PARAMETRIC_SIZE_MODEL+1];
				double fNormalization;
			};
			
			const SSTimeDensityData& GetSSTimeDensityData() const;

			/** Factory method.
			*/
			virtual CSRTimeDensityParametric* Create(long id) const = 0;

			/** Get the parametric model name.			
			*/
			virtual const char* GetModelName() const = 0;

			/** Name of the root in the xml description.
			* @return a string C which must not be deleted.
			*/
			virtual const char * GetXMLRootName() const;

			/** Get the instance of a time density item given its id.

			@param id The item's id.
			@param loadIfNotFound Boolean to specify if one must reload the instance if it wasn't already in the static map.
			@return the instance of a given time density item.
			*/
			static const CSRTimeDensityParametric* GetInstance(long id);

			/** Get the instance of a time density item given its name.

			@param id The item's name.
			@param loadIfNotFound Boolean to specify if one must load the instance if it wasn't already in the static map.
			*/
			static const CSRTimeDensityParametric* GetInstance(const char* name);

			/** Get the list by id of the time density items derived from a given model.

			@param model A model filter.
			@return a map of instances indexed by the ids.
			*/
			static void GetInstances(_STL::map< long, const CSRTimeDensityParametric*>& outMap, const char* model = NULL);

			/** Get the list by id of the time density items derived from a given model.

			@return a map of instances indexed by the ids.
			*/
			static const _STL::map< long, const CSRTimeDensityParametric*>& GetInstances();

			/** Tells if the whole set of data is valid.

			@return TRUE if data is valid, FALSE otherwise.
			*/
			virtual bool DataIsValid(_STL::string* err = NULL) const;

			/** Save data in database.

			@return FALSE if an error occurred, TRUE otherwise.
			*/
			virtual bool Save();	

			virtual bool Save(sophis::tools::CSREventVector* ev);
			/** Delete a given time density item.
			*/
			bool Delete();

			/** Tells if the time density's inner data has been modified.
			*/
			bool GetModified() const;

			/** Set the modified flag.
			*/
			void SetModified(bool value);

			/** Get the id of the set of parameters.
			*/
			long GetId() const;

			/** Set the id of the set of parameters.
			*/
			void SetId(long id);

			/** Get the name of the set of parameters.
			*/
			const char* GetName() const;

			/** Set the name of the set of parameters.
			*/
			void SetName(const char* name);

			/** Get the normalization constant.
			*/
			double GetNormalizationConstant() const;

			/** Set the normalization constant.
			*/
			void SetNormalizationConstant(double value);

			/** Get the precision of the weights in database.
			*/
			static int GetPrecisionInDatabase();

			typedef _STL::map<long, const CSRTimeDensityParametric*> instance_container;
			typedef instance_container::const_iterator const_iterator;

			static instance_container& GetMapOfInstances(bool reload = false);

		protected:
			/** Get the main table's name where are stored density items' data.
			*/
			static const char* GetInfoTableName();

			/** Get a new id for saving a new time density item.
			*/
			static long GetNewId();

			/** Specific methods to overload in derived class.
			*/			
			virtual bool SaveSpecific(long id, long idAudit);
			virtual bool HistorizeDataSpecific(long idMain, long idAudit);
			virtual bool DeleteSpecific();

			/** Get the SICO to actually load, taking into account prices date.
			*/
			long GetIdToLoad() const;

			/** Tell if the instance is historical or not.
			*/
			bool IsHisto() const;

			static bool LoadData(long id, SSTimeDensityData& data);
			static bool LoadData(const char* name, SSTimeDensityData& data);
			bool HistorizeData(long idMain, long idAudit);

			/** Item's common Data.
			*/
			SSTimeDensityData fData;

			/** Id of the data actually loaded (for Audit).
			*/
			long fIdToLoad;

			/** Modified flag.
			*/
			bool fModified;

			/** Create an instance of a time density item given its id.

			@param id The item's id.
			*/
			static CSRTimeDensityParametric* CreateInstance(long id);

			/** Create an instance of a time density model (resp. item) given its name.
			The model (resp. item) must already exist (Toolkit defined or stored in database).

			@param id The item's name.
			*/
			static CSRTimeDensityParametric* CreateInstance(const char* name);

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);

		};
	};
};
SPH_EPILOG
#endif
