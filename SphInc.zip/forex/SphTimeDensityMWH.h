#ifndef __SPHTimeDensityMDH_H__
#define __SPHTimeDensityMDH_H__

#include "SphInc/forex/SphTimeDensity.h"

SPH_PROLOG
namespace sophis
{
	namespace static_data
	{

		#define TIME_DENSITY_MDH_SIZE_COMMENT 100		

		/** Class to manage time density.

		The CSRTimeDensity class is used to manage two type o time density models:
		- The time density models with only one "static" set of parameters.
		- The time density models with several sets of parameters (stored in the database).
		*/
		class SOPHIS_FIT CSRTimeDensityMDH : public CSRTimeDensityParametric
		{
			DECLARATION_TIME_DENSITY_PARAMETRIC_MODEL(CSRTimeDensityMDH)
			CSRTimeDensityMDH(const CSRTimeDensityMDH& refDensity);
			CSRTimeDensityMDH& operator=(const CSRTimeDensityMDH& refDensity);			

		public:
			static const char* MODEL_NAME;

			virtual ~CSRTimeDensityMDH();

			/** Basic structure to store MDH weights.
			*/
			struct SOPHIS_FIT SSTimeDensityMDHWeight
			{
				SSTimeDensityMDHWeight();
				SSTimeDensityMDHWeight(const SSTimeDensityMDHWeight& refData);
				SSTimeDensityMDHWeight& operator=(const SSTimeDensityMDHWeight& refData);
				virtual void Clear();

				bool operator==(const SSTimeDensityMDHWeight& refData) const;
				bool operator<(const SSTimeDensityMDHWeight& refData) const;
				bool operator!=(const SSTimeDensityMDHWeight& refData) const;
				virtual bool isWeightEqual(double value) const;
				virtual bool IsValid() const;
				virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
				virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);
				
				long fKey;
				double fWeight;
				char fComments[TIME_DENSITY_MDH_SIZE_COMMENT+1];
			};

			/** Returns the density of time of a period.
			The density of the period is the integral along the time period of GetTimeDensity:
			\[ F(t_1,t_2) = \int_{t_1}^{t_2} f(s) ds\]

			@param startTime The period's start time.
			@param endTime The period's end time.
			@param pCalendar The calendar that specifies the business days.
			@return the density of time between {@var startTime} and the {@var endTime}.
			*/
			virtual double GetDayCountOfPeriod(double startTime, double endTime, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			virtual double AddNumberOfDays(double startTime, double numberOfDays, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;
			
			/** Returns the weight attributed to a given time.
			If any special event is associated to the time, then this method returns the weight defined in {@see fWeightDiscreteEvent}.
			Otherwise it calculate the time density at time {@var t} as:
			\[ f(t) = f_m(t) f_d(t) f_h(t).\]

			@param t The time.
			@param pCalendar The calendar that specifies the business days.
			@return The weight attributed to the time {@var t}.
			*/
			virtual double GetDensityOfTime(double t, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			/** Name of the root in the xml description.
			* @return a string C which must not be deleted.
			*/
			virtual const char * GetXMLRootName() const;

		protected:

			/** Historize in database the data that is specific to the density model.
			*/
			virtual bool HistorizeDataSpecific(long idMain, long idHisto)
				throw(sophisTools::base::DatabaseException); 

			/** Save in database the data that is specific to the density model.
			*/
			virtual bool SaveSpecific(long idMain, long idHisto);		

			/** Specific delete treatment for MDH model.

			@return always TRUE
			*/
			virtual bool DeleteSpecific();

			/** Initialize the object's data.
			If called with a argument, it copies the data from the argument.

			@param pDensity Object to be copied.
			*/
			void InitializeData(const CSRTimeDensityMDH* pDensity = NULL);

			/** Loads specific data from database.
			This method is called in the constructor.

			@return TRUE if the data was correctly loaded, FALSE otherwise.
			*/
			bool LoadSpecific(long id);

			virtual void GetDescription(tools::dataModel::DataSet& dataSet) const;
			virtual void UpdateFromDescription(const tools::dataModel::DataSet& dataSet);

		public:

			enum eWeightType
			{
				eUndefined = 0,
				eMonthTemplate,
				eWeekDay,
				eHour,
				eMonthSpecific,
				eDiscreteEvent
			};


			/** Give the month contribution in the weight of a given date.

			@param date The date.
			@return The month contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfMonth(long date) const;

			/** Tells if a month has a specific contribution due to its year.

			@param date The date.
			@param[out] weight The month's contribution in its year. {@var weight} is reset to 0 if the month has no specific definition in the date's year.
			@return TRUE if the month has a specific weight, FALSE otherwise.
			*/
			virtual bool IsMonthSpecific(long date, double *weight = NULL) const;

			/** Give a month's contribution within its year.

			@param date The date.
			@return The month's contribution in its year. Returns 0 if the month has no specific definition in the date's year.
			*/
			virtual double GetWeightOfMonthSpecific(long date) const;

			/** Set the weights for months.

			@return TRUE if the parameters was valid, FALSE otherwise.
			*/
			bool SetWeightOfMonthSpecific(const _STL::map<long, SSTimeDensityMDHWeight>& weights, bool keyAreDates = false);

			const _STL::map<long, SSTimeDensityMDHWeight>& GetWeightOfMonthSpecific() const;

			/** Give the month's template contribution in the weight of a given date.
			The template contribution of a month is independent from the date's year.

			@param date The date.
			@return The month's template contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfMonthTemplate(long date) const;

			/** Set the weights for months.

			@return TRUE if the parameters was valid, FALSE otherwise.
			*/
			bool SetWeightOfMonthTemplate(const _STL::vector<SSTimeDensityMDHWeight>& vWeights);
			const _STL::vector<SSTimeDensityMDHWeight>& GetWeightOfMonthTemplate() const;


			/** Give the weekday contribution in the weight of a given date.

			@param date The date.
			@return The weekday contribution in the weight of {@var date}.
			*/
			virtual double GetWeightOfWeekDay(long date, const sophis::static_data::CSRCalendar* pCalendar = NULL) const;

			const _STL::vector<SSTimeDensityMDHWeight>& GetWeightOfWeekDay() const;
			bool SetWeightOfWeekDay(const _STL::vector<SSTimeDensityMDHWeight>& weights);

			/** Give the weight attributed to a given hour in a day.

			@param hour The hour.
			@return The weight attributed to hour {@var hour}.
			*/
			virtual double GetWeightOfHour(unsigned int hour) const;
			bool SetWeightOfHour(const _STL::vector<SSTimeDensityMDHWeight>& weights);
			const _STL::vector<SSTimeDensityMDHWeight>& GetWeightOfHour() const;

			/** Tell if a discrete event is associated to a given date.			

			@param date The date.
			@param[out] weight The weight associated to the discrete event. {@var weight} is reset to 0 if no discrete event is associated to date {@var date}.
			@return TRUE is a discrete event is associated to the date {@var date}, FALSE otherwise.
			*/
			virtual bool IsDiscreteEvent(long date, double *weight = NULL) const;

			/** Get the weight of a discrete event associated to a given date.			

			@param date The date.			
			@return The weight associated to the discrete event. It returns 0 if no discrete event is associated to date {@var date}.
			*/
			virtual double GetWeightOfDiscreteEvent(long date) const;

			const _STL::map<long, SSTimeDensityMDHWeight>& GetWeightOfDiscreteEvent() const;
			bool SetWeightOfDiscreteEvent(const _STL::map<long, SSTimeDensityMDHWeight>& weights);

			/** Give an weight data by its index.

			@param type The weight type from the enum eWeightType: eMonthTemplate, eWeekDay, etc...
			@param i The index.
			@param[out] data The data retrieved.
			@return The discrete event's weight. Returns 0 if the index {@var i} is out of bounds.
			*/
			bool GetWeightByIndex(eWeightType weightType, unsigned int i, SSTimeDensityMDHWeight& outData) const;

			/** Get the cumulated density cache.
			*/
			const _STL::vector<double>& GetCache() const;

			/** Get the first maturity available in the cache.
			*/
			long GetCacheFirstDay() const;

		protected:
			/** Return the database table in which are stored the weights' data.
			*/
			const char* GetWeightTableName() const;

			//Utility methods
			bool SaveContainerOfWeight(long idMain, long idHisto, eWeightType weightType, const _STL::map<long, SSTimeDensityMDHWeight> *pMap, const _STL::vector<SSTimeDensityMDHWeight> *pVector = NULL) const;
			bool FillContainerOfWeight(long idMain, eWeightType weightType, _STL::map<long, SSTimeDensityMDHWeight> *pMap, _STL::vector<SSTimeDensityMDHWeight> *pVector = NULL);
			bool SetContainerOfWeight(eWeightType weightType, const _STL::map<long, SSTimeDensityMDHWeight>& mapIn);
			bool SetContainerOfWeight(eWeightType weightType, const _STL::vector<SSTimeDensityMDHWeight>& vectIn);

			/** A cache that stores values already calculated of the density cumulative function.
			These are daily values. The remaining intra-day part of the density is computed at each call.
			*/
			mutable _STL::vector<double> fCumulatedDayCountCalculated;

			mutable unsigned long fFirstDayCalculated;
			mutable unsigned long fLastDayCalculated;

			/** Clear the cumulated density cache.
			*/
			void ResetCache() const;


			/** A twelve-sized vector containing the month's weights, in a chronological order.
			The weight for January is the first element, February the second element, and so on until twelve.
			*/
			_STL::vector<SSTimeDensityMDHWeight> fWeightOfMonthTemplate;

			/** Map containing the weights for some pairs (month, year).
			The key is a month number
			*/
			_STL::map<long, SSTimeDensityMDHWeight>  fWeightOfMonthSpecific;

			/** A eight-sized vector containing the day's weights in chronological order.
			Weight number 1 is for Sunday, number 2 is for Monday, and so on until number 7 for Saturday. 
			Weight number 8 is for non-business days.
			*/
			_STL::vector<SSTimeDensityMDHWeight> fWeightOfWeekDay;

			/** Map containing the weights of hour ranges.
			*/
			_STL::vector<SSTimeDensityMDHWeight> fWeightOfHour;

			/** Map containing the weights of discrete events.
			*/
			_STL::map<long, SSTimeDensityMDHWeight> fWeightOfDiscreteEvent;
		};		
	};
};
SPH_EPILOG

#endif
