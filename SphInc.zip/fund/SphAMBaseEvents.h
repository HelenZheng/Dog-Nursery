
#pragma once
#ifndef _SPHAMBASEEVENTS_H_
#define _SPHAMBASEEVENTS_H_

/*
 	File:		SphAMEvents.h
 
 	Contains:	class for events for asset management.
 
 	Copyright:	� 2000-2002 Sophis.
*/

namespace sophis	
{
	namespace value	
	{
		enum eFundBaseEvent 
		{
			feLegalForm					= 'legf'   // legal form
		   ,feAmCutOffs					= 'amco'	// AM Cut Offs
		   ,feAmPreferences				= 'ampr'	// AM preferences
		   ,feAssetValueInstrCreation	= 'avci'	// notify that a cash instrument has been created	
		   ,feEstimatedNavUpdateEvent	= 'fenu'	// sent when updating estimated nav
		   ,feValuationNavUpdateEvent	= 'fvnu'	// sent when updating valuation nav
		   ,feOfficialNavUpdateEvent	= 'fonu'	// sent when updating official nav
		};

	}
}
#endif
