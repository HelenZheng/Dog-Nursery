 #pragma once
/*
 	File:		SphAMOverloadedDialogs.h
 
 	Contains:	Overload of RISQUE dialogs (portfolios, deals)
 
 	Copyright:	� 2006 Sophis.
*/

#ifndef _SPHFUNDOVERLOADED_DIALOGS_H_
#define _SPHFUNDOVERLOADED_DIALOGS_H_


// Macros definitions
#include "SphFundBaseGUIExports.h"

// Application includes
#include "SphInc/gui/SphTransactionDialog.h"
#include "SphInc/portfolio/SphTransaction.h"

#include "SphExternalFund.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

#ifdef _WIN32
#	pragma warning(push)
#	pragma warning(disable: 4251) // warning C4251: class 'type' needs to have dll-interface to be used by clients of class 'type2'
#endif

#define eGALibelle 84

namespace sophis 
{
	namespace value	
	{
		/** 
		*	Overload of CSRPortfolioDialog (portfolio properties)
		*
		*	If you also want to override this dialog, inheritates of that class instead of 
		*	CSRPortfolioDialog.
		*	@since 2.1
		*/

		class SOPHIS_FUND_BASE CSAMBasePortfolioDialog : public gui::CSRPortfolioDialog
		{
		public:
			DECLARATION_DIALOG(CSAMBasePortfolioDialog)
			virtual ~CSAMBasePortfolioDialog();
			
			virtual void OpenAfterInit(void);
		};

		class CSAMFundBaseDealUpdate;		
		/** 
		*	Overload of CSRTransactionDialog (ticket dialog box) 
		*	specific behavior for funds of funds (subscriptions or redemptions)
		*
		*	If you also want to override this dialog, inheritates of that class instead of 
		*	CSRTransactionDialog.
		*	@since 2.1
		*/
		class SOPHIS_FUND_BASE_GUI CSAMBaseTransactionDialog : public gui::CSRTransactionDialog
		{
		public:
			DECLARATION_DIALOG(CSAMBaseTransactionDialog)
			enum EControls { 
				cFirst = 401,
				cTDNAVDate=cFirst, 
				cTDStaticNAVDate, 
				cTDCutOff, 
				cTDStaticPriceNAVDate, 
				cTDUnused1,
				cTDUnused2,
				cTDValidationStatus, 
				cTDStaticValidationStatus, 
				cTDUnused3,
				cTDSubscriptionLabel,
				cTDSubscriptionList,
				cTDSeriesLabel,
				cTDSeriesList,
				cTDInvestmentFolioLabel,
				cTDInvestmentFolioMenu,
				cTDInvestmentStrategyMenu,
				cTDStaticEqualisationAmount,
				cTDEqualisationAmount,
				cTDCCy,
				cLAST, cCOUNT=cLAST-401
			};

			virtual void Open();
			virtual void OpenAfterInit();
			virtual void ElementValidation(int EAId_Modified);
			virtual void GetSpecificElements(_STL::vector<long> &elemsV);
			//Try to add the given counterparty in the dropdown list of the deal input window
			bool TryAddCounterPartyToMenu(long CounterPartyId);
		protected:
			// Called by Open
			virtual void InitialiseTransaction(portfolio::CSRTransaction* trans);
			virtual void UpdateTransactionFromReference(portfolio::CSRTransaction* trans);
			virtual void InitFromDealUpdater(portfolio::CSRTransaction* trans);
			virtual void SetDecimalsFromFund(const CSAMFundBase* fund);
			virtual void InitFromFund(const CSAMFundBase* fund, portfolio::CSRTransaction* trans);
			virtual void InitNavDate(const CSAMExternalFund *fund);
			virtual void HideFundElements(bool isAFund=false);			
			virtual void ShowFundElements();
			virtual void DisplayCutOffTimes(const CSAMExternalFund* fund);
			virtual void DisplayValidation();
			virtual void UpdateTransaction();
			virtual void UpdateSubscriptionsList();

			/**Initialize fElementList.
			It must be called in the constructor of the derivated class.
			
			@code 
			CSxTransactionDlg::CSxTransactionDlg() : CSAMTransactionDialog()
			{
				fResourceId	= IDD_TRANSACTION_DIALOG - ID_DIALOG_SHIFT;
				int nb = InitElementList(CSAMTransactionDialog::cCOUNT, eNbFields);
				fElementList[nb++] = new CSREditLong(this, eExternalKey, 0, 1000000000, 0, "TKT_EXTERNAL_KEY");
			}
			@endcode

			@param currentNbFields is the number of elements in the base class. (ex: CSAMTransactionDialog::cCOUNT)
            @param nbNewFields is the number of added custom fields. (ex: eNbFields)
			@return the index of the last base class element. Use it to increment the index of the element list. (ex: fElementList[nb++] = ...)
			@version 7.1.3.14
			*/
			int InitElementList(int currentNbFields, int nbNewFields);

			// Internal.
			void Refresh();
			void ShowSeriesElements(bool show=true);
			void UpdateTransactionFromSeries(long seriesId, bool isNewTransaction);
			void UpdateEqualisationAmountIssued(const CSAMExternalFund* externalFund,portfolio::CSRTransaction* trans);
			double GetEffectiveRate(const CSAMExternalFund* externalFund) const;
			long fNavDate;
			long fPriceNAVDate;
			double fPreviousQuantity;
			eFOFValidation fValidation;
			bool fNavDateEnforced;
			sophis::portfolio::TransactionIdent fSubscriptionInternalCode;

			_STL::auto_ptr<CSAMFundBaseDealUpdate> fDealUpdater;
		};
	}
}

#ifdef _WIN32
#	pragma warning(pop)
#endif


#endif // _SPHFUNDOVERLOADED_DIALOGS_H_
