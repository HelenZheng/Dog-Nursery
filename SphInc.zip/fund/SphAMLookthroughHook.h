 /*
 	File:		SphAMLookthroughHook.h

 	Contains:	Implement a hook for choosing which instruments are split 
				in a lookthrough extraction

 	Copyright:	� 2009 Sophis.

*/

/*! \file SphAMLookthroughHook.h
	\brief To choose instruments which are split in a lookthrough extraction
*/

#ifndef _SPHAM_LOOKTHROUGH__HOOK_H_
#define _SPHAM_LOOKTHROUGH__HOOK_H_

#include "SphInc/portfolio/SphExtractionCustomLookthrough.h"
#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/fund/SphFundBase.h"
#include "SphFundBaseExports.h"

namespace sophis	
{	
	namespace value
	{
		/** Class for choosing which instruments are split in a lookthrough extraction
		<br>
		This class provides a callback which is called during the lookthrough process
		of a criteria extraction with lookthrough selected as "Full" or "Package".
		The callback is called for each external fund which has no breakdown,
		and the returned benchmark is split during the lookthrough process.
		<br>
		@since 401 version of the software
		*/
		class SOPHIS_FUND_BASE CSAmLookthroughHook : public sophis::portfolio::CSRLookthroughHook
		{
		public:
			CSAmLookthroughHook();
			virtual ~CSAmLookthroughHook();

			/* Check gLookthroughHook and calls GetBenchmarkHook
			*/
			static const sophis::instrument::CSRInstrument* GetFundBenchmark(const sophis::value::CSAMFundBase* fund, sophis::portfolio::PSRExtraction extraction);

		protected:
			/* Get the fund benchmark to split when processing lookthrough in a criteria extraction 
			*  for a given fund which has no breakdown
			*/
			virtual const instrument::CSRInstrument* GetFundBenchmarkHook(const sophis::value::CSAMFundBase* fund, sophis::portfolio::PSRExtraction extraction) const = 0;

			/* Callback when processing lookthrough in a criteria extraction
			*/
			virtual bool SplitInstrumentHook(const sophis::instrument::CSRInstrument *inst, sophis::portfolio::PSRExtraction extra) const;
		};

	}
}

#endif // _SPHAM_LOOKTHROUGH__HOOK_H_