#pragma once

#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphTabButton.h"
#include <SphInc/gui/SphEditList.h>
#include "SphInc/tools/SphAlgorithm.h"
#include "SphTools/SphPrototype.h"

#include "SphGUIComponentsExports.h"

#define DECLARE_AM_BROWSER_PAGE(C) \
public: \
	sophis::gui::CSRFitDialog* Clone() const { return new C; }

#define	INITIALISE_FORMAT_AM_BROWSER_PAGE(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)

namespace sophis {
	namespace gui {

		class SOPHIS_GUI_COMPONENTS CSAmBrowserPage : public sophis::gui::CSRTabPage
		{
		public:
			struct InstrumentInfos
			{
				char reference[40];
				char ccy[5];
				char market[40];
				double Last;
				double Bid;
				double Ask;
				double tradingUnit;
			};

			CSAmBrowserPage();
			virtual ~CSAmBrowserPage();

			// This method should return informations that will be displayed in the instrument
			// informations section of the dialogue (last/name)... and is called on each element validation
			virtual InstrumentInfos GetInstrumentInfos()const;

			// This method must return 0 if there is no proper instrument selected
			// This is use to get the sicovam of the instrument
			// If the instrument need to be created, then it is to be done in this method
			// Called on the OK button and BrowserQuiter::Quit
			virtual long GetInstrumentCode();

			// This is used to change the order in left browser list
			// bigger is this number and higher is the prototype in the list
			// Reserved number are :
			// Main Browser : 100
			// Foreign Exchange : 90
			// Listed Options : 80
			// Listed Futures : 70
			// If not overloaded , this method will return 0, this mean that all prototypes with no display order
			// will be displayed in the bottom of the list in alphabetical order
			virtual long GetDisplayOrder();

			typedef sophis::tools::CSRPrototype<CSAmBrowserPage, const char*, sophis::tools::less_char_star> prototype;
			static prototype& GetPrototype();

			void ElementValidation(int EAId_Modified); // overload

		protected:

			// If the sicovam is known, then you can use this method to fill an instrument InstrumentInfos
			InstrumentInfos GetInstrumentInfos(long sicovam)const;
		};

		// This class can be sent to any component to close the window
		class BrowserQuiter
		{
		public:
			BrowserQuiter(CSAmBrowserPage* page);

			// This can be used to close the browser window
			// @param getCode : if set to true, then the browser dialog will call 
			// GetInstrumentCode and return the code to the parent window
			void Quit(bool getCode);
		private:
			CSAmBrowserPage* fPage;
		};
	};
}
