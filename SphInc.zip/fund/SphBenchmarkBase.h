#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHBENCHMARKBASE_H__
#define __SOPHIS_VALUE_SPHBENCHMARKBASE_H__


// Toolkit includes
#include "SphFundBaseExports.h"
#include "SphInc/market_data/SphMarketData.h"
#include "SphInc/portfolio/SphExtraction.h"
#include "SphInc/value/benchmark/SphBenchmarkBreakdownNodeKey.h"

namespace sophis
{
	namespace value
	{
		class CSAMFundBreakdown;


		/**
		 *  Interface class to get benchmarks from other libs depending on SophisFundBase.
		 */
		class SOPHIS_FUND_BASE ISAmBenchmarkBase
		{
		public:
			/**
			 *  Get the fund breakdown corresponding to the composition of the benchmark.
			 */
			virtual CSAMFundBreakdown* GetNewEquivalentFundBreakdown(sophis::portfolio::PSRExtraction extraction = sophis::portfolio::CSRExtraction::PSRMain,
			                                                         const sophis::market_data::CSRMarketData &marketData = *sophis::market_data::gApplicationContext) const = 0;

			/**
			 *  Get the underlyings corresponding to the composition of the benchmark.
			 */
			virtual void GetUnderlyings(_STL::set<long>& underlyings) const = 0;

			/**
			*	Get the broken-down composition.
			*	Internal use only.
			**/
			virtual bool GetBreakdown(	_STL::map<long, double> & breakdown,
										sophis::portfolio::PSRExtraction extraction = sophis::portfolio::CSRExtraction::PSRMain,
										const sophis::market_data::CSRMarketData * marketData = sophis::market_data::gApplicationContext,
										long benchmarkOffset = 0) const = 0;
			/**
			*	Same as GetBreakdown
			*	but only returns what users input in the Persistent weight/notional/market value column
			*   not transform what users input to weights.
			**/
			virtual bool GetPersistentWeight(	benchmark::TBenchmarkBreakdown & breakdown,
										sophis::portfolio::PSRExtraction extraction = sophis::portfolio::CSRExtraction::PSRMain,
										const sophis::market_data::CSRMarketData * marketData = sophis::market_data::gApplicationContext,
										long benchmarkOffset = 0,
										bool rescale = true) const = 0;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHBENCHMARKBASE_H__