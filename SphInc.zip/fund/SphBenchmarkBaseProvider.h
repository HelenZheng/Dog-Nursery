#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHBENCHMARKBASEPROVIDER_H__
#define __SOPHIS_VALUE_SPHBENCHMARKBASEPROVIDER_H__


// Toolkit includes
#include "SphFundBaseExports.h"


namespace sophis
{
	namespace instrument
	{
		class CSRInstrument;
	}

	namespace value
	{
		class ISAmBenchmarkBase;

		class SOPHIS_FUND_BASE ISAmBenchmarkBaseProvider
		{
		public:
			/** 
			 *  Gets the benchmark associated to a given code.
			 *
			 *  @param sicovam is the identifier of your benchmark.
			 *  @return a pointer on a CSAMBenchmark or NULL if sicovam is not the identifier of a benchmark. 
			 */
			virtual const ISAmBenchmarkBase* GetBenchmark(long sicovam) const = 0;

			/** 
			 *  Equivalent to dynamic_cast<const CSAMBenchmark *>().
			 *
			 *  @param theInstrument is a pointer on an instrument.
			 *  @return this instrument cast in CSAMBenchmark if it is a benchamrk, NULL otherwise.
			 */
			virtual const ISAmBenchmarkBase* GetBenchmark(const sophis::instrument::CSRInstrument* instrument) const = 0;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHBENCHMARKBASEPROVIDER_H__