#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPH_AM_BREAKDOWN_CONSTRAINT_H_
#define _SPH_AM_BREAKDOWN_CONSTRAINT_H_


#include "SphInc/fund/SphFundBaseExports.h"
#include "SphInc/tools/SphValidation.h"

#include "SphTools/SphCommon.h"
#include "SphTools/SphPrototype.h"
#include "SphSDBCInc/SphSQLQuery.h"

#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(set)


#define CONSTRAINT_NAME_SIZE 256
#define CONSTRAINT_CRITERION_NAME_SIZE 40


#define DECLARATION_BENCHMARK_CONSTRAINT_ACTION(derivedClass)			DECLARATION_PROTOTYPE(derivedClass, sophis::value::CSAMBreakdownConstraintAction)
#define	INITIALISE_BENCHMARK_CONSTRAINT_ACTION(derivedClass, name)		INITIALISE_PROTOTYPE(derivedClass, name)


namespace sophis {

	namespace tools {

		struct VoteException;

		namespace dataModel {

			class DataSet;

		}
	}

	namespace value {

		class CSAMSqlQueryHelper;

			/**
			*	For more complex constraints (e.g. exclude several criterion values),
			*	users should use buckets.
			**/
			enum eInclusionType
			{
				itInclusionTypeBegin = 1,
				itIncludeOnly = itInclusionTypeBegin,
				itExclude,
				itInclusionTypeEnd,
			};

			class SOPHIS_FUND_BASE CSAMBreakdownConstraint
			{
			public:

				CSAMBreakdownConstraint();

				CSAMBreakdownConstraint(long id, eInclusionType inclusionType, _STL::string& name, _STL::string& filter);

				CSAMBreakdownConstraint(const CSAMBreakdownConstraint & toCopy);
				
				virtual ~CSAMBreakdownConstraint();

				bool Equals(const CSAMBreakdownConstraint & toCompare, bool compareId = true) const;

				CSAMBreakdownConstraint * Clone() const;

				long GetId() const;
				void SetId(long id);

				_STL::string GetName() const;
				void SetName(const _STL::string & name);
				
				eInclusionType GetInclusionType() const;
				_STL::string GetInclusionTypeName() const;

				bool IsValid(_STL::string * invalidityReason = 0) const;

				

				_STL::string GetFilter() const;
				void SetFilter(const _STL::string & filter);
				
				void SetInclusionType(eInclusionType inclusionType);
				

				/**
				*	The reasons why the instrument was accepted / rejected are logged in DEBUG verbosity.
				*	@return true if the specified instrument satisfies the constraint, false otherwise. 
				**/
				bool AcceptInstrument(long instrumentCode) const;

				/**
				*	Save a constraint to database (whether to create it or to modify it).
				*	Does not commit nor send any coherency event.
				*	A new identifier is generated and set from a Oracle sequence if necessary.
				*	@throw sophis::sophis::tools::VoteException, sophis::sql::OracleException, sophisTools::base::ExceptionBase.
				**/
				void Save();


				/**
				*	XML Import / Export. 
				**/

				/**
				*	Retrieve the constraint description.
				*	This description must include the constraint root element.
				*	@param dataSet is the description to be filled with this component.
				**/
				void GetDescription(sophis::tools::dataModel::DataSet & dataSet) const;

				/**
				*	Import the benchmark constraint data from a XML data set.
				*	This may modify an existing constraint or create a new one.
				*	@return the internal identifier of the constraint found, modified or created.
				**/ 
				static long UpdateFromDescription(const sophis::tools::dataModel::DataSet & constraintDataSet);


				/**
				*	Remove a constraint from database.
				*	Does not commit nor send any coherency event.
				*	@throw sophis::sophis::tools::VoteException, sophis::sql::OracleException, sophisTools::base::ExceptionBase.
				**/
				static void Delete(long constraintId);

				/**
				*	@return "Unsupported" if the inclusion type specified is not supported. 
				**/
				static _STL::string GetInclusionTypeNameFromValue(eInclusionType inclusionType);
				
				/**
				*	@return 0 if the inclusion type name specified is not supported. 
				**/
				static eInclusionType GetInclusionTypeValueFromName(const _STL::string & inclusionTypeName);

			protected:

				// Persistent identifier of the constraint in database.
				long fId;

				// Name of the constraint.
				_STL::string fName;

				// Type of the constraint.
				eInclusionType fInclusionType;

				//filter
				_STL::string fFilter;

				static const char * __CLASS__;

			};

			typedef _STL::map<long, CSAMBreakdownConstraint> TBreakdownConstraintMap;


			/**
			*	Class managing all the constraints available (Singleton).
			**/
			class SOPHIS_FUND_BASE CSAMBreakdownConstraintMgr : public virtual TBreakdownConstraintMap
			{
			public:

				/**
				*	Get the one instance gathering all the constraints defined that are accessible for the current user.
				*	@param forceLoad If true, the data is loaded from database if it has never been before.
				*	Otherwise, as long as the first loading never occurred, this method will return NULL.
				*	@param forceReload If true, the data is loaded from database even if it has already been loaded before.
				*	If forceLoad is false and forceReload is true, the data is reloaded.
				*	@return null if the data loading has never been required.
				*	@throw OracleException.
				**/
				static const CSAMBreakdownConstraintMgr * GetInstance(bool forceLoad = true, bool forceReload = false);

				/**
				*	Get the const instance of a constraint stored in memory.
				*	Use with caution since the collection can be updated dynamically, so the pointer returned can be invalidated.
				*	@return NULL if no constraint could be found from the identifier supplied.
				**/
				const CSAMBreakdownConstraint * GetConstraint(long constraintId) const;

				/**
				*	Get the const instance of a constraint stored in memory that is identical to the one supplied, except for the identifier field.
				*	Use with caution since the collection can be updated dynamically, so the pointer returned can be invalidated.
				*	@return NULL if no satisfying constraint could be found.
				**/
				const CSAMBreakdownConstraint * GetConstraint(const CSAMBreakdownConstraint & toCompare) const;

				/**
				*	Get a copy of a constraint stored in memory. 
				**/
				bool GetConstraint(long constraintId, CSAMBreakdownConstraint & constraintData) const;

				static void SendConstraintsUpdatedEvent();

			protected:

				CSAMBreakdownConstraintMgr();

				/**
				*	Clear the map and load its contents from database.
				*	@throw OracleException.
				**/
				void Load();

				static CSAMBreakdownConstraintMgr * fInstance;
			};


			/**
			*	Data integrity.
			**/

			/**
			*	Constraint action interface. 
			**/
			class SOPHIS_FUND_BASE CSAMBreakdownConstraintAction
			{
			public:

				virtual ~CSAMBreakdownConstraintAction();

				/**
				*	By default, does nothing.
				**/
				virtual void VoteForCreation(const CSAMBreakdownConstraint & constraint)
					throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase);

				/**
				*	By default, does nothing.
				**/
				virtual void VoteForModification(const CSAMBreakdownConstraint & original, const CSAMBreakdownConstraint & newVersion)
					throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase);

				/**
				*	By default, does nothing.
				**/
				virtual void VoteForDeletion(long constraintId)
					throw (sophis::tools::VoteException, sophisTools::base::ExceptionBase);

				// Prototype type.
				typedef sophis::tools::CSRPrototype<CSAMBreakdownConstraintAction, _STL::string> prototype;

				/**
				*	Access to the prototype singleton.
				*	To add a trigger to this singleton, use INITIALISE_BENCHMARK_CONSTRAINT_ACTION.
				*	@see tools::CSRPrototype
				**/
				static prototype & GetPrototype();
			};

	}
}


#endif
