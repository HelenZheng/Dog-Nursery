#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXCHANGETRADEDFUND_H__
#define __SOPHIS_VALUE_SPHEXCHANGETRADEDFUND_H__


// Macros definitions
#define	INITIALISE_EXCHANGE_TRADED_FUND(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass,  name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExchangeTradedFundTemplate(name), hfEtf);
#define INITIALISE_EXCHANGE_TRADED_FUND_GUI(derivedClass, name, pageClass) \
	INITIALISE_PROTOTYPE(derivedClass, name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExchangeTradedFundTemplate(name, new pageClass), hfEtf);


// Toolkit includes
#include "SphExternalFundBase.h"
#include "SphExchangeTradedFundTemplate.h"
#include "SphInc\fund\SphFundBreakdown.h"


namespace sophis
{
	namespace instrument
	{
		class CSRPackage;
		class CSREtfStructure;
		class CSREtfStructureItem;
		class CSRPackage;
	}

	namespace value
	{
		class CSAMFundBreakdownBottomUp;

		class SOPHIS_FUND_BASE CSAMDefaultMetaModelExchangeTradedFund : public virtual CSAMDefaultMetaModelExternalFundBase
		{
		public:
			DECLARATION_META_MODEL(CSAMDefaultMetaModelExchangeTradedFund);
			virtual ~CSAMDefaultMetaModelExchangeTradedFund();

			virtual double GetTheoreticalValue(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context) const OVERRIDE;

			virtual double GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long date, market_data::eTaxCreditPercentageType forEvaluation, 
											const market_data::CSRMarketData& context,
											const instrument::CSRInstrument* initialForward = NULL) const OVERRIDE;

			virtual void	GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long					 *futureDates,
											double					 *val,
											short					 dateCount,
											market_data::eTaxCreditPercentageType forEvaluation,
											const market_data::CSRMarketData		 &context,
											const instrument::CSRInstrument*		initialForward = NULL) const OVERRIDE;

			virtual	void	GetLinearValue(const sophis::instrument::CSRInstrument& instr, 	double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;
			virtual void	GetForwardQuantoPrice(const sophis::instrument::CSRInstrument& instr, 	long					 *futureDates,
												double					 *val,
												int					 dateCount,
												market_data::eTaxCreditPercentageType forEvaluation,
												long strikeCurrency,
												double overVolatility,
												NSREnums::eVolatilityType volatType,
												bool put,
												const market_data::CSRMarketData		 &context) const OVERRIDE;

		protected:
			virtual void ComputeAllCore(sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;

			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSROption& option, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
			virtual void GetParentDeltaRiskSources(const instrument::CSRInstrument& underlyer, const instrument::CSRFuture& future, /*out*/ sophis::CSRComputationResults& rs) const OVERRIDE;
		private:
			static const char* __CLASS__;
		};

		/**
		 *  Class for exchange traded funds (ETF).
		 */
		class SOPHIS_FUND_BASE CSAMExchangeTradedFund : public virtual CSAMExternalFundBase
		{
		public:
			/** @name Construction - Destruction */
			//@{
			CSAMExchangeTradedFund();
			virtual ~CSAMExchangeTradedFund();

			const sophis::finance::CSRMetaModel* GetDefaultMetaModel() const;

			static CSAMExchangeTradedFund* CreateInstance(long code);
			//@}

			/** @name Initialization */
			//@{
			virtual void Initialise();
			virtual void Initialise(long instrumentCode, double dateHisto = 0);
			virtual void Initialise(const CSAMFundBase* fund);

			virtual void LoadSpecificData(); 
			//@}

			/** @name Prototype management */
			//@{
			typedef sophis::tools::CSRPrototype<CSAMExchangeTradedFund, const char*, sophis::tools::less_char_star> prototype;
			static prototype &GetPrototype();
			//@}

			virtual SSAmFundBaseLoadHelper* GetNewLoadHelper() const;
			virtual SSAmFundBaseLoadHelper* GetNewSaveHelper() const;
			virtual void InitFromLoadHelper(const SSAmFundBaseLoadHelper* loadHelper);

			virtual sophis::instrument::CSRInstrument* Clone() const;

			static const CSAMExchangeTradedFund* GetFund(long sicovam);
			static const CSAMExchangeTradedFund* GetFund(const sophis::instrument::CSRInstrument* theInstrument);

			static void GetExchangeTradedFundList(_STL::vector<long> &result, bool reload = false);
			static void DisposeExchangeTradedFundList();

			static const char* GetFundTypeName();
			virtual const char*	GetHedgeFundTypeName() const;

			virtual CSAMFundBaseHistoryData* new_HistoryData() const;
			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;

			virtual CSAMFundBaseDealUpdate* new_FundDealUpdater() const;

			void GetComposition(sophis::instrument::CSREtfStructure &composition) const;

			/** @name Calculation */
			//@{

			//virtual void InitialiseRecomputeAll();

			virtual	double GetDerivativeSpot(const market_data::CSRMarketData &context) const;
			//@}

			/** @name Lookthrough */
			//@{
			virtual bool HasLookthroughComponents(sophis::portfolio::PSRExtraction extraction) const;
			virtual void GetLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                      sophis::portfolio::PSRExtraction extraction,
			                                      const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                      const sophis::portfolio::eLookthroughType splitByComponents,
			                                      double* evalInstrument,
			                                      double* evalLookthroughDeals) const;

			virtual const CSAMFundBreakdown* GetBreakdown() const;

			const CSAMFundBreakdownBottomUp* GetConcreteBreakdown() const;
			void GetPricedBreakdown(double& totalAssetValue,CSAMFundBreakdownMap & m) const;
			void SetBreakdown(const CSAMFundBreakdownBottomUp &breakdown);
			//@}

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;
			//@}
			/**
			*	Returns the underlying package 
			*	@return the underlying package 
			*/
			virtual sophis::instrument::CSRPackage * GetPackage() const;
			
			/**
			*	Updates the underlying package 
			*/
			virtual void UpdatePackage();

			/*	Add Cash to the fund
			Parameter: amount of cash + curreny
			*/
			void AddCash(double amount, long curreny);
			
			/*Remove the cash from fund for particular currency 
			*/
			void RemoveCash(long curreny);

			/*Reove all cash*/
			void ClearCash();

			/*Populate pCiiashAmountByCurrency map*/
			void LoadCashData();

			const _STL::map<long,double>& GetCashByCurrency()const{return pCashAmountByCurrency;} 

			void SetBeta(const double value);
			double GetBeta() const;

			void SetETFType(const eETFType value);
			eETFType GetETFType() const;


		protected:
			virtual const char* GetXMLRootName() const;
			virtual sophis::static_data::CSAMFundBaseXMLDescription* new_XMLDescriptor() const;
			virtual sophis::static_data::CSAMFundBaseXMLUpdate* new_XMLUpdater();

			double fETFBeta;
			eETFType fETFType;

		private:
			_STL::map<long,double> pCashAmountByCurrency;
			void LoadBreakdown();

			static void GetCompositionForInstrument(long code, sophis::instrument::CSREtfStructureItem &structureItem);
			static void GetCompositionForPackage(const sophis::instrument::CSRPackage &package, sophis::instrument::CSREtfStructureItem &structureItem);

		private:
			// Traces
			static const char* __CLASS__;

			_STL::auto_ptr<CSAMFundBreakdownBottomUp> fBreakdown;
		};

	}
}


#endif // __SOPHIS_VALUE_SPHEXCHANGETRADEDFUND_H__