#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDHISTORYDATA_H__
#define __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDHISTORYDATA_H__


// Toolkit includes
#include "SphFundBaseHistoryData.h"
#include "SphInc/SphMacros.h"

namespace sophis
{
	namespace sql
	{
		class CSROracleException;
	};


	namespace value
	{
		struct SSAmFundBaseHistoryDBLoadHelper;


		class SOPHIS_FUND_BASE CSAMExchangeTradedFundHistoryDB : public virtual CSAMFundBaseHistoryDB
		{
		public:
			CSAMExchangeTradedFundHistoryDB();
			CSAMExchangeTradedFundHistoryDB(const SSAmFundBaseHistoryDBLoadHelper &loadHelper);
			CSAMExchangeTradedFundHistoryDB(const CSAMFundBaseHistoryDB& fundBase);
			virtual ~CSAMExchangeTradedFundHistoryDB();

			virtual CSAMFundBaseHistoryDB* Clone() const;
			virtual sophis::sql::CSRStructureDescriptor* GetDescriptor() const;
			virtual _STL::string GetSelectQuery(long fundCode, long date1, long date2, bool decreasingDate) const;
			virtual _STL::string GetInsertQuery(long fundCode) const;
			virtual _STL::string GetUpdateQuery(long fundCode) const;
		};


		class SOPHIS_FUND_BASE CSAMExchangeTradedFundHistoryData : public virtual CSAMFundBaseHistoryData
		{
		public:
			typedef _STL::vector<CSAMExchangeTradedFundHistoryDB> ExchangeTradedFundHistoryDBList ;

		public:
			CSAMExchangeTradedFundHistoryData(long fundCode);
			virtual ~CSAMExchangeTradedFundHistoryData();

			virtual CSAMFundBaseHistoryData* Clone() const;
			const ExchangeTradedFundHistoryDBList &GetHistoryList() const;


		protected:
			CSAMExchangeTradedFundHistoryData();

			virtual CSAMFundBaseHistoryDB* new_HistoryDB() const;

			virtual void ExecuteSelectQuery(const _STL::string& request, const sophis::sql::CSRStructureDescriptor* desc, long startDate, long endDate, bool decreasingDate) 
#ifndef GCC_XML
				throw(sophis::sql::CSROracleException) OVERRIDE
#endif
				;

		protected:
			ExchangeTradedFundHistoryDBList fHistoryDB;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDHISTORYDATA_H__