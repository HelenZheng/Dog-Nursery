#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDLOADHELPER_H__
#define __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseLoadHelper.h"


namespace sophis
{
	namespace value
	{
		class CSAMExchangeTradedFund;


		/**
		*  Helper structure to load fund data from database.
		*  Inherit from this struct when creating a fund based on CSAMExternalFund.
		*/
		struct SOPHIS_FUND_BASE SSAmExchangeTradedFundLoadHelper : public SSAmFundBaseLoadHelper
		{
			// Default constructor.
			SSAmExchangeTradedFundLoadHelper();
			// Constructor from a CSAMExternalFund.
			SSAmExchangeTradedFundLoadHelper(const CSAMExchangeTradedFund &fund);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmExchangeTradedFundLoadHelper();

			virtual int GetBaseClassSize() const;
			virtual int GetClassSize() const;

			// ETF Fields
			double fETFBeta;
			eETFType fETFType;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDLOADHELPER_H__