#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDTEMPLATE_H__
#define __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDTEMPLATE_H__


// Toolkit includes
#include "SphFundBaseTemplate.h"


namespace sophis
{
	namespace value
	{
		class CSAMExchangeTradedFund;


		class SOPHIS_FUND_BASE CSAMExchangeTradedFundTemplate : public virtual CSAMFundBaseTemplate
		{
		public:
			// Default constructor
			CSAMExchangeTradedFundTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype = 0);
			// Destructor
			virtual ~CSAMExchangeTradedFundTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const;

			// Clone the instrument and initialize it
			CSAMExchangeTradedFund* CreateInstrument() const;
			// Clone the instrument and initialize it with code
			CSAMExchangeTradedFund* CreateInstrument(long code) const;
			// Clone the instrument and initialize it with another one
			CSAMExchangeTradedFund* CreateInstrument(const CSAMFundBase* instrument) const;

			virtual void BuildSQL();

		protected:
			// Default constructor
			CSAMExchangeTradedFundTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXCHANGETRADEDFUNDTEMPLATE_H__