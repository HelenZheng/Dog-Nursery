/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphExternalFund.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Class that handles external funds.
*
*/

#ifndef _SphExternalFund_H_
#define _SphExternalFund_H_

/**
* System includes
*/
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(functional)

/**
* Application includes
*/
#include "SphInc\portfolio\SphTransaction.h"
#include "SphExternalFundBase.h"
#include "SphExternalFundTemplate.h"
#include "SphInc/static_data/SphSector.h"



// Macros definitions
#define	INITIALISE_EXTERNAL_FUND(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass,  name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExternalFundTemplate(name), hfExternal);/*\
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExternalFundTemplate(name), hHedgeFundClass); // Necessary to audit the classes of the fund based on this template
*/
#define INITIALISE_EXTERNAL_FUND_GUI(derivedClass, name, pageClass) \
	INITIALISE_PROTOTYPE(derivedClass, name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExternalFundTemplate(name, new pageClass), hfExternal);/*\
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMExternalFundTemplate(name, new pageClass), hHedgeFundClass); // Necessary to audit the classes of the fund based on this template
*/


/**
* defines
*/
#define PERF_FEE_COMMENT_STRING_LENGTH 256
#define MGT_FEE_COMMENT_STRING_LENGTH 256


#ifdef _WIN32
#	pragma warning(push)
#	pragma warning(disable: 4251) // warning C4251: class 'type' needs to have dll-interface to be used by clients of class 'type2'
#endif

/**
 *  typedef and classes
 */
namespace sophis 
{
	namespace value	
	{
		class CSAMExternalFundTemplate;
		class CSAMFundBreakdown;
		class CSAmInvestmentRulesFieldGroup;
		class CSAmInvestorsFieldGroup;
		class CSAmReturnsFieldGroup;
		class CSAmRiskFieldGroup;
		class CSAmStructureFieldGroup;
		class CSAmFeesFieldGroup;
		class CSAmEFCurrencyBreakdownSwitch;
		class CSAMFundClassBaseLinker;

		class SOPHIS_FUND_BASE CSAMDefaultMetaModelExternalFund : public virtual CSAMDefaultMetaModelExternalFundBase
		{
		public:
			DECLARATION_META_MODEL(CSAMDefaultMetaModelExternalFund);
			virtual ~CSAMDefaultMetaModelExternalFund();

			virtual double GetDuration(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData& context, const sophis::CSRComputationResults* results = 0) const OVERRIDE;
			virtual double	GetTheoreticalValue(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetFirstDerivative(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual double	GetSecondDerivative(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
		protected:
			virtual void	ComputeAllCore(sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, sophis::CSRComputationResults& results) const OVERRIDE;
		private:
			static const char* __CLASS__;
		};
		

		/** Class that handles external funds. */
		class SOPHIS_FUND_BASE CSAMExternalFund : public virtual CSAMExternalFundBase
		{
		public:
			CSAMExternalFund();
			virtual ~CSAMExternalFund();
			static CSAMExternalFund* CreateInstance(long code);

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const OVERRIDE;

			// internal
			typedef sophis::tools::CSRPrototype<CSAMExternalFund, const char *, sophis::tools::less_char_star> prototype;
			static prototype & GetPrototype();

			//=======  ACCESSORS  =======

			/// Initialise (or reinitialise) all fund data
			virtual void Initialise();

			/** 
			*  Initialise all fund data based on an instrument code and a date
			*  (automatically calls CSAMExternalFundBase::Load)
			*
			*  @param instrumentCode is a code of an instrument as found in table INFOS_HISTO
			*  @param dateHisto is an optional past date to retrieve an audited version of a fund
			*/
			virtual void Initialise(long instrumentCode, double dateHisto = 0);

			/** 
			*	Copy all data from another fund
			*	
			*	@param instrument is a pointer on another fund
			*	if this instrument is not a fund, nothing is done
			*/
			virtual void Initialise(const CSAMFundBase* instrument);

			/**
			*  Return the loading helper structure to use when loading the concrete fund class.
			*  Must return a new instance dynamically allocated of the concrete structure.
			*  This instance will be automatically deleted once loading as been performed.
			*/
			virtual SSAmFundBaseLoadHelper* GetNewLoadHelper() const;

			/**
			*  Fill the fund with data stored in the loading helper struct.
			*  The base class InitFromLoadStruct() must be called first.
			*/
			virtual void InitFromLoadHelper(const SSAmFundBaseLoadHelper* loadHelper);

			/**
			 *  Return the loading helper structure to use when saving the concrete fund class.
			 *  Must return a new instance dynamically allocated of the concrete structure, filled with correct data from the fund.
			 *  This instance will be automatically deleted once saving has been performed.
			 */
			virtual SSAmFundBaseLoadHelper* GetNewSaveHelper() const;

			/** Load infos depending on the type of the fund. Called by Load() */
			virtual void LoadSpecificData(); 

			/** 
			*	Create a new copy of a fund 
			*	
			*	@return a newly allocated fund
			*/
			sophis::instrument::CSRInstrument* Clone() const; // overriden from sophis::instrument::CSRInstrument

			/** 
			*	Gets the internal fund associated to a given code
			*	
			*	@param folio is the identifier of your fund.
			*	the method GetFund returns a pointer on a CSAMFund 
			*	or NULL if sicovam is not the identifier of an external fund 
			*/
			static const CSAMExternalFund* GetFund(long sicovam);
			static const CSRComputationResults* GetFundComputationResults(long sicovam);
			static CSRComputationResults& GetOrCreateFundComputationResults(long sicovam);
			static void EraseFundComputationResults(long sicovam);

			/** 
			*	Equivalent to dynamic_cast<const CSAMFund*>() but quicker.
			*	
			*	@param theInstrument is a pointer on an instrument
			*	@return this instrument cast in CSAMFund if it is a fund or NULL
			*/
			static const CSAMExternalFund* GetFund(const sophis::instrument::CSRInstrument* theInstrument);

			/** 
			*	Returns a string depending on a fund type
			*	
			*	@param type is a fund type
			*	@return a string to describe this type of funds
			*/
			static const char* GetFundTypeName() { return "external"; };
			
			virtual const char*	GetHedgeFundTypeName() const { return GetFundTypeName(); };

			//=======  CALCULATION  =======

			// all methods overridden from CSRInstrument

			//virtual void	InitialiseRecomputeAll();

			//virtual long	GetUnderlying(int whichUnderlying) const;
			virtual	double	GetDerivativeSpot(const market_data::CSRMarketData& context) const;

			virtual bool	FastRecomputation(const market_data::CSRMarketData& context, sophis::CSRComputationResults& results, long underlyingCode);

			//======= FUND DEALS COMPUTATION =======

			/**
			*	Returns an object in charge of computing a fund deal data (shares number, fees and amounts).
			*	It MUST BE DELETED.
			**/
			virtual CSAMFundBaseDealUpdate * new_FundDealUpdater() const;

			virtual bool SpecialTransaction(portfolio::CSRTransaction &transaction, RecalculeTransaction type) const;

			//=======  Lock up  =======

			enum ELockUpType
			{
				luUnlocked,
				luHard,
				luSoft
			};

			struct SLockUpValue
			{
				double pctValue;
				double minValue;
			};

			struct SOPHIS_FUND_BASE SLockUpRule
			{
				ELockUpType type;
				long date;
				SLockUpValue value;

				bool operator== (const SLockUpRule&)const;
			};

			class SOPHIS_FUND_BASE LockUpRules : public virtual _STL::vector<SLockUpRule>
			{
			public :
				void				GetLockUpRulesSortedCopy(long subscriptionDate, LockUpRules& rules) const;
				void				SortOnPositionDate();
				void				SortOnSubscriptionDate(long subscriptionDate);
				ELockUpType			IsLockedUp(long redemptionDate, long subscriptionDate) const;
				SLockUpValue		GetLockUpValue(long redemptionDate, long subscriptionDate) const;

				// Allow to get the lock up limits after a specific date
				long				GetUnlockLimit(long SubscriptionDate, long date=0) const;
				long				GetNextLockupLimit(long SubscriptionDate, long date=0) const;
			};

			const LockUpRules&				GetLockUpRules() const { return fLockUpRules; }
			void							SetLockUpRules(const LockUpRules & lockUpRules);

			ELockUpType						IsLockedUp(long redemptionDate, long subscriptionDate) const;
			SLockUpValue					GetLockUpValue(long redemptionDate, long subscriptionDate) const;

			// Allow to get the lock up limits after a specific date
			long							GetUnlockLimit(long SubscriptionDate, long date=0) const;
			long							GetNextLockupLimit(long SubscriptionDate, long date=0) const;

			//======= EXTERNAL FUND =======================
			long ConventRelativeDateFromString(_STL::string date, long referenceDate) const;

			long GetLockUpPeriod() const;
			void SetLockUpPeriod(const long lockUpPeriod);

			long GetCutOffTime()const;
			void SetCutOffTime(const long cutOffTime);

			long GetRedemptionLag()const;
			void SetRedemptionLag(const long redemptionLag);

			long GetSubscriptionLag()const;
			void SetSubscriptionLag(const long subcriptionLag);

			long GetSettlementDate(long date) const;
			long GetSettlementDateNoLag(long date) const;
			long GetNavDate(_STL::unique_ptr<sophis::portfolio::CSRTransaction> ptr)const;

			double GetLateRedemptionFees()const;
			void SetLateRedemptionFees(const double lateRedemptionFees);

			double GetMinimalAmount()const;
			void SetMinimalAmount(const double minimalAmount);

			bool GetUseLockUpRules()const;
			void SetUseLockUpRules(const bool useLockUpRule);


			long GetSubscriptionTime()const;
			void SetSubscriptionTime(const long subscriptionTime);

			_STL::string GetSubscriptionDate()const;
			void SetSubscriptionDate(const _STL::string relativeDate);

			long GetRedemptionTime()const;
			void SetRedemptionTime(const long redemptionTime);

			_STL::string GetRedemptionDate()const;
			void SetRedemptionDate(const _STL::string relativeDate);

			_STL::string GetDelayRedemptionSettlement()const;
			void SetDelayRedemptionSettlement(const _STL::string delayRedemptionSettlement);

			_STL::string GetForceMarketLag()const;
			void SetForceMarketLag(const _STL::string ForceMarkerLag);

			bool HasSeries() const;
			void HasSeries(const bool hasSeries);

			/** @name External fund data model */
			//@{
			struct SOPHIS_FUND_BASE TopHolding
			{
				TopHolding(long instrumentId = 0, double weight = 0);

				bool operator>(const TopHolding &other) const;
				bool operator==(const TopHolding &other) const;

				long fInstrumentId;
				double fWeight;
			};

			typedef _STL::set<long> PrimeBrokerContainer;
			typedef _STL::vector<TopHolding> TopHoldingVector;

			// ========  Generic data  ========
			// Specific fund fields group access
			CSAmInvestmentRulesFieldGroup* GetInvestmentRulesDataGroup() const;
			CSAmInvestorsFieldGroup* GetInvestorsDataGroup() const;
			CSAmStructureFieldGroup* GetStructureDataGroup() const;
			CSAmFeesFieldGroup* GetFeesDataGroup() const;


			double GetSingleDoubleFieldFromHistory(_STL::string field, long date) const;
			// ========  Fees  ========
			double GetHighwatermarkFromHistory(long date) const;
			double GetHighwatermark() const;
			void SetHighwatermark(double highwatermark);
			double GetHurdleRate() const;
			void SetHurdleRate(double hurdleRate);
			double GetPerformanceFee() const;
			void SetPerformanceFee(double fee);
			EPeriodicity GetPerformanceFeeFrequency() const;
			void SetPerformanceFeeFrequency(EPeriodicity frequency);
			const _STL::string &GetPerformanceFeeComment() const;
			void SetPerformanceFeeComment(const _STL::string &comment);
			double GetEqualisationCreditFromHistory(long date) const;

			double GetManagementFee() const;
			void SetManagementFee(double fee);
			EPeriodicity GetManagementFeeFrequency() const;
			void SetManagementFeeFrequency(EPeriodicity frequency);
			double GetRebate() const;
			void SetRebate(double rebate);
			const _STL::string &GetManagementFeeComment() const;
			void SetManagementFeeComment(const _STL::string &comment);

			// ========  Structure  ========
			long GetStrategyId() const;
			void SetStrategyId(long strategy);
			/// Return the top holdings of the fund ordered by decreasing weight.
			void GetTopHoldings(TopHoldingVector &topHoldings) const;
			void SetTopHoldings(const TopHoldingVector &topHoldings);
			//@}

			//=======  SECTORIAL COMPOSITION (EXTERNAL FUNDS)   =======

			/** 
			*	@return the number of sectors defined in the sectorial composition for this fund
			*
			*	@throws GeneralException if fund is not an internal fund
			*	@see GetNthSectorComposition
			*	@see GetSectorComposition
			*/
			int	GetSectorCompositionCount() const;

			/** 
			*	@param i is a value between 0 and GetSectorCompositionCount()-1
			*	@return the i-th sector
			*	@throws GeneralException if fund is not an internal fund or i is out of range
			*	@see GetSectorCompositionCount
			*/
			sophis::static_data::SSSectorComposition GetNthSectorComposition(int i) const;

			/** 
			*	Returns a vector describing the sectorial composition of this fund
			*
			*	@return the sectorial composition
			*	@see SSSectorComposition
			*/
			_STL::vector<sophis::static_data::SSSectorComposition> GetSectorComposition() const { return fSectorComposition; }

			/** 
			*	Allows to change the sectorial composition (handles audit trail)
			*
			*	@param s is the new sectorial composition
			*	@throws GeneralException if fund is not an internal fund or i is out of range
			*	@see SSSectorComposition
			*/
			void SetSectorComposition(const _STL::vector<sophis::static_data::SSSectorComposition>& s);


			//=======  BREAKDOWN for Look-Through (EXTERNAL FUNDS)  =======

			/**
			*	Get the breakdown data of the fund.
			*	By default, a fund has an empty instrument list as a breakdown.
			*	@return NULL if no breakdown data is attached to the fund.
			*	@see CSAMFundBreakdown.
			**/
			virtual const CSAMFundBreakdown * GetBreakdown() const;

			/**
			*	Copy the supplied breakdown into the fund and
			*	signal the fund as modified.
			**/
			void SetBreakdown(const CSAMFundBreakdown & breakdown);
						/**
			*	It's a more generic function. Specifying a fund data member by a keyword (the name), the function
			*	returns the associated value.Authorized names include :
			*		"Quotity"
			*		"Benchmark"
			*		"IssueDate"
			*		"Parameter:xxxxx" where xxxx is a parameter name
			*		"xxxxx" where xxxx is an indicator name
			*/
			bool GetIndicator(const _STL::string& indicatorName, double& theResult) const;

			/**
			*	Retrieve the list of the existing External funds ordered by name.
			*/ 
			static void GetExternalFundList(_STL::vector<long>& result, bool reload=false);
			static void DisposeExternalFundList();


			/** Return an instance of CSAMFundBaseHistoryData used to get historic data 
			*	The pointer MUST BE DELETED.
			*/
			virtual CSAMFundBaseHistoryData* new_HistoryData() const;

			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;

			/*Add Equalization Amount*/
			virtual const portfolio::CSRAssetValueCalculation* GetAssetValueCalculation() const OVERRIDE;

			/**
			*	Look-through breakdown.
			*	INTERNAL USE.
			*	@version 3.3.2
			**/
			virtual bool HasLookthroughComponents(sophis::portfolio::PSRExtraction extraction) const;
			virtual void GetLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                       sophis::portfolio::PSRExtraction extraction,
			                                       const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                       const sophis::portfolio::eLookthroughType splitByComponents,
			                                       double* evalInstrument,
			                                       double* evalLookthroughDeals) const;

			static void SetLookthroughIndicator(const _STL::string& indicatorName);
			static const _STL::string& GetLookthroughIndicator();
			static void ResetLookthroughIndicator();

			//=======  SERIES OF SHARES   =======
			typedef _STL::vector<long> SeriesList;
			/** If the external fund use the series of shares method, returns the list of series */
			virtual SeriesList GetSeries() const;
			
			/** Retrieves either the official or the estimated NAV
			*	return the first estimated or official nav found
			*	(Does not take any other rule into account)
			*/
			double GetValuation(long date) const ;

			/** Retrieves the latest nav from the database, applying the priority 
			*	rule official >> valuation >> estimated if several are available
			*	for the same date
			*	The difference with GetValuation is that EOD process takes into account 
			*	the valuation NAV (stored by a previous EOD)
			*/
			double GetValuationForEOD(long date) const ;

			/** Saves the valuation at a given date to the database 
			* (column VALUATION in the historique table)
			* NB: does not commit
			*/
			void SaveValuation(long date, double valuation) const;

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;
			//@}

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool HasFeature(const sophis::finance::CSRProductFeature &feature, const _STL::string &featureName) const;
			//@}
			/** @name Multi-class fund / classes */
			//@{
			/// Returns true if this is a multi-class fund. 
			/// Database is queried;

			//=======  MULTI-CLASS  =======

			/** @name Multi-class fund / classes */
			//@{
			/// Returns true if this is a multi-class fund
			virtual bool IsMultiClass() const ;

			/** Returns the associated classes (sorted)
			*	@param  vectFundClasses Class codes, in the order defined by the user
			*	@return true if this is a multi-class fund
			*/
			virtual bool GetFundClasses(_STL::vector<long>& vectFundClasses) const ;

			virtual CSAMFundClassBaseLinker * GetFundClassLinker() const;
			
			/**
			*	Returns the underlying package 
			*	@return the underlying package 
			*/
			virtual sophis::instrument::CSRPackage * GetPackage() const;
			
			/**
			*	Updates the underlying package 
			*/
			virtual void UpdatePackage();

		protected:
			/** Name of the root in the xml description.
			*	@return a string C which must not be deleted.
			*	This is called by {@link GetDescription_API} to construct the xml.
			*	By default, throws a NotImplemented exception.
			* @since 2.3.2
			*/
			virtual const char* GetXMLRootName() const;

			/** Get an object that manages the xml description of an external fund 
			*	It MUST BE DELETED 
			*/
			virtual sophis::static_data::CSAMFundBaseXMLDescription* new_XMLDescriptor() const;

			/** Get an object that manages the update of an external fund 
			*	It MUST BE DELETED 
			*/
			virtual sophis::static_data::CSAMFundBaseXMLUpdate* new_XMLUpdater();

			/** Load sector composition from database */
			void LoadSectorComposition();

			/** Load lockup rules from database */
			void LoadLockUpRules();

			/** @name External fund data model */
			//@{
			/// Load external fund fees from database.
			void LoadFees();
			/// Load external fund structure from database.
			void LoadTopHoldings();
			//@}

			/**
			*	Load the breakdown data from database.
			*	@throw OracleException, sophisTools::base::GeneralException.
			**/
			void LoadBreakdown();

			/**
			* Load custom redemption dates 
			* @throw OracleException, sophisTools::base::GeneralException
			**/
			void LoadRedemptionNAVDates();

		public:
			/** Retrieves the latest nav from the database, applying the priority 
			*	rule official >> valuation >> estimated if several are available
			*	for the same date. 
			*	param considerValuationNav: if set to false, only official and estimated NAVs are used
			*	output navDate represents the date of the NAV found
			*	output benchmarkReturn represents the return of the benchmark over the period navDate, date
			*	output benchmarkCoeff represents the ratio fund NAV/benchmark valuation at navDate
			*/
			double GetValuationWithContext(const sophis::market_data::CSRMarketData& context, long date, bool considerValuationNav = true, long* navDate = NULL, double* benchmarkReturn = NULL, double* benchmarkCoeff = NULL) const;

			void SetNAVRedemptionDates(const _STL::vector<long>& navDates); 
			void SetNAVRedemptionDates(int count, const long* dates);
			void SetRedemptionWeekNAVDay(sophisTools::eWeekdayType type) ;
			void SetRedemptionNAVDatesType(eNAVDatesType type);
			int GetNAVRedemptionDatesCount() const; 
			long GetRedemptionNthNAVDate(int i) const;
			const _STL::vector<long>& GetRedemptionNAVDates() const;
			virtual long GetRedemptionNAVDateAfter(long	date, 
										 long	currency = -1, 
										 long	marketCode = -1, 
										 long	issueDate = -1, 
										 long	expiry = -1, 
										 short	navDatesType = -1, 
										 short	weekNAVDate = -1) const OVERRIDE;


			/** 
			*	Returns the first NAV date after a given date, using NAV dates parameterisation
			*	and fund calendar
			*
			*	@param date is a requested date
			*	@return a NAV date or the date given as parameter if lower than the fund issue date
			*/

			static bool UseCurrencyBreakdown();
			//void SetUnderlyingSpot(int index, double value);
			static void SetFundToRecompute(long id);

			eNAVDatesType GetRedemptionNAVDatesType() const { return fRedemptionNAVDatesType; }
			sophisTools::eWeekdayType GetRedemptionWeekNAVDay() const {return fRedemptionWeekNAVDay;}
			
			/** @name External fund data model */
			//@{
			
			typedef _STL::set<TopHolding, _STL::greater<TopHolding> > TopHoldingContainer;
		protected:
			long fLockUpPeriod;
			_STL::vector<sophis::static_data::SSSectorComposition>	fSectorComposition;
			LockUpRules	fLockUpRules;
			bool fUseLockUpRules;
			eNAVDatesType					fRedemptionNAVDatesType;
			sophisTools::eWeekdayType		fRedemptionWeekNAVDay;

			

			// ========  Fees  ========
			double fHighwatermark;
			double fHurdleRate;
			double fPerformanceFee;
			EPeriodicity fPerformanceFeeFrequency;
			_STL::string fPerformanceFeeComment;
			double fManagementFee;
			EPeriodicity fManagementFeeFrequency;
			double fRebate;
			_STL::string fManagementFeeComment;
			_STL::vector<long> fRedemptionNavDates;
			// ========  Structure  ========
			long fStrategyId; // Stored in the DEFAULT_EVENT_LEG_1 of the TITRES table
			TopHoldingContainer fTopHoldings;
			_STL::auto_ptr<CSAMFundBreakdown> fBreakdown;
			//@}

			// ========  Series  ========
			bool fHasSeries; 

			// ========  Lookthrought  ========
			static _STL::string fLookthroughIndicator;

			/*Support Specific calendar for Redemption*/
			virtual eNAVDatesType GetNavDateTypeForRedemption() const  OVERRIDE
			{
				return (fRedemptionNAVDatesType == nNA) ? fNAVDatesType : fRedemptionNAVDatesType;
			}
			virtual sophisTools::eWeekdayType GetWeekNavDateForRedemption() const  OVERRIDE
			{
				return (fRedemptionNAVDatesType == nNA) ? fWeekNAVDay : fRedemptionWeekNAVDay;
			}
			virtual _STL::string GetTableForCustomRedemptionNavDate() const  OVERRIDE
			{
				return "ext_fund_navdates";
			}

		private:			
			static const char* __CLASS__;

			friend class CSAMExternalFundTemplate;

			//@{
			// ====== !!! INTERNAL - Do not use !!! ======
			friend class CSAmEFCurrencyBreakdownSwitch;

			static void UseCurrencyBreakdownForCalculations(bool use);
			static void ResetFundsWithCurrencyBreakdown();

			// Say if an existing currency breakdown must be used for the fund calculation.
			static bool fUseCurrencyBreakdown;
			// Store the fund modified with the currency breakdown to recompute them.
			static _STL::set<long> fFundsToRecompute;

			friend class CSAMDefaultMetaModelExternalFund;
			//@}
		};

		class SOPHIS_FUND_BASE CSAMExternalFundForAudit : public CSAMExternalFund
		{
		public:
			CSAMExternalFundForAudit();

			virtual ~CSAMExternalFundForAudit(){};

			virtual CSAMFundClassBaseLinker * GetFundClassLinker() const;

			/// Returns true if this is a multi-class fund
			virtual bool IsMultiClass() const ;

			/** Returns the associated classes (sorted)
			*	@param  vectFundClasses Class codes, in the order defined by the user
			*	@return true if this is a multi-class fund
			*/
			virtual bool GetFundClasses(_STL::vector<long>& vectFundClasses) const ;		
		};

				/*Asset Value For hedge fund calculator
		EQUALIZATION AMOUT is added to asset value according to pref CSAmBasePreferences::GetEqualisationAmountInAssetValue()
		*/
#define ASSET_VALUE_CALCULATION_FOR_HEDGE_FUND "Asset Value Calculation For Hedge Fund"
		class SOPHIS_FUND_BASE CSRAssetValueCalculationForHedgeFund : public virtual sophis::portfolio::CSRAssetValueCalculation
		{
		public:
			virtual double CalculateAssetValue(const sophis::portfolio::CSRUnrealizedOverload*, double price, double averagePrice, double NbOfSecuritiesAndQuotity, const TViewMvts* mvts=NULL) const OVERRIDE;

			virtual const char* GetName() const 
			{
				return ASSET_VALUE_CALCULATION_FOR_HEDGE_FUND;
			}

		};
	}
}

#ifdef _WIN32
#	pragma warning(pop)
#endif


#endif // _SphExternalFund_H_
