#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXTERNALFUNDBASE_H__
#define __SOPHIS_VALUE_SPHEXTERNALFUNDBASE_H__


// Toolkit includes
#include "SphFundBase.h"
#include "SphFundFieldEnums.h"


// Constants definition
#define AUDITOR_NAME_STRING_LENGTH 40
#define YEAR_END_STRING_LENGTH 40
#define REPORT_DESCRIPTION_STRING_LENGTH 40


namespace sophis
{
	namespace value
	{

		enum EPeriodicity 
		{
			epUndefined = -1,

			epWeekly = 1,
			epBiMonthly,
			epMonthly,
			epQuarterly,
			epBiAnnually,
			epAnnually,
			epFinal
		};

		class SOPHIS_FUND_BASE CSAMDefaultMetaModelExternalFundBase : public virtual CSAMDefaultMetaModelFundBase
		{
		public:
			DECLARATION_META_MODEL(CSAMDefaultMetaModelExternalFundBase);
			virtual ~CSAMDefaultMetaModelExternalFundBase();

			virtual double GetFirstDerivative(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual double GetSecondDerivative(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual double GetVega(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context,int whichUnderlying) const OVERRIDE;
			virtual double GetTheta(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double GetCrossedVega(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context,int which1, int which2) const OVERRIDE;
			virtual double GetEpsilon(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual double GetConvexity(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double	GetRho(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, int which, instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual void	GetRhoConvexity(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context,
											double price,
											double *rho,
											double *convexity,
											int which, 
											instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double	GetCrossedDeltaRho(const sophis::instrument::CSRInstrument& instr, const market_data::CSRMarketData &context, 
												int whichUnderlying, 
												int whichCurrency,
												instrument::eRhoBumpType rhoBumpType) const OVERRIDE;
			virtual double GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long date, market_data::eTaxCreditPercentageType forEvaluation, 
											const market_data::CSRMarketData& context,
											const instrument::CSRInstrument* initialForward = NULL) const OVERRIDE;
			virtual	void	GetLinearValue(const sophis::instrument::CSRInstrument& instr, 	double					 computationDate,
											long 					 futureDate,
											instrument::eSettlementType 		 settlementType,
											market_data::eTaxCreditPercentageType forEvaluation,
											double 					 *a,
											double 					 *b,
											double 					 *rate,
											const market_data::CSRMarketData		 &context) const OVERRIDE;
			virtual	void	GetValue(const sophis::instrument::CSRInstrument& instr, 	double 					 computationDate,
										long 					 futureDate,
										double 					 futureValue,
										instrument::eSettlementType 		 settlementType,
										market_data::eTaxCreditPercentageType forEvaluation,
										double 					 *spot,
										const market_data::CSRMarketData 	 &context) const OVERRIDE;
			virtual void	GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long					 *futureDates,
											double					 *val,
											short					 dateCount,
											market_data::eTaxCreditPercentageType forEvaluation,
											const market_data::CSRMarketData		 &context,
											const instrument::CSRInstrument*		initialForward = NULL) const OVERRIDE;
			virtual void	GetForwardQuantoPrice(const sophis::instrument::CSRInstrument& instr, 	long					 *futureDates,
													double					 *val,
													int					 dateCount,
													market_data::eTaxCreditPercentageType forEvaluation,
													long strikeCurrency,
													double overVolatility,
													NSREnums::eVolatilityType volatType,
													bool put,
													const market_data::CSRMarketData		 &context) const OVERRIDE;

			virtual void GetRiskSources(const instrument::CSRInstrument& instr, /*out*/ sophis::CSRComputationResults& rs, unsigned long bitFlag) const OVERRIDE;
		private:
			static const char* __CLASS__;
		};


		/**
		 *  Base class for external funds.
		 */
		class SOPHIS_FUND_BASE CSAMExternalFundBase : public virtual CSAMFundBase
		{
		public:
			/** @name Type definitions */
			//@{
			typedef _STL::set<long> PrimeBrokerContainer;
			//@}

		public:
			/** @name Construction - Destruction */
			//@{
			CSAMExternalFundBase();
			virtual ~CSAMExternalFundBase();
			//@}

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const OVERRIDE;

			/** @name Initialization */
			//@{
			/// Initialise (or reinitialise) all fund data
			virtual void Initialise();

			/** 
			 *  Initialise all fund data based on an instrument code and a date
			 *  (automatically calls CSAMExternalFundBase::Load)
			 *
			 *  @param instrumentCode is a code of an instrument as found in table INFOS_HISTO
			 *  @param dateHisto is an optional past date to retrieve an audited version of a fund
			 */
			virtual void Initialise(long instrumentCode, double dateHisto = 0);

			/** 
			 *  Copy all data from another fund
			 *
			 *  @param fund is a pointer on another fund
			 *  if this instrument is not a fund, nothing is done
			 */
			virtual void Initialise(const CSAMFundBase* fund);

			/** Load infos depending on the type of the fund. Called by Load() */
			virtual void LoadSpecificData();

			// ========  Legal information  ========
			long GetCustodianId() const;
			void SetCustodianId(long custodian);

			long GetAdministratorId() const;
			void SetAdministratorId(long admin);

			const _STL::string &GetAuditorName() const;
			void SetAuditorName(const _STL::string &name);

			long GetAuditLastDate() const;
			void SetAuditLastDate(long date);

			const _STL::string &GetYearEnd() const;
			void SetYearEnd(const _STL::string &yearEnd);

			EPeriodicity GetReportingFrequency() const;
			void SetReportingFrequency(EPeriodicity frequency);

			const _STL::string &GetReportDescription() const;
			void SetReportDescription(const _STL::string &reportDesc);

			const PrimeBrokerContainer &GetPrimeBrokers() const;
			void SetPrimeBrokers(const PrimeBrokerContainer& primeBrokers);
			//@}

			/** @name Calculation */
			//@{
			virtual bool HasFairValue() const;

			// Force implementation of these two methods in derived class
			/**
			 *  Always set fUnderlyingsLoaded to true before leaving this method
			 *  and BEFORE ResetRecomputeAll to prevent an infinite recursion
			 *  (ResetRecomputeAll calls GetUnderlyingCount).
			 */
			//virtual void InitialiseRecomputeAll() = 0;

			//virtual int GetUnderlyingCount() const;
			//virtual long GetUnderlying(int whichUnderlying) const;
			//virtual Boolean IsAnUnderlying(long instrumentCode, int* whichUnderlying) const;

			virtual double GetEquityGlobalDelta(const sophis::CSRComputationResults& results) const;
			virtual double GetEquityGlobalDelta(const market_data::CSRMarketData &context) const;
			virtual double GetDelta(const sophis::CSRComputationResults& results, long* code) const;
			virtual double GetGamma(const sophis::CSRComputationResults& results, long* code) const;

			//virtual int		GetRhoCount() const;
			//virtual long	GetRhoCurrency(int whichUnderlying) const;
			//virtual Boolean	IsARhoCurrency(long currency, int *whichUnderlying=0) const;


			/** @name Internal - Lookthrough */
			//@{
			/// Says if the internal funds must use its real composition or its benchmark for lookthrought calculations.
			static void SetUseBenchmarkForLookthrough(bool useBenchmark);
			virtual bool UseBenchmarkForLookthrough() const;

			/**
			 *	Get the breakdown data of the fund.
			 *	By default, a fund has an empty instrument list as a breakdown.
			 *	@return NULL if no breakdown data is attached to the fund.
			 *	@see CSAMFundBreakdown.
			 */
			virtual const CSAMFundBreakdown* GetBreakdown() const = 0;
			//@}

			virtual bool HasPurchaseTransaction(long code) const;

			virtual sophis::instrument::CSRPackage* GetPackage() const OVERRIDE;

			void reLoadDividends();

		protected:

			// ========  Legal information  ========
			long fCustodianId;
			long fAdministratorId;
			_STL::string fAuditorName;
			long fAuditLastDate;
			_STL::string fYearEnd;
			EPeriodicity fReportFrequency;
			_STL::string fReportDesc;
			PrimeBrokerContainer fPrimeBrokers;
			//@}

			/** @name Composition */
			//@{
			/// Internal.
			mutable sophis::instrument::CSRPackage* fPackage;
			bool	fIsPackageInitialised;
			/// Internal.
			bool fUnderlyingsLoaded; 
			//@}

			/** @name Internal - Lookthrough */
			//@{
			/// Internal.
			static bool fUseBenchmarkForLookthrough;
			//@}


		protected:
			/** @name CSAMExternalFundBase data model */
			//@{
			/// Load fund fields from database.
			void LoadFundFields();
			/// Load external fund legal information from database.
			void LoadLegalInformation();
			//@}

		private:
			// Traces
			static const char* __CLASS__;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXTERNALFUNDBASE_H__