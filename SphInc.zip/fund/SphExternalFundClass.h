#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef _SphHedgeFundClass_H_
#define _SphHedgeFundClass_H_

// Macros definitions
#define	INITIALISE_EXTERNAL_FUNDCLASS(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass,  name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMHedgeFundClassTemplate(name), hHedgeFundClass);
#define INITIALISE_HEDGE_FUNDCLASS_FUND_GUI(derivedClass, name, pageClass) \
	INITIALISE_PROTOTYPE(derivedClass, name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAMHedgeFundClassTemplate(name, new pageClass), hHedgeFundClass);

#include "SphHedgeFund.h"

namespace sophis
{
	namespace value
	{
	
		class SOPHIS_FUND_BASE CSAMHedgeFundClass : public virtual CSAmHedgeFund
		{
		public:
			static const char* __CLASS__;

			/** @name Prototype management */
			//@{
			typedef sophis::tools::CSRPrototype<CSAMHedgeFundClass, const char*, sophis::tools::less_char_star> prototype;
			static prototype &GetPrototype();
			//@}

			//=======  ACCESSORS  =======

			/// Initialise (or reinitialise) all fund data
			virtual void Initialise();

			/** 
			*	Initialise all fund data based on an instrument code and a date
			*	(automatically calls CSAMExternalFund::Load)
			*	
			*	@param instrumentCode is a code of an instrument as found in table INFOS_HISTO
			*	@param dateHisto is an optional past date to retrieve an audited version of a fund
			*/
			virtual void Initialise(long instrumentCode, double dateHisto=0.);

			/** 
			*	Copy all data from another fund
			*	
			*	@param instrument is a pointer on another fund
			*	if this instrument is not a fund, nothing is done
			*/
			virtual void Initialise(const CSAMFundBase* instrument);

			/** 
			*	Create a new copy of a series 
			*	
			*	@return a newly allocated series
			*/
			virtual sophis::instrument::CSRInstrument* Clone() const; // overriden from sophis::instrument::CSRInstrument

			/** 
			*	Returns a string depending on a fund type
			*	
			*	@param type is a fund type
			*	@return a string to describe this type of funds
			*/
			static const char* GetFundTypeName() { return "external fund class"; };

			virtual const char*	GetHedgeFundTypeName() const { return GetFundTypeName(); }

			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;

			virtual sophis::static_data::CSAMFundBaseXMLUpdate* new_XMLUpdater() OVERRIDE;
			virtual sophis::static_data::CSAMFundBaseXMLDescription* new_XMLDescriptor() const OVERRIDE;
			virtual const char* GetXMLRootName() const
			{
				return "hedgeFundClass";
			}

			static CSAMHedgeFundClass* CreateInstance(long code, bool isAudit = false);

			void SetMasterFund(long code)
			{
				pMasterFund = code;
			}

			long GetMasterFund() const
			{
				return pMasterFund;
			}

			void InitializeFromFund(long masterCode);

			/// Returns an instance of the fund class with the corresponding sicovam
			static const CSAMHedgeFundClass* GetFundClass(long code, bool isAudit = false);

			/// Like a dynamic_cast<const GetFundClass*> but quicker
			static const CSAMHedgeFundClass* GetFundClass(const sophis::instrument::CSRInstrument* instrument);

		private:
			void FillSpecificData();

		private:
			long pMasterFund;
		};

		///Database structure for fund classes
		struct SOPHIS_FUND_BASE SSHedgeFundClass
		{
			long fCode;
			char fTemplateName[FUND_TEMPLATE_NAME_LENGTH];
			char fName[SIZE_INSTRUMENT_NAME+1];
			char fReference[SIZE_INSTRUMENT_REF+1];
			char fExternalRef[SIZE_INSTRUMENT_REF+1];
			char fComment[200+1];
			long fIssuer;
			long fHedgeFundType;
			long fCurrency;
			long fMarketCode;
			double fQuotity;
			long fIssueDate;
			double fIssuePrice;
			double fIssuedShares;
			long fExpiry;
			double fStrike;
			long fSRRoundingMode;
			long fEntity;
			long fBenchmarkCode;
			long fNAVDatesType;
			long fWeekNAVDay;
			long fNAVNbDecimals;
			long fLegalForm;
			long fLockUpPeriod;
			long fStrategyId;
			long fUseLockUpRules;
			long fHasSeries;

			SSHedgeFundClass():
			fIssuer(0),
			fHedgeFundType(0),
			fCurrency(0),
			fMarketCode(0),
			fQuotity(0),
			fIssueDate(0),
			fIssuePrice(0),
			fIssuedShares(0),
			fExpiry(0),
			fStrike(0),
			fSRRoundingMode(0),
			fEntity(0),
			fBenchmarkCode(0),
			fNAVDatesType(0),
			fWeekNAVDay(0),
			fNAVNbDecimals(0),
			fLegalForm(0),
			fLockUpPeriod(0),
			fStrategyId(0),
			fUseLockUpRules(0),
			fHasSeries(0)
			{
				*fName = *fReference = *fComment = *fExternalRef = '\0';
			}

			static sophis::sql::CSRStructureDescriptor* GetDescriptor()
			{
				static sophis::sql::CSRStructureDescriptor* fDesc = 0;
				if (!fDesc)
				{
					fDesc = new sophis::sql::CSRStructureDescriptor(25, sizeof(SSHedgeFundClass));
					//ADD(&fDesc, SSHedgeFundClass, fCode, rdfInteger);
					//ADD(&fDesc, SSHedgeFundClass, fTemplateName, rdfString);
					ADD(fDesc, SSHedgeFundClass, fName, sophis::sql::rdfString);
					ADD(fDesc, SSHedgeFundClass, fReference, sophis::sql::rdfString);
					ADD(fDesc, SSHedgeFundClass, fExternalRef, sophis::sql::rdfString);
					ADD(fDesc, SSHedgeFundClass, fComment, sophis::sql::rdfString);
					ADD(fDesc, SSHedgeFundClass, fIssuer, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fHedgeFundType, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fCurrency, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fMarketCode, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fQuotity, sophis::sql::rdfFloat);
					ADD(fDesc, SSHedgeFundClass, fIssueDate, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fIssuePrice, sophis::sql::rdfFloat);
					ADD(fDesc, SSHedgeFundClass, fIssuedShares, sophis::sql::rdfFloat);
					ADD(fDesc, SSHedgeFundClass, fExpiry, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fStrike, sophis::sql::rdfFloat);
					ADD(fDesc, SSHedgeFundClass, fSRRoundingMode, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fEntity, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fBenchmarkCode, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fNAVDatesType, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fWeekNAVDay, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fNAVNbDecimals, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fLegalForm, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fLockUpPeriod, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fStrategyId, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fUseLockUpRules, sophis::sql::rdfInteger);
					ADD(fDesc, SSHedgeFundClass, fHasSeries, sophis::sql::rdfInteger);
				}
				return fDesc;
			}
		};
	}
}

#endif