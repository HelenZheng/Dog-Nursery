/********************************************************************
*	@date		:	26/09/2012
*
*	@file		: 	CSAmExternalFundFeesPeriod.h
*	
*	@author		:	Sophis
*
*	@purpose	:	Definition of fund fees accounting and payment 
*					periods
*	
*/

#pragma once

#ifndef _AM_EXTERNAL_FUND_FEES_PERIODS_H
#define _AM_EXTERNAL_FUND_FEES_PERIODS_H

#include "SphTools/SphCommon.h"
#include "SphFundBaseExports.h"

#include __STL_INCLUDE_PATH(string)	
#include __STL_INCLUDE_PATH(vector)	


namespace sophis
{
	namespace static_data
	{
		class CSRCalendar ;
	}

	namespace value
	{
		class CSAMExternalFund ;

		/// Base class for fund fees period definition
		class SOPHIS_FUND_BASE CSAmExternalFundFeesPeriod		
		{	
		public:

			/// Constructor
			CSAmExternalFundFeesPeriod() : fType("Undefined") {}
		
			/** Returns the Nth date, defined from an initial date
			*	and a number of periods (i.e., NOT fixed definition on periodicity alone)
			* @param fund Fund
			* @param calendar The calendar to be used, not null
			* @param initialDate The initial date
			* @param nbPeriods Period, greater than one
			* @return initial + nbPeriods*periodicity
			*/
			virtual long GetNthDate( 
				const CSAMExternalFund*							fund,
				const sophis::static_data::CSRCalendar* calendar, 
				long									initialDate, 
				int										nbPeriods) const=0 ;

			/** Returns the next fixed payment date
			* @param fund Fund
			* @param calendar The calendar to be used, not null
			* @param date The current date
			* @return The next fixed payment date after 'date', based 
			*	on the definition of periodicity alone
			*/
			virtual long GetNextFixedPaymentDate(
				const CSAMExternalFund*							fund,
				const sophis::static_data::CSRCalendar* calendar, 
				long									date) const=0 ;

			/** Returns the previous fixed payment date
			* @param fund Fund
			* @param calendar The calendar to be used, not null
			* @param date The current date
			* @return The previous fixed payment date before 'date', based 
			*	on the definition of periodicity alone
			*/
			virtual long GetPreviousFixedPaymentDate(
				const CSAMExternalFund*							fund,
				const sophis::static_data::CSRCalendar* calendar, 
				long									date) const=0 ;

			/** Returns Peroid's ID 
			* For standard period, return ID (1~100); 
			* For the toolkited period, return its unique ID (from 101)
			*/
			virtual int GetId() const=0 ;

			enum PeriodID
			{
				pIdDefault = 1,
				pIdWeekly,
				pIdBiMonthly,
				pIdMonthly,
				pIdQuarterly,
				pIdSemiAnnually,
				pIdAnnually,
				pIdFinal,
				pIdToolkit = 101
			};
			/// Type (as it will appear in menus)
			_STL::string GetType() const { return fType;}
		
		protected:

			/// Type
			_STL::string fType ;

		}; // End class CSAmExternalFundFeesPeriod


		/// Management of the defined fund fees periods
		class SOPHIS_FUND_BASE CSAmExternalFundFeesPeriods		
		{	
		public:

			/// Singleton pattern
			static CSAmExternalFundFeesPeriods* GetInstance();

			/// Accounting type, based on the index
			_STL::string GetAccountingType(int periodIndex) const ;

			/// Payment type, based on the index
			_STL::string GetPaymentType(int periodIndex) const ;

			/// Number of registered periods
			int GetNbPeriods() const ;

			/// Access to a given period
			const CSAmExternalFundFeesPeriod* GetPeriod(int periodIndex) const ;

			/// Registers a new fund fees period (Called via INITIALISE_FUND_FEES_PERIOD)
			void Insert(CSAmExternalFundFeesPeriod* fundFeesPeriod) ;

			/// Unregister the given fund fees period
			void Remove(CSAmExternalFundFeesPeriod* fundFeesPeriod) ;

			/// Returns true if this is a toolkit period
			bool IsToolkitPeriod(int periodIndex) const ;

			/// Returns period Id
			int GetPeriodId(int periodIndex) const;

			/// Returns period�Index
			int GetPeriodIndex(int periodId);

			/// Index of the Undefined type
			static int UndefinedType ;
			/// Index of the default type
			static int DefaultType ;
			/// Index of the final type
			static int FinalType ;

		private:

			/// Constructor
			CSAmExternalFundFeesPeriods() ;

			/// Destructor
			~CSAmExternalFundFeesPeriods() ;

			/** Storing the available periods in a vector and not
			a regular prototype, as they need to be indexed
			on a different order than the alphabetical one
			*/
			_STL::vector<CSAmExternalFundFeesPeriod*> fRegisteredPeriods ;

		}; // End class CSAmExternalFundFeesPeriods

	} // End namespace value

} // End namespace sophis

#endif