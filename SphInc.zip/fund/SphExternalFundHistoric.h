#pragma once

/*
File:	SphExternalFundHistoric.h

Contains:	classes to manage historic on an external fund

Copyright:	� 2006 Sophis.
*/


#ifndef _SPH_EXT_FUND_HISTORIC_H_
#define _SPH_EXT_FUND_HISTORIC_H_

#include "SphFundBaseExports.h"
#include "SphFundBaseHistoric.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(map)

namespace sophis	
{
	namespace value	
	{
		/** CSAMExternalFundHistoric -- stores history data in addition to the classical
		*	history (sophis::market_data::CSRHistoric).  This data is loaded into the
		*	history view by CSAMFundBaseHistoricList::RowInHistoric().  The data is loaded
		*	from the history view by CSAMFundBaseHistoricList::HistoricInRow().  Instances
		*	are created by new_HistoricList().
		*
		*	If you want to add fund columns, @see CSAMFundBaseHistoric for a complete
		*	description.
		*/
		class SOPHIS_FUND_BASE CSAMExternalFundHistoric : public CSAMFundBaseHistoric
		{
		public:
			virtual	void	Initialise();

			// Order does matter
			double	fValuationNav;				// Valuation nav
			double	fEstimatedNav;				// Estimated nav (aka soft nav)
			double  fEqualisation;				// Equalisation credit
			double  fHWM;						// HighWaterMark
			double	fEstimatedNavRor;			// Estimated nav rate of return
			long	fEstimatedNavReferenceDate;	// Reference date for the calculation of the estimated nav
			long	fEstimatedNavRorAsInput;	// If not zero, the RoR was used to specify the estimated nav (Hidden)			
		};

		/** CSAMExternalFundHistoricList -- Modifies the instrument history display for an
		/ external fund.
		*	In particular, it adds the following columns:
		*		-	Valuation NAV
		*		-	Estimated NAV
		*		-	Estimated NAV RoR
		*		-	Estimated NAV Reference date
		*		-	Estimated NAV Input (not displayed)
		*
		*	If you want to add fund columns, you must:
		*	-#	Derive sophis::value::CSAMExternalFundHistoric
		*		-#	Add data fields as necessary, one per new column.
		*		-#	Over-ride Initialise() to initialise your new data.
		*	-#	Derive sophis::value::CSAMExternalFundHistoricList and over-ride:
		*		-#	BuildColumns(void)
		*			to call CSAMExternalFundHistoricList::BuildColumns(void) and THEN
		*			add/hide columns as required.
		*		-#	HistoricInRow(long numLigne, historic *ligneHisto)
		*			to save data to your new CSAMExternalFundHistoric child class (A) and
		*			call CSAMExternalFundHistoricList::HistoricInRow().
		*		-#	RowInHistoric(long numLigne, historic *ligneHisto, Boolean ligneChargee = false)
		*			to load data from your new CSAMExternalFundHistoric child class (A) and
		*			then call CSAMExternalFundHistoric::RowInHistoric().
		*		-#	NewHisto(void)
		*			to return a new instance of your CSAMExternalFundHistoric child class
		*			(A).
		*	-#	Derive sophis::value::CSAMFund and over-ride:
		*		-#	Clone(void)
		*			to create an instance of the new CSAMFund child class (C) and
		*			then call newInstance->Initialise(this).
		*		-#	new_HistoricList(void)
		*			to return a instance of your CSAMExternalFundHistoricList child class
		*			(B).
		*	-#	Register your new fund class as a fund model:
		*		-#	Create a UNIVERSAL_MAIN method including the following line:
		*			INITIALISE_FUND(NewFundClass, "New Fund Class Model");
		*	-#	Change the model of one or more funds to the new fund model.  These
		*		funds will now display a modified history.
		*
		* @see sophis::value::CSAMFund::Clone(void)
		* @see sophis::value::CSAMFund::new_HistoricList(void)
		* @see UNIVERSAL_MAIN
		* @see INITIALISE_FUND()
		*/
		class SOPHIS_FUND_BASE CSAMExternalFundHistoricList : public CSAMFundBaseHistoricList
		{
		public:

			enum eExternalFundColPlus
			{
				cValuationNav=CSAMFundBaseHistoricList::cFieldCount,
				cEstimatedNav,
				//cEqualisation,
				cHWM,
				cEstimatedNavRor,
				cEstimatedNavRefDate,
				cEstimatedNavRorIsInput,				
				cExternalFundFieldCount
			};

			/**	Constructor.
			*	@param NumExtraColumns Gives the number of columns to be added by a sub-class.
			*	The default (0) is for constructing an instance of CSAMExternalFundHistoricList directly.
			*/
			CSAMExternalFundHistoricList(PInfoHisto infos, int NumExtraColumns=0);

			/// Overload
			virtual bool Save();

			/// Modification of the estimated nav reference date for a given line
			void SetEstimatedNavRefDate(int line, long date) ;

			/** Returns the previous NAV, when considering the date at a given line
			*	The priority order is Official Nav >> Valuation Nav >> Estimated Nav 
			*	If referenceDate is set, the line at that date is considered
			* (NB: If there is a NAV at this line, this is not the value returned !)
			*/
			double GetPreviousNav(int line, long referenceDate=0) ;

			/// An enum used by NavModified()
			enum eNavType
			{
				eOfficialNav,
				eValuationNav,
				eEstimatedNav				
			} ;

			/** Notifies the list that one of the nav has changed on a given line 
			*	(propagation for the calculation of the estimated NAV)
			*/
			void NavModified(int line, double newNav, eNavType whichNav) ;

		protected:
			/// Overload
			virtual long	GetHeaderResourceId() const;
			/// Overload
			virtual void	BuildColumns(void);
			/// Overload
			virtual historic* NewHisto(void);
			/// Overload
			virtual bool IsLinkedWithLast(int columnId);
			/// Overload
			virtual void HistoricInRow(long numLigne, historic *ligneHisto) ;
			/// Overload
			virtual void RowInHistoric(long numLigne, historic *ligneHisto, Boolean ligneChargee) ;
			/// Overload
			virtual CSAMFundBaseHistoric* GetHistoricLine(historic* ligneHisto) const;

			/// Returns true if the NAV should be taken into account
			bool ValidNav(double nav) const ;
		};

		/** 
		*	This class is used to display the nb of shares after S/R 
		*	This value is the nb of shares before S/R for external funds
		*/
		class CSRStaticNbPartsAfterSR : public CSRStaticDoubleCalculation
		{
		public:
			/// Constructor
			CSRStaticNbPartsAfterSR(	sophis::gui::CSREditList *liste,
				int 			 CNb_Double,
				int 			 numberOfDecimalPlaces,
				double 			 minimum,
				double 			 maximum,
				double			 value=0);
		private:
			/// Overload
			virtual double	Calculation(int line) const;
		};

		/// The edit element used for the GAV
		class SOPHIS_FUND_BASE CSRGavEditHistoric : public sophis::market_data::CSREditHistoric 
		{
		public:
			/// Constructor
			CSRGavEditHistoric(
				sophis::gui::CSREditList*	liste,
				int 						CNb_Double,
				int 						numberOfDecimalPlaces,
				double 						minimum,
				double 						maximum) ;

			/// Overload
			virtual Boolean	StringToValue(const char *sourc, int ligne);
		};

		/** This class is used to display the Net Asset Value
		*	Net Asset Value = Gross Asset Value + update of the estimated nav
		*/
		class SOPHIS_FUND_BASE CSRStaticNAV : public CSRStaticDoubleCalculation
		{
		public:
			/// Constructor
			CSRStaticNAV(
				sophis::gui::CSREditList*	liste,
				int							CNb_Double,
				int 						numberOfDecimalPlaces,
				double 						minimum,
				double 						maximum,
				double						value=0);

		private:
			/// Overload
			virtual double	Calculation(int line) const;
		};

		/// The edit element used to link the estimated nav and the rate of return
		class SOPHIS_FUND_BASE CSREstimatedNavEditHistoric : public sophis::market_data::CSREditHistoric 
		{
		public:
			/// Constructor
			CSREstimatedNavEditHistoric(
				sophis::gui::CSREditList*	liste,
				int 						CNb_Double,
				int 						numberOfDecimalPlaces,
				double 						minimum,
				double 						maximum,
				int							CEstimatedNavReferenceDate,
				int							CEstimatedNavNb_Double,
				int							CEstimatedRoRNbDouble,
				int							CEstimatedNavRorIsInput,
				double						value=0,
				const char*					columnName = kUndefinedField);

			/// Overload
			virtual void	ValueToString(char *dest, int ligne) const;

			/// Overload
			virtual Boolean	StringToValue(const char *sourc, int ligne);

		protected:

			/// Estimated nav reference date element
			int fCEstimatedNavReferenceDate ;

			/// Estimated nav element
			int fCEstimatedNavNb_Double ;

			/// Estimated nav rate of return element
			int fCEstimatedRoRNbDouble ;

			/// Which of the two is the one entered by the user ?
			int fCEstimatedNavRorIsInput ;
		} ;

		/** 
		*	This class is used to display the date of reference for the 
		*	calculation of the estimated nav
		*/	
		class SOPHIS_FUND_BASE CSREstimatedNavRefDateEditHistoric : public sophis::gui::CSREditDate
		{
		public:

			/// Constructor
			CSREstimatedNavRefDateEditHistoric(
				sophis::gui::CSREditList*	liste,
				int 						CNb_Date,
				int							CEstimatedNavNb_Double);

			/// Overload
			virtual Boolean	StringToValue(const char* sourc, int line);

		protected:

			/// Estimated nav element
			int fCEstimatedNavNb_Double ;
		};

		/// The edit element used for the valuation NAV
		class SOPHIS_FUND_BASE CSRValuationNavEditHistoric : public sophis::market_data::CSREditHistoric 
		{
		public:
			/// Constructor
			CSRValuationNavEditHistoric(
				sophis::gui::CSREditList*	liste,
				int 						CNb_Double,
				int 						numberOfDecimalPlaces,
				double 						minimum,
				double 						maximum) ;

			/// Overload
			virtual Boolean	StringToValue(const char *sourc, int ligne);
		};
			
	} // namespace value
} // namespace sophis


#endif
