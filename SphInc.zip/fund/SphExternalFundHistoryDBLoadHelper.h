#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXTERNALFUNDHISTORYDBLOADHELPER_H__
#define __SOPHIS_VALUE_SPHEXTERNALFUNDHISTORYDBLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseHistoryDBLoadHelper.h"


namespace sophis
{
	namespace value
	{
		struct SOPHIS_FUND_BASE SSAmExternalFundHistoryDBLoadHelper : public SSAmFundBaseHistoryDBLoadHelper
		{
			// Default constructor.
			SSAmExternalFundHistoryDBLoadHelper();
			// Copy constructor.
			SSAmExternalFundHistoryDBLoadHelper(const SSAmExternalFundHistoryDBLoadHelper &other);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmExternalFundHistoryDBLoadHelper();

			// Assignment operator.
			SSAmExternalFundHistoryDBLoadHelper &operator=(const SSAmExternalFundHistoryDBLoadHelper &other);

			// Coming from CSAMExternalFundHistoryDB
			double fValuationNav;
			double fEstimatedNav;
			long fEstimatedNavReferenceDate;
			long fEstimatedNavRorAsInput;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXTERNALFUNDHISTORYDBLOADHELPER_H__