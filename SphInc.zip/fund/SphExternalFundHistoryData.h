/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphExternalFundHistoryData.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Class to handle external fund history data
*
*/

#ifdef _WIN32
#	pragma once
#endif

#ifndef _SphExternalFundHistoryData_H_
#define _SphExternalFundHistoryData_H_

/**
* System includes
*/
#include "SphFundBaseExports.h"
#include "SphFundBaseHistoryData.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
/**
* Application includes
*/

// Macros definitions
#include "SphInc/SphMacros.h"

/**
* defines
*/

namespace sophis 
{
	namespace sql
	{
		class CSROracleException;
	};

	namespace value	
	{
		struct SSAmExternalFundHistoryDBLoadHelper;


		/** Base class used for SQL queries (history of prices) */
		class SOPHIS_FUND_BASE CSAMExternalFundHistoryDB : public virtual CSAMFundBaseHistoryDB
		{
		public:
			CSAMExternalFundHistoryDB();
			CSAMExternalFundHistoryDB(const SSAmExternalFundHistoryDBLoadHelper &loadHelper);
			CSAMExternalFundHistoryDB(const CSAMFundBaseHistoryDB& fundBase);
			virtual ~CSAMExternalFundHistoryDB();

			/** Clone the history data.
			*	@return a new derived class from CSAMExternalFundHistoryDB (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryDB* Clone() const;

			virtual sophis::sql::CSRStructureDescriptor* GetDescriptor() const;

			/** Build the select query that retrieves history data between two dates */
			virtual _STL::string GetSelectQuery(long fundCode, long date1, long date2, bool decreasingDate) const;
			
			/** Create the insert query based on object "this"
			*	Add history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetInsertQuery(long fundCode) const;

			/** Create the update query based on object "this" 
			*	Update history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetUpdateQuery(long fundCode) const;

			double	fValuationNav;				// Valuation nav
			double	fEstimatedNav;				// Estimated nav (aka soft nav)
			long	fEstimatedNavReferenceDate;	// Reference date for the calculation of the estimated nav
			long	fEstimatedNavRorAsInput;	// If not null, the RoR was used to specify the estimated nav			
		
		protected:
			using CSAMFundBaseHistoryDB::Initialize;
			void Initialize(const CSAMFundBaseHistoryDB& fundBase);
		};

		/** Base class to handle fund history data */
		class SOPHIS_FUND_BASE CSAMExternalFundHistoryData : public virtual CSAMFundBaseHistoryData
		{
		public:
			CSAMExternalFundHistoryData(long fundCode);
			virtual ~CSAMExternalFundHistoryData();
			
			void Initialize(long fundCode);

			/** Clone the history data.
			*	@return a new derived class from CSAMFundBaseHistoryData (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryData* Clone() const;

			typedef _STL::vector<CSAMExternalFundHistoryDB> ExternalFundHistoryDBList ;

			/// Access to the vector of history data
			const ExternalFundHistoryDBList& GetHistoryList() const { return fHistoryDB; };

		protected:
			// constructor required for virtual inheritance
			CSAMExternalFundHistoryData();

			/** Create an instance of CSAMFundBaseHistoryDB to perform requests 
			*	MUST BE DELETED
			*/
			virtual CSAMFundBaseHistoryDB* new_HistoryDB() const;

			/** Method that performs the request to fill an internal structure and fHistoryData
			*	@throws OracleException if an error occurs */
			virtual void ExecuteSelectQuery(const _STL::string& request, const sophis::sql::CSRStructureDescriptor* desc, long startDate, long endDate, bool decreasingDate) 
#ifndef GCC_XML
				throw(sophis::sql::CSROracleException) OVERRIDE
#endif
				;

			ExternalFundHistoryDBList fHistoryDB;
		};
	}
}

#endif // _SphExternalFundHistoryData_H_
