#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHEXTERNALFUNDLOADHELPER_H__
#define __SOPHIS_VALUE_SPHEXTERNALFUNDLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseLoadHelper.h"


namespace sophis
{
	namespace value
	{
		class CSAMExternalFund;


		/**
		*  Helper structure to load fund data from database.
		*  Inherit from this struct when creating a fund based on CSAMExternalFund.
		*/
		struct SOPHIS_FUND_BASE SSAmExternalFundLoadHelper : public SSAmFundBaseLoadHelper
		{
			// Default constructor.
			SSAmExternalFundLoadHelper();
			// Constructor from a CSAMExternalFund.
			SSAmExternalFundLoadHelper(const CSAMExternalFund &fund);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmExternalFundLoadHelper();

			virtual int GetBaseClassSize() const;
			virtual int GetClassSize() const;

			// Coming from CSAMExternalFund
			long fLockUpPeriod;
			bool fUseLockUpRules;
			long fStrategyId;
			bool fHasSeries;
			long fRedemptionNavDateType;
			long fRedemptionDayOfTheWeek;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHEXTERNALFUNDLOADHELPER_H__