#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SPHEXTERNALFUNDMACROS_H__
#define __SPHEXTERNALFUNDMACROS_H__


#include "SphFundBaseExports.h"
//#include "SphFundTemplate.h"


/*
 *  Macros for user external fund classes
 */

#define DECLARE_EXTERNAL_FUND_CLASS(derivedClass, baseClass) \
public: \
	derivedClass(); \
	void Initialise(); \
	void Initialise(const sophis::value::CSAMFundBase*); \
	sophis::instrument::CSRInstrument* Clone() const;

#define DEFINE_EXTERNAL_FUND_CLASS(derivedClass) \
	sophis::instrument::CSRInstrument* derivedClass::Clone() const \
	{ \
		derivedClass* instr = new derivedClass(); \
		instr->Initialise(this); \
		return instr; \
	}


#endif // __SPHEXTERNALFUNDMACROS_H__