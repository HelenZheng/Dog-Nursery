/********************************************************************
*	@date:		2007
*	
*	@file:	 	CSAMExternalFundSeries.h
*
*	@author:	Copyright (C) 2007 SOPHIS
*	
*	@purpose:	Class that handles external fund series.
*				We overload external funds as a series and the
*				inception represent the same instrument.
*
*/

#ifndef _CSAMExternalFundSeries_H_
#define _CSAMExternalFundSeries_H_

/**
* System includes
*/

/**
* Application includes
*/
#include "SphInc/fund/SphExternalFund.h"
#include "SphSDBCInc/SphSQLQueryBase.h"
// Macros definitions
#include "SphInc/fund/SphFundBaseExports.h"

/**
* defines
*/

#ifdef _WIN32
#	pragma warning(push)
#	pragma warning(disable: 4251) // warning C4251: class 'type' needs to have dll-interface to be used by clients of class 'type2'
#endif

/**
* typedef and classes
*/
namespace sophis 
{
	namespace value	
	{
		/** External funds series structure for DB. */
		struct SOPHIS_FUND_BASE SSExtFundSeries
		{
			char fName[SIZE_INSTRUMENT_NAME+1];
			char fReference[SIZE_INSTRUMENT_REF+1];
			char fComment[200+1];
			long fInceptionFund;
			char fExternalRef[SIZE_INSTRUMENT_REF+1];
			long fCurrency;
			long fMarketCode;
			double fQuotity;
			double fIssuePrice;
			long fIssueDate;

			SSExtFundSeries():
			fInceptionFund(0),
			fCurrency(0),
			fMarketCode(0),
			fQuotity(0.),
			fIssuePrice(0.),
			fIssueDate(0)
			{
				*fName = *fReference = *fComment = *fExternalRef = '\0';
			}

			static sophis::sql::CSRStructureDescriptor* GetDescriptor()
			{
				static sophis::sql::CSRStructureDescriptor* desc = 0;
				if (!desc)
				{
					desc = new sophis::sql::CSRStructureDescriptor(10, sizeof(SSExtFundSeries));
					ADD(desc, SSExtFundSeries, fName, sophis::sql::rdfString);
					ADD(desc, SSExtFundSeries, fReference, sophis::sql::rdfString);
					ADD(desc, SSExtFundSeries, fComment, sophis::sql::rdfString);
					ADD(desc, SSExtFundSeries, fInceptionFund, sophis::sql::rdfInteger);
					ADD(desc, SSExtFundSeries, fExternalRef, sophis::sql::rdfString);
					ADD(desc, SSExtFundSeries, fCurrency, sophis::sql::rdfInteger);
					ADD(desc, SSExtFundSeries, fMarketCode, sophis::sql::rdfInteger);
					ADD(desc, SSExtFundSeries, fQuotity, sophis::sql::rdfFloat);
					ADD(desc, SSExtFundSeries, fIssuePrice, sophis::sql::rdfFloat);
					ADD(desc, SSExtFundSeries, fIssueDate, sophis::sql::rdfInteger);
				}
				return desc;
			}
		};


		/** Class that handles external funds series. */
		class SOPHIS_FUND_BASE CSAMExternalFundSeries : public virtual CSAMExternalFund
		{
		public:
			CSAMExternalFundSeries();
			virtual ~CSAMExternalFundSeries();
			static CSAMExternalFundSeries* CreateInstance(long code);

			// internal
			typedef sophis::tools::CSRPrototype<CSAMExternalFundSeries, const char *, sophis::tools::less_char_star> prototype;
			static prototype & GetPrototype();

			//=======  ACCESSORS  =======

			/// Initialise (or reinitialise) all fund data
			virtual void Initialise();

			/** 
			*	Initialise all fund data based on an instrument code and a date
			*	(automatically calls CSAMExternalFund::Load)
			*	
			*	@param instrumentCode is a code of an instrument as found in table INFOS_HISTO
			*	@param dateHisto is an optional past date to retrieve an audited version of a fund
			*/
			virtual void Initialise(long instrumentCode, double dateHisto=0.);

			/** 
			*	Copy all data from another fund
			*	
			*	@param instrument is a pointer on another fund
			*	if this instrument is not a fund, nothing is done
			*/
			virtual void Initialise(const CSAMFundBase* instrument);

			/** 
			*	Create a new copy of a series 
			*	
			*	@return a newly allocated series
			*/
			sophis::instrument::CSRInstrument* Clone() const; // overriden from sophis::instrument::CSRInstrument

			/** 
			*	Gets the internal fund associated to a given code
			*	
			*	@param folio is the identifier of your fund.
			*	the method GetFund returns a pointer on a CSAMFund 
			*	or NULL if sicovam is not the identifier of an external fund 
			*/
			static const CSAMExternalFundSeries* GetFund(long sicovam);

			/** 
			*	Equivalent to dynamic_cast<const CSAMFund*>() but quicker.
			*	
			*	@param theInstrument is a pointer on an instrument
			*	@return this instrument cast in CSAMFund if it is a fund or NULL
			*/
			static const CSAMExternalFundSeries* GetFund(const sophis::instrument::CSRInstrument* theInstrument);
			
			typedef _STL::map<long, _STL::vector<long> > SeriesPerInception;
			/**
			*	Retrieve the list of the existing series ordered by name.
			*/ 
			static void GetExternalFundSeriesList(SeriesPerInception& result, bool reload=false);
			static void DisposeExternalFundSeriesList();

			/** 
			*	Returns a string depending on a fund type
			*	
			*	@param type is a fund type
			*	@return a string to describe this type of funds
			*/
			static const char* GetFundTypeName() { return "series"; };

			virtual const char*	GetHedgeFundTypeName() const { return GetFundTypeName(); };

			/** Set the sicovam of the inception fund */
			void SetInceptionFund(long sicovam);

			/** Get the sicovam of the inception fund */
			long GetInceptionFund() const;

			/** Get historic data from DB */
			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;
			//@}

			/** Get sector of inception fund */
			virtual const sophis::static_data::CSRSector* GetSector(long typeId) const;

			virtual void GetAvailableSectorTypes(_STL::set<long>& types) const;

			virtual void GetAvailableSectors(_STL::set<long>& sectors) const;


		protected:
			long fInceptionFund;

		private:
			static const char* __CLASS__;
		};
	}
}

#ifdef _WIN32
#	pragma warning(pop)
#endif


#endif // _CSAMExternalFundSeries_H_
