/**
*	File:		SphExternalFundTemplate.h
*
*	Contains:	encapsulates the SQL queries for CSAMExternalFund class
*
*	Copyright:	� 2006 Sophis.
*/

#ifndef _Sph_ExternalFundTemplate_H_
#define _Sph_ExternalFundTemplate_H_

#include "SphFundBaseExports.h"
#include "SphFundBaseTemplate.h"

namespace sophis	
{
	namespace value	
	{
		class CSAMExternalFund;
		class CSAmHedgeFund; 
		class CSAmMutualFund;
		class CSAMFundBaseEditCustomizable;
		class CSAMHedgeFundClass;

		class SOPHIS_FUND_BASE CSAMExternalFundTemplate : public virtual CSAMFundBaseTemplate
		{
		public:
			// Default constructor
			CSAMExternalFundTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype=0);
			// Destructor
			virtual ~CSAMExternalFundTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const;
			
			// Clone the instrument and initialize it
			virtual CSAMExternalFund* CreateInstrument() const;
			// Clone the instrument and initialize it with code
			virtual CSAMExternalFund* CreateInstrument(long code) const;
			// Clone the instrument and initialize it with another one
			virtual CSAMExternalFund* CreateInstrument(const CSAMFundBase* instrument) const;

			virtual void BuildSQL(); // overloaded
		
		protected:
			// Default constructor
			CSAMExternalFundTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);
		};
		
		class SOPHIS_FUND_BASE CSAmHedgeFundTemplate : public virtual CSAMExternalFundTemplate
		{
		public:
			// Default constructor
			CSAmHedgeFundTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype=0);
			// Destructor
			virtual ~CSAmHedgeFundTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const;
			
			// Clone the instrument and initialize it
			virtual CSAMExternalFund* CreateInstrument() const;
			// Clone the instrument and initialize it with code
			virtual CSAMExternalFund* CreateInstrument(long code) const;
			// Clone the instrument and initialize it with another one
			virtual CSAMExternalFund* CreateInstrument(const CSAMFundBase* instrument) const;

		protected:
			// Default constructor
			CSAmHedgeFundTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);
		};

		class SOPHIS_FUND_BASE CSAMHedgeFundClassTemplate : public virtual CSAMExternalFundTemplate
		{
		public:
			// Default constructor
			CSAMHedgeFundClassTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype=0);
			// Destructor
			virtual ~CSAMHedgeFundClassTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const;
			
			// Clone the instrument and initialize it
			virtual CSAMExternalFund* CreateInstrument() const;
			// Clone the instrument and initialize it with code
			virtual CSAMExternalFund* CreateInstrument(long code) const;
			// Clone the instrument and initialize it with another one
			virtual CSAMExternalFund* CreateInstrument(const CSAMFundBase* instrument) const;

		protected:
			// Default constructor
			CSAMHedgeFundClassTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);
		};

		class SOPHIS_FUND_BASE CSAmMutualFundTemplate : public virtual CSAMExternalFundTemplate
		{
		public:
			// Default constructor
			CSAmMutualFundTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype=0);
			// Destructor
			virtual ~CSAmMutualFundTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const;
			
			// Clone the instrument and initialize it
			virtual CSAMExternalFund* CreateInstrument() const;
			// Clone the instrument and initialize it with code
			virtual CSAMExternalFund* CreateInstrument(long code) const;
			// Clone the instrument and initialize it with another one
			virtual CSAMExternalFund* CreateInstrument(const CSAMFundBase* instrument) const;

		protected:
			// Default constructor
			CSAmMutualFundTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);
		};

	}
}

#endif