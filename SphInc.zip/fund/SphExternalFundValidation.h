/********************************************************************
*	@date		:	26.06.2007  
*
*	@file		: 	CSAMExternalFundValidation.h
*	
*	@author		:	SOPHIS
*
*	@purpose	:	Classes used for the validation of external funds' nav
*	
*/

#ifdef _WIN32
#	pragma once // speed up VC++ compilation
#endif

#ifndef _SPHAM_EXTERNAL_VALIDATION_H_
#define _SPHAM_EXTERNAL_VALIDATION_H_

#include "SphInc/fund/SphFundBaseExports.h"
#include "SphInc/fund/SphExternalFund.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(vector)

namespace sophis
{
	namespace value
	{
		struct SOPHIS_FUND_BASE ExternalFundData 
		{ 
			ExternalFundData();
			ExternalFundData(const ExternalFundData* data);

			enum EState { eNormal, ePending, eValidated, eError};

			long instrumentCode;			// Instrument external code
			portfolio::TransactionIdent transactionCode;			// Instrument external code
			char name[40];
			eFOFValidation status;
			long ticketNAVDate;
			double NAV;
			long historizedNAVDate;
			double spot;
			double qty;
			double netAmount;
			double equalisationAmount;
			double HWM;
			char error[200];
			EState validationState;

			void SetFromTransaction(const sophis::portfolio::CSRTransaction* transaction, long pNAVDate);	
			bool ResetLineToTransaction();	
			EState UpdateNAV();	

		private:
			static const char* __CLASS__;
		};

		typedef _STL::vector<ExternalFundData> ExternalFundDataList;

		class SOPHIS_FUND_BASE CSAMExternalFundValidation
		{
		public:
			CSAMExternalFundValidation();
			~CSAMExternalFundValidation();

			/** Initialize external fund data from the database 
			*	@param portfolioIds: Portfolios in which we look for external funds
			*	@param validationDate: external fund validation date
			*/
			void Init(const _STL::vector<long>& portfolioIds, long validationDate);

			/** Update the status of external fund transactions */
			void UpdateEFTransactions();

			/** Clear the external fund data list */
			void Clear();
				
			/** Insert an external fund data into the list */
			void Insert(const ExternalFundData& data);
			
			const ExternalFundDataList& GetExternalFundDataList() const { return fEFData; };
		private:
			ExternalFundDataList fEFData;
			static const char* __CLASS__;
		};
	}
}

#endif