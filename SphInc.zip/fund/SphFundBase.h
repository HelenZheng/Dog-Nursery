/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphFundBase.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Base class for funds management
*
*/

#ifdef _WIN32
#	pragma once
#endif

#ifndef _SphFundBase_H_
#define _SphFundBase_H_

/**
* System includes
*/

/**
* Application includes
*/
#include "SphInc/instrument/SphInstrument.h"
#include "SphInc/finance/SphProductTypeSubject.h"
#include "SphInc/finance/SphMetaModel.h"
#include "SphFundBaseTemplate.h"
#include "SphFundSRFees.h"
#include "SphUserParameters.h"
#include "SphFundFieldEnums.h"

// Macros definitions
#include "SphFundBaseExports.h"
#include "SphTools/SphPrototype.h"
#include "SphTools/SphDay.h"


/**
* defines
*/
#ifdef _WIN32
#	pragma warning (push)
#	pragma warning (disable : 4786)
#endif

#include __STL_INCLUDE_PATH(set)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(list)
#include __STL_INCLUDE_PATH(map)

#ifdef _WIN32
#	pragma warning(pop)
#endif

/**
* typedef and classes
*/

enum eRoundingModeType
{
	rmUndefined=-1,
	rmUpper=1,
	rmLower,
	rmNearest,
	rmTruncate,
	rmCount=4
};

enum eNAVDatesType
{
	nNA=0, //not applicable, optional in redemption calendar
	ndDaily,
	ndWeekly,
	ndCustom
};

enum eFOFValidation 
{
	efNoStatus,
	efInQty,
	efInAmt,
	efValidated
};

enum eETFType
{
	etfPhysic=1,
	etfSynthetic,
	etfCount=2
};

class CSRUserRights;


#ifdef _WIN32
#	pragma warning(push)
#	pragma warning(disable: 4251) // warning C4251: class 'type' needs to have dll-interface to be used by clients of class 'type2'
#endif

namespace sophis 
{
	namespace instrument	
	{
		class CSAMFundBaseAction;
		class CSREquity;
		class CSRPackage;
	}

	namespace static_data
	{
		class CSAMFundBaseXMLDescription;
		class CSAMFundBaseXMLUpdate;
	}

	namespace market_data
	{
		class CSRDividend;
		typedef _STL::shared_ptr<CSRDividend> CSRDividend_Ptr;
	}

	namespace value	
	{
		// internal
		class CSAMFundUserEditPage;
		class CSAMEODData;
		class CSAmFundField;
		class CSAmFundFieldGroup;
		class CSAmFundFieldGroupContainer;
		class CSAmMiscFieldGroup;
		class CSAmReturnsFieldGroup;
		class CSAmRiskFieldGroup;
		class CSAMFundBaseHistoryData;
		class CSAMFundBaseDealUpdate;
		class CSAMFundBreakdown;
		class ISAmBenchmarkBase;
		struct SSAmFundBaseLoadHelper;
		struct SSAmFundFieldKey;

		class SOPHIS_FUND_BASE CSAMDefaultMetaModelFundBase : public virtual sophis::finance::CSRMetaModel
		{
		public:
			DECLARATION_META_MODEL(CSAMDefaultMetaModelFundBase);
			virtual ~CSAMDefaultMetaModelFundBase();

			virtual double GetFirstDerivative(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData &context, int which) const OVERRIDE;
			virtual double GetSecondDerivative(const sophis::instrument::CSRInstrument& instr, const sophis::market_data::CSRMarketData &context, int which1, int which2) const OVERRIDE;
			virtual double GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long date, market_data::eTaxCreditPercentageType forEvaluation, 
											const market_data::CSRMarketData& context,
											const instrument::CSRInstrument* initialForward = NULL) const OVERRIDE;
			virtual void	GetForwardPrice(const sophis::instrument::CSRInstrument& instr, long					 *futureDates,
													double					 *val,
													short					 dateCount,
													market_data::eTaxCreditPercentageType forEvaluation,
													const market_data::CSRMarketData		 &context,
													const instrument::CSRInstrument*		initialForward = NULL) const OVERRIDE;
			virtual	void	GetLinearValue(const sophis::instrument::CSRInstrument& instr, 			double					 computationDate,
													long 					 futureDate,
													instrument::eSettlementType 		 settlementType,
													market_data::eTaxCreditPercentageType forEvaluation,
													double 					 *a,
													double 					 *b,
													double 					 *rate,
													const market_data::CSRMarketData		 &context) const;
			virtual	void	GetValue(const sophis::instrument::CSRInstrument& instr, 				double 					 computationDate,
													long 					 futureDate,
													double 					 futureValue,
													instrument::eSettlementType 		 settlementType,
													market_data::eTaxCreditPercentageType forEvaluation,
													double 					 *spot,
													const market_data::CSRMarketData 	 &context) const OVERRIDE;
			virtual void	GetForwardQuantoPrice(const sophis::instrument::CSRInstrument& instr, 	long					 *futureDates,
													double					 *val,
													int					 dateCount,
													market_data::eTaxCreditPercentageType forEvaluation,
													long strikeCurrency,
													double overVolatility,
													NSREnums::eVolatilityType volatType,
													bool put,
													const market_data::CSRMarketData		 &context) const OVERRIDE;
		};

		class SOPHIS_FUND_BASE CSAMFundBase : public virtual sophis::instrument::CSRInstrument,
		                                      public sophis::finance::ISRProductTypeSubject
		{
		public:
			/** 
			*	This method returns the status of the fund.
			*/
			virtual instrument::eInstrumentStatus GetStatus(void) const OVERRIDE;
			
			/**
			*	This method set the status of the fund.
			*/
			virtual void SetStatus(instrument::eInstrumentStatus status) OVERRIDE;

			CSAMFundBase();
			virtual ~CSAMFundBase();

			virtual const sophis::finance::CSRMetaModel * GetDefaultMetaModel() const OVERRIDE;

			//=======  ACCESSORS  =======

			/// Initialise (or reinitialise) all fund data
			virtual void Initialise();

			/** 
			*	Initialise all fund data based on an instrument code and a date
			*	(automatically calls CSAMFundBase::Load)
			*	
			*	@param instrumentCode is a code of an instrument as found in table INFOS_HISTO
			*	@param dateHisto is an optional past date to retrieve an audited version of a fund
			*/
			virtual void Initialise(long instrumentCode, double dateHisto=0.);

			/** 
			*	Copy all data from another fund
			*	
			*	@param instrument is a pointer on another fund
			*	if this instrument is not a fund, nothing is done
			*/
			virtual void Initialise(const CSAMFundBase* instrument);

			/// Load all fund data from database
			void Load(); 

			/**
			 *  Return the loading helper structure to use when loading the concrete fund class.
			 *  Must return a new instance dynamically allocated of the concrete structure.
			 *  This instance will be automatically deleted once loading has been performed.
			 */
			virtual SSAmFundBaseLoadHelper* GetNewLoadHelper() const = 0;

			/**
			 *  Fill the fund with data stored in the loading helper struct.
			 *  The base class InitFromLoadStruct() must be called first.
			 */
			virtual void InitFromLoadHelper(const SSAmFundBaseLoadHelper* loadHelper);

			/**
			 *  Return the loading helper structure to use when saving the concrete fund class.
			 *  Must return a new instance dynamically allocated of the concrete structure, filled with correct data from the fund.
			 *  This instance will be automatically deleted once saving has been performed.
			 */
			virtual SSAmFundBaseLoadHelper* GetNewSaveHelper() const = 0;

			/** Load infos depending on the type of the fund. Called by Load() */
			virtual void LoadSpecificData() {}; 

			/** 
			*	Create a new copy of a fund 
			*	
			*	@return a newly allocated fund
			*/
			sophis::instrument::CSRInstrument* Clone() const = 0; // overriden from sophis::instrument::CSRInstrument

			/** 
			*	Link with CSAMFundBaseTemplate
			*	
			*	@see CSAMFundBaseTemplate in SphFundTemplate.h
			*/
			void SetModelName(const char *model); // overriden from sophis::instrument::CSRInstrument
			const CSAMFundBaseTemplate* GetTemplate() const;
			static const CSAMFundBaseTemplate* GetTemplate(long sico, eHedgeFundType fundType, double dateHisto=0.);

			/** 
			*	Gets the fund associated to a given code
			*	
			*	@param folio is the identifier of your fund.
			*	the method GetFund returns a pointer on a CSAMFundBase 
			*	or NULL if sicovam is not the identifier of a fund 
			*/
			static const CSAMFundBase* GetFund(long sicovam);

			/** 
			*	Equivalent to dynamic_cast<const CSAMFundBase*>() but quicker.
			*	
			*	@param theInstrument is a pointer on an instrument
			*	@return this instrument cast in CSAMFundBase if it is a fund or NULL
			*/
			static const CSAMFundBase* GetFund(const sophis::instrument::CSRInstrument* theInstrument);

			//=======  FUNDS DATA / ACCESS =======

			virtual char			GetType() const { return 'Z'; }
			void					GetName(char* name) const; 
			char*					GetReference(char* ref) const; 
			void					GetExternalReference(char* ref) const; 
			void					GetModelName(char* model) const; 
			const char*				GetModelName() const { return fTemplateName; }
			eHedgeFundType			GetHedgeFundType() const { return fHedgeFundType; }
			virtual const char*		GetHedgeFundTypeName() const = 0;

			long					GetMarketCode() const; 
			long					GetLegalForm() const { return fLegalForm; }
			double					GetParity() const { return fParity; }
			char*					GetComment(char* dest) const; 

			long					GetIssueDate() const;
			long					GetExpiry() const;
			double					GetIssuePrice() const;
			double					GetIssuedSharesCount() const { return fIssuedShares; }
			virtual short			GetNAVNbDecimals() const;
			long					GetBenchmarkCode() const { return fBenchmarkCode; }
			double					GetDateHisto() const { return fDateHisto; }
			double					GetQuotity(bool withTaxes=false) const;
			double					GetFundQuotity() const;


			long					GetCodeAtCreation() const { return fCodeAtCreation; }

			virtual eRoundingModeType		GetSRRoundingMode() const;

			/// Code of the internal entity (class CSRThirdParty) which deals in the name of the fund
			long					GetEntity() const;

			/** 
			*	Returns the percentage of initial subscription value that is guaranteed at expiry to the shareholders
			*	@return 100.0 for 100%
			*/
			virtual	double			GetStrike(const static_data::CSRHistoricalData &histoData) const;

			/** 
			*	Get the calendar associated to a fund.
			*	
			*		Each instrument has a calendar associated with it. It is used everytime we need to calculate
			*		a date (NAV dates, fees, etc)
			*	@return the associated calendar of the instrument. By default, return
			*		the calendar associated with the market if not null, otherwise return the currency.
			*		The return object may be de-allocated using CSRCalendar::Delete, but this method
			*		does not do anything. In practice, it is a const pointer.
			*	 @see CSRCalendar
			*/
			virtual static_data::CSRCalendar* NewCSRCalendar() const;

			/**
			*	Return true if the fund has expired on a given date, i.e. if the fund has a valid expiry date and if the date
			*	provided as a parameter is (strictly) greater than that expiry date.
			*	When no date is specified, the calculation date is used (the first prices date).
			*/
			bool HasExpired(long onDate = 0) const;

			/** 
			*	Returns the code of the instrument dedicated to fees on this fund
			*	@return an instrument code
			*	@see class CSRInstrument
			*/
			long GetFeesInstrument() const;
			
			/**
			*	Returns the underlying package 
			*	@return the underlying package 
			*/
			virtual sophis::instrument::CSRPackage * GetPackage() const;
			
			/**
			*	Updates the underlying package 
			*/
			virtual void UpdatePackage();

			//=======  NAV & SHARES MANAGEMENT  =======
			/**
			*	Retrieves the total NAV for a given date (from database history)
			*
			*	@param date is the requested date
			*	@return one double value
			*/
			double GetTotalNAV(long date) const;

			/** 
			*	Retrieves the number of decimals to use whenever displaying the number of fund shares.
			*	This number is based on the number of decimals of the fund quotity.
			*
			*	@param none
			*	@return the number of decimals to use for the number of fund shares
			*/
			short GetSharesNbDecimals() const;

			/** 
			*	@return the number of NAV dates defined for this fund
			*
			*	@see GetNthNAVDate
			*/
			int	GetNAVDateCount() const;

			/** 
			*	@param i is a value between 0 and GetNAVDateCount()-1
			*
			*	@return the i-th NAV date or 0 if out of range
			*	@see GetNAVDateCount
			*/
			long GetNthNAVDate(int i) const;

			/** 
			*	Returns the list of all NAV dates associated to the fund.
			*
			*	@return a vector of dates 
			*	@see GetNAVDateCount
			*/
			const _STL::vector<long>& GetNAVDates() const;

			/** 
			*	Returns a list of all NAV dates between two dates 
			*	(using successive calls to GetNAVDateAfter)
			*
			*	@param date1 is the lowest date
			*	@param date2 is the highest date
			*	@param bool	redemption: indicated if nav dates for redemption have to be considered.
			*	@return a vector of all NAV dates between date1 and date2
			*	@see GetNAVDates, GetNAVDateAfter
			*/
			virtual _STL::vector<long> GetNAVDatesBetween(long date1, long date2,bool redemption = false) const;

			/** 
			*	Returns the first NAV date after a given date, using NAV dates parameterisation
			*	and fund calendar (when parameters set to default)
			*
			*	@param long	date is a requested date 
			*	@param long	currency is the fund's currency
			*	@param long	marketCode is the fund's corresponding marker code 
			*	@param long	issueDate fund's issue date 
			*	@param long	expiry fund's expiry date 
			*	@param short navDatesType 
			*	@param short weekNAVDate
			*	@return a NAV date or the date given as parameter if higher than the fund expiry date
			*/
			virtual long GetNAVDateAfter(long	date, 
										 long	currency = -1, 
										 long	marketCode = -1, 
										 long	issueDate = -1, 
										 long	expiry = -1, 
										 short	navDatesType = -1, 
										 short	weekNAVDate = -1,
										 bool redemption = false) const;

			/** 
			*	Returns the first NAV date after a given date, using NAV dates parameterisation
			*	and fund calendar (when parameters set to default)
			*
			*	@param long	date is a requested date 
			*	@param long	code is the fund's code 
			*	@param long	currency is the fund's currency
			*	@param long	marketCode is the fund's corresponding marker code 
			*	@param long	issueDate fund's issue date 
			*	@param long	expiry fund's expiry date 
			*	@param short navDatesType 
			*	@param short weekNAVDate
			*	@return a NAV date or the date given as parameter if higher than the fund expiry date
			*/
			static long GetNextNAVDate(long		date, 
									   long		code, 
									   long		currency, 
									   long		marketCode, 
									   long		issueDate, 
									   long		expiry, 
									   short	navDatesType, 
									   short	weekNAVDate);

			/** 
			*	Returns the first NAV date after a given date, using NAV dates parameterisation
			*	and fund calendar
			*
			*	@param date is a requested date
			*	@param bool	redemption: indicated if nav dates for redemption have to be considered.
			*	@return a NAV date or the date given as parameter if lower than the fund issue date
			*/
			virtual long GetNAVDateBefore(long date) const;

			/** 
			*	Returns the most appropriate NAV date, using NAV dates parameterisation
			*	and fund calendar (either after or before depending on market rules)
			*
			*	@param date is a requested date
			*	@return a NAV date or GetNAVDateAfter() if no calendar available
			*	@see GetCalendar
			*/
			long GetMatchingNAVDate(long date) const; 

			/** 
			*	Returns the nearest NAV date between GetNAVDateAfter() and GetNAVDateBefore()
			*
			*	@param date is a requested date
			*	@return a NAV date or GetNAVDateAfter() if no calendar available
			*	@see GetNAVDateAfter, GetNAVDateBefore
			*/
			long GetNearestNAVDate(long date) const;

			/**
			 *  Says if the given date is an official NAV date.
			 *  @param date is a requested date.
			 *  @return true if the given date is an official NAV date, false otherwise.
			 */
			virtual bool IsOfficialNavDate(long date) const;

			/** 
			*	Returns the way NAV dates are defined : daily, weekly or custom
			*
			*	@return a "NAV dates" type
			*	@see eNAVDatesType
			*/
			eNAVDatesType GetNAVDatesType() const { return fNAVDatesType; }

			/** 
			*	Returns the chosen day for weekly NAV dates 
			*
			*	@return a day in week
			*	@see GetNAVDatesType, sophisTools::eWeekdayType
			*/
			sophisTools::eWeekdayType GetWeekNAVDay() const { return fWeekNAVDay; }

			/** 
			*	Returns the chosen day for weekly NAV dates 
			*
			*	@return a day in week
			*	@see GetNAVDatesType, sophisTools::eWeekdayType
			*/
			virtual long GetSettlementDate(long transactionDate) const;


			//=======  HISTORICAL DATA  =======
			/** Return an instance of CSAMFundBaseHistoryData used to get historic data 
			*	The pointer MUST BE DELETED.
			*/
			virtual CSAMFundBaseHistoryData* new_HistoryData() const = 0;

			virtual sophis::market_data::CSRHistoricList* new_HistoricList(sophis::market_data::TInfoHisto * infos) const;

			//=======  FEES & DIVIDENDS MANAGEMENT  =======
			/**
			*	Retrieves the most recent date prior to the requested date  (from DB)
			*	where a EOD has been processed or 0 if none can be found
			*	@param	date: requested date
			*	@param	clause: sql clause to specify the EOD type
			*/
			long GetLastEODDate(long date, const char* clause="") const;

			/** 
			*	@return the number of dividends defined for this fund
			*/
			int GetDividendCount() const;

			/** 
			*	Delete all dividends tickets created with a given value date for this fund
			*
			*	@param date is the dividends value date
			*	@param messages is set in return with a vector of messages to be processed
			*/
			void DeleteDividendTransactions(long date, sophis::tools::CSREventVector & messages) const;

			market_data::CSRDividend_Ptr GetDividends() const;

			void SetDividends(market_data::CSRDividend_Ptr dividends);

			/** 
			*	Creates an array of dividends
			*
			*	@return an array of dividends
			*	@see CSRInstrument
			*/
			virtual sophis::instrument::SSDividendArray* new_DividendArray(	
				long 											beginDate, 
				long 											endDate,
				sophis::instrument::eSettlementType				settlementType,
				const sophis::market_data::CSRMarketData&		context,
				sophis::market_data::eTaxCreditPercentageType	toEvaluate,
				int*											elementsCount) const;

			/** 
			*	A dummy method to avoid problems during dividends calculation
			*	@see CSRInstrument
			*
			*/		
			virtual double GetDividendCreditFactor(
											long									date,
											sophis::market_data::eDividendValueType	type,
											sophis::market_data::eDividendNatureType nature,
											long*									untilDate) const ;


			/** Calculates the dividend amount which is going to be distributed over a period of time.
			This function is called during theta calculation and P&L attributions.
			@param startDate is the start of the period. It is excluded.
			@param endDate is the end of the period. It is included.
			@param context is the market data.
			@param discounted asks for discount of the coupons.
			@return	The dividend amount.
			*/
			virtual double	GetCouponAmount(		long				startDate,
													long				endDate,
													const market_data::CSRMarketData& context,
													bool				discounted) const;

			/** Gets the next dividend date after the given transaction date, as well as the dividend rate.
			The next dividend chosen must be in Monetary Unit and must be of type "Dividend" or "Exceptional Dividend"
			(for non-standard dividend types). See {@link market_data::eDividendNatureType}.
			@param whichLeg	Does not apply for the case of equities. However, value 0 must be passed in order to get results.
			@param transactionDate The transaction date after which the next dividend is sought. It is expressed in number of days since 01/01/1904.
			@param nextCouponDate Output parameter - The date of next dividend sought. It is expressed in number of days since 01/01/1904.
			@param couponRate Output parameter - The rate of next dividend sought. It is expressed in number of days since 01/01/1904.
			@param mayModifyCumExDistribution Output parameter set to False if the type of Dividend In Tax Credit is a "Negociation Dividend".
			@param PariPassDate Output parameter set to dividend date + 1 day, if the equity's market specify American as the type of Ex-dividend Date Calculation. Otherwise, it is set to False.
			This is expressed in number of days since 01/01/1904.
			*/
			virtual void	GetNextCouponDate(		int					whichLeg,
													long				transactionDate,
													long				*nextCouponDate,
													double				*couponRate,
													bool	*mayModifyCumExDistribution,
													long	*PariPassDate) const;

			/** Get the next coupon date.
			This method is called during the reporting to calculate the coupon to receive column.
			It is called only if the position is opened or if there was a transaction forty days before.
			*/
			virtual	void	GetNextCouponDate(	long	transactionDate,
												CouponList &couponList) const;

			//=======  Repo ===========
			virtual double	GetRepoMargin(double date1,double date2) const OVERRIDE;

			//=======  S/R FEES =======

			/** 
			*	Returns the S/R fees associated to the fund.
			*	@see CSAMFundSRFees
			*/
			const CSAMFundSRFees& GetFundSRFees() const {return fFundSRFees;}

			//======= FUND DEALS COMPUTATION =======

			/**
			*	Returns an object in charge of computing a fund deal data (shares number, fees and amounts).
			*	It MUST BE DELETED.
			**/
			virtual CSAMFundBaseDealUpdate * new_FundDealUpdater() const = 0;

			virtual bool SpecialTransaction(portfolio::CSRTransaction &transaction, RecalculeTransaction type) const;

			//=======  PARAMETERS  ======
			/**
			*	Accessor to the parameters.
			*/
			const _STL::vector<SSUserParameter>& GetUserParameters() const;

			/* user-defined parameters & indicators, and worksheets */
			void SetUserParameters(const _STL::vector<SSUserParameter>& r);
			
			//=======  CALCULATION  =======

			// all methods overridden from CSRInstrument

			virtual bool	HasFairValue() const = 0; 
			virtual double	GetAccountingValue(const market_data::CSRMarketData &context) const;

			//virtual void	InitialiseRecomputeAll() = 0;

			//virtual int		GetUnderlyingCount() const;
			//virtual long	GetUnderlying(int whichUnderlying) const = 0;
			//virtual Boolean	IsAnUnderlying(long instrumentCode, int *whichUnderlying=0) const;


			virtual double	GetEquityGlobalDelta(const sophis::CSRComputationResults& results) const OVERRIDE;
			virtual double	GetEquityGlobalDelta(const market_data::CSRMarketData &context) const OVERRIDE;
			virtual double	GetDelta(const sophis::CSRComputationResults& results, long *code) const OVERRIDE;
			virtual double	GetGamma(const sophis::CSRComputationResults& results,long *code) const OVERRIDE;

			//virtual int		GetRhoCount() const;
			//virtual long	GetRhoCurrency(int whichUnderlying) const;
			//virtual Boolean	IsARhoCurrency(long currency, int *whichUnderlying=0) const;

			Boolean			IsAPossibleSettlementType(sophis::instrument::eSettlementType s) const;


			/** 
			*	Add cash flows between start date and end_date (used by Cash balance)
			*
			*	@see CSRInstrument
			*/
			virtual void AddCashFlow(
				long									start_date, 
				long									end_date, 
				const sophis::portfolio::CSRPosition&	position, 
				sophis::portfolio::ISRCashFlow&			cashFlow,
				const sophis::market_data::CSRMarketData* context = NULL) const;

			virtual double GetTradingUnits() const;


			//=======  FUNDS DATA / MODIFICATION =======
			const bool		SetCurrency(const long currency); 
			void			SetName(const char* name);
			void			SetReference(const char* ref);
			const bool		SetExternalReference(const char* ref);

			const bool		SetMarketCode(const long value);	
			void			SetLegalForm(long form);
			const bool		SetComment(const char* comment); 

			void			SetIssueDate(long date);
			const bool		SetExpiry(const long expiry);
			void			SetIssuePrice(double price);
			void			SetIssuedSharesCount(double n);
			virtual void	SetNAVNbDecimals(short nbDecimal);
			virtual void	SetBenchmarkCode(long code);
			const bool		SetQuotity(const double value); 
			const bool		SetFundQuotity(const double value);
			void			SetParity(const double value);
			void			SetStrike(double s);

			virtual void	SetSRRoundingMode(eRoundingModeType t);

			void			SetEntity(long entity);
			void			SetFeesInstrument(long instr);

			void			SetFundSRFees(const CSAMFundSRFees& srFees);
			void			SetNAVDates(int count, const long* dates);
			void			SetNAVDates(const _STL::vector<long>& navDates);
			void			SetNAVDatesType(eNAVDatesType type);
			void			SetWeekNAVDay(sophisTools::eWeekdayType type);
			virtual void	SetQuotedValue(double m2mPrice);

			void			SetCodeAtCreation(long CodeAtCreation);
			//=======  MISC  =======

			/**
			*  Rounds an amount according to the fund's rounding method
			*/

			double RoundAmount(double amount, double factor) const;

			/**
			*  Rounds an amount according to the fund's rounding method and
			*   its currency rounding method
			*/   

			double RoundAmount(double amount) const;

			/**
			*	Retrieve the latest audited code for the specified date.
			*/
			long GetLatestAuditedCode(long sicovam, long date, const char* table, bool defaultValue=true) const;

			/* 
			*	Set that contains all table names that have been modified.
			*	Multiple insertions of the same table name is not possible
			*	into a set, its key is unique.
			*/
			mutable _STL::set<_STL::string>	fSetTablesModified;
			
			virtual bool HasPurchaseTransaction(long code) const = 0;

			/**
			*	GetHistoTableName() is used in the historization mechanism. 
			*	It fills the table name modified for this fund
			*
			*	@param the name of the historization table
			*	@throws GeneralException if fund code not in infos_histo (or more than once)
			*/
			void GetHistoTableName(char* name) const;

			//=======  LOOK-THROUGH MANAGEMENT  =======
			virtual bool HasTransparencyBreakDown(sophis::portfolio::PSRExtraction extraction) const;
			virtual void GetTransparencyBreakDown(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                      sophis::portfolio::PSRExtraction extraction,
			                                      const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                      const sophis::portfolio::eLookthroughType splitByComponents,
			                                      double* evalInstrument,
			                                      double* evalLookthroughDeals) const;

			virtual bool UseBenchmarkForLookthrough() const = 0;
			virtual bool HasLookthroughComponents(sophis::portfolio::PSRExtraction extraction) const = 0;
			virtual void GetLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                       sophis::portfolio::PSRExtraction extraction,
			                                       const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                       const sophis::portfolio::eLookthroughType splitByComponents,
			                                       double* evalInstrument,
			                                       double* evalLookthroughDeals) const = 0;



			/**
			*	GetOldCode() is used in the historization mechanism. It retrieves the original
			*	sicovam code from the historization code and one specified date...
			*	different from GetVieuxCode: date is a double, not a long
			*
			*	@param long the historization code, the date , and the name of the historization table
			*	@param defaultValue in case of failure (if false return 0, if true return the current sicovam code)
			*	@return the original sicovam code, 0 or the current sicovam code if it fails 
			*	@throws no exception, 
			*/
			long GetOldCode(long sicovam, double date, const char* table, bool defaultValue=true) const;

			virtual bool MatchMarkPnLRule(char* instrType, char* instrFeature1, char* instrFeature2) const;

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;
			//@}

			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual bool HasFeature(const sophis::finance::CSRProductFeature &feature, const _STL::string &featureName) const;
			//@}
			/** @name ISRProductTypeSubject interface implementation */
			//@{
			virtual long GetCurrency() const {return CSRInstrument::GetCurrency();}
			//@}
			/** @name CSAMFundBase data model */
			//@{
			// ========  Generic data  ========
			// Generic fund fields access
			CSAmFundFieldGroupContainer* fFundFields;
			CSAmFundFieldGroup* GetFundFieldsGroup(EFundFieldCategory category) const;
			CSAmFundField* GetFundField(const SSAmFundFieldKey &key) const;

			// Specific fund fields group access
			CSAmMiscFieldGroup* GetMiscDataGroup() const;
			CSAmReturnsFieldGroup* GetReturnsDataGroup() const;
			CSAmRiskFieldGroup* GetRiskDataGroup() const;

			// Data model save management
			bool MustSaveFundFields() const;
			void SaveFundFields(long sicoHisto) const;
			void SetFundFieldsSaved() const;

			/** Namespace of the root in the xml description.
				@return the namespace string.
				This is called before {@link GetDescription_API} to set specific
				namespace. For  example, namespace of external fund instrument.
				By default, returns "www.sophis.net/Instrument".
				@version 4.3.2
			*/
			virtual _STL::string GetXMLRootNamespace() const;

			virtual double GetBenchmarkCoeff(const sophis::market_data::CSRMarketData& context, long date) const;
		protected:

			/** 
			*	Allocates and returns a new list of dividends for this fund
			*	@see CSRDividend
			*/
			sophis::market_data::CSRDividend_Ptr new_DividendList() const;

			static void GetTemplateName(char* model, long sico, double dateHisto=0.);

			/** Get an object that manages the xml description of a fund 
			*	It MUST BE DELETED 
			*/
			virtual sophis::static_data::CSAMFundBaseXMLDescription* new_XMLDescriptor() const;

			/** Get an object that manages the update of a fund 
			*	It MUST BE DELETED 
			*/
			virtual sophis::static_data::CSAMFundBaseXMLUpdate* new_XMLUpdater();

			/**
			*	Initialize or modify the fund from a description.
			*	@param dataSet is an object that contains data with which the fund can be built or modified.
			*	A DataSet can be built from an XML file for instance.
			*	@throw GeneralException if the dataSet is invalid: the instrument cannot be built from it.
			*	It is called during XML Paste from clipboard (for instance).
			*	@since 2.3.2
			*	@see UpdateFromDescription_API
			*/
			virtual void UpdateFromDescription(const sophis::tools::dataModel::DataSet& dataSet);

			/**
			*	Check the fund after an update from a description.
			*	@param dataSet is an object that contains data with which the fund can be built or modified.
			*	@throw InvalidDataValue if the instrument is invalid after update.
			*	It is called during XML Paste from clipboard (for instance), after UpdateFromDescription.
			*	@since 3.2.6
			*	@see UpdateFromDescription_API
			*/
			virtual void CheckDescription(const sophis::tools::dataModel::DataSet& dataSet);

			/** Name of the root in the xml description.
			  *	@return a string C which must not be deleted.
			  *	This is called by {@link GetDescription_API} to construct the xml.
			  *	By default, throws a NotImplemented exception.
			  * @since 2.3.2
			  */
			virtual const char * GetXMLRootName() const = 0;

			/** Retrieve a description from an instrument.

			  * @param dataSet is the description to be filled with this instrument.
			  * @throw GeneralException if this instrument is invalid: the description cannot be built from it.
			  * It is called by the data service in view of updating the instrument using a XML provided by an external source. 
			  * @since 2.3.2
			  * @see GetDescription_API
			  */
			virtual void GetDescription(sophis::tools::dataModel::DataSet& dataSet) const;


			/** Synchonises fReference members of CSAMFundBase
			*	internal use
			*	@since 3.2.6
			*/
			void SynchronizeReferences();


			//=======  LOOK-THROUGHT MANAGEMENT  =======
			bool CanUseBenchmarkForLookthrough(sophis::portfolio::PSRExtraction extraction) const;
			bool CanUseIndexBenchmarkForLookthrough(sophis::portfolio::PSRExtraction extraction,
			                                        const sophis::instrument::CSREquity &indexBenchmark) const;
			bool CanUseAmBenchmarkForLookthrough(sophis::portfolio::PSRExtraction extraction,
			                                     const ISAmBenchmarkBase &amBenchmark) const;

			void GetBenchmarkLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                       sophis::portfolio::PSRExtraction extraction,
			                                       const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                       const sophis::portfolio::eLookthroughType splitByComponents,
			                                       double* evalInstrument,
			                                       double* evalLookthroughDeals) const;
			void GetSimpleBenchmarkLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                             sophis::portfolio::PSRExtraction extraction,
			                                             const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                             const sophis::portfolio::eLookthroughType splitByComponents,
			                                             double* evalInstrument,
			                                             double* evalLookthroughDeals,
			                                             const sophis::instrument::CSRInstrument &simpleBenchmark) const;
			void GetAmBenchmarkLookthroughComponents(_STL::vector<sophis::instrument::CSRInstrument::SSTransparencyBreakDown> &components,
			                                         sophis::portfolio::PSRExtraction extraction,
			                                         const sophis::portfolio::CSRExtractionCriteriaKey* folioKey,
			                                         const sophis::portfolio::eLookthroughType splitByComponents,
			                                         double* evalInstrument,
			                                         double* evalLookthroughDeals,
			                                         const ISAmBenchmarkBase &amBenchmark) const;
			/*Support Specific calendar for Redemption*/
			virtual eNAVDatesType GetNavDateTypeForRedemption() const 
			{
				return fNAVDatesType;
			}
			virtual sophisTools::eWeekdayType GetWeekNavDateForRedemption() const 
			{
				return fWeekNAVDay;
			}
			virtual _STL::string GetTableForCustomRedemptionNavDate() const 
			{
				return "fund_navdates";
			}
			virtual long GetRedemptionNAVDateAfter(long	date, 
										 long	currency = -1, 
										 long	marketCode = -1, 
										 long	issueDate = -1, 
										 long	expiry = -1, 
										 short	navDatesType = -1, 
										 short	weekNAVDate = -1) const
			{
				return GetRedemptionNAVDateAfter(date, currency ,issueDate,expiry,navDatesType,weekNAVDate);
			}
			

		protected:

			// data ---------------------------------------
			char							fName[40];
			char							fReference[25];
			char							fExternalRef[40];
			char							fComment[201];
			eHedgeFundType					fHedgeFundType;
			double							fQuotity;
			double							fParity;
			long							fIssueDate;
			double							fIssuePrice;
			double							fIssuedShares;
			long							fExpiry;
			short							fNAVNbDecimals;
			short							fSharesNbDecimals;
			long							fMarketCode;
			double							fStrike;
			_STL::vector<long>				fNAVDates;
			eRoundingModeType				fSRRoundingMode;
			CSAMFundSRFees					fFundSRFees;
			long							fEntity;
			long							fFeesInstrument;
			long							fBenchmarkCode;
			eNAVDatesType					fNAVDatesType;
			sophisTools::eWeekdayType		fWeekNAVDay;
			long							fLegalForm;
			market_data::CSRDividend_Ptr	fDividends;
			instrument::eInstrumentStatus	fFundStatus;

			// List of custom nav dates. Mutable because it is fed on the fly
			// if needed
			mutable _STL::set<long>			fCustomNAVDates;


			// user defined parameters ------------------------
			_STL::vector<SSUserParameter>	fUserParameters;
			mutable char					fTemplateName[FUND_TEMPLATE_NAME_LENGTH];

			// internal ---------------------------------------
			double							fDateHisto;
			long							fCodeAtCreation;

			// data storage ---------------------------------------
			void LoadNAVDates();
			void LoadSRFees();
			void LoadUserParameters();

			// misc ---------------------------------------

			/**
			*	Fetch all the custom nav dates for the fund
			* 	@warning const because it is called from const methods
			*/
			void LoadRedemptionNAVDates() const;

			/** 
			*	Sets the number of decimals to use whenever displaying the number of fund shares.
			*	This number is based on the number of decimals of the fund quotity.
			*
			*	@param none
			*	@return nothing
			*/
			void SetSharesNbDecimals();

			/**
			*	Return true if the name of fund whose code is fundCodeLeft lexically precedes 
			*	the name of the fund whose code is fundCodeRight (thus allowing to sort funds by name)
			*/
			static bool LexicalLessThan(long fundCodeLeft, long fundCodeRight);

			friend class sophis::instrument::CSAMFundBaseAction;
		
		private:
			static const char* __CLASS__;
		};
	}
}

#ifdef _WIN32
#	pragma warning(pop)
#endif


#endif // _SphFundBase_H_
