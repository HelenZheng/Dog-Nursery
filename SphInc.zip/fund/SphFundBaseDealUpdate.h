/********************************************************************
*	@date:		2006
*	
*	@file:	 	CSAMFundBaseDealUpdate.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Classes used to compute fees, number of shares and amounts 
*				when modifying a deal on a fund
*
*/

#ifndef _CSAM_FUND_BASE_DEAL_UPDATE_H_
#define _CSAM_FUND_BASE_DEAL_UPDATE_H_

#include "SphFundBaseExports.h"
#include "SphFundBase.h"
#include "SphInc/portfolio/SphPortfolioIdentifiers.h"

namespace sophis	
{
	namespace value	
	{
		/** defines which information is the reference for a subscription/redemption */
		enum eSRType
		{
			srtUndefined=-1,
			srtNetAmount=1,
			srtShares,
			srtGrossAmount,
		};

		/** Base structure containing all the data that may be modified by an update of the transaction */
		struct SOPHIS_FUND_BASE SSAMBaseDeal
		{
			double fSharesNb;		// number of shares subscribed or redeemed
			double fGrossAmount;
			double fNetAmount;		// net amount, that is gross amount - fees
			double fNav;			// nav per shares
			double fNbUnits;		// shares number / fund quotity
			eSRType fSrType;
			long fFundCode;
			short fBusinessEvent;
			portfolio::TransactionIdent fDealCode;
			long fNavDate;

			SSAMBaseDeal(long fundCode, 
			             portfolio::TransactionIdent dealCode, 
			             long navDate,
						 double shares, 
						 double grossAmount, 
						 double netAmount,
						 double nav, 
						 double units, 
						 eSRType srType);

			SSAMBaseDeal(const SSAMBaseDeal & amDeal);

			virtual ~SSAMBaseDeal();
		};

		/** S/R fees are in % or in amount */
		enum eFeesCalculationType
		{
			fctPercent,
			fctAmount
		};

		/** Class defining the S/R fees parameters */
		class SOPHIS_FUND_BASE SSBaseSRFeesParameters
		{
		public:
			SSBaseSRFeesParameters(eFeesCalculationType calcType, double extFeesRate, double intFeesRate,
								   double extFeesAmount, double intFeesAmount);

			SSBaseSRFeesParameters(const SSBaseSRFeesParameters & srFees);

			virtual ~SSBaseSRFeesParameters();

			/** Create a new instance of the current base S/R fees parameters.
			If you derive this class, do not forget to overload this method,
			particularly if you add new members.*/
			virtual SSBaseSRFeesParameters * Clone() const;

			/** Update the fees given an AMDeal */
			virtual void UpdateSRFeesFromDeal(const SSAMBaseDeal& amDeal);

			/** Get the total amount of fees and the discount rate from the fees' parameters */
			virtual void GetTotalFeesAndDiscountRate(const SSAMBaseDeal& amDeal, double& totalFees, double& discountRate) const;

			/** Round fees amount */
			virtual void RoundSRFees(double factor, eRoundingModeType rounding);

			/** Get the total amount of fees */
			virtual double GetTotalFees() const;

			/** Update the S/R fees from the fund definition */
			virtual void UpdateSRFeesFromFund(const CSAMFundBase* fund, bool isASubscription);

			void SetExtFeesAmount(double amount) { fExtFeesAmount = amount; }
			double GetExtFeesAmount() const { return fExtFeesAmount; }
			
			void SetIntFeesAmount(double amount) { fIntFeesAmount = amount; }
			double GetIntFeesAmount() const { return fIntFeesAmount; }

			void SetExtFeesRate(double rate) { fExtFeesRate = rate; }
			double GetExtFeesRate() const { return fExtFeesRate; }
			
			void SetIntFeesRate(double rate) { fIntFeesRate = rate; }
			double GetIntFeesRate() const { return fIntFeesRate; }

			eFeesCalculationType GetFeesCalculationType() const { return fFeesCalculationType; }
			void SetFeesCalculationType(eFeesCalculationType type) { fFeesCalculationType = type; }

		protected:
			eFeesCalculationType fFeesCalculationType;
			double fExtFeesRate;
			double fIntFeesRate;
			double fExtFeesMinAmount;
			double fIntFeesMinAmount;
			double fExtFeesAmount;
			double fIntFeesAmount;

		private:
			static const char* __CLASS__;
		};
		
		/** Base class containing fees computation parameters */
		class SOPHIS_FUND_BASE SSBaseFeesParameters
		{
		public:

			/** The base S/R fees parameters supplied will be cloned. */
			SSBaseFeesParameters(const SSBaseSRFeesParameters & srFees);
			
			/** the constructor deletes fBaseSRFeesParameters */
			virtual ~SSBaseFeesParameters();

			/** The pointer returned is owned by the SSBaseFeesParameters object. It can be NULL. */
			SSBaseSRFeesParameters* GetBaseSRFeesParameters() const { return fBaseSRFeesParameters; }
			
			/** Get the total amount of fees and the discount rate from the fees' parameters */
			virtual void GetTotalFeesAndDiscountRate(const SSAMBaseDeal& amDeal, double& totalFees, double& discountRate) const;

			/** Update the fees given an AMDeal */
			virtual void UpdateFeesFromDeal(const SSAMBaseDeal& amDeal);

			/** Round fees amount */
			virtual void RoundFees(double factor, eRoundingModeType rounding);

			/** Get the total amount of fees */
			virtual double GetTotalFees() const;

			void SetCounterPartyAmount(double amount) { fCounterPartyFees = amount; }
			double GetCounterPartyAmount() const { return fCounterPartyFees; }

		protected:
			double fCounterPartyFees;
			SSBaseSRFeesParameters* fBaseSRFeesParameters;
		};

		/** 
		*	Update modes :
		*	  u*Amount= net/gross amount changed
		*	  uNbShares= number of shares changed
		*	  uFees= fees changed
		*	  uApproxAmount= amount changed
		*     uNbUnits= nb units changed (used in XML update)
		*	the difference between u*Amount and uApproxAmount is that, after number of shares has been
		*	reevaluated, net and gross amount are recalculated with u*Amount but not with uApproxAmount
		*/
		enum EUpdateMode { uNetAmount, uGrossAmount, uNbShares, uFees, uApproxAmount, uNbUnits, uBusinessEvent };

		/** Class that computes shares number, fees and amounts given an update mode */
		class SOPHIS_FUND_BASE CSAMFundBaseDealUpdate
		{
		public:
			CSAMFundBaseDealUpdate();
			virtual ~CSAMFundBaseDealUpdate();

			/** Initialise the updater from a transaction */
			virtual void Initialise(const portfolio::CSRTransaction& trans) = 0;

			/** Update the fees parameters and the deal given an update mode */
			void Update(EUpdateMode mode);

			virtual SSAMBaseDeal* GetAMDeal() const = 0;
			virtual SSBaseFeesParameters* GetFeesParameters() const = 0;
			virtual SSBaseSRFeesParameters* GetSRFeesParameters() const;

			virtual void UpdateFromTransaction(const sophis::portfolio::CSRTransaction * transaction) {}

			/** Update the onject used on a redemption from the associated subscription */
			virtual void UpdateFromSubscription(sophis::portfolio::TransactionIdent subscriptionCode) {};

			/** Update the nav date */
			virtual void UpdateNavDate(long navDate);

			/** Update the nav */
			virtual void UpdateNav(double nav);

			/** Update subscription/redemption fees 
			*	May call Update() method
			*/
			void UpdateSubscrRedemptFees(bool always=false); // internal use
		protected:
			/** Initialise SSAMBaseDeal and SSBaseFeesParameters parameters from a transaction */
			void Initialise(const portfolio::CSRTransaction& trans, _STL::auto_ptr<SSAMBaseDeal>& deal, _STL::auto_ptr<SSBaseFeesParameters>& fees);

			/** Update the number of shares from the gross/net amounts and the fees */
			void UpdateSharesNb() const;

			/** Update the net amount from the gross amount and the fees */
			void UpdateNetAmount() const;

			/** Update the gross amount from the number of shares and the nav */
			void UpdateGrossAmount() const;

			/** Get the rounding factor from the currency of the fund */
			double GetCurrencyRoundingFactor() const;

			/** Round the resulting fees, gross and net amounts */
			void RoundFeesAndAmounts() const;

			/** Round an amount given a factor and the rounding mode of the fund
			*	See RoundAmountWithFactor
			*/
			double RoundAmount(double amount, double factor, bool inverseRounding=false) const;

			/** Check that the number of shares has to updated */
			virtual bool HasToUpdateSharesNb() const;

			/** Check that the net amount has to updated */
			virtual bool HasToUpdateNetAmount(EUpdateMode mode) const;

			/** Gives the forex associated to the given transaction */
			double GetExchangeRate(const portfolio::CSRTransaction& trans) const;

			/** Get fund nav according to fund quotation on market */
			double GetFundNav() const;

			const CSAMFundBase* fFund;

		private:
			static const char* __CLASS__;
		};

		/** Round an amount given a factor and a rounding mode
		*/
		extern SOPHIS_FUND_BASE double RoundAmountWithFactor(double amount, double factor, eRoundingModeType rounding);
	}
}

#endif