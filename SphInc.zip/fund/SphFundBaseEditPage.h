#pragma once

#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphTabButton.h"

// Macros definitions
#include "SphTools/SphPrototype.h"
#include "SphInc/tools/SphAlgorithm.h"

#include "SphFundBaseGUIExports.h"



#define	INITIALISE_FUND_EDITPAGE(derivedClass, name)	INITIALISE_PROTOTYPE(derivedClass, name)

namespace sophis	
{
	namespace value	
	{

		class CSAMFundBase;

		class SOPHIS_FUND_BASE_GUI CSAMFundBaseTab : public sophis::gui::CSRTabButton
		{
		public:
			CSAMFundBaseTab(sophis::gui::CSRFitDialog* window);
			virtual CSAMFundBase* GetFund() = 0;
			void ForceModifiedFlag(bool modified=false) const;
		};

		class SOPHIS_FUND_BASE_GUI CSAMFundBaseEditPage : public sophis::gui::CSRTabPage
		{
		public:
			CSAMFundBaseEditPage();
			CSAMFundBaseEditPage(CSAMFundBaseTab* tab);
			CSAMFundBase* GetFund() const { return ((CSAMFundBaseTab*)fTab)->GetFund(); } 
			virtual bool LoadFromFund();
			virtual bool SaveToFund();
			virtual void ForceModifiedFlag(bool modified=false) const {};
			bool EnterPage(); // overload
			bool LeavePage(); // overload

		protected:
			virtual bool IsReadOnly() const;
		};

		class SOPHIS_FUND_BASE_GUI CSAMFundUserEditPage : public CSAMFundBaseEditPage
		{
		public:
			CSAMFundUserEditPage();
			CSAMFundUserEditPage(CSAMFundBaseTab* tab);
			bool LoadFromFund(); // overload
			bool SaveToFund(); // overload
		};
	}
}
