#pragma once

#ifndef _SphFundBaseExports_H_
#define _SphFundBaseExports_H_

#ifdef _WIN32
#	ifdef SOPHIS_FUND_BASE_EXPORTS
#		define SOPHIS_FUND_BASE __declspec(dllexport)
#	else
#		define SOPHIS_FUND_BASE __declspec(dllimport)
#	endif
#else
#	define SOPHIS_FUND_BASE
#endif

#endif