#pragma once

#ifndef _SphFundBaseGUIExports_H_
#define _SphFundBaseGUIExports_H_

#ifdef _WIN32
#	ifdef SOPHIS_FUND_BASE_GUI_EXPORTS
#		define SOPHIS_FUND_BASE_GUI __declspec(dllexport)
#	else
#		define SOPHIS_FUND_BASE_GUI __declspec(dllimport)
#	endif
#else
#	define SOPHIS_FUND_BASE_GUI
#endif

#endif

