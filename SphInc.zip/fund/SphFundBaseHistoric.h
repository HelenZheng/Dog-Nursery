/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphFundBaseHistoric.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Base class to manage historical data of a fund.
*
*/

#pragma once

#ifndef _SPH_FUNDBASE_HISTORIC_H_
#define _SPH_FUNDBASE_HISTORIC_H_

#include "SphFundBaseExports.h"
#include "SphInc/market_data/SphHistoric.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(map)

namespace sophis	
{
	namespace value	
	{

		/** CSAMFundBaseHistoric -- stores history data in addition to the classical
		*	history (sophis::market_data::CSRHistoric).  This data is loaded into the
		*	history view by CSAMFundBaseHistoricList::RowInHistoric().  The data is loaded
		*	from the history view by CSAMFundBaseHistoricList::HistoricInRow().  Instances
		*	are created by CSAMFundBaseHistoricList::new_HistoricList().
		*
		*	If you want to add fund columns, @see CSAMFundBaseHistoricList for a complete
		*	description.
		*/
		class SOPHIS_FUND_BASE CSAMFundBaseHistoric : public sophis::market_data::CSRHistoric
		{
		public:
			virtual	void	Initialise();

			// These variables are assumed to be IN ORDER.  DO NOT RE-ORDER unless you
			// modify CSAMFundBaseHistoricList::RowInHistoric() and CSAMFundBaseHistoricList::HistoricInRow().
			double	fSharesCount;		// before S/R
			double	fSharesCountAfterPS;// after S/R
			double	fTotalGAV;			
			double	fNAV;				
		};

		/** CSAMFundBaseHistoricList -- Modifies the instrument history display for a Fund.
		*	In particular, it:
		*	-	hides the following columns:
		*		-	First
		*		-	High
		*		-	Low
		*		-	Arbitrage
		*		-	Spread
		*		-	Bid
		*		-	Ask
		*	-	renames the following columns:
		*		-	"Last" to "GAV"
		*	-	adds the following columns:
		*		-	Shares before S/R
		*		-	Shares after S/R
		*		-	Total GAV
		*		-	NAV
		*
		*	If you want to add fund columns, you must:
		*	-#	Derive sophis::value::CSAMFundBaseHistoric
		*		-#	Add data fields as necessary, one per new column.
		*		-#	Over-ride Initialise() to initialise your new data.
		*	-#	Derive sophis::value::CSAMFundBaseHistoricList and over-ride:
		*		-#	BuildColumns(void)
		*			to call CSAMFundBaseHistoricList::BuildColumns(void) and THEN
		*			add/hide columns as required.
		*		-#	HistoricInRow(long numLigne, historic *ligneHisto)
		*			to save data to your new CSAMFundBaseHistoric child class (A) and
		*			call CSAMFundBaseHistoricList::HistoricInRow().
		*		-#	RowInHistoric(long numLigne, historic *ligneHisto, Boolean ligneChargee = false)
		*			to load data from your new CSAMFundBaseHistoric child class (A) and
		*			then call CSAMFundBaseHistoric::RowInHistoric().
		*		-#	NewHisto(void)
		*			to return a new instance of your CSAMFundBaseHistoric child class
		*			(A).
		*	-#	Derive sophis::value::CSAMFund and over-ride:
		*		-#	Clone(void)
		*			to create an instance of the new CSAMFund child class (C) and
		*			then call newInstance->Initialise(this).
		*		-#	new_HistoricList(void)
		*			to return a instance of your CSAMFundBaseHistoricList child class
		*			(B).
		*	-#	Register your new fund class as a fund model:
		*		-#	Create a UNIVERSAL_MAIN method including the following line:
		*			INITIALISE_FUND(NewFundClass, "New Fund Class Model");
		*	-#	Change the model of one or more funds to the new fund model.  These
		*		funds will now display a modified history.
		*
		* @see sophis:;value::CSAMFundBaseHistoricList
		* @see sophis::value::CSAMFundBaseHistoricList::BuildColumns(void)
		* @see sophis::value::CSAMFundBaseHistoricList::HistoricInRow(long numLigne, historic *ligneHisto)
		* @see sophis::value::CSAMFundBaseHistoricList::RowInHistoric(long numLigne, historic *ligneHisto, Boolean ligneChargee = false)
		* @see sophis::value::CSAMFundBaseHistoricList::NewHisto(void)
		* @see sophis::value::CSAMFund::Clone(void)
		* @see sophis::value::CSAMFund::new_HistoricList(void)
		* @see UNIVERSAL_MAIN
		* @see INITIALISE_FUND()
		*/
		class SOPHIS_FUND_BASE CSAMFundBaseHistoricList : public sophis::market_data::CSRHistoricList {
		public:
			enum eColPlus
			{
				cNbSharesBeforeSR=0,
				cNbSharesAfterSR,
				cTotalGAV,
				cNAV,
				cFieldCount
			};

		protected:
			/**	Constructor.
			*	@param NumExtraColumns Gives the number of columns to be added by a sub-class.
			*	The default (0) is for constructing an instance of CSAMFundBaseHistoricList directly.
			*/
			CSAMFundBaseHistoricList(PInfoHisto infos, int fieldCount=cFieldCount, int NumExtraColumns=0);

			/**	Get the first index for the user column.
			*
			*	This is implemented for child classes derived from CSAMFundBaseHistoricList.
			*
			*	@return the index of the first column which must be used in
			*	BuildColumn().
			*
			*	@note: This overrides CSRHistoricList::GetFirstUserColumn() to return a
			*	value useful to children of CSAMFundBaseHistoricList.  To access columns
			*	added by CSAMFundBaseHistoricList, use Getcolumn() or GetColumnIndex().
			*/
			virtual int GetFirstUserColumn();

			/**	Return the new column referenced by an eColPlus value.
			*
			* @param col An int value referring to a column added by CSAMFundBaseHistoric.
			*
			* @return An SSColumn pointer or 0 if col is cEqualisation or cHWM and
			* hasPerfFees is false.
			*/
			virtual sophis::gui::SSColumn* GetColumn(int col);

			/** Return the index (in the CSREditList) of the column referenced by an
			* eColPlus value.
			*
			* @param col An int value referring to a column added by
			* CSAMFundBaseHistoric.
			*
			* @return The index or -1 if col is cEqualisation or cHWM and hasPerfFees
			* is false.
			*/
			virtual int GetColumnIndex(int col);

			/** Returns the structure used to build the columns */
			virtual CSAMFundBaseHistoric* GetHistoricLine(historic* ligneHisto) const;

			/** Add new columns and hide existing columns in the CSREditList. */
			virtual long	GetHeaderResourceId() const;
			virtual void	BuildColumns(void);
			virtual void	HistoricInRow(long numLigne, historic *ligneHisto);
			virtual void	RowInHistoric(long numLigne, historic *ligneHisto, Boolean ligneChargee = false);
			virtual historic*	NewHisto(void);
			virtual bool IsModifiedLinkedWithLast(market_data::CSRHistoric* historic);

			const int fFieldCount; // nb of additional fields (only for funds) displayed

			// These two classes use GetColumn(), GetColumnIndex(), GetInfos(),
			// GetLineCount() and GetElementByRelativeId().
			friend class CSRStaticNbPartsAfterSR;
			friend class CSRStaticNAV;
		};

		/** This abstract class allows to calculate the value to display in a historic column
		*	with other columns from the historic list
		*
		*	Calculation is the method to overload
		*/
		class SOPHIS_FUND_BASE CSRStaticDoubleCalculation : public sophis::gui::CSRStaticDouble
		{
		public:
			CSRStaticDoubleCalculation(	sophis::gui::CSREditList *liste,
				int 			 CNb_Double,
				int 			 numberOfDecimalPlaces,
				double 			 minimum,
				double 			 maximum,
				double			 value=0);
			virtual void	ValueToString(char *dest, int ligne) const;
			virtual Boolean	StringToValue(const char *sourc, int ligne);

		protected:
			virtual double	Calculation(int line) const = 0;
			// Internal
			void StoreNewValue(double value) const;
		};

	} // namespace value
} // namespace sophis


#endif
