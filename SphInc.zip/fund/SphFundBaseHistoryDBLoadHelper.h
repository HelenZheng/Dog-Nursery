#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHFUNDBASEHISTORYDBLOADHELPER_H__
#define __SOPHIS_VALUE_SPHFUNDBASEHISTORYDBLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseExports.h"


namespace sophis
{
	namespace value
	{
		/**
		 *  Helper structure to load fund data history DB from database.
		 */
		struct SOPHIS_FUND_BASE SSAmFundBaseHistoryDBLoadHelper
		{
			// Default constructor.
			SSAmFundBaseHistoryDBLoadHelper();
			// Copy constructor.
			SSAmFundBaseHistoryDBLoadHelper(const SSAmFundBaseHistoryDBLoadHelper &other);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmFundBaseHistoryDBLoadHelper();

			// Assignment operator.
			SSAmFundBaseHistoryDBLoadHelper &operator=(const SSAmFundBaseHistoryDBLoadHelper &other);

			// Coming from CSAMFundBaseHistoryDB
			long fDate;
			double fTheoretical;
			double fNav;
			double fSharesNb;
			double fTotalNav;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHFUNDBASEHISTORYDBLOADHELPER_H__