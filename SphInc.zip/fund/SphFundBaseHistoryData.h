/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphFundBaseHistoryData.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Base class to handle fund history data
*
*/

#ifdef _WIN32
#	pragma once
#endif

#ifndef _SphFundBaseHistoryData_H_
#define _SphFundBaseHistoryData_H_

/**
* System includes
*/
#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)

#include "SphInc/fund/SphFundBaseExports.h"

/**
* Application includes
*/

// Macros definitions


/**
* defines
*/

namespace sophis 
{
	namespace sql
	{
		class CSRStructureDescriptor;
	}
	namespace tools
	{
		class CSREventVector;
	}

	namespace value	
	{
		struct SSAmFundBaseHistoryDBLoadHelper;


		/** Base class used for SQL queries (history of prices) */
		class SOPHIS_FUND_BASE CSAMFundBaseHistoryDB
		{
		public:
			CSAMFundBaseHistoryDB();
			CSAMFundBaseHistoryDB(const SSAmFundBaseHistoryDBLoadHelper &loadHelper);
			CSAMFundBaseHistoryDB(const CSAMFundBaseHistoryDB& fundBase);
			virtual ~CSAMFundBaseHistoryDB();

			/** Clone the history data.
			*	@return a new derived class from CSAMFundBaseHistoryDB (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryDB* Clone() const = 0;

			virtual sophis::sql::CSRStructureDescriptor* GetDescriptor() const;

			/** Build the select query that retrieves history data between two dates */
			virtual _STL::string GetSelectQuery(long fundCode, long date1, long date2, bool decreasingDate) const = 0;

			/** Create the insert query based on object "this"
			*	Add history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetInsertQuery(long fundCode) const = 0;

			/** Create the update query based on object "this" 
			*	Update history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetUpdateQuery(long fundCode) const = 0;

			/** Create the delete query of history data for fund "fundCode" at date "date"
			*/
			virtual _STL::string GetDeleteQuery(long fundCode, long date) const;

			long	fDate;
			double	fTheoretical;
			double	fNav;
			double	fSharesNb;
			double	fTotalNav;
			
		protected:
			void Initialize(const CSAMFundBaseHistoryDB& fundBase);
			void Initialize(const SSAmFundBaseHistoryDBLoadHelper &loadHelper);
		};

		typedef _STL::vector<const CSAMFundBaseHistoryDB*> FundBaseHistoryDBList;

		/** Base class to handle fund history data */
		class SOPHIS_FUND_BASE CSAMFundBaseHistoryData
		{
		public:
			CSAMFundBaseHistoryData(long fundCode);

			void Initialize(long fundCode);

			virtual ~CSAMFundBaseHistoryData();
	
			/** Clone the history data.
			*	@return a new derived class from CSAMFundBaseHistoryData (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryData* Clone() const;

			/** accessors to the vector of data */
			FundBaseHistoryDBList& GetHistoryDB() { return fHistoryData; }
			const FundBaseHistoryDBList& GetHistoryDB() const { return fHistoryData; }

			/** 
			*	Load the object with fund history data between too dates
			*	@param date1 is the first date
			*	@param date2 is the second date, should have date1<=date2
			*	@param result is a vector of data
			*	@param decreasingdate to have results sorting by decreasing date (default=increasing)
			*	@return the number of entries found (=result.size())
			*	@see CSAMFundBaseHistoryDB
			*	@throws OracleException on error.
			*/
			int	LoadHistory(long date1, long date2, bool decreasingDate=false);

			/** 
			*	Add or update a history line
			*	@param histo: history data to update or add
			*	@param messages: coherency messages to send after commit
			*	@param fundCreation: true if called at fund creation, false otherwise
			*	No commit/rollback performed
			*/
			void AddToHistory(const CSAMFundBaseHistoryDB* histo, sophis::tools::CSREventVector& messages, bool fundCreation=false) const;

			/** Clear the fund history for a given day.
			*	@param date: date at which history data is removed
			*	@param messages: coherency messages to send after commit
			*	No commit/rollback performed
			*	@throws OracleException on error.
			*/
			void DeleteHistory(long date, sophis::tools::CSREventVector& messages) const;

		protected:
			// constructor required for virtual inheritance
			CSAMFundBaseHistoryData();
			
			/** Create an instance of CSAMFundBaseHistoryDB to perform requests 
			*	MUST BE DELETED
			*/
			virtual CSAMFundBaseHistoryDB* new_HistoryDB() const;

			/** Method that performs the request to fill an internal structure and fHistoryData
			*	@throws OracleException if an error occurs */
			virtual void ExecuteSelectQuery(const _STL::string& request, const sophis::sql::CSRStructureDescriptor* desc, long startDate, long endDate, bool decreasingDate);

			/// Method used to perform additional includes/updates in annex history tables.
			virtual void AddToSpecificHistory(const CSAMFundBaseHistoryDB* histo) const {}
			/// Method used to perform additional deletions in annex history tables.
			virtual void RemoveFromSpecificHistory(long date) const {}

			/** template function that creates a pointer on CSAMFundBaseHistoryDB
			*	from a CSAMFundBaseHistoryDB */
			template<class C> 
			static const CSAMFundBaseHistoryDB* CreateHistoryPtr(const C& in)
			{
				return (&in);
			}

			/** template method that fills fHistoryData
			*	from a vector of history data */
			template<class C> 
			void FillHistoryVector(const _STL::vector<C>& historyDB)
			{
				fHistoryData.resize(historyDB.size());
				_STL::vector<C>::const_iterator ite = historyDB.begin();
				FundBaseHistoryDBList::iterator iteResult = fHistoryData.begin();
				while (historyDB.end()!=ite)
				{
					(*iteResult++) = CreateHistoryPtr(*ite++);
				}
			}

			long fFundCode;
			FundBaseHistoryDBList fHistoryData;

		private:
			static const char* __CLASS__;
		};
	}
}

#endif // _SphFundBaseHistoryData_H_
