#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHFUNDBASELOADHELPER_H__
#define __SOPHIS_VALUE_SPHFUNDBASELOADHELPER_H__


// Toolkit includes
#include "SphFundBaseExports.h"
#include "SphFundBase.h"
#include "SphFundBaseTemplate.h"


namespace sophis
{
	namespace value
	{
		/**
		 *  Helper structure to load fund data from database.
		 *  Inherit directly from this struct when creating a fund template base on CSAMFundBaseTemplate.
		 */
		struct SOPHIS_FUND_BASE SSAmFundBaseLoadHelper
		{
			// Default constructor.
			SSAmFundBaseLoadHelper();
			// Constructor from a CSAMFundBase.
			SSAmFundBaseLoadHelper(const CSAMFundBase &fund);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmFundBaseLoadHelper();

			virtual int GetBaseClassSize() const;
			virtual int GetClassSize() const;

			// Coming from CSRInstrument
			long fCode;
			long fCurrency;

			// Coming from CSAMFundBase
			char fTemplateName[FUND_TEMPLATE_NAME_LENGTH];
			char fName[40];
			char fReference[25];
			char fExternalRef[40];
			char fComment[201];
			eHedgeFundType fHedgeFundType;
			long fMarketCode;
			double fQuotity;
			double fParity;
			long fIssueDate;
			double fIssuePrice;
			double fIssuedShares;
			long fExpiry;
			double fStrike;
			eRoundingModeType fSRRoundingMode;
			long fEntity;
			long fFeesInstrument;
			long fBenchmarkCode;
			eNAVDatesType fNAVDatesType;
			sophisTools::eWeekdayType fWeekNAVDay;
			short fNAVNbDecimals;
			long fLegalForm;
			long fListId;
			long fFactorModel;
			long fFundStatus;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHFUNDBASELOADHELPER_H__