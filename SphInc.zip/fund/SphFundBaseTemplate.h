/*
 	File:	SphFundTemplate.h
 
 	Contains:	encapsulates the SQL queries for CSAMFundBase class
 
 	Copyright:	� 2001 Sophis.
*/

#ifndef _Sph_FundTemplate_H_
#define _Sph_FundTemplate_H_


#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(vector)

#include "SphFundBaseExports.h"
#include "SphSDBCInc/SphSqlQuery.h"
#include "SphInc/gui/SphCustomMenu.h"
#include "SphInc/gui/SphDialog.h"

#ifndef Handle
typedef char** Handle;
#endif


enum eHedgeFundType
{
	hfUndefined=-1,
	hfInternal=1,
	hfExternal,
	hfExternalSeries,
	hfFundClass,
	hfEtf,
	hfHedgef,
	hHedgeFundClass,
	hfMutualFund,	
	hfMandate,
	hfLightPortfolio,
	hfCount = 10
};

#define FUND_STANDARD_TEMPLATE_NAME "Standard"
#define FUND_TEMPLATE_NAME_LENGTH 41


#ifdef _WIN32
#	pragma warning(push)
#	pragma warning(disable: 4251) // warning C4251: class 'type' needs to have dll-interface to be used by clients of class 'type2'
#endif

namespace sophis	
{
	namespace value	
	{
		class CSAMFundBase;
		class CSAMFundUserEditPage;
		class CSAMFundBaseEditCustomizable;

		class SOPHIS_FUND_BASE CSAMFundBaseTemplate
		{
		public:
			// Default constructor
			CSAMFundBaseTemplate(const char *name, CSAMFundUserEditPage* userDialogPrototype=0);
			// Destructor
			virtual ~CSAMFundBaseTemplate();

			// Clone the instrument and initialize it with another one
			virtual CSAMFundBase* CreateFund(const CSAMFundBase* instrument) const = 0;

			CSAMFundUserEditPage* CreateUserDialog() const;
			// Customize dialog with instrument (do nothing by default : to be overloaded)
			virtual void CustomizeDialog(CSAMFundBaseEditCustomizable* dialog, CSAMFundBase* instrument) const;
			// Uncustomize dialog (do nothing by default : to be overloaded)
			virtual void UncustomizeDialog(CSAMFundBaseEditCustomizable* dialog) const;

			/// Load data for the given fund
			void Load(CSAMFundBase &fund) const;
			
			const sophis::sql::CSRSqlQuery* GetSQLReadQuery() const { return fReadQuery; }
			const sophis::sql::CSRSqlQuery* GetSQLHistoReadQuery() const { return fHistoReadQuery; }
			const sophis::sql::CSRSqlQuery* GetSQLWriteQuery() const { return fWriteQuery; }

			const char* GetName() const { return fName; }
			virtual void BuildSQL() = 0;

			const CSAMFundBase* GetInstrumentPrototype() const { return fInstrumentPrototype; }
			const CSAMFundUserEditPage* GetDialogPrototype() const { return fUserDialogPrototype; }

		protected:
			// Default constructor
			CSAMFundBaseTemplate();

			// Required for virtual inheritance
			virtual void Initialize(const char *name, CSAMFundUserEditPage* userDialogPrototype);

			virtual void CustomizeSQL();

			// Name of the template
			char fName[FUND_TEMPLATE_NAME_LENGTH];

			Handle fReadQueryString;
			const sophis::sql::CSRSqlQuery* fReadQuery;
			Handle fHistoReadQueryString;
			const sophis::sql::CSRSqlQuery* fHistoReadQuery;
			Handle fWriteQueryString;
			const sophis::sql::CSRSqlQuery* fWriteQuery;
			
			sophis::sql::CSRStructureDescriptor fDesc; // SQL descriptor for both reading and writing
			sophis::sql::CSRStructureDescriptor fVar; // SQL descriptor for reading a long

			// Prototype of the instrument handled by this template (will be cloned)
			const CSAMFundBase* fInstrumentPrototype;
			CSAMFundUserEditPage* fUserDialogPrototype;


		private:
			static const char* const __CLASS__;
		};

	// List of instrument templates
	// There should be one global instance of this by instrument type (Equity, Package, Swap, Future, and so on)
		class SOPHIS_FUND_BASE CSAMFundTemplateMgr
		{
		public:
			CSAMFundTemplateMgr();
			~CSAMFundTemplateMgr();

			static CSAMFundTemplateMgr* GetInstance();

			// instrTemplate is a pointer created by new
			// it will be deleted in the destructor of CSAMFundTemplateMgr
			void Add(CSAMFundBaseTemplate* instrTemplate, eHedgeFundType fundType);
			void Remove(const char* name, eHedgeFundType fundType);
			const CSAMFundBaseTemplate* Find(const char* name, eHedgeFundType fundType) const;

			class Visitor 
			{ 
			public: 
				virtual bool Visit(const CSAMFundBaseTemplate* instrTemplate) = 0; 
			};
			void Parse(Visitor& visitor, eHedgeFundType fundType) const;

		private:
			typedef _STL::map<_STL::pair<long, _STL::string>, CSAMFundBaseTemplate*> TemplateMap;
			TemplateMap fTemplates;
			static CSAMFundTemplateMgr* fInstance;
		};

		// A generic popup for selecting a template
		class SOPHIS_FUND_BASE CSAMFundTemplatePopup : public sophis::gui::CSRCustomMenu 
		{
		public:
			CSAMFundTemplatePopup(	
				sophis::gui::CSRFitDialog 	*dialog, // owner dialog
				int 			ERId_Menu, // ID
				CSAMFundBase*	instrument, // the instrument beeing edited
				CSAMFundBaseEditCustomizable*	custDialog=0, // the dialog to be customized (can be different from owner dialog)
				bool			editable=true // is this popup editable ?
				);
			// Called after a new selection 
			void Action(); //overload
			// Get the selected template
			const CSAMFundBaseTemplate* GetTemplate() const;
			// Get the editaed instrument
			CSAMFundBase* GetInstrument() { return fInstrument; }

		protected:
			void BuildMenu(); // internal
			void SetValueFromList(); // internal
			void SetListFromValue(); // internal

			// Internal members
			const CSAMFundTemplateMgr* fMgr;
			CSAMFundBase* fInstrument;
			const CSAMFundBaseTemplate* fTemplate;
			CSAMFundBaseEditCustomizable* fCustDialog;

			class BuildMenuVisitor;
			friend class BuildMenuVisitor;
		};

		class CSAMFundTemplatePopup::BuildMenuVisitor : public CSAMFundTemplateMgr::Visitor
		{
		public:
			BuildMenuVisitor(CSAMFundTemplatePopup* popup);
			bool Visit(const CSAMFundBaseTemplate*); // overload
		protected:
			CSAMFundTemplatePopup* fPopup;
		};
	}
}

#ifdef _WIN32
#	pragma warning(pop)
#endif


#endif