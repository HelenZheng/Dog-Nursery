#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHFUNDFIELDENUMS_H__
#define __SOPHIS_VALUE_SPHFUNDFIELDENUMS_H__

namespace sophis
{
	namespace value
	{
		/**
		 *  Categories allowing to sort external fund fields.
		 */
		enum EFundFieldCategory
		{
			// Warning: Do not modify this line !
			ffcFirstCategory = 1,

			ffcInvestmentRules = ffcFirstCategory,
			ffcInvestors,
			ffcReturns,
			ffcRisk,
			ffcStructure,
			ffcFees,
			ffcMisc,

			// Warning: Do not modify this line !
			ffcLastCategory,
			ffcCount = ffcLastCategory - 1
		};


		/**
		 *  Define the type of data stored in the field.
		 */
		enum EFundFieldDatatype
		{
			ffdText = 1, ///< The field is a text one, its value is stored in the description.
			ffdDouble,
			ffdLong,
			ffdPercent,
			ffdDate,
			ffdTime
		};
	}
}


#endif // __SOPHIS_VALUE_SPHFUNDFIELDENUMS_H__