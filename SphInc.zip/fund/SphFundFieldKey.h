#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHFUNDFIELDKEY_H__
#define __SOPHIS_VALUE_SPHFUNDFIELDKEY_H__


#include "SphFundBaseExports.h"


namespace sophis
{
	namespace value
	{
		/**
		 *  Type of the external fund field.
		 */
		enum EFundFieldType
		{
			fftStandard, ///< Field hard-coded in the software.
			fftUser      ///< Field defined in database by the user.
		};


		/**
		 *  Unique key to identify an external fund field.
		 */
		struct SOPHIS_FUND_BASE SSAmFundFieldKey
		{
			/// Constructor.
			SSAmFundFieldKey(EFundFieldType type = fftStandard, long id = 0);

			/// Comparison operator to allow sorting in a map.
			bool operator<(const SSAmFundFieldKey& other) const;

			/// Type of the field.
			EFundFieldType fType;
			/// Id of the field.
			long fId;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHFUNDFIELDKEY_H__