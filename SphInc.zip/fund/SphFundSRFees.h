/********************************************************************
*	@date		:	08.09.2004  
*
*	@file		: 	SphFundSRFees.h
*	
*	@author		:	Copyright (C) 2004 SOPHIS
*
*	@purpose	:	Handle the subscriptions/redemptions fees of the fund
*	
*/

#ifndef _CSAM_FUNDSRFEES_H
#define _CSAM_FUNDSRFEES_H

#include "SphFundBaseExports.h"
#include "SphSDBCInc/SphSQLDataTypes.h"

	
namespace sophis 
{
	namespace value 
	{
		class SOPHIS_FUND_BASE CSAMFundSRFees
		{
		public:
			CSAMFundSRFees();
			
			bool operator==(const CSAMFundSRFees& srFees) const;

			/*	Load the S/R fees from database
			 *	@param sicovam: the fund code
 			 *	@return a short which is an Oracle error if not null or 1 there is no result.
			 */
			sophis::sql::errorCode LoadFromDatabase(long sicovam);

			/*	Save the S/R fees to database 
			 *	No commit operation performed
			 *	@param sicovam: the fund code
			 *	@return a short which is an Oracle error if not null.
			 */
			sophis::sql::errorCode SaveToDatabase(long sicovam) const;
			
			// accessors
			double GetInternalSubscripFeesInPercent() const { return fIntSubscripFeesPercent;}
			double GetInternalRedempFeesInPercent() const { return fIntRedempFeesPercent;}
			double GetExternalSubscripFeesInPercent() const { return fExtSubscripFeesPercent;}
			double GetExternalRedempFeesInPercent() const { return fExtRedempFeesPercent;}

			double GetInternalSubscripFeesMin() const { return fIntSubscripFeesMin;}
			double GetInternalRedempFeesMin() const { return fIntRedempFeesMin;}
			double GetExternalSubscripFeesMin() const { return fExtSubscripFeesMin;}
			double GetExternalRedempFeesMin() const { return fExtRedempFeesMin;}

			void SetInternalSubscripFeesInPercent(double value) { fIntSubscripFeesPercent = value;}
			void SetInternalRedempFeesInPercent(double value) { fIntRedempFeesPercent = value;}
			void SetExternalSubscripFeesInPercent(double value) { fExtSubscripFeesPercent = value;}
			void SetExternalRedempFeesInPercent(double value) { fExtRedempFeesPercent = value;}

			void SetInternalSubscripFeesMin(double value) { fIntSubscripFeesMin = value;}
			void SetInternalRedempFeesMin(double value) { fIntRedempFeesMin = value;}
			void SetExternalSubscripFeesMin(double value) { fExtSubscripFeesMin = value;}
			void SetExternalRedempFeesMin(double value) { fExtRedempFeesMin = value;}

		private:
			// internal fees (included in the fund cash)
			double	fIntSubscripFeesPercent; // internal subscription fees (%)
			double	fIntRedempFeesPercent;	 // internal redemption fees (%)
			double	fIntSubscripFeesMin;	 // minimum value for internal subscription fees 
			double	fIntRedempFeesMin;		 // minimum value for internal redemption fees 

			// external fees (not included)
			double	fExtSubscripFeesPercent; // external subscription fees (%)
			double	fExtRedempFeesPercent;	 // external redemption fees (%)
			double	fExtSubscripFeesMin;	 // minimum value for external subscription fees 
			double	fExtRedempFeesMin;		 // minimum value for external redemption fees 			
		};
	}
}

#endif