#pragma once

#ifndef _SphGUIComponentsExports_H_
#define _SphGUIComponentsExports_H_

#ifdef _WIN32
#	ifdef SOPHIS_GUI_COMPONENTS_EXPORTS
#		define SOPHIS_GUI_COMPONENTS __declspec(dllexport)
#	else
#		define SOPHIS_GUI_COMPONENTS __declspec(dllimport)
#	endif
#else
#	define SOPHIS_GUI_COMPONENTS
#endif

#endif

