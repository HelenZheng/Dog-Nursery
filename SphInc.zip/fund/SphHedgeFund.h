#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHHEDGEFUND_H__
#define __SOPHIS_VALUE_SPHHEDGEFUND_H__


// Macros definitions
#define	INITIALISE_HEDGE_FUND(derivedClass, name) \
	INITIALISE_PROTOTYPE(derivedClass,  name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAmHedgeFundTemplate(name), hfHedgef);
#define INITIALISE_HEDGE_FUND_FUND_GUI(derivedClass, name, pageClass) \
	INITIALISE_PROTOTYPE(derivedClass, name); \
	sophis::value::CSAMFundTemplateMgr::GetInstance()->Add(new sophis::value::CSAmHedgeFundTemplate(name, new pageClass), hfHedgef);


// Toolkit includes
#include "SphInc/fund/SphExternalFundBase.h"
#include "SphInc/fund/SphExternalFund.h"
#include "SphInc/fund/SphFundBreakdown.h"
#include "SphInc\portfolio\SphAssetValueCalculation.h"

namespace sophis
{

	namespace value
	{
		class CSAMFundBreakdownBottomUp;
		class CSAMExternalFundBase;



		/**
		 *  Class for hedge fund .
		 */
		class SOPHIS_FUND_BASE CSAmHedgeFund : public virtual CSAMExternalFund
		{
		public:
			/** @name Construction - Destruction */
			//@{
			CSAmHedgeFund();

			virtual ~CSAmHedgeFund();

			static CSAmHedgeFund* CreateInstance(long code);
			//@}

			/** @name Initialization */
			//@{
			virtual void Initialise() OVERRIDE;
			virtual void Initialise(long instrumentCode, double dateHisto = 0) OVERRIDE;
			virtual void Initialise(const CSAMFundBase* fund) OVERRIDE;

			//virtual void LoadSpecificData(); 
			////@}

			/** @name Prototype management */
			//@{
			typedef sophis::tools::CSRPrototype<CSAmHedgeFund, const char*, sophis::tools::less_char_star> prototype;
			static prototype &GetPrototype();
			//@}


			virtual sophis::instrument::CSRInstrument* Clone() const OVERRIDE;

			static const CSAmHedgeFund* GetFund(long sicovam);
			static const CSAmHedgeFund* GetFund(const sophis::instrument::CSRInstrument* theInstrument);

			static void GetHedgeFundList(_STL::vector<long> &result, bool reload /*= false*/);
			static void DisposeHedgeFundList();

			static const char* GetFundTypeName();
			virtual const char*	GetHedgeFundTypeName() const OVERRIDE;

			//@{
			virtual bool IsOfType(const sophis::finance::CSRProductType &type, const _STL::string &typeName) const OVERRIDE;
			virtual bool IsThisAllotment(long isThisAllot) const;
			virtual bool DoesInstrumentMatchCriteria(const char* criteriaFilter, long category_id, long rule_id) const;
			//@}
			
			virtual void CreateAutomaticTicket(bool eoy, long calculation_date, const portfolio::CSRPosition * position, _STL::vector<portfolio::CSRTransaction> &list, const portfolio_automatic_ticket &port) const OVERRIDE;
			virtual long GetAutomaticTicketByReporting(long date, bool eoy, _STL::string &filter) const OVERRIDE;
		protected:
			virtual const char* GetXMLRootName() const;
			virtual sophis::static_data::CSAMFundBaseXMLDescription* new_XMLDescriptor() const;
			
	
		private:
			// Traces*/
		private: 
			static const char* __CLASS__;
		};
	}
}


#endif // __SOPHIS_VALUE_SPHHEDGEFUND_H__