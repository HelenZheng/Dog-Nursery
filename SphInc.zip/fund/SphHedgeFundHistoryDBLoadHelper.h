#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHHEDGEFUNDHISTORYDBLOADHELPER_H__
#define __SOPHIS_VALUE_SPHHEDGEFUNDHISTORYDBLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseHistoryDBLoadHelper.h"


namespace sophis
{
	namespace value
	{
		struct SOPHIS_FUND_BASE SSAmHedgeFundHistoryDBLoadHelper : public SSAmFundBaseHistoryDBLoadHelper
		{
			// Default constructor.
			SSAmHedgeFundHistoryDBLoadHelper();
			// Copy constructor.
			SSAmHedgeFundHistoryDBLoadHelper(const SSAmHedgeFundHistoryDBLoadHelper &other);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmHedgeFundHistoryDBLoadHelper();

			// Assignment operator.
			SSAmHedgeFundHistoryDBLoadHelper &operator=(const SSAmHedgeFundHistoryDBLoadHelper &other);


		};
	}
}


#endif // __SOPHIS_VALUE_SPHHEDGEFUNDHISTORYDBLOADHELPER_H__