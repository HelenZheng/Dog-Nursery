#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHHEDGEFUNDLOADHELPER_H__
#define __SOPHIS_VALUE_SPHHEDGEFUNDLOADHELPER_H__


// Toolkit includes
#include "SphExternalFundLoadHelper.h"


namespace sophis
{
	namespace value
	{
		class CSAmHedgeFund;


		/**
		*  Helper structure to load fund data from database.
		*  Inherit from this struct when creating a fund based on CSAmHedgeFund.
		*/
		struct SOPHIS_FUND_BASE SSAmHedgeFundLoadHelper : public SSAmFundBaseLoadHelper
		{
			// Default constructor.
			SSAmHedgeFundLoadHelper();
			// Constructor from a CSAmHedgeFund.
			SSAmHedgeFundLoadHelper(const CSAmHedgeFund &fund);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmHedgeFundLoadHelper();

			virtual int GetBaseClassSize() const;
			virtual int GetClassSize() const;
			// Coming from CSAMHedgeFund
			long fLockUpPeriod;
			bool fUseLockUpRules;
			bool fHasSeries; 

		};
	}
}


#endif // __SOPHIS_VALUE_SPHHEDGEFUNDLOADHELPER_H__