#ifdef _WIN32
	#pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHMUTUALFUNDHISTORYDBLOADHELPER_H__
#define __SOPHIS_VALUE_SPHMUTUALFUNDHISTORYDBLOADHELPER_H__


// Toolkit includes
#include "SphFundBaseHistoryDBLoadHelper.h"


namespace sophis
{
	namespace value
	{
		struct SOPHIS_FUND_BASE SSAmMutualFundHistoryDBLoadHelper : public SSAmFundBaseHistoryDBLoadHelper
		{
			// Default constructor.
			SSAmMutualFundHistoryDBLoadHelper();
			// Copy constructor.
			SSAmMutualFundHistoryDBLoadHelper(const SSAmMutualFundHistoryDBLoadHelper &other);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmMutualFundHistoryDBLoadHelper();

			// Assignment operator.
			SSAmMutualFundHistoryDBLoadHelper &operator=(const SSAmMutualFundHistoryDBLoadHelper &other);


		};
	}
}


#endif // __SOPHIS_VALUE_SPHMUTUALFUNDHISTORYDBLOADHELPER_H__