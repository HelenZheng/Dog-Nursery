/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphExternalFundHistoryData.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Class to handle external fund history data
*
*/

#ifdef _WIN32
#	pragma once
#endif

#ifndef _SphMutualFundHistoryData_H_
#define _SphMutualFundHistoryData_H_

/**
* System includes
*/
#include "SphFundBaseExports.h"
#include "SphFundBaseHistoryData.h"

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(string)
#include __STL_INCLUDE_PATH(vector)
/**
* Application includes
*/

// Macros definitions


/**
* defines
*/

namespace sophis 
{
	namespace sql
	{
		class CSROracleException;
	};

	namespace value	
	{
		struct SSAmMutualFundHistoryDBLoadHelper;


		/** Base class used for SQL queries (history of prices) */
		class SOPHIS_FUND_BASE CSAmMutualFundHistoryDB : public virtual CSAMFundBaseHistoryDB
		{
		public:
			CSAmMutualFundHistoryDB();
			CSAmMutualFundHistoryDB(const SSAmMutualFundHistoryDBLoadHelper &loadHelper);
			CSAmMutualFundHistoryDB(const CSAMFundBaseHistoryDB& fundBase);
			virtual ~CSAmMutualFundHistoryDB();

			/** Clone the history data.
			*	@return a new derived class from CSAMMutualFundHistoryDB (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryDB* Clone() const;

			virtual sophis::sql::CSRStructureDescriptor* GetDescriptor() const;

			/** Build the select query that retrieves history data between two dates */
			virtual _STL::string GetSelectQuery(long fundCode, long date1, long date2, bool decreasingDate) const;
			
			/** Create the insert query based on object "this"
			*	Add history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetInsertQuery(long fundCode) const;

			/** Create the update query based on object "this" 
			*	Update history for fund "fundCode" with data of "this"
			*/
			virtual _STL::string GetUpdateQuery(long fundCode) const;

			double	fValuationNav;				// Valuation nav
			double	fEstimatedNav;				// Estimated nav (aka soft nav)
			long	fEstimatedNavReferenceDate;	// Reference date for the calculation of the estimated nav
			long	fEstimatedNavRorAsInput;	// If not null, the RoR was used to specify the estimated nav			
		
		protected:
			void Initialize(const CSAMFundBaseHistoryDB& fundBase);
		};

		/** Base class to handle fund history data */
		class SOPHIS_FUND_BASE CSAmMutualFundHistoryData : public virtual CSAMFundBaseHistoryData
		{
		public:
			CSAmMutualFundHistoryData(long fundCode);
			virtual ~CSAmMutualFundHistoryData();
			
			void Initialize(long fundCode);

			/** Clone the history data.
			*	@return a new derived class from CSAMFundBaseHistoryData (same as this) which must be deleted.
			*/
			virtual CSAMFundBaseHistoryData* Clone() const;

			typedef _STL::vector<CSAmMutualFundHistoryDB> ExternalFundHistoryDBList ;

			/// Access to the vector of history data
			const ExternalFundHistoryDBList& GetHistoryList() const { return fHistoryDB; };

		protected:
			// constructor required for virtual inheritance
			CSAmMutualFundHistoryData();

			/** Create an instance of CSAMFundBaseHistoryDB to perform requests 
			*	MUST BE DELETED
			*/
			virtual CSAMFundBaseHistoryDB* new_HistoryDB() const;

			/** Method that performs the request to fill an internal structure and fHistoryData
			*	@throws OracleException if an error occurs */
			virtual void ExecuteSelectQuery(const _STL::string& request, const sophis::sql::CSRStructureDescriptor* desc)
#ifndef GCC_XML
				throw(sophis::sql::CSROracleException)
#endif
				;

			ExternalFundHistoryDBList fHistoryDB;
		};
	}
}

#endif // _SphMutualFundHistoryData_H_
