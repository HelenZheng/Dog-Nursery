#ifdef _WIN32
#	pragma once // Speeds up VC++ compilation
#endif

#ifndef __SOPHIS_VALUE_SPHMUTUALFUNDLOADHELPER_H__
#define __SOPHIS_VALUE_SPHMUTUALFUNDLOADHELPER_H__


// Toolkit includes
#include "SphExternalFundLoadHelper.h"

namespace sophis
{
	namespace value
	{
		class CSAmMutualFund;


		/**
		*  Helper structure to load fund data from database.
		*  Inherit from this struct when creating a fund based on CSAmMutualFund.
		*/
		struct SOPHIS_FUND_BASE SSAmMutualFundLoadHelper : public SSAmFundBaseLoadHelper
		{
			// Default constructor.
			SSAmMutualFundLoadHelper();
			// Constructor from a CSAmMutualFund.
			SSAmMutualFundLoadHelper(const CSAmMutualFund &fund);
			// Virtual destructor to allow inheritance.
			virtual ~SSAmMutualFundLoadHelper();

			virtual int GetBaseClassSize() const;
			virtual int GetClassSize() const;
			// Coming from CSAmMutualFund
			long fLockUpPeriod;
			bool fUseLockUpRules;

		};
	}
}


#endif // __SOPHIS_VALUE_SPHMUTUALFUNDLOADHELPER_H__