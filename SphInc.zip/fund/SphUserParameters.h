/********************************************************************
*	@date:		2006
*	
*	@file:	 	SphUserParameters.h
*
*	@author:	Copyright (C) 2006 SOPHIS
*	
*	@purpose:	Structure that handles user-defined parameters.
*
*/

#ifndef _SphUserParameters_H_
#define _SphUserParameters_H_

/**
* System includes
*/

/**
* Application includes
*/

// Macros definitions
#include "SphFundBaseExports.h"
#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(vector)

/**
* defines
*/

/**
* typedef and classes
*/
namespace sophis 
{
	namespace value	
	{
		struct SOPHIS_FUND_BASE SSUserParameter
		{ 
			SSUserParameter();

			/** Get a list of user parameters defined for a fund 
			*	@param code: internal code (current or historical) of a fund 
			*	@return user-defined parameters
			*/
			static _STL::vector<SSUserParameter> SSUserParameter::GetUserParameters(long code);

			char	name[41]; 
			double	value; 
			char	comment[81]; 
		};
	}
}

#endif // _SphUserParameters_H_

