/*
 	File:		SphABSModelMenu.h

 	Contains:	Class pop-up menus used in ABS related GUI features.

 	Copyright:	� 1995-2006 Sophis.

*/

/*! \file SphABSModelMenu.h
	\brief handling ABS model pop-up menus
*/

#ifndef _SPHABSMODELMENU_H
#define _SPHABSMODELMENU_H

#include "SphInc/gui/SphCustomMenu.h"

SPH_PROLOG
namespace sophis {
	namespace gui {
		class CSRFitDialog;
		class CSREditList;

		/**
		*	The class CSRPricingTypeMenu stores the pricing type
		*	@version 7.1.3
		*/
		class SOPHIS_FIT CSRPricingTypeMenu : public sophis::gui::CSRCustomMenu
		{
		public:
			CSRPricingTypeMenu(	sophis::gui::CSRFitDialog	*dlg,
								int 						ERId_Menu,
								bool						editable=true,
								NSREnums::eDataType			valueType=NSREnums::dShort,
								unsigned int				valueSize=0,
								short 						listValue=1,
								const char 					*columnName=kUndefinedField,
								bool						possibleToReset=true,
								const char *				tagColonne = kSameAsOracleName);

			virtual void SetValueFromList();
			virtual void SetListFromValue();

			int	Compare( const CSRElement & elt ) const;
		};

		/**
		*	The class CSRABSPricingMethodMenu stores the pricing method
		*	@version 7.1.3
		*/

		class SOPHIS_FIT CSRABSPricingMethodMenu : public sophis::gui::CSRCustomMenu
		{
		public:
			CSRABSPricingMethodMenu(sophis::gui::CSRFitDialog	*dlg,
									int							ERId_Menu,
									bool						editable=true,
									NSREnums::eDataType			valueType=NSREnums::dShort,
									unsigned int				valueSize=0,
									short 						listValue=1,
									const char 					*columnName=kUndefinedField,
									bool						possibleToReset=true,
									const char *				tagColonne = kSameAsOracleName);

			virtual void SetValueFromList();
			virtual void SetListFromValue();

			int	Compare( const CSRElement & elt ) const;
		};

		/**
		*	The class CSRABSPricingMethodMenu stores the different ABS scenario
		*	@version 7.1.3
		*/

		class SOPHIS_FIT CSRABSScenarioMenu : public sophis::gui::CSRCustomMenu
		{
		public:
			CSRABSScenarioMenu(	sophis::gui::CSRFitDialog	*dialog, 
								int							ERId_Menu,
								bool						editable=true,
								NSREnums::eDataType			valueType=NSREnums::dLong,
								unsigned int				valueSize=0,
								short 						listValue=1,
								const char 					*columnName=kUndefinedField,
								bool						possibleToReset=true,
								const char *				tagColonne = kSameAsOracleName);

			CSRABSScenarioMenu(	sophis::gui::CSREditList	*list, 
								int							CNb_Menu,
								bool						editable=true,
								NSREnums::eDataType			valueType=NSREnums::dLong,
								unsigned int				valueSize=0,
								short 						listValue=1,
								const char 					*columnName=kUndefinedField,
								bool						possibleToReset=true,
								const char *				tagColonne = kSameAsOracleName);

			void	SetValueFromList();
			void	SetListFromValue();

			bool	IsValid (_STL::string scenarioName);

			typedef long value_type;

		protected:
			virtual CSUMenu	*DonneMenu(void) const;
		};

	}	//	namespace gui
}	//	namespace sophis

SPH_EPILOG
#endif  //_SPHABSMODELMENU_H
