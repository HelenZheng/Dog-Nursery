#ifndef _SphAutoCompletionEdit_H__
#define _SphAutoCompletionEdit_H__

#include "SphInc/gui/SphElement.h"

#include __STL_INCLUDE_PATH(map)

SPH_PROLOG

class CSUMenu;
class CSSuggestionHandler;

namespace sophis {
	namespace tools {
		class CSRArchive;// used within definition of ELEM_COMMON_INTERNALS
	}
}

struct SOPHIS_FIT less_string_i_functor
{
	bool operator () (const _STL::string& x, const _STL::string& y) const;	
};

namespace sophis
{
	namespace gui
	{
		/** 
		*	Class CSRGenericAutoCompletion:
		*
		*	The CSRGenericAutoCompletion class has been designed to handle a suggestion list of data inside a grid list. 
		*	The data can be chosen by selecting the right item or by typing it. If the current value is edited
		*	by typing, a suggestion list can appear in the bottom of the textbox in order to help and complete the 
		*	value automatically.
		*
		*	@version 5.2.3
		*	If the list may be long to be generated, it's advised to create a whole list which can be considered as 
		*	a source for auto completion suggestion list. This whole list is created during the calling of the constructor.
		*
		*	Use the 5.2.3 methods (the ones which contain "WholeList" in their name) to fill, clear the whole list.
		*	Do not forget to call CreateSuggestionListFromWholeList in CreateSuggestionList(const char* prefix).
		*
		*	If the creation of the whole list is not needed, don't fill the whole list.
		* 
		*
		*	OVERRIDE CreateSuggestionList METHOD TO BUILD A CUSTOM SUGGESTION LIST
		*	----------------------------------------------------------------------
		*	Actually, to have a custom suggestions list, the most important is to override the 
		*	CreateSuggestionList method (at least, CSRGenericAutoCompletion::CreateSuggestionList(const char* prefix) ).
		*
		*	There are 2 different ways to implement this control depending on time which is 
		*	taken to build the list. The list can be generated : 
		*	- every time a key is pressed (fast building lists method). You need your list builds very fast 
		*	  (among 0.2-0.5 seconds is acceptable).
		*	- when a key is pressed for the first time, the whole with all items is built (slow building list method)
		*
		*	The fast building list method can be used with filtering in order to improve performance. A first filter can be 
		*	done by filter the item which starts with the text typed in the field (this is called the "prefix").
		*
		*	The slow building list method needs you to provide the whole list with all possible items. It means there 
		*	won't be a filter by the prefix.
		*
		*	If you try to build a long time building list instead of short time list, you may encounter 
		*	performance problems. And the reverse case is also true. If the list is very long to build, prefer the 
		*	method for slow building lists.
		*
		*	Override CreateSuggestionList methods to build the list. Depending on the method you use to build the list, 
		*	you must override the correct overload method.
		*
		*	To build a fast list, you should override {@link CreateSuggestionList(const char* prefix)}. 
		*	The provided example shows how to do this.
		*
		*	To build a slow list, you should override {@link CreateSuggestionList()}. 
		*	The provided example shows how to do this. But don't forget to implement 
		*	CreateSuggestionList(const char* prefix) and call {@link CreateSuggestionListFromWholeList(const char* prefix)}.
		*
		*	@see CSRInstrumentCode
		*
		*	@remark A sample is available at SphSrc/AutoCompletion
		*
		*/
		class SOPHIS_FIT CSRGenericAutoCompletion : public CSRElement 
		{
		public:
			/**
			*	Constructor.
			*	@param dialog is a pointer to the dialog to which this element belongs. This parameter is used to set the values of the fDlog fields.
			*	@param dialog is a pointer to the dialog to which the CSRGenericAutoCompletion belongs.
			*	@param ERId_Code is the relative number of the CSRGenericAutoCompletion.
			*	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
			*	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
			*	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
			*	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*	@param creation is a boolean to ask for creation  of new reference.
			*	@param isCaseSensitive is a value indicating whether the auto completion edit control is case sensitive or not.
			*	@param maxSize is the maximum numbers of characters in an item text in the list.
			*/
			CSRGenericAutoCompletion(	CSRFitDialog 	*dialog,
				int 			ERId_Code,
				int 			ERId_Name=0,
				long			value=0,
				const char 		*columnName=kUndefinedField,
				const char		*tagColonne = kSameAsOracleName,
				bool			creation = false,
				bool			isCaseSensitive = false, 
				int				maxSize = 256);

			/**
			*	Constructor.
			*	@param list is a pointer to the editable list to which this element belongs . This parameter is used to set the values of the fEditList fields.
			*	@param CNb_Code is the relative number of the CSRGenericAutoCompletion column.
			*	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
			*	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
			*	@param columnName is the column name of a user table, whose structure includes the two following fields :
			*	- CODE number(10), security identifier. To link with the Sophis table.
			*	- NUMERO  number(3), line identifier
			*	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
			*	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*	@param isCaseSensitive is a value indicating whether the auto completion edit control is case sensitive or not.
			*	@param maxSize is the maximum numbers of characters in an item text in the list.
			*/
			CSRGenericAutoCompletion( CSREditList *list,
				int 			CNb_Code,
				int 			CNb_Name=-1,
				long			value=0,
				const char*		columnName=kUndefinedField,
				bool			canBeModified=true,
				const char*		tagColonne = kSameAsOracleName,
				bool			isCaseSensitive = false, 
				int				maxSize = 256);

			/**
			*	Destructor.
			*
			*	@remarks Therefore it should never be called explicitly. It's called by the destructor of the corresponding editable list or dialog.
			*/
			virtual ~CSRGenericAutoCompletion();

			/**
			*	Clear the whole suggestion list, whether it was made by SetCSUMenu or AddItem.
			*/
			void Clear();

			/**
			*	Adds an item for the whole suggestion list. 
			*	The partial list, the behavior are automatically managed by the toolkit.
			* 
			*	@param shortText The text to be edited and validated.
			*	@param longText The text to be displayed. Even if it's obligatory, it should start the same 
			*	way as the short text.
			*
			*	AddItem("Jun", "June");  will be displayed as Jun (June) and to get that 
			*	entry, the user has to type "J" or "Ju" or "Jun". "June" will display an empty choice.
			*
			*	@remark There's no need to sort the insertions of the items. The suggestion list is 
			*	automatically sorted.
			*/
			void AddItem(const char* shortText, const char* longText);

			/**
			*	Adds an item for the whole suggestion list. 
			*	The partial list, the behavior are automatically managed by the toolkit.
			* 
			*	@param text The text to be displayed, edited and validated. So the text in the suggestion
			*	list and the one which is edited are the same.
			*			
			*	@remark There's no need to sort the insertions of the items. The suggestion list is 
			*	automatically sorted.
			*/
			void AddItem(const char* text);

			/**
			*	Gets a value indicating whether the auto completion edit control is case sensitive.
			*	
			*	@remark The default value is false. It means if "sOph" is typed then it matches with 
			*	the following suggestions : "Sophis", "SOPHIS", "sophis", ...
			*/
			bool IsCaseSensitive() const;

			/**
			*	Sets a value indicating whether the auto completion edit control is case sensitive or not.
			*
			*	@param isCaseSensitive The value to set if the auto completion edit control is case sensitive or not.
			*
			*	@remark If the parameter isCaseSensitive is not provided, it sets to false by default.
			*/
			void SetCaseSensitive(bool isCaseSensitive = false);

			/**
			*	Gets the CSUMenu associated to the auto completion edit control. 
			*/
			CSUMenu* GetCSUMenu() const;

			/**
			*	Sets the CSUMenu associated to the auto completion edit control. 
			*	The suggestions list is automatically updated.
			*
			*	@param menu The CSUMenu which will be used to fill the suggestions list.
			*/
			void SetCSUMenu(CSUMenu* menu);

			/**
			*	Returns a suggestion menu handler. 
			*
			*	For internal use
			*
			*	@remark A suggestion menu handler can provide interesting things about a menu 
			*	like the number of items, the values of a item, ...
			*/
			CSSuggestionHandler* GetSuggestionMenu() const;

			/**
			*	Creates and fills the list of suggestions with all the possible items.
			*	This method is called when the first key is typed in the field. 
			*	Use if only the build of the suggestions list is long (more than 0.5 seconds). 
			*	
			*	If you plan to use SQL to fill the list which can takes 1 or 2 seconds.
			*	Overload CreateSuggestionList(), and use AddItemToWholeList to add all the items.
			*	The following example shows how to do. CSRSlowAutoComp inherits from CSRGenericAutoCompletion
			*
			*	void CSRSlowAutoComp::CreateSuggestionList()
			*	{
			*		// We clear the whole list
			*		ClearWholeList();
			*
			*		// We make a SQL select and fill a string array from the result of SQL Query
			*		...
			*
			*		// We add each string to the whole list
			*		for (int i=0; i<array_size; i++)
			*			AddItemToWholeList (array[i]);	// array is a string array of array_size size.
			*	}
			*
			*	@remark You must implement CreateSuggestionList(const char* prefix) and call CreateSuggestionListFromWholeList
			*	void CSRSlowAutoComp::CreateSuggestionList(const char* prefix)
			*	{
			*		CreateSuggestionListFromWholeList(prefix);
			*	}
			*
			*/
			virtual void CreateSuggestionList();

			/**
			*	Updates the value to display from the stored value.
			*
			*	@param dest The value to display which is going to be updated.
			*	@param line The line in the edit list grid where the displayed value is displayed.
			*
			*	@remark This method must be overloaded.
			*	@remark This method is used in lists like CSREditList.
			**/
			virtual void ValueToString(char* dest, int line) const = 0;

			/** 
			*	Updates the stored value to display from the displayed value.
			*
			*	@param dest The value to display which will be used to update the stored value.
			*	@param line The line in the edit list grid where the displayed value is displayed.
			*
			*	@remark This method must be overloaded.
			*	@remark This method is used in lists like CSREditList.
			*/
			virtual Boolean	StringToValue(const char* source, int line) = 0;

			/** 
			*	Gets the stored value.
			*
			*	@param value The returned value. The value is supposed to be a long in this case.
			*
			*	@remark This method must be overloaded.
			*/
			virtual void GetValue(void* value) const = 0;

			/** 
			*	Sets the stored value.
			*
			*	@param value The new value. The value is supposed to be a long in this case.
			*
			*	@remark This method must be overloaded.
			*/
			virtual void SetValue(const void* value) = 0;

			/**
			*	Gets a value indicating whether the auto completion edit control can be modified.
			*/
			virtual Boolean MenuCanBeModifiedInAList() const;

			/**
			*	Gets the maximum number of characters of the displayed value.
			*/
			int GetMaxSize() const;

			/**
			*	Sets the maximum number of characters of the displayed value.
			*
			*	@param value The new size of the displayed value.
			*/
			void SetMaxSize(int value);

			// Overload from CSRElement
			virtual void Update(void) const;
			virtual void operator = (const CSRElement&);
			void operator = (const CSRGenericAutoCompletion&);
			virtual bool IsValueValid() const;
			virtual int Compare(const CSRElement&) const;
			virtual	void Open();
			virtual void GetName(char *name) const;
			virtual	Boolean Validation();
			virtual bool CanDropFromDump(USWindow* dumpWind, long nbelem, const long* elem) const;	// internal
			virtual bool PasteFromDump(USWindow* dumpWind, long nbelem, const long* elem);			// internal

			/**
			*	Creates and fills the list of suggestions during typing in the fields.
			*	
			*	@param prefix The string entered during typing.
			*
			*	@remark Use it if the building of the list is fast because it's called every time a key is typed (less than 0.5 sec).
			*	
			*	If you plan to use array to fill the list which can takes 0.1 seconds.
			*	Overload CreateSuggestionList(const char* prefix), and use AddItem to add the items which begins with the prefix.
			*	The following example shows how to do. 
			*	CSRFastAutoComp inherits from CSRGenericAutoCompletion and has a string array fMonths.
			*
			*	void CSRFastAutoComp::CreateSuggestionList(const char* prefix)
			*	{
			*		// We clear the list
			*		Clear();
			*
			*		//foreach month, we add only the month which starts with the prefix string.
			*		for (int i=0; i<12; i++)
			*			if (sophisTools::strnicmp(fMonths[i], prefix, strlen(prefix)) == 0)
			*				AddItem(fMonths[i]);
			*	}
			*
			*	
			*	@remark If you have overridden {@link CreateSuggestionList()}, don't forget to override 
			*	this method and call {@link CreateSuggestionListFromWholeList(const char* prefix)}
			*	void CSRSlowAutoComp::CreateSuggestionList(const char* prefix)
			*	{
			*		CreateSuggestionListFromWholeList(prefix);
			*	}
			*
			*	@see CSRGenericAutoCompletion::CreateSuggestionList()
			*/
			virtual void CreateSuggestionList(const char* prefix);
			
			/**
			*	Gets the limit of the number of the items of the displayed suggestion list. 
			*/
			long GetLimitItemsNumber();

			/**
			*	Sets the limit of the number of the items of the displayed suggestion list. 
			*
			*	@param limit The limit of the number of the items of the displayed suggestion list.
			*
			*	@remark If you use AddItem whereas the size of the displayed list is reached then
			*	the item won't be add. 
			*/
			void SetLimitItemsNumber(long limit);

			/**
			*	Gets the  list of the instruments created by@see CreateSuggestionList.
			*
			*	@deprecated 5.2.3 Use *WholeList (like GetWholeListSize, ClearWholeList, ...) methods instead.
			*/
			_STL::multimap<_STL::string, _STL::string, less_string_i_functor> GetWholeList();

			/**
			*	Gets whole list size when using internal whole list.
			*
			*	@since 5.2.3
			*/
			int GetWholeListSize();

			/**
			*	Clears whole list size when using internal whole list.
			*
			*	@since 5.2.3
			*/
			void ClearWholeList();

			/**
			*	Add item to the whole list when using internal whole list.
			*
			*	@param shortText 
			*	The text to be edited and validated.
			*
			*	@param longText 
			*	The text to be displayed. Even if it's obligatory, it should start the same 
			*	way as the short text. 
			*
			*	AddItemToWholeList("Jun", "June");  will be displayed as "Jun (June)" and to get that 
			*	entry, the user has to type "J" or "Ju" or "Jun". "June" will display an empty choice.
			*
			*	@remark There's no need to sort the insertions of the items. The suggestion list is 
			*	automatically sorted.
			*
			*	@since 5.2.3
			*/
			void AddItemToWholeList(const char* shortText, const char* longText);

			/**
			*	Add item to the whole list when using internal whole list.
			*
			*	@param text The text to add to the list. Note that parameter is 
			*	considered as short text and long text. The meaning of short text and 
			*	long text can be seen at {@link CSRGenericAutoCompletion::AddItemToWholeList}.
			*
			*	@remark There's no need to sort the insertions of the items. The suggestion list is 
			*	automatically sorted.
			*
			*	@since 5.2.3
			*/
			void AddItemToWholeList(const char* text);
			
			/**
			*	Create the suggestion list from a prefix during typing. 
			*	The source used to fill the suggestion list is the whole list. 
			*   It must be used during the calling of 
			*	{@link CSRGenericAutoCompletion::CreateSuggestionList(const char* prefix)}.
			* 
			*	@parameter prefix The prefix typed by the user.
			*
			*	@since 5.2.3
			*/
			void CreateSuggestionListFromWholeList(const char* prefix);

			/**
			*	For Toolkit : if you create a component deriving directly from this class, and if you use this component
			*	in a CSRFitDialog, then you need to call this method for autocompletion to work.
			*	To call it, override the Initialisation(CSRFitDialog *dialogue, int &numero) method 
			*	(declared here by ELEM_COMMON_INTERNALS), and call this method inside. For instance :
			*   void YourComponentClass::Initialisation(CSRFitDialog *dialogue, int &numero)
			*	{
			*		Initialize(dialogue, numero, yourStringToValueFuncPtr, yourValueToStringFuncPtr, yourCheckStringFuncPtr);
			*	}
			*	@parameter dialog is your CSRFitDialog (same as Initialisation parameter named 'dialogue')
			*	@parameter number is the id of your component (same as Initialisation parameter named 'numero')
			*	@parameter StringToValueFuncPtr is pointer to a static function that converts a string into a long
			*	@parameter ValueToStringFuncPtr is pointer to a static function that converts a long into a string
			*	  This method should write the string into the char * parameter and return this parameter. 
			*   @parameter CheckStringFuncPtr is pointer to a static function that do almost the same as StringToValueFuncPtr, but make sure it returns 0
			*    when no value corresponds to the string.
			*
			*	@since 5.3.4
			*/
			void Initialize(CSRFitDialog *dialog, int &number, 
									long (*StringToValueFuncPtr)(const char*), 
									char * (*ValueToStringFuncPtr)(long, char*), 
									long (*CheckStringFuncPtr)(char*));

			typedef long value_type;

			long GetValue() const; // internal

			int GetNameId() const; // internal

		protected:
			/**
			* The stored value.
			*/
			long fValue;

			/**
			* The maximum number of characters of the displayed value.
			*/
			int fMaxSize;

			/**
			* The number of the column used to display the name of the instrument.
			*/
			int fERId_Name;

			/**
			* Handles the suggestion menu.
			*/
			CSSuggestionHandler* fSuggestionMenu;

			/**
			* Used to have all instrument lists.
			*
			* @remark It's not used in CSRInstrumentCode but it can be used in case of 
			* performance problems during the autocompletion during typing.
			*
			* @deprecated 5.2.3 it's not used internally.
			*/
			SPH_BEGIN_NOWARN_EXPORT
			_STL::multimap<_STL::string, _STL::string, less_string_i_functor> fWholeList;
			SPH_END_NOWARN_EXPORT
		
		private : 
			static const char* __CLASS__;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal

			ELEM_COMMON_INTERNALS
		};
	}
}

SPH_EPILOG

#endif