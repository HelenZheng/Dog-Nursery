#pragma once

#ifndef __SphBackOfficeKernelUI_H__
#define __SphBackOfficeKernelUI_H__

#include "SphInc/SphMacros.h"
#include "SphInc/backoffice_kernel/SphThirdPartyDlg.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"

class CSWindow;	// internal

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class SPH_BO_KERNEL_GUI CSRBackOfficeKernelUI
		{
		public:
			/**Specify the third party to edit.
			@param	thirdPartyId the id of the third party.
			@version 7.0
			*/
			static void EditThirdParty(long thirdPartyId);

#ifndef GCC_XML
			class SPH_BO_KERNEL_GUI ThirdPartyDlg
			{
			public:
				/** Return a third party from the window third party and an id.
				This is for internal use, not available in API and links with SphBackOfficeKernelGUI.
				@param window is a window.	
				@param id is a reference of a row in that window.
				@return a third party object which must not be deleted; return 0 if the window is not the good one.
				@since 4.4.1.2
				*/
				static const sophis::backoffice_kernel::CSRThirdPartyDlg *GetInstance(const CSWindow * window, LONG_PTR id);

				/** Show the the third party window.
				It is not available in API and links with SphBackOfficeKernelGUI.
				@param mode if a filter on the third party window.
				@since 4.4.1.2
				*/
				static void	ShowWindow(sophis::backoffice_kernel::eThirdGuiFilterMode filterMode);

				/** Open the third party dialog.
				It is not available in API and links with SphBackOfficeKernelGUI.
				@since 4.4.1.2
				*/
				static void OpenDialog(const sophis::backoffice_kernel::CSRThirdPartyDlg& dlg);

			private:
				ThirdPartyDlg();
				~ThirdPartyDlg();
				ThirdPartyDlg(const ThirdPartyDlg&);
				ThirdPartyDlg& operator = (const ThirdPartyDlg&);
			};

#endif

		private:
			CSRBackOfficeKernelUI();
			CSRBackOfficeKernelUI(const CSRBackOfficeKernelUI&);
			~CSRBackOfficeKernelUI();
			CSRBackOfficeKernelUI& operator = (const CSRBackOfficeKernelUI&);
		};
	}
}
SPH_EPILOG

#endif
