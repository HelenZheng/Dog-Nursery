#pragma once


#ifndef __SphBondYieldCurveDialog_H__
#define __SphBondYieldCurveDialog_H__

#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialog.h"

class CSRBondYCDialogData;
class CSRGeneralBondYCDialogData;
struct TDlog;
class CSRLayout;

#define DECLARATION_BOND_YIELD_CURVE_DIALOG(derivedClass) \
	static sophis::gui::CSRBondYieldCurveDialog * NewDeriveSophis();

#define WITHOUT_CONSTRUCTOR_BOND_YIELD_CURVE_DIALOG(derivedClass)	\
	sophis::gui::CSRBondYieldCurveDialog* derivedClass::NewDeriveSophis() { return new derivedClass(); }

#define DECLARATION_BOND_YIELD_CURVE_GENERAL_DIALOG(derivedClass) \
	static sophis::gui::CSRBondYieldCurveGeneralDialog * NewDeriveSophis();

#define WITHOUT_CONSTRUCTOR_BOND_YIELD_CURVE_GENERAL_DIALOG(derivedClass)	\
	sophis::gui::CSRBondYieldCurveGeneralDialog* derivedClass::NewDeriveSophis() { return new derivedClass(); }



SPH_PROLOG
namespace sophis
{
	namespace market_data
	{
		class CSRBondYieldCurve;
	}

	namespace gui
	{
		/** Base class for storing specific toolkit data for on-the-run bond yield curves
		Use INITIALISE_BOND_YIELD_CURVE_WITH_DATA to link this storage with a specific curve model
		@version 6.3
		*/
		class SOPHIS_FIT CSRBondYieldCurveDialog : public CSRFitDialog
		{
		public:
			/** Trivial constructor
				@version 6.3
			*/
			CSRBondYieldCurveDialog();

			/** Destructor
				@version 6.3
			*/
			virtual ~CSRBondYieldCurveDialog();

			/** Gets the curve associated with this dialog
			Note: this method only has effect outside the constructor, in GUI mode
			@return a pointer (which must *not* be deleted) to the curve, or null if not available
			@version 6.3
			*/
			const sophis::market_data::CSRBondYieldCurve* GetCSRBondYieldCurve() const;

			/** Gets the curve associated with this dialog
			Note: this method only has effect outside the constructor, in GUI mode
			@return a pointer (which must *not* be deleted) to the curve, or null if not available
			@version 6.3
			*/
			sophis::market_data::CSRBondYieldCurve* GetCSRBondYieldCurve();

			/** Update the curve (returned by GetCSRBondYieldCurve) with the data set in the dialog
			Note: this method only impacts the toolkit data
			Note: this method only has effect outside the constructor, in GUI mode.
			@version 6.3
			*/
			void UpdateCurveWithUI();

			/** Update the dialog with data set in the curve.
			Note this method only impacts the toolkit dialog elements
			Note: this method only has effect outside the constructor, in GUI mode
			@version 6.3
			*/
			void UpdateUIWithCurve();

			// INTERNAL
			inline const CSRBondYCDialogData& GetData() const;
			// INTERNAL
			inline CSRBondYCDialogData& GetData();
		private:
			// INTERNAL
			CSRBondYieldCurveDialog(const CSRBondYieldCurveDialog&);
			// INTERNAL
			CSRBondYieldCurveDialog& operator = (const CSRBondYieldCurveDialog&);
			// INTERNAL
			typedef CSRFitDialog base;

			// INTERNAL
			CSRBondYCDialogData* fData;
		};

		inline const CSRBondYCDialogData& CSRBondYieldCurveDialog::GetData() const { return *fData; }
		inline CSRBondYCDialogData& CSRBondYieldCurveDialog::GetData() { return *fData; }

		/** Base class for adding general toolkit data for on-the-run bond yield curves
		Use INITIALISE_BOND_YIELD_CURVE_GENERAL to add a general toolkit storage
		@version 6.3
		*/
		class SOPHIS_FIT CSRBondYieldCurveGeneralDialog : public CSRFitDialog
		{
		public:
			/** Trivial constructor
			@version 6.3
			*/
			CSRBondYieldCurveGeneralDialog();

			/** Destructor
			@version 6.3
			*/
			virtual ~CSRBondYieldCurveGeneralDialog();

			/** Gets the curve associated with this dialog
			Note: this method only has effect outside the constructor, in GUI mode
			@return a pointer (which must *not* be deleted) to the curve or null if not available
			@version 6.3
			*/
			const sophis::market_data::CSRBondYieldCurve* GetCSRBondYieldCurve() const;

			/** Gets the curve associated with this dialog
			Note: this method only has effect outside the constructor, in GUI mode
			@return a pointer (which must *not* be deleted) to the curve or null if not available
			@version 6.3
			*/
			sophis::market_data::CSRBondYieldCurve* GetCSRBondYieldCurve();

			/** Update the curve (returned by GetCSRBondYieldCurve) with the data set in the dialog
			Note: this method only impacts the toolkit data
			Note: this method only has effect outside the constructor, in GUI mode
			@version 6.3
			*/
			void UpdateCurveWithUI();

			/** Update the dialog with data set in the curve.
			Note this method only impacts the toolkit dialog elements
			Note: this method only has effect outside the constructor, in GUI mode
			@version 6.3
			*/
			void UpdateUIWithCurve();

			/** Refresh the whole dialog
			Note: this method only has effect outside the constructor, in GUI mode
			@version 6.3
			*/
			void RefreshDialog();

			/** Remove a standard element from the dialog
			Note: this method only has effect when called in a constructor
			@param eltId is the identifier of the element to remove
			@version 6.3
			*/
			void RemoveStandardElement(int eltId);

			/** Reset the dialog curve with the given one.
			This method is only needed when direct modifications on the curve returned by GetCSRBondYieldCurve
			are not enough (typically when modifying the curve model).
			Note: the given curve is cloned
			Note: this method only has effect outside the constructor, in GUI mode
			@param curve is the new curve to use in the dialog
			@version 6.3
			*/
			void ResetCurve(const sophis::market_data::CSRBondYieldCurve& curve);

			/** Called by Sophis whenever a modification occurs in the curve dialog
			Note: this method is only called in GUI mode
			@version 6.3
			*/
			virtual void OnCurveModified();

			/** Flag the curve as modified
			Note: this method only has effect outside the constructor, in GUI mode
			@version 6.3
			*/
			void SetCurveModified();

			/** LOW LEVEL TOOLKIT
			Called on dialog opening to modify existing layout
			By default, this method returns false
			@layout the layout to update
			@return true to install the layout, false when no layout is required
			@version 6.3
			*/
			virtual bool UpdateLayout(CSRLayout& layout);

			// INTERNAL
			inline const CSRGeneralBondYCDialogData& GetData() const;
			// INTERNAL
			inline CSRGeneralBondYCDialogData& GetData();

		private:
			// INTERNAL
			CSRBondYieldCurveGeneralDialog(const CSRBondYieldCurveGeneralDialog&);
			// INTERNAL
			CSRBondYieldCurveGeneralDialog& operator = (const CSRBondYieldCurveGeneralDialog&);
			// INTERNAL
			typedef CSRFitDialog base;

			// INTERNAL
			CSRGeneralBondYCDialogData* fData;
		};

		inline const CSRGeneralBondYCDialogData& CSRBondYieldCurveGeneralDialog::GetData() const { return *fData; }
		inline CSRGeneralBondYCDialogData& CSRBondYieldCurveGeneralDialog::GetData() { return *fData; }
	}
}

SPH_EPILOG
#endif
