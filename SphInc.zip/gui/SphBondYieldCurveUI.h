#pragma once

#ifndef __SphBondYieldCurveUI_H__
#define __SphBondYieldCurveUI_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphPrototype.h"
#include "SphInc/market_data/SphBondYieldCurve.h"


#define DECLARATION_BOND_YC_INTERPOLATION_UI(derived)			DECLARATION_PROTOTYPE(derived, sophis::gui::CSRBondYieldCurveInterpolationUI)
#define INITIALISE_BOND_YC_INTERPOLATION_UI(className, ident)	INITIALISE_PROTOTYPE(className, ident)

class ISRBYCInterpolationUIContext;
SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		/** Base class for drawing interpolation graphs in bond yield curve dialog.
		Use INITIALISE_BOND_YC_INTERPOLATION_UI with the same identifier used to register the interpolation model.
		This class is only used to draw lines between two graph points. All other data are using the interpolation model.
		@version 6.3
		*/
		class SOPHIS_BASIC_DATA_GUI CSRBondYieldCurveInterpolationUI
		{
		public:
			/** Trivial constructor
			@version 6.3
			*/
			CSRBondYieldCurveInterpolationUI();

			/** Virtual destructor
			@version 6.3
			*/
			virtual ~CSRBondYieldCurveInterpolationUI();

			/** Duplicate this object
			Use DECLARATION_BOND_YC_INTERPOLATION_UI
			@return a new object (which must be deleted) identical to the callee.
			@version 6.3
			*/
			virtual CSRBondYieldCurveInterpolationUI* Clone() const;

			/** Typedef for graphical point
			@version 6.3
			*/
			typedef _STL::pair<long, double> UIPoint;

			/** Draw lines to join two points.
			This method calls DrawCurveCore
			@param a is the first point
			@param b is the second point
			@version 6.3
			*/
			void DrawCurve(const UIPoint& a, const UIPoint& b) const;

			/** Typedef for prototype
			@version 6.3
			*/
			typedef sophis::tools::CSRPrototype<CSRBondYieldCurveInterpolationUI, long> prototype;

			/** Gets the registration prototype
			Use INITIALISE_BOND_YC_INTERPOLATION_UI.
			@return the registration prototype
			@version 6.3
			*/
			static prototype& GetPrototype();

			/** Gets the default (fallback) model.
			This model is linked with linear interpolation
			@return the default drawing model
			@version 6.3
			*/
			static const CSRBondYieldCurveInterpolationUI& Default();

			/** Gets the drawing model associated with an interpolation.
			When none is found, the default one is used.
			@param model is the interpolation to draw
			@return the drawing model to use
			@version 6.3
			*/
			static const CSRBondYieldCurveInterpolationUI& GetModel(long model);

			// INTERNAL
			void SetContext(ISRBYCInterpolationUIContext* ctx);

		protected:
			/** Called by Sophis to draw interpolation between two points.
			@param a is the first point
			@param b is the second point
			@see DrawLine
			@version 6.3
			*/
			virtual void DrawCurveCore(const UIPoint& a, const UIPoint& b) const;

			/** Draws a straight line between two points.
			@param a is the first point.
			@param b is the second point.
			@version 6.3
			*/
			void DrawLine(const UIPoint& a, const UIPoint& b) const;

		private:
			// INTERNAL
			ISRBYCInterpolationUIContext* fContext;
		};



		/** Static class containing methods usefull to visualize on-the-run bond yield curves
		@version 6.3
		*/
		class SOPHIS_BASIC_DATA_GUI CSRBondYieldCurveUI
		{
		public:
			/** Opens or activates the dialog corresponding to the curve
			If a curve with the same identifier has already its dialog open, it is put in front (and modified has no effect).
			Note that the curve is cloned in the process.
			@param yc is the curve to open.
			@param modified is boolean saying whether the dialog should be flagged a modified on opening
			@version 6.3
			*/
			static void OpenCurveDialog(const sophis::market_data::CSRBondYieldCurve& yc, bool modified = false);

			/** Opens or activates a curve dialog.
			If the curve dialog is already open, it is put in front (and modified has no effect)
			@param curveCode is the identifier of the curve to open
			@param modified is boolean saying whether the dialog should be flagged a modified on opening
			@version 6.3
			*/
			static void OpenCurveDialog(long curveCode, bool modified = false);

			/** Close the dialog of the curve with the given code.
			@param curveCode is the identifier of the curve whose dialog should be closed
			@return true on success (or if no such dialog is open), false otherwise (e.g. if the user refused to close the dialog)
			@version 6.3
			*/
			static bool CloseCurveDialog(long curveCode);
		private:
			CSRBondYieldCurveUI();
			CSRBondYieldCurveUI(const CSRBondYieldCurveUI&);
			~CSRBondYieldCurveUI();
			CSRBondYieldCurveUI& operator = (const CSRBondYieldCurveUI&);
		};
	}
}
SPH_EPILOG
#endif
