#ifndef _SphButton_H__
#define _SphButton_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphDialog.h"
#include __STL_INCLUDE_PATH(set)



SPH_PROLOG
namespace sophis
{
	namespace gui
	{

		/** Class CSRButton:
		*	The class CSRButton implements a basic button which commands a defined action when clicked.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRButton : public CSRElement
		{
		public:
			/** Constructor.
			The constructor CSRButton::CSRButton() calls the constructor CSRElement::CSRElement() by handing over
			the parameters dialog and ERId_Element.
			The ERId_Element parameter of CSROKButton, CSRCancelButton and CSRAlternativeButton have defaults values 1, 2 and 3.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Element is the relative ID of the button in the dialog.
			@param tooltip is the tooltip to be displayed.
			@version 4.5.2
			*/
			CSRButton(CSRFitDialog *dialog, int ERId_Element, _STL::string tooltip = "");

			/** Action associated with the button.
			After the Action() method has been defined, it is automatically called whenever the user clicks on the CSRButton.
			@version 4.5.2
			*/
			virtual	void	Action();

		public:
			void	Initialisation(CSRFitDialog *dialog, int &number);				// internal
		};

		/** Class CSROKButton:
		*	Implements an OK button which commands the common action in response to the user accepting information on the dialog.
		*	The OK button is a preselected element by default.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSROKButton : public CSRButton
		{
		public:
			/** Constructor.
			The constructor CSROKButton::CSROKButton() calls the constructor CSRElement::CSRElement() by handing over
			the parameters dialog and ERId_Element.
			The ERId_Element parameter is by default 1.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Element is the relative ID of the button in the dialog.
			@version 4.5.2
			*/
			CSROKButton(CSRFitDialog *dialog, int ERId_Element = 1);

			/** Action associated with the button.
			Default actions associated with the OK button causes the closure
			of the dialog and the return to the method CSRFitDialog::DoDialog() with the exiting parameter.
			@see CSRFitDialog::OnOK()
			This method will in turn call CSRFitDialog::OnOK() of the containing dialog.
			@see CSRFitDialog::DoDialog()
			@version 4.5.2
			*/
			virtual	void	Action();

		public:
		};

		/** Class CSRCancelButton:
		*	Implements a Cancel button which commands the common action in response to the user cancelling the
		*	modification of information on the dialog.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRCancelButton : public CSRButton
		{
		public:
			/** Constructor.
			The constructor CSRCancelButton::CSRCancelButton() calls the constructor CSRElement::CSRElement() by handing over
			the parameters dialog and ERId_Element.
			The ERId_Element parameter is by default 2.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Element is the relative ID of the button in the dialog.
			@version 4.5.2
			*/
			CSRCancelButton(CSRFitDialog *dialog, int ERId_Element = 2);

			/** Action associated with the button.
			Default actions associated with the Cancel button causes the closure
			of the dialog and the return to the method CSRFitDialog::DoDialog() with the right leaving parameter.
			@see CSRFitDialog::DoDialog()
			This method will in turn call CSRFitDialog::OnCancel() of the containing dialog.
			@see CSRFitDialog::OnCancel()
			@version 4.5.2
			*/
			virtual	void	Action();
		};

		/** Class CSRAlternativeButton:
		*	Implements a Delete button which commands the action of deleting (and closing) the dialog.
		*	As a result, the class derived from CSRAlternativeButton may display the information on the dialog
		*	in their initial values, when the dialog is opened again.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRAlternativeButton : public CSRButton
		{
		public:
			/** Constructor.
			The constructor CSRAlternativeButton::CSRAlternativeButton() calls the constructor CSRElement::CSRElement()
			by handing over	the parameters dialog and ERId_Element.
			The ERId_Element parameter is by default 3.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Element is the relative ID of the button in the dialog.
			@version 4.5.2
			*/
			CSRAlternativeButton(CSRFitDialog *dialog, int ERId_Element = 3);

			/** Action associated with the button.
			Default actions causes the closure of the dialog.
			@version 4.5.2
			*/
			virtual	void	Action();
		};

		/** Class CSRInstrumentName:
		*	The CSRInstrumentName button commands the action of displaying a dialog containing information on an
		*	instrument. Because instruments may be required as underlying of several products, it is useful to
		*	specify one type of button that will display the instrument's information, whenever this is required.
		*	This class assumes that within the same dialog, there exists an element storing the instrument's code\reference.
		*	@see CSRInstrumentCode
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRInstrumentName : public CSRButton
		{
		public:
			/** Constructor.
			The constructor CSRInstrumentName::CSRInstrumentName() calls the constructor CSRElement::CSRElement()
			by handing over	the parameters dialog and ERId_Name.
			It sets the relative ID of the instrument code element in the dialog.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Name is the relative ID of the button in the dialog.
			@param ERId_Code is the relative ID of the instrument code element in the dialog. This sets the value of fCodeId.
			@version 4.5.2
			*/
			CSRInstrumentName(CSRFitDialog *dialog, int ERId_Name, int ERId_Code);

			/** Displays the dialog of the instrument.
			On clicking on the button, a dialog opens with the instrument information. The instrument's code is retrieved with the
			the relative ID fCodeId. If the instrument's code dialog does not exist, the method displays nothing.
			@see fCodeId
			@version 4.5.2
			*/
			void Action();
		protected:

			/**The relative ID of the instrument code element, of which the information are displayed when clicking on the button.
			@version 4.5.2
			*/
			int fCodeId;
		};

		/** Class CSRInstrumentListButton:
		*	The CSRInstrumentListButton button commands the action of displaying the list of instruments of a certain
		*	category (Shares, Swapped Options, Bonds, etc).
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRInstrumentListButton : public CSRButton
		{
		public:
			/** Constructor.
			The constructor calls the constructor CSRElement::CSRElement() by handing over the parameters dialog and item.
			It also sets the type of instruments to display in the list.
			@param dialog points to the dialog to which the button belongs.
			@param item is the relative ID of the button in the dialog.
			@param menuItem is the identifying number of the category of instruments that are displayed. It is set to fMenuItem.
			@version 4.5.2
			*/
			CSRInstrumentListButton(CSRFitDialog* dialog, long item, long menuItem=0);

			/** Displays the list of instruments of a certaing category.
			On pressing the CSRInstrumentListButton button, the list of instrument of all categories is displayed.
			The overriding method may use member fMenuItem to limit the instruments displayed to be of a certain category.
			@version 4.5.2
			*/
			void Action();

		protected:

			/** The identifier of the category or type of the instruments that are to display.
			The different categories are the different items that appear under the 'Instruments' menu in RISQUE.
			@version 4.5.2
			*/
			int fMenuItem;
		};


		/**
		* Class providing a button able to delegate the user action to
		* an event listener.
		* @version 5.2.6
		*/
		class SOPHIS_FIT CSRBasicButton : public CSRButton
		{
		public:
			/**
			* Interface of the listener for the CSRBasicButton class.
			* @version 5.2.6
			*/
			class CSRListener
			{
			public:
				/**
				* The method called on user actions.
				* @param iButton
				*     The CSRBasicButton which has been activated.
				* @version 5.2.6
				*/
				virtual void OnButtonAction( const CSRBasicButton& iButton ) = 0;
			};

		public:
			/**
			* Constructor.
			* @param iDialog
			*     The owning CSRFitDialog
			* @param iResID
			*     The resource ID for the button
			* @version 5.2.6
			*/
			CSRBasicButton( CSRFitDialog* iDialog , int iResID );

			/**
			* Destructor.
			* @version 5.2.6
			*/
			virtual ~CSRBasicButton();

			/**
			* Add a listener.
			* @param iListener
			*     The listener to add. A listener can not be added twice.
			* @version 5.2.6
			*/
			void AddListener( CSRListener* iListener );

			/**
			* Remove a listener.
			* @param iListener
			*     The listener to remove.
			* @version 5.2.6
			*/
			void RemoveListener( CSRListener* iListener );

			/**
			* Overload of the CSRButton method in order to delegate the processing
			* of the user action.
			* @version 5.2.6
			*/
			virtual void Action();

		private:
			// INTERNAL
			SPH_BEGIN_NOWARN_EXPORT
			_STL::set<CSRListener*> fListenerSet;
			SPH_END_NOWARN_EXPORT
		private:
			// No copy allowed.
			CSRBasicButton( const CSRBasicButton& );
			CSRBasicButton& operator = ( const CSRBasicButton& );
		};

		/** Class CSRIconButton:
		*	Using the class CSRIconButton allows you to handle more elaborate buttons than 'OK', 'Cancel' and 'Aternative'.
		*	For instance, the user may require a 'triple icon', which allows for three states - normal, selected and disabled.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRIconButton : public CSRBasicButton
		{
		public:
			/* Constructor.
			The constructor CSRIconButton::CSRIconButton() calls the constructor CSRButton::CSRButton() by handing
			over the parameters dialog and ERId_Element. The parameter largeIcon indicates whether the resource is of type
			'ics8' (ICon Small, 8 bits per pixel) or 'icl8' (ICon Large, 8 bits per pixel).
			The parameter iconResourceId indicates its number. The resources must be numbered in the following way :
			iconResourceId for the normal button, iconResourceId+1 for the 'on' button and iconResourceId+2 for the
			greyed-out button.
			The parameter iconResourceId is stored in the field fIconId. The parameter largeIcon is stored
			in the field fLargeIcon.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Element is the relative ID of the button in the dialog.
			@param iconResourceId is to indicate the resource id of the icon.
			@param largeIcon is to indicate the size (large or small) of the resource icon.
			@version 4.5.2
			*/
			CSRIconButton(CSRFitDialog *dialog, int ERId_Element, int iconResourceId, Boolean largeIcon = false);

			/** Sets resource ID of the icon.
			The button is refreshed as a result.
			@version 4.5.2
			*/
			void	SetIcon(int iconResourceId);

			void	Initialisation(CSRFitDialog *dialog, int &number);	// internal


		protected:
			/**The resource id of the icon.
			*/
			int		fIconId;

			/** Indicates the size type of the icon.
			Set to true if the resource is of type 'icl8' (ICon Large, 8 bits per pixel),
			false if of type 'ics8' (ICon Small, 8 bits per pixel).
			@version 4.5.2
			*/
			Boolean	fLargeIcon;

			int		fIdInDlog; // SA: internal
		};


		/** Class CSRFamilyName:
		*	The CSRFamilyName button commands the action of displaying a dialog containing information on a yield curve
		*	family. Because the default currency family is used in calculation, it is useful to specify one type of 
		*	button that will display the yield curve family's information, whenever this is required.
		*
		*	@version 5.0.0
		*/
		class SOPHIS_BASIC_DATA_GUI CSRFamilyName : public CSRButton
		{
		public:
			/** Constructor.
			The constructor CSRFamilyName::CSRFamilyName() calls the constructor CSRElement::CSRElement()
			by handing over	the parameters dialog and ERId_Name. It sets also the currency and family codes.
			@param dialog points to the dialog to which the button belongs.
			@param ERId_Name is the relative ID of the button in the dialog.
			@param currency_code is the currency code. This sets the value of fCurrencyCode.
			@param family_code is the currency code. This sets the value of fFamilyCode.
			@version 5.0.0
			*/
			CSRFamilyName(CSRFitDialog *dialog, int ERId_Name, long currency_code, long family_code = 0);

			/** Displays the dialog of the yield curve family.
			On clicking on the button, a dialog opens with the yield curve family information. 
			On control+clicking on the button, a dialog opens with information about the default yield curve
			of the displayed family. 
			@version 5.0.0
			*/
			virtual void Action();

			/** Sets the new value of fCurrencyCode.
			The button is refreshed as a result.
			The default yield curve family name of the new currency will be displayed.
			@param newCurrency is the new value of fCurrencyCode.
			@version 5.0.0
			*/
			virtual void SetCurrency(long newCurrency); 

			/** Sets the new value of fFamilyCode.
			The button is refreshed as a result.
			The yield curve family name of the new family will be displayed.
			@param newFamily is the new value of fFamilyCode.
			@version 5.0.0
			*/
			virtual void SetFamily(long newFamily);

		protected:

			/**The currency code, from which the default yield curve family is gotten.
			@version 5.0.0
			*/
			long fCurrencyCode;

			/**The yield curve family code, of which the yield curve family information are displayed when clicking on the button.
			@version 5.0.0
			*/
			long fFamilyCode;
		};
	}
}
SPH_EPILOG

#endif