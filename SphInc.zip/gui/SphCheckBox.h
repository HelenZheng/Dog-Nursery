#ifndef _SphCheckBox_H__
#define _SphCheckBox_H__

#include "SphInc/gui/SphElement.h"
//#include "SphSDBCInc/SphSQLDataTypes.h"// used within definition of ELEM_COMMON_INTERNALS

SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSRArchive;// used within definition of ELEM_COMMON_INTERNALS
	}
}

namespace sophis
{
	namespace gui
	{

		/** Class CSRCheckBox:
		*	The class CSRCheckBox creates a conventional checkbox. Unlike radio buttons, checkboxes are independent
		*	from one another, i.e. the status of a definite checkbox does not affect the status of the other checkboxes.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRCheckBox : public CSRElement {
		public:
			/**Constructor.
			The constructor CSRCheckBox::CSRCheckBox() calls the constructor CSRElement::CSRElement() to which it passes
			on the parameters dialog, ERId_Element and columnName, then initialises the fields fValue and fNoDlgModif.
			The parameter fieldInTable is effective only when deriving a generic security dialog or a model.
			It is always assumed that the name of all user-created fields obey the
			following pattern : ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog points to the dialog to which the checkbox belongs.
			@param ERId_Element is the relative number of the checkbox. If not strictly positive, CSRFitDialog will
				assume that there is no such element in the associated resource, hence the CSRCheckBox will not be visually handled.
				However, the column columnName corresponding to this checkbox will be taken into account whenever necessary and its content will always be accessible.
			@param value is the default value (fValue) set to false. This parameter is used to initialise fValue if columnName is nvZero or whenever creating a security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
				For instance, ZZZ_MyColumn of the table TITRES is handled by CSRInstrument. If this parameter is not nvZero and
				if this security exists, the content of ZZZ_MyColumn with respect to this security will be used (instead of value) to initialise fValue.
			@param noDlgModif is to state whether the value of the checkbox can be modified.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRCheckBox(	CSRFitDialog*	dialog,
							int 			ERId_Element,
							Boolean			value=false,
						const char*			columnName = kUndefinedField,
							bool			noDlgModif=false,
							const char *	tagColonne = kSameAsOracleName);

			/** Sets the checking status of the check box.
			@param value is a generic pointer to a value that is assigned to fValue.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/** Obtains the current checking status of the check box.
			@param value is a generic pointer to memory where the current setting (checked/unchecked) of the check box is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/** Assigns the checking status of another element, to the fValue of this check box.
			@param a CSRElement reference referring to a CSRCheckBox object from which the fValue is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/** Assigns the checking status of another CSRCheckBox element, to the fValue of this check box.
			@param a CSRCheckBox object from which the fValue is copied.
			@version 4.5.2
			*/
					void operator = (const CSRCheckBox&);
			virtual int		Compare(const CSRElement&) const;

			/** Obtains a pointer to the boolean value indicating the current checking status of the element.
			@version 4.5.2
			*/
			bool	*GetValue(void) { return &fValue; }

			/// Value type as returned by CSRElement::GetElementValue
			typedef bool value_type;

			ELEM_COMMON_INTERNALS

		protected:
			/** The check box's boolean value, which indicates if the box is checked.
			@version 4.5.2
			*/
			bool	fValue;

			/** This is true to indicate that the check box is for read only purposes, and cannot be modified.
			@version 4.5.2
			*/
			bool	fNoDlgModif;

		};

	}
}
SPH_EPILOG
#endif
