#ifndef _SphCode_H__
#define _SphCode_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphAutoCompletionEdit.h"
//#include "SphSDBCInc/SphSQLDataTypes.h"// used within definition of ELEM_COMMON_INTERNALS

SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSRArchive;// used within definition of ELEM_COMMON_INTERNALS
	}
}

struct TDlog;

namespace sophis
{
	namespace gui
	{

/** Class CSRInstrumentCode:
*	The CSRInstrumentCode class has been designed to handle a security or instrument code (Sicovam), which can be used to
*	display the name of the security in a static text box of an element that is on the same dialog or list.
*	Given this code, it displays the security name as a static text item.
*	On the CSRInstrumentCode text box, the information displayed is the reference of the security.
*
*	@see CSRGenericAutoCompletion 
*
*	@since 3.4
*
*	@since 5.2.3
*	There is also methods which can be overloaded for a custom completion edit. In that case, look 
*	at {@link CSRGenericAutoCompletion}.Don't forget, there are 2 ways to build a suggestion list 
*	depending on speed which is needed to build it.
*
*	The way to implement a CSRInstrumentCode or its inherits is a bit different if you want to add in a 
*	CSREditList or a CSRFitDialog. The following shows you how to implement it.
*
*	1. ADD AN INHERITED COMPONENT TO AN EDIT LIST
*	---------------------------------------------
*	- You have to do the constructor
*	CSRSampleAutoComp::CSRSampleAutoComp(	CSREditList			*baseList, 
*		int 				CNb_Code,
*		int 				CNb_Name)
*		: CSRInstrumentCode(baseList, CNb_Code, false, CNb_Name)
*	{
*
*	}
*
*	- Implement the {@link CSRGenericAutoCompletion::CreateSuggestionList} methods.
*
*	- In the constructor of your list, add the component :
*	CSRSampleList::CSRSampleList(CSRFitDialog *dialog)
*		: CSREditList(dialog, ERId_Element, kUndefinedTable, MAX_NB_OF_ITEMS)
*	{
*		// Initialization code
*		...
*
*		fColumnCount			= 2;
*		fColumns				= new SSColumn[fColumnCount];
*
*		// We add a CSRInstrumentCode and our sample which inherits from CSRInstrumentCode.
*		fColumns[0].fElement		= new CSRInstrumentCode(this);	//We consider CNb_Code & CNb_Name are -1
*		fColumns[0].fColumnWidth	= 100;
*		fColumns[0].fAlignmentType	= aRight;
*		fColumns[0].fColumnName		= "Sample column with CSRInstrumentCode";
*
*		fColumns[1].fElement		= new CSRSampleAutoComp(this);	//We consider CNb_Code & CNb_Name are -1
*		fColumns[1].fColumnWidth	= 100;
*		fColumns[1].fAlignmentType	= aRight;
*		fColumns[1].fColumnName		= "Sample column with our custom component";
*
*		// Other initializations 
*		...
*	}
*
*	2. ADD AN INHERITED COMPONENT TO A DIALOG
*	-----------------------------------------
*	- You have to do the constructor
*	CSRSampleAutoComp::CSRSampleAutoComp(CSRFitDialog *dialog, 
*		int 				CNb_Code,
*		int 				CNb_Name)
*		: CSRInstrumentCode(dialog, CNb_Code, false, CNb_Name)
*	{
*
*	}
*
*	- Implement the {@link CSRGenericAutoCompletion::CreateSuggestionList} methods.
*
*	- In the constructor of your list, add the component :
*	CSRSampleDialog::CSRSampleDialog(): CSRFitDialog()
*	{
*		// Initialization code
*		...
*	
*		NewElementList(2);
*
*		if(fElementList) 
*		{
*			// We add a CSRInstrumentCode and our sample which inherits from CSRInstrumentCode.
*			fElementList[0] = new CSRInstrumentCode(this);	//We consider CNb_Code & CNb_Name are -1
*			fElementList[1] = new CSRSampleAutoComp(this);	//We consider CNb_Code & CNb_Name are -1
*		}
*
*		// Other initializations 
*		...
*
*	}
*
*	@remark The destructor is called when the window is closing or when the graphical component is destroyed.
*	@remark The strings used to display the list are copies. 
*
*	@remark A sample is available at SphSrc/AutoCompletion
*
*/
class SOPHIS_FIT CSRInstrumentCode : public CSRGenericAutoCompletion {
public:
	/**Overloaded Constructor 1.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: dialog, ERId_Code and columnName before initialising the fields fERId_Name and fValue.
	The parameter columnName is used only in model or when the generic security dialog has been derived
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRInstrumentCode belongs.
	@param ERId_Code is the relative number of the CSRInstrumentCode.
	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param creation is a boolean to ask for creation  of new reference.
	@version 4.5.2.1 new parameter tagColonne.
	@version 4.6 new parameter creation.
	*/
	CSRInstrumentCode(	CSRFitDialog 	*dialog,
						int 			 ERId_Code,
						int 			 ERId_Name=0,
						long			 value=0,
				  const char 			*columnName=kUndefinedField,
				  const char			*tagColonne = kSameAsOracleName,
						bool			creation = false);

	/**Overloaded Constructor 2.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: list, CNb_Code and columnName before initialising the fields fERId_Name and fValue and fCanBeModified.
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRInstrumentCode column.
	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
	@param columnName is the column name of a user table, whose structure includes the two following fields :
		- CODE number(10), security identifier. To link with the Sophis table.
		- NUMERO  number(3), line identifier
	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRInstrumentCode(	CSREditList		*list,
						int 			 CNb_Code,
						int 			 CNb_Name=-1,
						long			 value=0,
				  const char 			*columnName=kUndefinedField,
						bool			 canBeModified=true,
				  const char			*tagColonne = kSameAsOracleName);

	/**Overloaded Constructor 3.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: dialog, ERId_Code and columnName before initialising the fields fERId_Name and fValue.
	Please use this constructor to customize the suggestion list and to improve performance in this case by setting the useAllInstruments parameter to false.
	The parameter columnName is used only in model or when the generic security dialog has been derived.
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRInstrumentCode belongs.
	@param ERId_Code is the relative number of the CSRInstrumentCode.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not. For some cases, it can improve performance.
	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param creation is a boolean to ask for creation  of new reference.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not.
	@version 4.5.2.1 new parameter tagColonne.
	@version 4.6 new parameter creation.
	@version 5.2 new parameter useAllInstruments.
	*/
	CSRInstrumentCode(	CSRFitDialog 	*dialog,
						int 			 ERId_Code,
						bool			 useAllInstruments,
						int 			 ERId_Name=0,
						long			 value=0,
				  const	char 			*columnName=kUndefinedField,
				  const	char			*tagColonne = kSameAsOracleName,
						bool			 creation = false);

    /**Overloaded Constructor 4.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: list, CNb_Code and columnName before initialising the fields fERId_Name and fValue and fCanBeModified.
	Please use this constructor to customize the suggestion list and to improve performance in this case by setting the useAllInstruments parameter to false.
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRInstrumentCode column.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not. For some cases, it can improve performance.
	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
	@param columnName is the column name of a user table, whose structure includes the two following fields :
	- CODE number(10), security identifier. To link with the Sophis table.
	- NUMERO  number(3), line identifier
	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not.
	@version 4.5.2.1 new parameter tagColonne.
	@version 5.2 new parameter useAllInstruments.
	*/
	CSRInstrumentCode(	CSREditList		*list,
						int 			 CNb_Code,
						bool			 useAllInstruments,
						int 			 CNb_Name=-1,
						long			 value=0,
				  const	char 			*columnName=kUndefinedField,
						bool			 canBeModified=true,
				  const	char			*tagColonne = kSameAsOracleName);

	/** Destructor */
	virtual ~CSRInstrumentCode();


	/** Assignes the security code stored in another element, to this CSRInstrumentCode element.
	Method Overloaded.
	The CSRElement parameter must refer to a CSRInstrumentCode object.
	@param a CSRElement reference that must refer to a CSRInstrumentCode object, from which the security code (fValue) is copied.
	
	*/
	virtual void operator = (const CSRElement&);

	/** Assigns the security code stored in another element, to this CSRInstrumentCode element.
	Method Overloaded.
	@param a CSRInstrumentCode object from which the security code (fValue) is copied.
	
	*/
			void operator = (const CSRInstrumentCode&);

	/** 
	Overrides this method if you want some instrument not being displayed.
	@return	true	: if the current instrument can be selected.
			false	: if it cannot be selected.
	By default, always returns true;
	*/
	virtual bool	IsValueValid() const;

	/** Compares the security code stored in another element, with the code of this CSRInstrumentCode element.
	The CSRElement parameter must refer to a CSRInstrumentCode object.
	@param a CSRElement reference to a CSRInstrumentCode object, the security code (fValue) of which is compared with the code in this element.
	@return the result of the arithmetic subtraction of the parameter's code, from the code of this CSRInstrumentCode. Returns -1 if comparison fails to complete.
	
	*/
	virtual int		Compare(const CSRElement&) const;

	/** Sets the name of the security, in the corresponding security name element.
	This method is invoked when the list or dialog is opened, when the CSRInstrumentCode is validated, or simply when
	setting a new security reference\code to the element. Given this security code, it searches for the text box element of the security name and sets the correct name of the security.
	
	*/
	virtual	void	Open();

	/** Obtains the name of the security.
	@param name is a C string to which the name of the security (whose code is in this CSRInstrumentCode element) is copied;
	the size of the buffer must be at least SIZE_INSTRUMENT_NAME.
	
	*/
	virtual void 	GetName(char *name) const;

	/** Validates this CSRInstrumentCode element.
	This method is called when the dialog validates its elements. In turn, this method will call CSRInstrumentCode::Open()
	in order to refresh the name of the security.
	@see CSRInstrumentCode::Open()
	@return true if validation is completed successfully.
	
	*/
	virtual	Boolean	Validation();

	/** Converts the reference of the security to its code (SICOVAM) and sets it to this CSRInstrumentCode element.
	It is mainly called when the user enters information in the element's text box on the screen.
	The method is used in the case when the CSRInstrumentCode element is part of a CSREditList list.
	It takes the text string of the security reference, finds the code, and assigns it to the fValue of this element. Consequently,
	it sets the proper security name in the list's text box identified by fERId_Name.
	@param sourc is the reference of the security, whose code is to be set in this element.
	@param line is the number of the line on the containing CSREditList, which contains the security name (fERId_Name) element.
	@return true if the conversion is completed successfully.
	
	*/
	virtual Boolean	StringToValue(const char *sourc, int line);

	/** Converts the security code (SICOVAM) in the element to the security reference to display on the list.
	The method is used in the case when the CSRInstrumentCode element is part of a CSREditList list.
	This is a callback function, called internally by RISQUE.
	@param dest is a pointer to the string that appears in the cell on the screen.
	@param line is the number of the line on the containing CSREditList, onto which the security reference is sent. (not used in this method, but can be when you override it.)
	
	*/
	virtual void	ValueToString(char *dest, int line) const;

	/** Checks whether the security reference can be modified.
	The method is used in the case when the element is part of a list.
	By default, it returns true.
	Overriding class may return fCanBeModified.
	@see CSRInstrumentCode::fCanBeModified
	@return true if the CSRInstrumentCode allows modification.
	
	*/
	virtual Boolean	CanBeModifiedInAList(void) const;

	/** Sets the code and the displayed reference of the security to the CSRInstrumentCode element.
	It assigns a security code to fValue, and displays the security reference. Then, it updates the security name on the text box element identified by
	fERId_Name in the dialog or list. @see CSRInstrumentCode::Open()
	@param value is a pointer to the security code to set to this element.
	
	*/
	virtual void	SetValue(const void *value);

	/** Obtains the security code in the CSRInstrumentCode element.
	@param value is a pointer to the security code, to which the element's code is copied.
	
	*/
	virtual void	GetValue(void *value) const;

	/** Refreshes the CSRInstrumentCode element.
	This is called when a new security code is set to the element. It also refreshes the reference to the corresponding security name element in the dialog or list.
	
	*/
	virtual void	Update(void) const;

	/** Hides and disconnects the CSRInstrumentCode element in the dialog.
	The element will not be visible on the screen to the user. Consequently, it also hides the corresponding security
	name element in the dialog.
	@see CSRFitDialog::HideElement()
	
	*/
	virtual void	Hide(void) const;

	/** Sets the CSRInstrumentCode element to appear on the dialog back to its initial active status.
	The method performs the inverse of CSRInstrumentCode::Hide(). Consequently, it also shows the corresponding security
	name element in the dialog.
	@see CSRFitDialog::ShowElement()
	
	*/
	virtual void	Show(void) const;
	
	/**
	 * Returns the text currently displayed in the edit field.
	 * @since 5.2
	 */
	virtual void GetText( char* oText ) const;

	virtual bool	CanDropFromDump(USWindow* dumpWind, long nbelem, const long* elem) const;	// internal
	virtual bool	PasteFromDump(USWindow* dumpWind, long nbelem, const long* elem);			// internal

	/**
	* Fills the suggestion list with instruments which start with the given prefix. 
	* It's used every time the keyboard is touched. 
	*
	* @param prefix The prefix used to filter the list.
	*
	* @remarks If you plan to overload this method, don't forget to use Clear() to clear the list with all instruments 
	* except if you had set useAllInstrument to false in the constructor.
	*
	* @see CSRGenericAutoCompletion::CreateSuggestionList(const char* prefix)
	*
	* @since 5.2
	*/
	virtual void CreateSuggestionList(const char* prefix);

	void SetSuggestionHandler(CSSuggestionHandler* suggestionHandler);

	virtual ElemValue* GetComparableValue(int line) const;

protected:
	/** Indicates whether the security reference can be modified.
	By default, this member is not used within CSRInstrumentCode class. However, it can be used as the return value
	of CSRInstrumentCode::CanBeModifiedInAList(), if you override the latter and you wish to block the
	CSRInstrumentCode element.
	@see CSRInstrumentCode::CanBeModifiedInAList()
	
	*/
	bool fCanBeModified ;

	/** Indicates if a reference can be created if the item is in a dialog.
	@since 4.6
	*/
	bool fCreation;	

public:
	virtual short	DonneFiltre(void) const;		// internal
	virtual	int		DonneTypeTri() const;			// internal

	ELEM_COMMON_INTERNALS;


};

SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRInstrumentCode);

class SOPHIS_FIT CSRInterestRateCode : public CSRInstrumentCode
{
	long m_currency;

public:
	CSRInterestRateCode(	CSREditList			*list, 
		int 				CNb_Code);

	CSRInterestRateCode(	CSRFitDialog		*dlg, 
		int 				ref);

	virtual Boolean	StringToValue(const char *sourc, int line);

	virtual void CreateSuggestionList(const char* prefix);

	/// Set a currency filter : if no null, only the interest codes with a matching currency will be in the completion list
	virtual void SetCurrency(long currency);

	typedef long value_type;
};

SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRInterestRateCode);

class SOPHIS_FIT CSRForexSpotCode : public CSRInstrumentCode
{
	long m_currency;

public:
	CSRForexSpotCode(	CSREditList			*list, 
		int 				CNb_Code);

	CSRForexSpotCode(	CSRFitDialog		*dlg, 
		int 				ref);

	//virtual Boolean	StringToValue(const char *sourc, int line);

	virtual void CreateSuggestionList(const char* prefix);

	typedef long value_type;
};

SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRForexSpotCode);

/** Class CSRInstrumentNameWithCode:
*	Derives from CSRInstrumentCode and is used only within a list.
*	The class has been designed to handle a security/instrument code (SICOVAM). However, unlike CSRInstrumentCode that displays
*	the security reference on the text box, this class displays the name of the security in its text box. Therefore, there is
*	no need for the text element in the list for the security name.
*
*	
*/
class SOPHIS_FIT CSRInstrumentNameWithCode : public CSRInstrumentCode
{
public:
	/** Constructor.
	Passes parameters liste, NRC_Code, value and champDansTable to CSRInstrumentCode::CSRInstrumentCode().
	@param list is a pointer to the editable list to which the code column belongs.
	@param NRC_Code is the relative number of the CSRInstrumentNameWithCode column.
	@param value is the default security code set to 0. Used to initialise fValue, where the security code is stored.
	@param champDansTable (known as columnName in base class) is the column name of a user table whose structure includes the two following fields:
		- CODE number(10), security identifier. To link with the Sophis table.
		- NUMERO  number(3), line identifier
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRInstrumentNameWithCode(CSREditList* liste, int NRC_Code, long value=0, const char* champDansTable=kUndefinedField,const char *tagColonne = kSameAsOracleName);

	/** Indicates that the security name column cannot be modified.
	@return false to inform that security name cannot be changed in the list.
	
	*/
	Boolean	CanBeModifiedInAList(void) const;

	/** In addition to the above virtual method this also indicates if the filed could be modified.
	This class derived from CSRGenericAutoCompletion, that's why this method is taken into accaunt too.
	@return false to inform that field is not editable.
	*/

	Boolean MenuCanBeModifiedInAList() const;

	/** Converts the security code (sicovam) in the element to the security name to display on the the list.
	The method is used in the case when the CSRInstrumentNameWithCode element is part of a CSREditList list.
	This is a callback function, called internally by RISQUE.
	@param dest is a pointer to the security name that appears in the cell on the screen.
	@param line is the number of the line on the containing CSREditList, onto which the security name is sent.
	
	*/

	void ValueToString(char* dest, int ligne) const;
};

/** Class CSRThirdPartyCode.
*	Listable class designed to handle a third party's code or reference. The elements stores the code of the
*	third party (in fValue), while the element's text box holds the Reference of the third party.
*	Within the class, there is also the relative number of the element (if it exists) with the name of
*	the same third party.
*
*	
*/
class SOPHIS_FIT CSRThirdPartyCode : public CSRElement {
public:
	/** Overloaded Constructor 1.
	Passes to base class constructor CSRElement::CSRElement() parameters: dialog, ERId_Code and columnName,
	then it initialises the element's fValue with parameter value.
	The parameter columnName is used only in model or when the generic security dialog has been derived
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRThirdPartyCode belongs.
	@param ERId_Code is the relative number of the CSRThirdPartyCode.
	@param ERId_Name is the relative number of the static text element which will hold the name of the third party. Equal to nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new third party code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param canCreate is to specify whether the third party reference on the text box can be modified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRThirdPartyCode(	CSRFitDialog 	*dialog,
						int 			 ERId_Code,
						int 			 ERId_Name=0,
						long			 value=0,
				  const char 			*columnName = kUndefinedField,
						bool			 canCreate = false,
					const char			*tagColonne = kSameAsOracleName);

	/** Overloaded Constructor 2.
	Passes to base class constructor CSRElement::CSRElement() parameters: list, CNb_Code and columnName,
	then it initialises the element's fValue with parameter value.
	The parameter columnName is used only in model or when the generic security dialog has been derived
	See "How to derive CSRInstrumentDialog".
	@param list is a pointer to the list to which the CSRThirdPartyCode belongs.
	@param CNb_Code is the relative number of the CSRThirdPartyCode.
	@param CNb_Name is the relative number of the static text element which will hold the name of the third party. Equal to nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new third party code.
	@param columnName is the column name of a user table which structure possesses at least the two following fields :
		- CODE number(10), security identifier. To link with the Sophis table.
		- NUMERO  number(3), line identifier
	@param canCreate is to specify whether the third party reference on the text box can be modified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRThirdPartyCode(	CSREditList		*list,
						int 			 CNb_Code,
						int 			 CNb_Name=-1,
						long			 value=0,
				  const char 			*columnName = kUndefinedField,
						bool			 canCreate = false,
					const char			*tagColonne = kSameAsOracleName);

	/** Assigns the third party code stored in another element, to this CSRThirdPartyCode element.
	Method Overloaded.
	The CSRElement parameter must refer to a CSRThirdPartyCode object.
	@param a CSRElement reference that must refer to a CSRThirdPartyCode object, from which the third party code (fValue) is copied.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	virtual void operator = (const CSRElement&);

	/** Assigns the third party code stored in another element, to this CSRThirdPartyCode element.
	Method Overloaded.
	@param a CSRThirdPartyCode object from which the third party code (fValue) is copied.
	
	*/
			void operator = (const CSRThirdPartyCode&);

	/** Compares the third party code stored in another element, with the code of this CSRThirdPartyCode element.
	The CSRElement parameter must refer to a CSRThirdPartyCode object.
	@param a CSRElement reference to a CSRThirdPartyCode object, the third party code (fValue) of which is compared with the code in this element.
	@return the result of the arithmetic subtraction of the parameter's code, from the code of this CSRThirdPartyCode. Returns -1 if comparison fails to complete.
	
	*/
	virtual int		Compare(const CSRElement&) const;

	/** Sets the name of the third party, in the corresponding third party name element.
	This method is invoked when the list or dialog is opened, when the CSRThirdPartyCode is validated, or simply when
	setting a new third party reference\code to the element. Given this code, it searches for the text box element of the third party name
	and sets the correct name of the third party.
	
	*/
	virtual	void	Open();

	/** Obtains the name of the third party.
	This is required by CSRThirdPartyCode::Open(), in order to set the name of the portfolio in element CSRThirdPartyCode::fERId_Name.
	@see CSRThirdPartyCode::Open()
	@param name is a C string to which the name of the third party (whose code is in this CSRThirdPartyCode element) is copied.
	
	*/
	virtual void 	GetName(char *name) const;

	/** Obtains the code of the third party given its reference.
	@param sourc is the reference of third party of which the code is sought.
	@return the code of the third party with reference 'sourc'.
	
	*/
	virtual	long	GetCode(const char *sourc) const;

	/** Validates this CSRThirdPartyCode element.
	This method is called when the dialog validates its elements. In turn, this method will call CSRThirdPartyCode::Open()
	in order to refresh the name of the security.
	@see CSRThirdPartyCode::Open()
	@return true if validation is completed successfully.
	
	*/
	virtual	Boolean	Validation();

	/** Converts the reference of the third party to its code (SICOVAM), and sets it to this CSRThirdPartyCode element.
	It is mainly called when the user enters information in the element's text box on the screen.
	The method is used in the case when the CSRThirdPartyCode element is part of a CSREditList list.
	It takes the text string of the third party reference, finds the code, and assigns it to the fValue of this element. Consequently,
	it sets the proper third party name in the list's text box identified by fERId_Name.
	@param sourc is the reference of the third party, whose code is to be set in this element.
	@param line is the number of the line on the containing CSREditList, which contains the third party name (fERId_Name) element.
	@return true if the conversion is completed successfully.
	
	*/
	virtual Boolean	StringToValue(const char *sourc, int line);

	/** Converts the third party code (SICOVAM) in the element to the third party reference to display on the the list.
	The method is used in the case when the CSRThirdPartyCode element is part of a CSREditList list.
	This is a callback function, called internally by RISQUE.
	@param dest is a pointer to the string that appears in the cell on the screen.
	@param line is the number of the line on the containing CSREditList, onto which the third party reference is sent. (not used in this method, but can be  when you override it.)
	
	*/
	virtual void	ValueToString(char *dest, int line) const;

	/** Sets the code and the displayed reference of the third party to the CSRThirdPartyCode element.
	It assigns a security code to fValue. Then, it updates the third party name on the text box element identified by
	fERId_Name in the dialog or list. @see CSRThirdPartyCode::Open().
	@param value is a pointer to the third party code to set to this element.
	
	*/
	virtual void	SetValue(const void *value);

	/** Obtains the third party code in the CSRThirdPartyCode element.
	@param value is a pointer to the third party code to which element's code is copied.
	
	*/
	virtual void	GetValue(void *value) const;

	/** Checks whether the third party reference can be modified.
	The method is used when the element is part of a list.
	By default, it returns true.
	Overriding class may return fCanBeModified.
	@see CSRThirdPartyCode::fCanCreate
	@return true if the CSRThirdPartyCode allows modification.
	
	*/
	virtual Boolean	CanBeModifiedInAList(void) const;

protected:
	/** Stores the third party code (also know as SICOVAM).
	Given this, the reference of the third party can be displayed on the dialog's or list's text box, and likewise
	with the name of the third party on another text box.
	
	*/
	long	fValue;

	/** The relative ID of the third party name element.
	The ID of the element handling the name of the third party whose code is stored in fValue.
	In a dialog, if such third party name element does not exist, then fERId_Name is equal to 0. In the case of a list,
	if the element doesn't exist, fERId_Name is equal to -1.
	
	*/
	int		fERId_Name;

	/** Indicates whether the third party reference on the text box can be modified.
	By default, this member is not used in the base class. But if method CanBeModifiedInAList() is overridden,
	fCanCreate can be the return value.
	@see CSRThirdPartyCode::CanBeModifiedInAList()
	
	*/
	bool	fCanCreate;

public:
	virtual short	DonneFiltre(void) const;		// internal
	virtual	int		DonneTypeTri() const;			// internal

	ELEM_COMMON_INTERNALS;

};

/** Class CSRPortfolioCode.
*	Derives from CSRThirdPartyCode, the class handles the code of a portfolio, to display the reference of the portfolio
*	in the element's text box. The portfolio code of CSRPortfolioCode can be used to
*	display the name of the portfolio in a static text box of an element that is on the same dialog or list.
*
*	
*/
class SOPHIS_FIT CSRPortfolioCode : public CSRThirdPartyCode {
public:
	/** Overloaded Constructor 1.
	Passes all parameters to base class constructor CSRThirdPartyCode::CSRThirdPartyCode().
	@param dialog is a pointer to the dialog to which the CSRPortfolioCode belongs.
	@param ERId_Code is the relative number of the CSRPortfolioCode.
	@param ERId_Name is the relative number of the static text element which will hold the name of the portfolio. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new portfolio code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRPortfolioCode(	CSRFitDialog 	*dialog,
						int 			 ERId_Code,
						int 			 ERId_Name=0,
						long			 value=0,
				  const char 			*columnName = kUndefinedField,
				  const char			*tagColonne = kSameAsOracleName);

	/** Overloaded Constructor 2.
	Passes all parameters to base class constructor CSRThirdPartyCode::CSRThirdPartyCode().
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRPortfolioCode column.
	@param CNb_Name is the relative number of the portfolio name column. It is set to CSRThirdPartyCode::fERId_Name. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the portfolio code is stored.
	@param columnName is the column name of a user table which structure possesses at least the two following fields:
		- CODE number(10), security identifier. To link with the Sophis table.
		- NUMERO  number(3), line identifier
	@param fullPath is to indicate that the full path of the portfolio name is to be displayed on th list. @see CSRPortfolioCode::fFullPath.
	@param readOnly is to specify whether the portfolio reference on the text box can be modified. It is assigned to fReadOnly.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRPortfolioCode(	CSREditList		*list,
						int 			 CNb_Code,
						int 			 CNb_Name=-1,
						long			 value=0,
				  const char 			*columnName = kUndefinedField,
						bool			 fullPath=false,
						bool			 readOnly=false,
					const char			*tagColonne = kSameAsOracleName);

	/** Assignes the portfolio code stored in another element, to this CSRPortfolioCode element.
	Method Overloaded.
	@param a CSRPortfolioCode object from which the portfolio code (fValue) is copied.
	
	*/
			void operator = (const CSRPortfolioCode&);

	/** Obtains the name of the portfolio.
	This is required by CSRThirdPartyCode::Open(), in order to set the name of the portfolio in element CSRThirdPartyCode::fERId_Name.
	@see CSRThirdPartyCode::Open()
	Depending on fFullPath, the name retrieved may include the whole path from the root portfolio to the element's portfolio.
	@see CSRPortfolioCode::fFullPath
	@param name is a C string to which the name of the third party (whose code is in this CSRThirdPartyCode element) is copied.
	
	*/
	void 	GetName(char *name) const;

	/** Obtains the code of the portfolio given its reference.
	This method is used by CSRThirdPartyCode::StringToValue() in order to set a value to fValue given the reference.
	@param sourc is the reference of portfolio of which the code is sought.
	@return the code of the portfolio with reference 'sourc'
	
	*/
	long	GetCode(const char *sourc) const;

	/** Checks whether the portfolio reference can be modified.
	The method is used in the case when the element is part of a list.
	If the full path name is specified for the portfolio name element (CSRThirdPartyCode::fERId_Name), then the
	CSRPortfolioCode does permit modification. It returns false if CSRPortfolioCode::fReadOnly is true.
	@return true if the CSRPortfolioCode allows modification.
	
	*/
	Boolean CanBeModifiedInAList() const;

	/** Imposes whether the CSRPortfolioCode element can be modified.
	@param yesno is true if it is intended to disallow modification of the portfolio reference.
	
	*/
	void	SetReadOnly(bool yesno=true) { fReadOnly = yesno; }

	/** Checks whether the CSRPortfolioCode element can be modified.
	@return true if modification of the portfolio reference is allowed.
	
	*/
	bool	IsReadOnly() const { return fReadOnly; }

	/** Imposes whether the full path to the portfolio name must be displayed.
	@see fFullPath
	@param yesno is true to specify that the full path to the portfolio name is displayed.
	
	*/
	void	SetFullPath(bool yesno=true) { fFullPath = yesno; }

	/** Checks whether the full path to the portfolio name is to be displayed.
	@see fFullPath
	@return true to indicate that the full path to the portfolio name is displayed.
	
	*/
	bool	IsFullPath() const { return fFullPath; }

protected:
	/** Indicates whether to display the full path to the portfolio name.
	If this is true, in the portfolio name element identified by CSRThirdPartyCode::fERId_Name, the string will include the
	name and the full path from the root portfolio. If it is false, it will just display the name of the portfolio.
	
	*/
	bool fFullPath;

	/** Indicates whether the portfolio reference on CSRPortfolioCode element can be modified.
	If it is true, the reference cannot be modified.
	
	*/
	bool fReadOnly;
};


class SOPHIS_FIT CSRIssuerCode : public CSRInstrumentCode
{
public:
	/**Overloaded Constructor 1.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: dialog, ERId_Code and columnName before initialising the fields fERId_Name and fValue.
	The parameter columnName is used only in model or when the generic security dialog has been derived
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRInstrumentCode belongs.
	@param ERId_Code is the relative number of the CSRInstrumentCode.
	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param creation is a boolean to ask for creation  of new reference.
	@version 4.5.2.1 new parameter tagColonne.
	@version 4.6 new parameter creation.
	*/
	CSRIssuerCode(	CSRFitDialog 	*dialog,
					int 			 ERId_Code,
					int 			 ERId_Name=0,
					long			 value=0,
					const char 			*columnName=kUndefinedField,
					const char			*tagColonne = kSameAsOracleName,
					bool			creation = false);

	/**Overloaded Constructor 2.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: list, CNb_Code and columnName before initialising the fields fERId_Name and fValue and fCanBeModified.
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRInstrumentCode column.
	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
	@param columnName is the column name of a user table, whose structure includes the two following fields :
	- CODE number(10), security identifier. To link with the Sophis table.
	- NUMERO  number(3), line identifier
	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRIssuerCode(	CSREditList		*list,
					int 			 CNb_Code,
					int 			 CNb_Name=-1,
					long			 value=0,
					const char 			*columnName=kUndefinedField,
					bool			 canBeModified=true,
					const char			*tagColonne = kSameAsOracleName);


	/** 
	Overrides this method if you want some instrument not being displayed.
	@return	true	: if the current instrument can be selected.
	false	: if it cannot be selected.
	By default, always returns true;
	*/
	virtual bool	IsValueValid() const;

	/**
	* Fills the suggestion list.
	*
	* @param prefix The string entered during typing.
	* @remarks If you plan to overload this method, don't forget to use Clear() to clear the list with all instruments.
	* @since 5.2
	*/
	virtual void CreateSuggestionList(const char* prefix);
};

SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRIssuerCode);

class SOPHIS_FIT CSRUnitAutoCompletion : public CSRGenericAutoCompletion {
public:
	/**Overloaded Constructor 1.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: dialog, ERId_Code and columnName before initialising the fields fERId_Name and fValue.
	The parameter columnName is used only in model or when the generic security dialog has been derived
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRInstrumentCode belongs.
	@param ERId_Code is the relative number of the CSRInstrumentCode.
	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param creation is a boolean to ask for creation  of new reference.
	@version 4.5.2.1 new parameter tagColonne.
	@version 4.6 new parameter creation.
	*/
	CSRUnitAutoCompletion(	CSRFitDialog 	*dialog,
		int 			 ERId_Code,
		int 			 ERId_Name=0,
		long			 value=0,
		const char 			*columnName=kUndefinedField,
		const char			*tagColonne = kSameAsOracleName,
		bool			creation = false);

	/**Overloaded Constructor 2.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: list, CNb_Code and columnName before initialising the fields fERId_Name and fValue and fCanBeModified.
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRInstrumentCode column.
	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
	@param columnName is the column name of a user table, whose structure includes the two following fields :
	- CODE number(10), security identifier. To link with the Sophis table.
	- NUMERO  number(3), line identifier
	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRUnitAutoCompletion(	CSREditList		*list,
		int 			 CNb_Code,
		int 			 CNb_Name=-1,
		long			 value=0,
		const char 			*columnName=kUndefinedField,
		bool			 canBeModified=true,
		const char			*tagColonne = kSameAsOracleName);

	/**Overloaded Constructor 3.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: dialog, ERId_Code and columnName before initialising the fields fERId_Name and fValue.
	Please use this constructor to customize the suggestion list and to improve performance in this case by setting the useAllInstruments parameter to false.
	The parameter columnName is used only in model or when the generic security dialog has been derived.
	See "How to derive CSRInstrumentDialog".
	@param dialog is a pointer to the dialog to which the CSRInstrumentCode belongs.
	@param ERId_Code is the relative number of the CSRInstrumentCode.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not. For some cases, it can improve performance.
	@param ERId_Name is the relative number of the static text element which will hold the name of the security. Equal nvZero when there is no such element on the dialog.
	@param value is the default fValue set to 0. To initialise fValue if columnName is nvZero or when creating a new security code.
	@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
	@param tagColonne is the section tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param creation is a boolean to ask for creation  of new reference.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not.
	@version 4.5.2.1 new parameter tagColonne.
	@version 4.6 new parameter creation.
	@version 5.2 new parameter useAllInstruments.
	*/
	CSRUnitAutoCompletion(	CSRFitDialog 	*dialog,
		int 			 ERId_Code,
		bool			 useAllInstruments,
		int 			 ERId_Name=0,
		long			 value=0,
		const	char 			*columnName=kUndefinedField,
		const	char			*tagColonne = kSameAsOracleName,
		bool			 creation = false);

	/**Overloaded Constructor 4.
	The constructor CSRInstrumentCode::CSRInstrumentCode() passes on to the base class constructor CSRElement::CSRElement()
	the parameters: list, CNb_Code and columnName before initialising the fields fERId_Name and fValue and fCanBeModified.
	Please use this constructor to customize the suggestion list and to improve performance in this case by setting the useAllInstruments parameter to false.
	@param list is a pointer to the editable list to which the code column belongs.
	@param CNb_Code is the relative number of the CSRInstrumentCode column.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not. For some cases, it can improve performance.
	@param CNb_Name is the relative number of the security name column. If nvZero, no wording column is associated.
	@param value is the default fValue set to 0. Used to initialise fValue, where the security code is stored.
	@param columnName is the column name of a user table, whose structure includes the two following fields :
	- CODE number(10), security identifier. To link with the Sophis table.
	- NUMERO  number(3), line identifier
	@param canBeModified is a boolean that states whether the security code can be changed. The parameter's value is assigned to fCanBeModified.
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@param useAllInstruments is a value indicating whether the list of all instruments is created or not.
	@version 4.5.2.1 new parameter tagColonne.
	@version 5.2 new parameter useAllInstruments.
	*/
	CSRUnitAutoCompletion(	CSREditList		*list,
		int 			 CNb_Code,
		bool			 useAllInstruments,
		int 			 CNb_Name=-1,
		long			 value=0,
		const	char 			*columnName=kUndefinedField,
		bool			 canBeModified=true,
		const	char			*tagColonne = kSameAsOracleName);

	/** Destructor */
	virtual ~CSRUnitAutoCompletion();


	/** Assignes the security code stored in another element, to this CSRInstrumentCode element.
	Method Overloaded.
	The CSRElement parameter must refer to a CSRInstrumentCode object.
	@param a CSRElement reference that must refer to a CSRInstrumentCode object, from which the security code (fValue) is copied.

	*/
	virtual void operator = (const CSRElement&);

	/** Assigns the security code stored in another element, to this CSRInstrumentCode element.
	Method Overloaded.
	@param a CSRInstrumentCode object from which the security code (fValue) is copied.

	*/
	void operator = (const CSRUnitAutoCompletion&);

	/** 
	Overrides this method if you want some instrument not being displayed.
	@return	true	: if the current instrument can be selected.
	false	: if it cannot be selected.
	By default, always returns true;
	*/
	virtual bool	IsValueValid() const;

	/** Compares the security code stored in another element, with the code of this CSRInstrumentCode element.
	The CSRElement parameter must refer to a CSRInstrumentCode object.
	@param a CSRElement reference to a CSRInstrumentCode object, the security code (fValue) of which is compared with the code in this element.
	@return the result of the arithmetic subtraction of the parameter's code, from the code of this CSRInstrumentCode. Returns -1 if comparison fails to complete.

	*/
	virtual int		Compare(const CSRElement&) const;

	/** Sets the name of the security, in the corresponding security name element.
	This method is invoked when the list or dialog is opened, when the CSRInstrumentCode is validated, or simply when
	setting a new security reference\code to the element. Given this security code, it searches for the text box element of the security name and sets the correct name of the security.

	*/
	virtual	void	Open();

	/** Obtains the name of the security.
	@param name is a C string to which the name of the security (whose code is in this CSRInstrumentCode element) is copied;
	the size of the buffer must be at least SIZE_INSTRUMENT_NAME.

	*/
	virtual void 	GetName(char *name) const;

	/** Validates this CSRInstrumentCode element.
	This method is called when the dialog validates its elements. In turn, this method will call CSRInstrumentCode::Open()
	in order to refresh the name of the security.
	@see CSRInstrumentCode::Open()
	@return true if validation is completed successfully.

	*/
	virtual	Boolean	Validation();

	/** Converts the reference of the security to its code (SICOVAM) and sets it to this CSRInstrumentCode element.
	It is mainly called when the user enters information in the element's text box on the screen.
	The method is used in the case when the CSRInstrumentCode element is part of a CSREditList list.
	It takes the text string of the security reference, finds the code, and assigns it to the fValue of this element. Consequently,
	it sets the proper security name in the list's text box identified by fERId_Name.
	@param sourc is the reference of the security, whose code is to be set in this element.
	@param line is the number of the line on the containing CSREditList, which contains the security name (fERId_Name) element.
	@return true if the conversion is completed successfully.

	*/
	virtual Boolean	StringToValue(const char *sourc, int line);

	/** Converts the security code (SICOVAM) in the element to the security reference to display on the list.
	The method is used in the case when the CSRInstrumentCode element is part of a CSREditList list.
	This is a callback function, called internally by RISQUE.
	@param dest is a pointer to the string that appears in the cell on the screen.
	@param line is the number of the line on the containing CSREditList, onto which the security reference is sent. (not used in this method, but can be when you override it.)

	*/
	virtual void	ValueToString(char *dest, int line) const;

	/** Checks whether the security reference can be modified.
	The method is used in the case when the element is part of a list.
	By default, it returns true.
	Overriding class may return fCanBeModified.
	@see CSRInstrumentCode::fCanBeModified
	@return true if the CSRInstrumentCode allows modification.

	*/
	virtual Boolean	CanBeModifiedInAList(void) const;

	/** Sets the code and the displayed reference of the security to the CSRInstrumentCode element.
	It assigns a security code to fValue, and displays the security reference. Then, it updates the security name on the text box element identified by
	fERId_Name in the dialog or list. @see CSRInstrumentCode::Open()
	@param value is a pointer to the security code to set to this element.

	*/
	virtual void	SetValue(const void *value);

	/** Obtains the security code in the CSRInstrumentCode element.
	@param value is a pointer to the security code, to which the element's code is copied.

	*/
	virtual void	GetValue(void *value) const;

	/** Refreshes the CSRInstrumentCode element.
	This is called when a new security code is set to the element. It also refreshes the reference to the corresponding security name element in the dialog or list.

	*/
	virtual void	Update(void) const;

	/** Hides and disconnects the CSRInstrumentCode element in the dialog.
	The element will not be visible on the screen to the user. Consequently, it also hides the corresponding security
	name element in the dialog.
	@see CSRFitDialog::HideElement()

	*/
	virtual void	Hide(void) const;

	/** Sets the CSRInstrumentCode element to appear on the dialog back to its initial active status.
	The method performs the inverse of CSRInstrumentCode::Hide(). Consequently, it also shows the corresponding security
	name element in the dialog.
	@see CSRFitDialog::ShowElement()

	*/
	virtual void	Show(void) const;

	/**
	* Returns the text currently displayed in the edit field.
	* @since 5.2
	*/
	virtual void GetText( char* oText ) const;

	virtual bool	CanDropFromDump(USWindow* dumpWind, long nbelem, const long* elem) const;	// internal
	virtual bool	PasteFromDump(USWindow* dumpWind, long nbelem, const long* elem);			// internal

	/**
	* Fills the suggestion list with instruments which start with the given prefix. 
	* It's used every time the keyboard is touched. 
	*
	* @param prefix The prefix used to filter the list.
	*
	* @remarks If you plan to overload this method, don't forget to use Clear() to clear the list with all instruments 
	* except if you had set useAllInstrument to false in the constructor.
	*
	* @since 5.2
	*/
	virtual void CreateSuggestionList(const char* prefix);
	virtual void CreateSuggestionList();

	void SetSuggestionHandler(CSSuggestionHandler* suggestionHandler);

	bool GetCreatedInOldDialog();

protected:
	/** Indicates whether the security reference can be modified.
	By default, this member is not used within CSRInstrumentCode class. However, it can be used as the return value
	of CSRInstrumentCode::CanBeModifiedInAList(), if you override the latter and you wish to block the
	CSRInstrumentCode element.
	@see CSRInstrumentCode::CanBeModifiedInAList()

	*/
	bool fCanBeModified ;

	/** Indicates if a reference can be created if the item is in a dialog.
	@since 4.6
	*/
	bool fCreation;	
	bool fCreatedInOldDialog;

public:
	virtual short	DonneFiltre(void) const;		// internal
	virtual	int		DonneTypeTri() const;			// internal
	
	//This is method id used in the "old" dialogs.
	static void Initialisation(TDlog* dlog, int &numero, int nAbsoluteId,long* lValue);
	ELEM_COMMON_INTERNALS;

};



	}
}

SPH_EPILOG
#endif
