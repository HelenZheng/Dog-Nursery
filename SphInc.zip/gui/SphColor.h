
/*
 	File:		SphColor.h

 	Contains:	Class for the handling colors in gui

 	Copyright:	� 1996-2003 Sophis.
*/

/*! \file SphColor.h
	\brief Class for the handling of colours in a GUI
*/

#pragma once

#ifndef SPH_COLOR_H_
#define SPH_COLOR_H_

#include "SphInc/SphMacros.h"


SPH_PROLOG
namespace sophis	{
	namespace gui	{

		/** Structure defining a colour using a mix of green, blue and red.
		The values for colours are between 0 and 65335. It is used to define a colour
		when drawing a user column.
		*/
		struct SSRgbColor
		{
			unsigned short red;
			unsigned short green;
			unsigned short blue;
			bool operator==(const struct SSRgbColor &c) const
			{
				return (red==c.red) && (blue==c.blue) && (green==c.green);
			}
		};

		/** Define standard colour.
		@see SSRgbColor
		*/
		class RgbColorMgr
		{
		public:
			static SSRgbColor GetRgb(unsigned short red, unsigned short green, unsigned short blue) { SSRgbColor c; c.red = red; c.green = green; c.blue = blue; return c; }
			static SSRgbColor GetRed() { return GetRgb(65335, 0, 0); }
			static SSRgbColor GetGreen() { return GetRgb(0, 65335, 0); }
			static SSRgbColor GetBlue() { return GetRgb(0, 0, 65335); }
			static SSRgbColor GetBlack() { return GetRgb(0, 0, 0); }
			static SSRgbColor GetWhite() { return GetRgb(65335, 65335, 65335); }
			static SSRgbColor GetYellow() { return GetRgb(65335, 65335, 0); }
			static SSRgbColor GetCyan() { return GetRgb(0, 65335, 65335); }
			static SSRgbColor GetMagenta() { return GetRgb(65335, 0, 65335); }
			static SSRgbColor GetGrey() {return GetRgb(32767, 32767, 32767);}

			/** Find the user preference for the Bid column.
			@since 4.4.1.2
			*/
			static SOPHIS_FIT SSRgbColor GetBid();

			/** Find the user preference for the Ask column.
			@since 4.4.1.2
			*/
			static SOPHIS_FIT SSRgbColor GetAsk();

		};
	}
}

SPH_EPILOG
#endif
