#pragma once
#ifndef _SphColumnConfigurationMgr_H_
#define _SphColumnConfigurationMgr_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis {
	namespace gui {

/** 
 * ISRColumnConfigurationMgr interface is used to support column configuration tool bar in a dialog window.
 * @version 5.3.6
 */
class ISRColumnConfigurationMgr
{
public:
	/** Called by dialog. Implementation should return the resource id*/
	virtual long GetResourceId() = 0;
	/** Called by dialog. Implementation should return current selection*/
	virtual long GetConfigId() = 0;
	/** Called by tool bar when user chooses new configuration*/
	virtual void OnChangeColumns(long configId) = 0;
};

	} // gui
} // sophis
SPH_EPILOG
#endif // _SphColumnConfigurationMgr_H_