#pragma once
#ifndef _SphColumnExplDialog_H_
#define _SphColumnExplDialog_H_

#include "SphInc/gui/SphDialog.h"			// CSRFitDialog
#include "SphInc/gui/SphEditList.h"			// CSREditList
#include "SphInc/gui/SphColumnConfigurationMgr.h"	// ISRColumnConfigurationMgr

class CSRSelectColumn;
struct SSCellStyle;
union SSCellValue;
struct TCol;

SPH_PROLOG
namespace sophis {
	namespace gui {

class CSRColumnExplDialog;

/**
 * Column explanation list with support of columns configuration.
 * This class acts as bridge between tradition edit list and custom edit list with custom column selection.
 * The method LoadLine is not defined because it depends on the actual implementation and type of columns.
 *
 * The dialog can operate both via CSRSelectColumn interface and via TXT resources.
 *
 * @version 5.3.6
 */
class SOPHIS_INTERFACE CSRColumnExplList : public CSREditList
{
public:

	/** Constructor.
	 * @param dialog A pointer to the dialog to which the list belongs.
	 * @param ERId_List The relative number of the editable list as an element.
	 * @param selectColumn Column selector, defines what columns to choose.
	 * @param defaultColumns Default columns, useful for the first run when when no column configuration exists.
	 */
	CSRColumnExplList(CSRColumnExplDialog *dialog, int ERId_List, CSRSelectColumn* selectColumn = 0, _STL::vector<int>& defaultColumns = _STL::vector<int>());
	virtual ~CSRColumnExplList();

	/// See {@link CSREditList::LoadLine}
	virtual Boolean LoadLine(int lineNumber) const = 0;
	/// See {@link CSREditList::SaveLine}
	virtual void SaveLine(int lineNumber) {};
	/// See {@link CSREditList::CanSort}
	virtual bool CanSort(void) {return false;}
	/// See {@link CSREditList::RemoveLine}
	virtual void RemoveLine(int lineNumber);
	/// See {@link CSREditList::DoubleClick}
	virtual void DoubleClick(int lineNumber);
	/// See {@link CSREditList::CommandErase}
	virtual void CommandErase(void);
	/// See {@link CSREditList::Sort}
	virtual void Sort(int NRC_Colonne, Boolean croissant) {}
	/// See {@link CSREditList::GetCellStyle}
	virtual void GetCellStyle(long lineNumber, long colNumber, SSListCellStyle* state);

	/** Calls InitData() and initialises the columns configuration. */
	void Init();

	/** Invoked by the dialog when columns configuration is changed. */
	virtual void OnChangeColumns(long configId);

	/** Returns dialog containing the list. */
	inline CSRColumnExplDialog* GetColumnExplDialog() const { return fDlog; }

protected:

	/** Must initialise the list data, all the standard list components like fSize, fListeValuer, etc. */
	virtual void InitData() = 0;

	/** Must initialise given column element.
	 * @param column Column to be initialised.
	 * @param elemId Column element id.
	 * @param width Column width.
	 */
	virtual void CreateColumnElement(SSColumn *column, int elemId, int width) = 0;

	/** Specifies style for given cell.
	 * @param lineNumber Line number.
	 * @param elemId Column element id.
	 * @param style Style object which must be filled for style->style and style->color. */
	virtual void GetStyle(int lineNumber, int elemId, SSCellStyle *style) const {}

	/** TXT resource id for columns. Must overridden if not using CSRSelectColumn. */
	virtual int GetTxtResourceID() const { return 0; }
	/** ID for columns configuration storage. Must be overridden if not using CSRSelectColumn. */
	virtual long GetResourceID() const;
	/** May be overridden for additional columns setup. */
	virtual void UpdateColumns(TCol ** hCol);
	/** May be overridden for additional columns setup. */
	virtual void InitColumns();
	/** May be overridden to specify alignment for given column (default implementation queries GetStyle with lineNumber set to -1. */
	virtual eAlignmentType GetColumnAlignment(int elemId) const;


	_STL::string GetColName(int elemId) const;
	TCol** DialogSetOfColumn(long& colId);
	long GetCurrentConfigId();
	void LoadColumnWidths();
	void UpdateColumnWidths();
	void SaveColumnWidths();
	int GetColumnWidth(int id);

	CSRColumnExplDialog* fDlog;
	CSRSelectColumn* fSelectColumn;
	_STL::vector<int> fDefaultColumns;
	_STL::map<int, int> fColumnWidths;
	_STL::map<int, int> fDefaultWidths;

	friend class CSRColumnExplDialog;
};


/**
 * Column explanation list with support of columns configuration.
 * The list is based on handling abstract line objects and operating based on SSCellValue and SSCellStyle concepts.
 * @version 5.3.6
 */
class SOPHIS_INTERFACE CSRLineDataExplList : public CSRColumnExplList
{
public:
	/** Line is just a pointer (to the result object). */
	struct LineData {
		LineData() : fPtr(0) {}
		LineData(const void *ptr) : fPtr(ptr) {}
		void operator = (const void *ptr) { fPtr = ptr; }
		const void* operator->() const { return fPtr; }
		const void* operator*() const { return fPtr; }
	private:
		LineData(const LineData&) {}
		const void *fPtr;
	};

	CSRLineDataExplList(CSRColumnExplDialog *dialog, int ERId_List, CSRSelectColumn* selectColumn = 0, _STL::vector<int>& defaultColumns = _STL::vector<int>());

	/// See {@link CSREditList::LoadLine}
	virtual Boolean LoadLine(int lineNumber) const;
	/// See {@link CSREditList::RemoveLine}
	virtual void RemoveLine(int lineNumber);
	/// See {@link CSREditList::DoubleClick}
	virtual void DoubleClick(int lineNumber);

	/** Must populate cell style and value. */
	virtual void GetCell(int lineNumber, int elemId, SSCellValue *value, SSCellStyle *style) const = 0;

protected:
	/// See {@link CSRColumnExplList::InitData}
	virtual void InitData();
	/// See {@link CSRColumnExplList::CreateColumnElement}
	virtual void CreateColumnElement(SSColumn *column, int index, int width);
	/// See {@link CSRColumnExplList::GetStyle}
	virtual void GetStyle(int lineNumber, int elemId, SSCellStyle *style) const { GetCell(lineNumber, elemId, 0, style); }

	/** Adds one line to the list. */
	void AddLine(const void *ptr);
	/** Adds several lines to the list. */
	void AddLines(_STL::vector<const void*>& ptrList);
};


/**
 * Interface to create desired implementation of column explanation dialog.
 * @version 5.3.6
 */
class ISRColumnExplCreator
{
public:
	virtual CSRColumnExplDialog* new_ColumnExplDialog() = 0;
	virtual CSRUserEditInfo* new_UserEditInfo() = 0;
};

/**
 * Dialog supporting Column result explanation list.
 * @version 5.3.6
 */
class SOPHIS_INTERFACE CSRColumnExplDialog : public CSRFitDialog, public ISRColumnConfigurationMgr
{
protected:
	CSRColumnExplDialog();

public:
	static void ColumnExplDialog(ISRColumnExplCreator& creator);
	virtual ~CSRColumnExplDialog();

	/** Must return instance of desired list implementation. */
	virtual CSRColumnExplList* new_ColumnExplList() = 0;
	/** Must return title of the dialog. */
	virtual _STL::string GetColumnExplTitle() = 0;

	/** Called to see if line can be removed from the list.
	 * Default is no deletion.
	 * @param lineNumber Line index in the list.
	 * @param ptr Line data information (if any).
	 * @return true to enable line deletion, false otherwise (no deletion).
	 */
	virtual bool RemoveLine(int lineNumber, const void *ptr = 0) { return false; }

	/** Called to process double-click on the line.
	 * Default do nothing.
	 * @param ptr Line data information (if any).
	 * @param lineNumber Line index in the list.
	 */
	virtual void DoubleClick(int lineNumber, const void *ptr = 0) { return; }

	/** Initialises new dialog. */
	virtual void Init(ISRColumnExplCreator& creator);
	/** Called if the dialog is already open to update if needed to. */
	virtual void InitAlreadyOpen(ISRColumnExplCreator& creator) {}
	
	/// See {@link CSRFitDialog::Open}
	virtual void Open();

	// toolbar and column configuration handling
	virtual void OnToolbar(TDlog *pDlg, int nID);
	virtual	Boolean	Close(void);

	// ISRColumnConfigurationMgr implementation
	virtual long GetResourceId();
	virtual long GetConfigId();
	virtual void OnChangeColumns(long configId);

protected:
	CSRColumnExplList* fList;
};

	} // gui
} // sophis
SPH_EPILOG
#endif // _SphColumnExplDialog_H_
