/*! \file SphConfirmationDialog.h
	\brief Prevent display of confirmation dialog when saving an instrument
*/

#pragma once
#ifndef _SphConfirmationDialog_H_
#define _SphConfirmationDialog_H_


#include "SphInc/tools/SphAlgorithm.h"

#ifndef SOPHIS_INTERFACE
#	define SOPHIS_INTERFACE
#endif
SPH_PROLOG

class SOPHIS_INTERFACE SaveConfirmationOverloader : public sophis::tools::CSRAssignement<int>
{
public:

	/** Give a possibility to disable the confirmation dialogs
	It uses the design pattern of a smart pointer : the disabling is effective until the destruction of the local object created on the stack
	usage is for example:
	{ // containing block begin
	SaveConfirmationOverloader tmpDisable; // creation of the smart object, which disabled the confirmation dialog
	... // during all processing, the confirmation dialog is disabled
	} // here the confirmation dialog will be restored. This applies as well to "return" or "exception" inside the block.
	It is also possible to re-enable the confirmation dialog during a sub-part of the block by creating another object with parameter "disable = false"
	*/

	SaveConfirmationOverloader(bool disable = true);
};

SPH_EPILOG

#endif // _SphConfirmationDialog_H_
