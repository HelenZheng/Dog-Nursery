/*
File:		SphCorrelationGUI.h

Contains:	Class for the handling of correlation dialogs

Copyright:	(c) 2008 Sophis.

*/

/*! \file SphCorrelationGUI.h
\brief Handling correlation dialogs
*/

#ifndef _SphCorrelationGUI_H_
#define _SphCorrelationGUI_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class SOPHIS_BASIC_DATA_GUI CSRCorrelationGUI
		{
		public:
			/** Display the correlation dialog corresponding to the pair instrument/instrument.
			@param code1 is the instrument ID of the first element of the pair.
			@param code2 is the instrument ID of the second element of the pair.
			@version 5.3.5
			*/
			static void Display(long code1, long code2);
		};
	}
}
SPH_EPILOG
#endif