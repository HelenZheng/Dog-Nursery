#pragma once

#ifndef _SphCreditRiskGUI_H_
#define _SphCreditRiskGUI_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		/** Base class for displaying credit risk dialog.
		@version 7.0
		*/
		class SOPHIS_BASIC_DATA_GUI CSRCreditRiskGUI
		{
		public:
			/** Display the credit risk dialog corresponding to the instrument.
			@param code is the instrument ID.
			@version 7.0
			*/
			static void Display(long code);
		};
	}
}

SPH_EPILOG
#endif