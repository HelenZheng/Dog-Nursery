/*
 	File:		SphCustomMenu.h

 	Contains:	Class to create a pop-up menu control.
				This class is meant to be derived, to build the menu
				with calls to AppendMenu in the constructor.

 	Copyright:	� 1995-2000 Sophis.

*/

/*! \file SphCustomMenu.h
	\brief Creating a pop-up menu control.
*/

#ifndef _SPHCUSTOMMENU_H
#define _SPHCUSTOMMENU_H


#include "SphInc/SphEnums.h"
#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphDialog.h"
#include "SphInc/gui/SphMenu.h"
#include "SphInc/gui/SphEditElement.h"

#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)


SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace sophis {
	namespace gui {

class CSRFitDialog;
class CSREditList;

/**
*	The class CSRCustomMenu provides a generic process for creating pop-ups.
*	CSRCustomMenu allows you to select a data type for storage in the component,
*	unlike class CSRPopupMenu, which stores a short integer.
*
*	@since 4.1
*/
class SOPHIS_FIT CSRCustomMenu : public CSRElement {
public:
	/**	Constructor 1
	Used when the element is contained within a dialog. The constructor initialises the menu handle as empty,
	along with the rest of the fields, according to the parameters.
	@param dialog is a pointer to the dialog, which contains the custom pop-up menu element.
	@param ERId_Menu is the relative unique number of the CSRCustomMenu element, among other elements in the dialog.
	@param editable is a boolean value, used to determine whether the custom menu allows you to modify the selection.
	@param valueType is to specify the type of data value that is managed by the CSRCustomMenu element. By default, is is assumed Short.
	@see CSRCustomMenu::fKind @see CSRCustomMenu::fValue
	@param valueSize is the size (in bytes) of the data value managed by the CSRCustomMenu element.
	If parameter valueType is dFloat or dDouble, then valueSize is set automatically. If valueSize is passed as 0, then valueSize is set according to the type fKind.
	@param listValue is the default (initial) menu selection index. @see CSRCustomMenu::fListValue
	@param columnName is the name of a column of the Sophis database table handled by the CSRXxx object. @see CSRElement
	@param possibleToReset is to indicate whether it is allowed to reset the data value of the CSRCustomMenu object. @see CSRElement::IsPossibleToReset()
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRCustomMenu(		CSRFitDialog	 *dialog,
						int 				ERId_Menu,
						bool				editable=true,
						NSREnums::eDataType	valueType=NSREnums::dShort,
						unsigned int		valueSize=0,
						short 				listValue=1,
				  const char 				*columnName=kUndefinedField,
						bool				possibleToReset=true,
					const char *	tagColonne = kSameAsOracleName);
	/**	Constructor 2
	Used when the element is contained within a list, as a column. The constructor initialises the menu handle as empty,
	along with the rest of the fields, according to the parameters.
	@param list is a pointer to the list which contains the custom pop-up menu element.
	@param ERId_Menu is the relative unique number of the CSRCustomMenu element among other elements\columns in the list.
	@param editable is a boolean value to determine whether the custom menu allows modifying the selection.
	@param valueType is to specify the type of data value that is managed by the CSRCustomMenu element. By default, is is assumed Short.
	@see CSRCustomMenu::fKind @see CSRCustomMenu::fValue
	@param valueSize is the size (in bytes) of the data value managed by the CSRCustomMenu element.
	If parameter valueType is dFloat or dDouble, then valueSize is set automatically. If valueSize is 0, then valueSize is set according to the type fKind.
	@param listValue is the default (initial) menu selection index. @see CSRCustomMenu::fListValue
	@param columnName is the name of a column of the Sophis database table handled by the CSRXxx object. @see CSRElement
	@param possibleToReset is to indicate whether it is allowed to reset the data value of the CSRCustomMenu object. @see CSRElement::IsPossibleToReset()
	@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
	@version 4.5.2.1 new parameter tagColonne.
	*/
	CSRCustomMenu(		CSREditList			*list,
						int 				CNb_Menu,
						bool				editable=true,
						NSREnums::eDataType	valueType=NSREnums::dShort,
						unsigned int		valueSize=0,
						short 				listValue=1,
				  const char 				*columnName=kUndefinedField,
						bool				possibleToReset=true,
					const char *	tagColonne = kSameAsOracleName);

	/**	Destructor.
	It is called automatically by CSRFitDialog::~CSRFitDialog() or CSREditList::~CSREditList()
	@version 4.5.2
	*/
	virtual ~CSRCustomMenu();

	/**	Invoked when the dialog or list containing the CSRCustomMenu element, is opened.
	This is only used when the element is within a CSRFitDialog dialog.
	In turn, it will call the virtual Action. @see CSRCustomMenu::Action()
	@version 4.5.2
	*/
	void	Open();

	/** Called when a new value has been selected in the pop-up menu.
	The function is overriden, to perform special actions when the pop-up selection is changed.
	By default, it does nothing.
	@version 4.5.2
	*/
	virtual void Action();

	/** Called when a new value has been selected in the pop-up menu.
	The function is overridden, to perform special actions when the pop-up selection is changed.
	It is similar to Action, but only get called when the menu selection is changed.
	It won't be called on open a dialog or close a dialog
	By default, it does nothing.
	@version 6.2
	*/
	virtual void MenuSelectionChanged();

	/** Sets the element's data value from the index in the pop-up.
	Given the menu selection index (@see CSRCustomMenu::fListValue), the function assigns an appropriate value to the elements
	data value (@see CSRCustomMenu::fValue).
	This is called internally by RISQUE. Whenever a menu selection is made, the method is invoked by the index
	on the menu being selected. The overridden function will use the appropriate mechanism to set the correct value
	of fValue, according to its type fKind and the purpose for which the CSRCustomMenu-derived class is used.
	By default, it assumes the data value is of type Short, and the fValue is simply set to equal the menu index.
	@version 4.5.2
	*/
	virtual void SetValueFromList();

	/** Sets the index in the pop-up menu from the stored elements data value.
	This is a callback function. The user overrides the method in order to instruct it to find the menu selection index
	(@see CSRCustomMenu::fListValue) that corresponds to the data value (@see CSRCustomMenu::fValue) handled by the CSRCustomMenu element.
	By default, it assumes the data value is of type Short, and the menu index is simply set to equal the data value fValue.
	@version 4.5.2
	*/
	virtual void SetListFromValue();

	/**	Sets the text to display on the CSRCustomMenu element's box.
	This is a callback function called automatically by RISQUE, when the element is in a list.
	The text to display in the element's text box on the list is set generally according to the menu
	selection index (@see CSRCustomMenu::fListValue).
	By default, the method simply retrieves the string on the CSRCustomMenu's menu that corresponds to the
	menu selection index. Overriding the function may be necessary in order to perform checks on the validity
	of the menu selection index.
	@param dest is the string variable to which the text is assigned.
	@param ligne is the line number on the list.
	@version 4.5.2
	*/
	virtual void ValueToString(char *dest, int ligne) const;

	/** Converts the text string , finds the corresponding code, and assigns it to the fValue of this element.
	The method is used in the case when the CSRCustomMenu element is part of a CSREditList list.
	@param sourc is the string value, whose code is to be set in this element.
	@param line is the number of the line on the containing CSREditList
	@return true if the conversion is completed successfully.
	@see CSRCustomMenu::fValue
	@version 5.3.0.0
	*/
	virtual Boolean	StringToValue(const char *sourc, int line);

	/**	Obtains the data value stored by the CSRCustomMenu.
	@param value a pointer to the variable to which the data value is copied. It a pointer to void,
	so that the CSRCustomMenu-derived can handle any type of value when it calls the method, without overriding it.
	@see CSRCustomMenu::fValue
	@version 4.5.2
	*/
	void	GetValue(void *value) const;

	/**	Assigns a value to the element's data value.
	As well as assigning a value to fValue, it also adjusts the menu selection index fListValue accordingly.
	@param value is the value to be assigned to the CSRCustomMenu data value.
	@see CSRCustomMenu::fValue
	@version 4.5.2
	*/
	void	SetValue(const void *value);

	/**	Disables a menu selection.
	It prevents an item in the pop-up menu from being selected.
	@param whichElement is the index of the menu selection to disable.
	@version 4.5.2
	*/
	void	DisableElement(int whichElement);

	/**	Enables a menu selection.
	Makes an item in the pop-up menu available for selection.
	@param whichElement is the index of the menu selection to enable.
	@version 4.5.2
	*/
	void	EnableElement(int whichElement);

	/**	Adds a new item to the pop-up menu.
	@param element is the text string of the new menu item.
	@version 4.5.2
	*/
	void	AddElement(const char* element);

	/**	Remove a pop-up menu item
	@param whichElement is the index of the menu selection to remove.
	@version 5.2.2
	*/
	void	RemoveElement(int whichElement);

	/**	Reset the menu
	@version 5.0
	*/
	void	ResetMenu();

	/**	Refresh The Menu after the call of AddElement after the initialisation
	@version 5.0
	*/
	void	RefreshMenu();

	/**	Indicates whether the menu selection can be changed.
	This only applies to the case when the CSRCustomMenu is in a list.
	This permission is specified through a parameter in the constructor. @see CSRCustomMenu::CSRCustomMenu
	@return true if possible to make another selection on the menu, false otherwise.
	@version 4.5.2
	*/
	Boolean MenuCanBeModifiedInAList(void) const {return fMenuCanBeModifiedInAList;}

	/**	Indicates whether the CSRCustomMenu element allows its data value to be modified.
	This acts in the same way as CSRCustomMenu::MenuCanBeModifiedInAList, except that it is more generic.
	It tells if modification is allowed\disallowed, while considering the CSRCustomMenu as an element rather
	than a pop-up menu specifically.
	It is overriden by all classes derived from CSRElement. While MenuCanBeModifiedInAList is overriden by
	CSRElement-derived classes that handle menus.
	@return true if element allows modification of its value, false otherwise.
	@version 4.5.2
	*/
	Boolean	CanBeModifiedInAList(void) const {return fEditable;}

	/** Indicates if the data value of the element is empty or void.
	For instance, if the CSRCustomMenu data value is of type Short, then it returns true if the value is 0, or
	if fValue is a empty string if it is a string.
	By default, it tests the value of fValue according to the type specified by the derived class. Overriden
	method may perform additional checks.
	@return true if the data value is empty, false otherwise.
	@version 4.5.2
	*/
	virtual bool IsMenuEmpty(void);

	/**	Inserts a new item to the pop-up menu.
	@param element is the text string of the new menu item.
	@param pos is the position in the list
	@version 6.0.0
	*/
	void	InsertElement(const char* element, int pos);

public:
	/**	Indicates whether the element's menu is shared.
	Because in certain cases, the element's menu handle refers to a menu object that is not created specifically
	for this CSRCustomMenu object. In other words, it refers to the same menu used by other objects in the RISQUE.
	This will help the user to decide whether to manipulate the menu freely.
	@return true if the element's menu is shared by other objects in the code.
	@version 4.5.2
	*/
	Boolean IsASharedMenu() const {return fIsASharedMenu;}

	/** Imposes the sharing status of the element's menu.
	User may specify that the menu is shared or not.
	@param shared is true to set the menu as shared, false otherwise.
	@version 4.5.2
	*/
	void	SetShared(Boolean shared = true) {fIsASharedMenu = shared;}

	short	GetListValue(void) const;									// internal
	void	SetListValue(short value);									// internal
/** Assign menu. */
	USMenu	*DonneMenu(void) const {return fMenuHandle;}				// internal
/** Assign filter. */
	virtual short	DonneFiltre(void) const {return 0;}					// internal
/** Assign type. */
	virtual	int		DonneTypeTri() const;								// internal

	virtual int	Compare(const CSRElement&) const;

	ELEM_COMMON_INTERNALS

protected:
	/**	Obtains the default size of the data value.
	The size (in bytes) of the data value returned, is decided according to the type of the data value (@see CSRCustomMenu::fKind).
	This method must not be called if the data value is a text string.
	@return the size of the element's data value in bytes.
	@version 4.5.2
	*/
	unsigned int GetTailleParDefaut() const;

	/**	Obtains a type of the data value that matches an Oracle database-defined type.
	This method must not be used if the data value is of type Pointer.
	@return the integer that is the corresponding Oracle-defined type.
	@version 4.5.2
	*/
	int GetTypeOracle() const;

	/**	Compares the element's data value to a given value.
	The parameter has to point to an object of the same type as the data value.
	@param value is a pointer to the value that is to be compared with the element's stored data value.
	@return a positive integer if the values are different, 0 if they are equal.
	@version 4.5.2
	*/
	int		CompareValueTo(const void* value);

	/**	Index of the menu selection.
	It is the index of the item in the CSRCustomMenu's menu, that is currently being selected. This index
	also determines the data value fValue. The minimum value of the index is 1.
	@version 4.5.2
	*/
	short		fListValue;

	/**	The data value of the menu selection.
	Classes derived from CSRCustomMenu are used for various categories of data. The fValue is therefore a
	pointer to void for its compatibility to all types.
	@version 4.5.2
	*/
	void		*fValue;

	/**	Indicates whether the CSRCustomMenu element allows its data value to be modified.
	@see CSRCustomMenu::CanBeModifiedInAList
	@version 4.5.2
	*/
	bool		fEditable;

	/**	Indicates whether the menu selection can be changed.
	@see CSRCustomMenu::MenuCanBeModifiedInAList
	@version 4.5.2
	*/
	Boolean		fMenuCanBeModifiedInAList;

	/**	Indicates whether the element's menu is shared.
	@see CSRCustomMenu::IsASharedMenu
	@version 4.5.2
	*/
	Boolean		fIsASharedMenu;

	/**	Precision parameter if the data value of type Real
	@version 4.5.2
	*/
	int			fPrec;

	/**	The type of the data value stored by the element.
	This is the type of the object pointed to by the data value (@see CSRCustomMenu::fValue).
	The derived class may specify the type in the constructor. By default, it assumes the data type is a Short.
	@version 4.5.2
	*/
	NSREnums::eDataType	fKind;


	/**	Internal method to release menu handle.
	*/
	void ReleaseMenu();

	USMenu		*fMenuHandle; // internal
};

class SOPHIS_FIT CSROperatorCustomMenu : public sophis::gui::CSRCustomMenu {
public:
	CSROperatorCustomMenu(sophis::gui::CSRFitDialog 		*dialogue, 
		int 			 NRE_Menu, 
		bool			 editable=true);
	CSROperatorCustomMenu(sophis::gui::CSREditList *liste, 
		int 			 NRC_Menu, 
		bool			 editable=true);

	typedef long value_type;

	void SetToCurrentOperator();

protected:
	void BuildMenu();
	virtual void SetValueFromList();
	virtual void SetListFromValue();
};

SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSROperatorCustomMenu);

/**
 * Popup menu that is trivial to setup.
 * Example usage : 
 *		CSRTrivialPopupMenu* pPopup = newCSRTrivialPopupMenu(pDialog, idInDialog, smart_vector<string>() << "" << "First item" << "Second item");
 */
class SOPHIS_FIT CSRTrivialPopupMenu : public CSRGenericDynamicMenu
{
protected:

	_STL::vector<_STL::string> fItems;
	_STL::vector<_STL::string> fPreviousItems;

public:

	CSRTrivialPopupMenu(CSRFitDialog* pForm, int id, const _STL::vector<_STL::string>& items, short value = 0);
	CSRTrivialPopupMenu(CSREditList* pForm, int id, const _STL::vector<_STL::string>& items, short value = 0);
	
	virtual ~CSRTrivialPopupMenu();

	void SetItems(const _STL::vector<_STL::string>& items);

	virtual short GetListValue(void) const;

	virtual void	ValueToString(char *dest, int line) const;

	virtual Boolean	StringToValue(const char *sourc, int line);

	virtual bool UpdateMenu();

	// All of the following methods are kept here for compatibility with old reporting module gui dll
	virtual void SetValueFromList();
	virtual void SetListFromValue();
	virtual const char *InitialiseDialogue(const char* result);
	virtual char	*InitialisePointeur(char* result, bool noWriting);
};

SOPHIS_FIT CSRTrivialPopupMenu* newCSRTrivialPopupMenu(CSRGenericForm* pForm, int referenceInForm, const _STL::vector<_STL::string>& items, long value = 0);

//--------------------------------------------------------------------------------------
// CSRPopupMenuForPrototype
//--------------------------------------------------------------------------------------
// class handling the menu for choosing a prototyped class.
// Will also come in 6.0
template<typename T> class CSRPopupMenuForPrototype : public CSRCustomMenu
{
public:
	CSRPopupMenuForPrototype(	sophis::gui::CSRFitDialog	*dialog, 
								int 						ERId_Menu,
								int 						listValue, 
								const char 					*columnName,
								unsigned int				valueSize=40)
		: CSRCustomMenu(dialog, 
						ERId_Menu,
						true,
						NSREnums::dNullTerminatedString,
						valueSize,
						static_cast<short>(listValue), 
						columnName,
						false)// no possibility to reset
	{
		fIsASharedMenu = false;

		// delete fMenuHandle because it has been created in CSRCustomMenu
		ReleaseMenu();
		fMenuHandle = typename T::GetPrototype().new_Menu();

		// set up default value
		SetValueFromList();
	}

	void SetListFromValue()
	{
		typename T::prototype & list = T::GetPrototype();
		typename T::prototype::const_iterator scanList;

		fListValue = 1;
		for(scanList = list.begin(); scanList != list.end(); ++scanList, ++fListValue)
			if(strcmp(scanList->first, (char *) fValue) == 0)
				return;

		fListValue = 0;
		return;
	}

	void SetValueFromList()
	{
		typename T::prototype & list = T::GetPrototype();
		if (fListValue > 0 && fListValue <= (short) list.size())
			strcpy((char *)fValue , list.GetNth(fListValue-1)->first);
		else
			*(char *) fValue	= 0;
	}

};

	}	//	namespace gui
}	//	namespace sophis

SPH_END_NOWARN_EXPORT
SPH_EPILOG


#endif  //_SPHCUSTOMMENU_H
