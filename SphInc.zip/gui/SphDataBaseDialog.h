/*
 	File:		SphChildDialog.h

 	Contains:	Standard derived dialog (before in SphDialog)
 	Copyright:	� 1995-2003 Sophis.

*/
#pragma once

#ifndef	__SphDataBaseDialog_H__
#define	__SphDataBaseDialog_H__

#include "SphDialog.h"


SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		/** Class CSRDatabaseDialog: for a dialog that interacts with a record on a database table.
		The derived class will be for a specific record in a database table, and will also add elements to the dialog.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRDatabaseDialog : public CSRFitDialog
		{
		public:
			/**Constructor.
			Initialises class members.
			Sets up the table name fTableName and the primary key column name fColumnName, for which data are retrieved.
			Also constructs the dialog element CSRDatabaseDialog::fElem.
			@param table_name is the name of the database table on which the dialog interacts.
			@param column_name is the primary key column of table_name.
			@version 4.5.2
			*/
			CSRDatabaseDialog(const char *table_name, const char *column_name/*, long default_ident = 0L*/);
			
			/**Destructor.
			Overriding destructor should also call this destructor in order to delete members
			CSRDatabaseDialog::fElem and CSRDatabaseDialog::fPointer.
			@version 4.5.2
			*/
			virtual ~CSRDatabaseDialog();

			/**Selects data from fTableName given the value in fColumnName.
			The method fills member CSRDatabaseDialog::fPointer with the results of the SQL query.
			Member CSRDatabaseDialog::fRecordKey is the unique ID of the record and is set to parameter code.
			@param code is the unique value of fColumnName that specify the record to select from the table.
			@return true if data selection is successful.
			@version 4.5.2
			*/
			bool	ReadData(long code);

			/** (vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			@since 4.7.0
			*/
			bool ReadData();

			/**Saves data to the database.
			Saves data stored on CSRDatabaseDialog::fPointer, for record with fColumnName=fRecordKey on table fTableName.
			If fRecordKey is null, then a new identifier is generated for it.
			Inserts a new empty row in fTableName with only fColumnName set to fRecordKey
			and then calls OnInsertRecord (for instance, in case multiple key completion is needed).
			@return true if saving is successful.
			@version 4.5.2
			*/
			virtual bool SaveData();

			/**Inserts data for the rest of the record.
			By default, does nothing and returns true. You should override it in order to complete insertion for other columns
			in fTableName.
			@return true if insertion is successful.
			@version 4.5.2
			*/
			virtual bool OnInsertRecord();

			/**Initialises SQL queries (read, update) given fTableName and fColumnName.
			Includes also initialisation for HISTORIQUE table of fTableName.
			@version 4.5.2
			*/
			virtual	void Open(void);

			/**Creates a new identifier value for fColumnName.
			The overriding method will generate a value for key column fColumnName.
			This is specially used for saving a new record in table fTableName.
			@return the newly generated identifier.
			@version 4.5.2
			*/
			virtual long CreateIdentifier() = 0;

			/**Saves data in database (by default calls CSRDatabaseDialog::SaveData()).
			You override this method to save values in the database, for instance.
			as well as in dialog elements (see CSRFitDialog::Save()).
			@return true if saving is successful.
			@version 4.5.2
			*/
			virtual	bool Save(sophis::backoffice_kernel::eSavingMode mode);  // calls CanSave by default

			/**Indicates whether data can be saved.
			Should be overriden in order to set conditions for saving in database and\or from dialog elements.
			@return true if saving can take place.
			@version 4.5.2
			*/
			virtual bool CanSave(void);

			/**Sets the value of the extra ID.
			The extra ID may be the Four Eyes ID or the Audit that corresponds to the original ID fRecordKey.
			The methods sets the values for fAnotherIdent and fAnotherIsAudit.
			@param ident is the value of the extra ident, assigned to fAnotherIdent.
			@param anotherIsAudit is to specify whether fAnotherIdent is the Audit ident that corresponds to fRecordKey. It is assigned to fAnotherIsAudit.
			@version 4.5.2
			*/
			void SetAnotherIdent(long ident, bool anotherIsAudit = true);

			/**Obtains the extra ID.
			@param anotherId is pointer that will to the extra ident fAnotherIdent.
			@return true if the extra ident obtained is for Audit.
			@version 4.5.2
			*/
			bool GetAnotherIdent(long *anotherId);

			/**Sets the value of the ident.
			@param ident is the value of the ident
			@version 4.5.2
			*/
			virtual void SetIdent(long id);

			/**(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			@since 4.7.0
			*/
			_STL::vector<CSRElement*> fQueryKey;

			/**Gets the last error message logged by the dialog
			@since 5.2.7.2
			*/
			const char *GetErrorMessage(){return fErrorMessage.c_str();}

		protected:
			
			/**Pointer to data that stores results of the SQL read queries.
			@version 4.5.2
			*/
			infos_user		*fPointer;

			/**The Dialog Element that is core object responsible of much of the interaction with the database.
			@version 4.5.2
			*/
			DialogueElement	*fElem;

			/**Database table name on which the CSRDatabaseDialog interacts.
			@version 4.5.2
			*/
			char			fTableName[32];

			/**The name of the primary key column.
			@version 4.5.2
			*/
			char			fColumnName[32];

			/**The value of the unique ID contained in column fColumnName of table fColumnName.
			This value indicates which unique record to retrieve the table.
			@version 4.5.2
			*/
			long			fRecordKey;

			/**The extra ID that may be the Four Eyes ID or the Audit ID that
			corresponds to the original record ID fRecordKey.
			@version 4.5.2
			*/
			long			fAnotherIdent;

			/**Specifies whether member fAnotherIdent is the ID that corresponds to fRecordKey in the Audit table of fTableName.
			@version 4.5.2
			*/
			bool			fAnotherIsAudit;

			/**Specifies whether the save is carried out by the API or GUI
			@version 4.5.2
			*/
			sophis::backoffice_kernel::eSavingMode		fSavingMode;

			/**Stores an error message
			@version 5.2.7.2
			*/
			_STL::string	fErrorMessage;

		public:
			infos_user		*GetPointeur() {return fPointer;} // internal
			DialogueElement *GetElem();
		};
	}
}

SPH_EPILOG



#endif
