#pragma once

#ifndef	__SphDataBaseAuditDialog_H__
#define	__SphDataBaseAuditDialog_H__

#include "SphInc/gui/SphDataBaseDialog.h"
#include "SphInc/SphEnums.h"



SPH_PROLOG
namespace sophis
{
	namespace gui
	{		
		class SOPHIS_FIT CSRDatabaseAuditDialog:public sophis::gui::CSRDatabaseDialog
		{
		public:
			CSRDatabaseAuditDialog(	const char	*table_name, 
				const char	*column_name,
				bool		doAudit,
				bool		FEVersion=false);

			virtual ~CSRDatabaseAuditDialog();

			//////////////////////////////////////////////////////////////////////////////////////////
			//	this function is used to create the next audit data code							//
			//	and to know if this code should be saved in  compo_table							//
			//	if the specialized version return true, compo_table	is filled						//
			virtual bool CreateNextAuditCode( long* nextCode,char *compo_table,sophis::backoffice_kernel::eSavingMode *mode) = 0;	//
			//////////////////////////////////////////////////////////////////////////////////////////

			bool	SaveData();	
			long	GetRecordKey();
			short	UpdateAuditDataTable(char *table, char *columName, long code, long sequence_code);

			virtual bool	HasWriteAcces() {return true;}	

			static	short 	UpdateCompoTable(long code,
				long audit_code,
				char *compo_table, 
				NSREnums::eParameterModificationType typeModif,
				sophis::backoffice_kernel::eSavingMode mode);

			void InitDatabaseAuditDialogColumnList();	//(vvf, tst)

		protected:
			bool fDoAudit;
			bool fIsFEVersion;
		};
	}
}
SPH_EPILOG



#endif
