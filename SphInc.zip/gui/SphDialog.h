/*
 	File:		SphDialog.h

 	Contains:	Class for the handling of user's dialogs

 	Copyright:	� 1995-2003 Sophis.

*/
#pragma once

/*! \file SphDialog.h
	\brief Handling user dialogs
*/

#ifndef	__SphDialog_H__
#define	__SphDialog_H__

#include "SphTools/SphDay.h"
#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialogEnums.h"
#include "SphInc/portfolio/SphPortfolioEnums.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"
#include "SphTools/SphCommon.h"
#include "SphInc/gui/SphGenericForm.h"
#include "SphSDBCInc/SphSQLDataTypes.h"


#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)


#ifndef SOPHIS_INTERFACE
	#define SOPHIS_INTERFACE
#endif



#define DECLARATION_DIALOG(derive)	\
	public:							\
	derive();						\
	static sophis::gui::CSRFitDialog* NewDeriveSophis();

#define WITHOUT_CONSTRUCTOR_DIALOG(derive)	\
	sophis::gui::CSRFitDialog* derive::NewDeriveSophis(){ return new derive();}

#define CONSTRUCTOR_DIALOG(derive)		\
	derive::derive() {}					\
	WITHOUT_CONSTRUCTOR_DIALOG(derive)

extern SOPHIS_FIT bool gInitializationStandardDialogOnly;
#define INITIALISE_STANDARD_DIALOG(derivedClass,resource)			\
	{																\
		gInitializationStandardDialogOnly = true;					\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;	\
		::NewDialogueTitreSophis(&_dialogConstructor,(resource),0);	\
		gInitializationStandardDialogOnly = false;					\
	}


SPH_PROLOG
SPH_NOWARN_EXPORT


namespace sophis {
	namespace tools {
		class CSRArchive;
		namespace	dataModel	{
			class DataSet;
		}
	}
	namespace instrument {
		class CSRArbitrage;
		class CSRInstrument;
	}
}


namespace sophis {
   namespace backoffice_kernel {
      class CSRThirdParty;
   }
}


struct	TDlog;			// internal
class	horsDialogue;	// internal
struct	infos_user;		// internal
struct	TViewFolio;		// internal
struct  DialogueElement;// internal
struct	DialogueSurcharge;
struct	DialogueOption;
class	CSRUserEditInfo; // internal

class	CSPacket;	   // internal
class	CSCrossing;
class	CSTitre;
class	CSRColleUtilisateur_GUI;

class	CSRLayout;		// internal

namespace sophis
{
	namespace misc	{
		class	CSREvent;
	}
	namespace event {
		class ISEvent;
	}
	namespace gui
	{

		class CSRElement;
		union SSDataDescribed;

		/**Type of error generated when failing to send\receive Real Time or Coherency events.
		*	@version 4.5.2
		*/
		enum eEventErrorType {
			eeNoErr,
			eeUnknownEvent
		};

		/**Types of Real Time events.
		*	@version 4.5.2
		*/
		enum eFITEventType {
			feRedemption	= 'AMOR',
			feDividend		= 'DIVI',
			feComposition	= 'COMP',
			feLoanCost		= 'CTPE',
			feVolatility	= 'VOLA'
		};


		/** Class CSRFitDialog: base class for all dialogs.
		*	CSRFitDialog is one of RISQUE's base classes. It enables the user to create autonomous dialogs,
		*	security model dialogs, to derive dialogs from RISQUE and/or to overload these dialogs
		*	with autonomous dialogs or security model dialogs.
		*
		*	Notes:
		*	While modal dialogs are open, Coherency and Real-Time events are still treated and calculations are
		*	up to date.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRFitDialog : public CSRGenericForm {
		public:
			/**Constructor.
			Initialises all the fields public, private and protected.
			Before using an object of this class, one should derive it to integrate
			properly the elements one wants the dialog to handle (CSElements and their children).
			@version 4.5.2
			*/
			CSRFitDialog();

			/**Destructor.
			Purges every element of the dialog.
			All elements of CSRElement-derived classes referenced by its list fElementList.
			Therefore, one should never try to destroy these elements in an overloaded ~CSRFitDialog.
			@version 4.5.2
			*/
			virtual	~CSRFitDialog();

            /**Allows further control in the disposing of an exiting CSRFitDialog object.
			This method can be overridden in derived classes to control the behaviour
			of how CSRFitDialog objects are deleted.
			This default implementation just deletes the CSRFitDialog object.			
			@version 4.5.2
			*/
            virtual void Destroy();

			/**Creates a new CSRFitDialog object.
			The object is initialised using CSRFitDialog constructor, with memory allocated to it.
			Object returned must be destroyed explicitly.
			This method is overloaded to create a CSRFitDialog-derived object.
			@return a pointer to a CSRFitDialog object.
			@version 4.5.2
			*/
			virtual CSRFitDialog* Clone() const;

			/**Validates an element in the context.
			When selection moves from one element of the dialog to another one, the method CSRElement::Validation()
			of the current element is called and (if the call ends succesfully) so is CSRFitDialog::ElementValidation().
			You override the method in order to :
			- check the coherence of the current setting
			- take an appropriate action with respect to the current context.
			@param EAId_Modified is the absolute ID of the modified element
			@version 4.5.2
			*/
			virtual	void	ElementValidation(int EAId_Modified);

			/** Call the pValid method of the parent window.
			This method allow to reproduce the behavior of the standard GUI.
			@param absolute_IDToValid is the absolute ID of the element to valid.
			@version 5.2.2
			*/
			virtual void ValidParentDialog(int absolute_IDToValid);

			virtual void TabChanged(int tabFrom, int tabTo);

			/** Initialise the tabulation.
			This is called for each tab at the initialisation.
			@since 5.3
			*/
			virtual void InitialiseTabulation(TDlog * dlog);
			
			/**Called automatically before launching a dialog.
			CSRFitDialog::Open() calls CSRElement::Open() for all the dialog's elements.
			If you want to initialise your dialog globally, you must overload this virtual method.
			@version 4.5.2
			*/
			virtual	void	Open(void);

			/**
			*/
			virtual void	OpenAfterInit(void);

			/**Called automatically when closing the dialog.
			Virtual method to be overloaded.
			CSRFitDialog::DoDialog() calls CSRElement::Close() for all the elements of the dialog.
			If one of these calls receives the false answer, CSRFitDialog::Close() is not called
			and the dialog does not end. A dialog ends only if CSRFitDialog::Close() has been successfully called.
			Overload this virtual method, for special actions to be taken before closure, such as saving the dialog's data.
			@return True if all tasks before closure were completed succesfully, False otherwise.
			@version 4.5.2
			*/
			virtual	Boolean	Close(void);

			/**Saves data contained in the dialog.
			Virtual method to be overloaded.
			Saves values from elements of CSRElement-derived classes referenced by its list fElementList. This is usually
			called within CSRFitDialog::Close()
			@return True if saving opration is completed successfully.
			@version 4.5.2
			*/
			virtual	bool	Save(void);

			/**Indicates whether the current state of the dialog allows saving.
			Virtual method to be overloaded.
			It generally checks for the validity of the elements referenced by its list fElementList,
			such as making sure that an element is not null, before CSRFitDialog::Save() is called.
			@return True if saving can go ahead, False otherwise.
			@version 4.5.2
			*/
			virtual	bool	CanSave(void);

			/**Receives a Real Time event and performs appropriate tasks in response.
			Virtual method to be overloaded.
			The event is analysed and action is taken depending on its content. It could be an event that will
			lead to updating a value of one of the dialog's elements referenced by fElementList.
			Warning : to be notified, the window MUST be set to the type "Child" in the settings of the resource.
			@param event is received from the RT server.
			@version 4.5.2
			*/
			virtual void	HandleEvent(const sophis::event::ISEvent & event);

			/**Performs actions in response to pressing the OK button.
			Virtual method to be overloaded.
			This methode is invoked if the dialog contains an element of type CSRElement-derived CSROKButton.
			Upon pressing the OK button, CSRFitDialog::OnOK() is subsequently invoked from CSROKBouton::Action().
			@version 4.5.2
			*/
			virtual	void	OnOK();

			/**Performs actions in response to pressing the Cancel button.
			Virtual method to be overloaded.
			This methode is invoked if the dialog contains an element of type CSRElement-derived CSRCancelButton.
			Upon pressing the Cancel button, CSRFitDialog::OnCancel() is subsequently invoked from CSRCancelButton::Action().
			@version 4.5.2
			*/
			virtual	void	OnCancel();

			/**Creates the dialog's elements list fElementList, and sets fElementCount.
			Initialises fElementList to an array of CSRElement-derived pointers. All pointersare  initially null.
			The size fElementCount of fElementList is also set to nb.
			@param nb is the number fElementCount of elements to initialise in the dialog, therefore is the size of fElementList
			@version 4.5.2
			*/
			void		NewElementList(int nb);

			/** Hides and disconnects the dialog's element of which the absolute ID is NAE_ToHide.
			Typically, this method is called when opening a derived dialog in which one wishes to hide fields of the parent dialog.
			@param EAId_ToHide is the absolute ID of the element to hide.
			@version 4.5.2
			*/
			void		HideElement(int EAId_ToHide);

			/**Sets an element of the dialog back to its initial active status.
			The method performs the inverse of CSRFitDialog::HideElement().
			@param EAId_ToShow is the absolute ID of the element to show.
			@version 4.5.2
			*/
			void		ShowElement(int EAId_ToShow);

			/**Get an element's visibility (as changed by ShowElement / HideElement)
			@param NAE_ToQuery is the absolute ID of the element to query for visibility.
			@version 6.2
			*/
			bool		IsElementVisible(int NAE_ToQuery);

			/**Forbids access to an element.
			Disable the use of an element with absolute Id NAE_AInterdire. The element stays visible but is greyed out which shows that it can't be selected anymore.
			Typically, this method is called on opening a dialog derived from another one when one wants to forbid access to some of the parent's fields without altogether supressing these fields.
			@param EAId_ToDisable is the absolute ID of the element to disable.
			@version 4.5.2
			*/
			void		DisableElement(int EAId_ToDisable);

			/**Reauthorizes access to an element of the dialog.
			Inverse effect of CSRFitDialog::DisableElement().
			@param EAId_ToEnable is absolute ID of the element.
			@version 4.5.2
			*/
			void		EnableElement(int EAId_ToEnable);

			/**Displays text in an element.
			Displays a C string text in the element, either of editable type or of static type.
			The string is aligned with respect to the alignment parameter, which is of type enum eAlignmentType.
			Typically, the user will use SetTextInElement() to display a text in a static text element and
			will use CSRElement::SetValue() to display or to change the value of an editable text.
			@param EAId_ToWriteInto is absolute ID of the element.
			@param text is the C string text to display on the element.
			@param alignemnt is the type by which the string is aligned.
			@version 4.5.2
			*/
			void		SetTextInElement(int EAId_ToWriteInto, const char *text, eAlignmentType alignment);

			/**Refreshes an element.
			This method is typically called within the SetValue() method of a CSRElement-derived element in the dialog.
			As a result, the new value of the element is displayed.
			@param EAId_ToUpdate is absolute ID of the element.
			@version 4.5.2
			*/
			void		UpdateElement(int EAId_ToUpdate) const;

			/**Returns the parent dialog.
			For example, a main dialog consists of tabs. The current CSRFitDialog could be associated with one of the tabs,
			for which the main is therefire the parent dialog.
			@return the parent dialog.
			@version 4.5.2
			*/
			CSRFitDialog *GetParent() const;

			/**Returns an element given its Relative ID.
			Returns a pointer to the first element of the dialog with field CSRElement::fElementId equal to ERId_EltToGet.
			@param ERId_EltToGet is the relative number of the element.
			@return a pointer to an object of CSRElement\CSRElement-derived class.
			@version 4.5.2
			*/
			CSRElement	*GetElementByRelativeId(int ERId_EltToGet) const;

			template <typename element_type>
			element_type* GetElementByRelativeId(int ERId_EltToGet) const {
				CSRElement* pElement = GetElementByRelativeId(ERId_EltToGet);
				if (!pElement) {
					ASSERT(!"No such element"); return NULL;
				}
				element_type* pCastElement = dynamic_cast<element_type*>(pElement);
				if (!pCastElement) {
					ASSERT(!"Wrong element type"); return NULL;
				}
				return pCastElement;	
			}

			/**Returns an element given its Absolute ID.
			Returns an element of the dialog such that:
			- its index in fElementList is smaller than fFirstShiftedElement and its field fElementId is set to EAId_EltToGet
			- its index in fElementList is greater than or equal to fFirstShiftedElement and its field fElementId
			is equal to EAId_EltToGet-fShiftValue.
			You should use this method when one knows the absolute number of an element and one wants to
			retrieve its associated CSRElement.
			@param ERId_EltToGet is the absolute ID of the element. This absolute ID of the element to retrieve should be known.
			@return a pointer to an object of CSRElement\CSRElement-derived class.
			@version 4.5.2
			*/
			CSRElement	*GetElementByAbsoluteId(int EAId_EltToGet) const;

			/**Returns the number of elements in the dialog.
			@return number of CSRElement\CSRElement-derived elements referenced by in fElementList.
			@version 4.5.2
			*/
			int			GetElementCount(void) const { return fElementCount; }

			/**Returns the list of elements in the dialog.
			@return a pointer to fElementList that is the array of CSRElement\CSRElement-derived elements.
			@version 4.5.2
			*/
			CSRElement	**GetElementList(void) const { return fElementList; }

			/**Returns the resource ID of the dialog.
			@return value stored in CSRFitDialog::fResourceId, the resource ID of the dialog.
			@version 4.5.2
			*/
			int			GetResourceId(void) const	{ return fResourceId;	}

			/**Sets the values of both Shift Value & First Shifted Element.
			@param shiftValue is the value for fShiftValue.
			@param startAt is the value for fFirstShiftedElement. Equal to 0 by default.
			@version 4.5.2
			*/
			void		SetElementIdShift(int shiftValue, int startAt=0);

			/**Return the Shift Value.
			@return the Shift Value (fShiftValue).
			@version 4.5.2
			*/
			int			GetElementIdShift(void) const	{ return fShiftValue;	}

			/**Disconnects an element from the dialog.
			Assigns the value 0 to CSRElement::fElementId. Hence, CSRFitDialog::DoDialog() will not initialise this element.
			@param ERId_ToRemove is the relative ID of the element to be removed.
			@version 4.5.2
			*/
			void		RemoveElement(int ERId_ToRemove);

			/**Sets dialog as modified or not modified.
			Sets modification flag. If flag is down when CSRFitDialog closes, RISQUE does not ask whether
			it must save the current data.
			@param modified is a boolean value that is true to indicate dialog is modified, false otherwise.
			@version 4.5.2
			*/
			void		SetModified(bool modified=true) const;

			/** Check if the dialog has been modified.
			It checks for simple items and then loop on all items of the dialog
			calling {@link CSRElement::GetModified} to check for complexed items.
			*/
			bool		GetModified(void) const;

			/** Set a value to an item of the dialog.
			@param relativeID is the relative id of the item.
			@param value is a pointer on a valid buffer for the item.
			@throw InvalidArgument if relativeID is not correct.
			This is just a shortcut for {@link CSRFitDialog::GetElementByRelativeId} 
			then {@link CSRElement::SetValue}
			@since 4.6
			*/
			void SetElementValue(int relativeID, const void *value);


			/** Declares a frame to an element and a Title.
			Informs CSRFitDialog that an element should be boxed and that its heading
			should be 'titre' (instrument).
			Using this instruction will make the element visible whenever the dialog is launched with a title parameter not NULL,
			and the character string to which title points will appear in the top left corner of the box.
			@param ERId_EltToFrame is the relative ID of the element.
			@param title is the title on the top-left corner of dialog.
			@version 4.5.2
			*/
			void		FrameElement(int ERId_EltToFrame, const char *title);

			/**
			The method calls CSRElement::Initialisation() of each element in the dialog before calling CSRFitDialog::Open().
			The dialog window pops up, the preselected element being that of which the absolute number has been entered into
			fEAId_Selected (except if equals to -1).
			The dialog ends when CSRFitDialog::Close() is called. 
			@param modal is a boolean value to indicate whether the dialog is Modal or not. By defaut, dialogs are modal.Typically, one will never use non modal dialogs except to display computation results.
			@param title is a string the title of the dialog. Null string by default.
			@param center is a boolean value indicating whether the dialog is centred.
			@param CSRUserEditInfo is the User Edit Info that prevents the same dialog from being opened more than once.
			@return value of type eDialogResult list. This is used when the dialog is Modal. It is the status on which the dialog is closed. 
			@version 5.1 this method is now virtual.
			@version 4.5.1.0.14.1 Add a new parameter to specify to modify the color if this has been modified.
			*/
			virtual eDialogResult	DoDialog(	Boolean			modal= true, 
										const char		*title=0, 
										bool			center = true, 
										CSRUserEditInfo *userInfo = 0,
										bool modifyColor = false);

			/**Obtains the title of the dialog.
			Function overloaded.
			@param title is a C string to which the value of the dialog's title is copied.
			@version 4.5.2
			*/
			void		GetTitle(char *title) const;
			

			/** Describe the dialog items in the data set.
			This is used internally by Data service to populate user items.
			@since 4.5.2.1
			*/
			virtual void	DescribeElement(tools::dataModel::DataSet& data_set, const SSDataDescribed & dataPtr) const;

			/** Update the dialog items using the data set.
			This is used internally by Data service to update user items.
			@since 4.5.2.1
			*/
			virtual void	UpdateElement(const tools::dataModel::DataSet& data_set, SSDataDescribed & dataPtr);

			/**Returns the title of the dialog.
			Function overloaded.
			@return a pointer to a C string that is the dialog's title member.
			@version 4.5.2
			*/
			const char* GetTitle() const { return fTitle_; }

			/**Sets a title to the dialog.
			@param title is a C string that is the title to the dialog.
			@param gui is a boolean that is true if the title is to be set also on the dialog's window. It is True by default.
			@version 4.5.2
			*/
			void		SetTitle(const char *title, bool gui=true);
			// [26.12.2001 09:23 by NAV ] in merge time
			//void		SetTitle(char *title);

			/**Terminates and closes the dialog explicitly.
			To be used only with dialogs that do not use a model [i.e. CSRFitDialog::DoDialog(false)].
			@return boolean which is true if dialog closed successfully.
			@version 4.5.2
			*/
			Boolean		EndDialog(void);	// be carefull, deletes this.

			/**Activates a dialog.
			This method brings the dialog to the foreground.
			To be used only with dialogs that do not use a model [i.e. CSRFitDialog::DoDialog(false)].
			@version 4.5.2
			*/
			void		SetActive(void);

			/**Sets a double value to a CSRElement.
			The element must of a CSRElement-derived class that holds a value of type double (such as a CSREditDouble).
			@param ERId is the absolute ID of the element.
			@param value is the value to be set for the element referred to by ERId.
			@version 4.5.2
			*/
			void		SetDoubleValue(int ERId, double value);

			/** stricly internal method **/
			virtual		void GetEnableMenu(unsigned long* e1, unsigned long* e2, unsigned long* e3) const;

			/** strictly internal method **/
			virtual		void DoCommandMenu(unsigned long cmd, void* params) const;

			/** strictly internal method **/
			virtual		bool ForceEnableCommandMenu() const { return false; }

			/** internal */
			void	ChangeColorOnModification( bool change );
			void	ResetModifColoration();

			/** internal */
			CSRLayout *	GetLayout() const;
			/** internal */
			void		SetLayout(const CSRLayout& layout );
			void		RemoveLayout();

			/** Set the window in read-only	*/
			void SetReadOnly(bool readOnly) { fReadOnly = readOnly; }

		protected:
			/**List of all CSRElement\CSRElement-derived elements that constitute the dialog.
			@version 4.5.2
			*/
			CSRElement	**fElementList;

			/**Number of CSRElement\CSRElement-derived elements on the dialog. Size of fElementList array.
			@version 4.5.2
			*/
			int			fElementCount;

			/**Resource ID of the dialog.
			This is set up by the CSRFitDialog-derived class.
			@version 4.5.2
			*/
			int			fResourceId;

			/**The number by how much the Absolute ID of an element is greater than the relative ID.
			If fShiftValue is null, the absolute ID simply equals to the relative ID.
			@version 4.5.2
			*/
			int			fShiftValue;

			/**The number up to which the absolute ID of an element is equal to the Relative ID.
			If the fFirstShiftedElement is null, and the fShiftValue is positive, then the absolute ID of an
			element is its relative ID plus fShiftValue.
			@version 4.5.2
			*/
			int			fFirstShiftedElement;

			/**Pre-selected element.
			This is the absolute ID of the element which is to be pre-selected when openning the dialog.
			@version 4.5.2
			*/
			int			fEAId_Selected;
			bool		fIsInternalResource;

			/**Holds unique information on the dialog. This will prevent it from openning more than once.
			@version 4.5.2
			*/
			CSRUserEditInfo	*fUserEditInfo;

			/**Title of the dialog.
			*/
			char		fTitle_[256];

			/**Receives a Real-Time event by the active dialog.
			Used by Sophis API.
			@param event is the Real Time event.
			*/
			static void CallBackHandleEvent(const sophis::event::ISEvent & event);

			TDlog**		fDialog;

			/** internal */
			bool		fColorModification;

			/** internal */
			CSRLayout *	fLayout;

			/** internal */
			bool		fReadOnly;

		public:
			/**Displays an alert or error message.
			This method will cause a dialog to popup with an alert\error text message.
			@param alert is the alert\error text message.
			*/
			static	void			LogAlert(const char *alert);

			/**Displays a warning message.
			Displays a dialog with a warning symbol, and a text message.
			@param message is the warning text message.
			*/
			static	void			Message(const char *message);

			/// Return values for the ConfirmDialog method
			enum {
				CONFIRM_DIALOG_CANCEL = 1,
				CONFIRM_DIALOG_NO = 2,
				CONFIRM_DIALOG_YES = 3
			};

			/**Displays a confirmation message.
			In Gui displays a dialog with a confirmation message with three buttons (Yes,No and Cancel).
			In API/Batch, shows the message in the log and return 3.
			@param message is the confirmation text message.
			@return the boutton chooses (1 = Cancel, 2 = No, 3 = Yes)
			*/
			static	int				ConfirmDialog(const char* message);

			/**
			* Display a dialog with a combo box offering a choice between items.<br/>
			* @param message Text of the message to be displayed in the dialog, above the combobox.
			* @param title Title of the dialog.
			* @param items Items to be offered as choices in the combobox.
			* @param defaultItem Index of the item selected by default, or -1 if none is to be selected.
			* @return index of the item selected by the user, or -1 if none was selected or if the user clicked on the Cancel button.
			*/
			static int				OptionDialog(const _STL::string& message, const _STL::string& title, const _STL::vector<_STL::string>& items, short defaultItem);

		private:
			/**Displays Interest Rate dialog.
			@deprecated 7.0
			*/
			_SOPHIS_DEPRECATED("Use CSRStaticDataUI::InterestRateDialog instead")
			static	void			InterestRateDialog(long startDate, long endDate, double  discountFactor);
		public:

			/**Displays the content a .TXT file within a dialog.
			@param fileName is the name of the file to display.
			@version 4.5.2
			*/
			static	void			DisplayFile(const char *fileName);

			/**Sends an event on an Instrument.
			@param what is the type of the event.
			@param sicovam is the unique sicovam code of the instrument.
			@return the success result eEventErrorType after sending the event.
			@version 4.5.2
			*/
			static	eEventErrorType	SendCoherencyEvent(eFITEventType what, long sicovam);

			/**Checks if a dialog is open.
			This is called generally before attempting to open the dialog, in order to check that the same dialog is not already open.
			@param infos is the unique set of information about the dialog.
			@param activate is True if to state whether dialog is open.
			@return true if the dialog specified by parameter info is open.
			@version 4.5.2
			*/
			static	bool			IsActiveWindow(CSRUserEditInfo *info, Boolean activate = true);

			/**Returns a pointer to a dialog.
			Given the info about the dialog, the method returns a pointer to the dialog if it is created.
			@param info is the unique information about the dialog.
			@param activate.
			@return a pointer CSRFitDialog to the dialog specified by info if it is created. Returns null otherwise.
			@version 4.5.2
			*/
			static	CSRFitDialog*	GetCSRFitDialog(CSRUserEditInfo *info, Boolean activate = true);

		public:
			// for fixing dialog
			virtual bool AutomaticTicketIsValid() const; // check if valid
			virtual bool AutomaticTicketDone() const; // Oracle Query for fixing
			virtual double GetFixingValue() const;	// fixing value shown in automatic list
			virtual long GetFixingUnderlying() const;	// fixing underlying shown in automatic list
			virtual int GetMvtType() const;	// return the Mouvement Type to use for fixing. default is maFixingUser and can be maFinalFixingUser. @see SphTransferTrade.h

			/**
			 *	Functions called when the dialog got (or lose) the focus.
			 *	By default, they do nothing.
			 */
			virtual void	OnGotFocus();
			virtual void	OnLostFocus();

		public:
			DECLARATION_CASTAGE
		
		private:			

			horsDialogue*fOutsideDialog;
			char		**fFramedElements;

		public:

		// internal methods
			virtual void		InitialiseOracle(Tdescribe *desc,char** read,char** write);		// internal
			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual void		InitialiseOracle(Tdescribe *desc,
												 char** read,
												 char** write,
												 _STL::vector<CSRElement*>& v);

			virtual const char *		InitialiseDialogue(const char* result);							// internal
			virtual void		InitialisePointeur(::infos_user *infosUser);						// internal
			char *		InitialisePointeur( char * result );
			TDlog		*GetDlog(void) const { return (fDialog)?*fDialog:0; }			// internal
			void		SetDlog(TDlog* tdlog);	// internal
			virtual sql::errorCode		ReadQuery(char* result, long code);								// internal
			virtual sql::errorCode		ReadQuery(char* result, long long code);

			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual sql::errorCode		ReadQuery(char* result, _STL::vector<CSRElement*>& v);			
			virtual sql::errorCode		WriteQuery(char* result, long code);							// internal
			virtual sql::errorCode		WriteQuery(char* result, long long code);
			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual sql::errorCode		WriteQuery(char* resultat, _STL::vector<CSRElement*>& v);
			
			virtual sql::errorCode		Historise(long sico, long sico_histo);
			virtual sql::errorCode		HistoDuplicate(long sico, long sico_histo);
			virtual short		Free(char* result);									// internal
			virtual short		Duplicate(char* result);										// interna
			void		InitialiseOther(const CSRFitDialog & dialog);					// internal
			CSRUserEditInfo* GetUserEditInfo() const { return fUserEditInfo; }			// internal
			void		SetUserEditInfo(CSRUserEditInfo* info);
			TDlog*		OpenDialog(Boolean modal=false, short* refNum=0);				// internal
			virtual TDlog*		OpenDialog(Boolean modal, short* refNum, bool modifyColor);				// internal
			bool		IsInternalResource() const	{ return fIsInternalResource;	}	// internal
			virtual sophis::tools::CSRArchive & push (sophis::tools::CSRArchive & , const char * ) const;
			virtual const sophis::tools::CSRArchive & pop (const sophis::tools::CSRArchive & , char *);
			const char * pushDialog (sophis::tools::CSRArchive & , const char * ) const;
			char * popDialog (const sophis::tools::CSRArchive & , char *);
			virtual CSRElement *	GetGlobalElementByRelativeId( int relativeId );
			virtual int				GetGlobalElementCount() const;

		// internal methods

		#ifdef SOPHIS_INTERFACE
			friend SOPHIS_INTERFACE eDialogResult ActiveDialog(TDlog *dlog, long resID, int font, int size, bool center, const unsigned char *title, bool inMenu, int selItem, void (*CallBackHandleEvent)(const sophis::event::ISEvent & event));
		#endif
		friend bool ActiveDialogSurcharge(TDlog *dlog, int* resID, short* pRefNum);
		static	void				pOpen(TDlog *dlog);
		static	void				pFitDialogOpen(TDlog *dlog);
		static	void				pOpenAfterInit(TDlog *dlog);
		static	int					pClose(TDlog *dlog);
		static	void				pValid(TDlog *dlog, long numElement);
		static	void				pUpdate(TDlog * dlog);
		static	void				pClobber(TDlog * dlog);


		friend	class ::CSRColleUtilisateur_GUI;
		friend	class CSRElement;

		private:
			//static void API_CallBackHandleEvent(const sophis::event::ISEvent & event);

			static long fNextId;
			static _STL::map<long, CSRFitDialog *> fFitDialogs;
			/*const */long fId;

		public:
			inline int				GetPreSelectedElementID() const { return fEAId_Selected; }

			/** 
			 * Trigger the action callback associated with the element with specified relative id in this dialog, if applicable 
			 * @return true if there was such a callback and its call was successful, false otherwise
			 */
			bool TriggerElementAction(int elementId);

			/**Refreshes the display of all the elements based on their stored value.
			Has the same effect as calling UpdateElement on all elements.
			@version 5.3.5
			*/
			virtual void UpdateAllElements() const;

			long GetId() const { return fId; }
			static CSRFitDialog * GetFitDialog(long id);
		private:
			/*internal use. Modify acivate process*/
			virtual eDialogResult ActiveDialog(TDlog* dlog, bool center,const char* titre, bool inMenu);

		#ifdef __AFXWIN_H__
			_SOPHIS_DEPRECATED("Use CSRFitDialogUI::GetHWND instead") HWND		GetHWND() const;
		#endif
			_SOPHIS_DEPRECATED("Use CSRFitDialogUI::Show instead") void Show();
			_SOPHIS_DEPRECATED("Use CSRFitDialogUI::Hide instead") void Hide();
		};

		/////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////


		/** Class CSRSaveDialog: for a dialog that undertakes a compulsory Save action.
		A dialog derived from CSRSaveDialog will have to override the pure virtual Save() method, to perform its own functions upon saving the dialog's elements' values.
		An example is a main tabs dialog with a list of tabs each of which corresponds to a tab's dialog. The main dialog may susequently call the overridden Save() method of each tab dialog.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSaveDialog : public CSRFitDialog
		{
		public:
			/**Saves data contained in the dialog.
			Pure Virtual method to be overridden.
			Saves values from elements of CSRElement-derived classes referenced by its list CSRFitDialog::fElementList.
			@return True if saving opration is completed successfully.
			@version 4.5.2
			*/
			virtual	bool Save() = 0;
		};


		/** Class ISRGenericTabPage
			This class is an interface used to add the tab page properties to a dialog.
			@see {@link CSRTabPage}
			@see {@link CSRFitDialog}
			@see {@link CSRInstrumentTabPage}
			@version 5.3
		*/
		class SOPHIS_FIT ISRGenericTabPage
		{
		public:
			/**	Virtual destructor.
				@version 5.3
			*/
			virtual ~ISRGenericTabPage();

			/** PURE VIRTUAL.
			Called when leaving a tab page.
			Usually certain verifications are made, such as correctness of data, before leaving the tab.
			@return true if changes to the tab are accepted.
			@version 5.3
			*/
			virtual bool LeavePage()	= 0;

			/** PURE VIRTUAL.
			Called when entering a tab page.
			Setting values\styles to elements of the tab may be performed before entering the tab.
			@return true is all actions taken before entering the tab were successful.
			@version 5.3
			*/
			virtual bool EnterPage()	= 0;

			/** PURE VIRTUAL.
			Called when button pressed is on the toolbar.
			@version 5.3.4
			*/
			virtual void OnToolbarButton(int nId) = 0;

		protected:
			/**	Protected constructor.
				@version 5.3
			*/
			ISRGenericTabPage();
		};

		class CSRTabButton;

		/** Class CSRTabPage: Dialog used as a wrapper, on top of a Tab Button object (see CSRTabButton),
		for the purpose of keeping track of the tab control.
		*
		*	@version 4.5.2
		*	@version 5.3: overload {@link ISRGenericTabPage}.
		*/
		class SOPHIS_FIT CSRTabPage : public CSRFitDialog, public ISRGenericTabPage
		{
		public:
			/**Overloaded Constructor 1.
			Calls base class constructor CSRFitDialog().
			Initialises the Tab Button link fTab to null.
			@version 4.5.2
			*/
			CSRTabPage();

			/**Overloaded Constructor 2.
			Calls base class constructor CSRFitDialog() and initialises the Tab Button.
			Initialises the Tab Button link fTab to an existing tab.
			@param tab is initialised to the pointer fTab, that is the Tab Button that dialog CSRTabPage is built upon.
			@version 4.5.2
			*/
			CSRTabPage(CSRTabButton* tab);

			/**Destructor to be overriden.
			@version 4.5.2
			*/
			virtual ~CSRTabPage();

			/**Returns the Tab Button link member.
			@return pointer to the Tab Button to which the dialog refers.
			@version 4.5.2
			*/
			CSRTabButton* GetTab() const { return fTab; }

			/**Sets the Tab Button link.
			@param tab is a CSRTabButton\CSRTabButton-derived object to which the dialog refers.
			@version 4.5.2
			*/
			void SetTab(CSRTabButton* tab) { fTab = tab; }

			/**Called when leaving a tab page.
			Usually certain verifications are made, such as correctness of data, before leaving the tab.
			@return true if changes to the tab are accepted.
			@version 4.5.2
			@version 5.3: overload the pure virtual {@link ISRGenericTabPage::LeavePage}
			*/
			virtual bool LeavePage();

			/**Called when entering a tab page.
			Setting values\styles to elements of the tab may be performed before entering the tab.
			@return true is all actions taken before entering the tab were successful.
			@version 4.5.2
			@version 5.3: overload the pure virtual {@link ISRGenericTabPage::EnterPage}
			*/
			virtual bool EnterPage();

			/** default implementation for the ISRGenericTabPage::OnToolbarButton
			Called when button is pressed on the toolbar.
			@version 5.3.4
			*/
			virtual void OnToolbarButton(int nId);

			/**Called by the the HelpAction function of the wizard.
			@version 4.5.2
			*/
			virtual void HelpAction();

		protected:
			/**Link to the wrapped Tab object.
			@version 4.5.2
			*/
			CSRTabButton* fTab;
		};


		namespace CSRDisplayResult
		{
			void SOPHIS_FIT DisplayOutPutResult(const char*							portfolioName,
												const char*							scenarioName,
												const _STL::vector<_STL::string>*	curveNames,
												const _STL::vector<double>&			xcoordinates,
												const _STL::vector<double>&			ycoordinates,
												int									graphicType);

		}

	}
};

#ifdef SOPHIS_INTERFACE
SOPHIS_INTERFACE sophis::gui::eDialogResult	ActiveDialog(TDlog *dlog, long resID, int font, int size, bool center, const unsigned char *title, bool inMenu, int selItem, void (*CallBackHandleEvent)(const sophis::event::ISEvent & event)=0);
#endif


SPH_EPILOG



#endif
