#ifndef _SphDialohArea_H__
#define _SphDialohArea_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphDialog.h"


SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class CSRPopupMenu;

		/** Class CSRDialogArea:
		*	The CSRDialogArea allows the user to specify an area in a dialog box.
		*	This area can manage several CSRFitDialog and switch between them.
		*	Only one CSRFitDialog will be displayed at the same time.
		*
		*	@version 5.0 add the notion of id.
		*	@since 4.6
		*/
		class SOPHIS_FIT CSRDialogArea : public CSRElement
		{
		public:
			/** Constructor.
			The constructor CSRDialogArea::CSRDialogArea() calls the constructor CSRElement::CSRElement() by handing over
			the parameters dialogParent and ERId_Element.
			*/
			CSRDialogArea(CSRFitDialog *dialogParent, int ERId_Element);
			
			/**Destructor.
			*/
			virtual ~CSRDialogArea();
			
			/**Add a Dialog.
			@param id is a unique id of the dialog.
			@param dialog is a CSRFitDialog-derived object of the dialog to add. The CSRDialogArea will be in charge of deleting it.
			@param name is a C String used for the pop-up.
			@version 5.0 Add the id and the name.
			*/
			void AddDialog(long id, CSRFitDialog *dialog, const char * name);
			
			/**Returns a dialog given its 0 based index.
			Returns a pointer to the dialog corresponding to the index or NULL if the index is wrong.
			@param index is 0 based index of a dialog in the CSRDialogArea.
			@return a pointer to an CSRFitDialog-derived class.
			@version 4.6
			CSRFitDialog* GetDialog(int index);
			*/

			/**Returns a currently displayed dialog.
			Returns a pointer to the current dialog.
			@return a pointer to an CSRFitDialog-derived class.
			@version 4.6
			*/
			CSRFitDialog* GetCurrentDialog();

			/**Change the displayed dialog given by index.
			Do nothing if the index is wrong
			@param id is the id of the dialog in the CSRDialogArea.
			@see AddDialog
			@version 5.0 Two Switch by item and dialog.
			*/
			void SwitchToDialogById(long id);

			/**Change the displayed dialog given its 0 based index.
			Do nothing if the index is wrong
			@see AddDialog
			@version 5.0 Two Switch by item and dialog.
			*/
			void SwitchToDialogByItem(short item);

			/** Creates the popup directly linked with the dialog area.
			It is initialized with the value of fCurrentDialogIndex.
			@since 5.0
			*/
			CSRPopupMenu * CreatePopupMenu(int ERId_Element);
			
			/** Get the id by index in pop-up.
			@param item is the position in the pop-up starting from 0.
			@return the long id associated
			@see AddDialog
			@since 5.0
			*/
			long	GetIdByItem(short item) const;

			/** Retrieve the index in the pop-up from the id.
			@param item the long id.
			@return the position in the pop-up starting from 0.
			@see AddDialog
			@since 5.2
			*/
			short	GetItemById(long id) const;

		protected:
			void	Initialisation(CSRFitDialog *dialog, int &number);				// internal
			unsigned int fCurrentDialogIndex;
			struct LegDialog
			{
				long	fType;
				CSRFitDialog * fDlog;
				_STL::string fName;
			};

			class PopUp;

			typedef _STL::vector<LegDialog> List;
			List fDialogs;
		private:
			static const char * __CLASS__;

		};
	}
}
SPH_EPILOG


#endif