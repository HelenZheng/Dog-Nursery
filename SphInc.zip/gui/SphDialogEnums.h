#ifndef _SphDialogEnums_H_
#define _SphDialogEnums_H_

#include "SphInc/SphMacros.h"


SPH_PROLOG
namespace sophis
{
	namespace gui
	{

		/**The various colors that can be handled by an object of the CSREditList class.
		*	@version 4.5.2
		*/
		enum eTextColorType {
			tcUser,
			tcBlack,
			tcRed,
			tcDarkBlue,
			tcPink,
			tcGreen,
			tcLightBlue,
			tcYellow,
			tcGrey,
			// use (eTextColorType)(tcCurrency + i) where 0 <= i < GetCurrencyCount() for the color of the i-th currency
			tcCurrency 
		};

		/**The various fonts that can be handled by an object of the CSREditList class
		*	@version 4.5.2
		*/
		enum eTextStyleType {
			tsNormal	= 0,
			tsBold		= 1,
			tsItalic	= 2,
			tsUnderline = 4
		//	tsEmboss	= 8,
		//	tsShadow	= 16,
		//	tsCondensed	= 32,
		//	tsExpanded	= 64
		};

		/**The various possible types of templates for the style of a user column.
		*	@version 7.0.0
		*/
		enum eUserColTemplates
		{
			tNone	= -1,
			tPrice,
			tQuantity,
			tString
		};

		/**The various possible types of alignment for the elements of a text.
		*	@version 4.5.2
		*/
		enum eAlignmentType
		{
			aRight	= -1,
			aLeft,
			aCenter
		};

		/**The types of null values that are initializing values.
		*	@version 4.5.2
		*/
		enum eNullValueType {
			nvNoNullValue,
			nvUndefined,
			nvZero,
			nvZeroAndUndefined
		};

		/**The various ways one can quit a modal dialog.
		This is the type of output returned by CSRFitDialog::DoDialog(), when the dialog is closed.
		*/
		enum eDialogResult {
			drProblem=0,
			drCancel,
			drOkNotModified,
			drOkModified,
			drAlternative
		};

		/**The direction of shift of a line on the list.
		*	@version 4.5.2
		*/
		enum eShiftingDirectionType { 
			sdUp=0, 
			sdDown
		};

		/**FO Task Manager*/
		enum eFOTaskManager {
			cFolio,
			cFolioTotal,
			cDeal,
			cDealTotal,
			cPosition,
			cPositionTotal,
			cAction,
			cInstrumentDB,
			cVolatilityDB,
			cYieldCurveDB,
			cCreditRiskDB,
			cCorrelationDB,
			cDealID,
			cDealSico,
			// begin market data
			cInstrument, 
			cVolatility,
			cYieldCurve,
			cCreditRisk,
			cCorrelation,
			foLast
		};

		enum eFOAction {
			uFetchDeals,
			uDealsPreProcessing,
			uFlatView,
			uHierView,
			uLoadCurrencies,
			uConsolidateFolio,
			uFinish,
			uBuildMarginCall,
			uBuildFlatViews,
			uBuildFlatMvts,
			uBuildFlatMvts2,
			uAlloueTViewFolio,
			uResizeHA,
			uMarkPNL,
			uMarkPNLDone,
			uConsolidateResults,
			uConcatMvts,
			uAddExtraPosition,
			uComputeBooks,
			uLoadCommoWorksheet,
			uLast
		};

		const int kInThousands = -1;
		const int kWith0Or1DecimalsPlaces = -2;

	} // namespace gui
}; // namespace sophis

SPH_EPILOG
#endif
