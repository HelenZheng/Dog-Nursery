#pragma once

#ifndef __SphDialogUI_H__
#define __SphDialogUI_H__

#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphDialog.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class SOPHIS_INTERFACE CSRFitDialogUI
		{
		public:
			static HWND GetHWND(const CSRFitDialog& dlg);
			static void Show(CSRFitDialog& dlg);
			static void Hide(CSRFitDialog& dlg);
		private:
			CSRFitDialogUI();
			~CSRFitDialogUI();
			CSRFitDialogUI(const CSRFitDialogUI&);
			CSRFitDialogUI& operator = (const CSRFitDialogUI&);
		};
	}
}
SPH_EPILOG

#endif
