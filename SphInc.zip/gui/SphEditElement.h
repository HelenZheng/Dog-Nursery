#ifndef _SphEditElement_H__
#define _SphEditElement_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/SphPreference.h"
//#include "SphSDBCInc/SphSQLDataTypes.h"// used within definition of ELEM_COMMON_INTERNALS
//#include "SphTools/SphDay.h"
#include "SphInc/static_data/SphCalendar.h"
//DB size for value field for tiers properties
#define SIZE_PROPERTIES_VALUE 140

struct TDlog;

SPH_PROLOG
namespace sophis
{
	namespace tools
	{
		class CSRArchive;// used within definition of ELEM_COMMON_INTERNALS
	}
	namespace static_data 
	{
		class CSRCalendar;
	}

	namespace gui
	{
		/** Class CSREditText:
		*	Listable class designed to enter a text string.
		*	The class CSREditText is an editable text box created to retrieve char strings of a maximum given length.
		*	It stores the text string value in a member pointer.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditText : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditText::CSREditText() first passes on the parameters dialog
			(or list), ERId_Text and columnName to the constructor CSRElement::CSRElement()
			then initialises the fields fMaxCharacterCount and fValue which is the data value
			stored by the element.
			The parameter columnName is used only in model or when deriving a generic security dialog
			(See "How to derive CSRInstrumentDialog"). It is always assumed that the name of all user-created
			fields obey the following pattern : ZZZ_name_of_field where ZZZ stands for the initials
			of the bank.
			@param dialog is a pointer to the dialog to which the CSREditText belongs.
			@param ERId_Text is the relative number of the CSREditText element within the dialog.
			@param maxCharacterCount is the maximum number of characters that can be entered. To initialise fMaxCharacterCount.
			@param value is by default set to 0. The content of this C string will be transfererd to the memory block to which fValue points, whenever fieldInTable is nvZero or a new security is created.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditText(		CSRFitDialog 	*dialog,
								int 			 ERId_Text,
								int 			 maxCharacterCount,
						  const char			*value=0,
						  const char 			*columnName = kUndefinedField,
						  const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Similar to Constructor 1, instead it links the text string element to a CSREditList list.
			@param list is a pointer to the list to which the CSREditText belongs.
			@param CNb_Text is the relative number of the CSREditText element within the list.
			@param maxCharacterCount is the maximum number of characters that can be entered. To initialise fMaxCharacterCount.
			@param value is by default set to 0. The content of this C string will be transfererd to the memory block to which fValue points, whenever fieldInTable is nvZero or a new security is created.
			@param columnName is the user table column name of which the structure must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditText(		CSREditList		*list,
								int 			 CNb_Text,
								int 			 maxCharacterCount,
						  const char			*value=0,
						  const char 			*columnName = kUndefinedField,
						  const char *	tagColonne = kSameAsOracleName);

			/**Frees the memory allocated to the text string member.
			@version 4.5.2
			*/
			~CSREditText();

			/**Reads text string data and stores it in the element.
			The method is used in the case when the text string element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			It reads a text, and copies it to the element's text string member, the element
			being in a list.
			Overriding method may carry out some checkings before copying the value, such as the name must be within
			a set of names, etc.
			@param sourc is the text string to input into the element's text box on the list.
			@param line is the number of the line on the containing CSREditList, onto which text element is located.
			@return true if the text is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Copies a text string from the element to a string destined to display on the list.
			The method is used in the case when the text string element is part of a CSREditList list.
			This is a callback function, called internally by RISQUE.
			It copies the content of the CSREditText's text string into the corresponding cell on the list displayed.
			Overriding method may perform manipulations on the element's string before it is displayed, such as discarding new line
			and tab characters for instance.
			@param dest is a pointer to the string that appears in the cell on the screen.
			@param line is the number of the line on the containing CSREditList, onto which the element's value is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditText text string.
			Method Overloaded.
			By default, the CSRElement parameter has to refer to a CSREditText object. In this case, it does exactly
			what the second overloaded equal operator does, it simply copies the text string of the CSREditText parameter.
			Overriding method assumes that the parameter refers to an object of the same CSREditText-derived class as the class of the calling object, and
			therefore performs instructions in accordance to the type of values of the CSREditText-derived class.
			@param a reference to a CSREditText object from which the text is copied to this element's element.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the text string of another CSREditText element to this CSREditText text string.
			Method Overloaded.
			It simply copies the text string from another text string element.
			@param a CSREditText element from which the text string is copied.
			@version 4.5.2
			*/
			void operator = (const CSREditText&);

			/**Compares the text string of this CSREditText, with the value of another element.
			The parameter must refer to a CSREditText object, the text string of which is compared with
			the text string of the current CSREditText.
			Overriding method similarly assumes that the parameter refers to an object of the same CSREditText-derived class as the class of the
			calling object, and	therefore performs comparison in accordance to the type of values of the CSREditText-derived class.
			@param a reference to a CSREditText object from which the text is compared with this element's text string.
			@return -1 if the method fails to compare, or the result of strcmp() function if it succeeds.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditText.
			Overriding method may check the validity of the new value.
			@param value is the string that will be copied to this CSREditText's text string.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the text string from this CSREditText.
			Method Overloaded.
			Overriding method may do some manipulation on the element's text string before obtaining it.
			@param value is the string to which this element's text string will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the text string element allows to be edited and modified in a list.
			@return true if the CSREditText string can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Imposes that the text string can\cannot be modified.
			If set to "read only", the text element remains active, that is, allows to be copied and receives drag & drops,
			it is however not ediatable.
			@param readOnly is true to impose that the text element can't be modified.
			@version 4.5.2
			*/
			void			SetReadOnly(bool readOnly=true);

			/**Obtains a pointer to the text string value.
			Method Overloaded.
			Unlike the first GetValue(), which copies the value to another string, instead this method returns a pointer
			to the text string value.
			@return a pointer to the string value of this element.
			@version 4.5.2
			*/
			char	*GetValue(void) { return fValue; };

			/**Obtains the maximum number of characters that may be entered in this CSREditText.
			@return the maximum number of characters that can be entered for this element's text string.
			@version 4.5.2
			*/
			int		GetMaxChar(void) { return fMaxCharacterCount; };

			/// Value type as returned by GetElementValue<CSREditText>(CSREditText*)
			typedef _STL::string value_type;

		protected:
			/**Pointer to the text string member of the CSREditText element.
			It is a C string pointer. The size of the memory block allocated to this string is fMaxCharacterCount. The user
			initialises fValue with CSREditText::SetValue() and gets its value with CSREditText::GetValue().
			@version 4.5.2
			*/
			char	*fValue;

			/**The maximum number of characters that can be entered for the string of this element.
			@version 4.5.2
			*/
			int		fMaxCharacterCount;

		public:
			virtual short	DonneFiltre(void) const;							// internal
			virtual	int		DonneTypeTri() const;								// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditText* newCSREditText(CSRGenericForm* pForm, int referenceInForm, int length);

		/** Class CSRStaticText.
		*	Listable class for static text.
		*	This class derives from CSREditText. It is aimed for an elements holding a text string which the user
		*	cannot edit or modify. Such class can be useful for dialogs or lists containing texts for illustration only.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRStaticText : public CSREditText {
		public:
			/**Overloaded Constructor 1.
			Used when included in a dialog. It simply calls base class constructor 1 and passes the same parameters.
			@see CSREditText::CSREditText()
			@param dialog is a pointer to the dialog to which the CSREditText belongs.
			@param ERId_Text is the relative number of the CSREditText element within the dialog.
			@param maxCharacterCount is the maximum number of characters that can be entered. To initialise fMaxCharacterCount.
			@param value is by default set to 0. The content of this C string will be transfererd to the memory block to which fValue points, whenever fieldInTable is nvZero or a new security is created.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticText(		CSRFitDialog 	*dialog,
								int 			 ERId_Text,
								int 			 maxCharacterCount,
						  const char			*value=0,
						  const char 			*columnName = kUndefinedField,
						  const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2
			Used when included in a list. It simply calls base class constructor 2 and passes the same parameters.
			@see CSREditText::CSREditText()
			@param list is a pointer to the list to which the CSREditText belongs.
			@param CNb_Text is the relative number of the CSREditText element within the list.
			@param maxCharacterCount is the maximum number of characters that can be entered. To initialise fMaxCharacterCount.
			@param value is by default set to 0. The content of this C string will be transferred to the memory block to which fValue points, whenever fieldInTable is nvZero or a new security is created.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticText(		CSREditList		*list,
								int 			 CNb_Text,
								int 			 maxCharacterCount,
						  const char			*value=0,
						  const char 			*columnName = kUndefinedField,
						  const char *	tagColonne = kSameAsOracleName);

			/**Checks if the text string element can be edited in a list.
			This method overrides method CSREditText::CanBeModifiedInAList(). In respect to the definition and purpose of
			CSRStaticText, the method returns false.
			@see CSREditText::CanBeModifiedInAList()
			@return true if the CSREditText string can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

		};

		SOPHIS_FIT CSRStaticText* newCSRStaticText(CSRGenericForm* pForm, int referenceInForm, int length);

		/** Class CSREditLong:
		*	Listable class designed to handle long integer values.
		*	The class CSREditLong is an editable text box created to retrieve long integers with extrema checking.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditLong : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditLong::CSREditLong() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Long and columnName and then initialises the fields fMinimum, fMaximum and fValue.
			The parameter columnName is used only in a model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog"). We shall always assume that the name of all user-created fields obey the following
			pattern : ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditLong belongs.
			@param ERId_Long is the relative number of the CSREditLong in the dialog.
			@param minimum is the minimum value of the long integer. To initialise fMinimum.
			@param maximum is the maximum value of the long integer. To initialise fMaximum.
			@param value is the default value of the member long integer, set to 0. To initialise fValue when columnName is nvZero or when creating a security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the long integer value of 0 represents the non-initialisation of the element's value. @see CSREditLong::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditLong(	CSRFitDialog 	*dialog,
							int 			 ERId_Long,
							long 			 minimum,
							long 			 maximum,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=false,
						const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Similar to constructor 1, excepts that CSREditLong element is contained in a list.
			@param list is a pointer to the editable list to which the long integer column belongs.
			@param CNb_Long is the relative number of the CSLongEditables column.
			@param minimum is the minimum value of the long integer . To initialise fMinimum.
			@param maximum is the maximum value of the long integer . To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue, where the long integer value is stored.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields :
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param unaffectedIsZero is the boolean that indicates whether the long integer value of 0 represents the non-initialisation of the element's value.
			@see CSREditLong::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditLong(	CSREditList		*list,
							int 			 CNb_Long,
							long 			 minimum,
							long 			 maximum,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=true,
						const char *	tagColonne = kSameAsOracleName);

			/**Reads the long integer data and stores it into the element.
			The method is used in the case when the long integer element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			It takes a value, in the form of a C string, converts it and then copies it
			to the element's long integer member.
			This method overrides the base class method, in order to check that the value entered is between the minimum and
			maximum values specified in the constructor.
			@see fMinimum
			@see fMaximum
			@param sourc is the C string form of the long value that is input into the element.
			@param line is the number of the line on the containing CSREditList, onto which data is entered.
			@return true if the value is entered into the element successfully.
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Used to retrieve the element's long integer value, and also set a style to the element.
			This method is needed only if the CSREditLong is embedded into a CSREditList.
			A style is also set to parameter 'style'.
			This method overrides CSRElement::GetDisplayValue(), in order to set a style specific to the long integer type of
			CSREditLong.
			@see CSRElement::GetDisplayValue()
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSREditLong object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful you override it.
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Converts the long integer value from the element to a string to display on the the list.
			The method is used in the case when the CSREditLong element is part of a CSREditList list.
			This is a callback function, called internally by RISQUE.
			@param dest is a pointer to the string that appears in the cell on the screen.
			@param line is the number of the line on the containing CSREditList, onto which the element's value is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditLong long integer.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditLong.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditLong object, from which the long integer is copied.
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the long integer value of another CSREditLong element to this CSREditLong.
			Method Overloaded.
			It simply copies the long integer from another CSREditLong element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditLong object, from which the long integer value is copied.
			*/
					void operator = (const CSREditLong&);

			/**Compares the long integer value of this CSREditLong, with the value of another element.
			It checks that the parameter is referring to a CSREditLong object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditLong object, with which the long integer is compared
			@return the result of subtracting the parameter's value from this CSREditLong value. Returns -1 if the comparison fails to complete.
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new long integer value to this CSREditLong.
			You can override this method to check the validity of the new value.
			@param value is a pointer to the long integer that will be copied to this CSREditLong.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the long integer value from this CSREditLong.
			Method Overloaded.
			@param value is a pointer to a long integer to which this element's value will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list allows to edit and modify the long integer.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditLong value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains a pointer to the long integer value.
			Method Overloaded.
			@return a pointer to the long integer value of this element.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/**Obtains the minimum authorized value of the element.
			@return the minimum value that the element can have.
			*/
			long	GetMinimum(void) { return fMinimum; };

			/**Obtains the maximum authorized value of the element.
			@return the maximum value that the element can have.
			*/
			long	GetMaximum(void) { return fMaximum; };

			/// Value type as returned by GetElementValue<CSREditLong>(CSREditLong*)
			typedef long value_type;

		protected:
			long	fValue;

			/**Minimum authorized value of the element.
			A number smaller than fMinimum will not be allowed by the object. However,
			if fMinimum=fMaximum, extrema checking won't take place. The user initialises fMinimum
			in CSREditLong::CSREditLong() and gets its value with CSREditLong::GetMinimum().
			*/
			long	fMinimum;

			/**Maximum authorized value for the element.
			A number greater than fMaximum will not be allowed by the object. However,
			if fMinimum=fMaximum, extrema checking won't take place. The user initialises fMaximum
			in CSREditLong::CSREditLong() and gets its value with CSREditLong::GetMaximum().
			*/
			long	fMaximum;

			/**Indicator of the initialisation value.
			This is set to true to indicate that if the long integer value is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			*/
			bool	fUnaffectedIsZero;

		public:
			virtual short	DonneFiltre(void) const;					// internal
			virtual	int		DonneTypeTri() const;							// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditLong* newCSREditLong(CSRGenericForm* pForm, int referenceInForm, int min, int max);

		/** Class CSRStaticLong:
		*	Class derives from CSREditLong, it is designed to handle long integer values, that the user cannot edit or modify.
		*	The class is used when there are long integer values that are only intended for illustration on the dialog or list.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRStaticLong : public CSREditLong {
		public:
			/**Overloaded Constructor 1.
			Used when included in a dialog. It simply calls the first CSREditLong::CSREditLong() and passes the same parameters.
			@see CSREditLong::CSREditLong()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticLong(	CSRFitDialog 	*dialog,
							int 			 ERId_Long,
							long 			 minimum,
							long 			 maximum,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=false,
						const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Used when included in a list. It simply calls the first CSREditLong::CSREditLong() and passes the same parameters.
			@see CSREditLong::CSREditLong()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticLong(	CSREditList		*list,
							int 			 CNb_Long,
							long 			 minimum,
							long 			 maximum,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=true,
						const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the element cannot be edited.
			@see CSREditLong::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			*/
			virtual Boolean	CanBeModifiedInAList(void) const { return false; }
		};

		SOPHIS_FIT CSRStaticLong* newCSRStaticLong(CSRGenericForm* pForm, int referenceInForm, int min, int max);
		
		/** Class CSREditLong:
		*	Listable class designed to handle long integer values.
		*	The class CSREditLong is an editable text box created to retrieve long integers with extrema checking.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditLongLong : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditLong::CSREditLong() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Long and columnName and then initialises the fields fMinimum, fMaximum and fValue.
			The parameter columnName is used only in a model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog"). We shall always assume that the name of all user-created fields obey the following
			pattern : ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditLong belongs.
			@param ERId_Long is the relative number of the CSREditLong in the dialog.
			@param minimum is the minimum value of the long integer. To initialise fMinimum.
			@param maximum is the maximum value of the long integer. To initialise fMaximum.
			@param value is the default value of the member long integer, set to 0. To initialise fValue when columnName is nvZero or when creating a security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the long integer value of 0 represents the non-initialisation of the element's value. @see CSREditLong::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditLongLong(	CSRFitDialog 	*dialog,
							int 			 ERId_Long,
							long long minimum,
							long long maximum,
							long long value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=false,
						const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Similar to constructor 1, excepts that CSREditLong element is contained in a list.
			@param list is a pointer to the editable list to which the long integer column belongs.
			@param CNb_Long is the relative number of the CSLongEditables column.
			@param minimum is the minimum value of the long integer . To initialise fMinimum.
			@param maximum is the maximum value of the long integer . To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue, where the long integer value is stored.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields :
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param unaffectedIsZero is the boolean that indicates whether the long integer value of 0 represents the non-initialisation of the element's value.
			@see CSREditLong::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditLongLong(	CSREditList		*list,
							int 			 CNb_Long,
							long long 			 minimum,
							long long 			 maximum,
							long long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=true,
						const char *	tagColonne = kSameAsOracleName);

			/**Reads the long integer data and stores it into the element.
			The method is used in the case when the long integer element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			It takes a value, in the form of a C string, converts it and then copies it
			to the element's long integer member.
			This method overrides the base class method, in order to check that the value entered is between the minimum and
			maximum values specified in the constructor.
			@see fMinimum
			@see fMaximum
			@param sourc is the C string form of the long value that is input into the element.
			@param line is the number of the line on the containing CSREditList, onto which data is entered.
			@return true if the value is entered into the element successfully.
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Used to retrieve the element's long integer value, and also set a style to the element.
			This method is needed only if the CSREditLong is embedded into a CSREditList.
			A style is also set to parameter 'style'.
			This method overrides CSRElement::GetDisplayValue(), in order to set a style specific to the long integer type of
			CSREditLong.
			@see CSRElement::GetDisplayValue()
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSREditLong object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful you override it.
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Converts the long integer value from the element to a string to display on the the list.
			The method is used in the case when the CSREditLong element is part of a CSREditList list.
			This is a callback function, called internally by RISQUE.
			@param dest is a pointer to the string that appears in the cell on the screen.
			@param line is the number of the line on the containing CSREditList, onto which the element's value is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditLong long integer.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditLong.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditLong object, from which the long integer is copied.
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the long integer value of another CSREditLong element to this CSREditLong.
			Method Overloaded.
			It simply copies the long integer from another CSREditLong element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditLong object, from which the long integer value is copied.
			*/
					void operator = (const CSREditLongLong&);

			/**Compares the long integer value of this CSREditLong, with the value of another element.
			It checks that the parameter is referring to a CSREditLong object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditLong object, with which the long integer is compared
			@return the result of subtracting the parameter's value from this CSREditLong value. Returns -1 if the comparison fails to complete.
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new long integer value to this CSREditLong.
			You can override this method to check the validity of the new value.
			@param value is a pointer to the long integer that will be copied to this CSREditLong.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the long integer value from this CSREditLong.
			Method Overloaded.
			@param value is a pointer to a long integer to which this element's value will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list allows to edit and modify the long integer.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditLong value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains a pointer to the long integer value.
			Method Overloaded.
			@return a pointer to the long integer value of this element.
			@version 4.5.2
			*/
			long long	*GetValue(void) { return &fValue; };

			/**Obtains the minimum authorized value of the element.
			@return the minimum value that the element can have.
			*/
			long long	GetMinimum(void) { return fMinimum; };

			/**Obtains the maximum authorized value of the element.
			@return the maximum value that the element can have.
			*/
			long long	GetMaximum(void) { return fMaximum; };

			/// Value type as returned by GetElementValue<CSREditLong>(CSREditLong*)
			typedef long long value_type;

		protected:
			long long	fValue;

			/**Minimum authorized value of the element.
			A number smaller than fMinimum will not be allowed by the object. However,
			if fMinimum=fMaximum, extrema checking won't take place. The user initialises fMinimum
			in CSREditLong::CSREditLong() and gets its value with CSREditLong::GetMinimum().
			*/
			long long	fMinimum;

			/**Maximum authorized value for the element.
			A number greater than fMaximum will not be allowed by the object. However,
			if fMinimum=fMaximum, extrema checking won't take place. The user initialises fMaximum
			in CSREditLong::CSREditLong() and gets its value with CSREditLong::GetMaximum().
			*/
			long long	fMaximum;

			/**Indicator of the initialisation value.
			This is set to true to indicate that if the long integer value is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			*/
			bool	fUnaffectedIsZero;

		public:
			virtual short	DonneFiltre(void) const;					// internal
			virtual	int		DonneTypeTri() const;							// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditLongLong* newCSREditLongLong(CSRGenericForm* pForm, int referenceInForm, long long min, long long max);

		/** Class CSRStaticLong:
		*	Class derives from CSREditLong, it is designed to handle long integer values, that the user cannot edit or modify.
		*	The class is used when there are long integer values that are only intended for illustration on the dialog or list.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRStaticLongLong : public CSREditLongLong {
		public:
			/**Overloaded Constructor 1.
			Used when included in a dialog. It simply calls the first CSREditLong::CSREditLong() and passes the same parameters.
			@see CSREditLong::CSREditLong()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticLongLong(	CSRFitDialog 	*dialog,
							int 			 ERId_Long,
							long long 			 minimum,
							long long 			 maximum,
							long long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=false,
						const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Used when included in a list. It simply calls the first CSREditLong::CSREditLong() and passes the same parameters.
			@see CSREditLong::CSREditLong()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticLongLong(	CSREditList		*list,
							int 			 CNb_Long,
							long long 			 minimum,
							long long 			 maximum,
							long long			 value=0,
					  const char 			*columnName = kUndefinedField,
							bool			 unaffectedIsZero=true,
						const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the element cannot be edited.
			@see CSREditLong::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			*/
			virtual Boolean	CanBeModifiedInAList(void) const { return false; }
		};

		SOPHIS_FIT CSRStaticLongLong* newCSRStaticLongLong(CSRGenericForm* pForm, int referenceInForm, long long min, long long max);

		/** Class CSREditMnemo:	
		*	The class CSREditMnemo class is an editable text box created to retrieve or to display long integers
		*	of the form 'XXXX'. CSREditMnemo can, for instance, be used to enter or to display the code of an exchange
		*	or the code of a market.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditMnemo : public CSREditLong {
		public:
			/**Overloade Constructor 1.
			The constructor CSREditMnemo::CSREditMnemo() passes on to the CSREditLong::CSREditLong() constructor
			the parameters dialog (or list), ERId_Mnemo (or CNb_Mnemo), value and fieldInTable.
			The minimum and maximum values of the long integer (fMinimum, fMaximum) are irrelevant for this class, and therefore set to 0.
			@see CSREditLong::fMinimum
			@see CSREditLong::fMaximum
			The parameter columnName is used only in model or when deriving a generic security dialog
			(See "How to derive CSRInstrumentDialog"). We shall always assume that the name of all user-created
			fields obey the following pattern : ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditMnemo belongs.
			@param ERId_Mnemo is the CSREditMnemo's relative number, within the dialog.
			@param value is the element's long integer default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditMnemo(	CSRFitDialog 	*dialog,
							int 			 ERId_Mnemo,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/**Overloade Constructor 2.
			@param list is a pointer to the editable list to which the long integer column belongs.
			@param CNb_Mnemo is the relative number of the CSREditMnemo column, within the list.
			@param value is the element's long integer default value set to 0. It is used to initialise fValue, the mnemo's value.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
				CODE number(10), security identifier to establish a link with the Sophis table
				NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditMnemo(	CSREditList		*list,
							int 			 CNb_Mnemo,
							long			 value=0,
					  const char 			*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/** Reads the long integer data and stores it into the CSREditMnemo element.
			It is mainly called when the user enters information in the element's text box on the screen.
			Before the long integer value is input into the element, the function expects that the text string
			parameter entered, is of four characters. It checks that source string doesn't contain certain escape sequences
			(such as tab, new line, carriage return, etc).
			@see CSREditLong::StringToValue()
			@param sourc is the C string form of the long value that is input into the element.
			@param line is the number of the line on the containing CSREditList, onto which data is entered.
			@return true if the value is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a long integer value from the CSREditMnemo element to a string to display on the list.
			@see CSREditLong::ValueToString()
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Used to retrieve the CSREditMnemo element's long integer value, and also set a style to the element.
			@see CSREditLong::GetDisplayValue()
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

		public:
			void	Initialisation(CSRFitDialog *dialog, int &number);					// internal
			virtual short	DonneFiltre(void) const;											// internal

		};

		/*
		class CSRFlagPopupMenu : public CSREditLong {
		public:
			CSRFlagPopupMenu(	CSRFitDialog *dialog,
								int 		ERId_Control,
								int			MENUResourceId,
								long		value=0,
						  const char 		*columnName = kUndefinedField);

			virtual	void	Open(void);

			int		GetControlValue();
			int		Menu2Icon(int menuId);
			int		Icon2Menu(int iconId, int MaxMenu);

		protected:
			int	fResourceId;
			int	fERId_Control;
		};
		*/

		/** Class CSREditShort:
		*	The class CSREditShort is an editable text box created to retrieve short integers with extrema checking.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditShort : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditShort::CSREditShort() first passes on the parameters dialog (or list), ERId_Short
			(or CNb_Short) and columnName to the constructor CSRElement::CSRElement() than initialises the fields fMinimum,
			fMaximum and fValue.
			The parameter columnName is used only in model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog"). We shall always assume that the name of all user-created fields obey the following pattern:
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@see CSRElement::CSRElement()
			@param dialog is a pointer to the dialog to which the CSREditShort belongs.
			@param ERId_Short is the relative number of the CSREditShort within the dialog.
			@param minimum is the short integer's floor value. To initialise fMinimum.
			@param maximum is the hort integer's ceiling value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the short integer value of 0 represents the non-initialisation of the element's value.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			@see CSREditShort::fUnaffectedIsZero
			*/
			CSREditShort(		CSRFitDialog 	*dialog,
								int 			 ERId_Short,
								short 			 minimum,
								short 			 maximum,
								short			 value=0,
						  const char 			*columnName = kUndefinedField,
								bool			 unaffectedIsZero=false,
								const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Similar to constructor 1, excepts that CSREditShort element is contained in a list.
			@param list is a pointer to the editable list to which the short integer column belongs.
			@param CNb_Short is the relative number of the CSREditShort's column.
			@param minimum is the floor value. To initialise fMinimum.
			@param maximum is the ceiling value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue, where the short integer's value is stored.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param unaffectedIsZero is the boolean that indicates whether the short integer value of 0 represents the non-initialisation of the element's value.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			@see CSREditShort::fUnaffectedIsZero
			*/
			CSREditShort(		CSREditList		*list,
								int 			 CNb_Short,
								short 			 minimum,
								short 			 maximum,
								short			 value=0,
						  const char 			*columnName = kUndefinedField,
								bool			 unaffectedIsZero=true,
							const char *	tagColonne = kSameAsOracleName);

			/**Reads the short integer data and stores it into the CSREditShort element.
			@see CSREditLong::StringToValue()
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a short integer value from the CSREditShort element to a string to display on the list.
			@see CSREditLong::ValueToString()
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Used to retrieve the element's short integer value, and also set a style to the element.
			@see CSREditLong::GetDisplayValue()
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the value of a CSRElement to this element's short integer.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditShort.
			@see CSREditText::operation=(const CSRElement&)
			@param a CSRElement referring to a CSREditShort object, from which the short integer is copied.
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the short integer value of another CSREditShort element to this CSREditShort.
			Method Overloaded.
			It simply copies the short integer from another CSREditShort element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditShort object, from which the short integer value is copied.
			*/
					void operator = (const CSREditShort&);

			/**Compares the short integer value of this CSREditShort, with the value of another element.
			It checks that the parameter is referring to a CSREditShort object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditShort object, with which the short integer is compared.
			@return the result of subtracting the parameter's value from this CSREditShort value. Returns -1 if the comparison fails to complete.
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new short integer value to this CSREditShort.
			Method you can override to check the validity of the new value.
			@param value is a pointer to the short integer that will be copied to this CSREditShort.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the short integer value from this CSREditShort.
			Method Overloaded.
			@param value is a short integer to which this element's short integer value will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list can edit the short integer.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditShort value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains a pointer to the short integer value.
			Method Overloaded.
			@return a pointer to the short integer value of this element.
			@version 4.5.2
			*/
			short	*GetValue(void) { return &fValue; };

			/**Obtains the minimum authorized value of the CSREditShort element.
			@return the minimum value that the element can have.
			*/
			short	GetMin(void) { return fMinimum; };

			/**Obtains the maximum authorized value of the CSREditShort element.
			@return the maximum value that the element can have.
			*/
			short	GetMax(void) { return fMaximum; };

			/// Value type as returned by GetElementValue<CSREditShort>(CSREditShort*)
			typedef short value_type;

		protected:
			/**Holds the short integer value.
			The user initialises fValue with CSREditShort::SetValue() and gets its value with CSREditShort::GetValue().
			*/
			short	fValue;

			/**A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place. The user initialises
			fMinimum in CSREditShort::CSREditShort() and gets its value with CSREditShort::GetMin().
			*/
			short	fMinimum;

			/**A number greater than fMaximum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking won't take place. The user initialises
			fMaximum in CSREditShort::CSREditShort() and gets its value with CSREditShort::GetMax().
			*/
			short	fMaximum;

			/**Initialisation value indicator.
			This is set to true to indicate that if the short integer value is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			*/
			bool	fUnaffectedIsZero;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal

			ELEM_COMMON_INTERNALS

		};


		class SOPHIS_FIT CSREditTime;

		/** Class CSREditDate:
		*	Listable class derived from CSRElement.
		*	The class CSREditDate is an editable text box designed to handle dates.
		*	The class handles a member value of type long integer, that represent the date in days, that is, the date expressed
		*	as an integer (long) and represents the number of days since a certain fixed date. The fixed date from which the
		*	number of days are counted is specified by the fact whether the date is Relative or Absolute.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditDate : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditDate::CSREditDate() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Date (or CNb_Date) and columnName then initialises the fields fStoreInDays and fValue.
			The parameter columnName used only in a model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog").
			We shall always assume that the name of all user-created fields obeys the following pattern:
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditDate belongs.
			@param ERId_Date is the relative number of the CSREditDate.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
			@param storeInDays is used when initialising fStoreInDays, a field whose value indicates whether the information has been stored in the table under the 'DATE' or under the 'NUMBER' format. Irrelevant if columnName does not exist.
			@param checkDate is a boolean that states whether the date value entered in the element by the user must be validated in accordance with the currency in the dialog or list.
			@see CSREditDate::fCheckDate
			@param defaultValue is a boolean to indicate whether a default value exists for the element's date.
			@see fDefaultValue
			@param relativeDate is a boolean that is true if the element's date value is Relative, false if it is Absolute.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			@see fIsRelativeDate
			*/

			CSREditDate(	CSRFitDialog 	*dialog,
							int 			 ERId_Date,
							long			 value=0,
					  const char 	   		*columnName		= kUndefinedField,
			  				bool 			 storeInDays	= false,
			  				bool			 checkDate		= false,
			  				bool			 defaultValue	= false,
			  				bool			 relativeDate	= false,
							const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Creates the CSREditDate object when it is part of a list.
			@param list is a pointer to the editable list to which the date column belongs.
			@param CNb_Date is the relative number of the CSREditDate.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param storeInDays is used when initialising fStoreInDays, a field of which the value indicates whether the information has been stored in the table under the 'DATE' or under the 'NUMBER' format. Irrelevant if columnName does not exist. By default, date is stored in 'DATE' format.
			@param checkDate is a boolean that states whether the date value entered to the element by the user must be validated in accordance with a certain currency in the dialog.
			@see CSREditDate::fCheckDate
			@param defaultValue is a boolean to indicate whether a default value exist to the element's date.
			@see fDefaultValue
			@param relativeDate is a boolean that is true if the element's date value is Relative, false if it is Absolute.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			@see fIsRelativeDate
			*/
			CSREditDate(	CSREditList		*list,
							int 			 CNb_Date,
							long			 value=0,
					  const char 			*columnName		= kUndefinedField,
			  				bool	 		 storeInDays	= false,
			  				bool			 checkDate		= false,
			  				bool			 defaultValue	= false,
			  				bool			 relativeDate	= false,
						const char *	tagColonne = kSameAsOracleName);

			/**Checks the format of the date.
			Indicates whether the element's date is stored in the table under the format 'DATE' or under format the 'NUMBER'.
			@return true if the date is stored in 'NUMBER' format, false if it is in 'DATE' format.
			@version 4.5.2
			*/
			bool	StoreInDays(void) { return fStoreInDays; }

			/**Sets the Time component of the date.
			@see CSREditDate::fEditTime
			@param editTime is a pointer to a Time object, which will correspond to the time component of this CSREditDate.
			@version 4.5.2
			*/
			void	SetEditTime(CSREditTime* editTime) { fEditTime = editTime; }

			/**Reads the date value that is entered into the element.
			The method is used in the case when the CSREditDate element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			The parameter is a string describing the date. The format of this string depends on settings
			(e.g. 'MM/DD/YYYY' or 'MM/DD/YY' are both valid for US settings). It is converted into a long integer and
			stored in the CSREditDate's date member.
			@param sourc is a date text string that is input into the element on the list.
			@param line is the number of the line on the containing CSREditList, onto which the date element is stored.
			@return true if the date is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts the date from the element to a string to display on the list.
			The method is used in the case when the CSREditDate element is part of a CSREditList list.
			It converts the date stored in the element (fValue) from long integer to a text string for the date in format
			depending on settings (e.g. 'MM/DD/YYYY').
			@param dest is a pointer to the string that appears in the cell on the screen, to where the date is copied.
			@param line is the number of the line on the containing CSREditList, onto which the element's date is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Used to retrieve the element's date value, and also set a style to the element.
			@see CSRElement::GetDisplayValue()
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSREditDate object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if you override it.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the value of a CSRElement to the date of this CSREditDate.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditDate.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDate object, from which the date is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the long integer date value of another CSREditDate element to this CSREditDate.
			Method Overloaded.
			It simply copies the date from another CSREditDate element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditDate object, from which the date value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditDate&);

			/**Compares the date value of this CSREditDate, with the value of another element.
			It checks that the parameter is referring to a CSREditDate object.
			@param a CSRElement referring to a CSREditDate object, with which the date member is compared.
			@return the result of subtracting the parameter's long integer value from this CSREditDate long integer value. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new long integer date value to this CSREditDate.
			@param value is a pointer to the long integer that will be copied to this CSREditDate date.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the date value from this CSREditDate.
			@param value is a pointer to the long integer to which this element's date will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the CSREditDate element's value allows to be edited and modified in a list.
			The function returns true.
			@return true if the CSREditDate date can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Returns the absolute date from a relative date.
			@version 4.5.2
			*/
			static	static_data::SSRelativeDate	AbsoluteDateInRelative(long date);

			/**Returns the relative date from an absolute date.
			@version 4.5.2
			*/
			static	long			RelativedateInAbsolute(static_data::SSRelativeDate date);

			/**Displays the absolute date from a given date.
			@version 4.5.2
			*/
			static	void			DisplayAbsoluteDate(long date);

			/// Value type as returned by GetElementValue<CSREditDate>(CSREditDate*)
			typedef long value_type;

		protected:
			/**Obtains the currency that is tied to the date.
			This method is only used when validation of the date is required (fCheckDate=true).
			By default it does nothing.
			The overriding method will return the currency code, in relation to which the date has to be checked
			and validated. @see CSREditDate::fCheckDate
			When the CSREditDate date is changed, the currency code returned will be used to validate the new date.
			@return the currency code linked to the date. (for example the currency displayed in the same dialog.)
			@see CSREditDateForInstrument::GetCurrencyForDateCheck
			@version 4.5.2
			*/
			virtual	long	GetCurrencyForDateCheck() const;

			/**Obtains the market that is tied to the date.
			This method is only used when validation of the date is required (fCheckDate=true).
			By default it does nothing.
			The overriding method will return the market code, in relation to which (along with the currency) the date
			has to be checked and validated. @see CSREditDate::fCheckDate
			When the CSREditDate date is changed, the market code returned will be used to validate the new date.
			@return the market code linked to the date. (for example the market displayed in the same dialog.)
			@see CSREditDateForInstrument::GetMarketForDateCheck
			@version 4.5.2
			*/
			virtual	long	GetMarketForDateCheck() const;

			/**Obtains the default value of date.
			By default it does nothing.
			Overriding the method will return the default value, in case the user enters no characters in the text box of
			the CSREditDate in the dialog or list.
			@return the default value of the date.
			@version 4.5.2
			*/
			virtual	long	GetDefaultValue() const;

			/**Holds the CSREditDate date stored as a long integer.
			The fValue may be an absolute date (number of days elapsed since 01/01/1904) or a relative date
			(number of days elapsed since a given computation date)	although the user has entered it in the
			classical form (MM/DD/YY) in the CSREditDate.
			@version 4.5.2
			*/
			long	fValue;

			/**Indicates the format of the date value in the database table.
			Informs whether the information has been stored in the table under the 'DATE' or under the 'NUMBER' format.
			The value of fStoreInDays is true if the date is stored in 'NUMBER' format, false if it's in 'DATE' format.
			This member is irrelevant if columnName does not exist.
			The default value is false.
			@version 4.5.2
			*/
			bool	fStoreInDays;

			/** Validates the date, according to a certain Currency.
			Used when the date is tied to a certain Currency.
			When fCheckDate is true, prior to modifying the date by the user, RISQUE checks that the new date entered is valid
			with a currency that is linked to the date. In other words, it first takes the currency and works out the place of
			the currency's market. Then it checks that the date entered is not a holiday in the place of the currency.
			If fCheckDate is false, no such checking is carried out, and the date is recorded in the element.
			@version 4.5.2
			*/
			bool	fCheckDate;

			/**Indicates whether a default value has been specified for the CSREditDate element.
			@version 4.5.2
			*/
			bool	fDefaultValue;

			/**This true if the date is Relative, false if the date is Absolute.
			A date is called "absolute" if the starting point is 01/01/1904. Conversly, any date of which the starting
			point depends on the day on which a computation is being performed will be called "relative".
			@version 4.5.2
			*/
			bool	fIsRelativeDate;

			/**The Time component of the CSREditDate element.
			In some cases, in addition to the date, a time value is also specified on that date.
			@see CSREditTime
			@version 4.5.2
			*/
			CSREditTime	*fEditTime;


		private :
			static long GetCurrencyForDateCheck(TDlog *dlog , long item);
			static long GetMarketForDateCheck(TDlog *dlog , long item);
			static unsigned long GetDefaultValue(TDlog *dlog , long item);
			ElemValue* GetComparableValue(int line) const;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditDate* newCSREditDate(CSRGenericForm* pForm, int referenceInForm, 
			long			value			= 0,
			const char 	   	*columnName		= kUndefinedField,
			bool 			storeInDays	= false,
			bool			checkDate		= false,
			bool			defaultValue	= false,
			bool			relativeDate	= false,
			const char *	tagColonne = kSameAsOracleName);

		/** Class CSRStaticDate:
		*	Class derived from CSREditDate. It is used for handling date values that the user cannot edit or modify,
		*	that is, they are only for illustration.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRStaticDate : public CSREditDate
		{
		public:
			/**Overloaded Constructor 1.
			Passes all parameters to first constructor of CSREditDate.
			@see CSREditDate::CSREditDate.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticDate(	CSRFitDialog 	*dialog,
							int 			 ERId_Date,
							long			 value=0,
					  const char 	   		*columnName		= kUndefinedField,
			  				bool 			 storeInDays	= false,
			  				bool			 checkDate		= false,
			  				bool			 defaultValue	= false,
			  				bool			 relativeDate	= false,
							const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Passes all parameters to first constructor of CSREditDate.
			@see CSREditDate::CSREditDate.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticDate(	CSREditList		*list,
							int 			 CNb_Date,
							long			 value=0,
					  const char 			*columnName		= kUndefinedField,
			  				bool	 		 storeInDays	= false,
			  				bool			 checkDate		= false,
			  				bool			 defaultValue	= false,
			  				bool			 relativeDate	= false,
							const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the date element cannot be edited.
			@see CSREditDate::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			*/
			virtual Boolean CanBeModifiedInAList(void) const;
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRStaticDate);


		/** Class CSRDateTimePicker:
		*	Class derived from CSREditDate. It is used for handling a date/time calendar,
		*
		*	@version 7.1.3
		*/
		class SOPHIS_FIT CSRDateTimePicker : public CSREditDate
		{
		public:

			CSRDateTimePicker(	CSRFitDialog 	*dialog,
							int 			 ERId_Date,
							long			 value=0,
					  const char 	   		*columnName		= kUndefinedField,
							const char *	tagColonne = kSameAsOracleName);


			CSRDateTimePicker(	CSREditList		*list,
							int 			 CNb_Date,
							long			 value=0,
					  const char 			*columnName		= kUndefinedField,
							const char *	tagColonne = kSameAsOracleName);

			void SetPickerIsChecked(bool isChecked);
			bool GetPickerIsChecked();

		protected:
			virtual void Initialisation(CSRFitDialog *dialogue, int &numero) ;
			static unsigned long GetDefaultValueCallBack(TDlog *dlog , long item);
			static bool CheckDateCallback(TDlog *dlog, long item,long newDate); 
			static void PickerIsCheckedCallBack(TDlog *dlog, long item,bool isChecked); 
			virtual bool CheckDate(long newDate); //check date
			long	GetDefaultDate() const ;
		private:
			bool fPickerChecked;
		};

		class SOPHIS_FIT CSREditRelativeDate : public sophis::gui::CSREditDate
		{
		public:
			CSREditRelativeDate(sophis::gui::CSRFitDialog 	*dialog,
								int 						ERId_Date,
								long						value			=0,
								const char 	   				*columnName		= kUndefinedField,
								bool 						storeInDays		= false,
								bool						defaultValue	= false);
			CSREditRelativeDate(sophis::gui::CSREditList	*list,
								int 						CNb_Date,
								long						value			=0,
								const char 	   				*columnName		= kUndefinedField,
								bool 						storeInDays		= false,
								bool						defaultValue	= false);

			virtual Boolean	StringToValue(const char *sourc, int line);
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSREditRelativeDate);

		// ----------------------------------------------------------------------------------------
		// class CSREditPeriod
		// ----------------------------------------------------------------------------------------
		class SOPHIS_COMMODITY_GUI CSREditPeriod : public CSREditText
		{
			int fEndReference;
			char fStringValue[51];
			sophis::static_data::CSRCalendar* fCalendar;
		public:
			typedef long value_type;

			CSREditPeriod(CSREditList* pForm, int startReference, int endReference);
			CSREditPeriod(CSRFitDialog* pForm, int startReference, int endReference);

			virtual short DonneFiltre(void) const;
			virtual void ValueToString(char* dest, int line) const;
			virtual void SetValue(const void* value);
			virtual void GetValue(void* value) const;
			virtual Boolean Validation();
			virtual Boolean StringToValue(const char *sourc, int line);
			
			virtual void SetCalendar(sophis::static_data::CSRCalendar* pCalendar);
		};

		SOPHIS_COMMODITY_GUI CSREditPeriod* newCSREditPeriod(sophis::gui::CSRGenericForm* pForm, int referenceInForm, int endReferenceInForm);


		/** Class CSREditDateTime:
		*	The class CSREditDateTime is an editable text box designed to handle time in type Long Integer.
		*	On the dialog or list, the time is expressed in hours, minutes and maybe seconds.
		*	The time is stored in the member fValue, and is expressed as a long integer. The long integer value	refers to
		*	the number of seconds that ellapsed since the start of the day, that is, since 0 h, 0 minutes, 0 seconds.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditDateTime : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditDateTime::CSREditDateTime() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Date (or CNb_Date) and columnName then initialises the fields: fValue, fShowSeconds, fEditable and fStoreInSeconds.
			The parameter columnName in used only in a model or when deriving a generic security dialog (How to derive
			CSRInstrumentDialog).
			We shall always assume that the name of all user created fields obeys the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditDateTime belongs.
			@param ERId_Date is the relative number of the CSREditDateTime in the dialog.
			@param editable is a boolean that states if the time value can be edited and modified.
			@param storeInSeconds indicates whether the element's time information has been stored in the table under the 'DATE' or under the 'NUMBER' format. Irrelevant if columnName does not exist.
			@param showSeconds is a boolean that indicates whether seconds are to be displayed along with the hours and minutes of the time.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDateTime(CSRFitDialog 	*dialog,
							int 			ERId_Date,
							bool			editable = true,
							bool			storeInSeconds = false,
							Boolean			showSeconds = 0,
							long			value = 0,
					  const char 	   		*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Similar to first constructor, and is used when the CSREditDateTime is part of a list.
			@param list is a pointer to the editable list to which the date column belongs.
			@param CNb_Date is the relative number of the CSREditDateTime in the list.
			@param editable is a boolean that states if the time value can be edited and modified.
			@param storeInSeconds indicates whether the element's time information has been stored in the table under the 'DATE' or under the 'NUMBER' format. Irrelevant if columnName does not exist.
			@param showSeconds is a boolean that indicates whether seconds are to be displayed along with the hours and minutes of the time.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
				CODE number(10), security identifier to establish a link with the Sophis table
				NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDateTime(CSREditList		*list,
							int 			CNb_Date,
							bool			editable = true,
							bool			storeInSeconds = false,
							Boolean			showSeconds = 0,
							long			value = 0,
					  const char 			*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/**Reads the time value and stores it into the element.
			The method is used in the case when the text string element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			The time parameter is in 'HH24:MI:SS' format. It is converted into a long integer and
			stored in the CSREditDateTime::fValue.
			@param sourc is a time text string that is input into the element on the list.
			@param line is the number of the line on the containing CSREditList, onto which the time element is.
			@return true if the time is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts the time from the element to a string to display in the list.
			The method is used in the case when the CSREditDateTime element is part of a CSREditList list.
			It converts the time stored in the element (fValue) from long integer to a text string for the time in format
			'HH24:MI:SS'.
			@param dest is a pointer to the string that appears in the cell on the screen, to where the time is copied.
			@param line is the number of the line on the containing CSREditList, onto which the element's time is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to the time of this CSREditDateTime.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditDateTime.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDateTime object, from which the long integer (fValue) is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the long integer time value of another CSREditDateTime element to this CSREditDateTime.
			Method Overloaded.
			It copies the long integer fValue, fShowSeconds and fEditable from another CSREditDateTime element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditDateTime object, from which the long integer value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditDateTime&);

			/**Compares the time value of this CSREditDateTime, with the value of another element.
			It checks that the parameter is referring to a CSREditDateTime object.
			@param a CSRElement referring to a CSREditDateTime object, with which the time (fValue) is compared.
			@return the result of subtracting the parameter's long integer value from this CSREditDateTime long integer value. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new long integer time value to this CSREditDateTime.
			@param value is a pointer to the long integer that will be copied to CSREditDateTime::fValue.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the time value from this CSREditDateTime.
			@param value is a pointer to the long integer to which this element's time will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the CSREditDateTime element's value allows to be edited and modified in a list.
			The function returns fEditable.
			@return true if the CSREditDateTime time can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The time value.
			This is the number of seconds that ellapsed during the day since time 0 h, 0 minutes, 0 seconds.
			@version 4.5.2
			*/
			long	fValue;

			/**Indicates whether seconds are to be displayed (on the list or dialog) along with the hours and minutes of the time.
			If it is true, then seconds are displayed.
			@version 4.5.2
			*/
			Boolean fShowSeconds;

			/**Indicates whether the time value can be edited and modified by the user.
			@version 4.5.2
			*/
			bool	fEditable;

			/**States how the time information in stored in the database table.
			If it is true, the element's time information is stored in the table under the 'NUMBER' format. In which case,
			the number in the table is the same as fValue, and refers to the number of seconds that ellapsed since the start
			of the day.
			If it is false, then the table simply stores the time in 'DATE' format.
			Irrelevant if CSRElement::fChampDansTable does not exist.
			@version 4.5.2
			*/
			bool	fStoreInSeconds;

		public:
			virtual short	DonneFiltre(void);			// internal
			virtual	int		DonneTypeTri() const;		// internal

			ELEM_COMMON_INTERNALS

		};

		/** Class CSREditDateForInstrument:
		*	Derived from CSREditDate, it is used for elements that handle a date related or linked to a financial instrument.
		*	The CSREditDateForInstrument date element is included within a dialog of type CSRInstrumentDialog, that is, a dialog
		*	for handling and managing an instrument (shares, options,...) (@see CSRInstrumentDialog).
		*	The currency and the market of the dialog's instrument are necessary to this class.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditDateForInstrument : public CSREditDate {
		public:
			/**Overloaded Constructor 1.
			Passes all parameters to first constructor of CSREditDate.
			@see CSREditDate::CSREditDate()
			The constructor sets: fCheckDate to true (@see CSREditDate::fCheckDate),
			no default value exists (@see CSREditDate::fDefaultValue), date value is absolute (@see CSREditDate::fIsRelativeDate).
			The dialog parameter must be a pointer to a CSRInstrumentDialog\CSRInstrumentDialog-derived object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDateForInstrument(	CSRFitDialog 	*dialog,
										int 			 ERId_Date,
										long			 value=0,
								  const char 	   		*columnName = kUndefinedField,
						  				bool 			 storeInDays=false,
										const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Passes all parameters to second constructor of CSREditDate.
			@see CSREditDate::CSREditDate()
			The constructor sets: fCheckDate to true (@see CSREditDate::fCheckDate),
			no default value exists (@see CSREditDate::fDefaultValue), date value is absolute (@see CSREditDate::fIsRelativeDate).
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDateForInstrument(	CSREditList		*list,
										int 			 CNb_Date,
										long			 value=0,
								  const char 			*columnName = kUndefinedField,
						  				bool	 		 storeInDays=false,
										const char *	tagColonne = kSameAsOracleName);

		protected:
			/**Obtains the currency to which the date of CSREditDateForInstrument is tied.
			This method is invoked whenever the user attempts to change the date of the CSREditDateForInstrument on the dialog.
			It first obtains the instrument that handled by the containing CSRInstrumentDialog, and then it seeks the currency
			of this instrument.
			This method allows Risque to check that the date entered is not a holiday in the place where the currency is traded.
			If it finds that the date entered is a bank holiday, and therefore not valid, the newly-entered date is not recorded.
			@see CSREditDate::fCheckDate
			@return the currency code linked to the date, that is, the currency of the instrument handled by the containing dialog.
			@version 4.5.2
			*/
			virtual	long	GetCurrencyForDateCheck() const;

			/**Obtains the market in which the dialog's instrument currency is traded.
			This method is invoked whenever the user attempts to change the date of the CSREditDateForInstrument on the dialog.
			It first obtains the instrument that handled by the containing CSRInstrumentDialog, and then it seeks the market
			of this instrument.
			This method allows Risque to check that the date entered is not a holiday in the place where the market is located.
			If it finds that the date entered is a bank holiday, and therefore not valid, the newly-entered date is not recorded.
			@return the market code linked to the date. (for example the market displayed in the same dialog.)
			@see CSREditDateForInstrument::GetMarketForDateCheck
			@version 4.5.2
			*/
			virtual	long	GetMarketForDateCheck() const;

		public:

		};

		/** Class CSREditTime:
		*	The class is for designing an element that handles a time information.
		*	This class has a similar architecture and purpose as CSREditDateTime, only that CSREditTime stores the time
		*	information in double (Real Number) type.
		*	The interpretation of the time value (fValue) is different than in the case of CSREditDateTime. It all depends
		*	on whether data is strored in seconds (fStoredInSeconds=true) or not. @see CSREditTime::fValue
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditTime : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditTime::CSREditTime() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Time (or CNb_Time) and columnName then initialises the fields: fValue, fShowSeconds, fEditable and fStoreInSeconds.
			The parameter columnName in used only in a model or when deriving a generic security dialog (How to derive
			CSRInstrumentDialog).
			We shall always assume that the name of all user created fields obeys the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditTime belongs.
			@param ERId_Time is the relative number of the CSREditTime in the dialog.
			@param editable is a boolean that states if the time value can be edited and modified.
			@param storeInSeconds indicates whether the element's time information has been stored in the table under the 'DATE' or under the 'NUMBER' format. This parameter also states how the time value (fValue) is interpreted.
			@param showSeconds is a boolean that indicates whether seconds are to be displayed along with the hours and minutes of the time.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditTime(CSRFitDialog 	*dialog,
							int 		ERId_Time,
							bool		editable = true,
							bool		storeInSeconds = false,
							Boolean		showSeconds = 0,
							long		value = 0,
					  const char 	   	*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Links the CSREditTime element to a list.
			@param list is a pointer to the editable list to which the date column belongs.
			@param CNb_Time is the relative number of the CSREditTime in the list.
			@param editable is a boolean that states if the time value can be edited and modified.
			@param storeInSeconds indicates whether the element's time information has been stored in the table under the 'DATE' or under the 'NUMBER' format. This parameter also states how the time value (fValue) is interpreted.
			@param showSeconds is a boolean that indicates whether seconds are to be displayed along with the hours and minutes of the time.
			@param value is used when initialising fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
				CODE number(10), security identifier to establish a link with the Sophis table
				NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditTime(CSREditList		*list,
							int 		CNb_Time,
							bool		editable = true,
							bool		storeInSeconds = false,
							Boolean		showSeconds = 0,
							long		value = 0,
					  const char 		*columnName = kUndefinedField,
					  const char *	tagColonne = kSameAsOracleName);

			/**Reads the time value and stores it into the element.
			The method is used in the case when the text string element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			The time parameter is in 'HH24:MI:SS' format. It is converted into a double and
			stored in the CSREditTime::fValue. The method of conversion depends on fStoreInSeconds.
			@param sourc is a time text string that is input into the element on the list.
			@param line is the number of the line on the containing CSREditList, onto which the time element is located.
			@return true if the time is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts the time from the element to a string to display in the list.
			The method is used in the case when the CSREditTime element is part of a CSREditList list.
			It converts the time stored in the element (fValue) from double to a text string for the time in format
			'HH24:MI:SS'. The method of conversion depends on fStoreInSeconds.
			@param dest is a pointer to the string that appears in the cell on the screen, to where the time is copied.
			@param line is the number of the line on the containing CSREditList, onto which the element's time is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to the time of this CSREditTime.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditTime.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditTime object, from which the double (fValue) is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the time (fValue) of another CSREditTime element to this CSREditTime.
			Method Overloaded.
			It copies the double fValue, fShowSeconds and fEditable from another CSREditTime element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditTime object, from which the double value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditTime&);

			/**Compares the time of this CSREditTime, with the value of another element.
			It checks that the parameter is referring to a CSREditTime object.
			@param a CSRElement referring to a CSREditTime object, with which the time (fValue) is compared.
			@return the result of subtracting the parameter's fValue from this CSREditTime's fValue. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new time value to this CSREditTime.
			@param value is a pointer to a double value that will be copied to CSREditTime::fValue.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the time value from this CSREditTime.
			@param value is a pointer to the double value to which this element's time will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the CSREditTime element's value can be edited and modified in a list.
			The function returns fEditable.
			@return true if the CSREditTime time (fValue) can be edited and modified by the user.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/// Value type as returned by GetElementValue
			typedef double value_type;

		protected:
			/**The value that denotes the time.
			Its interpretation depends on fStoreInSeconds. If time is stored in seconds (fStoreInSeconds=true), the value of fValue
			is the number of seconds passed since the start of the day at 0h, 0 min, 0secs.
			If on the other hand time is not stored in seconds (fStoreInSeconds=false), fValue is a fraction of one day. This fraction
			can therefore determine the number of seconds elapsed since the start of the day.
			@version 4.5.2
			*/
			double	fValue;

			/**Indicates whether seconds are to be displayed (on the list or dialog) along with the hours and minutes of the time.
			If it is true, then seconds are displayed.
			@version 4.5.2
			*/
			Boolean fShowSeconds;

			/**Indicates whether the time value can be edited and modified by the user.
			@version 4.5.2
			*/
			bool	fEditable;

			/**States how the time information in stored in the database table, and also how to interpret fValue.
			It indicates how the time value is expressed in seconds. @see CSREditTime::fValue
			If the element's database table column CSRElement::fChampDansTable exists, it states also in what format the time
			is stored in the database table: if it is true, the element's time information is stored in the table under the
			'NUMBER' format. In which case,	the number in the table is the same as fValue, and refers to the number of seconds
			that ellapsed since the start of the day.
			If it is false, then the table simply stores the time in 'DATE' format.
			@version 4.5.2
			*/
			bool	fStoreInSeconds;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal

			ELEM_COMMON_INTERNALS

		};

		/** Class CSREditDouble:
		*	The class CSREditDouble is an editable text box created to retrieve double-accuracy real numbers.
		*	It deals with both number of decimals and extrema checking.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditDouble : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditDouble::CSREditDouble() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Double (or CNb_Double) and columnName then initialises the fields fNumberOfDecimalPlaces,
			fMinimum, fMaximum, fValue, fUnaffectedIsZero, and fReduceDisplayWidth.
			The parameter columnName is used only by model or when deriving the generic security dialog (See "How to derive CSRInstrumentDialog").
			It must always be assumed that the name of all user-created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which CSREditDouble belongs..
			@param ERId_Double is the CSREditDouble relative number in the dialog.
			@param numberOfDecimalPlaces is the number of decimal plaves in the double to display. To initialise fNumberOfDecimalPlaces.
			@param minimum is the double's minimum value. To initialise fMinimum.
			@param maximum is the double's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDouble::fUnaffectedIsZero
			@param reduceDisplayWidth is to indicate whether to reduce the display width when the fValue is large.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDouble(	CSRFitDialog 		*dialog,
								int 			 ERId_Double,
								int 			 numberOfDecimalPlaces,
								double 			 minimum,
								double 			 maximum,
								double			 value=0,
						  const char 	   		*columnName = kUndefinedField,
								bool			 unaffectedIsZero=false,
								bool			 reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Constructs a CSREditDouble that is part of a list.
			@param list points to the editable list to which the double column belongs.
			@param CNb_Double is the relative number of the CSREditDouble in the list.
			@param decimales is the number of decimal places in the double to display. To initialise fNumberOfDecimalPlaces.
			@param minimum is the double's minimum value. To initialise fMinimum.
			@param maximum is the double's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDouble::fUnaffectedIsZero
			@param reduceDisplayWidth is to indicate whether to reduce the display width when the fValue is large.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDouble(		CSREditList		*list,
								int 			 CNb_Double,
								int 			 numberOfDecimalPlaces,
								double 			 minimum,
								double 			 maximum,
								double			 value=0,
						  const char 			*columnName = kUndefinedField,
								bool			 unaffectedIsZero=true,
								bool			 reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/**Reads the double data value and stores it into the element.
			The method is used in the case when the CSREditDouble element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			It takes the value in the form of a C string, converts it and then copies it to the element's fValue.
			This method checks that value entered is between the minimum and
			maximum values specified in the constructor. @see fMinimum @see fMaximum
			@param sourc is the C string form of the double value that is input into the element on the screen.
			@param line is the number of the line on the containing CSREditList, onto which data is entered.
			@return true if the value is entered into the element successfully.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a double value from the element to a string to display on the list.
			The method is used in the case when the CSREditDouble element is part of a CSREditList list.
			This is a callback function, called internally by RISQUE.
			@param dest is a pointer to the string that appears in the cell on the screen.
			@param line is the number of the line on the containing CSREditList, onto which the element's value is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Used to retrieve the element's double value, and also set a style to the element.
			This method is needed only if the CSREditDouble is embedded into a CSREditList.
			@see CSRElement::GetDisplayValue()
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSREditDouble object for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful you override it.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the value of a CSRElement to this CSREditDouble.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditDouble.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDouble object, from which the double value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the double value of another CSREditDouble element to this CSREditDouble.
			Method Overloaded.
			It simply copies the value from another CSREditDouble element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditDouble object, from which the double value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditDouble&);

			/**Compares the value of this CSREditDouble, with the value of another element.
			It checks that the parameter is referring to a CSREditDouble object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditDouble object, with which the double value is compared.
			@return the result of subtracting the parameter's value from this CSREditDouble value. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditDouble.
			@param value is a pointer to the double that will be copied to fValue of this CSREditDouble.
			@version 4.5.2
			*/

			virtual void	SetSpecialUSFormat(short aFormat);
			virtual short	GetSpecialUSFormat();

			virtual void	SetValue(const void *value);

			/**Copies the value from this CSREditDouble.
			Method Overloaded.
			@param value is a pointer to which this element's fValue will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list can edit and modify the value.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditDouble value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains a pointer to the element's value.
			Method Overloaded.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			double	*GetValue(void) { return &fValue; }

			/**Sets a new number of decimal places for displaying the element's value.
			@see fNumberOfDecimalPlaces
			@param decimales is the new number of decimal places.
			@version 4.5.2
			*/
			void  SetNumberOfDecimalPlaces(short decimales);

			/**Obtains the number of decimal places of the element.
			@see fNumberOfDecimalPlaces
			@return the number of decimal places.
			@version 4.5.2
			*/
			short		GetNumberOfDecimalPlaces(void) { return fNumberOfDecimalPlaces; }

			/**Obtains the minimum authorized value of the element.
			@return the minimum value that the element can have.
			@version 4.5.2
			*/
			double	GetMinimum(void) { return fMinimum; }

			/**Obtains the maximum authorized value of the element.
			@return the maximum value that the element can have.
			@version 4.5.2
			*/
			double	GetMaximum(void) { return fMaximum; }

			/// Value type as returned by GetElementValue<CSREditDouble>(CSREditDouble*)
			typedef double value_type;

		protected:
			/**The double value handled by the CSREditDouble.
			fValue holds the exact value of the double-accuracy real number.
			@version 4.5.2
			*/
			double	fValue;

			/**The number of decimal places displayed.
			It is used when displaying the element's fValue in the text box on the list\dialog.
			This is the number of digits that appear right of the decimal point, on the display.
			@version 4.5.2
			*/
			short		fNumberOfDecimalPlaces;

			/**Smallest authorized value.
			A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking won't take place.
			@version 4.5.2
			*/
			double	fMinimum;

			/**Greatest authorized value.
			A number greater than fMaximum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking won't take place.
			@version 4.5.2
			*/
			double	fMaximum;

			/**Indicator of the initialistion value.
			This is set to true to indicate that if the fValue is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			@version 4.5.2
			*/
			bool	fUnaffectedIsZero;

			/**Indicates whether to reduce the display width when the fValue is large.
			@version 4.5.2
			*/
			bool	fReduceDisplayWidth;

			/**Used for displaying the numbes in US Bond format as 123-19+. Values 0 - Decimal (default), 1 - US32nd, 2 - US64nd
			@version 6.1
			*/
			short	fSpecialUSFormat;


		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditDouble* newCSREditDouble(CSRGenericForm* pForm, int referenceInForm, 
			int numberOfDecimalPlaces,
			double minimum = -1e11,
			double maximum =  1e11, 
			double value = 0);

		/** Class CSRStaticDouble:
		*	Derived from CSREditDouble, the class is designed to handle double values, that the user cannot edit or modify.
		*	The class is used when there are double values that are only intended for illustration on the dialog or list.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRStaticDouble : public CSREditDouble {
		public:
			/**Overloaded Constructor 1.
			Called when the CSRStaticDouble is part of a dialog. It passes all the parameters to first constructor CSREditDouble.
			@see CSREditDouble::CSREditDouble()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticDouble(	CSRFitDialog 	*dialog,
								int 			 ERId_Double,
								int 			 numberOfDecimalPlaces,
								double 			 minimum,
								double 			 maximum,
								double			 value=0.0,
						  const char 	   		*columnName = kUndefinedField,
								bool			 unaffectedIsZero=false,
								bool			 reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Called when the CSRStaticDouble is part of a list. It passes all the parameters to second constructor CSREditDouble.
			@see CSREditDouble::CSREditDouble()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRStaticDouble(	CSREditList*	list,
								int				ERId_Double,
								int				numberOfDecimalPlaces,
								double			minimum,
								double			maximum,
								double			value=0.0,
								const char*		columnName=kUndefinedField,
								bool			unaffectedIsZero=true,
								bool			reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the element cannot be edited.
			@see CSREditDouble::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const { return false; }

		};

		SOPHIS_FIT CSRStaticDouble* newCSRStaticDouble(CSRGenericForm* pForm, int referenceInForm, 
			int numberOfDecimalPlaces = CSRPreference::GetNumberOfDecimalsForPrice(),
			double minimum = -1e11,
			double maximum =  1e11, 
			double value = 0);

		/** Class CSREditFloat:
		*	Class designed to handle a floating type data (holds member fValue of type Float).
		*	The class CSREditFloat is an editable text box created to retrieve real numbers
		*	of the smallest floating type. It deals with both number of decimals and extrema checking.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditFloat : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditFloat::CSREditFloat() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Float (or CNb_Float) and columnName then initialises the fields fNumberOfDecimalPlaces,
			fMinimum, fMaximum, fValue, fUnaffectedIsZero, and fReduceDisplayWidth.
			The parameter columnName is used only by model or when deriving the generic security dialog (How to derive CSRInstrumentDialog).
			It must always be assumed that the name of all user created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which CSREditFloat belongs.
			@param ERId_Float is the CSREditFloat relative number in the dialog.
			@param numberOfDecimalPlaces is the number of decimal places in the float to display. To initialise fNumberOfDecimalPlaces.
			@param minimum is the float's minimum value. To initialise fMinimum.
			@param maximum is the float's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the float value equal to 0 represents the non-initialisation of the element's value. @see CSREditFloat::fUnaffectedIsZero
			@param reduceDisplayWidth is to indicate whether to reduce the display width when the fValue is large.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditFloat(		CSRFitDialog 	*dialog,
								int 			 ERId_Float,
								int 			 numberOfDecimalPlaces,
								float 			 minimum,
								float 			 maximum,
								float 			 value=0,
						  const char 	   	 	*columnName = kUndefinedField,
								bool			 unaffectedIsZero=false,
								bool			 reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Constructs a CSREditFloat that is part of a list.
			@param list points to the editable list to which the float column belongs.
			@param CNb_Float is the relative number of the CSREditFloat in the list.
			@param decimales is the number of decimal places in the float to display. To initialise fNumberOfDecimalPlaces.
			@param minimum is the float's minimum value. To initialise fMinimum.
			@param maximum is the float's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields :
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@param unaffectedIsZero is the boolean that indicates whether the float value equal to 0 represents the non-initialisation of the element's value. @see CSREditFloat::fUnaffectedIsZero
			@param reduceDisplayWidth is to indicate whether to reduce the display width when the fValue is large.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditFloat(		CSREditList		*list,
								int 			 CNb_Float,
								int 			 numberOfDecimalPlaces,
								float 			 minimum,
								float 			 maximum,
								float 			 value=0,
						  const char 			*columnName = kUndefinedField,
								bool			 unaffectedIsZero=true,
								bool			 reduceDisplayWidth=false,
								const char *	tagColonne = kSameAsOracleName);

			/**Reads the float data value and stores it into the element's fValue.
			The method is used in the case when the CSREditFloat element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			This method checks that value entered is between the minimum and
			maximum values specified in the constructor. @see fMinimum @see fMaximum
			@param sourc is the C string form of the float value that is input into the element.
			@param line is the number of the line on the containing CSREditList, onto which the CSREditFloat element is.
			@return true if the value is entered into the element successfully.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts the float value from the element to a string to display on the list.
			The method is used in the case when the CSREditFloat element is part of a CSREditList list.
			This is a callback function, called internally by RISQUE.
			@param dest is a pointer to the string that appears in the cell on the screen.
			@param line is the number of the line on the containing CSREditList, onto which the element's value is sent.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditFloat.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditFloat.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDouble object, from which the float integer is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the float value of another CSREditFloat element to this CSREditFloat.
			Method Overloaded.
			It simply copies the value from another CSREditFloat element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditFloat object, from which the float value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditFloat&);

			/**Compares the value of this CSREditFloat, with the value of another element.
			It checks that the parameter is referring to a CSREditFloat object.
			@see CSREditText::Compare()
			@param a CSRElement referring to a CSREditFloat object, with which the float value is compared
			@return the result of subtracting the parameter's value from this CSREditFloat value. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditFloat.
			@param value is a pointer to the float that will be copied to fValue of this CSREditFloat.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the value from this CSREditFloat.
			Method Overloaded.
			@param value is a pointer to which this element's fValue will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list allows to edit and modify the value.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditFloat value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains a pointer to the element's value.
			Method Overloaded.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			float	*GetValue(void) { return &fValue; }

			/**Obtains the minimum authorized value of the element.
			@return the minimum value that the element can have.
			@version 4.5.2
			*/
			float	GetMinimum(void) { return fMinimum; }

			/**Obtains the maximum authorized value of the element.
			@return the maximum value that the element can have.
			@version 4.5.2
			*/
			float	GetMaximum(void) { return fMaximum; }

			/**Obtains the number of decimal places of the element, that was set by the constructor.
			@see fNumberOfDecimalPlaces
			@return the number of decimal places.
			@version 4.5.2
			*/
			short		GetNumberOfDecimalPlaces(void) { return fNumberOfDecimalPlaces; }

			/// Value type as returned by GetElementValue<CSREditFloat>(CSREditFloat*)
			typedef float value_type;

		protected:
			/**The element's real number in the float type.
			fValue holds the simple-accuracy value. The user initialises fValue with CSREditFloat::SetValue() and
			gets its value with CSREditFloat::GetValue().
			*/
			float	fValue;

			/**Smallest authorized value.
			A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking won't take place.
			@version 4.5.2
			*/
			float	fMinimum;

			/**Greatest authorized value.
			A number greater than fMaximum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking won't take place.
			@version 4.5.2
			*/
			float	fMaximum;

			/**The number of decimal places displayed.
			It is used when displaying the element's fValue in the text box on the list\dialog.
			This is the number of digits that appear right of the decimal point, on the display.
			@version 4.5.2
			*/
			short		fNumberOfDecimalPlaces;

			/**Indicator of the initialistion value.
			This is set to true to indicate that if the fValue is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			@version 4.5.2
			*/
			bool	fUnaffectedIsZero;

			/**Indicates whether to reduce the display width when the fValue is large.
			@version 4.5.2
			*/
			bool	fReduceDisplayWidth;

		public:
			virtual short	DonneFiltre(void) const;	// internal
			virtual	int		DonneTypeTri() const;		// internal

			ELEM_COMMON_INTERNALS

		};

		/** Class CSREditDoublePercent:
		*	Listable class designed to enter a double value representing a Percentage. Handles the symbol '%'.
		*	The class CSREditDoublePercent is an editable text box designed to retrieve double-accuracy real numbers.
		*	As CSREditDouble it performs both number of decimals and extrema checking, in addition to which,
		*	it can also handle the '%' symbol.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditDoublePercent : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditDoublePercent::CSREditDoublePercent() passes on to the constructor CSRElement::CSRElement()
			the parameters dialog (or list), ERId_DoublePercent (or CNb_DoublePourcent) and columnName than initialises the
			fields fNumberOfDecimalPlaces, fMinimum, fMaximum and fValue.
			The parameter columnName is needed only in model or when deriving a generic security dialog (How to derive CSRInstrumentDialog).
			We shall always assume that the name of all user created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which CSREditDoublePercent belongs.
			@param ERId_DoublePercent is the CSREditDouble relative number in the dialog.
			@param decimales is the number of decimal places displayed. To initialise fDecimals.
			@param minimum is the double percentage's minimum value. To initialise fMinimum.
			@param maximum is the double percentage's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName Name of a Sophis Xxx table column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDoublePercent::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDoublePercent(		CSRFitDialog 	*dialog,
										int 			 ERId_DoublePercent,
										int 			 numberOfDecimalPlaces,
										double 			 minimum,
										double 			 maximum,
										sophisTools::SSDoublePct		 value=0,
										const char 	   	*columnName = kUndefinedField,
										bool			 unaffectedIsZero=false,
										const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			For when the CSREditDoublePercent is in a list.
			@param list points to the editable list to which the double percent column belongs.
			@param CNb_DoublePourcent is the relative number of the CSREditDoublePercent.
			@param decimales is the number of decimals displayed. To initialise fDecimals.
			@param minimum is the double percentage's minimum value. To initialise fMinimum.
			@param maximum is the double percentage's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			to which will be added :
				- ZZZ_MyColumn number(x,y), number's value
				- ZZZ_MaColumn_PCT number(1), boolean telling whether the number is in its normal form or expressed as a percentage.
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDoublePercent::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditDoublePercent(		CSREditList		*list,
										int 			 CNb_DoublePourcent,
										int 			 numberOfDecimalPlaces,
										double 			 minimum,
										double 			 maximum,
										sophisTools::SSDoublePct 	 value=0,
								  const char 	   		*columnName = kUndefinedField,
										bool			 unaffectedIsZero=true,
										const char *	tagColonne = kSameAsOracleName);

			/**Reads the double data value (expressed as percentage) and stores it into the element.
			@see CSREditDouble::StringToValue()
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a percentage double value from the element to a string to diaplay on the list.
			@see CSREditDouble::ValueToString()
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditDoublePercent.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditDoublePercent.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDoublePercent object, from which the double value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the double value of another CSREditDoublePercent element to this CSREditDoublePercent.
			Method Overloaded.
			It simply copies the value from another CSREditDoublePercent element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditDoublePercent object, from which the double value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditDoublePercent&);

			/**Compares the value of this CSREditDoublePercent, with the value of another element.
			It checks that the parameter is referring to a CSREditDoublePercent object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditDoublePercent object, with which the double value is compared.
			@return the the difference between the two values. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditDoublePercent.
			@param value is a pointer to the double that will be copied to fValue of this CSREditDoublePercent.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the value from this CSREditDoublePercent.
			Method Overloaded.
			@param value is a pointer to which this element's fValue will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list allows to edit and modify the value.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditDoublePercent value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains the minimum authorized value.
			@see fMinimum
			@return the minimum authorized value.
			@version 4.5.2
			*/
			double	GetMinimum(void) { return fMinimum; }

			/**Obtains the maximum authorized value.
			@see fMaximum
			@return the maximum authorized value.
			@version 4.5.2
			*/
			double	GetMaximum(void) { return fMaximum; }

			/**Obtains the number of decimal places to display.
			@see CSREditDoublePercent::fNumberOfDecimalPlaces
			@version 4.5.2
			*/
			short		GetNumberOfDecimalPlaces(void) { return fNumberOfDecimalPlaces; }

			/// Value type as returned by GetElementValue
			typedef sophisTools::SSDoublePct value_type;

		protected:
			/**Double percentage value handled by the element.
			fValue is of SSDoublePct type. The structure holds the exact value of the double-accuracy number, and a component 'inPercent'
			that indicates whether the value is in pecentage or absolute.
			@see SSDoublePct
			Default value set to 0, which means that inPercent is false (hence the '%' symbol is not handled).
			@version 4.5.2
			*/
			sophisTools::SSDoublePct	fValue;

			/**The minimum authorized value.
			A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 4.5.2
			*/
			double		fMinimum;

			/**The maximum authorized value.
			A number greater than fMaximum won't be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 4.5.2
			*/
			double		fMaximum;

			/**The number of decimal places displayed.
			It is used when displaying the element's fValue in the text box on the list\dialog.
			This is the number of digits that appear right of the decimal point, on the display.
			@version 4.5.2
			*/
			short			fNumberOfDecimalPlaces;

			/**Indicator of the initialistion value.
			This is set to true to indicate that if the fValue is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			@version 4.5.2
			*/
			bool		fUnaffectedIsZero;

		public:
			virtual	void	RequetesEcriture(int numElement,
							char			** updateQuery,
							char			** insertQuery,
							const char		*defaultName = 0);							// internal
			virtual short	DonneFiltre(void) const;											// internal
			virtual	int		DonneTypeTri() const;										// internal

			ELEM_COMMON_INTERNALS

		};

		/** Class CSREditDoubleBasisPoints:
		*	Listable class designed to enter a double value representing a Percentage or Basis Points. 
		*	The class CSREditDoubleBasisPoints is an editable text box designed to retrieve double-accuracy real numbers.
		*	As CSREditDouble it performs both number of decimals and extrema checking
		*
		*	@version 5.3.3
		*/
		class SOPHIS_FIT CSREditDoubleBasisPoints : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditDoubleBasisPoints::CSREditDoubleBasisPoints() passes on to the constructor CSRElement::CSRElement()
			the parameters dialog (or list), ERId_DoubleBasisPoints and columnName then initialises the
			fields fNumberOfDecimalPlaces, fMinimum, fMaximum, fFormat, fShowExtension and fValue.
			The parameter columnName is needed only in model or when deriving a generic security dialog (How to derive CSRInstrumentDialog).
			We shall always assume that the name of all user created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which CSREditDoublePercent belongs.
			@param ERId_DoubleBasisPoints is the CSREditDouble relative number in the dialog.
			@param decimales is the number of decimal places displayed. To initialise fDecimals.
			@param minimum is the double percentage's minimum value. To initialise fMinimum.
			@param maximum is the double percentage's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param format is the display format. False meaning show as percent, true meaning show as basis points (BPS)
			@param show_extension determines if the extension (% or BPS) is to be displayed as well.
			@param columnName Name of a Sophis Xxx table column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDoubleBasisPoints::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSREditDoubleBasisPoints(		CSRFitDialog 	*dialog,
				int 			 ERId_DoubleBasisPoints,
				int 			 numberOfDecimalPlaces,
				double 			 minimum,
				double 			 maximum,
				double			 value=0,
				bool			 format = false,
				bool			 show_extension = false,
				const char 	   	*columnName = kUndefinedField,
				bool			 unaffectedIsZero=false,
				bool			 reduceDisplayWidth=false,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			For when the CSREditDoubleBasisPoints is in a list.
			@param list points to the editable list to which the double percent column belongs.
			@param CNb_DoubleBasisPoints is the relative number of the CSREditDoubleBasisPoints.
			@param decimales is the number of decimals displayed. To initialise fDecimals.
			@param minimum is the double percentage's minimum value. To initialise fMinimum.
			@param maximum is the double percentage's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param format is the display format. False meaning show as percent, true meaning show as basis points (BPS)
			@param show_extension determines if the extension (% or BPS) is to be displayed as well.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			to which will be added :
			- ZZZ_MyColumn number(x,y), number's value
			- ZZZ_MaColumn_PCT number(1), boolean telling whether the number is in its normal form or expressed as a percentage.
			@param unaffectedIsZero is the boolean that indicates whether the double value equal to 0 represents the non-initialisation of the element's value. @see CSREditDoublePercent::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSREditDoubleBasisPoints(		CSREditList		*list,
				int 			 ERId_DoubleBasisPoints,
				int 			 numberOfDecimalPlaces,
				double 			 minimum,
				double 			 maximum,
				double		 	 value=0,
				bool			 format = false,
				bool			 show_extension = false,
				const char 	   		*columnName = kUndefinedField,
				bool			 unaffectedIsZero=true,
				bool			 reduceDisplayWidth=false,
				const char *	tagColonne = kSameAsOracleName);

			/**Reads the double data value (expressed as percentage) and stores it into the element.
			@see CSREditDouble::StringToValue()
			@version 5.3.3
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a percentage double value from the element to a string to display on the list.
			* Take note, that the display string depends on the display format. It could be percent or basis points.
			@see CSREditDouble::ValueToString()
			@version 5.3.3
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditDoubleBasisPoints.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditDoubleBasisPoints.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditDoubleBasisPoints object, from which the double value is copied.
			@version 5.3.3
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the double value of another CSREditDoubleBasisPoints element to this CSREditDoubleBasisPoints.
			Method Overloaded.
			It simply copies the value from another CSREditDoubleBasisPoints element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditDoubleBasisPoints object, from which the double value is copied.
			@version 5.3.3
			*/
			void operator = (const CSREditDoubleBasisPoints&);

			/**Compares the value of this CSREditDoubleBasisPoints, with the value of another element.
			It checks that the parameter is referring to a CSREditDoubleBasisPoints object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditDoubleBasisPoints object, with which the double value is compared.
			@return the the difference between the two values. Returns -1 if the comparison fails to complete.
			@version 5.3.3
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditDoubleBasisPoints.
			@param value is a pointer to the double that will be copied to fValue of this CSREditDoubleBasisPoints.
			@version 5.3.3
			*/
			virtual void	SetValue(const void *value);

			/**Copies the value from this CSREditDoubleBasisPoints.
			Method Overloaded.
			@param value is a pointer to which this element's fValue will be copied.
			@version 5.3.3
			*/
			virtual void	GetValue(void *value) const;

			/**Sets a new number of decimal places for displaying the element's value.
			@see fNumberOfDecimalPlaces
			@param decimales is the new number of decimal places.
			@version 5.3.3
			*/
			void  SetNumberOfDecimalPlaces(short decimales);

			/**Obtains the number of decimal places of the element.
			@see fNumberOfDecimalPlaces
			@return the number of decimal places.
			@version 5.3.3
			*/
			short		GetNumberOfDecimalPlaces(void) { return fNumberOfDecimalPlaces; }

			/**Checks if the element in a list allows to edit and modify the value.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditDoubleBasisPoints value can be edited and modified.
			@version 5.3.3
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains the minimum authorized value.
			@see fMinimum
			@return the minimum authorized value.
			@version 5.3.3
			*/
			double	GetMinimum(void) { return fMinimum; }

			/**Obtains the maximum authorized value.
			@see fMaximum
			@return the maximum authorized value.
			@version 5.3.3
			*/
			double	GetMaximum(void) { return fMaximum; }

			/**Obtains whether extension has to be shown.
			@see CSREditDoubleBasisPoints::fShowExtension
			@version 5.3.3
			*/
			bool	GetShowExtension(void) {return fShowExtension; }

			/**Obtains the display format.
			@see CSREditDoubleBasisPoints::fFormat
			@version 5.3.3
			*/
			bool	GetFormat(void) {return fFormat; }

			/// Value type as returned by GetElementValue
			typedef double value_type;

		protected:
			/**Double percentage value handled by the element.
			Default value set to 0.
			@version 5.3.3
			*/
			double		fValue;

			/**The minimum authorized value.
			A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 5.3.3
			*/
			double		fMinimum;

			/**The maximum authorized value.
			A number greater than fMaximum won't be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 5.3.3
			*/
			double		fMaximum;

			/**The number of decimal places displayed.
			It is used when displaying the element's fValue in the text box on the list\dialog.
			This is the number of digits that appear right of the decimal point, on the display.
			@version 5.3.3
			*/
			short			fNumberOfDecimalPlaces;

			/**Indicator of the initialization value.
			This is set to true to indicate that if the fValue is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			@version 5.3.3
			*/
			bool		fUnaffectedIsZero;

			/**Indicates whether to reduce the display width when the fValue is large.
			@version 5.3.3
			*/
			bool	fReduceDisplayWidth;

			/**Indicator of the display format.
			* This is set to false when display mode is percent, true when display mode is basis points.
			@version 5.3.3
			*/
			bool		fFormat;

			/**Indicator whether extension is to be shown.
			* This is set to false when no extension is displayed, true if display should append % or BPS,
			* depending on fFormat.
			@version 5.3.3
			*/
			bool		fShowExtension;

		public:
			/*
			virtual	void	RequetesEcriture(int numElement,
				char			** updateQuery,
				char			** insertQuery,
				const char		*defaultName = 0);							// internal
				*/
			virtual short	DonneFiltre(void) const;											// internal
			virtual	int		DonneTypeTri() const;										// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSREditDoubleBasisPoints* newCSREditDoubleBasisPoints(CSRGenericForm* pForm, int referenceInForm, 
			int numberOfDecimalPlaces,
			double minimum = -1e11,
			double maximum =  1e11, 
			double value = 0,
			bool format = false,
			bool show_extension = false);


		/** Class CSRStaticDoubleBasisPoints:
		*	Derived from CSREditDoubleBasisPoints, the class is designed to handle double values, that the user cannot edit or modify.
		*	The class is used when there are double values that are only intended for illustration on the dialog or list.
		*
		*	@version 5.3.3
		*/
		class SOPHIS_FIT CSRStaticDoubleBasisPoints : public CSREditDoubleBasisPoints {
		public:
			/**Overloaded Constructor 1.
			Called when the CSRStaticDoubleBasisPoints is part of a dialog. It passes all the parameters to first constructor CSREditDoubleBasisPoints.
			@see CSREditDoubleBasisPoints::CSREditDoubleBasisPoints()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticDoubleBasisPoints(	CSRFitDialog 	*dialog,
				int 			 ERId_Double,
				int 			 numberOfDecimalPlaces,
				double 			 minimum,
				double 			 maximum,
				double			 value=0.0,
				bool			 format = false,
				bool			 show_extension = false,
				const char 	   		*columnName = kUndefinedField,
				bool			 unaffectedIsZero=false,
				bool			 reduceDisplayWidth=false,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Called when the CSRStaticDoubleBasisPoints is part of a list. It passes all the parameters to second constructor CSREditDoubleBasisPoints.
			@see CSREditDoubleBasisPoints::CSREditDoubleBasisPoints()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticDoubleBasisPoints(	CSREditList*	list,
				int				ERId_Double,
				int				numberOfDecimalPlaces,
				double			minimum,
				double			maximum,
				double			value=0.0,
				bool			format = false,
				bool			show_extension = false,
				const char*		columnName=kUndefinedField,
				bool			unaffectedIsZero=true,
				bool			reduceDisplayWidth=false,
				const char *	tagColonne = kSameAsOracleName);

			/**Acknowledges that the element cannot be edited.
			@see CSREditDoubleBasisPoints::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			@version 5.3.3
			*/
			virtual Boolean	CanBeModifiedInAList(void) const { return false; }

		};

		SOPHIS_FIT CSRStaticDoubleBasisPoints* newCSRStaticDoubleBasisPoints(CSRGenericForm* pForm, int referenceInForm, 
			int numberOfDecimalPlaces = -1,
			double minimum = -1e11,
			double maximum =  1e11, 
			double value = 0,
			bool format = false,
			bool show_extension = false);


		class SOPHIS_FIT CSREditDoubleWithLetter : public sophis::gui::CSREditDouble
		{
		public:
			CSREditDoubleWithLetter(	sophis::gui::CSREditList		*list, 
				int 			 CNb_Double, 
				int 			 numberOfDecimalPlaces, 
				double 			 minimum, 
				double 			 maximum, 
				double			 value=0, 
				const char 			*columnName = kUndefinedField,
				bool			 unaffectedIsZero=true,
				bool			 reduceDisplayWidth=true);
			CSREditDoubleWithLetter(	sophis::gui::CSRFitDialog		*list, 
				int 			 CNb_Double, 
				int 			 numberOfDecimalPlaces, 
				double 			 minimum, 
				double 			 maximum, 
				double			 value=0, 
				const char 			*columnName = kUndefinedField,
				bool			 unaffectedIsZero=true,
				bool			 reduceDisplayWidth=true);
			Boolean	StringToValue(const char *sourc, int line);

			short	DonneFiltre(void) const;
		};

		SOPHIS_FIT CSREditDoubleWithLetter* newCSREditDoubleWithLetter(sophis::gui::CSRGenericForm* pForm, int referenceInForm, 
			int numberOfDecimalPlaces = 99,
			double minimum = -1e8,
			double maximum =  1e8, 
			double value = 0);

		/** Class CSREditFloatPercent:
		*	Listable class designed to enter a float value representing a Percentage. Handles the symbol '%'.
		*	The class CSREditFloatPrecent is an editable text box designed to retrieve double-accuracy real numbers.
		*	As CSREditDouble it performs both number of decimals and extrema checking, in addition to which,
		*	it can also handle the '%' symbol.
		*	It is used for similar purposes as CSREditDoublePercent, excepts that it is for float numbers.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSREditFloatPercent : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			The constructor CSREditFloatPercent::CSREditFloatPercent() passes on to the constructor CSRElement::CSRElement() the
			parameters dialog (or list), ERId_FloatPercent (or CNb_FloatPourcent) and columnName than initialises the fields
			fNumberOfDecimalPlaces, fMinimum, fMaximum, fUnaffectedIsZero and fValue.
			The parameter columnName is needed only in model or when deriving a generic security dialog (See "How to derive CSRInstrumentDialog").
			It is always assumed that the name of all user created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which CSFloatPercentEditable belongs.
			@param ERId_FloatPercent is the CSREditFloatPercent relative number in the dialog.
			@param decimales is the number of decimals. To initialise fDecimals.
			@param minimum is the float percent's minimum value. To initialise fMinimum.
			@param maximum is the float percent's maximum value. To initialise fMaximum.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param unaffectedIsZero is the boolean that indicates whether the float value equal to 0 represents the non-initialisation of the element's value. @see CSREditFloatPercent::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditFloatPercent(		CSRFitDialog 	*dialog,
										int 			 ERId_FloatPercent,
										int 			 numberOfDecimalPlaces,
										float 			 minimum,
										float 			 maximum,
										sophisTools::SSFloatPct 		 value=0,
								  const char 	   		*columnName = kUndefinedField,
										bool			 unaffectedIsZero=false,
										const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			@param list  Points to the editable list to which the float percent column belongs.
			@param NRC_FloatPercent Relative number of the CSFloatPercentEditables.
			@param decimales Number of decimals. To initialise fDecimals.
			@param minimum  Float percent's minimum value. To initialise fMinimum.
			@param maximum  Float percent's maximum value. To initialise fMaximum.
			@param value Default value set to 0. To initialise fValue if fieldInTable is nvZero or when creating a new security.
			@param fieldInTable User table column name of which the structure must possess at least the two following fields
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			to which you will add :
				- ZZZ_MyColumn number(x,y), number's value
				- ZZZ_MaColumn_PCT number(1), boolean telling whether the number is in its normal form or expressed as a percentage.
			@param unaffectedIsZero is the boolean that indicates whether the float value equal to 0 represents the non-initialisation of the element's value. @see CSREditFloatPercent::fUnaffectedIsZero
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSREditFloatPercent(		CSREditList		*list,
										int 			 CNb_FloatPourcent,
										int 			 numberOfDecimalPlaces,
										float 			 minimum,
										float 			 maximum,
										sophisTools::SSFloatPct 		 value=0,
								  const char 	   		*columnName = kUndefinedField,
										bool			 unaffectedIsZero=true,
										const char *	tagColonne = kSameAsOracleName);

			/**Reads the float data value (expressed as percentage) and stores it into the element.
			@see CSREditFloat::StringToValue()
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts a percentage float value from the element to a string to display on the list.
			@see CSREditFloat::ValueToString()
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Assigns the value of a CSRElement to this CSREditFloatPercent.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditFloatPercent.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditFloatPercent object, from which the float value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the value of another CSREditFloatPercent element to this CSREditFloatPercent.
			Method Overloaded.
			It simply copies the value from another CSREditFloatPercent element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditFloatPercent object, from which the float value is copied.
			@version 4.5.2
			*/
					void operator = (const CSREditFloatPercent&);

			/**Compares the value of this CSREditFloatPercent, with the value of another element.
			It checks that the parameter is referring to a CSREditFloatPercent object.
			@see CSREditText::Compare
			@param a CSRElement referring to a CSREditFloatPercent object, with which the float value is compared.
			@return the the difference between the two values. Returns -1 if the comparison fails to complete.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new value to this CSREditFloatPercent.
			@param value is a pointer to the float that will be copied to fValue of this CSREditFloatPercent.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Copies the value from this CSREditFloatPercent.
			Method Overloaded.
			@param value is a pointer to which this element's fValue will be copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the element in a list can edit and modify the value.
			By default, the method returns true, that is, the element is editable.
			@return true if the CSREditFloatPercent value can be edited and modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Obtains the minimum authorized value.
			@see fMinimum
			@return the minimum authorized value.
			@version 4.5.2
			*/
			float	GetMinimum(void) { return fMinimum; }

			/**Obtains the maximum authorized value.
			@see fMaximum
			@return the maximum authorized value.
			@version 4.5.2
			*/
			float	GetMaximum(void) { return fMaximum; }

			/**Obtains the number of decimal places to display.
			@see CSREditFloatPercent::fNumberOfDecimalPlaces
			@version 4.5.2
			*/
			short		GetNumberOfDecimalPlaces(void) { return fNumberOfDecimalPlaces; }

			/// Value type as returned by GetElementValue
			typedef sophisTools::SSFloatPct value_type;

		protected:
			/**Float value handled by the element.
			fValue is of SSFloatPct type. It holds the exact value of the double-accuracy number, and a component 'inPercent'
			that indicates whether the value is in pecentage or absolute.
			Default value set to 0, which means that inPercent is false (hence the '%' symbol is not handled).
			@see SSFloatPct
			@version 4.5.2
			*/
			sophisTools::SSFloatPct	fValue;

			/**The minimum authorized value.
			A number smaller than fMinimum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 4.5.2
			*/
			float		fMinimum;

			/**The maximum authorized value.
			A number greater than fMaximum will not be allowed by the object.
			However, if fMinimum=fMaximum, extrema checking will not take place.
			@version 4.5.2
			*/
			float		fMaximum;

			/**The number of decimal places displayed.
			It is used when displaying the element's fValue in the text box on the list\dialog.
			This is the number of digits that appear right of the decimal point, on the display.
			@version 4.5.2
			*/
			short			fNumberOfDecimalPlaces;

			/**Indicator of the initialistion value.
			This is set to true to indicate that if the fValue is equal 0, then it means that the element's
			value is not initialised, in which case the value 0 is not displayed on the text box.
			@version 4.5.2
			*/
			bool		fUnaffectedIsZero;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual	void	RequetesEcriture(int numElement,
							char			** updateQuery,
							char			** insertQuery,
							const char		*defaultName = 0);	// internal

			ELEM_COMMON_INTERNALS

		};

		/** Class CSREditMonth:
		*	Listable class derived from CSRElement.
		*	The class CSREditMonth is an editable text box designed to handle month.
		*	The class handles a member value of type long integer, that represent the date in months, that is, the month expressed
		*	as an integer (long) and represents the number of months since 01/0000.
		*	@version 5.2
		*/
		class SOPHIS_FIT CSREditMonth : public sophis::gui::CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSREditMonth::CSREditMonth() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog (or list), ERId_Month (or CNb_Month) and columnName then initializes the field fValue.
			The parameter columnName used only in a model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog").
			We shall always assume that the name of all user-created fields obeys the following pattern:
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSREditMonth belongs.
			@param ERId_Month is the relative number of the CSREditMonth.
			@param value is used when initializing fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table handled by the CSRXxx object.
			@see CSREditMonth::fCheckMonth
			@param defaultValue is a boolean to indicate whether a default value exists for the element's month.
			@see fDefaultValue
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/

			CSREditMonth(	CSRFitDialog 	*dialog,
				int 			 ERId_Month,
				long			 value=0,
				const char 	   		*columnName		= kUndefinedField,
				bool			 defaultValue	= false,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Creates the CSREditMonth object when it is part of a list.
			@param list is a pointer to the editable list to which the month column belongs.
			@param CNb_Month is the relative number of the CSREditMonth.
			@param value is used when initializing fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name, the structure of which must possess at least the two following fields:
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param defaultValue is a boolean to indicate whether a default value exist to the element's month.
			@see fDefaultValue
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSREditMonth(	CSREditList		*list,
				int 			 CNb_Month,
				long			 value=0,
				const char 			*columnName		= kUndefinedField,
				bool			 defaultValue	= false,
				const char *	tagColonne = kSameAsOracleName);

			/**Reads the month value that is entered into the element.
			The method is used in the case when the CSREditMonth element is part of a CSREditList list.
			It is mainly called when the user enters information in the element's text box on the screen.
			The month in parameter is in 'MM/YYYY' format. It is converted into a long integer and
			stored in the CSREditMonth's month member.
			@param sourc is a month text string that is input into the element on the list.
			@param line is the number of the line on the containing CSREditList, onto which the month element is stored.
			@return true if the month is entered into the element successfully.
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Converts the month from the element to a string to display on the list.
			The method is used in the case when the CSREditMonth element is part of a CSREditList list.
			It converts the month stored in the element (fValue) from long integer to a text string for the month in format
			'MM/YYYY'.
			@param dest is a pointer to the string that appears in the cell on the screen, to where the month is copied.
			@param line is the number of the line on the containing CSREditList, onto which the element's month is sent.
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Used to retrieve the element's month value, and also set a style to the element.
			@see CSRElement::GetDisplayValue()
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSREditMonth object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if you override it.
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the value of a CSRElement to the month of this CSREditMonth.
			Method Overloaded.
			The CSRElement parameter must refer to an object of CSREditMonth.
			@see CSREditText::operaton=(const CSRElement&)
			@param a CSRElement referring to a CSREditMonth object, from which the month is copied.
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the long integer month value of another CSREditMonth element to this CSREditMonth.
			Method Overloaded.
			It simply copies the month from another CSREditMonth element.
			@see CSREditText::operator=(const CSREditText&)
			@param is a reference to a CSREditMonth object, from which the month value is copied.
			*/
			void operator = (const CSREditMonth&);

			/**Compares the month value of this CSREditMonth, with the value of another element.
			It checks that the parameter is referring to a CSREditMonth object.
			@param a CSRElement referring to a CSREditMonth object, with which the month member is compared.
			@return the result of subtracting the parameter's long integer value from this CSREditMonth long integer value. Returns -1 if the comparison fails to complete.
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Assigns a new long integer month value to this CSREditMonth.
			@param value is a pointer to the long integer that will be copied to this CSREditMonth month.
			*/
			virtual void	SetValue(const void *value);

			/**Copies the month value from this CSREditMonth.
			@param value is a pointer to the long integer to which this element's month will be copied.
			*/
			virtual void	GetValue(void *value) const;

			/**Checks if the CSREditMonth element's value allows to be edited and modified in a list.
			The function returns true.
			@return true if the CSREditMonth month can be edited and modified.
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:

			/**Holds the CSREditMonth month stored as a long integer.
			The fValue may be an absolute month (number of months elapsed since 00/0000) or a relative month
			(number of months elapsed since a given computation month)	although the user has entered it in the
			classical form (MM/YYYY) in the CSREditMonth.
			*/
			long	fValue;

			/**Indicates whether a default value has been specified for the CSREditMonth element.
			*/
			bool	fDefaultValue;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal

			ELEM_COMMON_INTERNALS

		};


		/** Class CSRStaticMonth:
		*	Class derived from CSREditMonth. It is used for handling month values that the user cannot edit or modify,
		*	that is, they are only for illustration.
		*
		*	@version 5.2
		*/
		class SOPHIS_FIT CSRStaticMonth : public CSREditMonth
		{
		public:
			/**Overloaded Constructor 1.
			Passes all parameters to first constructor of CSREditMonth.
			@see CSREditMonth::CSREditMonth.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticMonth(	CSRFitDialog 	*dialog,
				int 			 ERId_Month,
				long			 value=0,
				const char 	   		*columnName		= kUndefinedField,
				bool			 defaultValue	= false,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Passes all parameters to first constructor of CSREditMonth.
			@see CSREditMonth::CSREditMonth.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticMonth(	CSREditList		*list,
				int 			 CNb_Month,
				long			 value=0,
				const char 			*columnName		= kUndefinedField,
				bool			 defaultValue	= false,
				const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the month element cannot be edited.
			@see CSREditMonth::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			*/
			virtual Boolean CanBeModifiedInAList(void) const;
		};

		/** Class CSRStaticTime:
		*	Class derived from CSREditTime. It is used for handling time values that the user cannot edit or modify,
		*	that is, they are only for illustration.
		*
		*	@version 5.2.2
		*/
		class SOPHIS_FIT CSRStaticTime : public CSREditTime
		{
		public:
			/**Overloaded Constructor 1.
			Passes all parameters to first constructor of CSREditTime.
			@see CSREditTime::CSREditTime.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticTime(CSRFitDialog 	*dialog,
				int 		ERId_Time,
				bool		storeInSeconds = false,
				Boolean		showSeconds = 0,
				long		value = 0,
				const char 	   	*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Passes all parameters to first constructor of CSREditDate.
			@see CSREditTime::CSREditTime.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			*/
			CSRStaticTime(CSREditList		*list,
				int 		CNb_Time,
				bool		storeInSeconds = false,
				Boolean		showSeconds = 0,
				long		value = 0,
				const char 		*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Aknowledges that the date element cannot be edited.
			@see CSREditTime::CanBeModifiedInAList()
			@return false because the element is static, and cannot be edited and modified.
			*/
			virtual Boolean CanBeModifiedInAList(void) const;
		};
	}
}
SPH_EPILOG
#endif
