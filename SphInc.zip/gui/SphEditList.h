#ifndef _SphEditList_H__
#define _SphEditList_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphGenericForm.h"


#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(map)
#include __STL_INCLUDE_PATH(list)
#include "SphInc/gui/SphColor.h"
#include "SphInc/gui/SphColor.h"
#include "SphSDBCInc/SphSQLDataTypes.h"


class	CSDumpMenu;
class	CSDumpAutoCompletion;
struct	sort_crit;
class	CSRUserEditInfo;
class	URect;
struct	TVFile;
struct	rec_krit;
struct	field_desc;
class	CSRColleUtilisateur_GUI;
class	CSRColleUtilisateur_ToolkitGUI;
class	CSCtxMenu;
class	CSRListCtrlGrille;
class	CSREditListGUI;

SPH_PROLOG
namespace sophis {
	namespace tools {
		class CSRArchive;
	}
	namespace misc	{
		class	CSREvent;
	}
	namespace event {
		class ISEvent;
	}
}

#define kSequencePlusS  ((char*)0)
#define kNoSection  ((char*)-1)

namespace sophis
{
	namespace gui
	{
		/**Structure handling the style, color, and resource icon ID of a cell in the list.
		*	@version 4.5.2
		*/
		struct SSListCellStyle
		{
		public:
			/**
			@see eTextStyleType
			@version 4.5.2
			*/
			sophis::gui::eTextStyleType		style;

			/**
			@see eTextColorType
			@version 4.5.2
			*/
			long			color;

			/**Ressource ID of the icon
			@version 4.5.2
			*/
			short			iconIndex;

			/**
			Cell background color
			@version 5.2.2
			*/
			SSRgbColor		backgroundColor;
			bool			useBackgroundColor;

			/**Constructor.
			Sets all fields to initialized values.
			@version 4.5.2
			*/
			SSListCellStyle() 
			{
				style = tsNormal; 
				color=0; 
				iconIndex=-1; 
				useBackgroundColor = false; 
				backgroundColor = RgbColorMgr::GetWhite(); 
			}
			
			/**Destructor.
			@version 5.2.2
			*/
			~SSListCellStyle() { }
		};


		/** Structure SSColumn:
		The SSColumn structure is column of CSREditList. Any object of this class possesses
		a pointer to a CSRElement and all the information needed to format the column.
		*
		*	@version 4.5.2
		*/
		struct SOPHIS_FIT SSColumn	{
			/** Constructor.
			The SSColumn::SSColumn() constructor initialises the field fColumnWidth (resp. fAlignmentType,
			fColumnName, and fElement ) to 60 (resp. aRight, 0 and 0).
			@version 4.5.2
			*/
			SSColumn(void);

			/**Destructor.
			The SSColumn::~SSColumn() destructor kills the CSRElement to which fElement points.
			It should not be called explicitly, as it will, in due time, automatically be called by CSREditList::~CSREditList().
			@version 4.5.2
			*/
			~SSColumn(void);

			/**Pointer to the CSRElement of a list's column
			@version 4.5.2
			*/
			CSRElement		   *fElement;

			/**Width of the column in pixels.
			fColumnWidth is width in pixels of the column on the screen. It should be when creating the SSColumn structure.
			@version 4.5.2
			*/
			int					fColumnWidth;

			/**Text justification in the column.
			The kind of alignment used when displaying the text depends on the value of fAlignmentType's.
			One sets this value when creating the SSColumn structure.
			@version 4.5.2
			*/
			eAlignmentType		fAlignmentType;

			/**Name of the column.
			fColumnName holds the name of the column. One sets its value when creating the SSColumn structure.
			@version 4.5.2
			*/
			const char		   *fColumnName;
			char				fName[41];
		};

		/** Class designed to handle a list (one or more columns of CSElements) in a dialog.
		*	The CSREditList class enables easy handling of arrays of:
		*	- Elements of an editable list (CSRElement)
		*	- Columns of such elements (SSColumn).
		*	CSREditList being itself a CSRElement, can be embeded in a CSRFitDialog just as any other dialog element can.
		*	This class is a parent class of CSRListArray.
		*
		*	@version 3.1
		*/
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FIT CSREditList : public CSRElement, public CSRGenericForm  {

		protected :
			typedef	_STL::map<int, _STL::string>	TDataColumns;
			typedef _STL::map<int, TDataColumns>	TDataMatrix;

		public:
			/** Constructor.
			CSREditList::CSREditList() passes on to the constructor CSRElement::CSRElement() the parameters
			dialog and ERId_List. It then initialises the fields fTable using tableName, fColumnCount and fColumns both to null.
			The editable list buffer should hold less than displayedLineCount lines. Irrespective of the buffer size,
			the list will always display displayedLineCount.
			@param dialog is a pointer to the dialog to which the list belongs.
			@param ERId_List is the relative number of the editable list as an element.
			@param tableName is the user database table whose structure must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier.
 			@param displayedLineCount is the number of lines to display. Default value set to 100.
			@param sequence is the sequence for the list for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@param section specifies if the sequence has to be encapsulated in a section; the possible values are a string, kSequencePlusS, or kNoSection.
			@version 4.5.2.1 new parameters sequence and section.
			*/
			CSREditList(	CSRFitDialog	*dialog,
							int				ERId_List,
							const char		*tableName = kUndefinedTable,
							int				displayedLineCount = 100,
							const char		*sequence = kSameAsOracleName,
							const char		*section = kSequencePlusS);

			/** Constructor used not within a CSRFitDialog.
			A CSREditList list can be created without a a CSRFitDialog container, that is, on a dialog of its own. It is ideal
			when all that is needed to display is the list grid. In this case member CSRElement::fDialog is set to null.
			Because there is no supporting CSRFitDialog, and thus no CSRElement items that assist with the use of the list, this
			constructor allows you to specify a toolbar, which includes buttons that appear within the application frame whenever
			the CSREditList is displayed. The toolbar provides common controls for the list.
			A list created with this constructor is not modal. Therefore a User Info object is needed to prevent the list from
			being displayed more than once.
			@param toolbar is the identifier of the toolbar resource that is displayed and used along with the list.
			@param tableName is the user database table whose structure must possess at least the two following fields:
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier.
			@param data is the unique User Info of the instance of the list being created. If the user info is found to exist already, then the same list instance is displayed already. This parameter is optional.
			@version 4.5.2
			*/
			CSREditList(	int				toolbar = -1,
							const char		*tableName = kUndefinedTable,
							CSRUserEditInfo	*data = 0);

			/**Frees the memory previously allocated to fColumns, as well as all SQL query strings.
			This destructor being automatically called by CSRFitDialog::~CSRFitDialog(). It should never be -explicitly- called.
			@version 4.5.2
			*/
			virtual ~CSREditList();

			/**Obtains the User Info object of the list.
			See comments on CSREditList::fData.
			@return a pointer to the user info object of the instance of the list.
			@version 4.5.2
			*/
			CSRUserEditInfo* GetUserEditInfo() const { return fData; }

			/**Sets the User Info object for the list.
			@param a pointer to a CSRUserEditInfo object to be attached to the list.
			@version 4.5.2
			*/
			void			SetUserEditInfo(CSRUserEditInfo* info);

			/**Obtains the address stored in fColumns[index].fElement
			This method is useful when it is desired to scan fColumns in order to analyse -or to act on- each of its elements.
			@param index is the index in the arrar fColumns that corresponds to the element being sought.
			@return a pointer to a CSRElement that is stored in 'index' of the array fColumns.
			@version 4.5.2
			*/
			CSRElement		*GetElementByIndex(int index) const;

			/**Obtains an element given its relative ID.
			The method returns a pointer to the editable list's first CSRElement of which the field fElementId is set
			to ERId_Element.
			ERId_Element is the relative number of a column of CSRElement. This number is passed on as a parameter to
			the CSRElement constructor (second form) and is stored in the fElementId field.
			@param ERId_Element is the relative number of the CSRElement sought.
			@return a pointer to the element whose relative ID is ERId_Element.
			@version 4.5.2
			*/
			CSRElement		*GetElementByRelativeId(int ERId_Element) const;

			template <typename element_type>
			element_type* GetElementByRelativeId(int ERId_Element) const {
				CSRElement* pElement = GetElementByRelativeId(ERId_Element);
				if (!pElement) {
					ASSERT(!"No such element"); return NULL;
				}
				element_type* pCastElement = dynamic_cast<element_type*>(pElement);
				if (!pCastElement) {
					ASSERT(!"Wrong element type"); return NULL;
				}
				return pCastElement;	
			}

			/**Obtains the address in fColumns[index], of which a column object SSColumn is stored.
			This method should be used when it is desired to scan fColumns in order to analyse -or to act on- each of
			its SSColumn.
			@param index is the index on the array fColumns, where is stored the sought SSColumn column object.
			@return a pointer to a column object, that is strored in 'index' by array fColumns.
			@version 4.5.2
			*/
			SSColumn		*GetColumnByIndex(int index) const;

			/**Obtains the column of an element given the element's relative ID.
			The method returns a pointer to the first SSColumn of the fColumns array such that the value of the field
			fElementId of the object to which SSColumn::fElement points is equal to ERId_Column.
			ERId_Column is the relative number of the column of CSElements. This number is passed on as a parameter to
			the CSRElement constructor (second form) and is stored in the fElementId field.
			@param ERId_Column is the relative ID of the element of the column being sought.
			@return a pointer to the SSColumn object whose element has a relative id equal ERId_Column.
			@version 4.5.2
			*/
			SSColumn		*GetColumnByRelativeId(int ERId_Column) const;

			int				GetIndexByRelativeId( int ERId_Column ) const;

			/**Returns the number of columns in the list.
			@return the number of columns fColumnCount, which is also the size of array fColumns.
			@version 4.5.2
			*/
			int				GetColumnCount(void) const { return fColumnCount; }

			/**Returns the position of the column of a given name. Returns -1 if no column correspond to this name.
			@return the column position. -1 if not found.
			*/

			virtual int		GetColumnPosition(const char* col_name) const;

			/**Returns the number of lines in the buffer of the list.
			That is, the number of lines that contains data, in the list.
			Overriding method may work out the number of lines in a different way, such as the case when the CSREditList-derived
			list uses a different memory structure (such as an STL vector) to store data of the list.
			The number returned should not be confused with the number of lines displayed fDisplayedLineCount.
			@return actual number of data lines in the list.
			@version 4.5.2
			*/
			virtual int		GetLineCount(void) const;

			/**Returns the number of the current line on the list.
			@return the number of the current line, that is fCurrentLine.
			@version 4.5.2
			*/
			int				GetCurrentLine(void) const { return fCurrentLine; }

			/**Transfers to 'address' the information handled by the CSRElement with relative number 'CNb_Column' in the line 'lineIndex.'
			The method copies the data value in a CSRElement element to an address specified by the user.
			The element is referred to by relative ID 'CNb_Column', and line number 'lineNumber'.
			Warning : 'address' should point to a memory block of the right size. All the CSREditList pointers
			are reinitialised and the information fields are filled with the same values as those of the line
			number lineIndex.
			@param lineIndex is the line on the list, containing the element to be loaded.
			@param CNb_Column is the relative ID of the element being loaded.
			@param address is the address where the element's data value is to be copied.
			@return true if lineIndex is within the range of line numbers in the buffer and the relative ID of the element exists, false otherwise.
			@version 4.5.2
			*/
			virtual Boolean	LoadElement(int lineIndex, int CNb_Column, void *address) const;

			/**Transfers the information handled in 'address' to the CSRElement with relative number 'CNb_Column' in the line 'lineIndex.'
			The method copies the data value in an address specified by the user to a CSRElement element.
			The element is referred to by relative ID 'CNb_Column', and line number 'lineNumber'.
			Warning : 'address' should point to a memory block of the right size. All the CSREditList pointers
			are reinitialised and the information fields are filled with the same values as those of the line
			number lineIndex.
			@param lineIndex is the line on the list, containing the element to overwrite.
			@param CNb_Column is the relative ID of the element being overwrited.
			@param address is the address containing element's data value is to be saved.
			@return true if lineIndex is within the range of line numbers in the buffer and the relative ID of the element exists, false otherwise.
			@version 4.5.1
			*/
			virtual bool	SaveElement(int lineIndex, int CNb_Column, void *address);

			/**Enlarge the number of lines held by a list element.
			As oppose to SetLineCount which recreate the buffer (delete the old one) SaveLineCount enlarge it
			@param newLineCount New number of lines
			@return true if if line number has been modified, false otherwise
			@version 5.1.
			*/
			virtual	bool SaveLineCount(int newLineCount);

			/** Loads the content of the buffer's lineIndexr-th line.
			The method will cause the content of this line in the list's buffer to be stored in the appropriate
			data values of the list's CSElements.
			This method is called in order to set the pointers of the list to any line differing from the current
			line. For instance, if the values stored in the 8th line are needed to calculate the values in
			the 6th line, LoadLine(7) is called before proceeding to the 6th line computations (7=8-1, because
			numbering starts at 0).
			Overriding the method may perform this differently, such as the case when the CSREditList-derived
			list uses a different memory structure (such as an STL vector) to store data of the list.
			@param lineIndex is the number of the line that is to be loaded.
			@return true if lineIndex is within the range of line numbers in the buffer, false otherwise.
			@version 4.5.2
			*/
			virtual Boolean	LoadLine(int lineIndex) const;

			/**Sets\obtains the status of a line on the list.
			Depending on the design of the CSREditList-derived class, you should override the method in
			order to obtain; the style, color, capability to select, capability	to edit, and whether to strike
			through a specific line. The method decides how to set these parameters in order to set the
			characteristics of the line.
			Warning : this method is not called when a line is refreshed. For Update() to take into account
			the changes that may have occured to a line, method RecomputeLineState() is called first.
			@param lineIndex is the number of the line of which the status is sought.
			@param style is a variable that the method set to either; tsNormal, tsBold, tsItalic, or tsUnderline
			@param color is a variable that is set to either tcUser, tcBlack, tcRed, tcDarkBlue, tcPink, tcGreen, tcLightBlue, tcYellow or tcCurrency.
			@param isSelected is a boolean that is set in order to specify whether the line can be selected by the user.
			@param canEdit is a boolean that is set in order to indicate whether the line must be editable.
			@param isStrikedThrough is a boolean that is set in order to specify that the line must appear on the grid with a line stricken through it.
			@version 4.5.2
			*/
			virtual void	GetLineState(	int					lineIndex,
											eTextStyleType		&style,
											eTextColorType		&color,
											Boolean				&isSelected,
											Boolean				&canEdit,
											Boolean				&isStrikedThrough) const;

			/**Saves an item on a line to the buffer.
			The method copies the content of the data value of the CSRElement of the numeroLigne line/CNb_Column column into the list's buffer.
			This is useful for example when a column depends on another column. It allows you to set the value of one dependant column in the buffer and not the others 
			while setting the value of the main column. It is important because at this point (when loading the CSRElements), some CSRElement have not been initialised yet, 
			so saving the whole line updates the rest of the line (Columns whose CSRElement have not been initialised) with garbage info.
			@param lineIndex is number of the line to save.
			@param CNb_Column is the index of the column to save.
			@version 5.3.2
			*/
			void	SaveItem(int numeroLigne, int CNb_Column);

			/**Saves a line to the buffer.
			The method copies the content of the data values of the CSRElements into the list's buffer. It is the reverse
			of what LoadLine does.
			This method may be overriden if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param lineIndex is number of the line to save.
			@version 4.5.2
			*/
			virtual void	SaveLine(int lineIndex);

			/**Sets the buffer size.
			Sets the size of the memory block allocated to the data buffer to: newLineCount lines times the size of one line
			(denoted by fSize), then resets	the buffer's content to nvZero.
			This method initialises/reinitialises the list. Calling this method is the same as killing all the existing lines
			and creating newLineCount new lines.
			You can override the method if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param newLineCount is the new number of lines for the list's buffer.
			@version 4.5.2
			*/
			virtual void	SetLineCount(int newLineCount);

			/**Sets the number of lines displayed.
			@param displayedLineCount is the new number of lines displayed for the list.
			@version 4.5.2
			*/
			virtual void	SetDisplayedLineCount(int displayedLineCount) { fDisplayedLineCount = displayedLineCount;}

			/**Widens the buffer size.
			Allocates more memory to the buffer of the current list.
			Unlike CSREditList::SetLineCount(), this method does not erase the data already in the buffer.
			You can override this method if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param HowManyNewLines is the number of lines by which the size of the buffer will increase.
			@version 4.5.2
			*/
			virtual void	Enlarge(int HowManyNewLines);

			/**Removes a line from the data buffer.
			Removes the line number lineIndex from the buffer of the list. The size of the buffer is reduced likewise.
			This method may be overriden if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param lineIndex is the number of the line to remove.
			@version 4.5.2
			*/
			virtual void	RemoveLine(int lineIndex);

			/**Creates a line in the buffer.
			It inserts a line in the buffer just before the line numbered beforelineIndex.
			The size of the buffer is therefore increased by one line.
			This method may be overriden if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param beforelineIndex is the number of the line before which the new line will be located.
			@version 4.5.2
			*/
			virtual	void	InsertLine(int beforelineIndex);

			/** Swaps the data content between two lines in the buffer.
			You can override this method if in the CSREditList-derived class the data buffer is designed and managed in a different way.
			@param line1 is the number of the line to which content of line2 will be copied.
			@param line2 is the number of the line to which content of line1 will be copied.
			@version 4.5.2
			*/
			virtual void	SwapLines(int line1, int line2);

			/** Responds when the mouse's left-button is double-clicked on a line.
			You can override this method in order to contain instructions performed in response to a mouse double-click
			on a list's line, such as opening a new dialog box or running calculations.
			The method is not called explicitly by the user, it is automatically called in the RISQUE context.
			@param lineNumber is the number of line which is double-clicked.
			@version 4.5.2
			*/
			virtual	void	DoubleClick(int lineNumber);

			/** Responds when the mouse's left-button is double-clicked on a line.
			You can override this method in order to contain instructions performed in response to a mouse double-click
			on a list's line, such as opening a new dialog box or running calculations.
			The method is not called explicitly by the user, it is automatically called in the RISQUE context.
			The method is called after {@link DoubleClick(int lineNumber)}
			@param lineNumber is the number of line which is double-clicked.
			@param columnNumber is the number of column which is double-clicked.
			@version 6.0
			*/
			virtual	void	DoubleClick(int lineNumber, int columnNumber);

			/** Responds when the mouse's right-button is clicked on a line to show a popup menu.
			You can override this method in order to contain instructions performed in response to a mouse double-click
			on a list's line. This is for internal use only as the CSCtxMenu is not published.
			The method is not called explicitly by the user, it is automatically called in the RISQUE context.
			@version 5.0
			*/
			virtual CSCtxMenu*	GetContextMenu(void);

			/**Sets\obtains the style of a cell located by line lineNumber and column colNumber.
			The method handles parameter 'state' to give it a style, color, and a resource icon ID.
			The overriding method makes decisions on how to set characteristics of the cell.
			@param lineNumber is the line on which the cell is located.
			@param colNumber is the number of column under which the cell is contained.
			@param state is an object to which the style, color, and resource icon ID are assigned.
			@version 4.5.2
			*/

			virtual void	GetCellStyle(long lineNumber, long colNumber, SSListCellStyle* state);

			/** Responds to the user's interactive selection of a line.
			You can override this method in order to perform instructions when the user selects a line on the grid.
			For instance, disabling a particular element, or showing a button on the dialog.
			@param lineNumber is the number of the line selected on the grid.
			@version 4.5.2
			*/
			virtual	void	Selection(int lineNumber);

			/**Responds when the user interactively moves selection from a line.
			When the user select a different line while lineNumber is currently selected, the overriding method will
			perform actions in response, such as for instance, hiding a button that is not needed for other lines.
			@param lineNumber is the number of the line from which selection has switched.
			@version 4.5.2
			*/
			virtual	void	LoseSelection(int lineNumber) {};

			/** Checks if Saving is enabled.
			Whenever the "File" menu is selected, method listGetEnable() of the base class CSREditList is invoked,
			which in turn calls EnableSave() to decide whether the "Save" item of the "File" menu should be enabled.
			You can override this method; it will depend on the design and logic of the CSREditList-derived class.
			@return true if Saving is permitted, false otherwise.
			@version 4.5.2
			*/
			virtual bool	EnableSave(void) { return fModified_; }

			/**Checks if Column Configuration is enabled.
			*/
			virtual bool	EnableConfiguration() { return false; }

			/**Checks if up command is enabled.
			*/
			virtual bool	EnableUp() { return false; }

			/**Checks if down command is enabled.
			*/
			virtual bool	EnableDown() { return false; }

			/**Checks if modify command is enabled.
			*/
			virtual bool	EnableModify() { return false; }

			/**Checks if validate command is enabled.
			*/
			virtual bool	EnableValidate() { return false; }
			
			/** Checks if new command is enabled.
			Whenever the "File" menu is selected, method listGetEnable() of the base class CSREditList is invoked,
			which in turn calls EnableNew() to decide whether the "New" item of the "File" menu should be enabled.
			You can override this method; it will depend on the design and logic of the CSREditList-derived class.
			@return true if New is permitted on the edit list, false otherwise.
			@version 5.0
			*/
			virtual bool	EnableNew(void) { return false; }

			/** Checks if new command is enabled.
			Whenever the "File" menu is selected, method listGetEnable() of the base class CSREditList is invoked,
			which in turn calls EnablePaste() to decide whether the "Paste" item of the "File" menu should be enabled.
			You can override this method; it will depend on the design and logic of the CSREditList-derived class.
			Return fPaste(true by default).
			@return true if Paste is permitted on the edit list, false otherwise.
			@version 5.1
			*/
			bool	EnablePaste() {return fPaste;}

			/**Checks if the list has been modified.
			@return true if the list was modified, false otherwise.
			@version 4.5.2
			*/
			bool			IsModified() const { return fModified_; }

			/** Sets the modification state of the list.
			The method changes the state of the list to 'as Modified', or 'as Unmodified', depending on the parameter.
			@param yesno is true when it is intended to state the list as modified, false to state it as unmodified.
			@version 4.5.2
			*/
			void			SetModified(bool yesno=true) { fModified_ = yesno; }

			/**Responds to Saving user action through the menu.
			It is called when the user presses Ctrl+S or selects Save from the File menu.
			The method is automatically called by listDoCmde() of the base class CSREditList.
			The overriding method generally simply saves list's data into the database.
			@version 4.5.2
			*/
			virtual void	CommandSave(void) {}

			/**Responds to Up user action through the menu.
			*/
			virtual void	CommandUp(void) {}

			/**Responds to Down user action through the menu.
			*/
			virtual void	CommandDown(void) {}

			/**Responds to Modify user action through the menu.
			*/
			virtual void	CommandModify(void) {}

			/**Responds to Validate user action through the menu.
			*/
			virtual void	CommandValidate(void) {}
			
			/**Responds to New user action through the menu.
			It is called when the user presses Ctrl+N or selects New from the File menu.
			The method is automatically called by listDoCmde() of the base class CSREditList.
			The overriding method generally simply inserts new line into the list.
			@version 5.0
			*/
			virtual void	CommandNew(void) {}

			/**Responds to New user action through the menu.
			It is called when the user presses Ctrl+U or selects Delete from the Edit menu.
			The method is automatically called by listDoCmde() of the base class CSREditList.
			Default method removes last line in selection from the list.
			The overriding method generally simply removes selected line from the list.
			@version 5.1
			*/
			virtual void	CommandErase(void);
			/**Obtains the number of lines selected and their indexes\numbers.
			When the user selects one or multiple lines, this method is called in order to record
			the number of lines selected, and to return all the selected lines' indexes.
			@param nb is the pointer to the integer to which the number of lines selected will be assigned.
			@return an array of the indexes\numbers of the lines selected.
			@version 4.5.2
			*/
			long*			new_SelectedLineCount(int *nb) const; // To be deleted with []

			/**Obtains the number of lines selected and their indexes\numbers.
			When the user selects one or multiple lines, this method is called in order to record
			Similar to new_SelectedLineCount(), however the indexes returned are in ascending order rather
			than in the order they were selected.
			@param nb is the pointer to the integer to which the number of lines selected will be assigned.
			@return an array of the indexes\numbers of the lines selected.
			@version 5.3
			*/
			long*			new_SortedSelectedLineCount(int *nb) const; // To be deleted with []

			/**Obtains the number of lines selected and their indexes\numbers.
			Similar to new_SelectedLineCount(), however it returns an STL vector template object containing the
			all lines selected.
			The advantage of this method is to avoid extra variables\parameter handling.
			@return an STL vector object containing indexes of lines selected, and whose size is therefore the number of lines selected.
			@version 4.5.2
			*/
			_STL::vector<long>	GetSelectedLines() const;

			/**Refreshes the entire screen of the list.
			Overloaded method.
			@version 4.5.2
			*/
			void			Update(void) const;

			/**Refreshes a single line on the list's screen.
			Overloaded method.
			@param lineIndex is the number of the line to update.
			@version 4.5.2
			*/
			void			Update(int lineIndex) const;

			/**Refreshes a single cell (CSRElement) on the list's screen.
			Overloaded method.
			@param lineIndex is the number of the line on which is the CSRElement cell to update.
			@param CNb_Column is the column number under which is the CSRElement cell to update.
			@version 4.5.2
			*/
			void			Update(int lineIndex,int CNb_Column) const;

			/**Checks if status has changed.
			Tells the CSREditList whether the aspect of a given line (or of a given set of lines) has changed.
			This method should normally be called before calling Update().
			@version 4.5.2
			*/
			void			RecomputeLineState(void) const;

			/**Changes the entire set of columns in the list.
			It assigns a new SSColumn set of columns to the list.
			@param numCols the new number of columns in the list.
			@param numColsLocked the new number of columns in the list that are locked
			@see CSREditList::fLockedColumnCount
			@param newCols is a pointer to the new set of columns for the list.
			@param recomputeSize is a boolean indicating whether or not the member fSize needs to be recomputed.
			fSize should generally be automatically recomputed. A notable exception is when the edit list is using
			CSRElements using offsets.
			@version 4.5.2
			@version 5.3 : fSize is now automatically recomputed if recomputeSize is set at true.
			*/
			void			ChangeColumnStatus(int numCols, int numColsLocked, SSColumn *newCols, bool recomputeSize = true );

			/**Imposes whether sorting (ascending\descending) of the lines on the list must be permitted or not.
			This method is usually called right after creating the list.
			@param autoriser is true if sorting is to be allowed, false if sorting is to be disallowed.
			@version 4.5.2
			*/
			void			AllowSorting(bool autoriser);

			/** Imposes whether or not moving a column by drag and drop is permitted or not.
			This method should be called after the creation of the list (in OpenAfterInit as an example)
			@param allow : true/false to activate/deactivate column moving.
			@version 5.2
			*/
			void			AllowColumnMoving(bool allow);

			/** Checks whether sorting of lines on the list is permitted.
			It is called internally by base class CSREditList, when an attempt to sort lines is made. Returns true by default.
			You should override this method if, for instance, the list prohibits any attempt to sort the lines.
			@return true if sorting of lines is allowed, false otherwise.
			@version 4.5.2
			*/
			virtual bool	CanSort(void) { return true; }

			/** Sorts the editable list.
			Sorts the editable list with respect to the column number CNb_Column. If 'ascending' is
			set to true (which is the case when no parameter is given) lines are sorted in the ascending
			order (increasing sequence). Otherwise, when increassing is set to false, lines are sorted
			in descending order. When the sorting process is over, the list is automatically redisplayed.
			@param CNb_Column is the relative ID of the CSRElement in the column on which sorting is based.
			@param ascending is true if lines are to be sorted in ascending order of values in CNb_Column, false if in descending order.
			@version 4.5.2
			*/
			virtual void    SortGeneral(char** pList, long element_size,long lKeyColumn,int CNb_Column, Boolean ascending = true, int maxNbLignes=-1);
			virtual void	Sort(int CNb_Column, Boolean ascending = true);

			/** Save the size of the column in user pref.
			This must be called in the constructor.
			@param name of the resource al most 256 length.
			@param id of the column in UserPrefSlr.
			@since 4.5.1.1.19
			*/
			void	SetColumnSize(const char * name, long user_column = 'COLO') ;

			/** Displays the list in a window.
			Opens a non-modal window in which the current CSREditList list is displayed in an autonomous way.
			The window title is the one chosen by the overriding virtual method GetWindowName().
			ActivateWindow automatically calls the method Open() of the CSREditList-derived class.
			@version 4.5.2
			*/
			void			ActivateWindow();

			/** Obtains the name of the window.
			When building a non-modal window suited to the current CSREditList, ActivateWindow()
			calls the virtual method GetWindowName() to retrieve the window's name.
			Overriding method sets parameter windowName to the desired string.
			@param windowName is the C string to which the desired window name will be assigned.
			@version 4.5.2
			*/
			virtual	void	GetWindowName(char *windowName) const;

			/** Executes after the value of a CSRElement is modified.
			Method is called internally by base class CSREditList.
			Overriding method performs further instructions after the value of the CSRElement with a given relative ID
			is modified.
			@param whichColumn is the relative ID of the element that is modified.
			@version 4.5.2
			*/
			virtual void	ColumnModification(int whichColumn);

			/**Obtains the Window containing the CSREditList list.
			@return a pointer to the window structure object supporting the list.
			@version 4.5.2
			*/
				USWindow	*GetWindow(void) { return fWindow; }

			/** Imposes whether the list must be resized in the containing dialog.
			@param resize is a boolean; when set to true, it necessitates the list to be resized in the containing dialog.
			@version 4.5.2
			*/
					void	ResizeInDialog(bool resize) { fResizeInDialog = resize; }

			/**Checks if the size of the list is dynamic.
			@see CSREditList::fDynamicSize
			@return true if the size of the list is dynamic, false otherwise.
			@version 4.5.2
			*/
					bool	IsDynamicSize() const { return fDynamicSize; }

			/**Imposes whether the size of the list must be dynamic.
			@see CSREditList::fDynamicSize
			@param onoff is equal to true when it is desired to have a list with a dynamic size.
			@version 4.5.2
			*/
					void	SetDynamicSize(bool onoff=true) { fDynamicSize = onoff; }

			/**Initialises the list.
			Called automatically by fDialog::Open() when executing the dialog, or by ActivateWindow()of base class CSREditList.
			Overriding method includes special instructions executed at the dialog's opening.
			Whenever, one overloads this method, one should not forget to call inherited::Open() in the derived method.
			@version 4.5.2
			*/
			virtual	void	Open(void);

			/** Assigns a CSRElement-derived element to the current list.
			By default, it expects the parameter to be a CSRElement pointer pointing to a CSREditList or a CSREditList-derived
			object. If this is the case, the buffer of the CSREditList-derived element will be pointed to by the buffer of
			the current list.
			You can override the method so that it expects a parameter of some known CSRElement-derived class (which doesn't
			have to be derived from CSREditList), and then assigns values in its own way.
			An example of overriding will be to assign values of elements in a dialog to a line on the list.
			@param is a CSRElement\CSRElement-derived object to which the data buffer will be pointed to by the current list.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns a CSREditList element to the current list.
			The current list's buffer will point to the buffer of the parameter list.
			@param is a CSREditList object with the data buffer which will be pointed to by the current list.
			@version 4.5.2
			*/
					void operator = (const CSREditList&);

			/**Compares the list's data with another CSRElement's data.
			By default, it expects the parameter to be a CSRElement pointer pointing to a CSREditList or a CSREditList-derived
			object. In this case, it compares the data buffer of the list with the parameter's data buffer.
			The overriding method may expects a parameter of some known CSRElement-derived class (which doesn't
			have to be derived from CSREditList), and then compares values in its own way.
			An example of overriding will be to compare values of elements in a dialog with values on a certain a line on the list.
			@param is a CSRElement\CSREditList object with the data buffer which will be pointed to\copied by\to the current list.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/** Responds to receiving a Real-Time event.
			It is called internally by RISQUE.
			You must override this method in order to perform instructions with the list, when an event is received in the list.
			@param event is a pointer to the Real-Time event object received by the list.
			@version 4.5.2
			*/
			virtual void	HandleEvent(const sophis::event::ISEvent & event);

			/**Adds to the list, columns described in database table USERCOLUMN.
			Columns\Additional columns of the list may be specified by the list's database table. Such columns are be defined by database
			table USERCOLUMN, for the list's table.
			For each (additional) column in USERCOLUMN, a CSRElement-derived element is created and added to list.
			The method only applies if a database table is linked to the CSREditList (fTable != kUndefinedTable and not null).
			@return true if there are additional columns defined in table USERCOLUMN for the list's database table.
			@version 4.5.2
			*/
			bool	LoadUserColumns();

			/** Gives a name to a column in the list.
			By default, it takes a SSColumn column object in the list, and assigns a new name to it (in SSColumn::fName).
			In addition, if a database table is linked to the list, then the table's name is also updated within table USERCOLUMN
			that describes columns for each of certain list's tables.
			Overriding the method will may a name in a different way, as required by the user (from an element of a different dialog for instance).
			@param colNumber is the index of the column within arrar fColumns, of which the name is given.
			@param sourc is a C string containing the new name of the column.
			@return false only in the case when a table is linked to the list, it fails to update the column name in USERCOLUMN. In any other case, it will return true.
			@version 4.5.2
			*/
			virtual int		SetHeaderColumnName(long colNumber, char *sourc);

			/**Obtains the name of a column.
			@param colNumber is the index of the column within arrar fColumns, of which the name is to obtain.
			@param sourc is a C string name of the column is copied.
			@version 4.5.2
			*/
			virtual bool	GetHeaderColumnName(long colNumber, char *dest);

			/**Obtains the resource ID of toolbar accompaning the list.
			@see CSREditList::fToolbar
			@return the resource ID of toolbar for the list.
			@version 4.5.2
			*/
					int		GetToolbar() const { return fToolbar; }

			/**Sets a toolbar to the list.
			Assigns to the list the resource ID of a toolbar.
			@see CSREditList::fToolbar
			@param toolbar is the resource ID of thenew toolbar.
			@version 4.5.2
			*/
					void	SetToolbar(int toolbar);

			/**Responds to the selection of a button on the toolbar.
			The overriding method will execute instructions when one of the control buttons is pressed, such as Save, Delete, etc.
			The control selected is specified by 'button', which is the resource identifier of the control button on the
			toolbar resource.
			@param button is resource ID assigned to the control button that is pressed.
			@version 4.5.2
			*/
			virtual void	ClickToolbar(unsigned char button) {}

			/**Shifts the position of a line on the list.
			Moves a line on the list one place up, or one place down. This is carried out only visually on the screen, except
			if parameter 'swapMemory' is true, in which case the line is also shifted within the data buffer of the list.
			@param direction is equal to 'sdUp' if the line is to be shifted upward on the list, equal to sdDown if to shifted downward.
			@param swapMemory is true if shifting also takes place within the data buffer of the list.
			@version 4.5.2
			*/
			void			ShiftSelection(eShiftingDirectionType direction, bool swapMemory=false); // shifts type selection one line up or one line down

			/**Obtains the SQL query for data retrieval.
			The SQL select query is the one responsible for reading database data of the list
			@see CSREditList::fReadQuery
			Method may be overriden if fReadQuery hasn't been initialised, or depending on how data is handled
			within the CSREditList-derived class.
			@param ret is a referance to the STL-string onto which the select SQL query.
			Use ret.c_str() to get C-string aftewards.
			@version 4.5.2
			*/
			virtual void	GetSelectQuery(_STL::string& ret);

			/**Obtains the SQL query for data insertion.
			The SQL insert query is the one responsible for inserting the list data into the database
			@see CSREditList::fWriteQuery
			Method may be overriden if fWriteQuery hasn't been initialised, or depending on how data is handled
			within the CSREditList-derived class.
			@param ret is a referance to the STL-string onto which the select SQL query. 
			Use ret.c_str() to get C-string aftewards.
			@version 4.5.2
			*/
			virtual void	GetInsertQuery(_STL::string& ret);

			/**Selects a specified line which is then highlighted in the list.
			param line is the index of the line to highlight.
			@version 4.5.2
			*/
			void			Select(int line);

			/**Selects a specified set of line which is then highlighted in the list.
			@param whichToSelect is the vector of indexes of the lines to highlight.
			@param unselectPrevious is true is previously selected lines must be unselected.
			@version 6.0
			*/
			void SelectMultiLine(const _STL::vector<int>& whichToSelect, bool unselectPrevious);

			/**Selects all the lines which are then highlighted in the list.
			@version 4.5.2
			*/
			void			SelectAll();

			/**Unselects all the lines in the list.
			@version 4.5.2
			*/
			void			UnselectAll();

			/**Checks if the list's database table is audited.
			It is possible that the list's data are audited in the database.
			By default it returns false, the overriding method will return true if data in the CSREditList-derived list
			are audited, so that, for instance, save data in a special database audit table.
			@return true is the list's data are audited, false otherwise.
			@version 4.5.2
			*/
			virtual bool	IsAuditable();

			/**Obtains first cell that is empty, within a set of columns.
			For each line on the list, cells in a set of given columns are checked. If a cell is detected to have a
			CSRElement-derived object with a null data value, it records the index on the column and index of the
			line containing the cell. It stops the search as soon as the first empty cell is found.
			@param cols is an array of column numbers to be checked. For every element it includes, it must contain [relativeID+1] of the element.
			@param num_col is the index of the array cols[], which refers to the element retrieved.
			@return the line number of the null cell. It is: line index + 1, that is, the line number if lines are numbered from 1.
			@version 4.5.2
			*/
					int		CheckNotNullValues(long *cols, int * num_col);

			/**Imposes whether columns of the list can or cannot be selected.
			This method is only useful when the list is contained within a dialog.
			@param selectable is true to impose that columns on the dialog can be selected.
			@version 4.5.2
			*/
					void	SetColumnSelectable(bool selectable) { if(!fDialog) fColumnSelectable = selectable; }

			/** Imposes whether the list data is audited/historised.
			This is normally invoked when the list is created. It imposes that the list data changes with the
			time, and the corresponding history may be available.
			@param history is set to true if the list known to be audited, and may have history.
			@version 4.5.2
			*/
					void	SetHistory(bool history=true) { fHasHistory = history; }

			/** Checks if the list data is audited/has a history.
			This method is specially invoked internally by base class CSREDitList in order to ascertain whether the "History" selection item in the "Audit" menu should be enabled or disabled.
			@return true is list's data are audited and histrical data may be retrieved.
			@version 4.5.2
			*/
			bool	HasHistory() const { return fHasHistory; }

			/**Sets the maximum number of lines that can be selected at one time.
			Common settings are one line at a time, or all lines displayed (fDisplayedLineCount) can be selected at one time.
			@param maxSelection is up to how many lines can be selected at one time.
			@version 4.5.2
			*/
			void	SetMaxSelection(int maxSelection) { fMaxSelection = maxSelection; } // to initialize before calling Open

			/**Obtains the maximum number of lines that can be selected at one time.
			@return the maximum number of lines that may be selected simultaneously.
			@version 4.5.2
			*/
			int		GetMaxSelection() const { return fMaxSelection; }

			/**Checks if a list is open\displayed.
			This is called generally before attempting to open the list, in order to check that the same list is not already open.
			@param info is the unique User Info set of information about the list.
			@param activate is True if to state whether dialog is open.
			@return true if the dialog specified by parameter info is open.
			@version 4.5.2
			*/
			static	bool IsActiveWindow(CSRUserEditInfo *info, Boolean activate = true);

			/**Obtains a list.
			Returns the list object specified by the user info parameter.
			@param info is the unique User Info set of information about the list.
			@activate.
			@return a pointer to the CSEditList object of the list sought.
			@version 4.5.2
			*/
			static	CSREditList* GetCSREditList(CSRUserEditInfo *info, Boolean activate = true);

			/**Sets a particular line to be the current line.
			@see CSREditList::fCurrentLine
			@param CurrentLine is the number of the line which is to be the current.
			@version 4.5.2
			*/
			void	SetCurrentLine( int CurrentLine ) const { fCurrentLine = CurrentLine ; }

			/**Checks whether drag & drop operation can act on each line of the list.
			@return true if the drag & drop is permitted on each line.
			@version 4.5.2
			*/
			bool	CanDropOnLines() const { return fCanDropOnLines; }

			/**Imposes whether drag & drop operation will be allowed to act on each line of the list.
			@param onoff is set to true, if it is desired to permit drag & drop operation on each line.
			@version 4.5.2
			*/
			void	SetCanDropOnLines(bool onoff=true) { fCanDropOnLines = onoff; }

			/** Set the number of the line onto which an item is dragged over the list.
			This method is used for drag & drop.
			@see CSREditList::fDropLine
			It is also called internally by RISQUE.
			@param line is the line number where an item is dragged to.
			@version 4.5.2
			*/
			void	SetDropLine(int line) { fDropLine = line; }

			/** Enable Paste on the list mecanism
			By default, the paste mecanism is enabled
			*/
			void	EnablePaste(bool on) { fPaste = on; }
			
			/**Returns true if paste should be forced for using the generic mecanism
			If the flag is set, the paste data is handled the same way wether the copy comes from Sophis or from
			some external application such as Excel
			The default is false
			This feature is used by CSRGenericTraderBlotter
			@return fPaste.
			*/
			virtual bool    IsForceGlobalPaste(void) const;

			/**Allows to overload the default generic paste mecanism
			@param dumpWind. The window structure object supporting the list
			@param size. the size of the data to paste
			@param elem. the data (string format) to paste
			@return true if the paste process succedded.
			*/
			virtual bool	PasteFromGlobal(USWindow* dumpWind, long size, const char* elem);

			/**Enables the downward copy mecanism. By default the feature is disabled.
			@param onoff is set to true, if it is desired to permit downward copy operation on columns.
			*/
			void    EnableDownwardCopy(bool onoff) const;

			/**
			*
			*/
			virtual bool	PasteFromExcel(USWindow* dumpWind, long size, const char* elem);

			/** 
			* Get the columns to paste before the others, in order of priority.
			* This is necessary when some column is computed from other columns, which therefore have to be pasted before.
			*/
			virtual bool GetColumnsToPasteFirst(const TDataColumns* colValues, _STL::list<int>* outPriorityCols) const;

			/**
			* Builds the matrix (lines + columns) of data to be pasted in the list.
			*    Derived classes typically call the generic method, and then remove some columns that should not be pasted.
			*    For example the Name of an instrument is not pasted because it will be obtained from the reference column.
			*/
			virtual bool GetDataMatrix(	const _STL::vector< _STL::vector<_STL::string> >	*parsedDocument,
										TDataMatrix											*outValues) const;

			/**
			* Ensures that the data are consistent. 
			* Data are consistent if all the lines of data are individually consistent.
			*/
			virtual bool EnsureDataConsistency(const TDataMatrix *translatedValues) const;

			/**
			* Ensures that a line of data in consistent.
			* The basic implementation just returns true as a verification of the data format is also done in the Paste method.
			* In addition to the data format, one could check the data values and their consistency.
			*/
			virtual bool EnsureDataConsistency(int lineIndex, const TDataColumns *colTranslatedValues) const;

			/**
			* Paste the data into the blotter.
			*/
			virtual bool Paste(const TDataMatrix *values);

			/** 
			* Get the lines where the data should be copied from the current GUI selection.
			* If more lines are needed, lines following the last one are added, provided that "CanOverwriteLine()" is true.
			* Returns true if the required number of lines has been found,
			*         false otherwise (e.g. some destination line can not be overidden)
			*/
			virtual bool GetDestinationLines(const _STL::vector< _STL::vector<_STL::string> >	*parsedDocument, 
											_STL::vector<long>									*outDestinationLines) const;

			/** 
			* Return true if the line is fully empty (all the columns are empty), 
			* and false otherwise.	
			*/
			virtual bool	CanOverwriteLine(int lineIndex) const;

			/** 
			* Reset the lines to "no-value" 
			*/
			void ResetLines(_STL::vector<int> lines);

			/** Paste a string data value into a cell, without updating or saving the blotter.
			Returns true if the paste is a success, false otherwise. */
			virtual bool PasteCell(int lineIndex, int colIndex, _STL::string cellValue);

			/**Allows to retrieve the selected cell position 
			@param line allows to retrieve the line of the selected cell. -1 if no cell is selected.
			@param column allows to retrieve the column of the selected cell. -1 if no cell is selected.
			*/
			void    GetSelectedCell(long &line, long &column) const;

			/**(vvf, 30/4/4)
			@since 4.7.0
			*/
			const char *GetTableName()  { return fTable; }

			/* Used in SortGeneral(), when ValueToString() is not usable, to have a key for ordering the edit list
			 * This method retrieves a 'key' for a given 'line' corresponding to the sort on the 'keyColumn'
			 * @param keyColumn : the ordering column of the edit list
			 * @param line : the line whose key should be retrieved
			 * @return the key of the line for a sort on the parameter column
			 */
				virtual ElemValue* GetComparableValue(long keyColumn, int line) const;

			/**Disables the element.
			Only useful when the element is within a CSRFitDialog.
			If disabled, the list cannot be edited.
			@version 5.2.2
			*/
			virtual void	Disable() const;

			/**Enables the element.
			Only useful when the element is within a CSRFitDialog.
			@version 5.2.2
			*/
			virtual void	Enable() const;

			/** INTERNAL.
			@version 5.2.2
			*/
			void	SetAuditList( CSREditList * auditList );

			/*
				Called when a cell is clicked.
				By default it does nothing.
				@param line : the line index of the cell.
				@param column : the column index of the cell.
			*/
			virtual void	OnCellClicked( const int & line, const int & column );

			/** Notification of cell edition start */
			virtual void	OnCellEdit(int line, int column);

			/// Helper structure for column creation (@see PrepareColumn, @see SetColumns)
			struct ColumnInfo {
				CSRElement* fElement;
				int fColumnWidth;
				eAlignmentType fAlignmentType;
				_STL::string fName;
			};
			
			/**
			* Prepare a column with all given parameters and output it in the ColumnInfo vector provided.
			*/
			static CSRElement* PrepareColumn(const _STL::string& name, CSRElement* pElement, int columnWidth, eAlignmentType alignmentType, _STL::vector<ColumnInfo>& columnsOut);
			
			/**
			* Allocate fColumns and fColumnCount with all the prepared ColumnInfo elements provided.
			* The order of columns in fColumns depends on the order in vColumns and on the possible content of the optional pRelativeIdToColumnIndex map.
			* If pRelativeIdToColumnIndex is NULL, the order of fColumns is the same as that of vColumns.
			* If pRelativeIdToColumnIndex is not NULL, its existing mappings will be used in priority to assign a column index to an element.
			* For elements that don't have such a mapping defined in pRelativeIdToColumnIndex, the remaining unassigned columns
			* are assigned sequentially to remaining elements in the same order as the vColumns.
			* If pRelativeIdToColumnIndex is not NULL, it will contain the effective mapping between each element's relative id and its corresponding column index.
			*/
			void SetColumns(const _STL::vector<ColumnInfo>& vColumns, _STL::map<int, int>* pRelativeIdToColumnIndex = NULL);

			/**
			* Get the column index from the column name.
			* Works for user columns only. Returns true if the column index was retrieved.
			@version 7.1.3
			*/
			virtual bool GetUserColumnIndexByName(const char* colName, long& colIndex);

		protected:
			/** A C string referring to the name of the database table that is linked to the list. That is, a table whose records are contained in the data buffer of the list.

			The structure of the table must include at least the two following fields :
				- CODE number(10), security identifier to establish a link with the Sophis table
				- NUMERO number(3), line identifier
			@version 4.5.2
			*/
			const char  *fTable;

			/**The total number of columns in the list.
			@version 4.5.2
			*/
			int			 fColumnCount;

			/**Number of columns in the list's database table that are described by database table USERCOLUMN.
			If a table is linked to the list, then fColumnCount (columns in the list) is initially equal to
			fUserColumnCount as set in the constructor.
			@version 4.5.2
			*/
			int			 fUserColumnCount;

			/** Number of columns in the list that are locked.
			Specifies the number of columns in the list that are locked.
			@version 4.5.2
			*/
			int			 fLockedColumnCount;

			/**Array of column objects, each of which has a link to a CSRElement.
			The array is of size fColumnCount.
			@version 4.5.2
			*/
			SSColumn	*fColumns;

			/**The maximum number of lines that can be selected at one time.
			@version 4.5.2
			*/
			int			fMaxSelection;

			/**Resource ID for the columns.
			@version 4.5.2
			*/
			int			fResIDCols;

			/**Indicates whether columns of the list can or cannot be selected.
			@version 4.5.2
			*/
			bool		fColumnSelectable;

			bool		fModified_; // internal

			/**Displays the history of a line data on the list.
			The method is automatically called by the base class CSREditList.
			The overriding method will perform actions to display the previous versions of a line selected.
			It usually creates and open a new CSREditList-derived list.
			@version 4.5.2
			*/
			virtual void	DoHistory(long selLine);

		public:
			void DoHistory_API(long selLine);

		protected:
			/**The data buffer of the list.
			@version 4.5.2
			*/
			char		**fListeValeur;

			/** The SQL update query.
			This query is responsible for transferring data from the list's data buffer to the database table linked
			to the list.
			@version 4.5.2
			*/
			char		**fWriteQuery;

			/**The SQL select query.
			It is responsible for tranfering data from the list's database table to the list's data buffer.
			@version 4.5.2
			*/
			char		**fReadQuery;

			/**The buffer onto which the user column's characteristics of the list's table (from table USERCOLUMN) are stored.
			@version 4.5.2
			*/
			void		*fBuffColSup;

			/**The descriptor for the SQL queries.
			@version 4.5.2
			*/
			Tdescribe	*fDesc;
			int			fOffset;

			/**(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			@since 4.7.0
			*/
			Tdescribe	*fDesc2;

			/**Holds the number of the current line.
			The current list normally indicates which line in the list's buffer is currently loaded into the data values of the
			CSRElements of the list.
			If no line has been chosen, this field is set to -1
			@version 4.5.2
			*/
			mutable int	fCurrentLine;

			/**The size (in bytes) of one single line in the data buffer
			@version 4.5.2
			*/
			int			fSize;

			/**Identifier of the toolbar resource that is displayed and used to control the list.
			@version 4.5.2
			*/
			int			fToolbar;

			/**Determines whether list's data are audited.
			@version 4.5.2
			*/
			bool		fHasHistory;

			/**Number of lines displayed for the list.
			It represents the number of lines in the buffer, plus additional empty lines that will also appear on the grid.
			@version 4.5.2
			*/
			int			fDisplayedLineCount;

			/**The window structure object supporting the list.
			@version 4.5.2
			*/
			USWindow	*fWindow;

			/**States whether the list must be resized in the containing dialog.
			@version 4.5.2
			*/
			bool		fResizeInDialog;

			/**The User Info object.
			This is a unique info object that is attached with every instance of list created.
			The info object is created and attached to the list.
			In order to prevent from creating and displaying a list more than once, method IsActiveWindow() will use
			the info object	and checks if there is a list with the same info object already created.
			If it is the case, then the list is not created again.
			@version 4.5.2
			*/
			CSRUserEditInfo	*fData;

			/**Specifies whether the number of lines displayed (fDisplayedLineCount) on screen is variable (default: false)
			When this is true, the number of lines displayed is always equal to the number of lines in the buffer.
			Variation in number of lines in the buffer results in variation in number of lines displayed also.
			@version 4.5.2
			*/
			bool		fDynamicSize;

			/**The number of the line on the list onto which an item is dragged over by the mouse.
			If set to -1, the line is always under the mouse pointer during drag & drop.
			@version 4.5.2
			*/
			int			fDropLine;

			/**whether drag & drop operation can act on each line of the list.
			@version 4.5.2
			*/
			bool		fCanDropOnLines;

			void			Resize(); // internal : apply change of number of line

			/** Get the tag for the data service.
			@return 0 if no tag.
			@since 4.5.2.1
			*/
			const char		*GetTag() const;
		// internal static methods
			static void		liste_ExtractDump(USWindow *wind, TVFile *theVFile, rec_krit *LesCriteres , int *nb_ligne, long **tab_cor);
			static void		listeCmde(USWindow *wind, struct TVFile *vFile, unsigned long cmd, void *params);
			static void		listDoCmde(unsigned long cmd, void *params);

			static void		liste_get_field_value(USWindow * wind, TVFile *theVFile, long rec_num, long field_num, char *dest);
			static Boolean	liste_set_field_value(USWindow * wind, TVFile *theVFile, long rec_num, long field_num, char *sourc);
			static field_desc **liste_get_field_info(USWindow * wind, TVFile *theVFile, long field_num);
			static void		listeEnable(USWindow * wind, struct TVFile* vFile, unsigned long *e1, unsigned long *e2, unsigned long *e3, Boolean front);
			static void		listGetEnable(Boolean infront, unsigned long *e1,unsigned long *e2,unsigned long *e3);
			static void		paste_global(USWindow* wind, struct TVFile *theVFile, long size, const char* completeString);

			static Boolean	listeGetColLgnCmd(USWindow * wind, TVFile *theVFile, long rec_num, long field_num, short theMods, short *curseur);
			static short	filtre(USWindow * wind, TVFile *theVFile, long rec_num);
			static short 	pClose(USWindow *, TVFile *TheVFile , short modified);
			static void		listeSelect(USWindow*, TVFile *TheVFile, int select, long rec_num, char *s);
			static void		listeGetStateCell(USWindow *, struct TVFile*, long, long, SSListCellStyle*);
			static void		listeCellEdit(USWindow*, struct TVFile*, long rec_num, long field_num);

			static int DumpGetMenuPopupSelection(CSDumpMenu* menu);
			static CSDumpMenu* DumpGetMenuPopup(USWindow *wind,TVFile *theVFile, long rec_num, long field_num, short theMods);
			static Boolean DumpMenuPopupChange(CSDumpMenu* menu, int nSel, bool isAskedToReset );

			static CSDumpAutoCompletion* DumpGetAutoCompletion(USWindow *wind,TVFile *theVFile, long rec_num, long field_num, short theMods);
			static void DumpGetAutoCompletionListSelection(CSDumpAutoCompletion* menu, _STL::string& text);
			static Boolean DumpAutoCompletionListChange(CSDumpAutoCompletion* menu, int nSel, bool isAskedToReset, const char* source );

			static int	Set_nom_col(USWindow *wind, TVFile *theVFile, long field_num, char *sourc);
			static bool Get_nom_col(USWindow *wind, TVFile *theVFile, long field_num, char *sourc);


			static void InfoProcCallback(USWindow *wind,TVFile *theVFile,short Mods, Boolean nIcon);
			static void CallBackHandleEvent(const sophis::event::ISEvent & event);

			static void		liste_Sort(USWindow *wind, TVFile *theVFile, sort_crit *crits, int *nb_ligne, long **tab_cor, int nbTries);

		public:
			void	Initialisation(CSRFitDialog *dialog, int &number);					// internal

			virtual void	InitialiseOracle(Tdescribe	*desc,
											char		**read,
											char		**write,
											char		**insert);						// internal
			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual	void	InitialiseOracle(_STL::vector<CSRElement*>& v,			
											 Tdescribe *desc, 
											 char		** lecture, 
											 char		** ecriture, 
											 char		** insert);

			virtual const char *InitialiseDialogue(const char* result);					// internal
			virtual char	*InitialisePointeur(char* result);							// internal
			virtual void	Describe(sophis::tools::dataModel::DataSet& data_set, const SSDataDescribed &dataPtr) const;
			virtual void	UpdateWithDataSet(const sophis::tools::dataModel::DataSet& data_set, SSDataDescribed &dataPtr);

			/** Archiving each value in each column of each line of the list.
			@param first parameter is the archive object.
			@param second parameter points to the data buffer from which the element values are archived.
			@version 4.5.2
			*/
			virtual const char *  push (sophis::tools::CSRArchive & , const char * ) const;

			/**Dearchiving values of elements archived, to the list.
			@param first parameter is the archive object.
			@param second parameter is the a pointer to the data buffer to which values from the archive are copied.
			@version 4.5.2
			*/
			virtual char *  pop (const sophis::tools::CSRArchive & , char *);

			virtual	void	Sort(sort_crit *crits);										// internal
			virtual sql::errorCode ReadQuery(char* result, long code) OVERRIDE;				// internal
			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual	sql::errorCode ReadQuery(char* result, _STL::vector<CSRElement*>& v);

			virtual sql::errorCode WriteQuery(char* result, long code) OVERRIDE;						// internal
			//(vvf, 30/4/4) --have replaced 'long code' with '_STL::vector<CSRElement*>'
			virtual	sql::errorCode	WriteQuery(char * resultat, _STL::vector<CSRElement*>& v);		

			/** Historise.
			@see CSRElement::Historise()
			@version 4.5.2
			*/
			sql::errorCode	Historise(long sico, long sico_histo);

			/** Duplicate history.
			@see CSRElement::HistoDuplicate()
			@version 4.5.2
			*/
			sql::errorCode	HistoDuplicate(long sico, long sico_histo);

			short	Free(char* result);													// internal
			short	Duplicate(char* result);											// internal
			void	InitialiseOther(const CSRElement & element);							// internal
			int		GetTailleObjet() const;												// internal

			friend class CSRListAudit;
			friend class CSRListCtrlGrille;
			friend class ::CSRColleUtilisateur_GUI;
			friend class ::CSRColleUtilisateur_ToolkitGUI;
			friend class ::CSREditListGUI;
		private:
			//void	API_Open(void);
			//static void API_CallBackHandleEvent(const sophis::event::ISEvent & event);

			static const char* __CLASS__;
		protected:
			const char		*GetSection() const;

			/** Field containing the tag for the data service.
			*/
			char		*fSectionName;

			/** comment for the complex type in XML grammar. 
			@see SetXMLGrammar
			@since 4.5.2.2
			*/
			_STL::string fXMLCommentComplexType;

			/** Specify the field minoccurs in  XML grammar. 
			*/
			bool fAtLeastOneLineInXML;

			/** Specify if the paste process is enabled or not
			*/
			bool fPaste;

			/** comment for one line for XML grammar. 
			@see SetXMLGrammar
			@since 4.5.2.2
			*/
			_STL::string fXMLCommentLine;

			/** comment for the complex type of one line for XML grammar. 
			@see SetXMLGrammar
			@since 4.5.2.2
			*/
			_STL::string fXMLCommentComplexTypeLine;

		private:
			/**INTERNAL.
			@version 5.2.2
			*/
			bool			fIsAudited;

			/**INTERNAL.
			@version 5.2.2
			*/
			CSREditList *	fAuditList;

		public:
			/**
			It is called when the user presses Ctrl+H or selects History from the Edit menu.
			The method is automatically called by listDoCmde() of the base class CSREditList.
			The method has to be overloaded.
			@version 6.0
			*/
			virtual void DoFunctionalHistory(void);

			/**	Returns true if FunctionalHistory should be activated for this list
			@version 6.1
			*/
			inline bool HasFunctionalHistory() const;
			inline void SetHasFunctionalHistory(bool has);

			/**
			* Sets line-dependent values in all line-dependent dynamic popups registered in this edit list.<br/>
			* Default implementation does nothing.
			*/
			virtual void UpdateLineDependentMenusContext();

		private:
			bool	fHasFunctionalHistory;

			DEPRECATED_OBSOLETE virtual	void GetWindowRectangle() const;
		};
		SPH_END_NOWARN_EXPORT

		inline bool CSREditList::HasFunctionalHistory() const
		{
			return fHasFunctionalHistory;
		}

		inline void	CSREditList::SetHasFunctionalHistory(bool has)
		{
			fHasFunctionalHistory = has;
		}

		/**	Class CSRListArray:
		*
		*	Special CSREditList designed to handle a list in a window.
		*	The CSRListArray class directly derives from the CSREditList class.
		*	Thus any object of this type can be embedded in a CSRFitDialog with other dialog elements. What makes this
		*	class particularly useful is that it displays, in a non-modal window, an array of results (whether editable
		*	or not) of a given size. The array is typically displayed by CSREditList::ActivateWindow().
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRListArray : public CSREditList	{
		public:
			/**Overloaded Constructor 1
			Initialises CSRListArray members given: the containing dialog, the Array, number of lines, size of one line, database table.
			@param dialog is a pointer to the dialog to which the list belongs. It is passed to the base class constructor.
			@param ERId_List is the relative ID of the array, as an element.
			@param array is the address of the array of which the values should be displayed.
			@param lineCount is the number of lines of the array of which the address is array. It is also the number of lines to display.
			@param columnSize is the size of one line, that is, the array's size divided by lineCount.
			@param tableName is the user database table linked to the array, of which the structure must possess at least certain fields (see CSEditList::CSREditList):
			@version 4.5.2
			*/
			CSRListArray(CSRFitDialog *dialog, int ERId_List, void *array, int lineCount, int columnSize, const char *tableName = kUndefinedTable);

			/** Overloaded Constructor 2
			Initialises members given: the Array, number of lines, the size of the column.
			In fact, this constructor does not call the base class constructor CSREditList::CSREditList.
			It should be used to display autonomous arrays in non-modal windows.
			@param array is the address of the array of which the values should be displayed.
			@param lineCount is the number of lines of the array of which the address is array. It is also the number of lines to display.
			@param columnSize is the size of one line, that is, the array's size divided by lineCount.
			@version 4.5.2
			*/
			CSRListArray(void * array, int lineCount, int columnSize);

			/** Destructor.
			Frees the memory allocated to the Array.
			It should not be called explicitly, it will be automatically called in due time by CSRFitDialog::~CSRFitDialog().
			@version 4.5.2
			*/
			~CSRListArray();

			/**Loads the content of the Array's lineIndexr-th line.
			The method will cause the content of this line in the Array's buffer to be stored in the appropriate
			data values of the array's CSElements.
			@param lineIndex is the number of the line that is to be loaded.
			@version 4.5.2
			*/
			virtual Boolean	LoadLine(int lineIndex) const;

			/**Sets the array buffer size.
			By default, the method does nothing.
			The overriding method sets the size of the memory block allocated to the array buffer (fArray) to: newLineCount lines times
			the size of one line (denoted by CSREditList::fSize). Overall, the setting of number of lines depends on the memory
			structure which the CSREditArray-derived array (fArray) points to.
			@param newLineCount is the new number of lines for the array's buffer.
			@version 4.5.2
			*/
			virtual void	SetLineCount(int newLineCount);

			/**Obtains the number of lines on the array.
			@return the number of lines of the array.
			@version 4.5.2
			*/
			virtual int		GetLineCount() const;

			/**Saves a line to the array buffer.
			The method copies the content of the data values of the CSRElements into the array's buffer (fArray). It is the
			reverse	of what LoadLine does.
			@param lineIndex is number of the line to save.
			@version 4.5.2
			*/
			virtual void	SaveLine(int lineIndex);

			/**Widens the array buffer size by a number of lines.
			By default, the method does nothing.
			You must override this method in order to allocate more memory to the array buffer, depending on the memory
			structure, which the CSREditArray-derived array (fArray) points to.
			@param HowManyNewLines is the number of lines by which the size of the array buffer will increase.
			@version 4.5.2
			*/
			virtual void	Enlarge(int HowManyNewLines);

			/**Removes a line from the array buffer.
			By default, the method does nothing.
			The overriding method removes the line number lineIndex from the array fArray. The size of the buffer is reduced
			likewise.
			You must override the method in order to allocates more memory to the array buffer, depending on the memory
			structure which the CSREditArray-derived array (fArray) points to.
			@param lineIndex is the number of the line to remove.
			@version 4.5.2
			*/
			virtual void	RemoveLine(int lineIndex);

			/**Inserts a new line into the array.
			It inserts a line into the array buffer (fArray) just before the line numbered 'beforeline'.
			The size of the buffer is therefore increased by one line.
			By default it does nothing. You may need to override the method, depending on the memory
			structure which the CSREditArray-derived array (fArray) points to.
			@param beforelineIndex is the number of the line before which the new line will be located.
			@version 4.5.2
			*/
			virtual	void	InsertLine(int beforeLine);

			/**Sorts the array lines.
			Sorts the array with respect to the column number CNb_Column. If 'ascending' is
			set to true (which is the case when no parameter is given) lines are sorted in the ascending
			order (increasing sequence), on contrary, when increassing is set to false, lines are sorted
			in descending order. When the sorting process is over, the list is automatically redisplayed.
			@param CNb_Column is the relative ID of the CSRElement in the column on which sorting is based.
			@param ascending is true if lines are to be sorted in ascending order of values in CNb_Column, false if in descending order.
			@version 4.5.2
			*/
			virtual void	Sort(int CNb_Column, Boolean ascending = true);

		protected:
			/**Nuber of lines set when the CSRListArray is created.
			Its value is that of the parameter passed on to CSRListArray::CSRListArray()(actually the constructor
			CSREditList::CSREditList() gets this in nombreLignesAffichees when called by CSRListArray::CSRListArray()).
			The number of lines that a given CSRListArray can handle is constant and always equal to the number of
			lines displayed.
			@version 4.5.2
			*/
			int		fLineCount;

			/**Address of the array buffer.
			It is the address of an array that can hold elements of all types. The size of the memory block
			allocated to this array is equal to fLineCount multiplied by the member CSREditList::Size (which has been set in
			the CSRListArray constructor).
			The address of the array can be passed as a parameter to the constructor CSRListArray::CSRListArray()
			or allocate fArray within the constructor of the CSRListArray-derived class. In all cases, fArray
			should point to a memory block of size fLineCount times fSize.
			@version 4.5.2
			*/
			void	*fArray;

			/**Size of one line.
			This is actually equal to fSize.
			@version 4.5.2
			*/
			long	fArraySize;

		public:

			virtual	void	Sort(sort_crit *crits);	// internal
		};

	}
}


SPH_EPILOG
#endif
