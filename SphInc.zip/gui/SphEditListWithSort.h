/********************************************************************
*	@date:		15/11/2006
*	
*	@file:	 	SphEditListWithSort.h
*
*	@author:	Philip Walford
*				Copyright (C) 2006 SOPHIS
*	
*	@purpose:	
*
*/
#ifndef _SPH_EDIT_LIST_WITH_SORT_H_
#define _SPH_EDIT_LIST_WITH_SORT_H_

#include "SphInc/gui/SphEditList.h"

#include __STL_INCLUDE_PATH(vector)

SPH_PROLOG
namespace sophis
{
	namespace gui
	{

		/** CSREditList with generalised multi-criteria (multi-column) sort
		 * implemented by default.
		 *
		 * This class is designed to work as a plug-in replacement for
		 * CSREditList.  It extends CSREditList, overloading only the methods
		 * which implement the various sorts.
		 *
		 * This class relies on the following virtual methods of CSREditList to
		 * work:
		 *
		 * -	CSREditList::LoadLine(int lineIndex) const
		 *
		 * -	CSREditList::GetComparableValue(long keyColumn, int line) const
		 *			This method is implemented by default in CSREditList and
		 *			should work for most columns.  The default is to call
		 *			CSRElement::GetComparableValue(int) for the column's
		 *			CSRElement.
		 *			This GetComparableValue() is called after calling
		 *			LoadLine(int) for the line in question.
		 *
		 * -	CSREditList::SwapLines(int line1, int line2)
		 *			Must correctly swap the contents of line1 and line2.
		 *			Sorting does not try to swap a line with itself
		 *			(i.e. SwapLines(X,X)).
		 *
		 * -	CSREditList::GetLineCount() const
		 *
		 * -	CSREditList::SetLineCount(int)
		 *			Should update the number of lines in the list, optionally
		 *			removing unused lines.  (This is not essential, although a
		 *			sort may result in fewer lines if LoadLine returns false for
		 *			a line.)
		 *
		 * @version 5.2.4
		 */
		class SOPHIS_FIT CSREditListWithSort : public CSREditList
		{
		public:
			/** Construct CSREditListWithSort.
			 *
			 * @see CSREditList::CSREditList(CSRFitDialog*, int, const char*,
			 *		int, const char*, const char*) for parameters.
			 */
			CSREditListWithSort(	CSRFitDialog	*dialog,
									int				ERId_List,
									const char		*tableName = kUndefinedTable,
									int				displayedLineCount = 100,
									const char		*sequence = kSameAsOracleName,
									const char		*section = kSequencePlusS);

			/** Construct CSREditListWithSort.
			 *
			 * @see CSREditList::CSREditList(int, const char*, CSRUserEditInfo*)
			 *		for parameters.
			 */
			CSREditListWithSort(	int				toolbar = -1,
									const char		*tableName = kUndefinedTable,
									CSRUserEditInfo	*data = 0);

			virtual ~CSREditListWithSort();

			/** Overload of CSREditList::Sort(sort_crit*) which (by default)
			 * implements all list sorting.
			 *
			 * Calls SortGeneral(sort_crit*, int). */
			virtual	void	Sort(sort_crit *crits);

		protected:
			/** Multi-criteria version of CSREditList::GetComparableValue(int,
			 * int) for use in SortGeneral.
			 *
			 * Create a sophis::gui::ElemValue* capable of comparing the values
			 * in zero or more columns of the list, depending upon crits.
			 *
			 * @note internal use. */
			sophis::gui::ElemValue* GetComparableValue(sort_crit *crits, int line) const;

			/** General multi-criteria sort for this list.  This method is a
			 * multi-criteria version of
			 * CSREditList::SortGeneral(char**, long, long, int, Boolean, int).
			 *
			 * @param crits defines the columns by which the list should be
			 * sorted and in which direction (ascending/descending).
			 *
			 * @param maxNbLines specifies the maximum number of lines to output
			 * from the sort.  If positive but fewer than the number given by
			 * GetLineCount(), the list will be truncated after sorting the
			 * first maxNbLines elements.  */
			virtual void SortGeneral(sort_crit *crits, int maxNbLines=-1);
		};

	} // namespace gui
} // namespace sophis
SPH_EPILOG

#endif // _SPH_EDIT_LIST_WITH_SORT_H_
