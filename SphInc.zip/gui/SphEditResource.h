/*
 	File:		SphEditResource.h

 	Contains:	Class for the handling of user's resources

 	Copyright:	� 1995-2000 Sophis.

*/

/*! \file SphEditResource.h
	\brief Handling user resources.
*/

#pragma once

#ifndef _SphEditRessource_H
#define _SphEditRessource_H

#include "SphInc/gui/SphCustomMenu.h"


SPH_PROLOG

// This control has the aspect of a popup menu.
// It allows the edition/display of an STR resource
class SOPHIS_FIT CSREditResourceSTR : public sophis::gui::CSRCustomMenu {
public:
	CSREditResourceSTR(	sophis::gui::CSRFitDialog 	*dialog, 
						int 			 ERId_Menu,
						short 			 STR_ResId,
						short			 lineCount=scNbLinesMax,	// quasi infinite limit
						short			 shiftValue=0,				// first index of menu strings
						bool			 editable=true,
						short			 storageShift=0,			// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	CSREditResourceSTR(sophis::gui::CSREditList		*theList, 
						int 			 CNb_Menu, 
						short 			 STR_ResId, 
						short			 lineCount=scNbLinesMax, // quasi infinite limit
						short			 shiftValue=0,
						bool			 editable=true,
						short			 storageShift=0,		// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	int		GetResourceId(void) { return fResourceID; };

	static const short scNbLinesMax;

protected:
	void BuildMenu();
	virtual short GetStringIndex(short line) {return line <= 0 ? -1 : line+fShiftValue;}
	void SetValueFromList();
	void SetListFromValue();

	short fResourceID;
	short fShiftValue;
	short fLineCount;
	short fStorageShift;
};

class SOPHIS_FIT CSREditResourceMENUshort : public sophis::gui::CSRCustomMenu {
public:
	CSREditResourceMENUshort(sophis::gui::CSRFitDialog 	*dialog, 
						int 			 ERId_Menu,
						short 			 STR_ResId,
						short			 lineCount=scNbLinesMax,	// quasi infinite limit
						short			 shiftValue=0,				// first index of menu strings
						bool			 editable=true,
						short			 storageShift=0,			// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	CSREditResourceMENUshort(sophis::gui::CSREditList		*theList, 
						int 			 CNb_Menu, 
						short 			 STR_ResId, 
						short			 lineCount=scNbLinesMax, // quasi infinite limit
						short			 shiftValue=0,
						bool			 editable=true,
						short			 storageShift=0,		// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	int		GetResourceId(void) { return fResourceID; };

	static const short scNbLinesMax;

protected:
	void BuildMenu();
	virtual short GetStringIndex(short line) {return line <= 0 ? -1 : line+fShiftValue;}
	void SetValueFromList();
	void SetListFromValue();

	short fResourceID;
	short fShiftValue;
	short fLineCount;
	short fStorageShift;
};

class SOPHIS_FIT CSREditResourceMENUlong : public sophis::gui::CSRCustomMenu {
public:
	CSREditResourceMENUlong(sophis::gui::CSRFitDialog 	*dialog, 
						int 			 ERId_Menu,
						short 			 STR_ResId,
						short			 lineCount=scNbLinesMax,	// quasi infinite limit
						short			 shiftValue=0,				// first index of menu strings
						bool			 editable=true,
						short			 storageShift=0,			// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	CSREditResourceMENUlong(sophis::gui::CSREditList		*theList, 
						int 			 CNb_Menu, 
						short 			 STR_ResId, 
						short			 lineCount=scNbLinesMax, // quasi infinite limit
						short			 shiftValue=0,
						bool			 editable=true,
						short			 storageShift=0,		// shift between the stored value and its index in the resource
				  const char 			*columnName=kUndefinedField,
				  const char *	tagColonne = kSameAsOracleName);

	int		GetResourceId(void) { return fResourceID; };

	static const short scNbLinesMax;

protected:
	void BuildMenu();
	virtual short GetStringIndex(short line) {return line <= 0 ? -1 : line+fShiftValue;}
	void SetValueFromList();
	void SetListFromValue();

	short fResourceID;
	short fShiftValue;
	short fLineCount;
	short fStorageShift;
};

SPH_EPILOG

#endif //_SphEditRessource.h
