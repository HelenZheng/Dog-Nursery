/*
 	File:		SphEditUser.h

 	Contains:	Class for the handling of Risk's users

 	Copyright:	� 1995-2000 Sophis.

*/

/*! \file SphEditUser.h
	\brief Managing users of RISQUE
*/

#pragma once

#ifndef _SphEditUser_H
#define _SphEditUser_H 1

#include "SphInc/gui/SphCustomMenu.h"

#include __STL_INCLUDE_PATH(iosfwd)


SPH_PROLOG

// This control has the aspect of a popup menu.
// It allows the edition/display of Risk's users
class SOPHIS_FIT CSREditUser : public sophis::gui::CSRCustomMenu {
public:
	/**
	 * Should this menu list users, groups or both.
	 */
	enum DataToDisplay
	{
		UsersAndGroups,
		OnlyUsers,
		OnlyGroups
	};

	CSREditUser(sophis::gui::CSRFitDialog 	*dialog, 
				int 			ERId_Menu, 
				bool			editable=true,
				const char 		*columnName=kUndefinedField,
				const char *	tagColonne = kSameAsOracleName,
				DataToDisplay   toDisplay = UsersAndGroups);
	CSREditUser(sophis::gui::CSREditList	*list, 
				int 			CNb_Menu, 
				bool			editable=true,
				const char 		*columnName=kUndefinedField,
				const char *	tagColonne = kSameAsOracleName,
				DataToDisplay   toDisplay = UsersAndGroups);

	virtual ~CSREditUser();

protected:
	SPH_BEGIN_NOWARN_EXPORT
	_STL::vector<long> indexUsers;
	SPH_END_NOWARN_EXPORT
	void BuildMenu(DataToDisplay toDisplay);
	void SetValueFromList();
	void SetListFromValue();
};


SPH_EPILOG

#endif //_SphEditUser_H
