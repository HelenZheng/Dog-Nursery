#ifndef _SphElement_H__
#define _SphElement_H__

#include "SphTools/SphCommon.h"

#include "SphInc/SphMacros.h"
#include "SphInc/gui/SphGenericForm.h"
#include "SphInc/gui/SphDialogEnums.h"
#include "SphInc/gui/SphColor.h"
#include "SphSDBCInc/SphSQLDataTypes.h"



#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)



class CSUMenu;
#define	USMenu		CSUMenu
#define	USWindow	void

#define kUndefinedField (( char* )-1)
#define kUndefinedTable (( char* )-1)
#define kSameAsOracleName (( char* )-1)
#define kNoTag			 (( char* )0)

union SSCellValue;
struct SSCellStyle;
class CSWindHier;
class CSRListAudit;

SPH_PROLOG
namespace sophis
{
	namespace market_data {
		struct SSYieldCurve;
	}
	namespace tools
	{
		class CSRArchive;
		namespace	dataModel	{
			class DataSet;
		}
	}
	namespace portfolio {
		class CSRTransaction;
		class CSRPortfolio;
	}
	namespace instrument 
	{
		class CSRInstrument;
	}
	namespace gui
	{

		class CSRFitDialog;
		class CSREditList;
		class CSRPortfolioHeaderDialogInternalData;
		struct NavBarDumpData ;

		/** Union giving a pointer on the data.
		In API, sometimes it is needed to get the data to get a full picture.
		For instance, when describing a user element in a xml whose description
		will use other data of the instrument. But it is not possible to create 
		the data, using for instance GetDialog()->new_CSRInstrument as it is not in the
		GUI. In that case, the data is given as parameters. Today, this case occurs only
		for xml and for instrument, but it is forecasted this need could occurs in other 
		situations so the structure is coded as an union.
		@since 4.5.2.1
		@see CSRElement::DescribeElement
		*/
		union SSDataDescribed
		{
			const instrument::CSRInstrument * fInstrument;
			const market_data::SSYieldCurve * fYieldCurve;
			const portfolio::CSRTransaction * fTransaction;
			const portfolio::CSRPortfolio * fPortfolio;
		};

		struct SOPHIS_FIT ElemValue {
			virtual ~ElemValue();
			virtual bool Compare(const ElemValue &other) const = 0;
		};

		/** Class CSRElement: to manage an element on a dialog CSRFitDialog.
		The class CSRElement is a base class from which all dialog elements derive. A CSRElement does not necessarily
		belong directly to a dialog, it can also be part of a special CSRElement : the CSREditList which
		handles one or more lists of CSElements. CSRElement is a friend of the CSRFitDialog class.
		All CSRElement-derived objects will contain a data value member, of which the presentation and manipulation
		takes place through the CSRFitDialog or a CSREditList list.
		*
		*	@version 3.1
		*/
		SPH_BEGIN_NOWARN_EXPORT
		class SOPHIS_FIT CSRElement
		{
		public:
			/**Constructor.
			The constructor CSRElement::CSRElement() initialises the fields fElementId, fChampDansTable,
			fDialog & fEditList of the current CSRElement.
			*/
			CSRElement();

			/**Overloaded Constructor 1.
			The parameter columnName has no effect when deriving a generic security dialog (of type CSRInstrumentDialog).
			It is always assumed that the name of all user created fields obey the following pattern:
				ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSRElement belongs.
			@param ERId_Element is the relative number of the element. If negative, CSRFitDialog will assume that there is no such element in the associated resource. The element will therefore not be handled visually. However, the field columnName associated with this element will be taken into consideration and its content will always be accessible.
			@param columnName is the name of a column of the Xxx Sophis table handled by the CSRXxx object. For instance, ZZZ_MyColumn in the table TITRES handled by CSRInstrument.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRElement(CSRFitDialog *dialog, int ERId_Element, const char *columnName = kUndefinedField, const char * tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			The parameter columnName has no effect when deriving a generic security dialog (of type CSRInstrumentDialog).
			It is always assumed that the name of all user-created fields obey the following pattern:
				ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param list is a pointer to the editable list to which this element belongs . This parameter is used to set the values of the fEditList fields.
			@param CNb_Column is relative number of the CSRElement's column.
			@param columnName is the column name of a user's table which structure possesses at least the two following fields:
			- CODE number(10): security identifier, to link with the Sophis table
			- NUMERO number(3): line identifier on the table.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRElement(CSREditList *list, int CNb_Column, const char *columnName = kUndefinedField, const char * tagColonne = kSameAsOracleName);

			/**Destructor.
			This is called automatically by CSRFitDialog::~CSRFitDialog(). Therefore it should never be called explicitly.
		
			*/
			virtual ~CSRElement();

			/**Called when the dialog is opened.
			Method called automatically by fDialog::Open().
			The overriding method will initialise the element as specified by the user.
			@version 4.5.2
			*/
			virtual	void	Open(void);

			virtual void	OpenAfterInit(void);

			/**Called when the dialog is closed.
			When a dialog is closed, fDialog::DoDialog() calls CSRElement::Close() in turn for all of its elements. If one of these
			calls returns false, the dialog does not end.
			Overriding method may perform specific tasks when closing.
			@return true if the element is ended successfully.
			@version 4.5.2
			*/
			virtual	Boolean	Close(void);

			/**Validates an element in the context.
			When selection moves from one element of the dialog to another one, the method CSRElement::Validation()
			of the current element is called and (if the call ends succesfully). This is followed by calling CSRFitDialog::ElementValidation().
			@return true if the element validation is successful.
			@version 4.5.2
			*/
			virtual	Boolean	Validation(void);

			/** Reads the value of the element from a string.
			This method is needed only if the CSRElement is embedded into a CSREditList.
			The method is the link between the pictural representation of the information and its storage in the CSRElement.
			You can override it if the storage or the interpretation of the information is not of a trivial kind. The method will
			receive a pointer to the string to interpret (the parameter sourc) as well as the number of the information
			line in a CSREditList grid (the parameter line). The interpreted value is then input to its storage in the CSRElement.
			Further to the interpretation, the overriding method may impose conditions such as the value being within a range allowed.
			If successful, StringToValue() stores the information in its
			fields and returns true.
			Overriding this method can also prove to be very useful when storing an element that involves recalculating the
			values of one or many other cells.
			@param sourc is a pointer to the string to interpret the information.
			@param line is the line number on the CSREditList grid that refers to the information.
			@return true if interpreting and inputing the information is successful, and all conditions are passed.
			@version 4.5.2
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/** Writes the value of the element in a string.
			This method is needed only if the CSRElement is embedded into a CSREditList.
			This method is the link between the value of the CSRElement and its pictural representation.
			In the overriding method, first the value within CSRElement is formated then stored in the string dest.
			The parameter line is the number of the information (destination) line in a CSREditList grid.
			This method is called automatically by Update() and UpdateElement().
			@param dest is a string of the pictorial representation, to which the element's value is to be formatted and sent.
			@param line is the line number on the CSREditList grid that refers to the information.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;
            virtual ElemValue* GetComparableValue(int line) const;

			/** Used to retrieve the element's value, and set a style to the element.
			This method is needed only if the CSRElement is embedded into a CSREditList.
			In a similar way as in ValueToString(), the element's value is written to the parameter 'value'.
			A style is also set to parameter 'style'. Parameter 'value' is of type SSCellValue which is a union of several
			type fields. SSCellStyle is a structure with different characteristics describing the pictorial representation
			in the element.
			The overriding method will assign the 'value' with the appropriate type, and will setup a style depending on the value.
			The value and the style objects will then be used as needed within the context where GetDisplayValue() is called.
			The default method will simply call ValueToString(), and set up a basic style.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style object that will be modified/initialised for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to assign.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Copies the value from a different element.
			Assigns the data value of a different CSRElement\CSRElement-derived object, to the value of the current CSRElement (pointed to by this)
			This method must be overriden in order to deal with the type of the elements' values appropriately, and depending on the type of the CSRElement-derived objects.
			@param is the CSRElement\CSRElement-derived object from which the data value is copied to the current element.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Tests the equality of values in two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if both elements' values are equal.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator == (const CSRElement&, const CSRElement&);

			/**Tests the inequality of values in two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if both elements' values are unequal.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator != (const CSRElement&, const CSRElement&);

			/**Compares the values of two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if first CSRElement's value is inferior-or-equal to second CSRElement's value.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator <= (const CSRElement&, const CSRElement&);

			/**Compares the values of two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if first CSRElement's value is superior-or-equal to second CSRElement's value.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator >= (const CSRElement&, const CSRElement&);

			/**Compares the values of two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if first CSRElement's value is strictly superior to second CSRElement's value.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator > (const CSRElement&, const CSRElement&);

			/**Compares the values of two different CSRElement\CSRElement-derived objects.
			Uses CSRElement::Compare().
			@param first CSRElement\CSRElement-derived object.
			@param second CSRElement\CSRElement-derived object.
			@return 1 if first CSRElement's value is strictly inferior to second CSRElement's value.
			@version 4.5.2
			*/
			friend SOPHIS_FIT int  operator < (const CSRElement&, const CSRElement&);

			/** Compares the value of the current element with a different element's value.
			Compares the value of this CSRElement\CSRElement-derived with the value of a different
			CSRElement\CSRElement-derived object.
			It returns an integer describing how the two values compare.
			You must override this method in order to carry out a customised comparison depending on the
			types and purposes of the CSRElement-derived classes involved.
			@param a CSRElement\CSRElement-derived object with which the current element is compared.
			@return 0 if both elements values are equal, -1 (or negative value) if this element's value is inferior to param element's value, +1 (or positive value) if this element's value is superior to param element's value.
			@version 4.5.2
			*/
			virtual int	Compare(const CSRElement&) const;

			/**Assigns a new value to the element's value member.
			Type of parameter is unknown. Overriding method will copy the parameter value to the current element's value
			depending on the types and purposes of the CSRElement-derived classes involved.
			@param value is a pointer to an unknown type. The object is cast to approprite type depending on the types and purposes of the CSRElement-derived classes involved. The value is then copied into the current element's value.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/** Assigns the element's value member to a parameter.
			Type of parameter is unknown. Overriding the method will copy the current element's value to the parameter value
			depending on the types and purposes of the CSRElement-derived classes involved.
			@param value is a pointer to an unknown type. The object is cast to approprite type depending on the types and purposes of the CSRElement-derived classes involved. The current element's value is then copied into the parameter's value.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/** Ask for complexed items if it has been modified.
			It is essentially overloaded for tab control to check all items in the tab control.
			It is called by {@link CSRFitDialog::GetModified} for each item of the dialog.
			@return false by default.
			@since 4.4.1.2
			*/
			virtual bool	GetModified() const;

			/**Gets the number of lines held by a list element.
			This is useful only when the element is a CSREditList (i.e. a list of elements).
			If the CSRElement is not of the CSREditList type GetLineCount() ( which needs not be called,
			except in a routine where one does not want to test the types of all the elements) will return 0.
			Otherwise, GetLineCount() returns the number of lines in the CSREditList buffer.
			@return the number of lines in the CSREditList buffer.
			@version 4.5.2
			*/
			virtual	int		GetLineCount(void) const;

			/**Enlarge the number of lines held by a list element.
			This is useful only when the element is a CSREditList (i.e. a list of elements).
			If the CSRElement is not of the CSREditList type, SaveLineCount() (which needs not be called,
			except in a routine where one does not want to test the types of all the elements) won't do anything.
			Otherwise, SavetLineCount() enlarge the number of lines in the CSREditList buffer.
			@param newLineCount New number of lines
			@return true if if line number has been modified, false otherwise
			@version 5.1.
			*/
			virtual	bool SaveLineCount(int newLineCount);

			/**Gets the value of a cell of a CSREditList.
			Only useful when the element is a CSREditList (i.e. a list of elements).
			LoadElement() transfers to *address the information handled by the element of which the relative
			number is CNb_Column with respect to the line lineIndex.
			If a CSRElement is not a CSREditList, LoadElement(), which needs not be called (except in a
			routine where one does not want to test the types of all the elements), then it returns false.
			@param lineIndex is the line on the CSREditList list that corresponds to the element in the list from which information sought.
			@param CNb_Column is the relative number of the element from which information is sought.
			@param address is a pointer to the object to which the element's information is copied. It points to an unknown type depending on the type and purposes of the CSRElement-derived element in the list.
			@return true if loading is successful.
			@version 4.5.2
			*/
			virtual	Boolean	LoadElement(int lineIndex,int CNb_Column,void *address) const;

			/**Set the value of a cell of a CSREditList.
			Only useful when the element is a CSREditList (i.e. a list of elements).
			SaveElement() transfers from *address to the element of which the relative
			number is CNb_Column with respect to the line lineIndex.
			If a CSRElement is not a CSREditList, SaveElement(), which needs not be called (except in a
			routine where one does not want to test the types of all the elements), then it returns false.
			@param lineIndex is the line on the CSREditList list that corresponds to the element in the list to which information will be saved.
			@param CNb_Column is the relative number of the element from to which information will be saved.
			@param address is a pointer to the object to which the element's information is get. It points to an unknown type depending on the type and purposes of the CSRElement-derived element in the list.
			@return true if saving is successful.
			@version 4.5.2
			*/
			virtual	bool SaveElement(int lineIndex, int CNb_Column, void * address);

			/** Enable/disable inputs when the element belongs to a list.
			Only useful when the element is within a CSREditList (i.e. a list of elements).
			CSREditList calls this method to know if the user is authorized to key information in the current
			CSRElement when it belongs to a CSREditList. You overload it so that it will return true
			or false whether your element should or not be editable.
			@return true if the current element allows editing information.
			@version 4.5.2
			*/
			virtual	Boolean	CanBeModifiedInAList(void) const;
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			void			SetText(const char *text, eAlignmentType align=aLeft);

			/**Returns the Relative ID of an element.
			Returns the value stored in fElementId set in the dialog's constructor. If the CSRElement
			is a column of CSREditList, then fElementId is its column number in the list fEditList.
			@return the number of the element within its native dialog.
			@version 4.5.2
			*/
			int				GetRelativeId(void) const { return fElementId; }

			/**Returns the absolute number of the element.
			The method returns:
			-  fElementId if fDialog::fShiftValue is nvZero or if the CSRElement index in fDialog::fElementList is smaller
			than fDialog::fFirstShiftedElement.
			-  fElementId+fDialog::fShiftValue otherwise.
			Note: the absolute number of an element is its number in the 'DLOG' type resource of the 'ResourceUtilisateur.rsrc' file.
			@return the absolute number of the element.
			@version 4.5.2
			*/
			int				GetAbsoluteId(void) const;

			/**Checks whether a given ID is the relative ID of the element.
			The overriding method can treat this differently, for example, by simply checking if the given ID is within a certain range
			if relative element IDs.
			@param ERId_Element is the number to check whether it is the relative ID of the element.
			@return true if ERId_Element is the relative ID of the current element.
			@version 4.5.2
			*/
			virtual	bool	IsARelativeId(int  ERId_Element) const;

			/**Returns the type of alignment of information presented by the element.
			The Alignment is the position in which the information on the element is placed, that is, either Left, Right, or Centered.
			@return the position, of type eAlignmentType, of information on the element. Values returned: aRight, aLeft or aCenter.
			@version 4.5.2
			*/
			eAlignmentType	GetAlignment() const;

			/**Sets the alignment of information on the element.
			By default, a newly created CSRElement\CSRElement-derived object has information aligned on the Left.
			@param align is the new alignment value set to the element.
			@version 4.5.2
			*/
			void			SetAlignment(eAlignmentType align);

			void			SetItemIndex(int index) { fItemIndex = index; }	// internal
			int				GetItemIndex() const { return fItemIndex; }		// internal

			/**Gets the associated dialog if the element is part of a dialog.
			Returns the value stored in fDialog (which has been set in the dialog constructor).
			Note: if the current CSRElement is a CSREditList column then fDialog is NULL.
			@return a pointer to the dialog object that contains the current element.
			@version 4.5.2
			*/
			CSRFitDialog	*GetDialog(void) const { return fDialog; }

			/**Gets the associated edit list if the element is a column of a list element.
			Returns the value stored in fEditList (which has been set in the dialog constructor).
			Note: if the current CSRElement is an element within a CSRDialog, then fEditList is NULL.
			@return a pointer to the fEditList list object in which the current element is a column.
			@version 4.5.2
			*/
			CSREditList		*GetEditList(void) const { return fEditList; }

			/** Checks whether it is permitted to reset the data value of the element.
			The overriding method will state conditions to determine whether the value of the current element can be
			assigned to its reset value. The reset value is established according to the type and purpose
			of the CSRElement-derived class.
			In most cases, when IsPossibleToReset() returns true, method Reset() is called.
			@return true if the element's value can be reset.
			@version 4.5.2
			*/
			virtual bool	IsPossibleToReset() const { return fPossibleToReset; } // override

			/**Imposes whether resetting the data value of the element must be allowed or not.
			By default, the method makes the action of resetting the element's value possible.
			The parameter value of this method will then be refered to by IsPossibleToReset() in order to
			inform on the resetting permission.
			@param yesno is a boolean value which will state whether resetting is allowed or not.
			@version 4.5.2
			*/
			void			SetPossibleToReset(bool yesno=true) { fPossibleToReset = yesno; }

			/** Assigns the data value of the current element to its reset value.
			Usually, the reset value is designed to be a value that is not within the set of values of the element that
			lead to calculation and processing. It is way of saying that the element "has no value".
			In the overriding method, the user will decide on a value according to the type and purpose
			of the CSRElement-derived class.
			@version 4.5.2
			*/
			virtual void	Reset() ;

			/**Refreshes the current element.
			Typically, method Update() is called from within SetValue() to display the current CSRElement's new value.
			Overriding method may perform further alterations. For example, if the element is within a list, when modifying
			its value, it calls	Update() in order update values of other elements on the same line in the list.
			@version 4.5.2
			*/
			virtual void	Update(void) const;

			/** Hides the element from appearing on the dialog.
			Only useful when the element is within a CSRFitDialog.
			Hides and disconnects the current element.
			Overriding method may perform further actions on other elements on the dialog. For example, if a CSRElement check box
			for "Include Currency" is hidden, then the CSRElement pop-up menu for "Select Curreny" must also be hidden.
			@version 4.5.2
			*/
			virtual void	Hide(void) const;

			/**Shows the element.
			Function overloaded.
			Only useful when the element is within a CSRFitDialog.
			Reconnects and redisplays an element to which the CSRElement::Hide() method has previously been applied.
			Overriding method may perform action that causes other elements related to current element to show as a result.
			@version 4.5.2
			*/
			virtual void	Show(void) const;

			/**Either shows or hides the element, according to parameter.
			Function overloaded.
			Only useful when the element is within a CSRFitDialog.
			The method actually invokes Hide() and Show() according to parameter.
			@param show is a boolean that is true if the element is to Show, false if it is to Hide.
			@version 4.5.2
			*/
			void			Show(bool show) const;

			/**Whether the element is shown or hidden (depending on previous calls to Show(), Show(bool) or Hide())
			@version 6.2
			*/
			bool	IsVisible() const;

			/** Disables the element.
			Only useful when the element is within a CSRFitDialog.
			The element remains visible but is greyed out which shows that it cannot be selected.
			Overriding method may disable or enable other elements as a result.
			@version 4.5.2
			*/
			virtual void	Disable(void) const;

			/**Enables the element
			Only useful when the element is within a CSRFitDialog.
			Function overloaded.
			Re-enables an element of the dialog to which the CSRElement::Disable() method has previously been applied.
			Overriding method may disable or enable other elements as a result.
			@version 4.5.2
			*/
			virtual void	Enable(void) const;

			/**Enables or disables an element according to parameter.
			Only useful when the element is within a CSRFitDialog.
			Function overloaded.
			The method calls either Enable() or Disable() according parameter.
			@param enable is a boolean that is true if the element is to be enabled, false if the element is to be disabled.
			@version 4.5.2
			*/
			void			Enable(bool enable) const;

			/** Specify a comment and the status for generation of the grammar.
			@param comment is a C String that will appear in grammar generation; it may be null.
			@param mandatory specify if minoccurs = 0 or 1; the default is false.
			@since 4.5.2.2
			*/
			void SetXMLGrammar(const char *comment, bool mandatory);

		public:
			DECLARATION_CASTAGE2
			ELEM_COMMON_INTERNALS

			const char	*GetAlignement() const;							// internal
			const char	*SetAlignement(const char * align);				// internal
			const char	*GetChampsDansTable() const {return fChampDansTable; } // internal
			void		IgnorePadding(bool ignore = true) { fIgnorePadding = ignore; } // internal??

			/**Returns the size (in bytes) of the type of element's value.
			By default, the constructors CSRElement() sets the size of 'long' type, that is 4 bytes.
			The overriding CSRElement constructor usually simply sets the data length to the sise of the element's value type.
			If the data value is a C string, then the data length may simply be the maximum number of characters for the string.
			The Data Length is generally used internally within the CSRElement to help set up SQL queries for data exchange
			between the element and the database.
			@return a long value that is the size of the element's data value.
			@version 4.5.2
			*/
			unsigned long	GetDataLength() const { return fDataLength; }

			virtual	void	RequetesEcriture(
										int			numElement,
										char		**updateQuery,
										char		**insertQuery,
										const char	*defaultName = 0);				// internal
			virtual short	DonneFiltre(void) const;								// internal
			virtual	int		DonneTypeTri() const;									// internal
			virtual USMenu	*DonneMenu(void) const;									// internal
			virtual short	GetListValue(void) const;								// internal
			virtual void	SetListValue(short value);								// internal
			virtual Boolean	IsASharedMenu() const;									// internal

					void	InitialiseOracle2(	Tdescribe 		*desc,
												char			**read,
												char			**write,
												int 			fieldType,
												int 			size,
												char 			**insert,
												const char 		*fieldName=0);		// internal

					void	InitQueriesFinal(	Tdescribe		*desc,
												char			**selectQuery,		// internal
												char			**insertQuery,
												int				fieldType,
												int				size,
												const char		*defaultFieldName = 0);

			virtual int		NumElementGere(void);									// internal
			virtual sophis::sql::errorCode	ReadQuery(char* result, long code);						// internal
			virtual sophis::sql::errorCode	WriteQuery(char* result, long code);					// internal

			/**Changes a particular database table record corresponding to the element to being a historic record.
			Method suitable for a CSREditList\CSREditList-derived element. Given the list's database table (see CSREditList),
			it updates the a record of unique column value 'sico', with new value 'sico_histo' that is the audited value of 'sico'.
			This way, the original record 'sico' becomes a historic\audit record.
			The method can be overriden to work in any similar way depending on the type and purpose
			of the CSREditList\CSRElement-derived class.
			@param sico is the original value in the unique column that refers to the record, in the element's database table.
			@param sico_histo is the new value in the unique column that refers to the record refered to by 'sico'. This means that the record has become an audit\historic.
			@return a short value the indicates the outcome of the database update.
			@version 4.5.2
			*/
			virtual sql::errorCode	Historise(long sico, long sico_histo);

			/** Adds historic/audit records to a database table, given the original records.
			Method suitable for a CSREditList\CSREditList-derived element. Given the list's database table (see CSREditList),
			Works in a similar way as Historise(). Instead of modifying the original records of 'sico' in a table to audit records,
			it duplicates 'sico' records and gives the copy records 'sico_histo' as their new value in their unique column. That is,
			the new records are audit records of the original records already in the database table.
			You can override this method to work in any similar way depending on the type and purpose.
			@param sico is the original value in the unique column that refers to the record(s), in the element's database table.
			@param sico_histo is the new value in the unique column that refers to the record(s) refered to by 'sico'. This means that the record has become an audit\historic.
			@return a short value the indicates the outcome of the database update.
			@version 4.5.2
			*/
			virtual	sql::errorCode	HistoDuplicate(long sico, long sico_histo);

			virtual short	Free(char* result);							// internal
			virtual short	Duplicate(char* result);								// internal
			
			virtual void	LoadElementByType(void *adresse);						// internal
			virtual	void	InitialiseOther(const CSRElement & elem);				// internal

			// Copy/paste & drag/drop operations
			virtual bool	CanDropFromDump(USWindow* dumpWind, long nbelem, const long* elem) const;			// internal
			virtual bool	PasteFromDump(USWindow* dumpWind, long nbelem, const long* elem);					// internal
			virtual bool	PasteFromHier(const CSWindHier* windHier, long nbelem, const long* elem, long hierColumnId, long targetLineId, long targetColumnId); // internal
			virtual bool	PasteFromNavbar(long nbelmen, const NavBarDumpData* data); //internal
			virtual bool	CanDropFromHier(const CSWindHier* windHier, long nbelem, const long* elem, long columnNumber) const; // internal
			virtual bool	CanDropFromNavbar(long nbelmen, const NavBarDumpData* data) const; //internal

			void			SetOffset(long offset);
			const int &		GetOffset() const;


			/**Call this method to change the style of the text displayed in the element.
			The style is defined in a short that is the result of the bitwise OR operator on
			{@link sophis::gui::eTextStyleType}.
			As an example, if you want a bold italic style, you call : SetTextStyle( tsBold | tsItalic );
			Note that this feature may not work on all the type of element.
			Note that this method can be called at any time.
			@param style : a short describing the style to set.
			@see {@link GetTextStyle}
			@version 5.3
			*/
			void					SetTextStyle( const short & style );

			/**Call this method to retrieve the style of the text displayed in the element.
			The style is defined in a short that is the result of the bitwise OR operator on
			{@link sophis::gui::eTextStyleType}.
			As an example, if you want to know if the text is bold, you have to test :
			( 0 != ( tsBold & myElement.GetTextStyle() ) )
			Note that this feature may not work on all the type of element.
			@return : a short describing the style to set.
			@see {@link SetTextStyle}
			@version 5.3
			*/
			const short &	GetTextStyle() const;

			/**Call this method to change the color of the text displayed in the element.
			Note that this method can be called at any time.
			@param color : a {@link sophis::gui::SSRgbColor} describing the color to apply to the text.
			@see {@link GetTextColor}
			@version 5.3
			*/
			void				SetTextColor( const SSRgbColor & color );

			/**Call this method to retrieve the customized color of the text displayed in the element.
			@return a {@link sophis::gui::SSRgbColor} describing the color of the text.
			@see {@link SetTextColor}
			@version 5.3
			*/
			const SSRgbColor &	GetTextColor() const;

			/**Call this method to activate the smooth display of the element.
			Note that this feature does not work for all the elements and that its effect may vary from an
			element to another.
			As an example, in a CSREditDouble, 1000000 may be displayed as 1000K or 1M depending on the size
			of the element in the dialog resource or on the size of the column in an edit list.
			@param smooth : true to activate the smooth display, false to deactivate it.
			@see {@link GetSmoothDisplay}
			@version 5.3
			*/
			void				SetSmoothDisplay( const bool & smooth = true );

			/**Call this method to know whether or not the smooth display is enabled for an element.
			@return true if the smooth display is enabled, false otherwise.
			@see {@link SetSmoothDisplay}
			@version 5.3
			*/
			const bool &		GetSmoothDisplay() const;

			/*
			Get the tooltip string.
			The tooltip is set during the initialization and changing its value afterwards
			has no effect on the displayed text.
			@return the tooltip string.
			@version 5.1 for CSRButton
			@version 5.3 in CSRElement
			*/
			const _STL::string &	GetTooltip() const;

			/*
			Set the tooltip string.
			The tooltip is set during the initialization and changing its value afterwards
			has no effect on the displayed text.
			@param tooltip the string to use as tooltip for the element.
			@version 5.1 for CSRButton
			@version 5.3 in CSRElement
			*/
			void					SetTooltip(const _STL::string & tooltip);

			/* 
			Get the explicitly defined accessible name string.
			The accessible name is set during initialization.
			@return the explicit accessible name
			@version 7.1
			*/
			const _STL::string &	GetAccName() const;

			/* 
			Set the accessible namestring.
			The accessible name is set during initialization.
			@param AccName the string to use as explicit accessible name (i.e. it overrides the default one).
			@version 7.1
			*/
			void					SetAccName(const _STL::string & AccName);

		protected:

			/**Element's Relative ID in the containing dialog or list.
			@version 4.5.2
			*/
			int				fElementId;

			/** The column name (of a Sophis database table), of which the information is handled by the CSRElement element.
			The column name of all user-created fields must obey the following pattern:
				ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			If the element is embedded in a CSREditList, the user's table structure must possess at least the two following fields:
				- CODE number(10): security identifier, To link with the Sophis table,
				- NUMERO number(3): line identifier on the table.
			@version 4.5.2
			*/
			const char		*fChampDansTable;

			/**Link to the dialog that contains the CSRElement.
			@version 4.5.2
			*/
			CSRFitDialog	*fDialog;

			/**Link to the list that includes a column handled by the CSRElement.
			@version 4.5.2
			*/
			CSREditList		*fEditList;

			long			fDecalageInitial;	// internal
			char			*fAlignement;		// internal
			bool			fIgnorePadding;		// internal
			unsigned long	fDataLength;		// internal

			/**The position in which the information on the element is placed, that is, either Left, Right, or Centered.
			The constructors of CSRElement all set the alignment to Left by default.
			@version 4.5.2
			*/
			eAlignmentType	fAlignment;			// not used everywhere

			bool			fPossibleToReset;	// internal
			int				fItemIndex;			// internal

			int				fOffset;
			mutable bool	fEnabledElement;

			/**Positions\Adjusts a pointer on the correct location on the List\Dialog's values memory.
			Method Overloaded.
			This method is required indirectly by the containing CSRFitDialog\CSREditList in order read\write
			data from\to its internal elements data storage (which is CSRFitDialog::fPointer in the case of a dialog,
			CSREditList::fListeValeur in the case of a list).
			Its purpose is to adjust a parameter pointer to the right position on the storage (according to some
			padding parameters) in order to transfer elements' data to\from database using SQL queries.
			*/
			const char *	GetPtr(const char *, long align = 0) const;

			/**Positions\Adjusts a pointer on the correct location on the List\Dialog's values memory.
			Method Overloaded.
			@see const char *CSRElement::GetPtr(const char*, long)
			*/
			char *			GetPtr( char *, long align = 0) const;

			/** Checks if the element is tied to a database table.
			The element could be contained in a dialog or list, in which case its value is generally tied to a record in a
			database table. The element may also have no interaction with a database table.
			@return true if the elements value is not to read\written to a database table.
			@version 4.5.2
			*/
			bool			NoData() const;

			/** Get the tag for the data service.
			@return 0 if no tag.
			@since 4.5.2.1
			*/
			const char		*GetTag() const;

			/** Field containing the tag for the data service.
			*/
			char		*fTagName;


			/** mandatory status for XML grammar. 
			Default is false.
			@see SetXMLGrammar
			@since 4.5.2.2
			*/
			bool fMandatory;

			/** comment for XML grammar. 
			@see SetXMLGrammar
			@since 4.5.2.2
			*/
			_STL::string fXMLComment;

			/**The style to apply to the text of the element.
			@version 5.3
			*/
			short			fTextStyle;

			/**If a custom color is being applied to the text of the element.
			@version 5.3
			*/
			bool			fHasTextColor;

			/**The custom color of the text of the element.
			@version 5.3
			*/
			SSRgbColor		fTextColor;

			/**If the smooth display is active or not.
			@version 5.3
			*/
			bool			fSmoothDisplay;

			/**The tooltip associated with the element.
			@version 5.3
			*/
			_STL::string	fTooltip;

			/**The explicit accessible name of the element.
			@version 7.1
			*/
			_STL::string	fAccName;

		friend class CSRFitDialog;
		friend class CSRListAudit;
		friend class CSRPortfolioHeaderDialogInternalData;

		private:
			virtual bool	CanDropFromHier(const CSWindHier* windHier, long nbelem, const long* elem) const;	// internal, DEPRECATED
			virtual bool	PasteFromHier(const CSWindHier* windHier, long nbelem, const long* elem);			// internal, DEPRECATED

			/// Generic getter and setter for a CSRElement
			template <typename element_type, typename value_type>
			class ElementGetterAndSetter {
			public:
				static void Get(element_type* pElement, value_type& valueOut) {
					pElement->GetValue(&valueOut);
				}
				static void Set(element_type* pElement, const value_type& value) {
					pElement->SetValue(&value);
				}
			};

			/// Specialization of ElementGetterAndSetter for string values (that are actually stored as const char* in all known CSRElement subclasses)
			template <typename element_type>
			class ElementGetterAndSetter<element_type, _STL::string> {
			public:
				static void Get(element_type* pElement, _STL::string& valueOut) {
					char* temp = new char[pElement->GetMaxChar() + 1];
					pElement->GetValue(temp);
					valueOut = temp;
					delete[] temp;
				}
				static void Set(element_type* pElement, const _STL::string& value) {
					pElement->SetValue(value.c_str());
				}
			};

		public:

			bool			IsEnabled() const;

			template <typename T>
			static void GetElementValue(T* pElement, typename T::value_type& value) {
				// Trigger a compilation error if this function is not called on a CSRElement descendent.
				if (false) CSRElement* pBaseElement = pElement;

				if (!pElement) {
					ASSERT(!"null element !"); return;
				}
				ElementGetterAndSetter<T, typename T::value_type>::Get(pElement, value);
			}

			template <typename T>
			static typename T::value_type GetElementValue(T* pElement) {
				typename T::value_type value;
				GetElementValue<T>(pElement, value);
				return value;
			}

			template <typename T>
			static void SetElementValue(T* pElement, const typename T::value_type& value) {
				// Trigger a compilation error if this function is not called on a CSRElement descendent.
				if (false) CSRElement* pBaseElement = pElement;
				
				if (!pElement) {
					ASSERT(!"null element !"); return;
				}
				ElementGetterAndSetter<T, typename T::value_type>::Set(pElement, value);
			}

			/**
			 * Try and give focus to this element.
			 * @return true if focus was successfully passed to the element
			 */
			virtual bool	SetFocus();
		};




		struct NavBarDumpData {

			enum NavBarItemType {
				Folio = 1,
				Misc = 2 //other type of elements that can be found in navbar
			};

			NavBarItemType type;
			long id;

		};

		SPH_END_NOWARN_EXPORT
	}
}
SPH_EPILOG
#endif
