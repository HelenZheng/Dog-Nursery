#ifndef _SphElementPointer_H__
#define _SphElementPointer_H__

#include "SphInc/gui/SphElement.h"
#include "SphInc/gui/SphMenu.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		/** class CSRElementPointer: To manage elements whose type could change in runtime.
		For example, a CSREditList having a column where different elements are defined depending on the line,
		some of the can be text, others menus, etc.
		Very useful and straight forward when the data to be displayed is Describable, because the element which is going to be called is already defined in the
		description and can be accessed easily (an example in ForecastScenarioGUI).
		@version 6.1
		@see CListForecastRuleEdit
		*/

		class SOPHIS_FIT CSRElementPointer : public CSRElement
		{
		public:

			/* Constructor
			The default constructor initializes the element pointer member variable as 0 (null) and calls the CSRElement default constructor.
			@version 6.1
			*/
			CSRElementPointer();

			/* Overloaded constructor
			Initializes the element pointer member variable as 0 (null) and calls the CSRElement default constructor.
			@param list is a pointer to the editable list to which this element belongs. This parameter is used to set the values of the fEditList fields.
			@param ERId_List is relative number of the CSRElement in the list.
			@version 6.1
			*/
			CSRElementPointer(CSREditList* list, int ERId_List);

			// Destructor not defined (default CSRElement destructor used) due to fElem is not reserved inside this class.
			//~CSRElementPointer();

			/* ValueToString
			If the element pointer is initialized, it calls to its ValueToString function.
			@param dest is a string of the pictorial representation, to which the element's value is to be formatted and sent.
			@param line is the line number on the CSREditList grid that refers to the information.
			@version 6.1
			*/
			virtual void ValueToString(char *dest, int line) const;

			/* StringToValue
			If the element pointer is initialized, it calls to its StringToValue function.
			@param sourc is a pointer to the string to interpret the information.
			@param line is the line number on the CSREditList grid that refers to the information.
			@version 6.1
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/* DonneMenu
			If the element pointer is initialized, it calls to its DonneMenu function.
			@version 6.1
			*/
			virtual MenuHandle DonneMenu(void) const;

			/* GetListValue
			If the element pointer is initialized, it calls to its GetListValue function.
			@version 6.1
			*/
			virtual short GetListValue(void) const;

			/* SetListValue
			If the element pointer is initialized, it calls to its SetListValue function.
			@param value is the position in the menu list.
			@version 6.1
			*/
			virtual void SetListValue(short value);

			/* SetValueFromList
			If the element pointer is initialized, it calls to its SetValueFromList function.
			@version 6.1
			*/
			virtual void SetValueFromList();

			/* GetValue
			If the element pointer is initialized, it calls to its GetValue function.
			@version 6.1
			*/
			virtual void* GetValue() const;

			/* GetValue
			If the element pointer is initialized, it calls to its GetValue function.
			@param value is a pointer to a long type. The current element's value is then copied into the parameter's value.
			@version 6.1
			*/
			virtual void GetValue(long* value) const;

			/* CanBeModifiedInAList
			If the element pointer is initialized, it calls to its CanBeModifiedInAList function.
			@version 6.1
			*/
			virtual Boolean CanBeModifiedInAList(void) const;

			/* MenuCanBeModifiedInAList
			If the element pointer is initialized, it calls to its MenuCanBeModifiedInAList function.
			@version 6.1
			*/
			virtual Boolean MenuCanBeModifiedInAList(void) const;

			/* IsASharedMenu
			If the element pointer is initialized, it calls to its IsASharedMenu function.
			@version 6.1
			*/
			virtual Boolean IsASharedMenu() const;

			/* fElem
			Pointer to any kind of CSRElement derived class (or to CSRElement itself) which represents the element to be used.
			@version 6.1
			*/
			CSRElement* fElem;
		};
	}
}
SPH_EPILOG
#endif
