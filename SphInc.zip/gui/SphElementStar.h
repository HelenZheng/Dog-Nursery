/*! \file SphElementStar.h
	\brief Manages * in a CSRElement.
*/

#pragma once
#ifndef _SphElementStar_H_
#define _SphElementStar_H_

/*
 * CSRElementStar class
 * (C) 2002 Sophis
 * This is a CSRElement-derived class which manages another CSRElement plus a star (*).
 * If the element is a popup, a star is added to the menu.
 * The value corresponding with the star is 0.
 * Available in SophisLimitGUI
 * Exported in SophisInterface, Not documented
 */

#include "SphInc/gui/SphElement.h"
#include "SphSDBCInc/SphSQLDataTypes.h"

#ifndef SOPHIS_INTERFACE
#	define SOPHIS_INTERFACE
#endif

SPH_PROLOG
class SOPHIS_INTERFACE CSRElementStar : public sophis::gui::CSRElement
{
public:
	CSRElementStar(sophis::gui::CSRElement* element);
	~CSRElementStar();
	void Init();
	ELEM_COMMON_INTERNALS

	virtual	void	Open(void);
	virtual void	OpenAfterInit(void);

	virtual	Boolean	Close(void);
	virtual	Boolean	Validation(void);

	virtual Boolean	StringToValue(const char *sourc, int line);
	virtual void	ValueToString(char *dest, int line) const;
	virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

	virtual void operator = (const sophis::gui::CSRElement&);

	virtual int	Compare(const sophis::gui::CSRElement&) const;

	virtual void	SetValue(const void *value);
	virtual void	GetValue(void *value) const;

	virtual	int		GetLineCount(void) const;
	virtual	Boolean	LoadElement(int lineIndex,int CNb_Column,void *address) const;
	virtual	Boolean	CanBeModifiedInAList(void) const;
	virtual Boolean	MenuCanBeModifiedInAList(void) const;

	virtual bool IsPossibleToReset() const ;
	virtual void Reset() ;

	virtual void	Update(void) const;
	virtual void	Hide(void) const;
	virtual void	Show(void) const;

	virtual void	Disable(void) const;
	virtual void	Enable(void) const;
	virtual bool	IsEnabled() const;

	virtual	void	RequetesEcriture(
								int			numElement,
								char		**updateQuery,
								char		**insertQuery,
								const char	*defaultName = 0);				// internal
	virtual short	DonneFiltre(void) const;								// internal
	virtual	int		DonneTypeTri() const;									// internal
	virtual USMenu	*DonneMenu(void) const;									// internal
	virtual short	GetListValue(void) const;								// internal
	virtual void	SetListValue(short value);								// internal
	virtual Boolean	IsASharedMenu() const;									// internal

	virtual int		NumElementGere(void);									// internal
	virtual sophis::sql::errorCode	ReadQuery(char* result, long code);						// internal
	virtual sophis::sql::errorCode	WriteQuery(char* result, long code);					// internal
	virtual sophis::sql::errorCode	Historise(long sico, long sico_histo);
	virtual	sophis::sql::errorCode	HistoDuplicate(long sico, long sico_histo);
	virtual short	Free(char* result);										// internal
	virtual short	Duplicate(char* result);								// internal
	virtual	void	InitialiseOther(const sophis::gui::CSRElement & elem);	// internal

	// Copy/paste & drag/drop operations
	virtual bool	CanDropFromDump(USWindow* dumpWind, long nbelem, const long* elem) const;			// internal
	virtual bool	PasteFromDump(USWindow* dumpWind, long nbelem, const long* elem);					// internal
	virtual bool	CanDropFromHier(const CSWindHier* windHier, long nbelem, const long* elem, long columnNumber) const;	// internal
	virtual bool	PasteFromHier(const CSWindHier* windHier, long nbelem, const long* elem, long hierColumnId, long targetLineId, long targetColumnId);			// internal

	virtual sophis::gui::CSRElement* GetElement() {return fElement;}

protected:
	sophis::gui::CSRElement* fElement;		// The element managed
	mutable USMenu* fMenuHandle;		// The popup menu (if needed)
	void* fValueBuffer;			// The buffer where value is stored
	void* fValueBufferBlank;	// The same buffer filled with 0
};
SPH_EPILOG
#endif // _SphElementStar_H_
