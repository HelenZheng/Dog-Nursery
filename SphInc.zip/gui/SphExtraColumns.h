/*
 	File:		SphExtraColumns.h

 	Contains:	Interface for extra columns.

 	Copyright:	� 2001-2002 Sophis.
*/

/*! \file SphExtraColumns.h
	\brief Interface for extra columns.
*/

#pragma once

#ifndef _SPHEXTRACOLUMNS_H_
#define _SPHEXTRACOLUMNS_H_

#include "SphTools/SphCommon.h"
#include __STL_INCLUDE_PATH(iosfwd)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG
namespace sophis {
	namespace gui {
		class CSRElement;
	}
	namespace sql	{
		class CSRStructureDescriptor;
	}
	namespace gui	{

struct SSExtraColumns
{
};

class ISRExtraColumns
{
public:
	ISRExtraColumns() {}
	virtual ~ISRExtraColumns() {}

	/** No implementation */
	virtual int GetExtraColumnsCount() const { return 0; }

	/** No implementation */
	virtual CSRElement * new_CSRElement(int nth) const {return 0;}

	/** No Implementation */
	virtual const char * GetTableSuffixe() const { return "toto";}



	/** With the two first methods and CSRElement::InitialiseOracle, new_descriptor can implement a CSRStructureDescriptor on SSExtraColumns. */
	virtual sql::CSRStructureDescriptor	* new_descriptor_values() const { return 0;}

	/** With the two first methods, read_values_query can implement the list of names " C1, C2, C3 ". */
	virtual _STL::string	read_values_query() const { return ""; }

	/** With the two first methods, update_values_query can implement the string  " C1 = :c1, C2=:c2, C3=:c3 ". */
	virtual _STL::string	update_values_query() const { return ""; }


	enum	eImplementationState
	{
		eNoImplementation,
		eOnlyDescriptor,
		eOnlyGUI,
		eBoth
	};

	/** According new_CSRElement, return eNoImplementation or eBoth */
	virtual eImplementationState	State() const { return eNoImplementation; }
};


	}
}

SPH_EPILOG
#endif



