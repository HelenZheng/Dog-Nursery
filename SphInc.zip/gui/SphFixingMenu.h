#pragma once

#ifndef _SPH_FIXING_MENU_
#define _SPH_FIXING_MENU_

#include "SphInc/gui/SphCustomMenu.h"

SPH_PROLOG
namespace sophis	{
	namespace gui	{

		class SOPHIS_FIT  CSRFixingMenu : public CSRCustomMenu
		{
		public:
			CSRFixingMenu(	CSRFitDialog* dialog, 
							int NRE_Menu, 
							bool editable=true);
			CSRFixingMenu(	CSREditList* l, 
							int NRC_Menu, 
							bool editable=true);
		protected:
			void BuildMenu();
			void SetValueFromList();
			void SetListFromValue();
		};
	}
}
SPH_EPILOG

#endif