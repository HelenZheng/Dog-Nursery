#pragma once
#ifndef	__SphGenericForm_H__
#define	__SphGenericForm_H__

#include "SphInc/SphMacros.h"
#include "SphTools/SphCommon.h"

#include __STL_INCLUDE_PATH(map)

SPH_PROLOG
namespace sophis {
	namespace gui {
		/**
		 * Parent class for all form-like classes, such as input dialogs and edit lists.
		 */
		class SOPHIS_FIT CSRGenericForm {
		public:
			virtual ~CSRGenericForm() {}
		};
	}; // namespace gui
}; // namespace sophis

/**
 * Macro that generates a trivial factory function for a derivate of the CSRElement class
 * @param Type class which factory is wanted. The factory method will be named after the type (say, if type is CSRMyElement, function name will be newCSRMyElement)
 */
#define TRIVIAL_ELEMENT_FACTORY(Type) \
	Type* new ## Type(sophis::gui::CSRGenericForm* pForm, int referenceInForm);

#define TRIVIAL_ELEMENT_FACTORY_IMPL(Type, ns) \
	Type* ns::new ## Type(sophis::gui::CSRGenericForm* pForm, int referenceInForm) { \
	CSRFitDialog* pDialog = dynamic_cast<sophis::gui::CSRFitDialog*>(pForm); \
	if (pDialog) { \
	return new Type(pDialog, referenceInForm); \
	} else { \
	return new Type(dynamic_cast<sophis::gui::CSREditList*>(pForm), referenceInForm); \
	} \
}


SPH_EPILOG

#endif // __SphGenericForm_H__