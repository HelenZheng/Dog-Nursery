 /*
 	File:		SphInstrumentDialog.h

 	Contains:	Handle a dialog for instrument
 	Copyright:	� 1995-2003 Sophis.

*/

/*! \file SphInstrumentDialog.h
	\brief Handle a dialog for instrument
*/


#pragma once

#ifndef	__SphInstrumentDialog_H__
#define	__SphInstrumentDialog_H__

#include "SphDialog.h"
#include "SphInc/scenario/SphInstrumentDialogInterface.h"

#define DECLARATION_INSTRUMENT_DIALOG(derive)			DECLARATION_DIALOG(derive)
#define WITHOUT_CONSTRUCTOR_INSTRUMENT_DIALOG(derive)	WITHOUT_CONSTRUCTOR_DIALOG(derive)
#define CONSTRUCTOR_INSTRUMENT_DIALOG(derive)			CONSTRUCTOR_DIALOG(derive)

#define INITIALISE_STANDARD_INSTRUMENT_DIALOG(derivedClass,resource,object)					\
	{																						\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;							\
		static SphInstrumentFactoryT<object> _instrumentConstructor;						\
		::NewDialogueTitreSophis(&_dialogConstructor, resource, &_instrumentConstructor);	\
	}

#define INITIALISE_SPECIFIC_DIALOG(derivedClass,object)							\
	{																			\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;				\
		static SphObjectFactoryWithParamT<object> _objectConstructor;			\
		::NewDialogueTitreSophis(&_dialogConstructor, &_objectConstructor);		\
	}

#define INITIALISE_SPECIFIC_INSTRUMENT_DIALOG(derivedClass,object)					\
	{																				\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;					\
		static SphInstrumentFactoryT<object> _instrumentConstructor;				\
		::NewDialogueTitreSophis(&_dialogConstructor, &_instrumentConstructor);		\
	}

#define INITIALISE_OPTION_DIALOG(derivedClass,object,resource)								\
	{																						\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;					\
		static SphInstrumentFactoryT<object> _instrumentConstructor;				\
		::NewDialogueTitreSophis(&_dialogConstructor, &_instrumentConstructor, resource);	\
	}

#define INITIALISE_OPTION_TICKET(derivedClass,object,resource,derivedClass2)				\
	{																						\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;					\
		static SphInstrumentFactoryT<object> _instrumentConstructor;				\
		static SphDialogFactoryT<derivedClass2> _dialogConstructor2;					\
		::NewDialogueTitreSophis(&_dialogConstructor, &_instrumentConstructor, resource, &_dialogConstructor2);	\
	}

/** Macro to overload one of the option dialog and allowing to modify the dialog.
This is usefull if you want to modify just the Gui of a Sophis dialogs. 
This new dialog will be shown in the option's dialog list when creating one.
Note that you cannot see in that new dialog an option with a specific dialog.
@param derivedClass is the  call name of the overload dialog..
@param resource is an integer of a Sophis Resource id like kMainDialogDialogElemCount.
*/
#define INITIALISE_GENERIC_DIALOG_FOR_OPTION(derivedClass,resource)		\
	{																	\
		static SphDialogFactoryT<derivedClass> _dialogConstructor;		\
		::NewDialogueTitreSophis(&_dialogConstructor, 0, resource);		\
	}


SPH_PROLOG

struct SSDevise;
namespace sophis {
	class CSRComputationResults;
	namespace event {
		class ISEvent;
	};
	namespace market_data {
		struct SSYieldCurve;
	};
};

namespace sophis {
	namespace gui {

		/** Class CSRInstrumentDialog: from which any instrument dialog derives (Shares, Rates, Currencies, Options...).
		CSRInstrumentDialog has got double inheritance. Indeed this class derives from both CSRFitDialog and CSRMarketDataOverloader,
		which enables it to know both the computation context and the security it features.
		Before any calculation, CSRMarketDataOverloader overloads the simulation parameters. One can derive the methods
		of a computation context if one of its editable elements is a simulation parameter.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRInstrumentDialog : public CSRFitDialog, public scenario::CSRInstrumentDialogInterface {
		public:
			/**The constructor CSRInstrumentDialog::CSRInstrumentDialog() calls the constructor
			CSRMarketDataOverloader::CSRMarketDataOverloader() by handing over gApplicationContext as parameter.
			@version 4.5.2
			*/
			CSRInstrumentDialog();

			/**Purely abstract destructor to be overriden.
			@version 4.5.2
			*/
			virtual ~CSRInstrumentDialog();

			/** Method called before recalculations.
			This method is automatically called before the recalculations take place.
			It enables the initialisation of the variables.
			You can override this in order to make it meet requirements with respect to the CSRInstrument security.
			If the dialog contains new calculation parameters, this is a good place to
			initialise the methods inherited from CSRFitDialog considered as CSRMarketDataOverloader.
			@param security is a reference to a CSRInstrument-derived object that is the security in question.
			@version 4.5.2
			*/
			virtual void BeforeRecompute(const instrument::CSRInstrument &security);

			/** Method called after recalculations.
			This method is called automatically after the recalculations have taken place.
			It allows you to carry out supplementary calculations and to display the relevant results as, for instance,
			barrier sensibilities.
			You can override this in order to meet requirements with respect to the CSRInstrument security.
			@param security is a reference to a CSRInstrument-derived object that is the security in question.
			@version 4.5.2
			*/
			virtual void AfterRecompute(const instrument::CSRInstrument &security, const sophis::CSRComputationResults& results) OVERRIDE;

			/** Invalidates the current security.
			The method is called automatically when the user invalidates the current security by unclicking 'Validation'
			in the option dialog.
			You can override this in order to affect the security in other ways.
			@version 4.5.2
			*/
			virtual void ProduitDevalide();

			/**Called before setting option's default parameters.
			It precedes method ReInitialise().
			@version 4.5.2
			*/
			virtual void BeforeParam();

			/** Sets option's default parameters.
			This method sets the option to its default values.
			You can override this in order to initialise new simulation parameters.
			@version 4.5.2
			*/
			virtual void ReInitialise();

			/**Initialises the security's parameters when creating it.
			@param security is the security of which the parameters are to initialise.
			@version 4.5.2
			*/
			virtual	void InitialiseOnConstruction(const instrument::CSRInstrument &security);

			/**Creates a new CSRInstrument of the current type.
			Creates & returns the address of a new CSRInstrument of the current type, which cannot be done through
			GetCSRInstrument() as the security has not yet been validated.
			If the returned pointer is not NULL, i.e. if the call does not fail, the CSRInstrument created still needs initialisation.
			Warning, this method can't be accessed while creating a dialog. It can be called for instance in
			CSRFitDialog::InitialiseOnConstruction() or CSRElement::Open().
			Object returned must be destroyed explicitly.
			@return a pointer to a newly created CSRInstrument object.
			@version 4.5.2
			*/
			instrument::CSRInstrument	*new_CSRInstrument() const;
				// Rule : every object created by new_AClass must be deleted with a classical delete

			sophis::market_data::SSYieldCurve	*new_SSYieldCurve() const;
				// Rule : every object created by new_AClass must be deleted with a classical delete


			SSDevise *new_SSDevise() const;
				// Rule : every object created by new_AClass must be deleted with a classical delete

			/**Analyses and responds to a Real Time event.
			@param paquet is the Real Time event packet received.
			@version 4.5.2
			*/
			virtual void Update(const sophis::event::ISEvent & event);

			/// Update the dialog's controls from the given instrument
			/** Used in particular by the data service : controls are updated from the instrument returned by the data service.
			  * Update only your extra fields. Standard fields are updated by default.
			  * When you override this method, you have to call the parent's one last.
			  * @param instr the instrument the controls must be initialized with. Warning: It must be an instance created with new_CSRInstrument().
			  */
			virtual void UpdateFromInstrument(const instrument::CSRInstrument& instr);
			
			char * GetNewInstrumentReference(char *refer);

			// INTERNAL
			void	SetDlog2( TDlog ** tDlog2 );

			TDlog	**fDlog2;

			instrument::CSRInstrument *(*newCSRTitre)(TDlog	**);
		private:
			sophis::market_data::SSYieldCurve *(*newSSYieldCurve)(TDlog **);

			SSDevise *(*newSSDevise)(TDlog **);

		public:

		friend struct ::infos_user;
		friend struct ::DialogueOption;
		friend struct ::DialogueSurcharge;
		};

		/** Class CSRArbitrageDialog: dialog for an arbitrage.
		The derived class may be an interface with an arbitrage object.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRArbitrageDialog : public CSRFitDialog {
		public:
			/**Constructor.
			Basic constructor that you should override.
			@version 4.5.2
			*/
			CSRArbitrageDialog();

			/**Destructor.
			Basic destructor that you should override.
			@version 4.5.2
			*/
			virtual ~CSRArbitrageDialog();

			/**Creates & returns a Arbitrage object that is contained within the dialog.
			Object returned must be destroyed explicitly.
			@return a pointer to a newly created CSRArbitrage object.
			@version 4.5.2
			*/
			sophis::instrument::CSRArbitrage *new_CSRArbitrage() const;

			/**Display the arbitrage dialog
			Should be overriden
			*/		
			virtual void Display();
		};

	}
}

SPH_EPILOG
#endif
