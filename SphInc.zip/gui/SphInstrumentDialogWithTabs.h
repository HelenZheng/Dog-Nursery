#ifndef SPH_INSTRUMENT_DIALOG_WITH_TABS_H
#define SPH_INSTRUMENT_DIALOG_WITH_TABS_H

#include "SphInc/gui/SphInstrumentDialog.h"
#include "SphInc/gui/SphTabButton.h"
#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(string)

SPH_PROLOG

class CSRPricerInstrumentDialogInternalData;
class CSRInstrumentDialogWithTabsInternalData;
class CSRElementHandlerInternalData;
struct TDlog;
struct infos_user;

namespace sophis
{
	namespace tools
	{
		class CSRArchive;
	}
	namespace instrument
	{
		class CSRInstrument;
	}

	namespace gui
	{
		/************************************************************************/
		/* CSRPricerInstrumentDialog                                            */
		/************************************************************************/
		/**
			CSRPricerInstrumentDialog is a CSRInstrumentDialog that can execute actions
			on tab-based instrument dialogs.
			This class is directly used to add a specific toolkit to an instrument (if its dialog
			uses a tab control).
			@version 5.2.6
		*/

		class SOPHIS_FIT CSRPricerInstrumentDialog : public CSRInstrumentDialog
		{
		public:
			/**	Constructor.
			*	@version 5.2.6
			*/
			CSRPricerInstrumentDialog();

			/**	Copy constructor.
			*	@version 5.2.6
			*/
			CSRPricerInstrumentDialog( const CSRPricerInstrumentDialog & toCopy );

			/**	Destructor.
			*	@version 5.2.6
			*/
			virtual ~CSRPricerInstrumentDialog();

			/**	Refresh the instrument dialog.
				Call this method to refresh the whole dialog.
				@version 5.2.6
			*/
			void	RefreshDialog();

			// INTERNAL
			CSRPricerInstrumentDialogInternalData *	GetInternalPricerData() const;
		private:
			// INTERNAL
			CSRPricerInstrumentDialogInternalData *	fPricerData;
		};


		/************************************************************************/
		/* CSRInstrumentDialogElementHandler                                    */
		/************************************************************************/
		/**
			Interface used to add or remove standard dialog elements in instrument dialogs having
			a tab control.
			In these dialogs, all the standard elements have a dialog-wide unique identifier.
			Calling {@link AddStandardElement} or {@link RemoveStandardElement} with this identifier allows
			the user to move or remove it.
			@version 5.2.6
		*/

		class SOPHIS_FIT CSRInstrumentDialogElementHandler
		{
		public:
			/**	Constructor.
			*	@version 5.2.6
			*/
			CSRInstrumentDialogElementHandler();

			/**	Destructor.
			*	@version 5.2.6
			*/
			virtual ~CSRInstrumentDialogElementHandler();

			/** Add a standard element to the toolkited tab page.
				Note that only one instance of a standard element can exist throughout the whole dialog.
				Therefore, AddStandardElement is generally linked with a corresponding {@link RemoveStandardElement}
				in another tab page.
				@param stdEltId is the dialog-wide unique identifier of the element to add.
				@version 5.2.6
			*/
			void	AddStandardElement( int stdEltId );

			/** Remove a standard element from the toolkited tab page.			
			@param stdEltId is the dialog-wide unique identifier of the element to remove.
			@version 5.2.6
			*/
			void	RemoveStandardElement( int stdEltId );

			// INTERNAL
			CSRElementHandlerInternalData *	GetInternalData() const;
		private:
			// INTERNAL
			CSRElementHandlerInternalData * fEltData;
		};


		/************************************************************************/
		/* CSRInstrumentTabPage                                                 */
		/************************************************************************/

		/**
			CSRInstrumentTabPage is a {@link sophis::gui::CSRTabPage} where standard elements
			can be added or removed.
			This class is used by {@link CSRInstrumentDialogWithTabs}.
			@version 5.2.6
		*/

		class SOPHIS_FIT CSRInstrumentTabPage : public CSRTabPage, public CSRInstrumentDialogElementHandler
		{
		public:
			/**	Constructor.
			*	@version 5.2.6
			*/
			CSRInstrumentTabPage();
		};


		/************************************************************************/
		/* CSRInstrumentDialogWithTabs                                          */
		/************************************************************************/

		/**
			CSRInstrumentDialogWithTabs is a class that allow the user to fully customized a tab control-based
			instrument dialog.
			Each tab page you want to customize should be overridden by a {@link CSRInstrumentTabPage} and
			added with {@link InsertTab} or {@link OverloadExistingDialog}

			To override an existing tab page, you have to create the dialog resource, then create your
			{@link CSRInstrumentTabPage} and then register it with OverloadExistingDialog, using the standard
			dialog resource identifier, without any offset.
			To add a new tab, just used InsertTab with a identifier that does not corresponds to one of the
			instrument standard dialog resource identifier.

			Note: some dialog resources are located in SphBasicDataGUI

			@version 5.2.6
		*/

		class SOPHIS_FIT CSRInstrumentDialogWithTabs : public CSRPricerInstrumentDialog, public CSRInstrumentDialogElementHandler
		{
		public:
			/**	Constructor.
			*	@version 5.2.6
			*/
			CSRInstrumentDialogWithTabs();

			/**	Copy constructor.
			*	@version 5.2.6
			*/
			CSRInstrumentDialogWithTabs( const CSRInstrumentDialogWithTabs & toCopy );

			/**	Destructor.
			*	@version 5.2.6
			*/
			virtual ~CSRInstrumentDialogWithTabs();

			/**	Insert a new tab page to the dialog.
			*	Note that if the identifier used corresponds to an already existing identifier and if
			*	the related dialog is not a tab page, the page will not be added in the tab control.
			*	@param page is the class that overrides the dialog.
			*	@param tabIdent is the identifier of the page to add. It can be a new or an existing identifier.
			*	@version 5.2.6
			*/
			void	InsertTab( CSRInstrumentTabPage * page, int tabIdent );

			/**	Overrides an existing dialog.
			*	Note that the identifier has to correspond to an existing one. If you want to add a new dialog,
			*	use {@link InsertTab} instead.
			*	@param page is the class that overrides the dialog.
			*	@param tabIdent is the identifier of the standard page to override.
			*	@version 5.2.6
			*/
			void	OverloadExistingDialog( CSRInstrumentTabPage * page, int dialogID );

			/**	Called by Risque to allow the user to modify the tab order (or to add or remove tabs).
			*	Note that the modified vector is checked before using it: multiple values are simplified, 
			*	identifiers that does not correspond to a tab page are removed...
			*	@param instr is the instrument displayed in the dialog.
			*	@param tabVect is a vector containing the default tab pages identifier. This vector can be modified.
			*	@version 5.2.6
			*/
			virtual void	AlterTabOrder( const instrument::CSRInstrument & instr, _STL::vector< int > & tabVect );

			/**	Return the object that has been registered with the given identifier.
			*	@param dialogID is the identifier of the registered dialog you want to retrieve.
			*	@return the dialog corresponding to dialogID, if any, 0 otherwise.
			*	@version 5.2.6
			*/
			CSRInstrumentTabPage *	GetOverloadedDialog( int dialogID ) const;

			/**	Show or hide a tab page.
			*	@param tabIdent is the identifier of the tab page to hide or show.
			*	@param show is true if you want to show the tab, false if you want ot hide it.
			*	@version 5.2.6
			*/
			void		ShowTabPage( int tabIdent, bool show = true ) const;

			/**	Hide a tab page.
			*	It simply calls {@link ShowTabPage} with the parameter show set at false.
			*	@param tabIdent is the identifier of the tab page to hide.
			*	@version 5.2.6
			*/
			inline void	HideTabPage( int tabIdent ) const;

			/** Describe the dialog items in the data set.
			This is used internally by Data service to populate user items.
			@since 6.2
			*/
			virtual void	DescribeElement(tools::dataModel::DataSet& data_set, const SSDataDescribed & dataPtr) const;

			/** Update the dialog items using the data set.
			This is used internally by Data service to update user items.
			@since 6.2
			*/
			virtual void	UpdateElement(const tools::dataModel::DataSet& data_set, SSDataDescribed & dataPtr);


			// INTERNAL
			CSRInstrumentDialogWithTabsInternalData *	GetInternalData() const;

			// INTERNAL
			CSRElement *	GetGlobalElementByRelativeId( int relativeId );
			// INTERNAL
			int				GetGlobalElementCount() const;
			// INTERNAL
			void		InitialiseOracle(Tdescribe *desc,char** read,char** write);	
			// INTERNAL
			void		InitialiseOracle(Tdescribe *desc, char** read, char** write, _STL::vector<CSRElement*>& v);
			// INTERNAL
			const char *	InitialiseDialogue(const char* resultat);
			// INTERNAL
			void		InitialisePointeur(::infos_user *infosUser);
			// INTERNAL
			sql::errorCode		ReadQuery(char* result, long code);	
			// INTERNAL
			sql::errorCode		ReadQuery(char* result, _STL::vector<CSRElement*>& v);
			// INTERNAL
			sql::errorCode		WriteQuery(char* result, long code);
			// INTERNAL
			sql::errorCode		WriteQuery(char* resultat, _STL::vector<CSRElement*>& v);
			// INTERNAL
			sql::errorCode		Historise(long sico, long sico_histo);
			// INTERNAL
			sql::errorCode		HistoDuplicate(long sico, long sico_histo);
			// INTERNAL
			short		Free(char* result);
			// INTERNAL
			short		Duplicate(char* result);
			// INTERNAL
			sophis::tools::CSRArchive & push (sophis::tools::CSRArchive & , const char * ) const;
			// INTERNAL
			const sophis::tools::CSRArchive & pop (const sophis::tools::CSRArchive & , char *);
			
		private:
			// INTERNAL
			CSRInstrumentDialogWithTabsInternalData *	fData;
		};

		inline void	CSRInstrumentDialogWithTabs::HideTabPage( int tabIdent ) const
		{
			ShowTabPage( tabIdent, false );
		}

		/************************************************************************/
		/* CSRMetaModelTabButton                                                 */
		/************************************************************************/

		/**
		CSRMetaModelTabButton is a {@link sophis::gui::CSRTabButton} for handling CSRInstrumentTabPage 
		and managing the toolkit data (infouser).
		@version 5.3
		*/

		class SOPHIS_FIT CSRMetaModelTabButton : public CSRTabButton
		{
		public:
			 struct SSTabElementMM
			 {
				 _STL::string			name;
				 int					ID;
				 CSRInstrumentTabPage	*MMTabPage;
			 };

			/**	Constructor.
			*	@param dlg is the parent dialog
			*	@param id is the relative id of the tabbutton
			*	@param newTabPages is the list of tab pages to display with the corresponding names and IDs. All tab pages' relative ID must be differents.
			*	@version 5.3
			*/
			CSRMetaModelTabButton(CSRInstrumentDialogWithTabs * dlg, int id, const _STL::vector<SSTabElementMM> &newTabPages);

			virtual ~CSRMetaModelTabButton();

			virtual void	Describe(sophis::tools::dataModel::DataSet& data_set, const sophis::gui::SSDataDescribed &dataPtr) const;
			virtual void	UpdateWithDataSet(const sophis::tools::dataModel::DataSet& data_set, sophis::gui::SSDataDescribed &dataPtr);
		};



		/************************************************************************/
		/* CSRMetaModelDlgWithTabs                                                 */
		/************************************************************************/

		/**
		CSRMetaModelDlgWithTabs is a {@link sophis::gui::CSRInstrumentDialogWithTabs} for handling 
		CSRInstrumentTabPage and managing the toolkit data (infouser) with other derivations than instruments.
		It is used for exemple for meta models dialogs {@link sophis::gui::CSRInstrumentDialogWithTabs::new_Dialog}
		@version 5.3
		*/

		class SOPHIS_FIT CSRMetaModelDlgWithTabs : public gui::CSRInstrumentDialogWithTabs
		{
		public:
			/**	Constructor. Default implementation does nothing. the implementation is in {@see InitialiseElements}
			*	@version 5.3
			*/
			CSRMetaModelDlgWithTabs();

			enum eOptionMonteCarloGeneralDialog 
			{
				eOk				= 1,
				eCancel,
				eTabButton,
				eNextElement	//4
			};
		protected:
			/**	Constructor implementation in order to add tabs easily.
			*	@param tabDialogs is the list of tabs one wants to add in the tab button of the dialog.
			*	@version 5.3
			*/
			void InitialiseElements(const _STL::vector<CSRMetaModelTabButton::SSTabElementMM> &tabDialogs);
		};
	}
}

SPH_EPILOG
#endif	// SPH_INSTRUMENT_DIALOG_WITH_TABS_H
