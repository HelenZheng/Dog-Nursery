#pragma once

#ifndef __SphInstrumentUI_H__
#define __SphInstrumentUI_H__

#include "SphInc/SphMacros.h"
#include "SphInc/instrument/SphInstrument.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class SOPHIS_BASIC_DATA_GUI CSRInstrumentUI
		{
		public:
			/** Open the dialog associated with an instrument.
			This method works only with the Toolkit and opens the dialog associated
			with the instrument.
			@param code is the internal code of the instrument
			@version 7.0
			*/
			static void OpenDialog(long code);

			/** Open the dialog associated with an instrument.
			This method works only with the Toolkit and opens the dialog associated
			with the instrument using code GetCode(), but not necessarily the instrument itself.
			@param toOpen is the instrument
			@version 7.0
			*/
			static void OpenDialog(const sophis::instrument::CSRInstrument& toOpen);

			/** Open the volatility dialog of an instrument.
			This method works only with the Toolkit and opens the dialog associated
			with the instrument.
			@param code is the internal code of the instrument
			@param matrix_format gives the GUI type (graph or matrix)
			@version 7.0
			*/
			static void OpenVolatilityDialog(long code, bool matrix_format);

		private:
			CSRInstrumentUI();
			CSRInstrumentUI(const CSRInstrumentUI& toCopy);
			~CSRInstrumentUI();
			CSRInstrumentUI& operator = (const CSRInstrumentUI& toCopy);
		};
	}
}
SPH_EPILOG
#endif
