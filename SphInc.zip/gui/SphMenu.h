#ifndef _SphMenu_H__
#define _SphMenu_H__

#include "SphTools/SphCommon.h"

#include "SphInc/gui/SphElement.h"
//#include "SphInc/gui/SphCustomMenu.h"
#include "SphInc/backoffice_kernel/SphThirdPartyEnums.h"


#include __STL_INCLUDE_PATH(vector)
#include __STL_INCLUDE_PATH(map)


SPH_PROLOG
SPH_BEGIN_NOWARN_EXPORT
namespace sophis {
	namespace tools {
		class CSRArchive;// used within definition of ELEM_COMMON_INTERNALS
	}
}

class CSRThirdPartyKeyMenu;	// internal
class CSUMenu;
class CSList;
typedef CSUMenu * MenuHandle;

namespace sophis
{
	namespace gui
	{

		/** Class CSRPopupMenu:
		*	Listable class designed to handle a user defined popup menu.
		*	The CSRPopupMenu class implements a local menu -i.e. a 'popup'- which allows you to choose among
		*	different options. Their shaded frame make the CSRPopupMenu easily recognizable.
		*	The popup menu must have been created in the 'MENU' resource.
		*	Warning : To see the popup menu appear, the item placed in the 'DLOG' resource must
		*	not be of the 'PopUp User Item' kind but of the 'Static Text Item' kind. This static text should be enabled.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRPopupMenu : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			Initilises all members to their null values.
			@version 4.5.2
			*/
			CSRPopupMenu();

			/** Overloaded Constructor 2.
			The constructor CSRPopupMenu::CSRPopupMenu() first passes on the parameters dialog, ERId_Menu and columnName to
			the CSRElement::CSRElement() constructor, then initialises the fields fResourceId and fValue.
			Parameter columnName is used only in model or when deriving a generic security dialog (See "How to derive CSRInstrumentDialog").
			It is always assumed that the name of all user-created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSRPopupMenu belongs.
			@param ERId_Menu is the relative number of the CSRPopupMenu.
			@param MENUResourceId is the number of the menu in 'MENU' resource. To initialise fResourceId.
			@param value is the default value set to 0. To initialise fValue when columnName is nvZero or if creating a new security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRPopupMenu(		CSRFitDialog 	*dialog,
				int 			 ERId_Menu,
				int 			 MENUResourceId,
				short 			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 3.
			Creates a popup element in a list.
			@param list is a pointer on the editable list to which the menu option column belongs.
			@param CNb_Menu is the relative number of the CSRPopupMenu's column.
			@param MENUResourceId is the number of the menu in the 'MENU' resource. To initialise fResourceId.
			@param value is the default value set to 0. To initialise fValue, where the selected option is stored.
			@param columnName is the user table column name of which the structure must possess at least the two following fields:
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRPopupMenu(		CSREditList		*list,
				int 			 CNb_Menu,
				int 			 MENUResourceId,
				short 			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			virtual short	DonneFiltre(void) const;								// internal
			virtual	int		DonneTypeTri() const;									// internal

			virtual USMenu	*DonneMenu(void) const;									// internal
			virtual short	GetListValue(void) const;								// internal
			virtual void	SetListValue(short value);								// internal
			virtual Boolean	IsASharedMenu() const;									// internal

			/**Invoked after data is selected in the popup menu by the user.
			Called right after the menu selection is made, and the new value selected is entered
			in the element.
			@param value is the selected option. This would be the same as fValue.
			@version 4.5.2
			*/
			virtual void	Action(short value);

			/**Converts the popup menu value stored in the popup element, to the string text to display on the screen.
			The method is used in the case when the popup menu is part of a CSREditList list.
			It takes the selected option value (fValue) and finds the text string corresponding to the selection.
			Overriding method will set the displayed string value depending on the design and purpose of the
			CSRPopupMenu-derived class.
			@param dest is the text string that appears on popup element text box on the list, to which the selection is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/** Implements StringToValue for Pop-Up Menu */
			virtual Boolean	StringToValue(const char *sourc, int line);


			/**Assigns the menu selection index of another element to this CSRPopupMenu.
			Method Overloaded.
			The parameter element must refer to a CSRPopupMenu object.
			@param an element referring to a CSRPopupMenu object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the menu selection value of another CSRPopupMenu element to this CSRPopupMenu.
			Method Overloaded.
			@param the CSRPopupMenu element from which the selection value is copied.
			@version 4.5.2
			*/
			void operator = (const CSRPopupMenu&);

			/**Compares the selection menu index of this CSRPopupMenu, with the index of another element.
			The parameter must refer to a CSRPopupMenu object, the fValue of which is compared with
			the fValue of the current CSRPopupMenu.
			@param a reference to a CSRPopupMenu object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's value\index (fValue) from the current value. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/** Obtains the shift in the popup selection indexes.
			Normally the enumerator of the selection values of the popup menu starts from value 1.
			However, if this enumerator starts from 0, you can override the method GetMenuShift() in order to
			return 1.
			@return the shift value in the popup menu of the CSRPopupMenu.
			@version 4.5.2
			*/
			virtual short	GetMenuShift(void) const;

			/**Obtains the selection index in the CSRPopupMenu.
			@param a pointer to the variable into which the CSRPopupMenu value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new selection index to the popup element.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/** Checks whether the pop-up menu allows modification.
			The method is used in the case when the pop-up menu is part of a list.
			By default, it returns true.
			@return true if the popup menu can be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Obtaing the resource ID of the popup menu.
			@see fResourceId
			@return the ID of the popup menu resource.
			@version 4.5.2
			*/
			int		GetResourceId(void) { return fResourceId; };

			/**Obtains a pointer to the index fValue.
			@return a pointer to the fValue that holds the menu selection value in the CSRPopupMenu.
			@version 4.5.2
			*/
			short 	*GetValue(void) { return &fValue; };

			/** Disables one item from being selected in the pop-up menu.
			@param whichElement is the index of the item to disable on the pop-up menu.
			@version 4.5.2
			*/
			void	DisableElement(int whichElement);

			/**Enables an item to become selectable in the popup menu.
			@param whichElement is the index of the item to enable on the popup menu.
			@version 4.5.2
			*/
			void	EnableElement(int whichElement);

			/**Set the name of an item in the popup menu.
			@param whichElement is the index of the item.
			@param entryName is the name to set.
			@version 5.2.6
			*/
			void	SetElementName(int whichElement, const _STL::string & entryName );

			/** Sets whether the pop-up menu allows modification.
			The method is used in the case when the pop-up menu is part of a list.
			*/
			void SetCanBeModifiedInAList(Boolean canBeModifiedInAList);

			ELEM_COMMON_INTERNALS

				/// Value type as returned by GetElementValue
				typedef short value_type;

		protected:
			/**The ID of the menu in 'MENU' resource, which contains the text strings of the selectable items of the menu.
			@version 4.5.2
			*/
			int		fResourceId;

			/** Stores the selected option on the po-up menu.
			This is simply the index of the selected menu item that currently appears in the pop-up menu element text box.
			@version 4.5.2
			*/
			short	fValue;

			/**	Indicates whether the menu selection can be changed.
			@see CSRPopupMenu::MenuCanBeModifiedInAList
			*/
			Boolean		fMenuCanBeModifiedInAList;
		};

		SOPHIS_FIT CSRPopupMenu* newCSRPopupMenu(CSRGenericForm* pForm, int referenceInForm, int dlgRef, short value = 0);

		/** Class CSRPopupMenu.
		*	Pop-up menu for selecting instrument maturity Annual Basis.
		*	This is a pop-up menu class for handling a menu with Annual Basis selection choices.
		*	The Annual Basis is related to a financial instrument, and describes how the maturity in years is calculated
		*	from the start date to the end date. The choices that are offered by the menu are: Actual/360, Actual/365F,
		*	Actual/365.25, Actual/Actual, Actual/365, 30/360 and 30E/360.
		*	The popup element's fValue is of type eDayCountBasisType. @see eDayCountBasisType
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRDayCountBasisTypeMenu : public CSRPopupMenu {
		public:
			/**Overloaded Constructor 1.
			Links the popup menu to a dialog.
			Passes all parameters to base class first constructor CSRPopupMenu. The resource ID of the menu is not initialized
			in the constructor, because it is the Annual Basis menu that is specific (constant) to this class, and is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRDayCountBasisTypeMenu(CSRFitDialog	*dialog,
				int 				ERId_Menu,
				short 				value=0,
				const char 				*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Links the popup menu to a list.
			Passes all parameters to base class second constructor CSRPopupMenu. The resource ID of the menu is not initialized
			in the constructor, because it is the Annual Basis menu that is specific (constant) to this class, and is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRDayCountBasisTypeMenu(CSREditList	*list,
				int 				CNb_Menu,
				short 				value=0,
				const char 				*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Obtains the Annual Basis selection currently in the CSRDayCountBasisTypeMenu.
			@param a pointer to the variable into which the popup element's Annual Basis value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new Annual Basis value to the popup element.
			@param value is a pointer to the Annual Basis value that is to be copied to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);


			virtual USMenu	*DonneMenu(void) const;	// internal

			typedef long value_type;
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRDayCountBasisTypeMenu);


		/** Class CSRYieldCalculationTypeMenu:
		*	Popup menu for selecting an Interest Rate calculation method.
		*	This is used with financial instruments such as Bonds, in order to provide the user with a choice of different
		*	methods to calculate the interest amount from the Interest Rate. Choices provided by the menu are: Linear, Actuarial,
		*	Continuous, and Absolute.
		*	The fValue of the CSRYieldCalculationTypeMenu element is of type eYieldCalculationType. @see eYieldCalculationType
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRYieldCalculationTypeMenu : public CSRPopupMenu {
		public:
			/**Overloaded Constructor 1.
			Links the popup menu to a dialog.
			Passes all parameters to base class first constructor CSRPopupMenu. The resource ID of the menu is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRYieldCalculationTypeMenu(	CSRFitDialog 	*dialog,
				int 			 ERId_Menu,
				short 			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Links the popup menu to a list.
			Passes all parameters to base class second constructor CSRPopupMenu. The resource ID of the menu is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRYieldCalculationTypeMenu(	CSREditList		*list,
				int 			 CNb_Menu,
				short 			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/**Specifies that the menu shift value is of 1.
			Because the enumerator for the displayed indexes of the menu items starts at 0, there should therfore
			be a shift of one, in order to bring the selections values from starting with 0 to starting with 1.
			@see eYieldCalculationType
			In class CSRDayCountBasisTypeMenu, there was no need for a shift value, because the indexes' enumerator
			eDayCountBasisType starts the displayed items with 1.
			@see CSRPopupMenu::GetMenuShift()
			@return the shift value of 1.
			@version 4.5.2
			*/
			virtual short	GetMenuShift(void) const;

			/**Obtains the Calculation Method selection currently in the CSRYieldCalculationTypeMenu.
			@param a pointer to the variable into which the popup element's Calculation Method value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new Calculation Method value to the popup element.
			@param value is a pointer to the Calculation Method value that is to be copied to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);


			virtual USMenu	*DonneMenu(void) const;	// internal

			typedef short value_type;

			void SetUseIntegers(bool use);

		protected:
			bool fUseIntegers;
		
		};

		SOPHIS_FIT CSRYieldCalculationTypeMenu* newCSRYieldCalculationTypeMenu(CSRGenericForm* pForm, int referenceInForm, short value = 0);

		/** Class CSRThirdPartyMenu:
		*	Popup menu for selecting a Third Party.
		*	Unlike CSRPopupMenu,this class doesn't use resources of the 'MENU' type. The class utilises a menu
		*	of Third Party names, which is linked to the class by member fMenuTiers.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRThirdPartyMenu : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor passes on the parameters dialog, ERId_Menu and columnName to
			the CSRElement::CSRElement(), then initializes the fValue, and sets the menu fMenuTiers with
			constraints on thirdPartyType, currency, market, IsSwiftCodeToDisplay, and AddStar.
			Parameter columnName is used only in model or when deriving a generic security dialog (See "How to derive CSRInstrumentDialog").
			It is always assumed that the name of all user-created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the CSRPopupMenu belongs.
			@param ERId_Menu is the relative number of the CSRPopupMenu.
			@param thirdPartyType is the type of third parties on the menu, the values of which corresponds as follows :
			0 : Group,
			1 : Counterparty,
			2 : Courtier,
			3 : Depositary,
			4 : Client,
			5 : Bank,
			6 : Corporate,
			7 : Exchange,
			8 : Supranational,
			9 : Other
			if this parameter is equal to -1, the menu will include all types of third parties.
			@param currency the currency of the fees of the third parties in the menu. The currency constraint will be neglected if this parameter is -1.
			@param market the market of the third parties' fees. The market constraint will be neglected if this parameter is equal to 0.
			@param allotment the allotment of the third parties' fees.
			@param entity the entity of the fees for the third party.
			@param value is the default value set to 0. To initialize fValue when columnName is nvZero or if creating a new security.
			@param columnName is the name of a Sophis Xxx table's column handled by the CSRXxx object.
			@param IsSwiftCodeToDisplay is true to indicate that the Swift Codes of the third parties are to include (displayed) in the menu. Is false if the names of thirdparties are to include instead.
			@param AddStar is true to state that a star character (*) in added at the end of the menu. The star character when selected, it is as if all third parties are selected, and the fValue is -1.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@param isInSubDialog is true if the CSRThirdPartyMenu must not be deleted by the container dialog, but by the mother dialog, as for example in the case of a toolkit specific instrument dialog.
			@param AddNullable is true to add an empty line, in order to allow the user to select a null/empty value.
			@version 4.5.2.1 new parameter tagColonne.
			@version 5.3 new parameter isInSubDialog.
			@version 5.3.1 new parameter AddNullable.
			*/
			CSRThirdPartyMenu(	sophis::gui::CSRFitDialog*dialog,
				int 		ERId_Menu,
				backoffice_kernel::eThirdPartyType	thirdPartyType,
				long		currency=0,
				long		market=0,
				long		allotment=0,
				long		entity=0,
				long 		value=0,
				const char 		*columnName = kUndefinedField,
				bool		IsSwiftCodeToDisplay = false,
				bool		AddStar = false,
				const char *	tagColonne = kSameAsOracleName,
				bool		isInSubDialog = false,
				bool		AddNullable = false,
				bool isSwiftAndThirdToDisplay = false) ;

			/** Overloaded Constructor 2.
			Similar to the first constructor, except that the pop-up menu element is part of a list, and the columnName is set differently.
			@param columnName is the user table column name of which the structure must possess at least the two following fields:
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRThirdPartyMenu(	sophis::gui::CSREditList *list,
				int 		CNb_Menu,
				backoffice_kernel::eThirdPartyType	thirdPartyType,
				long		currency=0,
				long		market=0,
				long 		value=0,
				long		allotment=0,
				long		entity=0,
				const char 		*columnName = kUndefinedField,
				bool		IsSwiftCodeToDisplay = false,
				bool		AddStar = false,
				const char *	tagColonne = kSameAsOracleName,
				bool		AddNullable = false) ;

			/**Destroys the menu element fMenuTiers.
			@version 4.5.2
			*/
			~CSRThirdPartyMenu(void);

			/**Converts the third party code fValue stored in the popup element, to the third party name to display on the screen.
			The method is used in the case when the popup menu is part of a CSREditList list.
			It reads the third party code stored in fValue, and finds the corresponding name in the menu.
			@param dest is the name that appears on the popup element text box on the list, to which the selection is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/** Implements StringToValue for Third party menu */
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Assigns the third party code selection of another element to this CSRThirdPartyMenu.
			The parameter element must refer to a CSRThirdPartyMenu object.
			@param an element referring to a CSRThirdPartyMenu object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Compares the third party code selection of this CSRThirdPartyMenu, with the third party code of another element.
			The parameter must refer to a CSRThirdPartyMenu object, the fValue of which is compared with
			the fValue of the current CSRThirdPartyMenu.
			@param a reference to a CSRThirdPartyMenu object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's third party code (fValue) from the current third party code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the current third party code in the CSRThirdPartyMenu.
			@param a pointer to the variable into which the CSRThirdPartyMenu value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new third party code selection to the popup menu.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Checks whether the popup menu allows modification.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@return true if the popup menu can be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Obtains a pointer to the fValue.
			@return a pointer to the fValue that holds the third party code selection in the CSRThirdPartyMenu.
			@version 4.5.2
			*/
			long 	*GetValue(void) { return &fValue; };

			/**Specifies a new third parties' fees currency.
			Because a new currency is set, the menu is reconstructed to select the
			third parties' whose fees are in that newly specified currency.
			Function CSRThirdPartyMenu::Update() is called after this, in order to reconstruct the menu.
			@param currency is the new third parties' fees currency.
			@version 4.5.2
			*/
			void	SetCurrency(long currency);

			/**Specifies a new market of the third parties' fees.
			Following this, the menu is reconstructed to select the	third parties' whose fees
			are in that newly specified market.
			Function CSRThirdPartyMenu::Update() is called after this, in order to reconstruct the menu.
			@param is the new market of the third parties' fees.
			@version 4.5.2
			*/
			void	SetMarket(long market);

			/**Specifies a new allotment of the third parties' fees.
			Following this, the menu is reconstructed to select the	third parties' whose fees
			are in that newly specified allotment.
			Function CSRThirdPartyMenu::Update() is called after this, in order to reconstruct the menu.
			@param is the new allotment of the third parties' fees.
			@version 4.5.2
			*/
			void	SetAllotment(long allotment);

			/**Specifies a new entity of the third parties' fees.
			Following this, the menu is reconstructed to select the	third parties' whose fees
			are in that newly specified entity.
			Function CSRThirdPartyMenu::Update() is called after this, in order to reconstruct the menu.
			@param is the new entity of the third parties' fees.
			@version 4.5.2
			*/
			void	SetEntity(long entity);

			/**Reconstructs the menu.
			@see CSRThidPartyMenu::fMenuTiers
			Normally it is called after SetCurrency() or SetMarket().
			@version 4.5.2
			*/
			virtual void	Update(void);

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The Third Party code that is currenly selected in the popup menu.
			@version 4.5.2
			*/
			long				fValue;

			/**The menu of selectable third parties.
			It handles the set of all third parties as constrained by the type, currency and market.
			The menu contains the names of the third parties. The currently selected third party code
			in fValue is mapped to its corresponding name in fMenuTiers, which is then displayed on
			the text box.
			@version 4.5.2
			*/
			mutable CSRThirdPartyKeyMenu*	fMenuTiers;

			/** INTERNAL */
			bool					fDeleteMenuTiers;
			bool					fIsInSubDialog;
			bool					fNullable;

		public:
			virtual short	DonneFiltre(void) const;							// internal
			virtual	int		DonneTypeTri() const;								// internal
			virtual USMenu	*DonneMenu(void) const;								// internal
			virtual short	GetListValue(void) const;							// internal
			virtual void	SetListValue(short value);							// internal
			virtual Boolean	IsASharedMenu() const;								// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSRThirdPartyMenu* newCSRThirdPartyMenu(sophis::gui::CSRGenericForm* pForm, int referenceInForm, sophis::backoffice_kernel::eThirdPartyType thirdPartyType);

		/** Class CSRSelectPSet:
		*	Popup menu for selecting a Place Of Settlement.
		*
		*	@version 5.2.4
		*/
		class SOPHIS_FIT CSRSelectPSet : public CSRThirdPartyMenu {
		public:
			// Creates a menu of psets allowing to have a nullable entry
			CSRSelectPSet(	sophis::gui::CSRFitDialog*dialog,
				int 		ERId_Pset,
				long		currency=0,
				long		market=0,
				long		allotment=0,
				long		entity=0,
				long 		value=0,
				const char 		*columnName = kUndefinedField,
				bool		IsSwiftCodeToDisplay = false,
				bool		AddStar = false,
				bool		AddNullable = false,
				void		*cchmValuePtr = 0,
				const char *	tagColonne = kSameAsOracleName) ;

			CSRSelectPSet(	sophis::gui::CSREditList *list,
				int 		CNb_Pset,
				long		currency=0,
				long		market=0,
				long 		value=0,
				long		allotment=0,
				long		entity=0,
				const char 		*columnName = kUndefinedField,
				bool		IsSwiftCodeToDisplay = false,
				bool		AddStar = false,
				bool		AddNullable = false,
				void		*cchmValuePtr = 0,
				const char *	tagColonne = kSameAsOracleName) ;

			~CSRSelectPSet(void) {}

			virtual void Update();
			virtual MenuHandle DonneMenu(void) const;
			virtual void ValueToString(char *dest, int line) const;

		protected:
			bool nullable;
			/* 
			* Pointer to the current value set for a clearing house (i.e. workflow) menu so 
			* that we can customise the pset list according to what workflow is currently selected.
			* If this is not defined then the pset list in the menu is set up ignoring what is 
			* currently selected in the workflow menu that we would have linked to.
			*/
			void* fCCHMValue;
		};

		/** Class CSRSelectCurrency:
		*	The CSRSelectCurrency class implements a popup menu which is used to choose a currency.
		*	This class does not derive from CSRPopupMenu. It deals with dynamic data type, whereas
		*	CSRPopupMenu uses resources of the 'MENU' type.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectCurrency : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSRSelectCurrency::CSRSelectCurrency() passes on to the constructor CSRElement::CSRElement()
			the parameters dialog, ERId_Currency and columnName then initializes the field fValue.
			The parameter columnName is used only in a model or when deriving a generic security dialog (See "How to derive
			CSRInstrumentDialog"). It is always assumed that the name of all user created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog is a pointer to the dialog to which the current CSRSelectCurrency belongs.
			@param ERId_Currency is the relative number of CSRSelectCurrency in the dialog.
			@param value is the default value set to 0. Used to initialize fValue if columnName is nvZero or when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param ERId_Market is the relative number of the CSRSelectMarket element, whose market is that of the currency. The CSRSelectMarket element has to be in the dialog.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@param defaultMarket is the default value to be assigned to the CSRSelectMarket element when this CSRSelectCurrency changes value.
			@version 4.5.2.1 new parameter tagColonne.
			@version 4.5.2.2 new parameter defaultMarket.
			*/
			CSRSelectCurrency(	CSRFitDialog 	*dialog,
				int 			 ERId_Currency,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				int				 ERId_Market = 0,
				const char *	tagColonne = kSameAsOracleName,
				long			defaultMarket=0);

			/**Overloaded Constructor 2.
			The constructor CSRSelectCurrency::CSRSelectCurrency() passes on to the constructor CSRElement::CSRElement()
			the parameters list, CNb_Devise and columnName then initializes the field fValue.
			It is always assumed that the name of all user-created fields obey the following pattern :
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param list is a pointer to the list to which the current CSRSelectCurrency belongs.
			@param CNb_Devise is the relative number of CSRSelectCurrency in the list.
			@param value is the default value set to 0. Used to initialize fValue if columnName is nvZero or when creating a new security.
			@param columnName is the user table column name of which the structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param CNb_Marche is the relative number of the CSRSelectMarket element, whose market is that of the currency. The CSRSelectMarket element has to be in the list.
			@param canBeModified is to state if the currency selection can be modified in the list. This is useful when the select currency element is part of a Hierarchical list.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@param defaultMarket is the default value to be assigned to the CSRSelectMarket element when this CSRSelectCurrency changes value.
			@version 4.5.2.1 new parameter tagColonne.
			@version 4.5.2.2 new parameter defaultMarket.
			*/
			CSRSelectCurrency(	CSREditList		*list,
				int 			 CNb_Devise,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				int				 CNb_Marche = 0,
				bool			canBeModified = true,
				const char *	tagColonne = kSameAsOracleName,
				long			defaultMarket=0);

			/**Checks whether the user can change the currency selected.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Checks if the currency selection can be modified, when the popup menu is in a Hierarchical list.
			Similar to MenuCanBeModifiedInAList(), except that it is used when the element is in a Hierarchical list.
			@see CSRSelectCurrency::fCanBeModified
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Converts the currency code stored in the popup element, to the currency name to display on the screen.
			The method is used in the case when the popup menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the selected option value (fValue) and finds the currency name.
			@param dest is the text string that appears on the popup element text box on the list, to which the currency name is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/** Implements StringToValue for SelectCurrency menu */
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Sets a display style to the popup element and obtains the currency code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectCurrency object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the currency code selection of another element to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectCurrency object.
			@param an element referring to a CSRSelectCurrency object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the currency code selection of another CSRSelectCurrency element to this element.
			Method Overloaded.
			@param the CSRSelectCurrency element from which the selection value is copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectCurrency&);

			/**Compares the currency code of this CSRSelectCurrency, with the currency code of another element.
			The parameter must refer to a CSRSelectCurrency object, the fValue of which is compared with
			the fValue of the current CSRSelectCurrency.
			@param a reference to a CSRSelectCurrency object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's currency code selection (fValue) from the current element's currency code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the currency code selection in the CSRSelectCurrency.
			@param a pointer to the variable into which the CSRSelectCurrency value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new currency code selection to the popup element.
			Method overloaded.
			This function in turn calls overloaded SetValue(long), which loads the new menu for the
			dialog's or list's market popup element. @see CSRSelectMarket
			@see CSRSelectCurrency::SetValue(long)
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Optains a pointer to the fValue containing the currency code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/**Assigns a new currency code selection to the popup element and loads new menu for the market.
			This is invoked by overloaded SetValue(const void*). After it assigns the new currency code, it gets the
			market popup menu element in the same dialog or list (@see CSRSelectMarket), and loads the new menu of the market, that corresponds
			to the new currency.
			@param value is the currency code that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(long value);

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The currently selected currency.
			It holds the code of the currency that is currently selected, and appears on the list\dialog.
			@version 4.5.2
			*/
			long	fValue;

			/**The relative ID of the CSRSelectMarket popup element in the dialog or list.
			@version 4.5.2
			*/
			int		fERId_Market;

			/**Indicates if the currency selection can be modified, when the popup menu is embedded in a Hierarchical list.
			@version 4.5.2
			*/
			bool	fCanBeModified;

			/**Default value for the market element.
			@version 4.5.2.2*/
			long	fDefaultMarket;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual USMenu	*DonneMenu(void) const;				// internal
			virtual short	GetListValue(void) const;			// internal
			virtual void	SetListValue(short value);			// internal
			virtual Boolean	IsASharedMenu() const;				// internal

			ELEM_COMMON_INTERNALS

		};

		class SOPHIS_FIT CSRSelectMarketPlace : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSRSelectMarketPlace::CSRSelectMarketPlace() passes on to the constructor CSRElement::CSRElement()
			the parameters dialog, NRE_MarketPlace and columnName then initializes the field fValue.
			*/
			CSRSelectMarketPlace(	CSRFitDialog *dialogue, 
				int NRE_MarketPlace, 
				long nCurrencyCode,
				long value
				);

			/**Overloaded Constructor 2.
			The constructor CSRSelectMarketPlace::CSRSelectMarketPlace() passes on to the constructor CSRElement::CSRElement()
			*/
			CSRSelectMarketPlace(	CSREditList		*list, 
				int NRE_MarketPlace, 
				long nCurrencyCode,
				long value
				);
			/**Checks whether the user can change the MarketPlace selected.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Checks if the MarketPlace selection can be modified, when the popup menu is in a Hierarchical list.
			Similar to MenuCanBeModifiedInAList(), except that it is used when the element is in a Hierarchical list.
			@see MarketPlace::fCanBeModified
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Converts the MarketPlace code stored in the popup element, to the MarketPlace name to display on the screen.
			The method is used in the case when the popup menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the selected option value (fValue) and finds the currency name.
			@param dest is the text string that appears on the popup element text box on the list, to which the currency name is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/** Implements StringToValue for CSRSelectMarketPlace menu */
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Sets a display style to the popup element and obtains the MarketPlace code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectCurrency object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the MarketPlace code selection of another element to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectMarketPlace object.
			@param an element referring to a CSRSelectMarketPlace object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the currency code selection of another CSRSelectMarketPlace element to this element.
			Method Overloaded.
			@param the CSRSelectMarketPlace element from which the selection value is copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectMarketPlace&);

			/**Compares the currency code of this CSRSelectMarketPlace, with the MarketPlace code of another element.
			The parameter must refer to a CSRSelectMarketPlace object, the fValue of which is compared with
			the fValue of the current CSRSelectMarketPlace.
			@param a reference to a CSRSelectMarketPlace object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's MarketPlace code selection (fValue) from the current element's MarketPlace code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the MarketPlace code selection in the CSRSelectMarketPlace.
			@param a pointer to the variable into which the CSRSelectMarketPlace value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new MarketPlace code selection to the popup element.
			*/
			virtual void	SetValue(const void *value);

			/**Optains a pointer to the fValue containing the MarketPlace code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/**Assigns a new MarketPlace code selection to the popup element and loads new menu for the market.
			*/
			virtual void	SetValue(long value);
			virtual long	GetCurrencyCode();
			virtual void	SetCurrencyCode(long nCurrencyCode);

		protected:
			/**The currently selected MarketPlace.
			It holds the code of the MarketPlace that is currently selected, and appears on the list\dialog.
			@version 4.5.2
			*/
			long	fValue;

			/**The relative ID of the CSRSelectMarketPlace popup element in the dialog or list.
			@version 4.5.2
			*/
			int		fERId_MarketPlace;

			/**Indicates if the MarketPlace selection can be modified, when the popup menu is embedded in a Hierarchical list.
			@version 4.5.2
			*/
			bool	fCanBeModified;

			/**Currency Code that used to retrieve the Market Places list.
			@version 4.5.2
			*/

			long	fCurrencyCode;
		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual USMenu	*DonneMenu(void) const;				// internal
			virtual short	GetListValue(void) const;			// internal
			virtual void	SetListValue(short value);			// internal
			virtual Boolean	IsASharedMenu() const;				// internal

			ELEM_COMMON_INTERNALS

		};


		SOPHIS_FIT CSRSelectCurrency* newCSRSelectCurrency(CSRGenericForm* pForm, int referenceInForm, int marketPosition = 0);

		/** Class CSRSelectMarket.
		*	Implements a pop-up menu which is used to choose a market (exchange).
		*	It enables one to choose a stock exchange between all those linked to a given currency.
		*	Unlike CSRPopupMenu, this class doesn't use resources of the 'MENU' type. The class utilises a menu
		*	of markets of a specific traded currency.
		*	If the containing dialog includes a Depository popup menu element (CSRSelectDepository), the class keeps up to
		*	date the depositories menu, by specifying the selected market code, and a currency linked to it.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectMarket : public CSRElement {
		public:
			/** Overloaded Constructor 1.
			The constructor CSRSelectMarket::CSRSelectMarket() passes on to the constructor
			CSRElement::CSRElement() the parameters dialog, ERId_Market and columnName then initializes the fields fCurrency and fValue.
			The parameter columnName is used only in model or when deriving a generic security dialog (See "How to derive CSRInstrumentDialog").
			It should always be assumed that the name of all user-created fields obey the following pattern:
			ZZZ_name_of_field where ZZZ stands for the initials of the bank.
			@param dialog points to the dialog to which CSRSelectMarket belongs.
			@param ERId_Market is the relative number of CSRSelectMarket.
			@param currency is the traded currency that defines the set of markets on the menu. It is the currency to which the exchanges listed by CSRSelectMarket belong.
			@param value is the default value set to 0. To initialize fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param tagColonne is the section for the market for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectMarket(	CSRFitDialog 	*dialog,
				int 			 ERId_Market,
				long			 currency,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			The constructor CSRSelectMarket::CSRSelectMarket() passes on to the constructor
			CSRElement::CSRElement() the parameters list, CNb_Marche and columnName then initializes the fields fCurrency and fValue.
			@param list points to the list to which CSRSelectMarket belongs.
			@param CNb_Marche is the relative number of CSRSelectMarket.
			@param currency is the traded currency that defines the set of markets on the menu. It is the currency to which the exchanges listed by CSRSelectMarket belong.
			@param value is the default value set to 0. To initialize fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name of which the structure must possess at least the two following fields:
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param canBeModified is to state if the currency selection can be modified in the list. This is useful when the select currency element is part of a Hierarchical list.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectMarket(	CSREditList		*list,
				int 			 CNb_Marche,
				long			 currency,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				bool			canBeModified = false,
				const char *	tagColonne = kSameAsOracleName);

			/** Converts the market code stored in the pop-up element, to the market name to display on the screen.
			The method is used in the case when the pop-up menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the selected option value (fValue) and finds the market name.
			@param dest is the text string that appears on the popup element text box on the list, to which the market name is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;
			virtual Boolean StringToValue(const char *sourc, int ligne);

			/**Sets a display style to the popup element and obtains the market code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectMarket object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the market code selection and the corresponding currency (fCurrency) of another element to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectMarket object.
			@param an element referring to a CSRSelectMarket object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the market code selection and the corresponding currency (fCurrency) of another element to this element.
			Method Overloaded.
			@param an CSRSelectMarket object, from which the selection value is copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectMarket&);

			/**Compares the market code of this CSRSelectMarket, with the market code of another element.
			The parameter must refer to a CSRSelectMarket object, the fValue of which is compared with
			the fValue of the current CSRSelectMarket.
			@param a reference to a CSRSelectMarket object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's market code selection (fValue) from the current element's market code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the market code selection in the CSRSelectMarket.
			@param a pointer to the variable into which the CSRSelectMarket value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new market code selection to the popup element.
			Method Overloaded.
			This function in turn calls overloaded SetValue(long), which loads the new menu for the
			dialog's or list's Depository popup element. @see CSRSelectDepositary
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Checks whether the user can make a new selection of market.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Checks if a new market can be selected, when the popup menu is in a Hierarchical list.
			Similar to MenuCanBeModifiedInAList(), except that it is used when the element is in a Hierarchical list.
			@see CSRSelectMarket::fCanBeModified
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	CanBeModifiedInAList(void) const;

			/**Optains a pointer to the fValue containing the market code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/**Assigns a new market code selection to the popup element.
			Method Overloaded.
			This is invoked by overloaded SetValue(const void*). After it assigns the new market code, it obtains the
			Depository popup menu element in the same dialog or list (@see CSRSelectDepository), and loads the new menu of the
			depositories, that corresponds to the new market and it's currency fCurrency.
			@param value is the market code that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			void	SetValue(long value) ;

			/**Sets a new traded currency of the markets that must be on the menu.
			Informs CSRSelectMarket that the center to which the exchanges belong has changed. fCurrency is then set to the
			value newCurrency, and the menu is updated to fit the currency change. The screen is refreshed.
			CSRSelectCurrency::SetValue() is called automatically if CSRSelectCurrency knows of the existence of the
			CSRSelectMarket.
			@param newCurrency is the new currency code which will define a new set of markets in the menu.
			@version 4.5.2
			*/
			void	SetCurrency(long newCurrency);

			/**Obtains the traded currency of the markets.
			@return the currency that define the set of markets in the menu.
			@version 4.5.2
			*/
			long	GetCurrency() const { return fCurrency; }

			/**Sets the relative ID of the depository popup menu element (CSRSelectDepository) of the dialog/list.
			@see fERId_Depositary
			@param the relative ID of the depository popup menu element in the dialog or list.
			@version 4.5.2
			*/
			void	SetIdDepositary( int IdDepositary ) ;

			/**Obtains the relative ID of the depository popup menu element (CSRSelectDepository) of the dialog/list.
			@see fERId_Depositary
			@return relative ID of the depository popup menu element in the dialog or list.
			@version 4.5.2
			*/
			int		GetIdDepositary() const ;

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**Code of the selected exchange or market.
			fValue holds the 'exchange' code as a long integer, which is the currently selected market/exchange
			in the popup menu element.
			@version 4.5.2
			*/
			long	fValue;

			/**Center with which the exchanges are associated.
			fCurrency is the currency code. Each currency -sometimes market or place- 'owns' a certain
			number of exchanges. This exchanges can be handled through the CSRSelectMarket class.
			The user initialises fCurrency -i.e. chooses a market- with CSRSelectMarket::SetCurrency().
			@version 4.5.2
			*/
			long	fCurrency;

			/**The relative ID of the depository popup menu element (CSRSelectDepository) of the dialog/list.
			The depository popup menu will be updated whenever the market code selected and the currency (fCurrency) change.
			The set of depositories in the menu are updated according to the new market and currency.
			@version 4.5.2
			*/
			int		fERId_Depositary;

			/**Indicates if the currency selection can be modified, when the popup menu is embedded in a Hierarchical list.
			@version 4.5.2
			*/
			bool	fCanBeModified;

			_STL::vector<_STL::string> GetAllMarkets(void) const;
		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal
			virtual USMenu	*DonneMenu(void) const;			// internal
			virtual short	GetListValue(void) const;		// internal
			virtual void	SetListValue(short value);		// internal
			virtual Boolean	IsASharedMenu() const;			// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSRSelectMarket* newCSRSelectMarket(CSRGenericForm* pForm, int referenceInForm);

		/** Class CSRSelectDepositary:
		*	Derives from CSRThirdParyMenu, it is a popup menu for selecting a Depository.
		*	The class utilises a menu of Depository names, which is linked to the class by member fMenuTiers.
		*
		*	@version 4.5.2
		*/

		class CSCPTYMenuCacheMgr
		{
		public:
			virtual CSRThirdPartyKeyMenu* GetCPTYMenu( backoffice_kernel::eThirdPartyType typeTiers
				,long currency, long market, long allotment, long entity
				,bool IsSwiftToDisplay, bool AddStar) = 0;
		};

		class SOPHIS_FIT CSRSelectDepositary : public CSRThirdPartyMenu {
		public:
			/**Overloaded Constructor 1.
			Passes all parameters to first CSRThirdPartyMenu constructor. The popup element is
			in a dialog.
			@see CSRThirdPartyMenu::CSRThidPartyMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectDepositary(	CSRFitDialog 	*dialog,
				int 			 ERId_Depositary,
				long			 currency,
				long			 market,
				long			 allotment,
				long			 entity,
				CSCPTYMenuCacheMgr *menuCacheMgr = NULL,
				long			 value=0,
				const char 		 *columnName = kUndefinedField,
				bool			IsSwiftCodeToDisplay = false,
				bool			AddStar = false ,
				const char *	tagColonne = kSameAsOracleName) ;

			/**Overloaded Constructor 2.
			Passes all parameters to the second CSRThirdPartyMenu constructor. The popup element is
			in a list.
			@see CSRThirdPartyMenu::CSRThidPartyMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectDepositary(	CSREditList		*list,
				int 			 CNb_Depositary,
				long			 currency,
				long			 market,
				long			 allotment,
				long			 entity,
				CSCPTYMenuCacheMgr *menuCacheMgr = NULL,
				long			 value=0,
				const char 		 *columnName = kUndefinedField,
				bool			IsSwiftCodeToDisplay = false,
				bool			AddStar = false,
				const char *	tagColonne = kSameAsOracleName) ;

			/** Returns true to indicate that the pop-up menu allows modification.
			It is named differently from the base class method, because this function
			is invoked when menu is in Hierarchical windows.
			@return true because the Depository code selection can be modified.
			@version 4.5.2
			*/

			~CSRSelectDepositary() { if ( fMenuCacheMgr) delete fMenuCacheMgr; }
			Boolean CanBeModifiedInAList(void) const{return true;}

			virtual void Update(void);

			virtual void ValueToString(char *dest, int line);
			virtual short GetListValue(void) const;
			virtual void SetListValue(short value);
			virtual MenuHandle DonneMenu(void) const;
			static void WashCash();

		private:
			typedef _STL::map< long, _STL::string > MLongString;
			mutable CSCPTYMenuCacheMgr *fMenuCacheMgr;
			static MLongString CPTYNameCash;

			void RefreshWithCache();

			mutable long fLastCurrency;
			mutable long fLastMarket;
			mutable long fLastAllotment;
			mutable long fLastEntity;
		};

		/** Class CSRSelectInterestRate:
		*	Popup menu holding the interest rates. The interest rates' curves are of a specific currency,
		*	which is held also by the class.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectInterestRate : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			Passes to constructor CSRElement::CSRElement() the parameters: dialog, ERId_InterestRate, and columnName.
			The element is vontained in a dialog.
			@param dialog points to the dialog to which CSRSelectInterestRate belongs.
			@param ERId_InterestRate is the relative number of CSRSelectInterestRate.
			@param currency is the currency of the interest rates on the menu. It is the currency to which the interest rates listed by CSRSelectInterestRate belong.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectInterestRate(	CSRFitDialog 	*dialog,
				int 			 ERId_InterestRate,
				long			 currency,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			@param list points to the list to which CSRSelectInterestRate belongs.
			@param CNb_InterestRate is the relative number of CSRSelectInterestRate.
			@param currency is the currency of the interest rates on the menu. It is the currency to which the interest rates listed by CSRSelectInterestRate belong.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name whose structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectInterestRate(	CSREditList		*list,
				int 			 CNb_InterestRate,
				long			 currency,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Converts the interest rate code stored in the pop-up element, to the market name to display on the screen.
			The method is used in the case when the pop-up menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the currently selected interest rate code (fValue) and finds its name.
			@param dest is the text string that appears on the pop-up element text box on the list, to which the interest rate name is copied.
			@param line is the line on the list onto which the pop-up element is located.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/** Converts the reference of the security to its code (SICOVAM) and sets it to this element.
			The method is used in the case when the CSRInstrumentCode element is part of a CSREditList list.
			It takes the text string of the security reference, finds the code, and assigns it to the fValue of this element. 
			@param sourc is the reference of the security, whose code is to be set in this element.
			@param line is the number of the line on the containing CSREditList.
			@return true if the conversion is completed successfully.
			@see CSRCustomMenu::fValue
			@version 5.3.0.0
			*/
			virtual Boolean	StringToValue(const char *sourc, int line);

			/**Sets a display style to the popup element and obtains the interest rate code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectInterestRate object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the interest rate code selection and the related currency of another element, to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectInterestRate object.
			@param an element referring to a CSRSelectInterestRate object, from which the selection value and the currency are copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the interest rate code selection and the related currency of another element, to this element.
			Method Overloaded.
			@param an CSRSelectInterestRate object, from which the selection value and the currency are copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectInterestRate&);

			/**Compares the interest rate of this CSRSelectInterestRate, with the interest rate of another element.
			The parameter must refer to a CSRSelectInterestRate object, the fValue of which is compared with
			the fValue of the current CSRSelectInterestRate.
			@param a reference to a CSRSelectInterestRate object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's interest rate code selection (fValue) from the current element's interest rate code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the interest rate selection in the CSRSelectInterestRate.
			@param a pointer to the variable into which the CSRSelectInterestRate value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new interest rate selection to the popup element.
			Method Overloaded.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Checks whether the user can make a new selection of interest rate.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@returns true if the popup menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Optains a pointer to the fValue containing the interest rate code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/**Assigns a new interest rate code selection to the popup element.
			Method Overloaded.
			@param value is the interest rate code that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			void	SetValue(long value) { fValue = value; };

			/**Sets the currency of the interest rates that are contained in the menu.
			@see fCurrency
			@param the currency to whivh the set of interest rates belong.
			@version 4.5.2
			*/
			virtual void	SetCurrency(long newCurrency);

			/**Obtains the currency of the interest rates that are contained on the menu.
			@see fCurrency
			@return the currency to which the set of interest rates belong.
			@version 4.5.2
			*/
			long	GetCurrency() const { return fCurrency; }


			/** Unselect the pop-up by setting the current value to default/null.
			* This method is called when doing ALT-Click, provided that 'IsPossibleToReset()' returned true.
			@version 5.0
			*/
			virtual void	Reset() ;

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The currently selected interest rate code (sicovam) from the menu.
			@version 4.5.2
			*/
			long	fValue;

			/**It is the currency to which the interest rates listed by the CSRSelectInterestRate's menu belong.
			@version 4.5.2
			*/
			long	fCurrency;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal
			virtual USMenu	*DonneMenu(void) const;			// internal
			virtual short	GetListValue(void) const;		// internal
			virtual void	SetListValue(short value);		// internal
			virtual Boolean	IsASharedMenu() const;			// internal

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSRSelectInterestRate* newCSRSelectInterestRate(sophis::gui::CSRGenericForm* pForm, int referenceInForm, long currency);

		/** Class CSRSelectInterestRate:
		*	Popup menu holding the interpolated interest rates. The interest rates' curves are of a specific currency,
		*	which is held also by the class.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectInterpolatedInterestRate : public CSRSelectInterestRate {
		public:
			/**Overloaded Constructor 1.
			Passes to constructor CSRElement::CSRElement() the parameters: dialog, ERId_InterestRate, and columnName.
			The element is vontained in a dialog.
			@param dialog points to the dialog to which CSRSelectInterestRate belongs.
			@param ERId_InterestRate is the relative number of CSRSelectInterestRate.
			@param currency is the currency of the interest rates on the menu. It is the currency to which the interest rates listed by CSRSelectInterestRate belong.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectInterpolatedInterestRate(	CSRFitDialog 	*dialog,
												int 			 ERId_InterestRate,
												long			 currency,
												long			 value=0,
												const char 			*columnName = kUndefinedField,
												const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			@param list points to the list to which CSRSelectInterestRate belongs.
			@param CNb_InterestRate is the relative number of CSRSelectInterestRate.
			@param currency is the currency of the interest rates on the menu. It is the currency to which the interest rates listed by CSRSelectInterestRate belong.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name whose structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectInterpolatedInterestRate(	CSREditList		*list,
												int 			 CNb_InterestRate,
												long			 currency,
												long			 value=0,
												const char 			*columnName = kUndefinedField,
												const char *	tagColonne = kSameAsOracleName);

			/// Value type as returned by GetElementValue
			typedef long value_type;

			virtual void	SetCurrency(long newCurrency);
			virtual USMenu	*DonneMenu(void) const;			// internal
		};
		/** Class CSRSelectFamily.
		*	Pop-up menu holding the Families of interest rate curves. The interest rate curves' families are defined by a
		*	currency, which is held also by the class.
		*	The value handled by the class is the code of the interest curves family currenly selected in the pop-up menu element.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectFamily : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			Passes to base class constructor CSRElement::CSRElement() the parameters: dialog, ERId_InterestRate and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a dialog.
			@param dialog points to the dialog to which CSRSelectFamily belongs.
			@param ERId_InterestRate is the relative number of CSRSelectFamily.
			@param currency is the currency that determines the interest curves' families included in the menu.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectFamily(CSRFitDialog*	 dialog,
				int 			 ERId_InterestRate,
				long			 currency,
				long			 value=0,
				const char*		 columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Passes to base class constructor CSRElement::CSRElement() the parameters: list, CNb_InterestRate and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a list.
			@param list points to the list to which CSRSelectFamily belongs.
			@param CNb_InterestRate is the relative number of CSRSelectFamily.
			@param currency is the currency that determines the interest curves' families included in the menu.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name whose structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectFamily(CSREditList*	 list,
				int 			 CNb_InterestRate,
				long			 currency,
				long			 value=0,
				const char*		 columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Converts the code of the interest curves family stored in the popup element, to the name of the family to display on the screen.
			The method is used in the case when the pop-up menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the currently selected family code (fValue) and finds its name.
			@param dest is the text string that appears on the popup element text box on the list, to which the family name is copied.
			@param line is the line on the list onto which the popup element is located.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Sets a display style to the popup element and obtains the family code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectFamily object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the selected interest curves family code and related currency in another element, to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectFamily object.
			@param an element referring to a CSRSelectFamily object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the selected interest curves family code and related currency in another element, to this element.
			Method Overloaded.
			@param an CSRSelectFamily object, from which the selection value and the currency are copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectFamily&);

			/**Compares the interest curves family of this CSRSelectFamily, with the interest curves family of another element.
			The parameter must refer to a CSRSelectFamily object, the fValue of which is compared with
			the fValue of the current CSRSelectFamily.
			@param a reference to a CSRSelectFamily object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's family code (fValue) from the current element's family code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the interest curves family selection in the CSRSelectFamily.
			@param a pointer to the variable into which the CSRSelectFamily value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new interest curves family to the popup element.
			Method Overloaded.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/** Checks whether the user can make a new selection of interest curves family.
			The method is used in the case when the pop-up menu is part of a list.
			By default, it returns true.
			@returns true if the pop-up menu element allows the selection to be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Optains a pointer to the fValue containing the interest curves family code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/** Assigns a new interest curves family to the pop-up element.
			Method Overloaded.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			void	SetValue(long value) { fValue = value; };

			/**Sets the currency of the interest curves' families that are in the menu.
			@param the currency relating to the menu's interest curves' families.
			@version 4.5.2
			*/
			void	SetCurrency(long newCurrency);

			/**Obtains the currency of the interest curves families that are in the menu.
			@return the currency relating to the menu's interest curves' families.
			@version 4.5.2
			*/
			long	GetCurrency() const { return fCurrency; }

			void DisableFamily(long familyCode);

			void EnableFamily(long familyCode);

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/** The code of the selected family of interest curves.
			The code of the interest curves family currenly selected in the pop-up menu element.
			@version 4.5.2
			*/
			long	fValue;

			/**The currency relating to the set of families of interest curves, listed in the element's menu.
			@version 4.5.2
			*/
			long	fCurrency;

		public:
			virtual short	DonneFiltre(void) const;		// internal
			virtual	int		DonneTypeTri() const;			// internal
			virtual USMenu	*DonneMenu(void) const;			// internal
			virtual short	GetListValue(void) const;		// internal
			virtual void	SetListValue(short value);		// internal
			virtual Boolean	IsASharedMenu() const;			// internal

			virtual Boolean StringToValue(const char *sourc, int line);

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT CSRSelectFamily* newCSRSelectFamily(sophis::gui::CSRGenericForm* pForm, int referenceInForm, long currency);

		/** Class CSRSelectSeniority:
		*	Popup menu holding the set of seniorities.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectSeniority : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			Passes to base class constructor CSRElement::CSRElement() the parameters: dialog, ERId_Seniority and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a dialog.
			@param dialog points to the dialog to which CSRSelectSeniority belongs.
			@param ERId_InterestRate is the relative number of CSRSelectSeniority.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectSeniority(	CSRFitDialog 	*dialog,
				int 			 ERId_Seniority,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Passes to base class constructor CSRElement::CSRElement() the parameters: list, CNb_Seniority and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a list.
			@param list points to the list to which CSRSelectSeniority belongs.
			@param CNb_Seniority is the relative number of CSRSelectSeniority.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name whose structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param isEditable is a boolean that states whether the menu selection can be changed. The parameter's value is assigned to fIsEditable.
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRSelectSeniority(	CSREditList		*list,
				int 			 CNb_Seniority,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				bool			isEditable = true,
				const char *	tagColonne = kSameAsOracleName);

			/** Checks whether the popup menu allows modification.
			The method is used in the case when the pop-up menu is part of a list.
			By default, it returns true.
			@return true if the pop-up menu can be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/** Implementation of CSRElement method.
			*  Since 'true' is returned, the pop-up can be reset using ALT+Click and the 'Reset()' method will be called.
			@version 5.0
			*/
			virtual bool	IsPossibleToReset() const { return true; }

			virtual Boolean CanBeModifiedInAList() const;

			/** Converts the code of the seniority stored in the pop-up element, to the name of the seniority to display on the screen.
			The method is used in the case when the pop-up menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the currently selected seniority code (fValue) and finds its name.
			@param dest is the text string that appears on the pop-up element text box on the list, to which the seniority name is copied.
			@param line is the line on the list onto which the pop-up element is located.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Sets a display style to the popup element and obtains the seniority code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectSeniority object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the selected seniority code in another element, to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectSeniority object.
			@param an element referring to a CSRSelectSeniority object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the selected seniority code in another element, to this element.
			Method Overloaded.
			@param an CSRSelectSeniority object, from which the seniority code are copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectSeniority&);

			/**Compares the selected seniority of this CSRSelectFamily, with the seniority of another element.
			The parameter must refer to a CSRSelectSeniority object, the fValue of which is compared with
			the fValue of the current CSRSelectSeniority.
			@param a reference to a CSRSelectSeniority object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's seniority code (fValue) from the current element's family code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the seniority selection code in the CSRSelectSeniority.
			@param a pointer to the variable into which the CSRSelectSeniority value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/** Assigns a new seniority code to the pop-up element.
			Method Overloaded.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/* Unselect the pop-up by setting the current value to default/null.
			* This method is called when doing ALT-Click, provided that 'IsPossibleToReset()' returned true.
			@version 5.0
			*/
			virtual void	Reset();

			/**Optains a pointer to the fValue containing the selected seniority code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The code of the seniority that is currently selected from the popup menu of the CSRSelectSeniority element.
			@version 4.5.2
			*/
			long	fValue;

			/**The relative ID of the CSRSelectSeniority element is the dialog or list.
			@version 4.5.2
			*/
			int		fERId_Seniority;

			/**Indicates whether menu selection can be modified.
			This is true if the user is allowed to select another seniority from the CSRSelectSeniority popup menu.
			@version 4.5.2
			*/
			bool	fIsEditable;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual USMenu	*DonneMenu(void) const;				// internal
			virtual short	GetListValue(void) const;			// internal
			virtual void	SetListValue(short value);			// internal
			virtual Boolean	IsASharedMenu() const;				// internal
			virtual Boolean StringToValue(const char *sourc, int line);

			ELEM_COMMON_INTERNALS

		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRSelectSeniority);

		/** Class CSRSelectDefaultEvent:
		*	Popup menu holding the set of default events.
		*
		*	@version 4.5.2
		*/
		class SOPHIS_FIT CSRSelectDefaultEvent : public CSRElement {
		public:
			/**Overloaded Constructor 1.
			Passes to base class constructor CSRElement::CSRElement() the parameters: dialog, ERId_DefaultEvent and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a dialog.
			@param dialog points to the dialog to which CSRSelectDefaultEvent belongs.
			@param ERId_InterestRate is the relative number of CSRSelectDefaultEvent.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the name of a Sophis Xxx table column handled by the CSRXxx object.
			@version 4.5.2
			*/
			CSRSelectDefaultEvent(	CSRFitDialog 	*dialog,
				int 			 ERId_DefaultEvent,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			/** Overloaded Constructor 2.
			Passes to base class constructor CSRElement::CSRElement() the parameters: list, CNb_DefaultEvent and columnName. It initialises the
			default currently selected item in the element's fValue. The constructor is called when the CSRSelectFamily element is in a list.
			@param list points to the list to which CSRSelectDefaultEvent belongs.
			@param CNb_DefaultEvent is the relative number of CSRSelectDefaultEvent.
			@param value is the default value set to 0. To initialise fValue if columnName is nvZero when creating a new security.
			@param columnName is the user table column name whose structure must possess at least the two following fields :
			- CODE number(10), security identifier to establish a link with the Sophis table
			- NUMERO number(3), line identifier
			@param isEditable is a boolean that states whether the menu selection can be changed. The parameter's value is assigned to fIsEditable.
			@version 4.5.2
			*/
			CSRSelectDefaultEvent(	CSREditList		*list,
				int 			 CNb_DefaultEvent,
				long			 value=0,
				const char 			*columnName = kUndefinedField,
				bool			isEditable = true,
				const char *	tagColonne = kSameAsOracleName);

			/** Checks whether the popup menu allows modification.
			The method is used in the case when the pop-up menu is part of a list.
			By default, it returns true.
			@return true if the pop-up menu can be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/** Implementation of CSRElement method.
			*  Since 'true' is returned, the pop-up can be reset using ALT+Click and the 'Reset()' method will be called.
			@version 5.0
			*/
			virtual bool	IsPossibleToReset() const { return true; }

			virtual Boolean CanBeModifiedInAList() const;

			/** Converts the code of the default event stored in the pop-up element, to the name of the default event to display on the screen.
			The method is used in the case when the pop-up menu is part of a list.
			It is a callback function invoked internally by RISQUE.
			It takes the currently selected default event code (fValue) and finds its name.
			@param dest is the text string that appears on the pop-up element text box on the list, to which the default event name is copied.
			@param line is the line on the list onto which the pop-up element is located.
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const;

			/**Sets a display style to the popup element and obtains the default event code.
			@param value is a pointer to a union of several types. The value in the element is assigned to it.
			@param style is a style that will be modified/initialised to the CSRSelectDefaultEvent object, for use by the calling function.
			@param line is the line number on the CSREditList grid that refers to the information.
			@param onlyTheValue is true when the value parameter is the only one to obtain (not the style). Not used in this method, but can be useful if overriden.
			@version 4.5.2
			*/
			virtual void	GetDisplayValue(SSCellValue *value, SSCellStyle *style, int line, bool onlyTheValue) const;

			/**Assigns the selected default event code in another element, to this element.
			Method Overloaded.
			The parameter element must refer to a CSRSelectDefaultEvent object.
			@param an element referring to a CSRSelectDefaultEvent object, from which the selection value is copied.
			@version 4.5.2
			*/
			virtual void operator = (const CSRElement&);

			/**Assigns the selected default event code in another element, to this element.
			Method Overloaded.
			@param an CSRSelectDefaultEvent object, from which the default event code are copied.
			@version 4.5.2
			*/
			void operator = (const CSRSelectDefaultEvent&);

			/**Compares the selected default event of this CSRSelectFamily, with the default event of another element.
			The parameter must refer to a CSRSelectDefaultEvent object, the fValue of which is compared with
			the fValue of the current CSRSelectDefaultEvent.
			@param a reference to a CSRSelectDefaultEvent object from which the value is compared with this element's value.
			@return the result of the subtracting the parameter's default event code (fValue) from the current element's family code. Returns -1 if the method fails to compare.
			@version 4.5.2
			*/
			virtual int		Compare(const CSRElement&) const;

			/**Obtains the default event selection code in the CSRSelectDefaultEvent.
			@param a pointer to the variable into which the CSRSelectDefaultEvent value is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/** Assigns a new default event code to the pop-up element.
			Method Overloaded.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/* Unselect the pop-up by setting the current value to default/null.
			* This method is called when doing ALT-Click, provided that 'IsPossibleToReset()' returned true.
			@version 5.0
			*/
			virtual void	Reset();

			/**Optains a pointer to the fValue containing the selected default event code.
			@return a pointer to fValue.
			@version 4.5.2
			*/
			long	*GetValue(void) { return &fValue; };

			/// Value type as returned by GetElementValue
			typedef long value_type;

		protected:
			/**The code of the default event that is currently selected from the popup menu of the CSRSelectDefaultEvent element.
			@version 4.5.2
			*/
			long	fValue;

			/**The relative ID of the CSRSelectDefaultEvent element is the dialog or list.
			@version 4.5.2
			*/
			int		fERId_DefaultEvent;

			/**Indicates whether menu selection can be modified.
			This is true if the user is allowed to select another default event from the CSRSelectDefaultEvent popup menu.
			@version 4.5.2
			*/
			bool	fIsEditable;

		public:
			virtual short	DonneFiltre(void) const;			// internal
			virtual	int		DonneTypeTri() const;				// internal
			virtual USMenu	*DonneMenu(void) const;				// internal
			virtual short	GetListValue(void) const;			// internal
			virtual void	SetListValue(short value);			// internal
			virtual Boolean	IsASharedMenu() const;				// internal
			virtual Boolean StringToValue(const char *sourc, int line);

			ELEM_COMMON_INTERNALS

		};



		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRSelectDefaultEvent);


		/** Class CSRDeliveryMenu.
		*	Pop-up menu for selecting instrument delivery.
		*	This is a pop-up menu class for handling a menu with delivery choices.
		*	The popup element's fValue is of type eDelivery. @see eDelivery
		*
		*	@version 7.1
		*/
		class SOPHIS_FIT CSRDeliveryMenu : public CSRPopupMenu {
		public:
			/**Overloaded Constructor 1.
			Links the popup menu to a dialog.
			Passes all parameters to base class first constructor CSRPopupMenu. The resource ID of the menu is not initialized
			in the constructor, because it is the delivery menu that is specific (constant) to this class, and is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRDeliveryMenu        (CSRFitDialog	*dialog,
				int 				ERId_Menu,
				short 				value=0,
				const char 			*columnName = kUndefinedField,
				const char *	    tagColonne = kSameAsOracleName);

			/**Overloaded Constructor 2.
			Links the popup menu to a list.
			Passes all parameters to base class second constructor CSRPopupMenu. The resource ID of the menu is not initialized
			in the constructor, because it is the Delivery menu that is specific (constant) to this class, and is set
			internally by the class.
			@see CSRPopupMenu::CSRPopupMenu()
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@version 4.5.2.1 new parameter tagColonne.
			*/
			CSRDeliveryMenu        (CSREditList	*list,
				int 				CNb_Menu,
				short 				value=0,
				const char 			*columnName = kUndefinedField,
				const char *		tagColonne = kSameAsOracleName);

			/**Obtains the Delivery selection currently in the CSRCreditDefaultSwapBlotter.
			@param a pointer to the variable into which the popup element's Delivery value is copied.
			@version 7.1
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new Delivery value to the popup element.
			@param value is a pointer to the Delivery value that is to be copied to the fValue of the popup menu element.
			@version 7.1
			*/
			virtual void	SetValue(const void *value);


			virtual USMenu	*DonneMenu(void) const;	// internal

			typedef long value_type;
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRDeliveryMenu);

		class SOPHIS_FIT CSRPopupOptionModel : public sophis::gui::CSRPopupMenu
		{
		public:
			CSRPopupOptionModel(		sophis::gui::CSRFitDialog 	*dialog, 
				int 			 ERId_Menu, 
				short 			 value=0, 
				const char 		 *columnName = kUndefinedField);

			CSRPopupOptionModel(		sophis::gui::CSREditList		 *listBase, 
				int 			 CNb_Menu, 
				short 			 value=0, 
				const char 		 *columnName = kUndefinedField);

			virtual USMenu	*DonneMenu(void) const;	

			virtual void	GetValue(void *value) const;
			virtual void	SetValue(const void *value);
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRPopupOptionModel);

		class SOPHIS_FIT CSRPopupSwapModel : public sophis::gui::CSRPopupMenu
		{
		public:
			CSRPopupSwapModel(		sophis::gui::CSRFitDialog 	*dialog, 
				int 			 ERId_Menu, 
				short 			 value=0, 
				const char 		 *columnName = kUndefinedField);

			CSRPopupSwapModel(		sophis::gui::CSREditList		 *listBase, 
				int 			 CNb_Menu, 
				short 			 value=0, 
				const char 		 *columnName = kUndefinedField);

			void ChooseModel(const char* modelname);

			virtual USMenu	*DonneMenu(void) const;	
		};

		SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRPopupSwapModel);

		class SOPHIS_FIT CSRPopupMenuCustomData : public CSRPopupMenu
		{
		public:
			CSRPopupMenuCustomData(		const _STL::vector<char*>& nameList,
				const _STL::vector<long>& keyList,
				CSRFitDialog 	*dialog,
				int 			 ERId_Menu,
				short 			 value=0,
				const char 		 *columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);
			CSRPopupMenuCustomData(		const _STL::vector<char*>& nameList,
				const _STL::vector<long>& keyList,
				CSREditList		*list,
				int 			 CNb_Menu,
				short 			value=0,
				const char 		*columnName = kUndefinedField,
				const char *	tagColonne = kSameAsOracleName);

			~CSRPopupMenuCustomData();

			virtual USMenu	*DonneMenu(void) const;
			virtual void	GetValue(void *value) const;

		protected:
			_STL::vector<long> fKeyList;
			USMenu* fCustomMenu;
		};


		class SOPHIS_FIT CSRPopupPortfolio : public CSRPopupMenu
		{
		public:
			CSRPopupPortfolio(	CSREditList	*list,
				int 		CNb_Portfolio,
				long		folioIdent = 0,	
				const char 	*columnName = kUndefinedField);
			CSRPopupPortfolio(	CSRFitDialog	*dlog,
				int 		ERId_Menu,
				long		folioIdent = 0,	
				const char 	*columnName = kUndefinedField,
				bool bShowAllAvailableFolders = false,
				long nRestrictOnEntity = -1);	// OOF #43064: Option to restrict available folio list by entity.

			~CSRPopupPortfolio();

			virtual USMenu	*DonneMenu(void) const;	
			virtual void	GetValue(void *value) const;

			short	IdentToIndex(long ident);

			virtual void	SetValue(const void *value);

			virtual short	GetListValue(void) const;								// internal
			virtual void	SetListValue(short value);								// internal

			// Sets the selected menu item to the first available, and returns the folio code of that item
			// If there are no items in the folio list, returns -1.
			long SetToFirstAvailable();

			struct DataPortfolio
			{
				CSUMenu * menu;
				_STL::vector<long> array_codes;
			};

			static void CreateMenuPortfolio(bool withtempfolder, long folioIdent, 
				DataPortfolio& data, bool bIncludeAllAvailableFolders=false, long nRestrictOnEntity = -1); // internal

			bool FolderExistsInSelection(long nFolderIdent);

			typedef long value_type;

		protected:
			DataPortfolio  fData;
			long			fFolioIdent;

		private:
			bool m_bShowAllAvailableFolders;
		};

		SOPHIS_FIT CSRPopupPortfolio* newCSRPopupPortfolio(CSRGenericForm* pForm, int referenceInForm, int folioIdent);

		class SOPHIS_FIT CSRPopupMenuQuotationGrid : public CSRPopupMenu 
		{
		public:
			CSRPopupMenuQuotationGrid(	CSRFitDialog 	*dialog, 
				int 			 ERId_Menu);

			CSRPopupMenuQuotationGrid(	CSREditList		*list, 
				int 			 CNb_Menu);	

			virtual CSUMenu *DonneMenu(void) const;	

			void GetCurrentQuotationGrid(_STL::string& nom) const;

			void SetCurrentQuotationGrid(const _STL::string& nom);

		private:
			MenuHandle fMenuModel;
		};

		class SOPHIS_FIT CSRPopupMenuForceMenu : public CSRPopupMenu
		{
		public:
			/**	Constructor 1
			Used when the element is contained within a dialog. The constructor initialises the menu handle as empty,
			along with the rest of the fields, according to the parameters.
			@param dialog is a pointer to the dialog, which contains the custom pop-up menu element.
			@param ERId_Menu is the relative unique number of the CSRCustomMenu element, among other elements in the dialog.
			@param newMenuToDelete is new instance of the menu to set.
			@param value is the default (initial) menu selection index.
			@param columnName is the name of a column of the Sophis database table handled by the CSRXxx object. @see CSRElement
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@since 5.3.
			*/
			CSRPopupMenuForceMenu(	CSRFitDialog								*dialog,
				int 										ERId_Menu,
				CSUMenu										*newMenuToDelete,
				short 										value=0,
				const char 									*columnName=kUndefinedField,
				const char *								tagColonne = kSameAsOracleName);		
			/**	Constructor 2
			Used when the element is contained within a list, as a column. The constructor initialises the menu handle as empty,
			along with the rest of the fields, according to the parameters.
			@param list is a pointer to the list which contains the custom pop-up menu element.
			@param ERId_Menu is the relative unique number of the CSRCustomMenu element, among other elements in the dialog.
			@param newMenuToDelete is new instance of the menu to set.
			@param value is the default (initial) menu selection index.
			@param columnName is the name of a column of the Sophis database table handled by the CSRXxx object. @see CSRElement
			@param tagColonne is the tag for the column for the DataService; the possible values are a string, kSameAsOracleName, or no tag.
			@since 5.3.
			*/
			CSRPopupMenuForceMenu(	CSREditList									*list,
				int 										CNb_Menu,
				CSUMenu										*newMenuToDelete,
				short 										listValue=0,
				const char 									*columnName=kUndefinedField,
				const char *								tagColonne = kSameAsOracleName);

			~CSRPopupMenuForceMenu();

			virtual USMenu	*DonneMenu(void) const;									// internal
		protected:
			CSUMenu *fMenuHdl;
		};

		class  SOPHIS_BASIC_DATA_GUI CSRAllotmentMenu : public sophis::gui::CSRPopupMenu
		{
		public:
			CSRAllotmentMenu(sophis::gui::CSRFitDialog	*dialog, 
				int 				ERId_Menu, 
				short 				value=0, 
				const char 				*columnName = kUndefinedField);
			CSRAllotmentMenu(sophis::gui::CSREditList	*list, 
				int 		CNb_Menu, 
				short 		value=0, 
				const char 	*columnName = kUndefinedField);

			virtual USMenu	*DonneMenu(void) const;	// internal
			virtual void	GetValue(void *value) const;
			virtual void	SetValue(const void *value);
			virtual short	GetListValue(void) const;
			virtual void	SetListValue(short value);
		};

		SOPHIS_BASIC_DATA_GUI TRIVIAL_ELEMENT_FACTORY(CSRAllotmentMenu);

        class SOPHIS_FIT CSRCommonFixingTypeMenu : public sophis::gui::CSRPopupMenu
        {
        public:
	        CSRCommonFixingTypeMenu(sophis::gui::CSRFitDialog	*dialog, 
		        int 				ERId_Menu, 
		        bool				readonly = false,
		        short 				value=0, 
		        const char 				*columnName = kUndefinedField);
	        CSRCommonFixingTypeMenu(sophis::gui::CSREditList	*list, 
		        int 		CNb_Menu, 
		        bool		readonly = false,
		        short 		value=0, 
		        const char 	*columnName = kUndefinedField);

	        virtual USMenu	*DonneMenu(void) const;	// internal

	        virtual void	GetValue(void *value) const;
	        virtual	void	SetValue(const void *value);
	        virtual Boolean	MenuCanBeModifiedInAList(void) const { return !fReadOnly; }
            virtual void SetListValue(short value);
        	
	        typedef long value_type;

        protected:
	        bool fReadOnly;
        };

        SOPHIS_FIT TRIVIAL_ELEMENT_FACTORY(CSRCommonFixingTypeMenu);

        /**
         * For backwards compatibility purpose. New devs should use CSRCommonFixingTypeMenu instead (handles both dialog and edit list modes better).
         */
		class SOPHIS_BASIC_DATA_GUI CSRFixingTypeLegMenu : public sophis::gui::CSRCommonFixingTypeMenu
		{
		public:
			CSRFixingTypeLegMenu(sophis::gui::CSRFitDialog	*dialog, 
				int 				ERId_Menu, 
				bool				readonly = false,
				short 				value=0, 
				const char 				*columnName = kUndefinedField);
			CSRFixingTypeLegMenu(sophis::gui::CSREditList	*list, 
				int 		CNb_Menu, 
				bool		readonly = false,
				short 		value=0, 
				const char 	*columnName = kUndefinedField);

			virtual	void    SetListValue(short value);
            virtual	void	SetValue(const void *value);
		};

		SOPHIS_BASIC_DATA_GUI TRIVIAL_ELEMENT_FACTORY(CSRFixingTypeLegMenu);

		/// Base class for generic menus
		class SOPHIS_FIT CSRGenericDynamicMenu : public sophis::gui::CSRElement 
		{
		protected:
			/** The code that is currenly selected in the popup menu. */
			long fValue;

		public:

			CSRGenericDynamicMenu(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);


			CSRGenericDynamicMenu(
				CSREditList *liste, 
				int NRC_Menu, 
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			virtual ~CSRGenericDynamicMenu(void);

			/**Converts the code fValue stored in the popup element, to the name to display on the screen.
			The method is used in the case when the popup menu is part of a CSREditList list.
			It reads the code stored in fValue, and finds the corresponding name in the menu.
			@param dest is the name that appears on the popup element text box on the list, to which the selection is copied.
			@param line is the line on the the list onto which the popup element is located
			@version 4.5.2
			*/
			virtual void	ValueToString(char *dest, int line) const = 0;

			/** Convert a string to a code and assign it to fValue */
			virtual Boolean	StringToValue(const char *sourc, int line) = 0;

			/** 
			* Update fMenu (create it if needed), return true if the menu contents changed in any way 
			*/
			virtual bool UpdateMenu() = 0;

			virtual void SetPositionInMenu(short position);

			/**Obtains the current code (long value).
			@param a pointer to the variable into which the code is copied.
			@version 4.5.2
			*/
			virtual void	GetValue(void *value) const;

			/**Assigns a new code to the popup menu.
			@param value is a pointer to the value that is to be assigned to the fValue of the popup menu element.
			@version 4.5.2
			*/
			virtual void	SetValue(const void *value);

			/**Checks whether the popup menu allows modification.
			The method is used in the case when the popup menu is part of a list.
			By default, it returns true.
			@return true if the popup menu can be modified.
			@version 4.5.2
			*/
			virtual Boolean	MenuCanBeModifiedInAList(void) const;

			/**Obtains a pointer to the fValue.
			@return a pointer to the fValue that holds the third party code selection in the CSRThirdPartyMenu.
			@version 4.5.2
			*/
			long 	*GetValue(void) { return &fValue; };

			/**Reconstructs the menu.
			@see CSRThidPartyMenu::fMenuTiers
			Normally it is called after SetCurrency() or SetMarket().
			@version 4.5.2
			*/
			virtual void	Update(void) const;
		
			/// Obtains the menu
			virtual MenuHandle GetMenu();
		
			/// Value type as returned by GetElementValue
			typedef long value_type;
		
			mutable MenuHandle fMenuHandle;
		
		public:

			virtual short	DonneFiltre(void) const;							// internal
			virtual	int		DonneTypeTri() const;								// internal
			virtual USMenu	*DonneMenu(void) const;								// internal
			virtual short	GetListValue(void) const;							// internal
			virtual void	SetListValue(short value);							// internal
			virtual Boolean	IsASharedMenu() const;								// internal


			virtual void	Initialisation(sophis::gui::CSRFitDialog *dialog, int &number);
			virtual char	*InitialisePointeur(char* result);
			virtual char	*InitialisePointeur(char* result, bool noWriting);
			virtual const char *InitialiseDialogue(const char* result);

			virtual void	InitialiseOracle(	Tdescribe	*desc, char		**read, char		**write, char		**insert);
			virtual	void	InitRequetes(Tdescribe	*desc, char		**selectQuery, char		**insertQuery);
			virtual sophis::sql::eRelationalDatabaseFieldType	GetOracleStorage(void);
			virtual	void	RequetesEcritureFormat(char *valeurChamp);
		};

		class SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModel : public CSRGenericDynamicMenu
		{
		protected:

			long fCurrency;
			_STL::string fModelName;

			mutable long fPreviousCurrency;
			mutable _STL::string fPreviousModelName;

		public:

			CSRSelectFamilyWithModel(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long currency = 0,
				_STL::string modelName = "",
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			CSRSelectFamilyWithModel(
				CSREditList *liste, 
				int NRC_Menu, 
				long currency = 0,
				_STL::string modelName = "", 
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			virtual ~CSRSelectFamilyWithModel(void);

			virtual void	ValueToString(char *dest, int line) const;

			virtual Boolean	StringToValue(const char *sourc, int line);

			virtual bool UpdateMenu();

			virtual void SetCurrency(long currency);
			virtual void SetModelName(_STL::string modelName);
			virtual bool CheckYieldCurveIsCoherent(long yieldCurveId);
		};
		SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModel* newCSRSelectFamilyWithModel(CSRGenericForm* pForm, int referenceInForm, long currency = 0, _STL::string modelName = "");

		class SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModelForBasisSwap : public CSRSelectFamilyWithModel
		{
		public:

			CSRSelectFamilyWithModelForBasisSwap(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long currency = 0,
				_STL::string modelName = "",
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			CSRSelectFamilyWithModelForBasisSwap(
				CSREditList *liste, 
				int NRC_Menu, 
				long currency = 0,
				_STL::string modelName = "", 
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			virtual ~CSRSelectFamilyWithModelForBasisSwap(void);

			virtual bool CheckYieldCurveIsCoherent(long yieldCurveId);
		};
		SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModelForBasisSwap* newCSRSelectFamilyWithModelForBasisSwap(CSRGenericForm* pForm, int referenceInForm, long currency = 0, _STL::string modelName = "");
	
		class SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModelMonetary : public CSRSelectFamilyWithModel
		{
		public:

			CSRSelectFamilyWithModelMonetary(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long currency = 0,
				_STL::string modelName = "",
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			CSRSelectFamilyWithModelMonetary(
				CSREditList *liste, 
				int NRC_Menu, 
				long currency = 0,
				_STL::string modelName = "", 
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			virtual ~CSRSelectFamilyWithModelMonetary(void){};

			virtual bool CheckYieldCurveIsCoherent(long yieldCurveId);
		};

		SOPHIS_PORTFOLIO_GUI CSRSelectFamilyWithModelMonetary* newCSRSelectFamilyWithModelMonetary(CSRGenericForm* pForm, int referenceInForm, long currency, _STL::string modelName);

		class SOPHIS_PORTFOLIO_GUI CSRInterestRateCurveMenu : public CSRGenericDynamicMenu
		{
		protected:

			long fFamily;

			mutable long fPreviousFamily;

		public:

			CSRInterestRateCurveMenu(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long family = 0,
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			CSRInterestRateCurveMenu(
				CSREditList *liste, 
				int NRC_Menu, 
				long family = 0,
				long value = 0, 
				const char *champDansTable = kUndefinedField,
				const char * tagColonne = kSameAsOracleName);

			virtual ~CSRInterestRateCurveMenu(void);

			virtual void	ValueToString(char *dest, int line) const;

			virtual Boolean	StringToValue(const char *sourc, int line);

			virtual bool UpdateMenu();

			virtual void SetFamily(long family);
		};

		SOPHIS_PORTFOLIO_GUI CSRInterestRateCurveMenu* newCSRInterestRateCurveMenu(CSRGenericForm* pForm, int referenceInForm, long family = 0);

		/// Menu containing all business events that correspond to a given sicovam.
		class SOPHIS_BASIC_DATA_GUI CSRDynamicBusinessEventMenu : public CSRGenericDynamicMenu 
		{
			/// Cache that maps an Affectation id to the corresponding vector of business events.
			_STL::map<long, _STL::vector<long> > fMenuCache;
			long fSicovam;
			long fPreviousSicovam;
		public:
			CSRDynamicBusinessEventMenu(
				CSRFitDialog *dialogue, 
				int NRE_Menu, 
				long sicovam = -1, //CSRBusinessEvent::ALL_BE
				long value = 0, 
				const char *champDansTable = kUndefinedField, 
				const char * tagColonne = kSameAsOracleName);

			CSRDynamicBusinessEventMenu(
				CSREditList* liste, 
				int NRC_Menu,  
				long sicovam = -1, //CSRBusinessEvent::ALL_BE
				long value = 0, 
				const char *champDansTable = kUndefinedField, 
				const char * tagColonne = kSameAsOracleName);

			~CSRDynamicBusinessEventMenu();

			void ValueToString(char *dest, int line) const;

			Boolean StringToValue(const char *sourc, int line);

			bool UpdateMenu();
			
			void SetSicovam(long sicovam);
		};

		SOPHIS_BASIC_DATA_GUI CSRDynamicBusinessEventMenu* newCSRDynamicBusinessEventMenu(CSRGenericForm* pForm, int referenceInForm, long sicovam = -1 /*CSRBusinessEvent::BE_ALL*/);

	}
}

SPH_END_NOWARN_EXPORT
SPH_EPILOG


#endif