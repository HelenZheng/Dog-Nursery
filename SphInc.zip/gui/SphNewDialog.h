#pragma once
/*
 	File:		SphNewDialog.h

 	Contains:	Interface for a sophis class to create a dialog.

 	Copyright:	� 2002 Sophis.
*/

/*! \file SphNewDialog.h
	\brief Creating a dialog.
*/

#ifndef _SphNewDialog_H_
#define _SphNewDialog_H_

#include "SphInc/SphMacros.h"

SPH_PROLOG
namespace sophis	{
	namespace	gui	{

		class CSRFitDialog;

		/** Interface for creating a dialog.
		When derived objects can add a dialog for including supplementary data,
		the main class implements the interface with a trivial return and the derived class can implement the new_Dialog method, to show the associated dialog, if necessary
		@see CSRExtraction
		@since 4.4.0
		*/
		class SOPHIS_FIT ISRNewDialog
		{
		public:
			/** Trivial constructor.
			*/
			ISRNewDialog();

			/** Trivial destructor.
			*/
			virtual ~ISRNewDialog();

			/** Creation of the associated dialog for supplementary data.
			The dialog does not need to be fitted with the derived class, only with the default values.
			@return a new dialog which will be deleted later on. Returns 0
			if no supplementary data.
			*/
			virtual CSRFitDialog * new_Dialog() const;

			/** Called by CSRMetaModel::OpenDialogInReadMode. Creation of the associated dialog for displaying data.
			@return a new dialog which will be deleted later on. Returns 0
			if no supplementary data.
			*/
			virtual CSRFitDialog * new_ReadDialog(const instrument::CSRInstrument * instrument) const;
		};

	}
}

SPH_EPILOG
#endif
