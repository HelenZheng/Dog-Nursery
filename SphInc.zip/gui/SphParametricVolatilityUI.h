#pragma once

#include "SphInc/SphMacros.h"
#include "SphInc/market_data/SphParametricVolatility.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{
		class SOPHIS_BASIC_DATA_GUI CSRParametricVolatilityUI
		{
		public:
			/** Show the dialog to edit the parametric volatility.
			Note that this function is in SphBasicDataGUI.dll
			and is not availbale in API.
			*/
			static void	Edit(sophis::market_data::CSRParametricVolatility& paramVol, bool forImpliedVol=false);
		private:
			CSRParametricVolatilityUI();
			~CSRParametricVolatilityUI();
			CSRParametricVolatilityUI(const CSRParametricVolatilityUI&);
			CSRParametricVolatilityUI& operator = (const CSRParametricVolatilityUI&);
		};
	}
}
SPH_EPILOG

