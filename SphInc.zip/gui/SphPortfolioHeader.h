/*
File:		SphPortfolioHeader.h

Contains:	Class for the handling of portfolio headers data and WinForm custom header registration 

Copyright:	(c) 2006-2007 Sophis.

*/

/*! \file SphPortfolioHeader.h
\brief Handling portfolio headers data
*/

#ifndef	_SphPortfolioHeader_H_
#define	_SphPortfolioHeader_H_

#include "SphInc/SphMacros.h"
#include "SphInc/portfolio/SphExtraction.h"

SPH_PROLOG
namespace sophis
{
	namespace gui
	{

		/**Enumeration defining the possible location of the header.
		The current location of the header can be retrieve by using CSRPortfolioHeaderDialog::GetLocation.
		@version 5.3
		*/
		enum FolioHeaderLocation
		{
			_DefaultLocation,
			_Portfolio,
			_ResultVariation,
			_CrossedIndicators,
			_LastLocation
		};

		/**	Class CSRPortfolioHeaderCurrencyData:
		*	Storage for the data relative to a currency.
		*	In the standard header, this data correspond to a line of the edit list.
		*	
		*	@version 5.3
		*/
		class SOPHIS_PORTFOLIO_GUI CSRPortfolioHeaderCurrencyData
		{
		public:
			/**Constructor.
			@version 5.3
			*/
			CSRPortfolioHeaderCurrencyData();

			/**Data.
			*/
			long	fCurrency;
			double	fDelta;
			double	fGamma;
			double	fRho;
			double	fConvexity;
			double	fIndex;
		};

		/** Export
		*/
		template class SOPHIS_PORTFOLIO_GUI _STL::allocator< CSRPortfolioHeaderCurrencyData >;
		template class SOPHIS_PORTFOLIO_GUI _STL::vector< CSRPortfolioHeaderCurrencyData, _STL::allocator< CSRPortfolioHeaderCurrencyData > >;

		typedef _STL::vector< CSRPortfolioHeaderCurrencyData > CSRPortfolioHeaderCurrencyDataVector;


		/**	Class CSRPortfolioHeaderData:
		*	Storage for the data relative to the whole header.
		*	It contains the results that needs to be displayed in the header.
		*	
		*	@version 5.3
		*/
		class SOPHIS_PORTFOLIO_GUI CSRPortfolioHeaderData
		{
		public:
			/**Constructor.
			@version 5.3
			*/
			CSRPortfolioHeaderData();

			/**Destructor.
			@version 5.3
			*/
			virtual ~CSRPortfolioHeaderData();

			/**General data.
			@version 5.3
			*/
			long		fInstrumentCode;		// Portfolio underlying.
			long		fCurrency;				// Currency used in the folio.
			long		fGreekCurrency;			// Currency used for some greeks.

			/**Only useful in the result variation window.
			This date corresponds to the previous date used when computing the variations.
			@version 5.3
			*/
			long		fPreviousDate;

			/**Results data.
			@version 5.3
			*/
			double		fRealized;
			double		fUnrealized;
			double		fIncome;
			double		fTreasury;
			double		fFinancing;
			double		fResult;

			/**Greek data.
			@version 5.3
			*/
			double		fDelta;
			double		fGamma;
			double		fEpsilon;
			double		fVega;
			double		fTheta;
			double		fRho;

			/**Currency data (displayed in the edit list on the right-hand side of the header).
			@version 5.3
			*/
			CSRPortfolioHeaderCurrencyDataVector	fCurrencyData;

		protected:
			void Initialize(const CSRPortfolioHeaderData &other);
		};


		/**	Class CSRPortfolioHeaderWinFormData:
		*	Storage for the data relative to the whole header.
		*	It contains the results that needs to be displayed in the WinForm style header.
		*	
		*	@version 5.3
		*/
		class SOPHIS_PORTFOLIO_GUI CSRPortfolioHeaderWinFormData : public virtual CSRPortfolioHeaderData
		{
		public:
			/**Constructor
			@folioIdent	folio ident of the header window
			@extraction	extraction of the header window
			@location	header type (location)
			*/
			CSRPortfolioHeaderWinFormData(const CSRPortfolioHeaderData& headerData,
										long folioIdent,
										portfolio::PSRExtraction extraction,
										FolioHeaderLocation location, 
										_STL::string workbookName = "");
			
			/**Constructor
			@folioIdent	folio ident of the header window
			@extraction	extraction of the header window;
			@location	header type (location)
			@dummy : for DotNet wrapping reason. Useles in the code.
			*/
			CSRPortfolioHeaderWinFormData(const CSRPortfolioHeaderData& headerData,
										long folioIdent,
										portfolio::PSRExtraction extraction,
										FolioHeaderLocation location,
										bool dummy, 
										_STL::string workbookName = "");

			/**Copy constructor.
			*/
			CSRPortfolioHeaderWinFormData(const CSRPortfolioHeaderWinFormData& toCopy);

			/** Identifier of the principal folio displayed in the window containing this header.
			@see {@link CSRPortfolioHeaderDialog::GetFolioID}
			*/
			long fFolioIdent;

			_STL::string fWorkbookName;
			/** Get the Extraction used by the window containing this header
			@see {@link CSRPortfolioHeaderDialog::GetFolios}
			*/
			portfolio::PSRExtraction GetFolios();

			/** Get the Extraction used by the window containing this header
			@see {@link CSRPortfolioHeaderDialog::GetFolios}
			*/
			portfolio::PSRExtraction GetExtraction();


			/** Location of the window where the header is being displayed
			@see {@link CSRPortfolioHeaderDialog::GetLocation}
			@see {@link FolioHeaderLocation}
			*/
			FolioHeaderLocation fLocation;

			CSRPortfolioHeaderWinFormData();

			void Initialize(const CSRPortfolioHeaderData& headerData,
				long folioIdent,
				portfolio::PSRExtraction extraction,
				FolioHeaderLocation location, 
				_STL::string workbookName);

			void Initialize(const CSRPortfolioHeaderData& headerData,
				long folioIdent,
				portfolio::PSRExtraction  extraction,
				FolioHeaderLocation location,bool dummy, 
				_STL::string workbookName);

		protected:

			/**Copy constructor.
			*/
			void Initialize(const CSRPortfolioHeaderWinFormData& toCopy);


		private:
			/**Private extraction 
			*/
#ifndef GCC_XML
			_STL::weak_ptr<sophis::portfolio::CSRExtraction> fExtraction;
#endif

		public:
			virtual ~CSRPortfolioHeaderWinFormData();
		};

		/** Class to handle WinForm style portfolio headers
		@see {@link CSRPortfolioHeaderDialog}
		@version 5.3
		*/
		class SOPHIS_PORTFOLIO_GUI CSRPortfolioHeader
		{
		public:
			/**Retrieve the identifier of the header to use when opening a portfolio type window (portfolio, 
			result variation ...).
			Same use as {@link CSRPortfolioHeaderDialog::GetCurrentHeaderID}. 
			To be used from .NET toolkit.
			*/
			static long	GetCurrentHeaderID(FolioHeaderLocation location);

			/**Call this static method if you want to modify the header that is used when opening
			a portfolio type window.
			Same use as {@link CSRPortfolioHeaderDialog::SetCurrentHeaderID}. 
			To be used from .NET toolkit.
			*/
			static void	SetCurrentHeaderID(FolioHeaderLocation location, long ident);

			/**Calls this static method if you want to retrieve the identifier of the default header.
			Same use as {@link CSRPortfolioHeaderDialog::GetDefaultHeaderID}. 
			To be used from .NET toolkit.
			*/
			static long	GetDefaultHeaderID();

			/** Get the number of registered WinForm type headers.
			*/
			static long GetHeaderFormCount();

			/**Get the WinFom name associated to a given header identifier.
			*/
			static _STL::string GetHeaderFormName(long ident);

			/** Register a WinForm style portfolio header with same header name as form name
			@ident portfolio header ID
			@formName form name
			*/
			static void RegisterHeaderForm(long ident, _STL::string formName);

			/** Set the default folio header to the "Customizable header" for the current user for a specific folio. Overrides the GetDefaultHeaderID
			@ident portfolio header ID
			@formName form name
			*/
			enum eCustomizableFolioHeaderMode
			{
				eCFHSameAsParent,
				eCFHForcedYes,
				eCFHForcedNo,
				eCFHLastEnum = eCFHForcedNo
			};

			static void SetCustomizableHeader(long idFolio,eCustomizableFolioHeaderMode mode);
			static void SetCustomizableHeader(_STL::string wbName,eCustomizableFolioHeaderMode mode);

			/** Returns true is the folio is using the customizable header.
			@ident portfolio header ID
			@formName form name
			*/
			static eCustomizableFolioHeaderMode IsUsingCustomizableHeader(long idFolio);
			static eCustomizableFolioHeaderMode IsUsingCustomizableHeader(_STL::string wbName);

			static long GetCustomizableHeaderID();

			static void RegisterCustomizableHeaderForm(_STL::string formName,_STL::string formTitle);

			/**Get the WinFom name associated to a given header index.
			*/
			static _STL::string GeNthCustomizableHeaderFormName(int index);
			static _STL::string GeNthCustomizableHeaderFormTitle(int index);
			static int GeCustomizableHeaderFormCount();

			/**Get the nearest parent folio having a configuration saved in the database.
			*  Calling this method does not load the folios.
			*/
			static long GetFirstParentFolioWithSettings(long idFolioTarget, portfolio::PSRExtraction extraction = 0);

		private:
			// internal
			static _STL::map<long, _STL::string> fHeaderForm;

			static const char * __CLASS__;
		};

		/** Class to handle sophis menu enable status.
		It is used to modify CSUMenu entries status from .NET toolkit
		@version 5.3
		*/
		class SOPHIS_PORTFOLIO_GUI CSRMenuEntry
		{
		public:
			CSRMenuEntry();
			CSRMenuEntry(const _STL::string& text, bool enable);

			/** Menu entry text
			*/
			_STL::string	fText;

			/** Menu entry status
			*/
			bool			fEnable;
		};

	}	// namespace gui
}	// namespace sophis
SPH_EPILOG
#endif // _SphPortfolioHeader_H_
