EXEC  PCKG_BTG_ARCH_INST.PRC_POPULATE_TITRES_NOV;
EXEC  PCKG_BTG_ARCH_INST.PRC_ARCH_INSTRUMENTS;

truncate table HISTORIQUED_D;
truncate table HISTORIQUEB_D;
truncate table HISTORIQUEA_D;
truncate table HISTORIQUET_D;

call optimize_history_pkg.load();

commit;

EXEC DBMS_STATS.GATHER_SCHEMA_STATS('BTG41');
