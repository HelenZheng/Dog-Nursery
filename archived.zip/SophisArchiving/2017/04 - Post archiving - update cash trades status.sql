
--Steps to update the backoffice status to mo confirmed for those posted cash

--1. 

select SEQLOG.nextval from dual;

--2. 


begin
update histomvts
set backoffice=12 
where refcon in(
select refcon from histomvts 

inner join titres
on titres.sicovam=histomvts.sicovam

where titres.reference like 'Archiving_Cash_%'
);commit;
end;