
SELECT DISTINCT

HISTOMVTS.SICOVAM SICOVAM
,TITRES.reference REFERENCE
,TITRES.libelle NAME
--,TO_CHAR(HISTOMVTS.dateneg, 'YYYY-MM-DD') TRADE_DATE
, SECTOR_INSTRUMENT_ASSOCIATION.sector INST_BBG_COUNTRY_CODE
, SECTORS.name INST_COUNTRY_NAME
, AFFECTATION.libelle ALLOTMENT
, DEVISE_TO_STR(MARCHE.codedevise) MARKET_CCY
, MARCHE.mnemomarche MARKET_ID
, num_to_str(MARCHE.mnemomarche) MARKET_CODE
--, MARCHE.codedevise CCY_CODE

, MARCHE.libelle MARKET_NAME
, EXTRNL_REF_MARKET_VALUE.value JPM_PSET_BIC


------Select all trades in the database + Backups
FROM (
	SELECT *
	FROM HISTOMVTS
	
	UNION ALL
	
	SELECT *
	FROM btg_histomvts_backup2017 b2017
WHERE NOT EXISTS (
		SELECT 1
		FROM histomvts h
		WHERE h.refcon = b2017.refcon
		)

UNION ALL

SELECT *
FROM btg_histomvts_backup2015 b2015
WHERE NOT EXISTS (
		SELECT 1
		FROM btg_histomvts_backup2017 b
		WHERE b.refcon = b2015.refcon
		)

UNION ALL

SELECT *
FROM btg_histomvts_backup2014 b2014
WHERE NOT EXISTS (
		SELECT 1
		FROM btg_histomvts_backup2015 b
		WHERE b.refcon = b2014.refcon
		) ) HISTOMVTS
    

    
------INSTRUMENT
LEFT JOIN TITRES 
	ON TITRES.sicovam = HISTOMVTS.sicovam   
------

------ALLOTMENT
LEFT JOIN AFFECTATION
ON AFFECTATION.ident = TITRES.affectation 
------

------BUSINESS_EVENTS
INNER JOIN BUSINESS_EVENTS
	ON BUSINESS_EVENTS.id = HISTOMVTS.type
		AND BUSINESS_EVENTS.compta = 1 -- Select trades with BUSINESS EVENT affecting position only
------

------SECTOR_INSTRUMENT_ASSOCIATION 
left join SECTOR_INSTRUMENT_ASSOCIATION 
on SECTOR_INSTRUMENT_ASSOCIATION.sicovam = TITRES.sicovam 
and SECTOR_INSTRUMENT_ASSOCIATION.type=1364 --1364 BBG Country Code
------

------SECTOR
left join SECTORS
on SECTORS.id = SECTOR_INSTRUMENT_ASSOCIATION.sector
------

------MARKET
LEFT JOIN MARCHE
	ON MARCHE.codedevise = TITRES.devisectt
		AND MARCHE.mnemomarche = TITRES.marche
------

------JPM PSET BIC
left join EXTRNL_REF_MARKET_VALUE
on  EXTRNL_REF_MARKET_VALUE.currency = MARCHE.codedevise
and EXTRNL_REF_MARKET_VALUE.market = MARCHE.mnemomarche 
and EXTRNL_REF_MARKET_VALUE.ref_ident=3 --3	JPM PSET BIC
------

WHERE  HISTOMVTS.backoffice NOT IN (select KERNEL_STATUS_ID from BO_KERNEL_STATUS_COMPONENT where KERNEL_STATUS_GROUP_ID=68415) -- Exclude cancelled trades    
AND TITRES.type in ('A')  --INST_TYPE A = Shares O = Bonds
AND TRUNC(HISTOMVTS.DATENEG) >= '01-MAR-2016' -- START_DATE
--AND TRUNC(HISTOMVTS.DATENEG) <= '01-MAR-2016' -- START_DATE
AND TRUNC(HISTOMVTS.DATENEG) <= '08-MAY-2017' -- END_DATE
AND AFFECTATION.libelle NOT IN (
    'External fund series'
    ,'External funds'
    ,'Indexes'
    ,'Internal Funds'
    ,'Share - Dummy'
    ,'Shares - Delisted'
    ,'Shares - Suspended'
    ,'Shares - Ticker Change'
    ,'Shares - Unlisted'
    )
;

--LIST ALL MARKET WITH JPM PSET BIC
select 

 MARCHE.mnemomarche MARKET_ID
, num_to_str(MARCHE.mnemomarche) MARKET_CODE
, MARCHE.codedevise CCY_CODE
, DEVISE_TO_STR(MARCHE.codedevise) CCY
, MARCHE.libelle MARKET_NAME
, EXTRNL_REF_MARKET_VALUE.value MARKET_PSET_BIC

from MARCHE

left join EXTRNL_REF_MARKET_VALUE
on  EXTRNL_REF_MARKET_VALUE.currency = MARCHE.codedevise
and EXTRNL_REF_MARKET_VALUE.market = MARCHE.mnemomarche 
and EXTRNL_REF_MARKET_VALUE.ref_ident=3 --3	JPM PSET BIC

order by CCY
;
