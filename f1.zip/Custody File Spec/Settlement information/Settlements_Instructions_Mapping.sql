/*
BTG_MAPPING_SOURCE
1	Settlement Instruction

BTG_MAPPING_TYPE
1	Clearer BIC Code
2	EuroClearer BIC Code
3	Clearer Safe Account Code

*/

---------------------------------EUROCLEAR PARTICIPANT CODE---------------------------------

--The INPUT_CODE is a concatenation of Counterparty ID and ISO Currency code connected by _

select 
BTG_MAPPING_CODE.source_id
,BTG_MAPPING_CODE.type_id
,BTG_MAPPING_CODE.input_code
,BTG_MAPPING_CODE.output_code EUROCLEAR_PARTICIPANT_CODE
,NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code) CPTY_ID
,TIERS.name CPTY_NAME
,SWIFT_CODE.SWIFT CPTY_BIC_CODE
,CPTYGROUP.NAME GROUP_NAME

from BTG_MAPPING_CODE 

left join TIERS on TIERS.ident =  NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code)

left join tiers CPTYGROUP on CPTYGROUP.ident = TIERS.mgr

left join tiersgeneral SWIFT_CODE on SWIFT_CODE.code = TIERS.ident

where BTG_MAPPING_CODE.source_id=1 and BTG_MAPPING_CODE.type_id=2 --EUROCLEAR

order by CPTY_NAME
;
------------------------------------------------------------------

---------------------------------CLEARER BIC---------------------------------
--The INPUT_CODE is a concatenation of Counterparty ID and Bloomberg country ID of the issuer of the traded Fixed Income instrument connected by _

--List all Bloomberg Country Names
select ID,Name from sectors where parent=1364;

select 
BTG_MAPPING_CODE.source_id
,BTG_MAPPING_CODE.type_id
,BTG_MAPPING_CODE.input_code
,REGEXP_REPLACE(BTG_MAPPING_CODE.input_code, '(.*)(_)(.*)', '\3' ) COUNTRY_CODE
,BTG_MAPPING_CODE.output_code CLEARER_BIC_CODE
,NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code) CPTY_ID
,TIERS.name CPTY_NAME
,SWIFT_CODE.SWIFT CPTY_BIC_CODE
,CPTYGROUP.NAME GROUP_NAME

from BTG_MAPPING_CODE 

left join TIERS on TIERS.ident =  NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code)

left join tiers CPTYGROUP on CPTYGROUP.ident = TIERS.mgr

left join tiersgeneral SWIFT_CODE on SWIFT_CODE.code = TIERS.ident

where BTG_MAPPING_CODE.source_id=1 and BTG_MAPPING_CODE.type_id=1 --CLEARER 

order by CPTY_NAME
;
------------------------------------------------------------------

---------------------------------SAFE ACCOUNT---------------------------------
--The INPUT_CODE is a concatenation of Counterparty ID and Bloomberg country ID of the issuer of the traded Fixed Income instrument connected by _

--List all Bloomberg Country Names
select ID,Name from sectors where parent=1364;

select 
BTG_MAPPING_CODE.source_id
,BTG_MAPPING_CODE.type_id
,BTG_MAPPING_CODE.input_code
,REGEXP_REPLACE(BTG_MAPPING_CODE.input_code, '(.*)(_)(.*)', '\3' ) COUNTRY_CODE
,BTG_MAPPING_CODE.output_code SAFE_ACCOUNT_CODE
,NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code) CPTY_ID
,TIERS.name CPTY_NAME
,SWIFT_CODE.SWIFT CPTY_BIC_CODE
,CPTYGROUP.NAME GROUP_NAME

from BTG_MAPPING_CODE 

left join TIERS on TIERS.ident =  NVL(SUBSTR(BTG_MAPPING_CODE.input_code, 0, INSTR(BTG_MAPPING_CODE.input_code, '_')-1), BTG_MAPPING_CODE.input_code)

left join tiers CPTYGROUP on CPTYGROUP.ident = TIERS.mgr

left join tiersgeneral SWIFT_CODE on SWIFT_CODE.code = TIERS.ident

where BTG_MAPPING_CODE.source_id=1 and BTG_MAPPING_CODE.type_id=3 --SAFE ACCOUNT 

order by CPTY_NAME
;
------------------------------------------------------------------