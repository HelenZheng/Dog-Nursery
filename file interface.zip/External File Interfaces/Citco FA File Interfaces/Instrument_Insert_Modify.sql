BEGIN

INSERT INTO amrecon_vacations 
(
select distinct max(refcon)
,
2
,trunc(sysdate)
,0
, null
,3331
from histomvts
where sicovam in
(
select Instrument.sicovam
from titres Instrument

INNER JOIN (
  SELECT infos_histo.sicovam AS sicovam
  , MAX(infos_histo.date_validite) AS modifydate
  FROM infos_histo
  where infos_histo.modif !=1
  group by infos_histo.sicovam
) infos_histo_KEYS
ON infos_histo_KEYS.sicovam = Instrument.sicovam

where  
(to_date('1904-01-01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') + NUMTODSINTERVAL (infos_histo_KEYS.modifydate, 'day')) 
> 
(   SELECT MAX(amrecon_vacations.SENDING_DATE) FROM amrecon_vacations
    INNER JOIN HISTOMVTS ON amrecon_vacations.REFCON = HISTOMVTS.REFCON
    INNER JOIN TITRES ON HISTOMVTS.SICOVAM = TITRES.SICOVAM
    WHERE TITRES.SICOVAM = Instrument.sicovam and esid=3331 and sent=1 )
and Instrument.sicovam in  (select titres.sicovam FROM amrecon_vacations
    INNER JOIN HISTOMVTS ON amrecon_vacations.REFCON = HISTOMVTS.REFCON
    INNER JOIN TITRES ON HISTOMVTS.SICOVAM = TITRES.SICOVAM
    WHERE TITRES.SICOVAM = Instrument.sicovam and esid=3331 and sent=1)    
and Instrument.sicovam NOT in (select titres.sicovam FROM amrecon_vacations
    INNER JOIN HISTOMVTS ON amrecon_vacations.REFCON = HISTOMVTS.REFCON
    INNER JOIN TITRES ON HISTOMVTS.SICOVAM = TITRES.SICOVAM
    WHERE TITRES.SICOVAM = Instrument.sicovam and esid=3331 and sent=0)
    )
group by sicovam
);

COMMIT;

END;
/
EXIT