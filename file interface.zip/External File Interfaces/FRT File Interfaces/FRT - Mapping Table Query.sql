select 
     -- t2.IDENT    Account_Fund_Group_Id
      t2.name    Acount_Fund_Group
      ,t1.ident   Account_Id
      ,t1.name    Account_Name

from tiers t1

left join tiers t2
  on t1.mgr = t2.IDENT

--where t2.name like '%Q%'

where BTG41.ESTDEPOSITAIRE(t1.OPTIONS) = 1
and t2.ident not in (10016965,10008942)
order by Acount_Fund_Group,Account_Name
;