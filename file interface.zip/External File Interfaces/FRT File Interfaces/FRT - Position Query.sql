select cusip.value                CUSIP
      ,sedol.value                      SEDOL
      ,isin.value                       ISIN
      ,symbol.value                     SYMBOL
      ,MIC_Code.value                   EXCHANGE
      
      ,t.reference                      BLOOMBERG
      ,t.libelle                        SECURITY_NAME
      
      
      ,CASE t.type
        WHEN 'A' THEN 'Share'
        WHEN 'D' THEN 'Derivative'
        WHEN 'G' THEN 'CFD'
      END                               INSTRUMENT_TYPE
      
      ,a.libelle                        INSTRUMENT_SUBTYPE
      
      ,FUND_ID
      ,FUND_NAME
      
      ,Depositary.IDENT                 ACCT_NUMBER
      ,Depositary.name                  ACCT_NAME
      
      ,sum(Temp.quantite)                  QUANTITY
      
      
FROM (
      select *
      from histomvts
      
      UNION
      
      select *
      from BTG41.BTG_HISTOMVTS_BACKUP2014
      ) temp
      
      
left join titres t
  on temp.sicovam = t.sicovam
  
LEFT JOIN affectation a
  ON t.affectation = a.ident
  
LEFT JOIN marche
    ON t.marche = marche.mnemomarche
      AND t.devisectt = marche.codedevise

LEFT JOIN extrnl_ref_market_value MIC_Code
    ON MIC_Code.market = marche.mnemomarche
      AND MIC_Code.currency = marche.codedevise
        AND MIC_Code.ref_ident = 7

left join extrnl_references_instruments isin
  on temp.sicovam = isin.sophis_ident
    and isin.ref_ident = 1

left join extrnl_references_instruments sedol
  on temp.sicovam = sedol.sophis_ident
    and sedol.ref_ident = 2
    
left join extrnl_references_instruments cusip
  on temp.sicovam = cusip.sophis_ident
    and cusip.ref_ident = 3
    
LEFT JOIN extrnl_references_instruments symbol
  ON temp.sicovam = symbol.sophis_ident
    AND symbol.ref_ident = 25
    
LEFT JOIN devisev2 Currency
  ON Currency.code = temp.devisepay
  
LEFT JOIN tiers Depositary
  ON DEPOSITARY.ident = temp.DEPOSITAIRE
  
LEFT JOIN TIERS Broker
  ON Broker.ident = temp.courtier
  
INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
            , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID 
            , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME 
            , FOLIO.ident AS STRATEGY_ID 
            , FOLIO.name AS STRATEGY_NAME 
            ,level 
            FROM FOLIO 
            WHERE LEVEL >= 4 
            START WITH FOLIO.ident IN 
            (
            --PCKG_BTG.FOLIO_PRIMARY_FUNDS 
            14414
            --,PCKG_BTG.FOLIO_UCITS_FUND 
            ,90565
            )
            CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
          ) FUND_BOOK_STRATEGY 
  ON FUND_BOOK_STRATEGY.STRATEGY_ID = temp.OPCVM

INNER JOIN BUSINESS_EVENTS 
  ON BUSINESS_EVENTS.id = temp.type
    AND BUSINESS_EVENTS.COMPTA = 1
    
WHERE temp.dateneg <= TRUNC(ADD_MONTHS(sysdate, -9), 'month') --opening position
--WHERE temp.dateneg <= trunc(last_day(add_months(sysdate,-7)))
       
AND BUSINESS_EVENTS.id not in 
(
143	  --Financing Fee
,141	--SL Fee
,2    --Coupon
)

AND temp.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --excludes cancelled trades 

AND t.type in 
(
'A'   --Shares
,'D'  --Derivatives
,'G'  --CFDs
)

AND a.ident not in --Exclude bad allotments
(
1140	--Share - Dummy
,1501	--Shares - Delisted
,1505	--Shares - Ticker Change
) 


group by cusip.value
        ,sedol.value
        ,isin.value
        ,symbol.value
        ,MIC_Code.value
        ,t.reference
        ,t.libelle
        ,CASE t.type
            WHEN 'A' THEN 'Share'
            WHEN 'D' THEN 'Derivative'
            WHEN 'G' THEN 'CFD'
        END
        ,a.libelle
        ,FUND_ID
        ,FUND_NAME
        ,Depositary.IDENT
        ,Depositary.name


HAVING sum(temp.quantite) <> 0

order by cusip
;



