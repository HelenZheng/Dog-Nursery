select h.refcon                   CLIENT_TRANS_ID
          ,CASE t.type
            WHEN 'A' THEN 'Share'
            WHEN 'D' THEN 'Derivative'
            WHEN 'G' THEN 'CFD'
          END                               INSTRUMENT_TYPE
          ,a.libelle                        INSTRUMENT_SUBTYPE
          ,FUND_ID
          ,FUND_NAME
          ,Depositary.IDENT                 ACCT_NUMBER
          ,Depositary.name                  ACCT_NAME
          ,CASE
            WHEN h.type = 147 THEN 'DIVIDEND'
            WHEN h.type = 3	THEN 'STOCK SPLIT'
            WHEN BUSINESS_EVENTS.compta = 1 AND h.quantite > 0 THEN 'BUY'
            WHEN BUSINESS_EVENTS.compta = 1 AND h.quantite < 0 THEN 'SELL'
            ELSE 'UNKNOWN'
          END                               TRANS_TYPE
          ,h.dateneg                        TRADE_DATE
          ,h.quantite                       QUANTITY 
          ,h.cours                          PRICE
          ,DEVISE_TO_STR(currency.code)     CURRENCY
          ,cusip.value                      CUSIP
          ,sedol.value                      SEDOL
          ,isin.value                       ISIN
          ,symbol.value                     SYMBOL
          ,MIC_Code.value                   EXCHANGE
          ,t.reference BLOOMBERG
          ,t.libelle                        SECURITY_NAME
          ,h.DATEVAL                        SETTLE_DATE
          ,h.montant                        NET_AMOUNT
          ,Broker.name                      BROKER_NAME
          ,underlyingcusip.value            UNDERLYING_CUSIP
          ,underlyingsedol.value            UNDERLYING_SEDOL
          ,underlyingisin.value             UNDERLYING_ISIN
    
    FROM (
          select * from histomvts
          union all
          select * from btg_histomvts_backup2015 b2015 where not exists (select 1 from histomvts h where h.refcon = b2015.refcon)
          union all
          select * from btg_histomvts_backup2014 b2014 where not exists (select 1 from btg_histomvts_backup2015 b where b.refcon = b2014.refcon)
         ) h
    
    left join titres t
      on h.sicovam = t.sicovam
            
   left join titres underlying
      ON underlying.sicovam = 
      case when t.type='A' then t.base1 
      when t.type='D' then t.codesj      
      else decode(t.code_emet,0,decode(t.codesj,0,t.codesj2,t.codesj),t.code_emet) end       
      
    LEFT JOIN affectation a
      ON t.affectation = a.ident
      
    LEFT JOIN marche
        ON t.marche = marche.mnemomarche
          AND t.devisectt = marche.codedevise
    
    LEFT JOIN extrnl_ref_market_value MIC_Code
        ON MIC_Code.market = marche.mnemomarche
          AND MIC_Code.currency = marche.codedevise
            AND MIC_Code.ref_ident = 7
    
    left join extrnl_references_instruments isin
      on isin.sophis_ident = (case when t.type = 'G' then underlying.sicovam else t.sicovam end)
        and isin.ref_ident = 1
    
    left join extrnl_references_instruments sedol
      on sedol.sophis_ident = (case when t.type = 'G' then underlying.sicovam else t.sicovam end)
        and sedol.ref_ident = 2
        
    left join extrnl_references_instruments cusip
      on cusip.sophis_ident = (case when t.type = 'G' then underlying.sicovam else t.sicovam end)
        and cusip.ref_ident = 3
        
    LEFT JOIN extrnl_references_instruments symbol
      ON symbol.sophis_ident = (case when t.type = 'G' then underlying.sicovam else t.sicovam end)
        AND symbol.ref_ident = 25
        
    left join extrnl_references_instruments underlyingisin
      on underlyingisin.sophis_ident = (case when t.type = 'G' then NULL else underlying.sicovam end)
        and underlyingisin.ref_ident = 1
    
    left join extrnl_references_instruments underlyingsedol
      on underlyingsedol.sophis_ident = (case when t.type = 'G' then NULL else underlying.sicovam end)
        and underlyingsedol.ref_ident = 2
        
    left join extrnl_references_instruments underlyingcusip
      on underlyingcusip.sophis_ident = (case when t.type = 'G' then NULL else underlying.sicovam end)
        and underlyingcusip.ref_ident = 3        
        
    LEFT JOIN devisev2 Currency
      ON Currency.code = h.devisepay
      
    LEFT JOIN tiers Depositary
      ON DEPOSITARY.ident = h.DEPOSITAIRE
      
    LEFT JOIN TIERS Broker
      ON Broker.ident = h.courtier
      
    INNER JOIN ( SELECT CONNECT_BY_ROOT(FOLIO.ident) AS TOP_FUND_ID 
                , CONNECT_BY_ROOT(FOLIO.name) AS TOP_FUND_NAME 
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 1, 2) AS FUND_ID 
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 1, 2) AS Fund_NAME 
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.ident, '�'), '[^�]+', 3, 4) AS BOOK_ID 
                , REGEXP_SUBSTR(SYS_CONNECT_BY_PATH(FOLIO.name, '�'), '[^�]+', 3, 4) AS BOOK_NAME 
                , FOLIO.ident AS STRATEGY_ID 
                , FOLIO.name AS STRATEGY_NAME 
                ,level 
                FROM FOLIO 
                WHERE LEVEL >= 4 
                START WITH FOLIO.ident IN 
                (
                --PCKG_BTG.FOLIO_PRIMARY_FUNDS 
                14414
                --,PCKG_BTG.FOLIO_UCITS_FUND 
                ,90565
                )
                CONNECT BY PRIOR FOLIO.ident = FOLIO.mgr 
              ) FUND_BOOK_STRATEGY 
      ON FUND_BOOK_STRATEGY.STRATEGY_ID = h.OPCVM
    
    INNER JOIN BUSINESS_EVENTS 
      ON BUSINESS_EVENTS.id = h.type
    
        
    WHERE h.dateneg >= TRUNC(ADD_MONTHS(sysdate, -9), 'Q')
    AND h.dateneg <= TRUNC(ADD_MONTHS(sysdate, -6), 'Q')
    
    AND BUSINESS_EVENTS.id not in 
    (
    143	  --Financing Fee
    ,141	--SL Fee
    ,2    --Coupon
    )
    
    AND h.backoffice NOT IN (192,11,13,17,26,27,220,248,252) --excludes cancelled trades 
    AND t.type in 
    (
    'A'   --Shares
    ,'D'  --Derivatives
    ,'G'  --CFDs
    )
    
    AND a.ident not in --Exclude bad allotments
    (
    1140	--Share - Dummy
    ,1501	--Shares - Delisted
    ,1505	--Shares - Ticker Change
    )

order by 9 asc
;

