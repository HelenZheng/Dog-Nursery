BEGIN

INSERT INTO amrecon_vacations 
(
	SELECT DISTINCT trades.refcon
	,2
	,trunc(sysdate)
	,0
	,trunc(sysdate)
	,3183 
	FROM histomvts trades 
	
	INNER JOIN 
	(
	SELECT histomvts.sicovam
		,histomvts.refcon
		,histomvts.dateneg
		,histomvts.dateval
		,histomvts.mvtident
		,histomvts.depositaire
		,histomvts.contrepartie
		,histomvts.backoffice
	FROM histomvts
	INNER JOIN amrecon_vacations ON amrecon_vacations.refcon = histomvts.refcon
		AND amrecon_vacations.esid = 3183
		AND amrecon_vacations.generation_type IN (2,3)
		AND amrecon_vacations.sent = 0
	WHERE histomvts.type IN (240,242)
	) partial_term 
	ON partial_term.sicovam = trades.sicovam
	AND partial_term.mvtident = trades.mvtident
	AND partial_term.dateneg <= trades.dateneg
	AND partial_term.refcon != trades.refcon 
	
	LEFT JOIN amrecon_vacations pending_trade 
	ON pending_trade.refcon = trades.refcon
	AND pending_trade.sent = 0
	AND pending_trade.esid = 3183 
	
	INNER JOIN amrecon_vacations sent 
	ON sent.refcon = trades.refcon
	AND sent.sent = 1
	AND sent.generation_type IN (1,2)
	AND sent.esid = 3183 
	
	WHERE trades.backoffice IN (12,16,244)
	AND trades.type IN (240,242)
	AND pending_trade.refcon IS NULL
);

COMMIT;

END;
/
EXIT