BEGIN
	UPDATE amrecon_vacations
	SET sent = 0
	WHERE esid = 3183
	AND generation_type = 3
	AND refcon IN 
	(
			SELECT *
			FROM 
			(
				(
					SELECT DISTINCT cancelled_trades.refcon
					FROM amrecon_vacations cancelled_trades
					
					INNER JOIN (
						SELECT max(sending_date) AS latest_sent
						FROM amrecon_vacations
						WHERE esid = 3183
							AND sent = 1
						) last_sent
					ON last_sent.latest_sent = cancelled_trades.sending_date
						
					INNER JOIN btg_emir_confirm
					ON btg_emir_confirm.refcon = cancelled_trades.refcon
					AND btg_emir_confirm.UTI IS NOT NULL
					
					INNER JOIN (
						SELECT UTI.refcon uti_refcon
						FROM btg_emir_uti_audit all_refcon
						INNER JOIN btg_emir_uti_audit UTI
							ON UTI.uti = all_refcon.uti
						INNER JOIN amrecon_vacations
							ON all_refcon.refcon = amrecon_vacations.refcon
						INNER JOIN btg_emir_confirm
							ON btg_emir_confirm.refcon = all_refcon.refcon
								AND btg_emir_confirm.UTI = UTI.UTI
						WHERE amrecon_vacations.esid = 3183
							AND amrecon_vacations.sent = 1
							AND AMRECON_VACATIONS.GENERATION_TYPE IN (1,2)
							AND to_char(amrecon_vacations.sending_date, 'yyyymmddhh24miss') > to_char(all_refcon.audit_timestamp, 'yyyymmddhh24miss')
						) UTI_sent
					ON UTI_sent.uti_refcon = cancelled_trades.refcon
					
					INNER JOIN (
						SELECT allocation.refcon trade_id
						FROM histomvts allocation
						INNER JOIN ta_block_to_generated
							ON ta_block_to_generated.generated_id = allocation.refcon
						INNER JOIN TA_CANCELLED_TO_CLONE
							ON TA_CANCELLED_TO_CLONE.cancelled_id = abs(ta_block_to_generated.block_id)
						INNER JOIN histomvts execution
							ON execution.refcon = TA_CANCELLED_TO_CLONE.clone_id
						WHERE execution.backoffice = 260
						) Unallocated_clone_excution
					ON Unallocated_clone_excution.trade_id = cancelled_trades.refcon

					INNER JOIN histomvts
                    ON cancelled_trades.refcon=histomvts.refcon
                    AND histomvts.type in (1,444,6) -- Purchase/Sale, Purchase/Sale Off Market, Currency
					
					WHERE cancelled_trades.esid = 3183
					AND cancelled_trades.generation_type IN (3)
					AND cancelled_trades.sent = 1
					)
				
				UNION
				
				(
					SELECT DISTINCT cancelled_trades.REFCON
					FROM amrecon_vacations cancelled_trades
					INNER JOIN (
						SELECT max(sending_date) AS latest_sent
						FROM amrecon_vacations
						WHERE esid = 3183
							AND sent = 1
						) last_sent
					ON last_sent.latest_sent = cancelled_trades.sending_date
					
					INNER JOIN btg_emir_confirm
					ON btg_emir_confirm.refcon = cancelled_trades.refcon
					AND btg_emir_confirm.UTI IS NOT NULL
					
					LEFT JOIN (
						SELECT UTI.refcon uti_refcon
						FROM btg_emir_uti_audit all_refcon
						INNER JOIN btg_emir_uti_audit UTI
							ON UTI.uti = all_refcon.uti
						INNER JOIN amrecon_vacations
							ON all_refcon.refcon = amrecon_vacations.refcon
						INNER JOIN btg_emir_confirm
							ON btg_emir_confirm.refcon = all_refcon.refcon
								AND btg_emir_confirm.UTI = UTI.UTI
						WHERE amrecon_vacations.esid = 3183
							AND amrecon_vacations.sent = 1
							AND AMRECON_VACATIONS.GENERATION_TYPE IN (1,2)
							AND to_char(amrecon_vacations.sending_date, 'yyyymmddhh24miss') > to_char(all_refcon.audit_timestamp, 'yyyymmddhh24miss')
						) UTI_sent
					ON UTI_sent.uti_refcon = cancelled_trades.refcon
					
					INNER JOIN (
						SELECT btg_emir_uti_audit.refcon
							,max(btg_emir_uti_audit.audit_timestamp) AS max_utitime
						FROM btg_emir_uti_audit
						
						INNER JOIN (
							SELECT refcon
								,max(sending_date) AS maxtime
							FROM amrecon_vacations
							WHERE esid = 3183
								AND generation_type IN (1,2)
								AND sent = 1
							GROUP BY refcon
							) maxtime
						ON btg_emir_uti_audit.refcon = maxtime.refcon
						
						WHERE to_char(maxtime.maxtime, 'yyyymmddhh24miss') > to_char(btg_emir_uti_audit.audit_timestamp, 'yyyymmddhh24miss')
						
						GROUP BY btg_emir_uti_audit.refcon
						) different_UTI_sent
					ON different_UTI_sent.refcon = cancelled_trades.refcon
					
					INNER JOIN (
						SELECT allocation.refcon trade_id
						FROM histomvts allocation
						INNER JOIN ta_block_to_generated
							ON ta_block_to_generated.generated_id = allocation.refcon
						INNER JOIN TA_CANCELLED_TO_CLONE
							ON TA_CANCELLED_TO_CLONE.cancelled_id = abs(ta_block_to_generated.block_id)
						INNER JOIN histomvts execution
							ON execution.refcon = TA_CANCELLED_TO_CLONE.clone_id
						WHERE execution.backoffice = 260
						) Unallocated_clone_excution
					ON Unallocated_clone_excution.trade_id = cancelled_trades.refcon

					INNER JOIN histomvts
                    ON cancelled_trades.refcon=histomvts.refcon
                    AND histomvts.type in (1,444,6) -- Purchase/Sale, Purchase/Sale Off Market, Currency
					
					WHERE cancelled_trades.esid = 3183
					AND cancelled_trades.generation_type IN (3)
					AND cancelled_trades.sent = 1
					AND UTI_sent.uti_refcon IS NULL
					)
				)
			);

COMMIT;
END;
/
EXIT
