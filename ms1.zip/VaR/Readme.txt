

	ADDING new Proxies

		- Use VAR_SPOT_IMPORT File
		- Update Table in Proxy_Mapping File


